#!/usr/bin/env bash
# Developer helper: rebuild the frontend and run the server on all interfaces.
set -e
cd "$(dirname "$0")"
pip install -r backend/requirements.txt
(cd frontend && npm install && npm run build)
cd backend && CAFE_PORT="${PORT:-8000}" python -m app.serve --port "${PORT:-8000}"
