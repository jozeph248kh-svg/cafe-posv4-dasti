#!/usr/bin/env bash
# Build the shippable ZIP («بستهٔ آمادهٔ اجرا») from this working tree.
#
# Why a script: the release used to be packed by hand, and hand-packing already shipped one release
# without the built UI, and another with a LF start.bat (Windows cmd needs CRLF). Every rule below is
# a rule that has bitten us once:
#   • .git / node_modules / data / caches / local screenshots never ship
#   • the built UI (frontend/ui) always ships — the shop PC has no Node.js
#   • start.bat is rewritten with CRLF line endings
#   • the Persian «شروع-از-اینجا.txt» and the UI screenshots go in docs/
#
# Usage: tools/package.sh [output.zip] [version]
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)
OUT=${1:-$HOME/cafe-pos-final.zip}
VER=${2:-dev}
SHOTS=${SHOTS:-$ROOT/../qa-shots}       # the UI screenshots live next to the project, not inside it
STAGE=$(mktemp -d)
trap 'rm -rf "$STAGE"' EXIT

test -f frontend/ui/index.html || { echo "frontend/ui is missing — run: cd frontend && npm run build" >&2; exit 1; }

mkdir -p "$STAGE/cafe-pos"
tar -cf - \
  --exclude=./.git --exclude=./frontend/node_modules --exclude=./node_modules --exclude=./data \
  --exclude='__pycache__' --exclude=.pytest_cache --exclude=.ruff_cache --exclude=./qa-shots \
  --exclude=./shots --exclude='*.pyc' --exclude=./crawl.json \
  . | tar -xf - -C "$STAGE/cafe-pos"

# Windows launcher must keep CRLF, whatever the checkout did to it
python3 - "$STAGE/cafe-pos/start.bat" <<'PY'
import sys
p = sys.argv[1]
data = open(p, 'rb').read().replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
open(p, 'wb').write(data)
PY

# UI screenshots for the owner + the release note
for pair in "ui-1-floor.png:tables-hover-rest.png" "ui-2-floor-hover.png:tables-hover-hover.png" \
            "ui-5-floor-dark.png:tables-dark.png" "ui-7-floor-tablet.png:tables-tablet.png" \
            "ui-3-buttons-hover.png:buttons-hover.png" "ui-6-order-panel-hover.png:pos-actions-hover.png" \
            "ui-10-dwell-ok.png:tables-dwell-normal.png" "ui-11-dwell-warn.png:tables-dwell-warning.png" \
            "ui-12-dwell-late.png:tables-dwell-late.png"; do
  src=${pair%%:*}; dst=${pair##*:}
  [ -f "$SHOTS/$src" ] && cp "$SHOTS/$src" "$STAGE/cafe-pos/docs/$dst"
done

if [ -f "$ROOT/docs/شروع-از-اینجا.txt" ]; then cp "$ROOT/docs/شروع-از-اینجا.txt" "$STAGE/cafe-pos/"; fi

rm -f "$OUT"
( cd "$STAGE" && zip -r -q -9 "$OUT" cafe-pos )
echo "built $OUT"
unzip -t "$OUT" | tail -1
unzip -l "$OUT" | tail -2
sha256sum "$OUT"
