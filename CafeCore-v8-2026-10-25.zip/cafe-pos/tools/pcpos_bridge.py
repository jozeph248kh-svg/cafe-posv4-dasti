"""
پل کارتخوان (PC-POS Bridge) — نسخه مرجع
==========================================
این برنامه روی کامپیوتر ویندوزیِ کنار کارتخوان اجرا می‌شود و قرارداد ساده HTTP/JSON نرم‌افزار کافه را
به SDK اختصاصی شرکت PSP (سداد، به‌پرداخت، پارسیان، سامان‌کیش، ...) وصل می‌کند.

    python pcpos_bridge.py --port 8090 --token SECRET            # حالت شبیه‌ساز (پیش‌فرض)
    python pcpos_bridge.py --port 8090 --adapter mypsp.Adapter   # با آداپتور واقعی

قرارداد:
    GET  /status  -> {"ok": true, "psp": "...", "version": "1.0"}
    POST /sale    {"uid", "amount" (ریال), "terminal", "device", "orderId", "timeout"}
               -> {"status": "approved|declined|error|cancelled", "rrn", "trace", "card", "code", "message"}
    POST /cancel  {"uid"}

برای اتصال واقعی یک کلاس Adapter با متدهای sale(amount_rial, device, timeout, cancel_event) و name بنویسید.
بیشتر PSPها SDK دات‌نت (DLL) می‌دهند که با بسته pythonnet قابل فراخوانی است؛ نمونه (فرضی — نام کلاس‌ها
و متدها را از مستند SDK همان PSP بردارید):

    import clr; clr.AddReference(r"C:\\PSP\\PcPosLibrary.dll")
    from PcPosLibrary import PcPosBusiness
    class Adapter:
        name = "sadad"
        def sale(self, amount, device, timeout, cancel_event):
            pos = PcPosBusiness(); pos.Ip, pos.Port = device.split(":")[0], int(device.split(":")[1])
            r = pos.Sale(str(amount))
            return {"status": "approved" if r.ResponseCode == "00" else "declined", "rrn": r.RRN,
                    "trace": r.TraceNumber, "card": r.CardNumber, "code": r.ResponseCode, "message": r.Message}
"""
import argparse
import importlib
import json
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CANCEL: dict[str, threading.Event] = {}


class Simulator:
    name = "simulator"

    def sale(self, amount, device, timeout, cancel_event):
        for _ in range(40):
            if cancel_event.wait(0.1):
                return {"status": "cancelled", "message": "لغو شد"}
        if (amount // 10_000) % 100 == 13:
            return {"status": "declined", "code": "51", "message": "موجودی کافی نیست"}
        return {"status": "approved", "rrn": str(random.randint(10**11, 10**12 - 1)), "trace": str(random.randint(100000, 999999)),
                "card": f"610433******{random.randint(1000, 9999)}", "code": "00", "message": "تراکنش موفق"}


def make_handler(adapter, token):
    class H(BaseHTTPRequestHandler):
        def _send(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _auth(self):
            if token and self.headers.get("Authorization") != f"Bearer {token}":
                self._send(401, {"status": "error", "message": "توکن نامعتبر"})
                return False
            return True

        def do_GET(self):
            if self._auth() and self.path.startswith("/status"):
                self._send(200, {"ok": True, "psp": adapter.name, "version": "1.0"})

        def do_POST(self):
            if not self._auth():
                return
            data = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
            if self.path.startswith("/cancel"):
                ev = CANCEL.get(data.get("uid", ""))
                if ev:
                    ev.set()
                return self._send(200, {"ok": True})
            if self.path.startswith("/sale"):
                ev = CANCEL.setdefault(data.get("uid", str(time.time())), threading.Event())
                try:
                    res = adapter.sale(int(data["amount"]), data.get("device"), int(data.get("timeout") or 90), ev)
                except Exception as e:  # noqa: BLE001
                    res = {"status": "error", "message": str(e)}
                finally:
                    CANCEL.pop(data.get("uid", ""), None)
                print(time.strftime("%H:%M:%S"), data.get("amount"), "→", res.get("status"), res.get("rrn") or res.get("message"))
                return self._send(200, res)
            self._send(404, {"status": "error", "message": "not found"})

        def log_message(self, *a):
            pass
    return H


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="PC-POS bridge for Cafe POS")
    ap.add_argument("--port", type=int, default=8090)
    ap.add_argument("--token", default="")
    ap.add_argument("--adapter", default="", help="module.Class of a real PSP adapter")
    a = ap.parse_args()
    adapter = Simulator()
    if a.adapter:
        mod, cls = a.adapter.rsplit(".", 1)
        adapter = getattr(importlib.import_module(mod), cls)()
    print(f"PC-POS bridge ({adapter.name}) listening on 0.0.0.0:{a.port}")
    ThreadingHTTPServer(("0.0.0.0", a.port), make_handler(adapter, a.token)).serve_forever()
