# راهنمای توسعه — Cafe POS

این فایل برای کسی است که کد را تغییر می‌دهد (نه برای نصب روی دستگاه صندوق).
راهنمای نصب و استفاده در `README.md` است.

## پیش‌نیازها

| ابزار | نسخه | برای چه |
|---|---|---|
| Python | ۳٫۱۰ یا جدیدتر (تست‌شده: ۳٫۱۳) | بک‌اند |
| Node.js | ۲۰ یا جدیدتر | فقط ساخت فرانت‌اند |

## نصب محیط توسعه

```bash
python -m venv .venv && source .venv/bin/activate    # ویندوز: .venv\Scripts\activate
pip install -r backend/requirements-dev.txt

cd frontend && npm ci && cd ..
```

## اجرای تست‌ها

```bash
bash test.sh            # همان چیزی که CI اجرا می‌کند: lint + تست بک‌اند + تست فرانت
bash test.sh --build    # به‌علاوه build تولیدی فرانت‌اند
```

یا جداگانه:

```bash
cd backend && python -m pytest          # ۱۸۲ تست
cd frontend && npm test                 # ۹۵ تست (vitest)
cd frontend && npm run build            # ساخت مجدد frontend/ui
```

### تست کامپوننت در فرانت‌اند
کتابخانه‌ها: `vitest` + `@testing-library/react` + `@testing-library/user-event`.
الگو: وابستگی‌های مرزی (`core/api`، `core/auth`، `core/realtime`) را با `vi.mock` استاب کنید و
خودِ کامپوننت را واقعی نگه دارید — نمونه‌ها در `src/modules/pos/OrderPanel.test.jsx` و
`src/components/PinPad.test.jsx`.

دو نکته که وقت آدم را می‌گیرد:
- پاک‌سازی خودکار `@testing-library` در `src/test/setup.js` وصل شده است (چون vitest در این پروژه
  بدون `globals` اجرا می‌شود). اگر `afterEach(cleanup)` را بردارید، تست‌ها روی هم انبار می‌شوند.
- `antd-jalali` زیر vitest لود **نمی‌شود** (به مسیر داخلی `antd/es/...` بدون پسوند import می‌کند و
  لودر Node آن را پیدا نمی‌کند). در تست‌هایی که به آن برمی‌خورید، پکیج را `vi.mock` کنید؛ منطق تقویم
  در `src/core/jalali.test.js` مستقیم تست شده است.

## تست مرورگری (E2E)

تست‌های واحد قطعه‌ها را ثابت می‌کنند؛ این یکی ثابت می‌کند **کنار هم کار می‌کنند**:

```bash
pip install playwright httpx && python -m playwright install chromium
python qa/e2e_money.py            # ۱۴ بررسی، سرور و داده‌ی موقت خودش را می‌سازد
```

مسیر کامل: ورود با PIN → باز کردن صندوق → لمس میز → لمس آیتم منو → ارسال به آشپزخانه →
پرداخت نقدی → بسته شدن سفارش → **ثبت مصرف در دفتر انبار** → دیده شدن در گزارش فروش.
در CI هم به‌صورت job جداگانه (`e2e`) اجرا می‌شود.

بقیه‌ی اسکریپت‌های مرورگری در `qa/` هستند (پیمایش همه‌ی صفحه‌ها، تخفیف، آفلاین، شمارش کور،
چاپ ESC/POS، HTTPS، fuzz) — فهرستشان در `qa/README.md`.

> روی سرور لینوکسِ خالی، کرومیوم به چند کتابخانه نیاز دارد:
> `sudo apt-get install -y libnss3 libnspr4 libatk1.0-0t64 libatk-bridge2.0-0t64 libatspi2.0-0t64 libasound2t64 libxkbcommon0 libxdamage1`

## چیزهایی که نباید فراموش شوند

1. **`frontend/ui` را کامیت کنید.** خروجی build داخل مخزن نگه داشته می‌شود تا دستگاه صندوق
   به Node.js نیاز نداشته باشد. اگر فایل‌های `frontend/src` را تغییر دادید، `npm run build`
   و سپس کامیت `frontend/ui` لازم است.
2. **نسخه‌های `backend/requirements.txt` را بدون اجرای تست عوض نکنید.** این نسخه‌ها
   دقیقاً همان چیزی هستند که تست شده‌اند.
3. **همه تست‌ها باید سبز باشند** قبل از هر تحویل.

## ساختار

```
backend/
  app/core/        زیرساخت مشترک: db، امنیت، بکاپ، rate limit، پرینتر، realtime ...
  app/modules/     ۲۴ ماژول مستقل (هر کدام models/router/service)
  app/main.py      ساخت اپ و اتصال ماژول‌ها
  tests/           ۲۱ فایل تست
frontend/
  src/core/        منطق خالص: api، format، jalali، print، outbox، skins ...
  src/modules/     صفحه‌های هر قابلیت
  src/components/  کامپوننت‌های مشترک
  ui/              build تولیدی (کامیت می‌شود؛ نام dist عمداً استفاده نمی‌شود)
qa/                اسکریپت‌های تست دستی/کارایی
```

## CI

`.github/workflows/ci.yml` روی هر push و pull request سه کار انجام می‌دهد:

- **backend:** نصب `requirements-dev.txt` → `ruff check` → `pytest`
- **frontend:** `npm ci` → `npm test` → `npm run build`
- **dist check (اطلاع‌دهی):** یک build تازه می‌گیرد و اگر `frontend/ui` کامیت‌شده قدیمی بود
  هشدار می‌دهد. عمداً pipeline را قرمز نمی‌کند تا یک build قدیمی جلوی رفع باگ را نگیرد.

تست PostgreSQL (اختیاری، فقط محلی): `CAFE_TEST_DATABASE_URL=... python -m pytest` — جزئیات در
`backend/tests/conftest.py`.
