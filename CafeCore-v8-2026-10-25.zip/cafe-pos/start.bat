:<<"::BATCH"
@echo off
REM ===================================================================
REM  Cafe POS launcher - works on BOTH Windows and Linux/macOS
REM    Windows : double-click start.bat
REM    Linux   : bash start.bat
REM  (the top part is Windows batch, the bottom part is bash)
REM ===================================================================
setlocal
chcp 65001 >nul
title Cafe POS - Cafe and Restaurant Management
cd /d "%~dp0"
if not defined PORT set "PORT=8000"
set "CAFE_PORT=%PORT%"
echo.
echo  ==============================================
echo       Cafe POS - Cafe and Restaurant System
echo  ==============================================
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (where python >nul 2>nul && set "PY=python")
if not defined PY (
  echo [ERROR] Python is not installed.
  echo         Install Python 3.10+ from https://www.python.org/downloads/
  echo         IMPORTANT: tick "Add python.exe to PATH" during installation.
  pause
  exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python 3.10 or newer is required.
  echo         Install it from https://www.python.org/downloads/
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo [ERROR] Could not create the virtual environment.
    pause
    exit /b 1
  )
)

echo [2/3] Installing Python packages - first run may take a minute...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r backend\requirements.txt
if errorlevel 1 (
  echo [ERROR] Package installation failed. Check your internet connection.
  pause
  exit /b 1
)

if not exist "frontend\ui\index.html" (
  echo       Building the frontend...
  where npm >nul 2>nul || (
    echo [ERROR] Frontend build not found and Node.js is not installed.
    echo         Install Node.js from https://nodejs.org/ and run again.
    pause
    exit /b 1
  )
  pushd frontend
  call npm install
  call npm run build
  popd
)

echo [3/3] Starting server...
echo.
echo  ----------------------------------------------
echo   First login         :  admin / admin123  - you must then choose a new password
echo   Data and backups    :  data folder next to this file
echo   Stop server         :  Ctrl + C
echo   Other devices: use the "Other devices" address printed below.
echo   If Windows Firewall asks, click "Allow access" (Private networks).
echo  ----------------------------------------------
echo.
cd backend
"..\.venv\Scripts\python.exe" -m app.portcheck %PORT%
if errorlevel 1 (
  pause
  exit /b 1
)
"..\.venv\Scripts\python.exe" -m app.serve --port %PORT% --open
echo.
echo Server stopped.
pause
exit /b 0
::BATCH

# ======================= Linux / macOS part (bash) =======================
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8000}"
export CAFE_PORT="$PORT"
echo ""
echo " =============================================="
echo "      Cafe POS - Cafe and Restaurant System"
echo " =============================================="
echo ""

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "[ERROR] Python 3.10+ is not installed.  (Ubuntu/Debian: sudo apt install python3 python3-venv)"
  exit 1
fi
if ! "$PY" -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"; then
  echo "[ERROR] Python 3.10 or newer is required (found: $("$PY" --version 2>&1))."
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  echo "[1/3] Creating virtual environment..."
  "$PY" -m venv .venv || {
    echo "[ERROR] Could not create venv.  Ubuntu/Debian: sudo apt install python3-venv"
    rm -rf .venv; exit 1; }
fi

echo "[2/3] Installing Python packages - first run may take a minute..."
.venv/bin/python -m pip install --disable-pip-version-check -q -r backend/requirements.txt

if [ ! -f frontend/ui/index.html ]; then
  echo "      Building the frontend..."
  if ! command -v npm >/dev/null 2>&1; then
    echo "[ERROR] Frontend build not found and Node.js is not installed (https://nodejs.org/)."
    exit 1
  fi
  (cd frontend && npm install && npm run build)
fi

echo "[3/3] Starting server..."
echo ""
echo " ----------------------------------------------"
echo "  First login         :  admin / admin123  - you must then choose a new password"
echo "  Data and backups    :  ./data"
echo "  Stop server         :  Ctrl + C"
echo "  Other devices: use the 'Other devices' address printed below."
echo " ----------------------------------------------"
echo ""
cd backend
../.venv/bin/python -m app.portcheck "$PORT" || exit 1
exec ../.venv/bin/python -m app.serve --port "$PORT" --open
