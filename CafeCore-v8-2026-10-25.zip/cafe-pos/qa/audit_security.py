"""
Phase 10 — security checks against the running app (authorised, test data only).

Covers: unauthenticated access, role separation on financial endpoints, injection attempts,
path traversal, mass-assignment of money fields, login rate limiting, secret leakage in responses
and logs, and CORS defaults.

  python qa/audit_security.py
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8101"))
BASE = f"http://127.0.0.1:{PORT}"
fails, total = [], [0]


def check(name, ok, extra=""):
    total[0] += 1
    if not ok:
        fails.append(f"{name} → {extra}")
        print(f"FAIL {name}  → {extra}")
    else:
        print(f"PASS {name}")


def raw_get(path: str) -> tuple[int, bytes]:
    """GET with the path exactly as written (no client-side ../ normalisation)."""
    import socket
    s = socket.create_connection(("127.0.0.1", PORT), timeout=15)
    try:
        s.sendall(f"GET {path} HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n".encode())
        data = b""
        while chunk := s.recv(65536):
            data += chunk
    finally:
        s.close()
    return int(data.split(b" ")[1]), data


def main():
    data = tempfile.mkdtemp(prefix="cafe-audit-sec-")
    log = open(os.path.join(data, "server.log"), "w+")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                           stdout=log, stderr=subprocess.STDOUT)
    for _ in range(160):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                break
        except Exception:
            pass
        time.sleep(0.25)
    try:
        def login(u, p):
            r = httpx.post(BASE + "/api/staff/auth/login", json={"username": u, "password": p})
            return {"Authorization": "Bearer " + r.json()["token"]}
        A = login("admin", "admin123")
        C = login("reza", "cashier123")
        W = login("ali", "waiter123")
        K = login("chef", "kitchen123")
        token = A["Authorization"].split()[1]
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})

        print("---- unauthenticated access")
        for path in ("/api/reports/sales", "/api/orders/active", "/api/staff/users", "/api/system/settings",
                     "/api/inventory/ingredients", "/api/system/backups", "/api/system/audit"):
            r = httpx.get(BASE + path)
            check(f"{path} needs a token", r.status_code in (401, 403), r.status_code)

        print("\n---- role separation on financial data")
        for who, h, path in (("waiter", W, "/api/reports/sales"), ("waiter", W, "/api/system/audit"),
                             ("chef", K, "/api/reports/sales"), ("waiter", W, "/api/staff/users"),
                             ("waiter", W, "/api/shifts/staff-reports")):
            r = httpx.get(BASE + path, headers=h)
            check(f"{who} cannot read {path}", r.status_code in (401, 403), r.status_code)

        print("\n---- privilege escalation attempts")
        r = httpx.post(BASE + "/api/staff/users", headers=W, json={"username": "evil", "full_name": "Evil",
                                                                   "password": "evil123", "role_id": 1})
        check("a waiter cannot create an admin user", r.status_code in (401, 403), r.status_code)
        r = httpx.put(BASE + "/api/system/settings", headers=W, json={"tax.percent": 0})
        check("a waiter cannot change tax settings", r.status_code in (401, 403), r.status_code)
        r = httpx.post(BASE + "/api/orders/discounts/presets", headers=W, json={"name": "x", "kind": "percent", "value": 100})
        check("a waiter cannot create a 100% discount preset", r.status_code in (401, 403), r.status_code)

        print("\n---- injection attempts (parameterised queries must treat them as data)")
        r = httpx.get(BASE + "/api/customers", headers=A, params={"q": "'; DROP TABLE customers; --"})
        check("SQL injection text in a search is handled as data", r.status_code in (200, 422), r.status_code)
        r = httpx.get(BASE + "/api/orders", headers=A, params={"q": "1 OR 1=1"})
        check("boolean injection in the order search is handled", r.status_code in (200, 422), r.status_code)
        r = httpx.get(BASE + "/api/customers", headers=A)
        check("tables still exist after the injection attempts", r.status_code == 200, r.status_code)
        r = httpx.post(BASE + "/api/menu/categories", headers=A, json={"name": "<img src=x onerror=alert(1)>", "sort": 1})
        check("markup in a field is accepted as text (escaped by React, not executed)", r.status_code in (201, 422), r.status_code)

        print("\n---- path traversal on file endpoints")
        for name in ("../../secret.key", "..%2f..%2fsecret.key", "cafe.db", "/etc/passwd"):
            r = httpx.get(BASE + f"/api/system/backups/{name}", headers=A)
            check(f"backup download refuses {name!r}", r.status_code in (400, 404, 422), r.status_code)
        # httpx normalises "../" before sending, which would silently turn this into a request for "/secret.key"
        # (the SPA answers that with index.html, 200) — send the raw path over a socket instead.
        status, body = raw_get("/uploads/../../secret.key")
        check("uploads path traversal refuses (raw path)", status in (400, 404), status)
        secret = open(os.path.join(data, "secret.key")).read().strip().encode() if os.path.exists(os.path.join(data, "secret.key")) else b""
        status2, body2 = raw_get("/secret.key")
        check("the key file is not served (SPA fallback only)", secret not in body2 and b"<html" in body2.lower(), status2)

        print("\n---- money fields cannot be mass-assigned from the client")
        full = httpx.get(BASE + "/api/menu/full", headers=C).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        it = next(i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                  and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))
        o = httpx.post(BASE + "/api/orders", headers=C,
                       json={"type": "takeaway", "lines": [{"menu_item_id": it["id"], "qty": 1,
                                                            "unit_price": 1, "total": 1}]})
        check("a client cannot dictate the line price", o.status_code == 201 and o.json()["lines"][0]["unit_price"] == it["price"],
              o.json()["lines"][0]["unit_price"] if o.status_code == 201 else o.status_code)
        o2 = httpx.post(BASE + "/api/orders", headers=C,
                        json={"type": "takeaway", "total": 1, "subtotal": 1, "tax_amount": 0,
                              "lines": [{"menu_item_id": it["id"], "qty": 1}]})
        check("a client cannot dictate the order total", o2.status_code == 201 and o2.json()["total"] > 1,
              o2.json().get("total") if o2.status_code == 201 else o2.status_code)
        oid = o2.json()["id"]
        r = httpx.post(BASE + f"/api/orders/{oid}/payments", headers=C,
                       json={"payments": [{"method": "cash", "amount": 10**9}]})
        check("an over-payment is capped/refused, not written as given", r.status_code >= 400 or r.json()["paid_amount"] <= r.json()["total"],
              r.status_code)

        print("\n---- login throttling")
        codes = []
        for _ in range(8):
            codes.append(httpx.post(BASE + "/api/staff/auth/login",
                                    json={"username": "admin", "password": "wrong-password"}).status_code)
        check("repeated bad passwords are throttled (429)", 429 in codes, codes)

        print("\n---- secret leakage")
        s = httpx.get(BASE + "/api/system/settings", headers=A).json()
        check("no secret keys in the settings response", not any(k in s for k in ("sms.config", "branch.api_key")),
              [k for k in s if "config" in k or "key" in k])
        for path in ("/api/system/info", "/api/branches/local/status", "/api/sms/status"):
            r = httpx.get(BASE + path, headers=A)
            body = r.text
            check(f"{path} does not echo the session token", token not in body, r.status_code)
        # sms status may list the *names* of its config fields, but never a credential value
        sms = httpx.get(BASE + "/api/sms/status", headers=A).json()
        vals = [v for prov in (sms.get("config") or {}).values() if isinstance(prov, dict)
                for k, v in prov.items() if k in ("api_key", "token") and v]
        check("sms status returns only masked credentials", all(str(v).startswith("••••") for v in vals), vals)
        r = httpx.get(BASE + "/api/staff/users", headers=A)
        check("user list has no password/pin hashes", "hash" not in r.text and "$2b$" not in r.text, r.status_code)

        print("\n---- misc headers / CORS")
        r = httpx.get(BASE + "/api/health", headers={"Origin": "http://evil.example"})
        allow = r.headers.get("access-control-allow-origin")
        check("CORS is not wide open by default", allow not in ("*", "http://evil.example"), allow)
        r = httpx.get(BASE + "/api/health")
        check("no server banner leaking versions", "uvicorn" not in (r.headers.get("server") or "").lower(),
              r.headers.get("server"))

        print("\n---- server log must not contain credentials")
        log.flush()
        text = open(os.path.join(data, "server.log"), encoding="utf-8", errors="ignore").read()
        check("no JWT in the log", token[:24] not in text)
        check("no plaintext password in the log", "admin123" not in text and "cashier123" not in text)
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
        log.close()
        shutil.rmtree(data, ignore_errors=True)

    print(f"\n{total[0] - len(fails)}/{total[0]} security checks passed")
    if fails:
        print("\nfailures:")
        for f in fails:
            print(" -", f)
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
