import httpx, time, statistics, datetime as dt, json
B = "http://127.0.0.1:8011"
for _ in range(60):
    try:
        httpx.get(B + "/api/health", timeout=1); break
    except Exception: time.sleep(0.5)
H = {"Authorization": "Bearer " + httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}).json()["token"]}
today = dt.date.today(); m1 = today - dt.timedelta(days=30); y1 = today - dt.timedelta(days=364)
cases = [
    ("POS: floor", "/api/orders/floor", {}), ("POS: active orders", "/api/orders/active", {}),
    ("menu full", "/api/menu/full", {}), ("KDS tickets", "/api/kitchen/tickets", {}),
    ("dashboard", "/api/reports/dashboard", {}),
    ("orders list p1", "/api/orders", {"date_from": y1, "date_to": today, "page": 1, "size": 20}),
    ("orders list p500", "/api/orders", {"date_from": y1, "date_to": today, "page": 500, "size": 20}),
    ("orders search", "/api/orders", {"date_from": y1, "date_to": today, "q": "123"}),
    ("sales report today", "/api/reports/sales", {}),
    ("sales report 30d", "/api/reports/sales", {"date_from": m1, "date_to": today}),
    ("sales report 365d", "/api/reports/sales", {"date_from": y1, "date_to": today}),
    ("P&L 30d", "/api/expenses/pnl", {"date_from": m1, "date_to": today}),
    ("excel export 30d", "/api/reports/sales/export", {"date_from": m1, "date_to": today}),
    ("inventory list", "/api/inventory/ingredients", {}), ("audit log", "/api/system/audit", {}),
]
res = []
for name, path, params in cases:
    ts = []
    for _ in range(5):
        t = time.perf_counter(); r = httpx.get(B + path, headers=H, params=params, timeout=120); ts.append((time.perf_counter() - t) * 1000)
    res.append((name, r.status_code, round(statistics.median(ts)), round(max(ts)), len(r.content)))
# write path: create + pay an order
item = next(i for i in httpx.get(B + "/api/menu/full", headers=H).json()["items"] if not i["modifier_group_ids"] and not (i["code"] or "").startswith("__"))
httpx.post(B + "/api/shifts/open", headers=H, json={"opening_cash": 0})
ts = []
for _ in range(20):
    t = time.perf_counter()
    o = httpx.post(B + "/api/orders", headers=H, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    r = httpx.post(B + f"/api/orders/{o['id']}/payments", headers=H, json={"payments": [{"method": "card", "amount": o["total"]}]})
    ts.append((time.perf_counter() - t) * 1000)
res.append(("create+pay order (2 calls)", r.status_code, round(statistics.median(ts)), round(max(ts)), 0))
for r in res: print(f"{r[0]:<28} {r[1]}  median {r[2]:>6} ms   max {r[3]:>6} ms   {r[4]/1024:,.0f} KB")
