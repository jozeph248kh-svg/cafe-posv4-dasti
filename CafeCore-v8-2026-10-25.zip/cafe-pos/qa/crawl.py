"""Crawl every screen as admin in 3 viewports; record console/page errors, failed API calls, horizontal overflow, tiny touch targets."""
import json, httpx, sys
from playwright.sync_api import sync_playwright
B = "http://127.0.0.1:8001"
ADMIN = ["dashboard", "orders", "online", "reservations", "delivery", "shifts", "customers", "club", "reports", "finance/pnl", "finance/expenses",
         "menu", "floor", "inventory/ingredients", "inventory/food-cost", "inventory/purchases", "inventory/count", "inventory/movements",
         "marketplace", "sms", "card-readers", "moadian", "branches", "staff", "settings", "audit", "modules", "discounts", "timeclock"]
PAGES = ["/", "/pos", "/kds", "/my-shift"] + [f"/admin/{p}" for p in ADMIN] + ["/menu", "/order"]
VIEWS = {"desktop": (1440, 900), "tablet": (1024, 768), "mobile": (390, 844)}
tok = httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}).json()["token"]
report = {}
with sync_playwright() as p:
    br = p.chromium.launch()
    for vname, (w, h) in VIEWS.items():
        ctx = br.new_context(viewport={"width": w, "height": h}, locale="fa-IR", has_touch=vname != "desktop")
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        page = ctx.new_page()
        cur = {"errs": []}
        page.on("console", lambda m: m.type == "error" and cur["errs"].append("console: " + m.text[:200]))
        page.on("pageerror", lambda e: cur["errs"].append("pageerror: " + str(e)[:200]))
        page.on("response", lambda r: r.status >= 400 and "/api/" in r.url and cur["errs"].append(f"http {r.status} {r.url.replace(B, '')[:100]}"))
        for path in PAGES:
            cur["errs"] = []
            page.goto(B + path, wait_until="networkidle")
            page.wait_for_timeout(700)
            m = page.evaluate("""() => {
              const sw = document.documentElement.scrollWidth, iw = window.innerWidth;
              const small = [...document.querySelectorAll('button, a, [role=button], .ant-select-selector')]
                .filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && (r.height < 24 || r.width < 24) && getComputedStyle(e).visibility !== 'hidden'; }).length;
              const empty = !document.querySelector('#root')?.innerText.trim();
              return { overflow: sw - iw, small, empty, dir: document.documentElement.dir || getComputedStyle(document.body).direction };
            }""")
            name = f"{vname}_{path.strip('/').replace('/', '_') or 'home'}"
            page.screenshot(path=f"shots/{name}.png")
            report[name] = {**m, "errors": sorted(set(cur["errs"]))}
        ctx.close()
    br.close()
json.dump(report, open("crawl.json", "w"), ensure_ascii=False, indent=1)
bad = {k: v for k, v in report.items() if v["errors"] or v["overflow"] > 2 or v["empty"]}
print("screens:", len(report), " with problems:", len(bad))
for k, v in bad.items():
    print(k, "overflow" if v["overflow"] > 2 else "", v["overflow"], v["errors"][:4], "EMPTY" if v["empty"] else "")
print("dirs:", {v["dir"] for v in report.values()})
