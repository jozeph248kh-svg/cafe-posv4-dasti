"""Screenshots for the «روح در دکمه‌ها» round: hover elevation on buttons + the new table tiles.

The hover states are CSS-only, so a jsdom test cannot see them. This script drives a real Chromium,
hovers with a real mouse and measures the *computed* transform/box-shadow before and after the hover,
then saves the pictures the owner asked for.
Run:  python qa/shots_hover.py    (needs a server on :8012 with demo data)
"""
import pathlib
import sys

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8061"
OUT = pathlib.Path("/home/user/work/qa-shots")
ok = fail = 0


def check(name, cond, detail=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {name}")
    else:
        fail += 1
        print(f"FAIL {name} {detail}")


def lift_px(transform):
    """translateY from a computed matrix → positive number of pixels the element moved up."""
    if not transform or not transform.startswith("matrix"):
        return 0.0
    return abs(float(transform.split("(")[1].split(",")[-1].rstrip(")")))


def hover_effect(page, selector, label):
    """Move the real mouse off, read the computed style, hover, read again. Returns (before, after)."""
    el = page.locator(selector).first
    box = el.bounding_box()
    page.mouse.move(5, 5)
    page.wait_for_timeout(260)
    before = el.evaluate("e => { const s = getComputedStyle(e); return [s.transform, s.boxShadow] }")
    page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
    page.wait_for_timeout(320)
    after = el.evaluate("e => { const s = getComputedStyle(e); return [s.transform, s.boxShadow] }")
    moved = before[0] != after[0] and after[0] not in ("none", "")
    shadow = before[1] != after[1]
    check(f"{label}: lifts on hover", moved, f"{before[0]} → {after[0]}")
    check(f"{label}: gains a shadow on hover", shadow, after[1][:80])
    return before, after


def admin_token():
    """Demo users ship with must_change_password, and that token may not read anything else → change it once.

    Only the throwaway demo database of this script (CAFE_DATA_DIR under /tmp) is touched; nothing here
    talks to a real installation.
    """
    new = "Qa!Demo1234"                       # the password this script leaves behind on its own demo DB
    for pwd in ("admin123", new):
        r = httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": pwd}, timeout=20)
        if r.status_code == 200 and not r.json().get("must_change_password"):
            return r.json()["token"]
        if r.status_code == 200:              # forced-change token: only /auth/password is allowed with it
            httpx.post(B + "/api/staff/auth/password", headers={"Authorization": "Bearer " + r.json()["token"]},
                       json={"current_password": pwd, "new_password": new}, timeout=20)
    return httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": new}, timeout=20).json()["token"]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    tok = admin_token()
    with sync_playwright() as p:
        br = p.chromium.launch()
        ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR", device_scale_factor=2)
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        page = ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)[:200]))

        # ---------- POS floor ----------
        page.goto(B + "/pos", wait_until="networkidle")
        page.wait_for_selector(".table-card", timeout=20000)
        page.wait_for_timeout(900)
        page.screenshot(path=str(OUT / "ui-1-floor.png"))
        cards = page.locator(".table-card")
        check("floor tiles painted", cards.count() >= 4, cards.count())
        check("no new horizontal overflow on the floor", page.evaluate("document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1"))

        # dwell bar: present on every busy table, fill follows the setting, and it never leaves its track
        bars = page.locator(".table-card:not(.free) .tc-bar")
        check("every busy table shows a dwell bar", bars.count() >= 1, bars.count())
        geom = page.evaluate("""() => [...document.querySelectorAll('.table-card:not(.free) .tc-bar')].map(b => {
          const track = b.getBoundingClientRect().width, fill = b.querySelector('i').getBoundingClientRect().width
          return { pct: Math.round(fill / track * 100), max: +b.getAttribute('aria-valuemax'),
                   now: +b.getAttribute('aria-valuenow'), cls: b.className }
        })""")
        check("bar fill matches minutes / target", all(abs(g["pct"] - min(100, round(g["now"] / g["max"] * 100))) <= 1 for g in geom), geom)
        check("bar never overflows its track", all(0 <= g["pct"] <= 100 for g in geom), geom)
        check("bar limit comes from the setting (90 by default)", all(g["max"] == 90 for g in geom), geom)
        print("sitting bars:", geom)

        # the sitting time is written on the tile and painted in the configured colour
        clock = page.locator(".table-card:not(.free) .tc-clock").first
        check("sitting time is printed on the tile", "′" in clock.inner_text(), clock.inner_text())
        check("sitting time carries a colour level", clock.get_attribute("class").split()[-1] in ("ok", "warn", "late"),
              clock.get_attribute("class"))
        tick = page.evaluate("() => getComputedStyle(document.querySelector('.tc-bar'), '::after').width")
        check("the bar shows where the warning starts", tick not in ("", "auto"), tick)

        occupied = page.locator(".table-card:not(.free)").first
        tile_shift = hover_effect(page, ".table-card:not(.free)", "table tile")[1][0]
        page.screenshot(path=str(OUT / "ui-2-floor-hover.png"))
        check("status is written in words on the tile", page.locator(".tc-pill").first.inner_text().strip() != "")

        # the POS action group (تخفیف / پیش‌فاکتور / پرداخت) must rise as one block, never split apart
        cards = page.locator(".table-card:not(.free)")
        used = None
        for i in range(cards.count()):
            page.locator(".table-card:not(.free)").nth(i).click()
            page.wait_for_timeout(1500)
            if page.locator(".op-actions .ant-space-compact").count():
                used = i
                break
        check("POS action group found", used is not None, "no order panel with a compact button group")
        if used is not None:
            group = page.locator(".op-actions .ant-space-compact").first
            pay = page.locator(".op-actions .btn-pay, .op-actions button").last
            pb = pay.bounding_box()
            gb = group.bounding_box()
            page.mouse.move(5, 5)
            page.wait_for_timeout(260)
            g0 = group.evaluate("e => getComputedStyle(e).transform")
            b0 = pay.evaluate("e => getComputedStyle(e).transform")
            page.mouse.move(pb["x"] + pb["width"] / 2, pb["y"] + pb["height"] / 2)
            page.wait_for_timeout(360)
            g1 = group.evaluate("e => getComputedStyle(e).transform")
            b1 = pay.evaluate("e => getComputedStyle(e).transform")
            check("POS action group lifts as one block", g0 != g1 and g1 not in ("none", ""), f"{g0} → {g1}")
            check("buttons inside the group do not separate", b0 == b1, f"{b0} → {b1}")
            check("the group is still one continuous strip", abs(gb["height"] - group.bounding_box()["height"]) < 1)
            page.screenshot(path=str(OUT / "ui-6-order-panel-hover.png"))
        page.mouse.move(5, 5)
        page.keyboard.press("Escape")
        page.wait_for_timeout(400)

        # ---------- admin page, antd buttons ----------
        page.goto(B + "/admin/customers", wait_until="networkidle")
        page.wait_for_timeout(1200)
        btn = page.locator("button.ant-btn-primary").first
        if btn.count():
            before_btn = hover_effect(page, "button.ant-btn-primary", "primary button")[1][0]
            shift, tile = lift_px(before_btn), lift_px(tile_shift)
            check("a button lifts at least as much as a table tile (owner's rule)",
                  shift >= tile - 0.01, f"button {shift}px vs tile {tile}px")
            page.screenshot(path=str(OUT / "ui-3-buttons-hover.png"))
        else:
            check("primary button exists on the customers page", False, "none found")

        # a default (secondary) button too
        page.goto(B + "/admin/menu", wait_until="networkidle")
        page.wait_for_timeout(1200)
        if page.locator("button.ant-btn-default").count():
            hover_effect(page, "button.ant-btn-default", "default button")
            page.screenshot(path=str(OUT / "ui-4-default-hover.png"))
        else:
            check("default button exists on the menu page", False, "none found")

        # dense places must NOT jump
        page.goto(B + "/admin/orders", wait_until="networkidle")
        page.wait_for_timeout(1500)
        cell_btn = page.locator(".ant-table button.ant-btn").first
        if cell_btn.count():
            tb = cell_btn.bounding_box()
            page.mouse.move(5, 5)
            page.wait_for_timeout(220)
            page.mouse.move(tb["x"] + tb["width"] / 2, tb["y"] + tb["height"] / 2)
            page.wait_for_timeout(280)
            t = cell_btn.evaluate("e => getComputedStyle(e).transform")
            check("buttons inside table rows stay still (no jumping rows)", t in ("none", "matrix(1, 0, 0, 1, 0, 0)"), t)

        # ---------- dark mode ----------
        page.emulate_media(color_scheme="dark")
        page.evaluate("localStorage.setItem('cafe_dark','1')")
        page.goto(B + "/pos", wait_until="networkidle")
        page.wait_for_selector(".table-card", timeout=20000)
        page.wait_for_timeout(900)
        page.screenshot(path=str(OUT / "ui-5-floor-dark.png"))
        check("dark mode still paints the floor", page.locator(".table-card").count() >= 4)
        check("no page crash", not errors, errors[:2])
        br.close()

    print(f"\n{ok}/{ok + fail} checks passed")
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
