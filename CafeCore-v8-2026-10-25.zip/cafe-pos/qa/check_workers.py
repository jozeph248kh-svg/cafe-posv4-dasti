"""
Is it safe to run CafeCore with more than one uvicorn worker? This script answers with measurements, not opinion.

For 1 and 2 workers it starts the real app (`python -m uvicorn app.main:app --workers N`) on a throw-away data
dir and checks the three things that a second process would break:

  A. live updates   — 6 WebSocket clients, then 3 order changes: how many clients received the events?
                      (the realtime hub keeps its sockets in process memory)
  B. background jobs — the start-up backup runs inside each worker: how many backups are written?
  C. concurrent order numbers — 16 simultaneous POST /orders: any duplicate number / 409 conflict?

    python qa/check_workers.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
FACTORY = {"username": "admin", "password": "admin123"}


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def start(data: str, port: int, workers: int) -> subprocess.Popen:
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(port), "CAFE_SAMPLE_USERS": "true", "CAFE_DEMO_DATA": "false",
           "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false", "CAFE_LOGIN_MAX_FAILURES": "100000"}
    proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                             "--port", str(port), "--workers", str(workers), "--log-level", "warning"],
                            cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(300):
        try:
            if httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1).status_code == 200:
                time.sleep(1.0)          # let every worker finish its start-up
                return proc
        except Exception:
            pass
        time.sleep(0.25)
    proc.kill()
    raise SystemExit("server did not start")


def live_updates(port: int, headers: dict, sockets: int = 6, events: int = 3) -> dict:
    """Open `sockets` WebSockets, fire `events` order changes, count who heard the `order.changed` topic."""
    import asyncio

    import websockets

    got = [0] * sockets

    async def client(i: int, stop: asyncio.Event):
        uri = f"ws://127.0.0.1:{port}/ws?token={headers['Authorization'].split()[1]}"
        try:
            async with websockets.connect(uri) as ws:
                while not stop.is_set():
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=0.5)
                    except asyncio.TimeoutError:
                        continue
                    try:
                        if json.loads(raw).get("topic") == "order.changed":
                            got[i] += 1
                    except Exception:
                        pass
        except Exception:
            pass

    async def run():
        stop = asyncio.Event()
        tasks = [asyncio.create_task(client(i, stop)) for i in range(sockets)]
        await asyncio.sleep(1.5)                       # everyone is connected
        for _ in range(events):
            httpx.post(f"http://127.0.0.1:{port}/api/orders", headers=headers,
                       json={"type": "takeaway", "lines": []}, timeout=20)
            await asyncio.sleep(0.4)
        await asyncio.sleep(1.0)
        stop.set()
        await asyncio.gather(*tasks, return_exceptions=True)

    asyncio.run(run())
    return {"clients": sockets, "events_sent": events, "clients_that_heard": sum(1 for c in got if c),
            "events_per_client": got}


def backup_files(data: str) -> int:
    d = os.path.join(data, "backups")
    return len([f for f in os.listdir(d) if f.endswith(".db")]) if os.path.isdir(d) else 0


def parallel_orders(port: int, headers: dict, n: int = 16) -> dict:
    codes, numbers, errors = [], [], []
    gate = threading.Barrier(n)

    def one():
        gate.wait()
        try:
            with httpx.Client(base_url=f"http://127.0.0.1:{port}", headers=headers, timeout=60) as c:
                r = c.post("/api/orders", json={"type": "takeaway", "lines": []})
            codes.append(r.status_code)
            if r.status_code == 201:
                numbers.append(r.json()["number"])
        except Exception as e:                       # noqa: BLE001 — a dropped connection is a result too
            errors.append(f"{type(e).__name__}: {e}")

    ts = [threading.Thread(target=one) for _ in range(n)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return {"requests": n, "created": codes.count(201), "other_codes": sorted({c for c in codes if c != 201}),
            "transport_errors": errors[:3], "n_transport_errors": len(errors),
            "duplicate_numbers": len(numbers) - len(set(numbers))}


def preboot(data: str) -> bool:
    """Create the schema the way a real install does (one process), so the multi-worker test starts from a
    database that already exists — the more favourable case for running several workers."""
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_SAMPLE_USERS": "true", "CAFE_DEMO_DATA": "false",
           "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false", "CAFE_PORT": "8099"}
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", "8099"], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ok = False
    for _ in range(200):
        try:
            if httpx.get("http://127.0.0.1:8099/api/health", timeout=1).status_code == 200:
                ok = True
                break
        except Exception:
            time.sleep(0.25)
    p.terminate()
    try:
        p.wait(20)
    except Exception:
        p.kill()
    return ok


def fresh_db_two_workers() -> dict:
    """The very case an owner hits after an update: an empty data dir and `--workers 2`."""
    data = tempfile.mkdtemp(prefix="cafe-workers-fresh-")
    port = free_port()
    log = os.path.join(data, "server.log")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_SAMPLE_USERS": "true", "CAFE_DEMO_DATA": "false",
           "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    with open(log, "w") as fh:
        p = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                              "--port", str(port), "--workers", "2", "--log-level", "warning"],
                             cwd=BACKEND, env=env, stdout=fh, stderr=subprocess.STDOUT)
        started = False
        for _ in range(120):
            try:
                if httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1).status_code == 200:
                    started = True
                    break
            except Exception:
                pass
            time.sleep(0.25)
        time.sleep(6)                     # a worker that failed to start can still answer briefly
        try:
            served_later = httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=2).status_code == 200
        except Exception:
            served_later = False
        alive = p.poll() is None
        p.terminate()
        try:
            p.wait(20)
        except Exception:
            p.kill()
    text = open(log, errors="replace").read()
    reason = next((ln.strip() for ln in text.splitlines() if "startup failed" in ln.lower() or "already exists" in ln), "")
    shutil.rmtree(data, ignore_errors=True)
    return {"served_requests": started, "serves_after_6s": served_later, "process_alive": alive, "reason": reason[:160]}


def run(workers: int, pg_url: str | None = None) -> dict:
    data = tempfile.mkdtemp(prefix=f"cafe-workers-{workers}-")
    if not pg_url:
        preboot(data)                      # schema exists before the multi-worker start (favourable case)
    port = free_port()
    if pg_url:
        from sqlalchemy import create_engine, text
        eng = create_engine(pg_url)
        with eng.begin() as c:
            c.execute(text("DROP SCHEMA public CASCADE"))
            c.execute(text("CREATE SCHEMA public"))
        eng.dispose()
        os.environ["CAFE_DATABASE_URL"] = pg_url
    proc = start(data, port, workers)
    try:
        tok = httpx.post(f"http://127.0.0.1:{port}/api/staff/auth/login", json=FACTORY).json()["token"]
        H = {"Authorization": f"Bearer {tok}"}
        res = {"workers": workers, "backend": "postgres" if pg_url else "sqlite",
               "startup_backups": backup_files(data)}
        res["live"] = live_updates(port, H)
        res["parallel"] = parallel_orders(port, H)
        return res
    finally:
        proc.terminate()
        try:
            proc.wait(20)
        except Exception:
            proc.kill()
        if pg_url:
            os.environ.pop("CAFE_DATABASE_URL", None)
        shutil.rmtree(data, ignore_errors=True)


def main() -> int:
    print("=== an empty data dir with --workers 2 (what an owner hits after an update) ===")
    fresh = fresh_db_two_workers()
    print(f"  answered /api/health at first: {fresh['served_requests']} · still serving after 6 s: {fresh['serves_after_6s']} · "
          f"process alive: {fresh['process_alive']}")
    print(f"  server said: {fresh['reason'] or '(nothing)'}")

    out = []
    for w in (1, 2):
        print(f"\n=== {w} uvicorn worker(s), existing database ===", flush=True)
        r = run(w)
        out.append(r)
        lv, pl = r["live"], r["parallel"]
        print(f"  live updates : {lv['events_sent']} events → heard by {lv['clients_that_heard']}/{lv['clients']} clients  {lv['events_per_client']}")
        print(f"  start-up backups written: {r['startup_backups']}")
        print(f"  concurrent order creation: {pl['created']}/{pl['requests']} created, other codes {pl['other_codes']}, "
              f"transport errors {pl['n_transport_errors']}, duplicate numbers {pl['duplicate_numbers']}")
        if pl["transport_errors"]:
            print(f"    first errors: {pl['transport_errors']}")
    print("\n=== summary ===")
    for r in out:
        pl = r["parallel"]
        print(f"{r['workers']} worker(s): live delivered to {r['live']['clients_that_heard']}/{r['live']['clients']} clients · "
              f"backups at start-up {r['startup_backups']} · created {pl['created']}/{pl['requests']} · "
              f"other codes {pl['other_codes'] or '-'} · transport errors {pl['n_transport_errors']} · duplicates {pl['duplicate_numbers']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
