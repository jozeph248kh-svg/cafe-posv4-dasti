"""Round 9: theme editor smoke — open «تم جدید», live preview, contrast table, save as business default, restore."""
import json, sys, urllib.request
from playwright.sync_api import sync_playwright
B = "http://localhost:8001"; OUT = "/home/user/qa/audit/r9/"
def api(method, path, body=None, tok=None):
    r = urllib.request.Request(B + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                               headers={"content-type": "application/json", **({"authorization": f"Bearer {tok}"} if tok else {})})
    return json.load(urllib.request.urlopen(r))
tok = api("POST", "/api/staff/auth/login", {"username": "admin", "password": "admin123"})["token"]
before = api("GET", "/api/system/theme")
res, errs = [], []
def check(name, ok, detail=""): res.append((name, bool(ok))); print(("PASS " if ok else "FAIL ") + name, detail)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={"width": 1440, "height": 900}); pg = ctx.new_page()
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(B + "/login"); pg.evaluate(f"localStorage.clear(); localStorage.setItem('cafe_token', '{tok}')")
        pg.goto(B + "/admin/settings?tab=theme", wait_until="networkidle"); pg.wait_for_timeout(800)
        check("gallery shows 6 built-in skins", pg.locator(".skin-card").count() >= 6, pg.locator(".skin-card").count())
        prim0 = pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()")
        check("classic primary by default", prim0 == "#4f46e5", prim0)
        pg.locator(".skin-new").click(); pg.locator(".skin-editor").wait_for(); pg.wait_for_timeout(500)
        pg.locator(".skin-name").fill("تست سبز")
        # change primary via the colour picker text input
        pg.locator(".se-color").first.locator(".ant-color-picker-trigger").click()
        inp = pg.locator(".ant-color-picker-input input").first; inp.fill("0F7B5F"); inp.press("Enter"); pg.wait_for_timeout(600)
        pg.screenshot(path=OUT + "editor_picker.png")
        pg.locator(".skin-editor .ant-drawer-title").click(); pg.wait_for_timeout(400)   # close the picker popup, keep the drawer
        prim1 = pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()")
        check("live preview repaints the whole app", prim1 == "#0f7b5f", prim1)
        check("contrast table rendered", pg.locator(".contrast-table tbody tr").count() >= 20, pg.locator(".contrast-table tbody tr").count())
        pg.screenshot(path=OUT + "editor.png")
        pg.locator(".skin-save-default").click(); pg.wait_for_timeout(1200)
        t = api("GET", "/api/system/theme")
        check("saved on server as business default", t["skin"] != "classic" and any(c["name"] == "تست سبز" and c["light"]["primary"] == "#0f7b5f" for c in t["custom"]), t["skin"])
        prim2 = pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()")
        check("app keeps the new default after closing the editor", prim2 == "#0f7b5f", prim2)
        # a second device (fresh context) follows the business default …
        c2 = b.new_context(); p2 = c2.new_page(); p2.goto(B + "/login", wait_until="networkidle"); p2.wait_for_timeout(600)
        check("other device (login page) follows business default", p2.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()") == "#0f7b5f")
        # … unless it chose its own skin
        p2.evaluate("localStorage.setItem('cafe_skin', 'rose')"); p2.reload(wait_until="networkidle"); p2.wait_for_timeout(400)
        check("device override wins", p2.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()") == "#be185d")
        # live push: business default changes → open page repaints without reload
        api("PUT", "/api/system/theme", {"skin": "jade", "custom": t["custom"]}, tok); pg.wait_for_timeout(1500)
        check("realtime theme.changed repaints open devices", pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()") == "#2f7d5b")
        c2.close(); b.close()
finally:
    api("PUT", "/api/system/theme", before, tok)
check("no page errors", not errs, errs[:3])
print(f"{sum(ok for _, ok in res)}/{len(res)} passed")
sys.exit(0 if all(ok for _, ok in res) else 1)
