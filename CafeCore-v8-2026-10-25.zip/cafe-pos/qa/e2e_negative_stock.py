"""
The negative-stock alert as a manager actually sees it, in a real browser.

  1. an ingredient with a small stock and a menu item that consumes it,
  2. a cashier sells more than the stock (the sale goes through — that is the policy),
  3. the manager's screen shows the red «موجودی منفی» badge, and the popover lists
     the item, the stock before, the stock after and the shortage,
  4. a second sale in the same episode does not add a second alert (no spam), but the shortage follows.

    python qa/e2e_negative_stock.py        # own data dir, own server on :8078
"""
import os
import subprocess
import sys
import tempfile
import time

import httpx
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8078"))
BASE = f"http://127.0.0.1:{PORT}"
FA = {str(i): d for i, d in enumerate("۰۱۲۳۴۵۶۷۸۹")}
results = []


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def start_server(env):
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)],
                            cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(200):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.25)
    proc.kill()
    raise SystemExit("server did not start")


def main():
    data = tempfile.mkdtemp(prefix="cafe-e2e-negative-")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = start_server(env)
    shots = os.path.join(ROOT, "qa", "shots")
    os.makedirs(shots, exist_ok=True)
    try:
        def login(u, p):
            t = httpx.post(BASE + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]
            return {"Authorization": "Bearer " + t}

        A, C = login("admin", "admin123"), login("reza", "cashier123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})

        ing = httpx.post(BASE + "/api/inventory/ingredients", headers=A,
                         json={"name": "شیر تست مرورگر", "unit": "g", "opening_stock": 400, "min_stock": 0, "cost_per_unit": 30}).json()
        cats = httpx.get(BASE + "/api/menu/categories", headers=A).json()
        item = httpx.post(BASE + "/api/menu/items", headers=A,
                          json={"category_id": cats[0]["id"], "name": "نوشیدنی تست موجودی", "price": 120_000}).json()
        httpx.put(f"{BASE}/api/inventory/recipes/item/{item['id']}", headers=A,
                  json=[{"ingredient_id": ing["id"], "qty": 100}])

        with sync_playwright() as p:
            browser = p.chromium.launch()
            ctx = browser.new_context(viewport={"width": 1400, "height": 900}, locale="fa-IR")
            tok = A["Authorization"].split()[1]
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
            page = ctx.new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

            page.goto(BASE + "/admin/inventory/ingredients", wait_until="networkidle")
            page.wait_for_timeout(1200)
            check("no alert badge while the stock is fine", page.locator(".stock-alert-tag").count() == 0)

            # a sale of 7 × 100 g = 700 g against 400 g in stock (the cashier keeps selling)
            o = httpx.post(BASE + "/api/orders", headers=C,
                           json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 7}]}).json()
            pay = httpx.post(f"{BASE}/api/orders/{o['id']}/payments", headers=C,
                             json={"payments": [{"method": "cash", "amount": o["total"]}]})
            check("the sale beyond the stock went through", pay.status_code == 200 and pay.json()["status"] == "closed", pay.text[:200])

            page.wait_for_timeout(2500)          # the badge refreshes on the live event
            check("the manager sees the negative-stock badge", page.locator(".stock-alert-tag").count() > 0)
            page.locator(".stock-alert-tag").first.click()
            page.wait_for_timeout(800)
            text = page.locator(".ant-popover").inner_text()
            check("the alert names the item", "شیر تست مرورگر" in text, text[:200])
            check("it shows before / after / shortage", "−۳۰۰" in text and "۳۰۰" in text and "۴۰۰" in text, text[:300])
            page.screenshot(path=os.path.join(shots, "negative_stock_alert.png"))

            alerts = httpx.get(BASE + "/api/inventory/alerts", headers=A).json()
            check("one open alert for that ingredient", len([a for a in alerts if a["ingredient_id"] == ing["id"]]) == 1, alerts)

            # a second sale in the same episode must not add a second alert
            o2 = httpx.post(BASE + "/api/orders", headers=C,
                            json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 2}]}).json()
            httpx.post(f"{BASE}/api/orders/{o2['id']}/payments", headers=C, json={"payments": [{"method": "cash", "amount": o2["total"]}]})
            page.wait_for_timeout(2000)
            alerts = httpx.get(BASE + "/api/inventory/alerts", headers=A).json()
            mine = [a for a in alerts if a["ingredient_id"] == ing["id"]]
            check("still one alert, but the shortage grew", len(mine) == 1 and mine[0]["shortage"] == 500, mine)

            check("no page or console errors", not errors, errors[:3])
            browser.close()
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=15)
        except Exception:
            srv.kill()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
