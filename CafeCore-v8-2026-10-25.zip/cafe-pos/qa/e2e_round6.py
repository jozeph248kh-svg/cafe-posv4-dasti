"""Browser test of round-6 multi-register + limited offline mode on the demo server (:8001):

  manager : Shifts page register bar, register manager, open a second register, "use on this device"
  cashier : POS asks which register this device uses; X-Register-Id is sent; shift tag shows the register
  offline : (browser offline) payment refused with a clear message, new order + added items go to the device queue,
            back online → queue sent once (no duplicates), replay with the same request id adds nothing
Leaves the demo data as it was: the QA register is closed and disabled, test orders are cancelled.
Fails on any console error (except the expected offline network errors), page error or API 5xx; shots/r6_*.png.
"""
import json
import sys

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
ok, fail = [], []
QA_REG = "صندوق تست QA"


def check(name, cond, info=""):
    (ok if cond else fail).append(name + (f" — {info}" if info and not cond else ""))
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


def login(u, p):
    return httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]


cash_tok, mgr_tok = login("reza", "cashier123"), login("sara", "manager123")
H = lambda t, **x: {"Authorization": f"Bearer {t}", **x}  # noqa: E731
full = httpx.get(B + "/api/menu/full", headers=H(mgr_tok)).json()
item = next(i for i in full["items"] if i["is_available"] and not i["code"].startswith("__") and not i["modifier_group_ids"])

# QA register: reuse (re-enable) or create
regs = httpx.get(B + "/api/shifts/registers", headers=H(mgr_tok), params={"all": 1}).json()
qa = next((r for r in regs if r["name"] == QA_REG), None)
if qa:
    qa = httpx.put(f"{B}/api/shifts/registers/{qa['id']}", headers=H(mgr_tok), json={"name": QA_REG, "is_active": True, "sort": 50}).json()
else:
    qa = httpx.post(B + "/api/shifts/registers", headers=H(mgr_tok), json={"name": QA_REG, "sort": 50}).json()
main = next(r for r in httpx.get(B + "/api/shifts/registers", headers=H(mgr_tok)).json() if r["is_main"])
main_was_open = bool(main["open_shift"])
QA_ID = qa["id"]


def open_orders():
    return {o["id"]: o for o in httpx.get(B + "/api/orders", headers=H(mgr_tok), params={"status": "open", "size": 200}).json()["items"]}


def order(oid):
    return httpx.get(f"{B}/api/orders/{oid}", headers=H(mgr_tok)).json()


def qty(o):
    return sum(x["qty"] for x in o["lines"] if x["status"] != "void")


errors, offline_phase = [], [False]
before = set(open_orders())
with sync_playwright() as pw:
    br = pw.chromium.launch()

    def ctx_for(tok, register=None):
        ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')" + (f";localStorage.setItem('cafe_register', '{register}')" if register else ""))
        pg = ctx.new_page()

        def on_console(m):
            t = m.text
            if m.type != "error" or "status of 403" in t or "status of 400" in t:
                return
            if offline_phase[0] and ("ERR_INTERNET_DISCONNECTED" in t or "WebSocket" in t or "Failed to fetch" in t):
                return
            errors.append("console: " + t[:200])
        pg.on("console", on_console)
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
        pg.on("response", lambda r: r.status >= 500 and errors.append(f"http {r.status} {r.url}"))
        return ctx, pg

    # ------------------------------------------------------------ manager: Shifts page
    ctx, pg = ctx_for(mgr_tok)
    pg.goto(B + "/admin/shifts", wait_until="networkidle")
    check("register bar shown (several registers)", pg.locator(".registers-bar .reg-view").count() == 1)
    pg.locator(".reg-manage").click()
    pg.wait_for_selector(".reg-new-name")
    dlg = pg.locator(".ant-modal-content", has=pg.locator(".reg-new-name"))
    names = dlg.locator(".ant-table-row input[type=text], .ant-table-row input:not([role])").evaluate_all("els => els.map(e => e.value)")
    check("register manager lists main + QA", "صندوق اصلی" in names and QA_REG in names, names)
    pg.screenshot(path="shots/r6_registers_manager.png")
    dlg.locator(".ant-modal-close").click()
    pg.locator(".reg-view").click()
    pg.locator(".ant-select-item-option", has_text=QA_REG).click()
    pg.wait_for_timeout(600)
    check("header shows the viewed register", QA_REG in pg.locator(".page-header h3").first.inner_text())
    pg.get_by_role("button", name="باز کردن صندوق", exact=True).click()
    m = pg.locator(".ant-modal-content").last
    check("open dialog names the register", QA_REG in m.inner_text())
    m.locator("input").first.fill("500000")
    m.get_by_role("button", name="ثبت").click()
    pg.wait_for_timeout(1000)
    regs = {r["id"]: r for r in httpx.get(B + "/api/shifts/registers", headers=H(mgr_tok)).json()}
    check("QA register opened from the UI", bool(regs[QA_ID]["open_shift"]))
    check("main register untouched", bool(regs[main["id"]]["open_shift"]) == main_was_open)
    pg.locator(".reg-use").click()
    pg.wait_for_timeout(300)
    check("«use on this device» stores the register", pg.evaluate("localStorage.getItem('cafe_register')") == str(QA_ID))
    pg.screenshot(path="shots/r6_shifts_register.png")
    ctx.close()

    # ------------------------------------------------------------ cashier: POS asks for the register
    ctx, pg = ctx_for(cash_tok)
    sent_headers = []
    pg.on("request", lambda r: "/api/" in r.url and sent_headers.append(r.headers.get("x-register-id")))
    pg.goto(B + "/pos", wait_until="networkidle")
    pg.wait_for_selector(".reg-pick", timeout=8000)
    check("POS asks which register this device uses", pg.locator(".reg-pick").count() == 1)
    pg.screenshot(path="shots/r6_pos_pick_register.png")
    pg.locator(".reg-pick").click()
    pg.locator(".ant-select-item-option", has_text=QA_REG).click()
    pg.locator(".reg-pick-ok").click()
    pg.wait_for_timeout(1200)
    check("choice saved on the device", pg.evaluate("localStorage.getItem('cafe_register')") == str(QA_ID))
    check("requests carry X-Register-Id", str(QA_ID) in sent_headers)
    tag = pg.locator(".shift-tag")
    check("shift tag shows register + open", tag.count() == 0 or (QA_REG in tag.inner_text() and "باز" in tag.inner_text()), tag.inner_text() if tag.count() else "")

    # an online takeaway order, kept open on screen
    def new_takeaway():
        pg.get_by_role("button", name="بیرون‌بر").first.click()
        pg.locator(".ant-modal-content .ant-btn-primary").last.click()
        pg.wait_for_timeout(300)
        pg.locator(".item-card", has_text=item["name"]).first.click()
        pg.wait_for_timeout(200)
        pg.locator(".btn-send").click()
        pg.wait_for_timeout(1200)

    new_takeaway()
    created = [oid for oid in open_orders() if oid not in before]
    check("online order created", len(created) == 1, created)
    first = created[0] if created else None

    # ------------------------------------------------------------ offline
    offline_phase[0] = True
    ctx.set_offline(True)
    pg.wait_for_timeout(500)
    pg.locator(".btn-pay").click()
    pg.wait_for_timeout(500)
    check("payment refused offline with a clear message", pg.locator(".ant-modal-confirm", has_text="پرداخت در حالت آفلاین ممکن نیست").count() == 1)
    pg.screenshot(path="shots/r6_offline_pay.png")
    pg.get_by_role("button", name="متوجه شدم").click()
    # add an item to the open order → queued
    pg.locator(".item-card", has_text=item["name"]).first.click()
    pg.wait_for_timeout(200)
    pg.locator(".btn-send").click()
    pg.wait_for_timeout(800)
    check("added items queued with a warning", pg.locator(".ant-message", has_text="صف آفلاین").count() >= 1)
    # a brand-new order → queued
    new_takeaway()
    box = json.loads(pg.evaluate("localStorage.getItem('cafe_outbox')") or "[]")
    check("two entries in the device queue", len(box) == 2 and {e["kind"] for e in box} == {"lines", "create"}, [e["kind"] for e in box])
    check("queue badge visible", pg.locator(".outbox-tag").count() == 1)
    pg.locator(".outbox-tag").click()
    pg.wait_for_timeout(400)
    pg.screenshot(path="shots/r6_offline_queue.png")
    pg.keyboard.press("Escape")
    check("nothing reached the server while offline", qty(order(first)) == 1 and len([o for o in open_orders() if o not in before]) == 1)

    # ------------------------------------------------------------ back online → synced once
    ctx.set_offline(False)
    pg.wait_for_function("!(JSON.parse(localStorage.getItem('cafe_outbox') || '[]').length)", timeout=20000)
    pg.wait_for_timeout(800)
    offline_phase[0] = False
    now_open = [oid for oid in open_orders() if oid not in before]
    check("queue sent after reconnect", len(now_open) == 2, now_open)
    check("added item applied exactly once", qty(order(first)) == 2, qty(order(first)))
    check("sync toast shown", pg.locator(".ant-message", has_text="از صف آفلاین").count() >= 1)
    # replaying the same requests (e.g. a second device restored the same storage) adds nothing
    lines_e = next(e for e in box if e["kind"] == "lines")
    create_e = next(e for e in box if e["kind"] == "create")
    r1 = httpx.post(f"{B}/api/orders/{lines_e['order_id']}/lines", headers=H(cash_tok), json={"lines": lines_e["lines"], "send": True, "request_id": lines_e["id"]})
    r2 = httpx.post(B + "/api/orders", headers=H(cash_tok), json={**create_e["draft"], "lines": create_e["lines"], "send": True, "request_id": create_e["id"], "merge_if_busy": True})
    check("replay is a no-op", r1.status_code == 200 and qty(r1.json()) == 2 and r2.status_code == 201
          and len([o for o in open_orders() if o not in before]) == 2, (r1.status_code, r2.status_code))
    ctx.close()
    br.close()

# ------------------------------------------------------------ cleanup
for oid in [o for o in open_orders() if o not in before]:
    httpx.post(f"{B}/api/orders/{oid}/cancel", headers=H(mgr_tok), json={"reason": "پایان تست QA"})
c = httpx.post(B + "/api/shifts/close", headers=H(mgr_tok), json={"counted_cash": 500000, "register_id": QA_ID})
check("QA register closed", c.status_code == 200, c.text[:200])
d = httpx.put(f"{B}/api/shifts/registers/{QA_ID}", headers=H(mgr_tok), json={"name": QA_REG, "is_active": False, "sort": 50})
check("QA register disabled again", d.status_code == 200, d.text[:200])
check("no console/page errors or 5xx", not errors, errors[:5])
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
