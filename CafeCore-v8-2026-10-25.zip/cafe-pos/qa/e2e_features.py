"""Browser test of the discount system, management reports and backup settings (demo server on :8001).

  cashier: preset bill discount (within ceiling) → custom 25% (over the 10% ceiling → manager PIN) → item comp (PIN)
  admin:   «تخفیف‌ها» page (presets + ceilings), every report tab, Z report, backups tab
Fails on any console error, page error or API 5xx; screenshots go to shots/feat_*.png.
"""
import sys

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
ok, fail = [], []


def check(name, cond, info=""):
    (ok if cond else fail).append(name + (f" — {info}" if info and not cond else ""))
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


def login(u, p):
    return httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]


cash_tok, admin_tok, mgr_tok = login("reza", "cashier123"), login("admin", "admin123"), login("sara", "manager123")
H = lambda t: {"Authorization": f"Bearer {t}"}  # noqa: E731
full = httpx.get(B + "/api/menu/full", headers=H(admin_tok)).json()
groups = {g["id"]: g for g in full["modifier_groups"]}


def line(item, qty=1):
    opts = [next((o for o in groups[g]["options"] if o["is_default"]), groups[g]["options"][0])["id"] for g in item["modifier_group_ids"] if groups[g]["min_select"] >= 1]
    return {"menu_item_id": item["id"], "qty": qty, "modifier_option_ids": opts}


items = [i for i in full["items"] if i["is_available"] and not i["code"].startswith("__")]
order = httpx.post(B + "/api/orders", headers=H(cash_tok), json={"type": "takeaway", "customer_name": "تست تخفیف",
                                                                 "lines": [line(items[0], 2), line(items[3])]}).json()
oid = order["id"]
get_order = lambda: httpx.get(f"{B}/api/orders/{oid}", headers=H(admin_tok)).json()  # noqa: E731

errors, forbidden = [], []
with sync_playwright() as p:
    br = p.chromium.launch()

    def ctx_for(tok):
        ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        pg = ctx.new_page()
        # 403 «override_required» is the designed trigger for the manager-PIN dialog: allowed, but only on discount URLs
        pg.on("console", lambda m: m.type == "error" and "status of 403" not in m.text and errors.append("console: " + m.text[:200]))
        pg.on("response", lambda r: r.status == 403 and (forbidden.append(r.url.replace(B, ""))))
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
        pg.on("response", lambda r: r.status >= 500 and errors.append(f"http {r.status} {r.url}"))
        return ctx, pg

    # ------------------------------------------------------------ cashier: discounts at the register
    ctx, pg = ctx_for(cash_tok)
    pg.goto(B + "/pos", wait_until="networkidle")
    pg.locator(".ob-card", has_text=f"#{order['number']:,}".translate(str.maketrans("0123456789,", "۰۱۲۳۴۵۶۷۸۹٬"))).filter(has_text="تست تخفیف").first.click()  # number alone can collide with older open orders
    pg.wait_for_timeout(500)
    pg.locator(".btn-discount").click()
    pg.wait_for_selector(".disc-preset")
    modal = pg.locator(".ant-modal-content").last
    check("discount dialog shows presets", pg.locator(".disc-preset").count() >= 4)
    check("dialog shows the cashier's ceiling (10%)", "۱۰٪" in modal.inner_text())
    pg.locator(".disc-preset", has_text="جبران تأخیر").click()
    check("preset within ceiling → no PIN needed", "در محدوده مجاز" in modal.inner_text())
    pg.screenshot(path="shots/feat_discount_dialog.png")
    modal.get_by_role("button", name="اعمال تخفیف").click()
    pg.wait_for_timeout(800)
    o = get_order()
    check("preset bill discount applied (10%, max 200k)", o["discount_amount"] == min(round(o["subtotal"] * 0.10), 200_000), o["discount_amount"])
    check("totals show «تخفیف فاکتور»", pg.locator(".op-totals .row.discount", has_text="تخفیف فاکتور").count() == 1)

    pg.locator(".btn-discount").click()
    pg.wait_for_selector(".disc-preset")
    modal = pg.locator(".ant-modal-content").last
    modal.get_by_role("button", name="۲۵٪").click()
    modal.locator(".disc-reason input, input.disc-reason").first.fill("جبران نارضایتی مشتری")
    check("over ceiling → button says manager approval", modal.get_by_role("button", name="اعمال با تأیید مدیر").count() == 1)
    modal.get_by_role("button", name="اعمال با تأیید مدیر").click()
    pg.wait_for_selector(".pinpad")
    pin_modal = pg.locator(".ant-modal-content", has=pg.locator(".pinpad"))
    check("PIN dialog explains the ceiling", "سقف" in pin_modal.inner_text(), pin_modal.inner_text()[:120])
    pg.screenshot(path="shots/feat_discount_pin.png")
    pg.keyboard.type("2222")
    pg.wait_for_timeout(1200)
    o = get_order()
    check("25% applied after manager PIN", o["discount_amount"] == round(o["subtotal"] * 0.25) and o["discount_type"] == "percent", o["discount_amount"])

    # item discount (comp) on the first line
    pg.locator(".ol-row").first.locator("button:has(.anticon-percentage)").click()
    pg.wait_for_selector(".disc-preset")
    modal = pg.locator(".ant-modal-content").last
    check("item dialog title", "تخفیف آیتم" in modal.inner_text())
    pg.locator(".disc-preset", has_text="آیتم معیوب").click()
    modal.locator(".disc-reason input, input.disc-reason").first.fill("سوخته بود")
    modal.get_by_role("button", name="اعمال با تأیید مدیر").click()
    pg.wait_for_selector(".pinpad")
    pg.keyboard.type("2222")
    pg.wait_for_timeout(1200)
    o = get_order()
    first = o["lines"][0]
    check("item comped (100%) with reason", first["discount_amount"] == first["total"] and "سوخته بود" in (first["discount_reason"] or ""), first)
    check("bill discount now applies to the rest", o["discount_amount"] == o["line_discount_amount"] + round((o["subtotal"] - o["line_discount_amount"]) * 0.25))
    check("line shows the discount", pg.locator(".ol-disc").count() >= 1)
    pg.screenshot(path="shots/feat_pos_discounts.png")
    ctx.close()
    httpx.post(f"{B}/api/orders/{oid}/cancel", headers=H(mgr_tok), json={"reason": "پایان تست"})

    # ------------------------------------------------------------ admin: discounts page, reports, backups
    ctx, pg = ctx_for(admin_tok)
    pg.goto(B + "/admin/discounts", wait_until="networkidle")
    check("discounts page lists presets", pg.locator(".ant-table-row").count() >= 6)
    pg.get_by_role("tab", name="سقف تخفیف کارکنان").click()
    pg.wait_for_timeout(600)
    check("ceilings tab lists the cashier role", pg.locator(".ant-table-row", has_text="صندوقدار").count() >= 1)
    pg.screenshot(path="shots/feat_discount_limits.png")

    pg.goto(B + "/admin/reports", wait_until="networkidle")
    for tab in ["مهندسی منو", "تخفیف‌ها", "عملکرد پرسنل", "مغایرت صندوق", "میزها و سالن", "سرعت آشپزخانه", "افزودنی‌ها", "مشتریان", "دفتر مالیات"]:
        before = len(errors)
        t = pg.get_by_role("tab", name=tab)
        if not t.is_visible():                       # antd moves extra tabs into the "more" dropdown
            pg.locator(".ant-tabs-nav-more").click()
            pg.locator(".ant-tabs-dropdown-menu-item", has_text=tab).click()
        else:
            t.click()
        pg.wait_for_timeout(900)
        pane = pg.locator(".ant-tabs-tabpane-active")
        check(f"report tab «{tab}» renders", len(errors) == before and pane.inner_text().strip() != "", errors[before:][:2])
        pg.screenshot(path=f"shots/feat_report_{tab.replace(' ', '_')}.png")
    check("KPI cards compare with previous period", pg.locator(".stat-card", has_text="نسبت به").count() >= 1)
    pg.get_by_role("button", name="گزارش پایان روز (Z)").click()
    pg.wait_for_timeout(900)
    check("Z report preview", "فروش خالص" in pg.locator(".ant-modal-content").last.inner_text())
    pg.screenshot(path="shots/feat_z_report.png")
    pg.keyboard.press("Escape")

    pg.goto(B + "/admin/settings", wait_until="networkidle")
    pg.get_by_role("tab", name="پشتیبان‌گیری").click()
    pg.wait_for_timeout(700)
    txt = pg.locator(".ant-tabs-tabpane-active").inner_text()
    check("backups tab explains hourly/daily policy", "ساعتی" in txt and "روزانه" in txt and "۱۴" in txt, txt[:200])
    pg.screenshot(path="shots/feat_backups.png")
    ctx.close()
    br.close()

check("no console/page errors or 5xx", not errors, errors[:5])
check("403s only from discount approval (manager PIN flow)", forbidden and all("/discount" in u for u in forbidden), forbidden)
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
