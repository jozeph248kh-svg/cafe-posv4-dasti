"""Browser check of LAN HTTPS (server started with CAFE_HTTPS=true via `python -m app.serve --port 8443`).

Certificate trust itself is verified in tests/test_tls.py with real verification against the local CA; here the
browser ignores the (untrusted-in-this-sandbox) CA and checks the app over TLS: secure context, live link over wss://,
pages load, HTTPS help + CA download in Settings.
Usage: python e2e_https.py [https://127.0.0.1:8443] [path/to/ca.crt]
"""
import ssl
import sys

import httpx
from playwright.sync_api import sync_playwright

B = sys.argv[1] if len(sys.argv) > 1 else "https://127.0.0.1:8443"
CA = sys.argv[2] if len(sys.argv) > 2 else "/tmp/httpsdata/tls/ca.crt"
ok, fail = [], []


def check(name, cond, info=""):
    (ok if cond else fail).append(name)
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


ctx_ssl = ssl.create_default_context(cafile=CA)
tok = httpx.post(B + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}, verify=ctx_ssl).json()["token"]
adm = httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}, verify=ctx_ssl).json()["token"]
check("API verified against the local CA", bool(tok))
errors, sockets = [], []
with sync_playwright() as pw:
    br = pw.chromium.launch()
    for who, t in (("cashier", tok), ("admin", adm)):
        ctx = br.new_context(ignore_https_errors=True, viewport={"width": 1440, "height": 900}, locale="fa-IR")
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{t}')")
        pg = ctx.new_page()
        pg.on("console", lambda m: m.type == "error" and "status of 4" not in m.text and errors.append(m.text[:200]))
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
        pg.on("websocket", lambda w: sockets.append(w.url))
        if who == "cashier":
            pg.goto(B + "/pos", wait_until="networkidle")
            pg.wait_for_timeout(1500)
            check("secure context in the browser", pg.evaluate("window.isSecureContext") is True)
            check("live link uses wss://", any(u.startswith("wss://") for u in sockets), sockets)
            check("POS loaded (tables visible)", pg.locator(".ob-card, .table-card, .ft-card").count() > 0 or "سالن" in pg.content())
            check("live status online", pg.locator(".ant-badge-status-success").count() >= 1)
            pg.screenshot(path="shots/https_pos.png")
        else:
            pg.goto(B + "/admin/settings", wait_until="networkidle")
            pg.get_by_role("tab", name="شبکه و دستگاه‌ها").click()
            pg.wait_for_timeout(400)
            box = pg.locator(".https-box")
            check("Settings shows HTTPS on + install help", box.count() == 1 and "دانلود گواهی" in box.inner_text())
            check("LAN addresses shown with https://", "https://" in pg.locator(".ant-tabs-tabpane-active").inner_text())
            with pg.expect_download() as dl:
                box.get_by_text("دانلود گواهی").click()
            path = dl.value.path()
            check("CA certificate downloads from the page", open(path, "rb").read() == open(CA, "rb").read())
            pg.screenshot(path="shots/https_settings.png")
        ctx.close()
    br.close()
check("no console/page errors", not errors, errors[:5])
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
