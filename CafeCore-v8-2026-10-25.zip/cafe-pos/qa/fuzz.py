import os, sys, re, json, shutil, random
D = "/tmp/audit_fuzz"; shutil.rmtree(D, ignore_errors=True)
os.environ.update(CAFE_DATA_DIR=D, CAFE_BACKGROUND_JOBS="false", CAFE_DEMO_DATA="true", CAFE_FORCE_PASSWORD_CHANGE="false", CAFE_LOGIN_MAX_FAILURES="100000")
sys.path.insert(0, os.path.expanduser("~/cafe-pos/backend"))
import logging; logging.disable(logging.CRITICAL)
from fastapi.testclient import TestClient
from app.main import app
c = TestClient(app, raise_server_exceptions=False); c.__enter__()
H = {"Authorization": "Bearer " + c.post("/api/staff/auth/login", json={"username": "admin", "password": "admin123"}).json()["token"]}
spec = app.openapi(); comps = spec["components"]["schemas"]
def resolve(s):
    while "$ref" in s: s = comps[s["$ref"].split("/")[-1]]
    return s
def props(s):
    s = resolve(s)
    if "anyOf" in s: s = resolve(next((x for x in s["anyOf"] if x.get("type") != "null"), s["anyOf"][0]))
    return s
def valid(s, depth=0):
    s = props(s)
    t = s.get("type")
    if "enum" in s: return s["enum"][0]
    if t == "object" or "properties" in s:
        return {k: valid(v, depth+1) for k, v in s.get("properties", {}).items()} if depth < 4 else {}
    if t == "array": return [valid(s.get("items", {}), depth+1)] if depth < 4 else []
    if t == "integer": return max(1, s.get("minimum", 1))
    if t == "number": return 1.5
    if t == "boolean": return True
    if t == "string":
        if s.get("format") == "date": return "2026-01-01"
        if s.get("format") == "date-time": return "2026-01-01T10:00:00"
        return "test-value"
    return "x"
BAD = [None, -1, 10**20, -10**20, "x"*5000, "abc", [], {}, True, 1.5, "٫۱۲۳", "<script>alert(1)</script>", "' OR 1=1 --", "2026-13-45"]
fails = {}
from collections import Counter
stat = Counter(); total = [0]
ids = ["1", "2", "999999", "0", "-1", "99999999999999999999", "abc"]
for path, ops in spec["paths"].items():
    if not path.startswith("/api") or "webhook" in path or "auth/password" in path: continue
    for m, op in ops.items():
        if m == "get" and "{" not in path and not op.get("parameters"): continue
        bodyschema = op.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema")
        variants = []
        base = valid(bodyschema) if bodyschema else None
        variants.append(base); variants.append({}); variants.append("garbage")
        if isinstance(base, dict):
            for k in base:
                for b in random.sample(BAD, 6):
                    v = dict(base); v[k] = b; variants.append(v)
        if isinstance(base, list): variants += [[b] for b in BAD[:6]]
        for pid in ids:
            url = re.sub(r"\{[^}]+\}", pid, path)
            qp = {p["name"]: random.choice(["abc", "-5", "99999999999999999999", "2026-99-99", ""]) for p in op.get("parameters", []) if p["in"] == "query"}
            for v in variants[: (len(variants) if pid == "1" else 2)]:
                if path.endswith("/backups") and m == "post": continue
                r = c.request(m.upper(), url, headers=H, json=v, params=qp if random.random() < 0.5 else None)
                stat[r.status_code] += 1
                if r.status_code >= 500:
                    fails.setdefault(f"{m.upper()} {path}", []).append((pid, json.dumps(v, ensure_ascii=False)[:150], r.text[:120]))
print("requests", sum(stat.values()), dict(stat))
print("endpoints with 5xx:", len(fails))
for k, v in fails.items(): print(k, len(v), "\n    ", v[0])
