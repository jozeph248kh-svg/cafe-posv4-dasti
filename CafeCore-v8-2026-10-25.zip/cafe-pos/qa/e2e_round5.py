"""Browser test of round-5 features on the demo server (:8001):

  admin   : discount presets page (automatic / promo code / buy-X-get-Y / combo editor), ceilings incl. daily & monthly
  cashier : promo code at the register, daily usage in the dialog
  guest   : promo code on the online checkout (/order) → order carries the discount
  manager : refund with return-to-stock; time clock page (log, labour vs sales, wages)
  login   : time clock PIN punch on the login screen; header clock button
Fails on any console error, page error or API 5xx; screenshots go to shots/r5_*.png.
"""
import sys

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
ok, fail = [], []
FA = str.maketrans("0123456789,", "۰۱۲۳۴۵۶۷۸۹٬")


def check(name, cond, info=""):
    (ok if cond else fail).append(name + (f" — {info}" if info and not cond else ""))
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


def login(u, p):
    return httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]


cash_tok, admin_tok, mgr_tok = login("reza", "cashier123"), login("admin", "admin123"), login("sara", "manager123")
H = lambda t: {"Authorization": f"Bearer {t}"}  # noqa: E731
full = httpx.get(B + "/api/menu/full", headers=H(admin_tok)).json()
groups = {g["id"]: g for g in full["modifier_groups"]}


def line(item, qty=1):
    opts = [next((o for o in groups[g]["options"] if o["is_default"]), groups[g]["options"][0])["id"] for g in item["modifier_group_ids"] if groups[g]["min_select"] >= 1]
    return {"menu_item_id": item["id"], "qty": qty, "modifier_option_ids": opts}


items = [i for i in full["items"] if i["is_available"] and not i["code"].startswith("__") and not i["modifier_group_ids"]]
# remove a leftover preset from an earlier run
for p in httpx.get(B + "/api/orders/discounts/presets", headers=H(admin_tok), params={"all": 1}).json():
    if p["code"] == "QA10":
        httpx.delete(f"{B}/api/orders/discounts/presets/{p['id']}", headers=H(admin_tok))

errors = []
with sync_playwright() as pw:
    br = pw.chromium.launch()

    def ctx_for(tok=None, mobile=False):
        ctx = br.new_context(viewport={"width": 420, "height": 860} if mobile else {"width": 1440, "height": 900}, locale="fa-IR")
        if tok:
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        pg = ctx.new_page()
        pg.on("console", lambda m: m.type == "error" and "status of 403" not in m.text and "status of 400" not in m.text
              and errors.append("console: " + m.text[:200]))
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
        pg.on("response", lambda r: r.status >= 500 and errors.append(f"http {r.status} {r.url}"))
        return ctx, pg

    # ------------------------------------------------------------ admin: preset editor
    ctx, pg = ctx_for(admin_tok)
    pg.goto(B + "/admin/discounts", wait_until="networkidle")
    body = pg.locator(".ant-table").first.inner_text()
    check("presets table shows automatic + promo-code presets", "خودکار" in body and "WELCOME20" in body, body[:300])
    check("bogo and combo demo presets listed", "پیتزای دوم نیم‌بها" in body and "قهوه و کیک" in body)
    pg.screenshot(path="shots/r5_presets.png")
    pg.get_by_role("button", name="تخفیف جدید").click()
    drawer = pg.locator(".ant-drawer-content").last
    drawer.wait_for()
    drawer.locator(".ant-segmented-item", has_text="ترکیبی").click()
    pg.wait_for_timeout(300)
    check("combo kind shows the parts editor", drawer.locator(".combo-part").count() >= 1, drawer.inner_text()[:200])
    drawer.locator(".ant-segmented-item", has_text="یکی بخر").first.click()
    pg.wait_for_timeout(300)
    check("bogo kind shows the gift-discount field", "تخفیف هدیه" in drawer.inner_text(), drawer.inner_text()[:300])
    pg.screenshot(path="shots/r5_preset_bogo.png")
    drawer.locator(".ant-segmented-item", has_text="درصدی").click()
    drawer.locator("input#name, input[id$='name']").first.fill("کد تست QA")
    drawer.locator(".ant-radio-button-wrapper", has_text="با کد تخفیف").click()
    pg.wait_for_timeout(300)
    drawer.locator("input[id$='code']").fill("qa10")
    val = drawer.locator("input[id$='value']")
    val.fill("10")
    pg.screenshot(path="shots/r5_preset_code.png")
    drawer.get_by_role("button", name="ذخیره").click()
    pg.wait_for_timeout(1000)
    created = [p for p in httpx.get(B + "/api/orders/discounts/presets", headers=H(admin_tok), params={"all": 1}).json() if p["code"] == "QA10"]
    check("promo-code preset saved from the UI (code upper-cased)", len(created) == 1 and created[0]["value"] == 10, created)
    pg.get_by_role("tab", name="سقف تخفیف کارکنان").click()
    pg.wait_for_timeout(700)
    t = pg.locator(".ant-tabs-tabpane-active").inner_text()
    check("ceilings tab shows daily/monthly columns", "روزانه" in t and "ماهانه" in t, t[:200])
    pg.screenshot(path="shots/r5_limits.png")
    ctx.close()

    # ------------------------------------------------------------ cashier: promo code at the register
    order = httpx.post(B + "/api/orders", headers=H(cash_tok), json={"type": "takeaway", "customer_name": "تست کد",
                                                                     "lines": [line(items[0], 2), line(items[1])]}).json()
    oid = order["id"]
    ctx, pg = ctx_for(cash_tok)
    pg.goto(B + "/pos", wait_until="networkidle")
    pg.locator(".ob-card", has_text=f"#{order['number']:,}".translate(FA)).filter(has_text="تست کد").first.click()  # number alone can collide with older open orders
    pg.wait_for_timeout(500)
    check("header shows the time-clock button", pg.locator(".tc-btn").count() == 1)
    pg.locator(".btn-discount").click()
    pg.wait_for_selector(".disc-code")
    modal = pg.locator(".ant-modal-content").last
    modal.locator(".disc-code input").fill("nope99")
    modal.get_by_role("button", name="اعمال کد").click()
    pg.wait_for_timeout(800)
    check("unknown code refused", httpx.get(f"{B}/api/orders/{oid}", headers=H(cash_tok)).json()["discount_amount"] == 0)
    modal.locator(".disc-code input").fill("qa10")
    pg.screenshot(path="shots/r5_pos_code.png")
    modal.get_by_role("button", name="اعمال کد").click()
    pg.wait_for_timeout(1000)
    o = httpx.get(f"{B}/api/orders/{oid}", headers=H(cash_tok)).json()
    check("promo code applied at the register", o["discount_code"] == "QA10" and o["discount_amount"] == round(o["subtotal"] * 0.10), o["discount_amount"])
    check("totals show the code", pg.locator(".op-totals .row.discount", has_text="QA10").count() == 1)
    pg.screenshot(path="shots/r5_pos_after_code.png")
    ctx.close()
    httpx.post(f"{B}/api/orders/{oid}/cancel", headers=H(mgr_tok), json={"reason": "پایان تست"})

    # ------------------------------------------------------------ guest: online checkout with a code
    ctx, pg = ctx_for(None, mobile=True)
    pg.goto(B + "/order", wait_until="networkidle")
    cards = pg.locator(".qr-item:not(.off)")
    for k in range(3):
        cards.nth(k).click()
        pg.wait_for_timeout(300)
        add = pg.locator(".ant-drawer-content .oa-sheet-foot .ant-btn-primary")
        if add.count() and add.first.is_visible():
            add.first.click()
            pg.wait_for_timeout(300)
    pg.locator(".oa-cartbar").click()
    pg.wait_for_timeout(500)
    sheet = pg.locator(".ant-drawer-content").last
    sheet.locator(".ant-segmented-item", has_text="تحویل حضوری").click()
    sheet.locator("input[id$='customer_name']").fill("مهمان تست")
    sheet.locator("input[id$='phone']").fill("09120000555")
    sheet.locator(".disc-code input").fill("qa10")
    sheet.get_by_role("button", name="اعمال").click()
    pg.wait_for_timeout(900)
    txt = sheet.locator(".oa-sum").inner_text()
    check("checkout shows the promo discount", "تخفیف" in txt and "QA10" in txt, txt)
    pg.screenshot(path="shots/r5_online_promo.png", full_page=True)
    foot = sheet.locator(".oa-sheet-foot .ant-btn-primary")
    if foot.is_enabled():
        foot.click()
        pg.wait_for_timeout(1500)
        check("online order placed → tracking shows the discount", "تخفیف" in pg.locator("body").inner_text())
        pg.screenshot(path="shots/r5_online_track.png", full_page=True)
    else:
        check("online order button enabled (min order reached)", False, foot.inner_text())
    ctx.close()

    # ------------------------------------------------------------ manager: refund with restock
    httpx.post(B + "/api/shifts/open", headers=H(cash_tok), json={"opening_cash": 0})
    o = httpx.post(B + "/api/orders", headers=H(cash_tok), json={"type": "takeaway", "lines": [line(items[2], 2)]}).json()
    pay = httpx.post(f"{B}/api/orders/{o['id']}/payments", headers=H(cash_tok), json={"payments": [{"method": "card", "amount": o["total"]}]})
    check("test order paid", pay.status_code == 200, pay.text[:200])
    ctx, pg = ctx_for(mgr_tok)
    pg.goto(B + "/admin/orders", wait_until="networkidle")
    pg.locator(".ant-table-row", has_text=f"#{o['number']:,}".translate(FA)).first.click()
    pg.wait_for_timeout(700)
    pg.get_by_role("button", name="بازپرداخت").click()
    pg.wait_for_selector(".restock-box")
    m = pg.locator(".ant-modal-content").last
    m.locator("textarea").fill("مشتری پس آورد، باز نشده")
    m.locator(".restock-row input").first.fill("1")
    pg.screenshot(path="shots/r5_refund_restock.png")
    m.get_by_role("button", name="ثبت بازپرداخت").click()
    pg.wait_for_timeout(1200)
    after = httpx.get(f"{B}/api/orders/{o['id']}", headers=H(mgr_tok)).json()
    check("refund recorded with 1 item returned", after["lines"][0]["returned_qty"] == 1 and after["paid_amount"] == 0, after["lines"][0])
    check("detail shows the returned qty", pg.locator("text=برگشت به انبار").count() >= 1)

    # ------------------------------------------------------------ manager: time clock page
    pg.goto(B + "/admin/timeclock", wait_until="networkidle")
    pg.wait_for_timeout(800)
    check("time-clock log lists demo attendance", pg.locator(".ant-table-row").count() >= 5)
    pg.screenshot(path="shots/r5_timeclock_log.png")
    pg.get_by_role("button", name="ثبت دستی").click()
    pg.wait_for_timeout(500)
    check("manual entry dialog opens with Jalali date", pg.locator(".ant-modal-content .ant-picker").count() >= 3)
    pg.screenshot(path="shots/r5_timeclock_manual.png")
    pg.keyboard.press("Escape")
    pg.get_by_role("tab", name="هزینه نیرو و فروش").click()
    pg.wait_for_timeout(1200)
    t = pg.locator(".ant-tabs-tabpane-active").inner_text()
    check("labour tab shows labour % and SPLH", "نسبت هزینه نیرو به فروش" in t and "فروش به ازای هر ساعت کار" in t, t[:200])
    pg.screenshot(path="shots/r5_labor.png", full_page=True)
    pg.get_by_role("tab", name="حقوق و دستمزد").click()          # renamed in round 6 (monthly salary + insurance)
    pg.wait_for_timeout(700)
    check("wages tab lists staff", pg.locator(".ant-tabs-tabpane-active .ant-table-row").count() >= 4)
    pg.screenshot(path="shots/r5_wages.png")
    ctx.close()

    # ------------------------------------------------------------ login screen: PIN punch
    # round 7: a clock-out needs the end-of-shift report first (shift.report_required) — maryam submits it if she is on the clock
    mar_tok = login("maryam", "waiter123")
    if httpx.get(B + "/api/timeclock/me", headers=H(mar_tok)).json()["on_clock"]:
        check("maryam's end-of-shift report submitted before the PIN clock-out",
              httpx.post(B + "/api/shifts/my-report", headers=H(mar_tok), json={"note": "QA"}).status_code == 201)
    ctx, pg = ctx_for(None)
    pg.goto(B + "/login", wait_until="networkidle")
    pg.locator(".ant-segmented-item", has_text="حضور و غیاب").click()
    pg.wait_for_timeout(300)
    pg.keyboard.type("5555")
    pg.wait_for_timeout(1200)
    res = pg.locator(".punch-result")
    check("PIN punch on the login screen shows the result", res.count() == 1 and "ثبت شد" in res.inner_text(), pg.locator(".login-form").inner_text()[:200])
    pg.screenshot(path="shots/r5_login_punch.png")
    check("still on the login page (no session opened)", "/login" in pg.url and not pg.evaluate("localStorage.getItem('cafe_token')"))
    ctx.close()
    br.close()

httpx.post(B + "/api/shifts/close", headers=H(cash_tok), json={"counted_cash": 0})
check("no console/page errors or 5xx", not errors, errors[:5])
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
