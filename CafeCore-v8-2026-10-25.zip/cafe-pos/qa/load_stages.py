"""
Staged load test with real measurements (no estimated numbers).

    python qa/load_stages.py --stages 1200,10000,50000 --backend sqlite
    python qa/load_stages.py --stages 1200,10000 --backend postgres \
        --pg-url postgresql+psycopg://postgres@127.0.0.1:5433/cafe_load

For every stage it
  1. builds a fresh database (SQLite data dir, or an emptied PostgreSQL schema),
  2. seeds that many orders directly in the database (each with lines + a payment, ~5 % left open),
  3. runs a concurrent mixed load — POST /orders, GET /orders/active, GET /kitchen/tickets,
     GET /reports/dashboard, GET /reports/sales — with N threads for D seconds,
  4. records latency p50/p95/p99 per endpoint, the error rate, the server's RSS and CPU, and the
     database's own response time for the queries behind those endpoints,
  5. checks the invariants that matter (unique order numbers, no duplicate payment, finances reconcile
     with the reports, stock ledger agrees with the ingredient balances).

Everything printed is measured on this machine; a stage that does not finish is reported as NOT RUN.
"""
import argparse
import json
import os
import random
import shutil
import socket
import statistics
import subprocess
import sys
import tempfile
import threading
import time
from datetime import date, timedelta

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
RESULTS = []


# ----------------------------------------------------------------- environment helpers
def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def server_env(data_dir: str, port: int, db_url: str | None) -> dict:
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data_dir, "CAFE_PORT": str(port), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "false", "CAFE_FORCE_PASSWORD_CHANGE": "false",
           "CAFE_BACKGROUND_JOBS": "false", "CAFE_LOGIN_MAX_FAILURES": "100000"}
    if db_url:
        env["CAFE_DATABASE_URL"] = db_url
    return env


def start_server(env: dict, port: int, log_path: str) -> subprocess.Popen:
    log = open(log_path, "w")
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(port)], cwd=BACKEND, env=env,
                            stdout=log, stderr=subprocess.STDOUT)
    base = f"http://127.0.0.1:{port}"
    for _ in range(400):
        try:
            if httpx.get(base + "/api/health", timeout=1).status_code == 200:
                return proc
        except Exception:
            pass
        if proc.poll() is not None:
            raise SystemExit("server exited during startup — see " + log_path)
        time.sleep(0.25)
    proc.kill()
    raise SystemExit("server did not start — see " + log_path)


def proc_cpu_seconds(pid: int) -> float:
    with open(f"/proc/{pid}/stat") as f:
        parts = f.read().split()
    return (int(parts[13]) + int(parts[14])) / os.sysconf("SC_CLK_TCK")


def proc_rss_mb(pid: int) -> float:
    with open(f"/proc/{pid}/status") as f:
        for line in f:
            if line.startswith("VmRSS:"):
                return int(line.split()[1]) / 1024
    return 0.0


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    k = max(0, min(len(s) - 1, int(round((p / 100) * (len(s) - 1)))))
    return s[k]


# ----------------------------------------------------------------- seeding (direct DB, fast)
def seed(db_url: str | None, data_dir: str, n: int, progress=print) -> dict:
    """Insert n orders straight into the database: lines + one payment each (closed), some open.

    Seeding through the API would take ~45 minutes for 50k orders; the load phase itself always goes through
    the real HTTP API. The inserted rows follow the same rules the API writes (total = Σ line totals,
    paid_amount = Σ payments, one payment per closed order).
    """
    if db_url:
        os.environ["CAFE_DATABASE_URL"] = db_url
    os.environ["CAFE_DATA_DIR"] = data_dir
    os.environ["CAFE_DEMO_DATA"] = "false"
    os.environ["CAFE_SAMPLE_USERS"] = "true"
    os.environ["CAFE_FORCE_PASSWORD_CHANGE"] = "false"
    os.environ["CAFE_BACKGROUND_JOBS"] = "false"
    sys.path.insert(0, BACKEND)
    from sqlalchemy import func

    from app.core.db import SessionLocal
    from app.core.models import User
    from app.modules.menu.models import MenuItem
    from app.modules.orders.models import Order, OrderLine, Payment
    from app.core.utils import business_day, now

    rnd = random.Random(20261024)
    with SessionLocal() as db:
        items = db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.price > 0).all()
        staff = db.query(User).all()
        if not items:
            raise SystemExit("no menu items — start the server once so it seeds the menu")
        today = business_day()
        days = [today - timedelta(days=i) for i in range(30)]
        # continue after whatever the server created on start-up (it may already have orders for today)
        numbers = {d: 0 for d in days}
        for d, mx in db.query(Order.business_date, func.max(Order.number)).group_by(Order.business_date).all():
            if d in numbers:
                numbers[d] = int(mx or 0)
        batch = 0
        t0 = time.time()
        for i in range(n):
            bdate = days[i % len(days)]
            numbers[bdate] += 1
            waiter = staff[i % len(staff)]
            closed = i % 20 != 0
            o = Order(number=numbers[bdate], business_date=bdate, type=rnd.choice(["dine_in", "takeaway", "takeaway"]),
                      status="closed" if closed else "open", source="pos", guests=rnd.randint(1, 4),
                      waiter_id=waiter.id, created_by=waiter.id,
                      closed_at=now() - timedelta(minutes=rnd.randint(5, 20000)) if closed else None)
            db.add(o)
            db.flush()
            subtotal = 0
            for _ in range(rnd.randint(1, 3)):
                it = rnd.choice(items)
                qty = rnd.randint(1, 3)
                total = it.price * qty
                subtotal += total
                db.add(OrderLine(order_id=o.id, menu_item_id=it.id, station_id=it.station_id, name=it.name,
                                 base_price=it.price, unit_price=it.price, qty=qty, modifiers=[],
                                 status="served" if closed else "pending"))
            o.subtotal, o.total = subtotal, subtotal
            if closed:
                o.paid_amount = subtotal
                db.add(Payment(order_id=o.id, method="cash" if i % 3 else "card", amount=subtotal,
                               created_by=waiter.id))
            batch += 1
            if batch >= 1000:
                db.commit()
                batch = 0
                if i and i % 10000 == 0:
                    progress(f"    … {i:,} orders seeded ({time.time() - t0:.0f}s)")
        db.commit()
        total = db.query(func.count(Order.id)).scalar()
        open_n = db.query(func.count(Order.id)).filter(Order.status == "open").scalar()
    return {"orders": total, "open": open_n, "seconds": round(time.time() - t0, 1)}


# ----------------------------------------------------------------- the load itself
class Sampler(threading.Thread):
    """RSS + CPU of the server process while the load runs."""

    def __init__(self, pid: int):
        super().__init__(daemon=True)
        self.pid, self.stop, self.rss, self.cpu = pid, threading.Event(), [], []
        self.cpu0 = proc_cpu_seconds(pid)

    def run(self):
        t0 = time.time()
        while not self.stop.is_set():
            try:
                self.rss.append(proc_rss_mb(self.pid))
            except OSError:
                break
            self.stop.wait(0.5)
        dt = max(time.time() - t0, 0.001)
        self.cpu_pct = 100 * (proc_cpu_seconds(self.pid) - self.cpu0) / dt


def run_load(base: str, headers: dict, admin_headers: dict, item_id: int, duration: float, threads: int) -> dict:
    lat: dict[str, list[float]] = {}
    err: dict[str, int] = {}
    calls: dict[str, int] = {}
    created_payments: list[tuple[int, int]] = []      # (order_id, paid) of orders created under load
    lock = threading.Lock()
    stop_at = time.time() + duration
    plan = ["create", "active", "kitchen", "dashboard", "sales"]

    def request(kind: str, fn) -> None:
        """One HTTP call, timed on its own (a create is 3 requests: the order, its payment, the payment replay)."""
        t0 = time.perf_counter()
        try:
            r = fn()
            ok = 200 <= r.status_code < 300
        except Exception:
            r, ok = None, False
        dt = (time.perf_counter() - t0) * 1000
        with lock:
            lat.setdefault(kind, []).append(dt)
            calls[kind] = calls.get(kind, 0) + 1
            if not ok:
                err[kind] = err.get(kind, 0) + 1
        return r

    def one(kind: str, client: httpx.Client) -> None:
        if kind == "create":
            r = request("create", lambda: client.post("/api/orders", json={
                "type": "takeaway", "lines": [{"menu_item_id": item_id, "qty": 1}]}))
            if r is None or r.status_code != 201:
                return
            o = r.json()
            body = {"payments": [{"method": "card", "amount": o["remaining"]}], "request_id": f"load-{o['id']}-pay"}
            p = request("pay", lambda: client.post(f"/api/orders/{o['id']}/payments", json=body))
            # the very same request id again — a double click / network retry must not take the money twice
            request("pay_replay", lambda: client.post(f"/api/orders/{o['id']}/payments", json=body))
            with lock:
                created_payments.append((o["id"], o["total"] if p is not None and p.status_code == 200 else -1))
        elif kind == "active":
            request("active", lambda: client.get("/api/orders/active"))
        elif kind == "kitchen":
            request("kitchen", lambda: client.get("/api/kitchen/tickets"))
        elif kind == "dashboard":
            request("dashboard", lambda: client.get("/api/reports/dashboard", headers=admin_headers))
        else:
            request("sales", lambda: client.get("/api/reports/sales", headers=admin_headers))

    def worker(idx: int) -> None:
        client = httpx.Client(base_url=base, headers=headers, timeout=180)
        i = idx
        while time.time() < stop_at:
            one(plan[i % len(plan)], client)
            i += 1
        client.close()

    ts = [threading.Thread(target=worker, args=(i,)) for i in range(threads)]
    t0 = time.time()
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    wall = time.time() - t0
    return {"latency": lat, "errors": err, "calls": calls, "wall": wall, "created": created_payments}


def sequential_latency(base: str, headers: dict, admin_headers: dict, item_id: int, runs: int = 5) -> dict:
    """Each endpoint alone, one request at a time — the endpoint's own cost, without queueing behind other users."""
    calls = {
        "active": lambda c: c.get("/api/orders/active"),
        "kitchen": lambda c: c.get("/api/kitchen/tickets"),
        "dashboard": lambda c: c.get("/api/reports/dashboard", headers=admin_headers),
        "sales": lambda c: c.get("/api/reports/sales", headers=admin_headers),
        "create": lambda c: c.post("/api/orders", json={"type": "takeaway", "lines": [{"menu_item_id": item_id, "qty": 1}]}),
    }
    out = {}
    with httpx.Client(base_url=base, headers=headers, timeout=300) as c:
        for name, fn in calls.items():
            times, bad = [], 0
            for _ in range(runs):
                t0 = time.perf_counter()
                r = fn(c)
                times.append((time.perf_counter() - t0) * 1000)
                bad += r.status_code >= 400
            out[name] = {"p50": round(statistics.median(times), 1), "max": round(max(times), 1), "errors": bad}
    return out


def app_timings(db_url: str | None, data_dir: str) -> dict:
    """Where the time goes: the same work the slow endpoints do, executed in-process (no HTTP, no queueing)."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker, selectinload

    from app.modules.orders.models import Order
    from app.modules.reports.service import sales_report
    from app.core.utils import business_day
    from datetime import timedelta

    url = db_url or f"sqlite:///{os.path.join(data_dir, 'cafe.db')}"
    engine = create_engine(url)
    S = sessionmaker(bind=engine)
    today = business_day()
    out = {}
    with S() as db:
        for label, fn in (
            ("sales_report(today) — 1 of the 3 the dashboard runs", lambda: sales_report(db, today, today)),
            ("sales_report(14 days)", lambda: sales_report(db, today - timedelta(days=13), today)),
            ("open orders + lines + payments (GET /orders/active)", lambda: db.query(Order)
                .options(selectinload(Order.lines), selectinload(Order.payments)).filter(Order.status == "open").all()),
        ):
            times = []
            for _ in range(3):
                db.expire_all()
                t0 = time.perf_counter()
                fn()
                times.append((time.perf_counter() - t0) * 1000)
            out[label] = {"p50": round(statistics.median(times), 1), "max": round(max(times), 1)}
    engine.dispose()
    return out


def db_query_times(db_url: str | None, data_dir: str) -> dict:
    """The database's own share of the work: the queries behind the slowest screens, timed directly."""
    from sqlalchemy import create_engine, text
    url = db_url or f"sqlite:///{os.path.join(data_dir, 'cafe.db')}"
    engine = create_engine(url)
    qs = {
        "sales aggregate (30 days)": "SELECT COUNT(*), SUM(total), SUM(discount_amount), SUM(tax_amount) FROM orders WHERE status='closed'",
        "order page (20 newest)": "SELECT id, number, total, created_at FROM orders ORDER BY created_at DESC LIMIT 20",
        "kitchen open tickets": "SELECT COUNT(*) FROM order_lines WHERE status IN ('pending','sent','ready')",
        "payments sum": "SELECT SUM(amount) FROM payments",
    }
    out = {}
    with engine.connect() as c:
        for label, q in qs.items():
            times = []
            for _ in range(7):
                t0 = time.perf_counter()
                c.execute(text(q)).fetchall()
                times.append((time.perf_counter() - t0) * 1000)
            out[label] = {"p50": round(statistics.median(times), 1), "max": round(max(times), 1)}
    engine.dispose()
    return out


# ----------------------------------------------------------------- correctness checks after the load
def correctness(db_url: str | None, data_dir: str, base: str, admin_h: dict, created: list[tuple[int, int]]) -> dict:
    from sqlalchemy import create_engine, func, text
    from sqlalchemy.orm import sessionmaker

    from app.modules.orders.models import Order, OrderLine, Payment

    url = db_url or f"sqlite:///{os.path.join(data_dir, 'cafe.db')}"
    engine = create_engine(url)
    S = sessionmaker(bind=engine)
    res = {}
    with S() as db:
        dup_numbers = db.execute(text(
            "SELECT business_date, number, COUNT(*) AS c FROM orders GROUP BY business_date, number HAVING COUNT(*) > 1")).fetchall()
        res["duplicate_order_numbers"] = len(dup_numbers)

        dup_req = db.execute(text(
            "SELECT request_id, COUNT(*) AS c FROM payments WHERE request_id IS NOT NULL GROUP BY request_id HAVING COUNT(*) > 1")).fetchall()
        res["duplicate_payment_request_ids"] = len(dup_req)

        paid_wrong = db.execute(text(
            "SELECT COUNT(*) FROM orders o WHERE o.paid_amount <> "
            "(SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.order_id = o.id)")).scalar()
        res["orders_where_paid_amount_disagrees"] = int(paid_wrong)

        overpaid = db.query(func.count(Order.id)).filter(Order.paid_amount > Order.total).scalar()
        res["orders_paid_more_than_total"] = int(overpaid)

        # what the till says vs. what the database says
        db_closed_sum = int(db.query(func.coalesce(func.sum(Payment.amount), 0))
                            .join(Order, Payment.order_id == Order.id).filter(Order.status == "closed").scalar() or 0)
        rep = httpx.get(base + "/api/reports/sales", headers=admin_h, params={"date_from": (date.today() - timedelta(days=40)).isoformat(),
                                                                             "date_to": date.today().isoformat()}, timeout=120).json()
        res["db_payments_sum"] = db_closed_sum
        summary = rep.get("summary") or {}
        res["report_net"] = summary.get("net")
        res["report_orders"] = summary.get("orders")
        res["report_matches_db"] = (summary.get("net") == db_closed_sum)
        res["report_orders_match_db"] = (summary.get("orders") == int(
            db.query(func.count(Order.id)).filter(Order.status == "closed").scalar() or 0))

        # stock ledger vs. ingredient balance
        bad_stock = db.execute(text("""
            SELECT COUNT(*) FROM ingredients i WHERE ABS(i.stock - COALESCE(
                (SELECT m.balance FROM stock_movements m WHERE m.ingredient_id = i.id ORDER BY m.id DESC LIMIT 1), i.stock)) > 0.001
        """)).scalar()
        res["ingredients_out_of_sync_with_ledger"] = int(bad_stock)

        # the orders created live during the load: exactly one payment each, and it matches the bill
        bad_created = 0
        for oid, total in created:
            o = db.get(Order, oid)
            if not o or total < 0:
                bad_created += 1
                continue
            pays = db.query(Payment).filter(Payment.order_id == oid).all()
            if len(pays) != 1 or sum(p.amount for p in pays) != o.total or o.paid_amount != o.total:
                bad_created += 1
        res["live_orders_created"] = len(created)
        res["live_orders_with_wrong_payments"] = bad_created

        res["orders_total"] = int(db.query(func.count(Order.id)).scalar())
        res["lines_total"] = int(db.query(func.count(OrderLine.id)).scalar())
        res["payments_total"] = int(db.query(func.count(Payment.id)).scalar())
    engine.dispose()
    ok = (res["duplicate_order_numbers"] == 0 and res["duplicate_payment_request_ids"] == 0
          and res["orders_where_paid_amount_disagrees"] == 0 and res["orders_paid_more_than_total"] == 0
          and res["report_matches_db"] and res["report_orders_match_db"]
          and res["ingredients_out_of_sync_with_ledger"] == 0 and res["live_orders_with_wrong_payments"] == 0)
    res["all_ok"] = ok
    return res


# ----------------------------------------------------------------- one stage
def run_stage(n: int, backend: str, pg_url: str | None, duration: float, threads: int) -> dict:
    print(f"\n=== stage: {n:,} orders · backend {backend} ===", flush=True)
    data_dir = tempfile.mkdtemp(prefix=f"cafe-load-{backend}-")
    port = free_port()
    base = f"http://127.0.0.1:{port}"
    db_url = None
    stage = {"orders": n, "backend": backend}

    if backend == "postgres":
        from sqlalchemy import create_engine, text
        eng = create_engine(pg_url)
        with eng.begin() as c:                       # a fresh schema for this stage
            c.execute(text("DROP SCHEMA public CASCADE"))
            c.execute(text("CREATE SCHEMA public"))
        eng.dispose()
        db_url = pg_url

    env = server_env(data_dir, port, db_url)
    srv = start_server(env, port, os.path.join(data_dir, "server.log"))
    try:
        tok = httpx.post(base + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}).json()["token"]
        A = {"Authorization": f"Bearer {tok}"}
        ctok = httpx.post(base + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}).json()["token"]
        C = {"Authorization": f"Bearer {ctok}"}
        httpx.post(base + "/api/shifts/open", headers=C, json={"opening_cash": 0})

        print(f"  seeding {n:,} orders directly in the database …", flush=True)
        seeded = seed(db_url, data_dir, n)
        stage["seeded"] = seeded
        print(f"  seeded {seeded['orders']:,} orders ({seeded['open']:,} open) in {seeded['seconds']}s", flush=True)

        full = httpx.get(base + "/api/menu/full", headers=C).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        items = [i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                 and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]
        item_id = items[0]["id"]

        httpx.get(base + "/api/orders/active", headers=C)          # warm-up
        print("  single-client latency (5 runs each, no other traffic) …", flush=True)
        stage["sequential_ms"] = sequential_latency(base, C, A, item_id)
        rss_before, cpu_before = proc_rss_mb(srv.pid), proc_cpu_seconds(srv.pid)
        sampler = Sampler(srv.pid)
        sampler.start()
        print(f"  load: {threads} threads for {duration:.0f}s (create / active / kitchen / dashboard / sales) …", flush=True)
        load = run_load(base, C, A, item_id, duration, threads)
        sampler.stop.set()
        sampler.join()

        stage["load"] = {
            "threads": threads, "duration_s": round(load["wall"], 1),
            "calls_per_endpoint": load["calls"], "errors_per_endpoint": load["errors"],
            "total_calls": sum(load["calls"].values()),
            "error_rate_pct": round(100 * sum(load["errors"].values()) / max(sum(load["calls"].values()), 1), 3),
            "rps": round(sum(load["calls"].values()) / max(load["wall"], 0.001), 1),
            "rss_mb_before": round(rss_before, 1), "rss_mb_peak": round(max(sampler.rss or [0]), 1),
            "rss_mb_avg": round(statistics.mean(sampler.rss), 1) if sampler.rss else 0,
            "cpu_pct_of_one_core": round(getattr(sampler, "cpu_pct", 0), 1),
            "cpu_cores_on_this_machine": os.cpu_count(),
            "latency_ms": {k: {"n": len(v), "p50": round(percentile(v, 50), 1), "p95": round(percentile(v, 95), 1),
                               "p99": round(percentile(v, 99), 1), "max": round(max(v), 1)}
                           for k, v in load["latency"].items()},
        }
        stage["db_query_ms"] = db_query_times(db_url, data_dir)
        try:
            stage["app_ms"] = app_timings(db_url, data_dir)
        except Exception as e:                      # noqa: BLE001 — a measurement must never hide the load results
            stage["app_ms"] = {"error": f"{type(e).__name__}: {e}"}
        stage["correctness"] = correctness(db_url, data_dir, base, A, load["created"])
        size = (os.path.getsize(os.path.join(data_dir, "cafe.db")) / 1024 / 1024) if backend == "sqlite" else None
        if size:
            stage["db_size_mb"] = round(size, 1)
        l = stage["load"]
        print(f"  {l['total_calls']} requests, {l['rps']} req/s, error rate {l['error_rate_pct']}%, "
              f"RSS peak {l['rss_mb_peak']} MB, CPU {l['cpu_pct_of_one_core']}% of one core", flush=True)
        for k, v in l["latency_ms"].items():
            print(f"    {k:10s} n={v['n']:5d}  p50 {v['p50']:8.1f}  p95 {v['p95']:8.1f}  p99 {v['p99']:8.1f} ms", flush=True)
        for k, v in (stage.get("sequential_ms") or {}).items():
            print(f"    single {k:9s} p50 {v['p50']:8.1f}  max {v['max']:8.1f} ms", flush=True)
        for k, v in (stage.get("app_ms") or {}).items():
            print(f"    in-process: {k} → {v}", flush=True)
        print(f"  correctness: {stage['correctness']['all_ok']}  {json.dumps({k: v for k, v in stage['correctness'].items() if k != 'all_ok'}, ensure_ascii=False)}", flush=True)
    finally:
        srv.terminate()
        try:
            srv.wait(20)
        except Exception:
            srv.kill()
        shutil.rmtree(data_dir, ignore_errors=True)
    return stage


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="1200,10000,50000")
    ap.add_argument("--backend", default="sqlite", choices=["sqlite", "postgres"])
    ap.add_argument("--pg-url", default=os.environ.get("CAFE_LOAD_PG_URL", "postgresql+psycopg://postgres@127.0.0.1:5433/cafe_load"))
    ap.add_argument("--duration", type=float, default=20.0)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--out", default="")
    ap.add_argument("--single", action="store_true", help=argparse.SUPPRESS)
    args = ap.parse_args()

    os.environ.setdefault("CAFE_SAMPLE_USERS", "true")
    stages = [int(x) for x in args.stages.split(",") if x.strip()]

    if len(stages) > 1 and not args.single:
        # One subprocess per stage: the seeding/correctness code imports the app, which binds its engine to the
        # data dir of the FIRST stage at import time — reusing one process would silently seed the wrong database.
        files = []
        for n in stages:
            tmp = tempfile.mktemp(prefix=f"load-stage-{n}-", suffix=".json")
            cmd = [sys.executable, os.path.abspath(__file__), "--stages", str(n), "--backend", args.backend,
                   "--pg-url", args.pg_url, "--duration", str(args.duration), "--threads", str(args.threads),
                   "--out", tmp, "--single"]
            rc = subprocess.call(cmd, cwd=ROOT)
            if rc != 0 or not os.path.exists(tmp):
                print(f"\n!! stage {n:,} did NOT complete (exit {rc}) — reported as not run")
                continue
            files.append(tmp)
        allres = []
        for f in files:
            with open(f) as fh:
                allres.extend(json.load(fh))
        print("\n================ summary ================")
        for s in allres:
            l = s["load"]
            print(f"{s['orders']:>7,} orders · {s['backend']:<8} · {l['rps']:>6.1f} req/s · err {l['error_rate_pct']}% · "
                  f"RSS peak {l['rss_mb_peak']} MB · CPU {l['cpu_pct_of_one_core']}% of one core · correctness {s['correctness']['all_ok']}")
            for k, v in l["latency_ms"].items():
                print(f"         {k:10s} p50 {v['p50']:7.1f}  p95 {v['p95']:7.1f}  p99 {v['p99']:7.1f} ms")
        if args.out:
            with open(args.out, "w") as f:
                json.dump(allres, f, ensure_ascii=False, indent=2)
            print(f"\nwritten to {args.out}")
        return 0 if all(s["correctness"]["all_ok"] and s["load"]["error_rate_pct"] == 0 for s in allres) and allres else 1

    for n in stages:
        RESULTS.append(run_stage(n, args.backend, args.pg_url, args.duration, args.threads))
    if args.out:
        with open(args.out, "w") as f:
            json.dump(RESULTS, f, ensure_ascii=False, indent=2)
    return 0 if all(s["correctness"]["all_ok"] and s["load"]["error_rate_pct"] == 0 for s in RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
