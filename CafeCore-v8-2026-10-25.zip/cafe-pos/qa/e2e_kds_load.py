"""
Does the kitchen screen stay responsive under a busy service?

This reproduces the second freeze the shop reported: the KDS used to run one 1-second timer per
ticket, so 30 tickets re-rendered 30 whole cards every second. On a cheap kitchen tablet the board
crawled and looked frozen.

The check measures, with 40 live tickets on screen:
  * how many DOM elements exist (it must not grow),
  * how long a forced layout + paint takes (a proxy for "the screen is alive"),
  * that the clock actually advances (the board is not dead),
  * that clicking a ticket still answers quickly.

    python qa/e2e_kds_load.py        # exit 0 = the board stayed responsive
"""
import os
import subprocess
import sys
import tempfile
import time

import httpx
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8066"))
BASE = f"http://127.0.0.1:{PORT}"
TICKETS = 40
results = []


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def main():
    data = tempfile.mkdtemp(prefix="cafe-kds-")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(120):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                break
        except Exception:
            pass
        time.sleep(0.25)
    try:
        chef_token = httpx.post(BASE + "/api/staff/auth/login",
                                json={"username": "chef", "password": "kitchen123"}).json()["token"]
        H = {"Authorization": "Bearer " + chef_token}
        cashier = {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                          json={"username": "reza", "password": "cashier123"}).json()["token"]}
        httpx.post(BASE + "/api/shifts/open", headers=cashier, json={"opening_cash": 0})
        full = httpx.get(BASE + "/api/menu/full", headers=cashier).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        item = next(i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                    and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))
        # a busy service: forty tickets waiting in the kitchen
        for k in range(TICKETS):
            httpx.post(BASE + "/api/orders", headers=cashier,
                       json={"type": "takeaway", "send": True, "lines": [{"menu_item_id": item["id"], "qty": 1 + k % 3}]})
        live = httpx.get(BASE + "/api/kitchen/tickets", headers=H).json()
        check(f"the kitchen has {TICKETS} live tickets", len(live) >= TICKETS, len(live))

        with sync_playwright() as p:
            browser = p.chromium.launch()
            ctx = browser.new_context(viewport={"width": 1280, "height": 800})
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{chef_token}')")   # the kitchen tablet stays logged in
            page = ctx.new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.goto(BASE + "/kds", wait_until="networkidle")
            page.wait_for_timeout(2500)
            shown = page.locator(".kds-ticket").count()
            check("the board renders every ticket", shown >= TICKETS, shown)
            if not shown:
                page.screenshot(path=os.path.join(ROOT, "qa", "kds_empty.png"))
                print("DEBUG body:", page.inner_text("body")[:300].replace("\n", " | "))
                print("DEBUG url:", page.url)

            nodes_before = page.evaluate("document.querySelectorAll('*').length")

            # a click must answer promptly even with a full board
            t0 = time.time()
            page.locator(".kt-bump").first.click(timeout=5000)
            click_ms = (time.time() - t0) * 1000
            check("clicking a ticket answers in under 1.5 s", click_ms < 1500, f"{click_ms:.0f} ms")

            # the clock must still move (the board is alive, not frozen)
            page.wait_for_timeout(2200)
            node_growth = page.evaluate("document.querySelectorAll('*').length") - nodes_before
            check("the page does not leak DOM nodes while ticking", node_growth < TICKETS, node_growth)

            # a main-thread stall is what "frozen" means: measure the worst frame gap over 3 s
            worst = page.evaluate("""async () => {
              let worst = 0, last = performance.now()
              await new Promise((done) => {
                const end = last + 3000
                function f(now) { const gap = now - last; if (gap > worst) worst = gap; last = now; if (now < end) requestAnimationFrame(f); else done() }
                requestAnimationFrame(f)
              })
              return Math.round(worst)
            }""")
            check("no main-thread stall longer than 400 ms (the old bug locked the tablet)", worst < 400, f"worst frame gap {worst} ms")
            check("no page errors", not errors, errors[:2])
            browser.close()
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except Exception:
            srv.kill()
        import shutil
        shutil.rmtree(data, ignore_errors=True)

    passed, total = sum(results), len(results)
    print(f"\n{passed}/{total} checks passed")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
