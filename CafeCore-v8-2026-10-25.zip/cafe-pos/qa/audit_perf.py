"""
Phase 12 — measured performance at a realistic café volume (not guessed numbers).

Seeds N orders (default 1500, each 1-3 lines, paid) through the real API, then measures the response
time of every screen the staff uses, several times each, and reports p50/p95.

  QA_ORDERS=1500 python qa/audit_perf.py
"""
import os
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8099"))
BASE = f"http://127.0.0.1:{PORT}"
fails = []


def start(data):
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "false", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(160):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            pass
        time.sleep(0.25)
    raise SystemExit("server did not start")


def timed(label, fn, runs=7, budget_p95=None):
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        r = fn()
        times.append((time.perf_counter() - t0) * 1000)
        if r.status_code >= 400:
            fails.append(f"{label}: HTTP {r.status_code}")
    p50, p95 = statistics.median(times), sorted(times)[max(0, int(len(times) * 0.95) - 1)]
    ok = budget_p95 is None or p95 <= budget_p95
    print(f"{'PASS' if ok else 'SLOW'} {label:44s} p50 {p50:7.1f} ms   p95 {p95:7.1f} ms"
          + (f"   (budget {budget_p95} ms)" if budget_p95 else ""))
    if not ok:
        fails.append(f"{label}: p95 {p95:.0f} ms over budget {budget_p95} ms")
    return p95


def main():
    n = int(os.environ.get("QA_ORDERS", "1500"))
    data = tempfile.mkdtemp(prefix="cafe-audit-perf-")
    srv = start(data)
    try:
        def login(u, p):
            return {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                            json={"username": u, "password": p}).json()["token"]}
        A, C = login("admin", "admin123"), login("reza", "cashier123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})
        full = httpx.get(BASE + "/api/menu/full", headers=C).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        items = [i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                 and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]

        print(f"seeding {n} paid orders through the API ...")
        t0 = time.time()
        made = 0
        for k in range(n):
            lines = [{"menu_item_id": it["id"], "qty": 1 + (k % 3)} for it in items[: 1 + (k % min(3, len(items)))]]
            r = httpx.post(BASE + "/api/orders", headers=C, json={"type": "takeaway", "lines": lines,
                                                                  "request_id": f"perf-{k:06d}-seed"}, timeout=30)
            if r.status_code != 201:
                continue
            o = r.json()
            if k % 5 == 0:      # leave every fifth order open, like a busy service
                continue
            p = httpx.post(BASE + f"/api/orders/{o['id']}/payments", headers=C,
                           json={"payments": [{"method": "cash", "amount": o["remaining"]}]}, timeout=30)
            if p.status_code == 200:
                made += 1
        print(f"seeded {made} paid orders in {time.time() - t0:.1f}s\n")

        print("measured response times (7 runs each, on this machine):")
        timed("GET /api/orders/active (open orders)", lambda: httpx.get(BASE + "/api/orders/active", headers=C), budget_p95=400)
        timed("GET /api/orders?page=1 (history, 20/page)", lambda: httpx.get(BASE + "/api/orders", headers=C, params={"page": 1, "size": 20}), budget_p95=400)
        timed("GET /api/reports/sales (today)", lambda: httpx.get(BASE + "/api/reports/sales", headers=A), budget_p95=1500)
        timed("GET /api/reports/dashboard", lambda: httpx.get(BASE + "/api/reports/dashboard", headers=A), budget_p95=1500)
        timed("GET /api/reports/insights/menu (30 days)", lambda: httpx.get(BASE + "/api/reports/insights/menu", headers=A), budget_p95=2000)
        timed("GET /api/inventory/ingredients", lambda: httpx.get(BASE + "/api/inventory/ingredients", headers=A), budget_p95=400)
        timed("GET /api/kitchen/tickets", lambda: httpx.get(BASE + "/api/kitchen/tickets", headers=A), budget_p95=400)
        timed("POST /api/orders (create + 3 lines)", lambda: httpx.post(BASE + "/api/orders", headers=C,
              json={"type": "takeaway", "lines": [{"menu_item_id": items[0]["id"], "qty": 1}]}, timeout=30), runs=5, budget_p95=600)
        timed("GET /api/system/audit (200 rows)", lambda: httpx.get(BASE + "/api/system/audit", headers=A), budget_p95=600)

        db = os.path.join(data, "cafe.db")
        size = os.path.getsize(db) / 1024 / 1024
        print(f"\ndatabase size with {made} paid orders: {size:.1f} MB")
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
        shutil.rmtree(data, ignore_errors=True)

    print("\n" + ("all endpoints within budget" if not fails else "problems:\n - " + "\n - ".join(fails)))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
