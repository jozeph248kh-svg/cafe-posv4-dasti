"""Fresh install with PRODUCTION defaults (no env vars): no demo data, no sample users, docs off, forced password change."""
import os, subprocess, sys, tempfile, time, httpx, shutil
from playwright.sync_api import sync_playwright
data = tempfile.mkdtemp(prefix="cafe-prod-"); port = 8021; B = f"http://127.0.0.1:{port}"
env = {k: v for k, v in os.environ.items() if not k.startswith("CAFE_")}
env.update(CAFE_DATA_DIR=data, CAFE_PORT=str(port))
srv = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port)],
                       cwd=os.path.expanduser("~/cafe-pos/backend"), env=env, stdout=open("/tmp/prod.log", "w"), stderr=subprocess.STDOUT)
ok = []
def check(name, cond): ok.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name)
try:
    for _ in range(60):
        try: httpx.get(B + "/api/health", timeout=1); break
        except Exception: time.sleep(0.3)
    check("no sample users (reza/cashier123 refused)", httpx.post(B + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}).status_code == 401)
    check("API docs disabled", httpx.get(B + "/docs").status_code in (404,) or "swagger" not in httpx.get(B + "/docs").text.lower())
    check("openapi.json disabled", httpx.get(B + "/openapi.json").status_code == 404 or "openapi" not in httpx.get(B + "/openapi.json").text[:50])
    check("PIN login can't be used (admin has no PIN)", httpx.post(B + "/api/staff/auth/pin", json={"pin": "1111"}).status_code in (401, 403))
    with sync_playwright() as p:
        br = p.chromium.launch(); page = br.new_page(viewport={"width": 1280, "height": 800})
        errs = []; step = ["start"]; page.on("pageerror", lambda e: errs.append((step[0], str(e), getattr(e, "stack", "")[:300])))
        page.on("console", lambda m: m.type in ("error", "warning") and errs.append((step[0], "console", m.text[:200])))
        page.on("response", lambda r: r.status >= 400 and errs.append((step[0], r.status, r.url)))
        page.goto(B + "/login", wait_until="networkidle")
        page.evaluate("localStorage.setItem('cafe_login_mode', 'pin')"); page.reload(wait_until="networkidle"); page.wait_for_timeout(500)
        body = page.inner_text("body")
        check("login: no PIN set yet -> opens on username/password", page.locator("#username").is_visible())
        check("login: no demo PINs advertised, first-login hint shown", "۱۱۱۱" not in body and "اولین ورود" in body)
        page.get_by_text("کد ورود سریع").click(); page.wait_for_timeout(300)
        check("login: PIN tab explains how to set up PINs", "هنوز کد ورود سریع تعریف نشده" in page.inner_text("body") and not page.locator(".pin-grid").is_visible())
        page.screenshot(path="shots/prod_login_nopin.png")
        page.get_by_role("button", name="ورود با نام کاربری و رمز").click(); page.wait_for_timeout(300)
        page.fill("#username", "admin"); page.fill("#password", "admin123")
        step[0]="login"; page.get_by_role("button", name="ورود").click(); page.wait_for_timeout(1500)
        modal = page.locator(".ant-modal-content")
        check("forced password modal shown", modal.is_visible() and "تغییر رمز عبور پیش‌فرض" in modal.inner_text())
        page.keyboard.press("Escape"); page.wait_for_timeout(400)
        check("modal can't be dismissed with Esc", modal.is_visible())
        page.screenshot(path="shots/prod_forced.png")
        step[0]="short"; page.fill("#current", "admin123"); page.fill("#next", "short"); page.fill("#confirm", "short")
        page.get_by_role("button", name="ذخیره رمز جدید").click(); page.wait_for_timeout(500)
        check("short password rejected in form", modal.is_visible())
        step[0]="change"; page.fill("#next", "Cafe-Strong-2026"); page.fill("#confirm", "Cafe-Strong-2026")
        page.get_by_role("button", name="ذخیره رمز جدید").click(); page.wait_for_timeout(2000)
        check("modal closed after change", not modal.is_visible())
        step[0]="dash"; page.goto(B + "/admin/dashboard", wait_until="networkidle"); page.wait_for_timeout(1000)
        check("admin pages work after change", "داشبورد" in page.inner_text("body"))
        page.screenshot(path="shots/prod_after.png")
        check("no JS errors", not errs) or print(errs)
        br.close()
    check("old password no longer works", httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}).status_code == 401)
    r = httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "Cafe-Strong-2026"}).json()
    check("new password works, no forced change", r.get("must_change_password") is False)
    h = {"Authorization": "Bearer " + r["token"]}
    me = next(u for u in httpx.get(B + "/api/staff/users", headers=h).json() if u["username"] == "admin")
    httpx.put(B + f"/api/staff/users/{me['id']}", headers=h, json={"username": "admin", "full_name": me["full_name"], "role_id": me["role_id"], "pin": "4826"}).raise_for_status()
    with sync_playwright() as p:
        br = p.chromium.launch(); page = br.new_page(viewport={"width": 1280, "height": 800})
        page.goto(B + "/login", wait_until="networkidle"); page.evaluate("localStorage.setItem('cafe_login_mode', 'pin')"); page.reload(wait_until="networkidle"); page.wait_for_timeout(500)
        body = page.inner_text("body")
        check("login: after a PIN is set the PIN pad is shown (no setup hint, no demo PINs)", page.locator(".pin-grid").is_visible() and "هنوز کد ورود" not in body and "۱۱۱۱" not in body and "اولین ورود" not in body)
        page.screenshot(path="shots/prod_login_pin.png")
        br.close()
    check("PIN login works with the new PIN", httpx.post(B + "/api/staff/auth/pin", json={"pin": "4826"}).status_code == 200)
    check("no demo orders", httpx.get(B + "/api/orders/active", headers=h).json() == [])
    check("automatic (hourly) backup created at startup", any(f.endswith(("-hourly.db", "-hourly-.db")) for f in os.listdir(os.path.join(data, "backups"))))
finally:
    srv.terminate(); srv.wait(10)
log = open("/tmp/prod.log").read()
check("passwords/tokens absent from server log", "admin123" not in log and "Cafe-Strong-2026" not in log and "eyJ" not in log)
shutil.rmtree(data, ignore_errors=True)
print(f"{sum(o for _, o in ok)}/{len(ok)} passed")
