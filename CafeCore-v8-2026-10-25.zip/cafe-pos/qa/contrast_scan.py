"""Round 9 readability scan: visible text whose colour has low WCAG contrast against its effective background.
Covers every skin × mode, whole pages (not only the viewport), gradients (worst colour stop), and opened overlays
(POS order panel, theme popover, theme editor drawer).
usage: python contrast_scan.py [skins=all] [modes=0,1] [paths=default list] [--json out.json]
  severity: FAIL < 3.0 (normal text) / < 2.4 (large) — "text disappears";  AA < 4.5 / < 3.0 — WCAG AA miss."""
import json, sys, urllib.request
from playwright.sync_api import sync_playwright
B = "http://localhost:8001"
args = [a for a in sys.argv[1:] if not a.startswith("--")]
out_json = sys.argv[sys.argv.index("--json") + 1] if "--json" in sys.argv else None
if out_json in args: args.remove(out_json)
SKINS = ["classic", "latte", "jade", "ocean", "rose", "graphite"] if len(args) < 1 or args[0] == "all" else args[0].split(",")
MODES = (args[1] if len(args) > 1 else "0,1").split(",")
ADMIN = ["dashboard", "orders", "online", "reservations", "delivery", "shifts", "staff-reports", "customers", "club", "reports",
         "finance/pnl", "finance/expenses", "menu", "discounts", "floor", "inventory/ingredients", "inventory/food-cost",
         "inventory/purchases", "inventory/count", "inventory/movements", "marketplace", "sms", "card-readers",
         "moadian", "branches", "timeclock", "staff", "settings", "settings?tab=theme", "audit", "modules"]
PATHS = args[2].split(",") if len(args) > 2 else ["/", "/pos", "/kds", "/my-shift"] + [f"/admin/{p}" for p in ADMIN]
JS = r"""() => {
  const parse = (c) => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1] }
  const allColors = (s) => (s.match(/rgba?\([^)]+\)/g) || []).map(parse).filter(Boolean)
  const lum = ([r, g, b]) => { const f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4 }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b) }
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05) }
  const over = (top, under) => [0, 1, 2].map((i) => top[i] * top[3] + under[i] * (1 - top[3])).concat(1)
  const out = []
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT)
  const seen = new Set()
  while (walker.nextNode()) {
    const t = walker.currentNode; const txt = t.textContent.trim(); if (!txt) continue
    if (!/[\p{L}\p{N}]/u.test(txt)) continue                     // punctuation / icons only
    const el = t.parentElement; if (!el || seen.has(el)) continue; seen.add(el)
    const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue
    if (el.checkVisibility && !el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) continue
    if (el.closest('[disabled], [aria-disabled="true"], .ant-btn-disabled, .ant-picker-cell-disabled, .ant-select-item-option-disabled, .ant-pagination-disabled, .ant-steps-item-wait, .ant-input-disabled, .ant-select-disabled, .ant-radio-button-wrapper-disabled, .ant-segmented-item-disabled, .ant-menu-item-disabled, .ant-checkbox-wrapper-disabled, .ant-tabs-tab-disabled, .mini, .cx-sample, .skin-swatch')) continue
    const cs = getComputedStyle(el)
    let fg = parse(cs.color); if (!fg) continue
    // effective background; intentionally dimmed subtrees (opacity < .6: sold-out items, cancelled rows) are exempt
    let n = el, under = [255, 255, 255, 1], stack = [], grads = null, dimmed = false, img = false
    while (n && n.nodeType === 1) {
      const s = getComputedStyle(n)
      if (+s.opacity < .6) dimmed = true
      const c = parse(s.backgroundColor)
      if (s.backgroundImage && s.backgroundImage !== 'none') {
        if (s.backgroundImage.includes('url(')) { img = true; break }
        const stops = allColors(s.backgroundImage).filter((x) => x[3] >= .9)
        if (stops.length) { grads = stops; if (c && c[3] > 0) stack.push(c); break }
      }
      if (c && c[3] > 0) { if (c[3] >= .95) { under = c; break } stack.push(c) }
      n = n.parentElement
    }
    if (dimmed || img) continue
    let bgs = grads ? grads.map((g) => g.slice()) : [under]
    bgs = bgs.map((bg) => { let x = bg; for (const a of stack.slice().reverse()) x = over(a, x); return x })
    const k = Math.min(...bgs.map((bg) => ratio(fg[3] < 1 ? over(fg, bg) : fg, bg)))
    const size = parseFloat(cs.fontSize), big = size >= 18.6 || (size >= 14 && +cs.fontWeight >= 700)
    const fail = k < (big ? 2.4 : 3.0), aa = k < (big ? 3 : 4.5)
    if (aa) out.push({ k: Math.round(k * 100) / 100, sev: fail ? 'FAIL' : 'AA', grad: !!grads, txt: txt.slice(0, 28),
      cls: (typeof el.className === 'string' ? el.className : '').slice(0, 50), parent: (typeof el.parentElement?.className === 'string' ? el.parentElement.className : '').slice(0, 40),
      fg: cs.color, bg: grads ? 'gradient' : `rgb(${bgs[0].slice(0, 3).map(Math.round).join(',')})` })
  }
  return out
}"""
# overlays opened on some pages (scanned in addition to the page itself)
ACTIONS = {
    "/pos": [("order panel", ".table-card.occupied, .table-card.ready, .table-card.billing")],
    "/admin/dashboard": [("theme popover", ".theme-switch")],
    "/admin/settings?tab=theme": [("skin editor", ".skin-new")],
}
tok = json.load(urllib.request.urlopen(urllib.request.Request(B + "/api/staff/auth/login", data=json.dumps({"username": "admin", "password": "admin123"}).encode(), headers={"content-type": "application/json"})))["token"]
report, total_fail, total_aa = [], 0, 0
def record(skin, mode, where, bad):
    global total_fail, total_aa
    uniq = {}
    for x in bad: uniq.setdefault((x["cls"], x["parent"], x["fg"], x["bg"]), x)
    f = sum(1 for x in uniq.values() if x["sev"] == "FAIL"); a = len(uniq) - f
    total_fail += f; total_aa += a
    report.append({"skin": skin, "mode": mode, "where": where, "fail": f, "aa": a, "items": sorted(uniq.values(), key=lambda x: x["k"])})
    if f or a:
        print(f"  [{skin}/{'dark' if mode == '1' else 'light'}] {where}: FAIL {f}  AA {a}")
        for x in sorted(uniq.values(), key=lambda x: x["k"])[:6]: print("      ", x)
with sync_playwright() as p:
    b = p.chromium.launch()
    for skin in SKINS:
        for mode in MODES:
            ctx = b.new_context(viewport={"width": 1440, "height": 900}); pg = ctx.new_page()
            pg.goto(B + "/login", wait_until="networkidle")
            pg.evaluate(f"localStorage.clear(); localStorage.setItem('cafe_dark', '{mode}'); localStorage.setItem('cafe_skin', '{skin}')")
            pg.reload(wait_until="networkidle"); pg.wait_for_timeout(500)
            record(skin, mode, "/login", pg.evaluate(JS))
            pg.evaluate(f"localStorage.setItem('cafe_token', '{tok}')")
            for path in PATHS:
                pg.goto(B + path, wait_until="networkidle"); pg.wait_for_timeout(900)
                record(skin, mode, path, pg.evaluate(JS))
                for label, sel in ACTIONS.get(path, []):
                    loc = pg.locator(sel).first
                    if loc.count():
                        loc.click(); pg.wait_for_timeout(1000)
                        record(skin, mode, f"{path} + {label}", pg.evaluate(JS))
                        pg.keyboard.press("Escape")
            ctx.close()
    b.close()
print(f"TOTAL  FAIL(text disappears) = {total_fail}   AA misses = {total_aa}   ({len(report)} screens)")
if out_json: json.dump(report, open(out_json, "w"), ensure_ascii=False, indent=1)
