"""Open every management-report tab in a real browser and assert it paints without a React crash.

The insight tabs are the ones that break when a section answers with a partial payload — a crash there
unmounts the whole Reports page (white screen) instead of showing an empty state.
Run:  python qa/e2e_insights.py      (needs a server on :8001 with demo data, see qa/README.md)
"""
import sys

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
TABS = ["مهندسی منو", "تخفیف‌ها", "عملکرد پرسنل", "مغایرت صندوق", "میزها و سالن",
        "سرعت آشپزخانه", "افزودنی‌ها", "مشتریان", "دفتر مالیات"]
ok = fail = 0


def check(name, cond, detail=""):
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {name}")
    else:
        fail += 1
        print(f"FAIL {name} {detail}")


def main():
    tok = httpx.post(B + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"}, timeout=20).json()["token"]
    with sync_playwright() as p:
        br = p.chromium.launch()
        ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        page = ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)[:200]))
        page.on("console", lambda m: m.type == "error" and errors.append("console: " + m.text[:200]))
        page.goto(B + "/admin/reports", wait_until="networkidle")
        page.wait_for_timeout(800)
        check("reports page loads", page.locator("#root").inner_text().strip() != "")
        for label in TABS:
            errors.clear()
            tab = page.locator(f".ant-tabs-tab:has-text('{label}')").first
            tab.click()
            page.wait_for_timeout(1200)
            body = page.locator(".ant-tabs-tabpane-active").inner_text().strip()
            check(f"tab «{label}» paints", body != "" and not errors, errors[:2])
        check("no page crash (root still painted)", page.locator("#root").inner_text().strip() != "")
        br.close()
    print(f"\n{ok}/{ok + fail} checks passed")
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
