"""
Independent ledger vs. the application: API, database and Excel must tell the same story.

The script builds a small but complete business day through the real API (taxed sales, a line discount, a bill
discount, a 100 % comp, a refund with restock, a refund without restock, a purchase after the sales, waste and an
operating expense), then recomputes every financial indicator **directly from the database tables** with plain SQL
— no application code — and compares it with

  * GET /api/expenses/pnl      (the profit & loss screen)
  * GET /api/reports/sales     (the sales report screen)
  * GET /api/reports/sales/export  (the Excel the owner downloads)

    python qa/audit_fin_ledger.py        # own data dir, own server on :8094
"""
import io
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
from datetime import date, timedelta

import httpx
from openpyxl import load_workbook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8094"))
BASE = f"http://127.0.0.1:{PORT}"
results = []
db_path_holder = [None]


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def start(env):
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(200):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            time.sleep(0.25)
    p.kill()
    raise SystemExit("server did not start")


def con_scope():
    return sqlite3.connect(db_path_holder[0])


def main():
    data = tempfile.mkdtemp(prefix="cafe-audit-ledger-")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true", "CAFE_DEMO_DATA": "false",
           "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = start(env)
    db_path = os.path.join(data, "cafe.db")
    db_path_holder[0] = db_path
    try:
        def lg(u, p):
            return {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                            json={"username": u, "password": p}).json()["token"]}
        A, C, M = lg("admin", "admin123"), lg("reza", "cashier123"), lg("sara", "manager123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})
        httpx.put(BASE + "/api/system/settings", headers=A, json={"tax.enabled": True, "tax.percent": 10,
                                                                  "service.enabled": False, "rounding.step": 0})
        ing = httpx.post(BASE + "/api/inventory/ingredients", headers=A,
                         json={"name": "دانه دفتر", "unit": "g", "opening_stock": 500, "cost_per_unit": 10,
                               "min_stock": 0}).json()
        grp = httpx.post(BASE + "/api/menu/modifier-groups", headers=A, json={
            "name": "شیرین‌کننده دفتر", "min_select": 0, "max_select": 1,
            "options": [{"name": "معمولی", "price_delta": 0, "is_default": True, "is_available": True},
                        {"name": "سیروپ", "price_delta": 10_000, "is_default": False, "is_available": True}]}).json()
        syrup = next(o for o in grp["options"] if o["name"] == "سیروپ")
        mod_ing = httpx.post(BASE + "/api/inventory/ingredients", headers=A,
                             json={"name": "سیروپ دفتر", "unit": "g", "opening_stock": 500, "cost_per_unit": 20,
                                   "min_stock": 0}).json()
        httpx.put(f"{BASE}/api/inventory/recipes/option/{syrup['id']}", headers=A,
                  json=[{"ingredient_id": mod_ing["id"], "qty": 5}])          # 100 per modifier
        cat = httpx.get(BASE + "/api/menu/categories", headers=A).json()[0]["id"]
        item = httpx.post(BASE + "/api/menu/items", headers=A,
                          json={"category_id": cat, "name": "قهوه دفتر", "price": 100_000,
                                "modifier_group_ids": [grp["id"]]}).json()
        httpx.put(f"{BASE}/api/inventory/recipes/item/{item['id']}", headers=A,
                  json=[{"ingredient_id": ing["id"], "qty": 10}])             # 100 base cost

        def sell(qty=1, mods=(), discount=None, comp=False):
            o = httpx.post(BASE + "/api/orders", headers=C,
                           json={"type": "takeaway",
                                 "lines": [{"menu_item_id": item["id"], "qty": qty, "modifier_option_ids": list(mods)}]}).json()
            if comp:
                o = httpx.post(f"{BASE}/api/orders/{o['id']}/discount", headers=M,
                               json={"type": "percent", "value": 100, "reason": "مهمان"}).json()
            elif discount:
                o = httpx.post(f"{BASE}/api/orders/{o['id']}/discount", headers=M, json=discount).json()
            r = httpx.post(f"{BASE}/api/orders/{o['id']}/payments", headers=C,
                           json={"payments": [] if o["total"] == 0 else
                                 [{"method": "cash", "amount": o["remaining"], "tendered": o["remaining"]}]})
            assert r.status_code == 200, r.text
            return r.json()

        o1 = sell(2)                                             # 2 × 100,000 + VAT
        o2 = sell(1, mods=[syrup["id"]], discount={"type": "percent", "value": 50, "reason": "تخفیف کلی"})
        o3 = sell(3, comp=True)                                  # 100 % comp
        o4 = sell(2)                                             # this one is fully refunded + restocked
        refunded_with_restock = o4["total"]
        httpx.post(f"{BASE}/api/orders/{o4['id']}/refund", headers=M,
                   json={"method": "cash", "amount": refunded_with_restock, "reason": "برگشت",
                         "restock": [{"line_id": o4["lines"][0]["id"], "qty": 2}]})
        o5 = sell(1)                                             # this one is refunded WITHOUT restock
        httpx.post(f"{BASE}/api/orders/{o5['id']}/refund", headers=M,
                   json={"method": "cash", "amount": o5["total"], "reason": "دور ریخته شد"})
        # a purchase AFTER the sales (prices ×5) — must not touch the profit of what was already sold
        httpx.post(f"{BASE}/api/inventory/purchases", headers=A,
                   json={"purchase_date": date.today().isoformat(),
                         "lines": [{"ingredient_id": ing["id"], "qty": 100, "unit_cost": 50}]})
        httpx.post(f"{BASE}/api/inventory/ingredients/{ing['id']}/adjust", headers=A,
                   json={"kind": "waste", "qty": 2, "note": "ریخت"})       # 2 × 10 = 20 (cost at waste time)
        exp_cat = httpx.get(BASE + "/api/expenses/categories", headers=A).json()[0]["id"]
        httpx.post(BASE + "/api/expenses", headers=A,
                   json={"category_id": exp_cat, "amount": 30_000, "expense_date": date.today().isoformat(),
                         "note": "اجاره تست"})

        # ------------------------------------------------------------------ independent ledger (pure SQL)
        con = sqlite3.connect(db_path)
        q = con.execute
        revenue_orders = q("select coalesce(sum(total - tax_amount),0) from orders where status='closed'").fetchone()[0]
        tax_billed = q("select coalesce(sum(tax_amount),0) from orders where status='closed'").fetchone()[0]
        refund_rows = q("""select p.amount, o.total, o.tax_amount from payments p join orders o on o.id=p.order_id
                           where p.is_refund=1""").fetchall()
        revenue_refunded = sum(max(-a, 0) * ((t - tx) / t if t else 0) for a, t, tx in refund_rows)
        tax_refunded = sum(max(-a, 0) * (tx / t if t else 0) for a, t, tx in refund_rows)
        cogs = q("""select coalesce(sum(cost_amount * (qty - returned_qty) / qty),0) from order_lines l
                    join orders o on o.id=l.order_id where o.status='closed' and l.status!='void'""").fetchone()[0]
        waste = q("""select coalesce(sum(-qty*unit_cost),0) from stock_movements where kind='waste'""").fetchone()[0]
        expenses = q("select coalesce(sum(amount),0) from expenses").fetchone()[0]
        con.close()
        refunds_raw = sum(max(-a, 0) for a, _t, _tx in refund_rows)
        ledger = {
            # two documented views of the same money (docs/FINANCIALS.md §1):
            "billed_revenue": round(revenue_orders),          # sales-report view: what was billed, net of VAT
            "tax_billed": round(tax_billed),
            "refunds_raw": round(refunds_raw),                # money handed back, as the sales report lists it
            "refund_revenue_part": round(revenue_refunded),
            "revenue": round(revenue_orders - revenue_refunded),   # P&L view: what was earned
            "tax": round(tax_billed - tax_refunded),
            "cogs": round(cogs),
            "waste": round(waste),
            "expenses": expenses,
        }
        ledger["gross_profit"] = ledger["revenue"] - ledger["cogs"] - ledger["waste"]
        ledger["net_profit"] = ledger["gross_profit"] - ledger["expenses"]
        print("independent ledger (SQL only):", ledger)

        # ------------------------------------------------------------------ compare with the API
        pnl = httpx.get(BASE + "/api/expenses/pnl", headers=A).json()
        for key in ("revenue", "tax", "cogs", "waste", "expenses", "gross_profit", "net_profit"):
            api_value = pnl["sales"]["tax"] if key == "tax" else pnl[key]
            check(f"P&L {key} == ledger", api_value == ledger[key], (api_value, ledger[key]))
        check("daily series adds up to the net profit",
              sum(d["profit"] for d in pnl["series"]) == pnl["net_profit"],
              (sum(d["profit"] for d in pnl["series"]), pnl["net_profit"]))
        check("replacement cost is its own indicator and higher after the price rise",
              pnl["replacement_cost"] > pnl["cogs"], (pnl["replacement_cost"], pnl["cogs"]))
        check("the fully refunded+restocked bill left no COGS behind",
              pnl["cogs"] < round(cogs) + 1 and pnl["cogs"] == ledger["cogs"])

        sales = httpx.get(BASE + "/api/reports/sales", headers=A).json()
        # the sales report is the BILLING view (refunds are their own line), the P&L is the EARNED view
        check("sales report net_revenue == ledger billed revenue",
              sales["summary"]["net_revenue"] == ledger["billed_revenue"],
              (sales["summary"]["net_revenue"], ledger["billed_revenue"]))
        check("sales report refunds == ledger refunds", sales["summary"]["refunds"] == ledger["refunds_raw"],
              (sales["summary"]["refunds"], ledger["refunds_raw"]))
        check("billing view − revenue part of the refunds == P&L revenue",
              sales["summary"]["net_revenue"] - ledger["refund_revenue_part"] == pnl["revenue"],
              (sales["summary"]["net_revenue"] - ledger["refund_revenue_part"], pnl["revenue"]))
        item_rows = {i["id"]: i for i in sales["by_item"]}
        row = item_rows[item["id"]]
        con = sqlite3.connect(db_path)
        item_cost = con.execute("""select coalesce(sum(l.cost_amount*(l.qty-l.returned_qty)/l.qty),0) from order_lines l
                                   join orders o on o.id=l.order_id where o.status='closed' and l.menu_item_id=?""",
                                (item["id"],)).fetchone()[0]
        con.close()
        check("item COGS == ledger", row["cost"] == round(item_cost), (row["cost"], round(item_cost)))
        check("item profit == revenue − COGS", row["profit"] == row["revenue"] - row["cost"])

        # ------------------------------------------------------------------ Excel
        x = httpx.get(BASE + "/api/reports/sales/export", headers=A)
        wb = load_workbook(io.BytesIO(x.content))
        ws = wb["آیتم‌ها"]
        header = [c.value for c in ws[1]]
        rows = {r[0]: r for r in ws.iter_rows(min_row=2, values_only=True)}
        xl = rows[item["name"]]
        check("Excel item revenue == API", xl[header.index("فروش (تومان)")] == row["revenue"])
        check("Excel item COGS == API", xl[header.index("بهای تمام‌شده (تومان)")] == row["cost"])
        check("Excel item profit == API", xl[header.index("سود (تومان)")] == row["profit"])
        summary_ws = wb["خلاصه"]
        summary = {r[0]: r[1] for r in summary_ws.iter_rows(values_only=True) if r[0]}
        check("Excel summary revenue == ledger billed revenue",
              summary.get("درآمد خالص فروش (بدون مالیات)") == ledger["billed_revenue"],
              (summary.get("درآمد خالص فروش (بدون مالیات)"), ledger["billed_revenue"]))
        check("Excel summary COGS == ledger COGS", summary.get("بهای تمام‌شده مواد (COGS تاریخی)") == ledger["cogs"],
              (summary.get("بهای تمام‌شده مواد (COGS تاریخی)"), ledger["cogs"]))
        check("Excel summary VAT == ledger billed VAT", summary.get("مالیات") == ledger["tax_billed"],
              (summary.get("مالیات"), ledger["tax_billed"]))
        check("Excel summary refunds == ledger refunds", summary.get("بازپرداخت") == ledger["refunds_raw"])

        # ---------------------------------------------------------- legacy mix + multi-part VAT (round-3 findings)
        # one bill with two lines; one line is stripped of its snapshot (a row from before the migration) while the
        # other keeps it. The order's sale movements cover BOTH lines, so COGS must stay the same (no double count).
        o6 = sell(1)                                     # a normal bill to be split in two lines is not possible here
        con = sqlite3.connect(db_path)
        line_rows = con.execute("select id, qty, cost_amount from order_lines where order_id=? order by id",
                                (o6["id"],)).fetchall()
        assert len(line_rows) == 1
        with_snapshot = line_rows[0][2]
        con.execute("update order_lines set cost_amount=NULL where id=?", (line_rows[0][0],))
        con.commit()
        con.close()
        pnl_after = httpx.get(BASE + "/api/expenses/pnl", headers=A).json()
        con = sqlite3.connect(db_path)
        movement = con.execute("""select coalesce(sum(-qty*unit_cost),0) from stock_movements
                                  where kind='sale' and ref_type='order' and ref_id=?""", (o6["id"],)).fetchone()[0]
        con.close()
        check("a legacy line is valued from its own order's movement (not more, not less)",
              abs(movement - with_snapshot) <= 1, (movement, with_snapshot))
        check("…and it is reported as estimated, not as a certain snapshot",
              pnl_after["cogs_estimated_lines"] >= 1, pnl_after.get("cogs_estimated_lines"))

        # three odd partial refunds of a taxed bill: the reversed VAT must equal the bill's VAT exactly
        o7 = sell(1)
        tax7 = o7["tax_amount"]
        total7 = o7["total"]
        pnl_before_refunds = httpx.get(BASE + "/api/expenses/pnl", headers=A).json()["sales"]["tax"]
        parts = [total7 // 3, total7 // 3, total7 - 2 * (total7 // 3)]
        for part in parts:
            r = httpx.post(f"{BASE}/api/orders/{o7['id']}/refund", headers=M,
                           json={"method": "cash", "amount": part, "reason": "جزئی"})
            assert r.status_code == 200, r.text
        con = sqlite3.connect(db_path)
        refunds7 = [row[0] for row in con.execute("select amount from payments where order_id=? and is_refund=1",
                                                  (o7["id"],))]
        con.close()
        check("the three parts add up to the bill", -sum(refunds7) == total7, (-sum(refunds7), total7))
        pnl_after_refunds = httpx.get(BASE + "/api/expenses/pnl", headers=A).json()["sales"]["tax"]
        check("the reversed VAT of three partial refunds equals the bill's VAT exactly",
              pnl_before_refunds - pnl_after_refunds == tax7, (pnl_before_refunds - pnl_after_refunds, tax7))

        # ------------------------------------------------ returned goods: cost on the day of the event
        o8 = sell(2)                                       # 2 units
        with con_scope() as con:
            con.execute("update orders set business_date=date('now','-1 day') where id=?", (o8["id"],))
            con.execute("update payments set created_at=datetime('now','-1 day') where order_id=?", (o8["id"],))
        day1 = (date.today() - timedelta(days=1)).isoformat()
        day2 = date.today().isoformat()

        def cogs_on(day):
            r = httpx.get(BASE + "/api/expenses/pnl", headers=A, params={"date_from": day, "date_to": day})
            return r.json()["cogs"]

        d1_before, d2_before = cogs_on(day1), cogs_on(day2)
        line8 = o8["lines"][0]["id"]
        r = httpx.post(f"{BASE}/api/orders/{o8['id']}/refund", headers=M,
                       json={"method": "cash", "amount": o8["total"], "reason": "برگشت کالا",
                             "restock": [{"line_id": line8, "qty": 2}]})
        assert r.status_code == 200, r.text
        con = sqlite3.connect(db_path)
        ev = con.execute("select qty, unit_cost, date(created_at) from order_refund_lines where order_id=?",
                         (o8["id"],)).fetchall()
        con.close()
        check("the return is one event with quantity + frozen unit cost",
              len(ev) == 1 and ev[0][0] == 2 and ev[0][1] > 0, ev)
        check("the sale day COGS did not change", cogs_on(day1) == d1_before, (cogs_on(day1), d1_before))
        check("the return day carries the material cost of what came back",
              cogs_on(day2) - d2_before == -round(ev[0][0] * ev[0][1]), (cogs_on(day2) - d2_before, ev))


    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
