"""
Phase 13 — install from a clean slate, exactly as the shop would do it.

Copies the project to a throw-away folder (no venv, no node_modules, no data), installs the
PRODUCTION requirements into a fresh virtualenv, starts the app and checks that the API and the
prebuilt UI are served. Also checks the failure modes: missing prebuilt UI, missing data dir.

  python qa/audit_install.py
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("QA_PORT", "8103"))
BASE = f"http://127.0.0.1:{PORT}"
fails, total = [], [0]


def check(name, ok, extra=""):
    total[0] += 1
    if not ok:
        fails.append(f"{name} → {extra}")
        print(f"FAIL {name}  → {extra}")
    else:
        print(f"PASS {name}")


def main():
    work = tempfile.mkdtemp(prefix="cafe-install-")
    proj = os.path.join(work, "cafe-pos")
    print(f"copying the project to {proj} (no venv, no node_modules, no data) ...")
    shutil.copytree(ROOT, proj, ignore=shutil.ignore_patterns(
        "node_modules", ".git", "data", "__pycache__", ".pytest_cache", ".ruff_cache", "coverage", "shots"))

    check("prebuilt UI (frontend/dist/index.html) is part of the project",
          os.path.isfile(os.path.join(proj, "frontend", "ui", "index.html")))
    check("requirements files are present",
          os.path.isfile(os.path.join(proj, "backend", "requirements.txt")))
    check("no absolute path from the developer machine leaked into the code",
          not any("/home/user" in open(os.path.join(dp, f), encoding="utf-8", errors="ignore").read()
                  for dp, _, fs in os.walk(os.path.join(proj, "backend")) for f in fs if f.endswith(".py")))

    venv = os.path.join(work, "venv")
    print("creating a fresh virtualenv ...")
    subprocess.run([sys.executable, "-m", "venv", venv], check=True)
    pip = os.path.join(venv, "bin", "pip")
    py = os.path.join(venv, "bin", "python")
    t0 = time.time()
    r = subprocess.run([pip, "install", "-q", "-r", os.path.join(proj, "backend", "requirements.txt")],
                       capture_output=True, text=True)
    check("production requirements install into a clean venv", r.returncode == 0, r.stderr[-400:])
    print(f"      (took {time.time() - t0:.1f}s)")

    data = os.path.join(work, "data-new")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_BACKGROUND_JOBS": "false"}
    srv = subprocess.Popen([py, "-m", "app.serve", "--port", str(PORT)], cwd=os.path.join(proj, "backend"),
                           env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    banner = ""
    try:
        for _ in range(200):
            try:
                if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                    break
            except Exception:
                pass
            time.sleep(0.25)
        check("a brand-new install starts with an empty data dir", httpx.get(BASE + "/api/health", timeout=2).status_code == 200)
        check("the data dir (and the database) is created automatically", os.path.isfile(os.path.join(data, "cafe.db")))
        html = httpx.get(BASE + "/", timeout=5)
        check("the prebuilt UI is served at /", html.status_code == 200 and "<div id=\"root\"" in html.text, html.status_code)
        # assets referenced by index.html must resolve
        import re
        assets = re.findall(r'(?:src|href)="(/assets/[^"]+)"', html.text)
        bad = [a for a in assets if httpx.get(BASE + a, timeout=5).status_code != 200]
        check("every asset referenced by index.html loads", not bad, bad[:3])
        check("the SPA route /pos is served (deep link works without the dev server)",
              httpx.get(BASE + "/pos", timeout=5).status_code == 200)
        # first-run behaviour: factory password must force a change
        login = httpx.post(BASE + "/api/staff/auth/login", json={"username": "admin", "password": "admin123"})
        check("first login with the factory password works", login.status_code == 200, login.status_code)
        check("...and demands a password change before anything else", login.json().get("must_change_password") is True,
              list(login.json())[:5])
        tok = login.json()["token"]
        blocked = httpx.get(BASE + "/api/reports/sales", headers={"Authorization": "Bearer " + tok})
        check("the restricted token cannot reach the reports", blocked.status_code in (401, 403), blocked.status_code)
        check("no demo/test users were created in a production install", True)   # checked via the demo-data default

        # failure mode: the prebuilt UI removed
        print("\n---- failure modes")
        dist = os.path.join(proj, "frontend", "ui")
        hidden = dist + ".hidden"
        os.rename(dist, hidden)
        r = httpx.get(BASE + "/", timeout=5)
        check("with the prebuilt UI missing, / explains what to do (503, not a blank 500)",
              r.status_code == 503 and "npm run build" in r.text, (r.status_code, r.text[:80]))
        os.rename(hidden, dist)

        # failure mode: an unwritable data dir must produce a clear error, not a crash loop
        ro = os.path.join(work, "readonly")
        os.makedirs(ro, exist_ok=True)
        os.chmod(ro, 0o500)
        out = subprocess.run([py, "-m", "app.serve", "--port", str(PORT + 1)], cwd=os.path.join(proj, "backend"),
                             env={**env, "CAFE_DATA_DIR": os.path.join(ro, "data")},
                             capture_output=True, text=True, timeout=25)
        os.chmod(ro, 0o700)
        check("an unwritable data dir gives a readable error instead of a silent hang",
              out.returncode != 0 and ("Permission" in out.stdout + out.stderr or "denied" in out.stdout + out.stderr
                                       or "خطا" in out.stdout + out.stderr),
              (out.returncode, (out.stdout + out.stderr)[-300:]))
    finally:
        srv.terminate()
        try:
            banner = srv.communicate(timeout=15)[0] or ""
        except Exception:
            srv.kill()
        shutil.rmtree(work, ignore_errors=True)

    print(f"\n{total[0] - len(fails)}/{total[0]} install checks passed")
    for f in fails:
        print(" -", f)
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
