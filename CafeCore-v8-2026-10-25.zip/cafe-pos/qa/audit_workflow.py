"""
Phase 6/7 — order lifecycle (state machine), kitchen tickets and multi-device concurrency.

Every check is a request against a running server with throw-away data; the point is to prove that
ILLEGAL transitions are refused (not just that legal ones work).

  python qa/audit_workflow.py
"""
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8097"))
BASE = f"http://127.0.0.1:{PORT}"
fails, total = [], [0]


def check(name, ok, extra=""):
    total[0] += 1
    if not ok:
        fails.append(f"{name} → {extra}")
        print(f"FAIL {name}  → {extra}")


def start(data):
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(160):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            pass
        time.sleep(0.25)
    raise SystemExit("server did not start")


def main():
    data = tempfile.mkdtemp(prefix="cafe-audit-flow-")
    srv = start(data)
    try:
        def login(u, p):
            return {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                            json={"username": u, "password": p}).json()["token"]}
        A, C = login("admin", "admin123"), login("reza", "cashier123")
        K = login("chef", "kitchen123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})
        full = httpx.get(BASE + "/api/menu/full", headers=C).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        items = [i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                 and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]
        it = items[0]

        def new(**kw):
            body = {"type": "takeaway", "lines": [{"menu_item_id": it["id"], "qty": 2}]}
            body.update(kw)
            r = httpx.post(BASE + "/api/orders", headers=C, json=body)
            assert r.status_code == 201, r.text
            return r.json()

        def pay(o, amount=None):
            return httpx.post(BASE + f"/api/orders/{o['id']}/payments", headers=C,
                              json={"payments": [{"method": "cash", "amount": amount or o["remaining"]}]})

        print("---- illegal transitions on a CLOSED order")
        o = new()
        check("paying the full remaining amount closes the order", pay(o).json()["status"] == "closed")
        closed = httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()
        checks = [
            ("add a line", httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C,
                                      json={"lines": [{"menu_item_id": it["id"], "qty": 1}]})),
            ("change a quantity", httpx.patch(BASE + f"/api/orders/{o['id']}/lines/{o['lines'][0]['id']}",
                                              headers=C, json={"qty": 5})),
            ("void a line", httpx.post(BASE + f"/api/orders/{o['id']}/lines/{o['lines'][0]['id']}/void",
                                       headers=A, json={"reason": "تست"})),
            ("apply a discount", httpx.post(BASE + f"/api/orders/{o['id']}/discount", headers=A,
                                            json={"type": "percent", "value": 10, "reason": "تست"})),
            ("cancel it", httpx.post(BASE + f"/api/orders/{o['id']}/cancel", headers=A, json={"reason": "تست"})),
            ("pay it again", pay(closed, 1000)),
            ("split it", httpx.post(BASE + f"/api/orders/{o['id']}/split", headers=A,
                                    json={"lines": [{"line_id": o["lines"][0]["id"], "qty": 1}]})),
            ("transfer it", httpx.post(BASE + f"/api/orders/{o['id']}/transfer", headers=A, json={"table_id": 1})),
        ]
        for label, r in checks:
            check(f"closed order: {label} is refused", r.status_code >= 400, r.status_code)

        print("\n---- illegal transitions on a CANCELLED order")
        o = new()
        r = httpx.post(BASE + f"/api/orders/{o['id']}/cancel", headers=A, json={"reason": "مشتری منصرف شد"})
        check("cancelling an unpaid order works", r.status_code == 200, r.text[:120])
        r2 = httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C,
                        json={"lines": [{"menu_item_id": it["id"], "qty": 1}]})
        check("cancelled order: adding a line is refused", r2.status_code >= 400, r2.status_code)
        r3 = httpx.post(BASE + f"/api/orders/{o['id']}/payments", headers=C,
                        json={"payments": [{"method": "cash", "amount": 1000}]})
        check("cancelled order: paying is refused", r3.status_code >= 400, r3.status_code)

        print("\n---- refund rules")
        o = new()
        pay(o)
        paid = httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()
        r = httpx.post(BASE + f"/api/orders/{o['id']}/refund", headers=A,
                       json={"method": "cash", "amount": paid["total"] + 1, "reason": "تست"})
        check("refund above the paid amount is refused", r.status_code >= 400, r.status_code)
        r = httpx.post(BASE + f"/api/orders/{o['id']}/refund", headers=A,
                       json={"method": "cash", "amount": paid["total"], "reason": "تست"})
        check("a full refund is accepted", r.status_code == 200, r.text[:150])
        r = httpx.post(BASE + f"/api/orders/{o['id']}/refund", headers=A,
                       json={"method": "cash", "amount": 1000, "reason": "تست"})
        check("a second refund against the same payment is refused", r.status_code >= 400, r.status_code)
        o2 = new()
        r = httpx.post(BASE + f"/api/orders/{o2['id']}/refund", headers=A,
                       json={"method": "cash", "amount": 1000, "reason": "تست"})
        check("refunding an unpaid order is refused", r.status_code >= 400, r.status_code)

        print("\n---- kitchen: ticket lifecycle")
        o = new(send=True)
        tk = httpx.get(BASE + "/api/kitchen/tickets", headers=K).json()
        mine = [t for t in tk if t["order_number"] == o["number"]]
        check("sending an order creates exactly one kitchen ticket", len(mine) == 1, len(mine))
        if mine:
            tid = mine[0]["id"]
            # sending again must not duplicate the ticket
            httpx.post(BASE + f"/api/orders/{o['id']}/send", headers=C)
            tk2 = httpx.get(BASE + "/api/kitchen/tickets", headers=K).json()
            check("sending twice does not duplicate the ticket",
                  len([t for t in tk2 if t["order_number"] == o["number"]]) == 1)
            r = httpx.post(BASE + f"/api/kitchen/tickets/{tid}/status", headers=K, json={"status": "preparing"})
            check("kitchen can move a ticket to preparing", r.status_code in (200, 204), r.status_code)
            # a ticket walks new → preparing → ready → done, one bump per step
            seen = []
            for _ in range(4):
                httpx.post(BASE + f"/api/kitchen/tickets/{tid}/bump", headers=K)
                t = [x for x in httpx.get(BASE + "/api/kitchen/tickets", headers=K, params={"include_done": True}).json()
                     if x["id"] == tid]
                seen.append(t[0]["status"] if t else None)
                if seen[-1] == "done":
                    break
            check("bumping walks the ticket to done and stops there", seen and seen[-1] == "done", seen)
            # a voided line must disappear from the kitchen's view of the order
            o3 = new(send=True)
            lid = o3["lines"][0]["id"]
            httpx.post(BASE + f"/api/orders/{o3['id']}/lines/{lid}/void", headers=A, json={"reason": "تست"})
            t3 = [x for x in httpx.get(BASE + "/api/kitchen/tickets", headers=K).json() if x["order_number"] == o3["number"]]
            voided = t3 and all(i["is_void"] for i in t3[0]["items"] if i["menu_item_id"] == it["id"]) if t3 else True
            check("a voided line is flagged to the kitchen, not silently cooked", bool(voided), t3[:1])

        print("\n---- tables: occupancy rules")
        floor = httpx.get(BASE + "/api/orders/floor", headers=C).json()
        free = [t for a in floor for t in a["tables"] if t["status"] == "free"]
        if len(free) >= 2:
            t1, t2 = free[0]["id"], free[1]["id"]
            o1 = new(type="dine_in", table_id=t1)
            o2 = new(type="dine_in", table_id=t2)
            r = httpx.post(BASE + f"/api/orders/{o1['id']}/transfer", headers=A, json={"table_id": t2})
            check("transfer onto an occupied table is refused", r.status_code >= 400, r.status_code)
            r = httpx.post(BASE + f"/api/orders/{o1['id']}/transfer", headers=A, json={"table_id": t1})
            check("transfer onto its own table is refused (or a no-op)", r.status_code >= 400 or r.json()["table_id"] == t1, r.status_code)
            r = httpx.post(BASE + f"/api/orders/{o1['id']}/merge", headers=A, json={"target_order_id": o2["id"]})
            check("merging two orders works", r.status_code == 200, r.text[:120])
            left = [x for x in httpx.get(BASE + "/api/orders/active", headers=C).json() if x["table_id"] == t1]
            check("after a merge the source table is free again", not left, left[:1])

        print("\n---- multi-device: 10 clients adding lines to the SAME order at once")
        o = new()
        before = len(httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()["lines"])
        errs = []

        def add(k):
            r = httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C,
                           json={"lines": [{"menu_item_id": it["id"], "qty": 1, "note": f"دستگاه {k}"}],
                                 "request_id": f"dev-{k}-aaaa1111"}, timeout=20)
            if r.status_code != 200:
                errs.append(r.status_code)
        threads = [threading.Thread(target=add, args=(k,)) for k in range(10)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        final = httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()
        check("all 10 concurrent line additions succeeded", not errs, errs)
        check("no line was lost or duplicated", len(final["lines"]) - before == 10, (len(final["lines"]) - before, errs))
        check("the order total matches its lines after the burst",
              final["subtotal"] == sum(l["unit_price"] * l["qty"] for l in final["lines"] if l["status"] != "void"),
              final["subtotal"])

        print("\n---- the same request replayed (offline queue behaviour)")
        # a unique note keeps this line from merging into an identical pending one, so the count is meaningful
        o = new()
        before = len(httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()["lines"])
        body = {"lines": [{"menu_item_id": it["id"], "qty": 1, "note": "replay-تست"}], "request_id": "replay-9999-zzzz"}
        r1 = httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C, json=body)
        r2 = httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C, json=body)
        after = len(httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()["lines"])
        check("a replayed request adds the line exactly once", r1.status_code == r2.status_code == 200 and after - before == 1,
              (r1.status_code, r2.status_code, after - before))
        # and merging identical lines is the documented behaviour for a *different* request id
        body2 = {"lines": [{"menu_item_id": it["id"], "qty": 2, "note": "replay-تست"}], "request_id": "merge-8888-zzzz"}
        r3 = httpx.post(BASE + f"/api/orders/{o['id']}/lines", headers=C, json=body2)
        lines_now = httpx.get(BASE + f"/api/orders/{o['id']}", headers=C).json()["lines"]
        merged = [l for l in lines_now if l["note"] == "replay-تست"]
        check("an identical line is merged (qty 3) instead of being duplicated",
              r3.status_code == 200 and len(merged) == 1 and merged[0]["qty"] == 3,
              [(l["qty"], l["note"]) for l in lines_now])
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
        shutil.rmtree(data, ignore_errors=True)

    print(f"\n{total[0] - len(fails)}/{total[0]} workflow checks passed")
    if fails:
        print("\nfailures:")
        for f in fails:
            print(" -", f)
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
