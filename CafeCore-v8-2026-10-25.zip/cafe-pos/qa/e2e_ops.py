import os, subprocess, sys, tempfile, time, sqlite3, shutil, httpx
from playwright.sync_api import sync_playwright
FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
data = tempfile.mkdtemp(prefix="cafe-ops-"); port = 8031; B = f"http://127.0.0.1:{port}"
src = sqlite3.connect(os.path.expanduser("~/cafe-pos/data/cafe.db")); dst = sqlite3.connect(f"{data}/cafe.db"); src.backup(dst); dst.close(); src.close()
shutil.copy(os.path.expanduser("~/cafe-pos/data/secret.key"), data)
env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")}, "CAFE_DATA_DIR": data, "CAFE_PORT": str(port),
       "CAFE_SAMPLE_USERS": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
def start():
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"],
                         cwd=os.path.expanduser("~/cafe-pos/backend"), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(80):
        try: httpx.get(B + "/api/health", timeout=1); return p
        except Exception: time.sleep(0.25)
    raise SystemExit("server did not start")
res = []
def check(n, c, extra=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, extra if not c else "")
login = lambda u, pw: httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": pw}).json()["token"]
srv = start()
try:
    tc, tk = login("reza", "cashier123"), login("chef", "kitchen123"); H = {"Authorization": "Bearer " + tc}
    httpx.post(B + "/api/shifts/open", headers=H, json={"opening_cash": 0})
    full = httpx.get(B + "/api/menu/full", headers=H).json(); groups = {g["id"]: g for g in full["modifier_groups"]}
    item = next(i for i in full["items"] if i["is_active"] and i["is_available"] and not (i["code"] or "").startswith("__") and i["station_id"]
                and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))
    def new_order(note=None):
        return httpx.post(B + "/api/orders", headers=H, json={"type": "takeaway", "send": True,
                          "lines": [{"menu_item_id": item["id"], "qty": 2, "note": note}]}).json()
    with sync_playwright() as p:
        br = p.chromium.launch()
        kctx = br.new_context(viewport={"width": 1280, "height": 800}); kctx.add_init_script(f"localStorage.setItem('cafe_token','{tk}')")
        kds = kctx.new_page(); kerr = []; kds.on("pageerror", lambda e: kerr.append(str(e)))
        kds.goto(B + "/kds", wait_until="networkidle"); kds.wait_for_timeout(1000)
        o1 = new_order()
        try: kds.get_by_text(f"#{str(o1['number']).translate(FA)}").first.wait_for(timeout=5000); live = True
        except Exception: live = False
        check("KDS shows a new order live (no refresh)", live)
        # backend restart while KDS stays open
        srv.terminate(); srv.wait(10); kds.wait_for_timeout(1500)
        srv = start()
        tc = login("reza", "cashier123"); H["Authorization"] = "Bearer " + tc
        o2 = new_order()
        try: kds.get_by_text(f"#{str(o2['number']).translate(FA)}").first.wait_for(timeout=20000); rec = True
        except Exception: rec = False
        check("KDS reconnects after backend restart and shows new order", rec)
        kds.reload(wait_until="networkidle"); kds.wait_for_timeout(800)
        body = kds.inner_text("body")
        check("KDS state restored from server after refresh", f"#{str(o1['number']).translate(FA)}" in body and f"#{str(o2['number']).translate(FA)}" in body)
        # concurrent bump of the same ticket from two KDS screens
        tid = next(t["id"] for t in httpx.get(B + "/api/kitchen/tickets", headers={"Authorization": "Bearer " + tk}).json() if t["order_id"] == o1["id"])
        import threading
        out = []
        ths = [threading.Thread(target=lambda: out.append(httpx.post(B + f"/api/kitchen/tickets/{tid}/bump", headers={"Authorization": "Bearer " + tk}).status_code)) for _ in range(4)]
        [t.start() for t in ths]; [t.join() for t in ths]
        st = next((t for t in httpx.get(B + "/api/kitchen/tickets", headers={"Authorization": "Bearer " + tk}, params={"include_done": True}).json() if t["id"] == tid), None)
        check("4 simultaneous bumps → no 5xx", all(s < 500 for s in out), out)
        # kitchen user: no POS/admin
        kds.goto(B + "/pos", wait_until="networkidle"); kds.wait_for_timeout(700)
        check("chef cannot open POS", "/pos" not in kds.url or "صندوق" not in kds.inner_text("body")[:400], kds.url)
        kds.goto(B + "/admin/dashboard", wait_until="networkidle"); kds.wait_for_timeout(700)
        check("chef cannot open admin dashboard", "/admin/dashboard" not in kds.url, kds.url)
        check("no JS errors on KDS", not kerr, kerr)
        # printing from the built frontend (cashier)
        long_note = "بدون شکر، شیر بادام گرم جداگانه سرو شود و لیوان کاغذی دوجداره برای بیرون بردن آماده شود لطفاً"
        o3 = new_order(long_note)
        pay = httpx.post(B + f"/api/orders/{o3['id']}/payments", headers=H, json={"payments": [{"method": "cash", "amount": o3["total"] + 50000, "tendered": o3["total"] + 50000}]}).json()
        cctx = br.new_context(viewport={"width": 1280, "height": 800}); cctx.add_init_script(f"localStorage.setItem('cafe_token','{tc}')")
        cctx.add_init_script("""window.__printed = []; new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
            if (n.tagName === 'IFRAME') n.contentWindow.print = () => window.__printed.push(n.contentDocument.documentElement.outerHTML) }))).observe(document, {childList: true, subtree: true})""")
        pos = cctx.new_page(); perr = []; pos.on("pageerror", lambda e: perr.append(str(e)))
        before = httpx.get(B + "/api/orders", headers=H, params={"size": 1}).json()["total"]
        pos.goto(B + "/admin/orders", wait_until="networkidle"); pos.wait_for_timeout(800)
        pos.get_by_placeholder("شماره سفارش، نام یا تلفن مشتری").fill(str(o3["number"])); pos.keyboard.press("Enter"); pos.wait_for_timeout(800)
        pos.locator("tr.ant-table-row").first.locator("button").first.click(); pos.wait_for_timeout(800)
        for _ in range(3):
            pos.get_by_role("button", name="چاپ").first.click(); pos.wait_for_timeout(500)
        printed = pos.evaluate("window.__printed")
        check("receipt printed 3× from built UI", len(printed) == 3, len(printed))
        after = httpx.get(B + "/api/orders", headers=H, params={"size": 1}).json()["total"]
        check("repeat printing creates no orders", after == before, (before, after))
        if printed:
            html = printed[0]
            for label, needle in (("business name", "کافه"), ("order number", str(o3["number"]).translate(FA)), ("total label", "مبلغ قابل پرداخت"),
                                  ("payment method", "نقد"), ("change", "باقیمانده"), ("note", "شیر بادام")):
                check(f"receipt has {label}", needle in html)
            pg = br.new_page(viewport={"width": 302, "height": 600}); pg.set_content(html); pg.wait_for_timeout(300)
            ov = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check("receipt fits 80mm (no horizontal overflow)", ov <= 0, ov)
            pg.screenshot(path="shots/receipt_80mm.png", full_page=True)
            pg.pdf(path="shots/receipt_80mm.pdf", width="80mm", print_background=True)
        check("no JS errors in orders/print", not perr, perr)
        # kitchen ticket print from KDS (if the KDS offers a print button)
        br.close()
finally:
    srv.terminate(); srv.wait(10)
shutil.rmtree(data, ignore_errors=True)
print(f"{sum(res)}/{len(res)} passed")
