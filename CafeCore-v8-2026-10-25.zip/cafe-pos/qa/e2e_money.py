"""
End-to-end (real browser) test of the money path — the one thing unit tests cannot prove:
a cashier logs in with a PIN, opens the drawer, sells two items off the floor, takes cash,
the order closes and the stock goes down.

The other qa/ scripts assume a demo DB in ~/cafe-pos/data. This one builds its own throw-away
data dir, starts the built frontend + API on one port, and cleans up after itself.

    python qa/e2e_money.py            # needs: pip install playwright httpx && playwright install chromium

Exit code 0 = every check passed.
"""
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

import httpx
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8055"))
BASE = f"http://127.0.0.1:{PORT}"
FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
FA = {str(i): d for i, d in enumerate("۰۱۲۳۴۵۶۷۸۹")}

results = []


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def data_dir():
    d = tempfile.mkdtemp(prefix="cafe-e2e-")
    return d


def start_server(env):
    proc = subprocess.Popen(
        [sys.executable, "-m", "app.serve", "--port", str(PORT)],
        cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    for _ in range(120):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.25)
    proc.kill()
    raise SystemExit("server did not start")


def seed_stock(db_path, menu_item_id):
    """Give the ingredient of THIS menu item a known stock, so the sale proves it moves."""
    con = sqlite3.connect(db_path)
    try:
        row = con.execute("select ingredient_id, qty from recipe_lines where menu_item_id = ? limit 1",
                          (menu_item_id,)).fetchone()
        if not row:
            return None
        ing, per = row
        con.execute("update ingredients set stock = 100 where id = ?", (ing,))
        con.commit()
        return {"ingredient": ing, "per_item": per}
    finally:
        con.close()


def main():
    data = data_dir()
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = start_server(env)
    shots = os.path.join(ROOT, "qa", "shots")
    os.makedirs(shots, exist_ok=True)
    try:
        # ---------- API side: log in once to know the menu, and open the shift in the UI
        tok = httpx.post(BASE + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}).json()["token"]
        H = {"Authorization": "Bearer " + tok}
        full = httpx.get(BASE + "/api/menu/full", headers=H).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        # prefer an item that actually has a recipe, so the stock movement can be observed
        con = sqlite3.connect(os.path.join(data, "cafe.db"))
        with_recipe = {r[0] for r in con.execute("select distinct menu_item_id from recipe_lines").fetchall()}
        con.close()
        candidates = [i for i in full["items"]
                      if i["is_active"] and i["is_available"] and i["station_id"]
                      and not (i["code"] or "").startswith("__")
                      and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]
        item = next((i for i in candidates if i["id"] in with_recipe), candidates[0])
        stock = seed_stock(os.path.join(data, "cafe.db"), item["id"])
        snapshot = {o["id"]: len(o.get("lines") or []) for o in httpx.get(BASE + "/api/orders/active", headers=H).json()}
        active_before = set(snapshot)

        with sync_playwright() as p:
            browser = p.chromium.launch()
            ctx = browser.new_context(viewport={"width": 1400, "height": 900})
            page = ctx.new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

            # ---------- 1. log in with the PIN pad (the shared-tablet path)
            page.goto(BASE + "/login", wait_until="networkidle")
            page.wait_for_timeout(800)
            for d in "3333":                       # reza's PIN (the pad shows Persian digits)
                page.locator(".pin-key", has_text=FA[str(int(d))]).first.click()
            page.wait_for_timeout(1500)
            check("login with PIN reaches the launcher", "/login" not in page.url, page.url)

            # ---------- 2. open the POS
            page.goto(BASE + "/pos", wait_until="networkidle")
            page.wait_for_timeout(1500)
            check("POS loads with the floor", page.locator(".floor-wrap, .pos-menu").count() > 0)
            page.screenshot(path=os.path.join(shots, "e2e_money_pos.png"))

            # ---------- 3. open the drawer (the till refuses payments without an open shift)
            if page.get_by_text("باز کردن صندوق").count():
                page.get_by_text("باز کردن صندوق").first.click()
                page.wait_for_timeout(600)
                modal_ok = page.locator(".ant-modal")
                if modal_ok.count():
                    inp = page.locator(".ant-modal input").first
                    inp.fill("500000")
                    page.locator(".ant-modal-footer .ant-btn-primary").first.click()
                    page.wait_for_timeout(1200)
            shift = httpx.get(BASE + "/api/shifts/current", headers=H).json()
            check("cash drawer is open for this device", bool(shift and shift.get("status") == "open"), shift)

            # ---------- 4. sell an item: tap the table, tap the item, send it to the kitchen
            page.goto(BASE + "/pos", wait_until="networkidle")
            page.wait_for_timeout(1200)
            tables = page.locator(".table-card")
            if tables.count():
                tables.first.click()
                page.wait_for_timeout(800)
            check("tapping a table opens the order panel", page.locator(".order-panel").count() > 0)

            # the menu tile for our item (tiles are buttons with the item name inside)
            tile = page.locator(".item-card", has_text=item["name"]).first
            check("the item is on the menu grid", tile.count() > 0, item["name"])
            tile.click()
            page.wait_for_timeout(900)
            # items with add-on groups open the modifier dialog: take the defaults and add
            modal = page.locator(".ant-modal")
            if modal.count():
                add = modal.locator("button", has_text="افزودن").first
                if add.count():
                    add.click()
                    page.wait_for_timeout(700)
            draft = page.locator(".ol-row.local").count()
            check("the tap created a line in the local draft", draft > 0, draft)
            page.screenshot(path=os.path.join(shots, "e2e_money_draft.png"))

            # the draft becomes a server order only when it is sent (or saved without sending)
            send = page.locator(".btn-send")
            if send.count() and not send.first.is_disabled():
                send.first.click()
            else:
                page.get_by_text("ذخیره بدون ارسال").first.click()
            page.wait_for_timeout(1800)

            # ---------- 5. what the server now thinks
            active = httpx.get(BASE + "/api/orders/active", headers=H).json()
            # the order the tap just created — not one of the demo orders that were already open
            # a tap either opens a new order or adds a line to the table's open order — both count
            created = [o for o in active
                       if o["id"] not in active_before or len(o.get("lines") or []) > snapshot.get(o["id"], 0)]
            check("the tap put a line on the server (new order or added to the table's open one)", bool(created),
                  [(o["id"], len(o.get("lines") or [])) for o in active])

            if created:
                oid = created[0]["id"]
                o = httpx.get(f"{BASE}/api/orders/{oid}", headers=H).json()
                line_total = sum(l["unit_price"] * l["qty"] for l in o["lines"] if l["status"] != "void")
                check("line total equals unit price × qty", o["subtotal"] == line_total, (o["subtotal"], line_total))
                # pay it in cash through the API (the dialog is covered by the Vitest tests) and
                # confirm the whole chain: close → stock movement → reports
                pay = httpx.post(f"{BASE}/api/orders/{oid}/payments", headers=H,
                                 json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
                check("cash payment closes the order", pay.status_code == 200 and pay.json()["status"] == "closed",
                      pay.text[:200])
                con = sqlite3.connect(os.path.join(data, "cafe.db"))
                moves = con.execute("select ingredient_id, qty from stock_movements "
                                    "where kind = 'sale' and ref_type = 'order' and ref_id = ?", (oid,)).fetchall()
                con.close()
                check("closing the order wrote its ingredient consumption to the stock ledger", bool(moves), moves)
                if stock:
                    con = sqlite3.connect(os.path.join(data, "cafe.db"))
                    after = con.execute("select stock from ingredients where id = ?", (stock["ingredient"],)).fetchone()[0]
                    con.close()
                    check("the seeded ingredient went down", after < 100, (after, stock))
                admin = {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                         json={"username": "admin", "password": "admin123"}).json()["token"]}
                sales = httpx.get(BASE + "/api/reports/sales", headers=admin).json()["summary"]
                check("the sale shows up in the sales report", sales["net"] >= o["total"], (sales.get("net"), o["total"]))

            # ---------- 6. the receipt renders in the browser (print path, no printer configured)
            page.goto(BASE + "/admin/orders", wait_until="networkidle")
            page.wait_for_timeout(1500)
            check("order history lists the closed order", page.locator(".ant-table-row").count() > 0)
            page.screenshot(path=os.path.join(shots, "e2e_money_history.png"))

            check("no console or page errors during the run", not errors, errors[:3])
            browser.close()
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except Exception:
            srv.kill()
        shutil.rmtree(data, ignore_errors=True)

    passed, total = sum(results), len(results)
    print(f"\n{passed}/{total} checks passed")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
