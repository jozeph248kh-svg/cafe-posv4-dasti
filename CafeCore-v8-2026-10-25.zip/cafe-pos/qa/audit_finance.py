"""
Phase 5 — financial correctness, checked against an INDEPENDENT recomputation.

For N random orders (random items, quantities, discounts, payments, tax/service/rounding settings)
the script recomputes every number from scratch — in plain integer arithmetic, outside the app —
and compares it with what the API stored and with what the reports say.

  python qa/audit_finance.py            # default 120 random orders
"""
import os
import random
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8095"))
BASE = f"http://127.0.0.1:{PORT}"
fails = []
checks = [0]


def check(name, ok, extra=""):
    checks[0] += 1
    if not ok:
        fails.append(f"{name} → {extra}")
        print(f"FAIL {name}  → {extra}")


def start(data):
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(160):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            pass
        time.sleep(0.25)
    raise SystemExit("server did not start")


def expected_money(subtotal, line_disc, bill_type, bill_value, bill_cap, settings, order_type):
    """The pricing rules, re-implemented here from the spec — deliberately NOT imported from the app."""
    discount = line_disc
    remainder = subtotal - line_disc
    if remainder > 0 and bill_type:
        if bill_type == "percent":
            bill = round(remainder * min(bill_value, 100) / 100)
        else:
            bill = min(bill_value, remainder)
        if bill_cap:
            bill = min(bill, bill_cap)
        bill = max(min(bill, remainder), 0)
        discount += bill
    base = subtotal - discount
    # the spec says: service charge only on dine-in tables
    service = round(base * settings["service.percent"] / 100) if settings["service.enabled"] and order_type == "dine_in" else 0
    tax = round((base + service) * settings["tax.percent"] / 100) if settings["tax.enabled"] else 0
    raw = base + service + tax
    step = settings["rounding.step"]
    total = round(raw / step) * step if step > 0 else raw
    return {"discount": discount, "service": service, "tax": tax, "rounding": total - raw, "total": max(total, 0)}


def main():
    random.seed(20261001)
    n_orders = int(os.environ.get("QA_ORDERS", "120"))
    data = tempfile.mkdtemp(prefix="cafe-audit-fin-")
    srv = start(data)
    try:
        def login(u, p):
            return {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                            json={"username": u, "password": p}).json()["token"]}
        A = login("admin", "admin123")
        C = login("reza", "cashier123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})

        # The demo data ships an AUTOMATIC discount («هپی‌آور نوشیدنی سرد», 20 % on cold drinks, 16:00–19:00).
        # Between 16:00 and 19:00 it silently discounts the orders this audit creates, so its own recomputation
        # disagrees with the server (57 false failures, reproducible only in that window — the app is right, the
        # audit was time-dependent). An automatic preset is a separate feature; this audit checks the pricing
        # formula, so the auto presets are switched off here (the data dir is temporary).
        # The list endpoint only shows pickable presets, so the automatic ones are read from the management view.
        def presets():
            return httpx.get(BASE + "/api/orders/discounts/presets", headers=A, params={"all": "true"}).json()

        auto = [p for p in presets() if p.get("auto_apply")]
        for p in auto:
            body = {k: p.get(k) for k in ("name", "kind", "value", "scope", "is_active", "start_time", "end_time",
                                          "color", "min_subtotal", "target_item_ids", "target_category_ids",
                                          "requires_manager", "reason_required", "max_amount", "code")}
            body["auto_apply"] = False
            r = httpx.put(f"{BASE}/api/orders/discounts/presets/{p['id']}", headers=A, json=body)
            check(f"auto preset «{p['name']}» switched off for this audit", r.status_code in (200, 201, 204), r.text[:160])
        left = [p for p in presets() if p.get("auto_apply")]
        check("no automatic discount preset can disturb this audit", not left, [p["name"] for p in left])
        if auto:
            print(f"  ({len(auto)} automatic discount preset(s) disabled for this run)")

        full = httpx.get(BASE + "/api/menu/full", headers=C).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        items = [i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                 and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]
        assert len(items) >= 5, "need a few orderable items"

        settings_sets = [
            {"tax.enabled": True, "tax.percent": 10, "service.enabled": True, "service.percent": 0, "rounding.step": 0},
            {"tax.enabled": True, "tax.percent": 9, "service.enabled": True, "service.percent": 10, "rounding.step": 0},
            {"tax.enabled": True, "tax.percent": 10, "service.enabled": False, "service.percent": 0, "rounding.step": 1000},
            {"tax.enabled": False, "tax.percent": 0, "service.enabled": False, "service.percent": 0, "rounding.step": 0},
        ]
        totals_paid = 0
        for k in range(n_orders):
            s = settings_sets[k % len(settings_sets)]
            httpx.put(BASE + "/api/system/settings", headers=A, json=s).raise_for_status() if k % 15 == 0 else None
            # read the settings the server actually has (it validates and may normalise)
            live = httpx.get(BASE + "/api/system/settings", headers=A).json()
            cfg = {"tax.enabled": live["tax.enabled"], "tax.percent": live["tax.percent"],
                   "service.enabled": live["service.enabled"], "service.percent": live["service.percent"],
                   "rounding.step": live["rounding.step"]}
            mode = ["takeaway", "dine_in", "delivery"][k % 3] if k % 7 else "takeaway"
            floor = httpx.get(BASE + "/api/orders/floor", headers=C).json()
            free = [t for a in floor for t in a["tables"] if t["status"] == "free"]
            if mode == "dine_in" and not free:
                mode = "takeaway"
            body = {"type": mode, "lines": [{"menu_item_id": it["id"], "qty": random.randint(1, 4)}
                                            for it in random.sample(items, random.randint(1, 3))]}
            if mode == "dine_in":
                body["table_id"] = free[0]["id"]
            if mode == "delivery":
                body.update({"customer_name": "مشتری تست", "customer_phone": "09120000000", "customer_address": "تهران، خیابان تست، پلاک ۱"})
            o = httpx.post(BASE + "/api/orders", headers=C, json=body)
            check(f"#{k} order created", o.status_code == 201, o.text[:120])
            if o.status_code != 201:
                continue
            o = o.json()
            oid = o["id"]

            # --- independent recomputation straight from the stored lines
            sub = sum(l["unit_price"] * l["qty"] for l in o["lines"] if l["status"] != "void")
            line_disc = 0
            bill_type = bill_value = bill_cap = None

            # item discount on the first line (half the orders)
            if k % 2 == 0:
                l0 = o["lines"][0]
                pct = random.choice([5, 10, 15, 33, 50])
                r = httpx.post(f"{BASE}/api/orders/{oid}/lines/{l0['id']}/discount", headers=A,
                               json={"type": "percent", "value": pct, "reason": "تست مالی"})
                check(f"#{k} item discount accepted", r.status_code == 200, r.text[:120])
                if r.status_code == 200:
                    o = r.json()
                    line_disc = sum(l["discount_amount"] for l in o["lines"])

            # bill discount on a third of the orders
            if k % 3 == 0:
                if k % 6 == 0:
                    bill_type, bill_value = "percent", random.choice([5, 10, 25])
                else:
                    bill_type, bill_value = "amount", random.choice([10_000, 50_000])
                bill_cap = None
                r = httpx.post(f"{BASE}/api/orders/{oid}/discount", headers=A,
                               json={"type": bill_type, "value": bill_value, "reason": "تست مالی"})
                check(f"#{k} bill discount accepted", r.status_code == 200, r.text[:120])
                if r.status_code == 200:
                    o = r.json()

            exp = expected_money(sub, line_disc, bill_type, bill_value, bill_cap, cfg, o["type"])
            check(f"#{k} subtotal", o["subtotal"] == sub, (o["subtotal"], sub))
            check(f"#{k} discount", o["discount_amount"] == exp["discount"], (o["discount_amount"], exp))
            check(f"#{k} service", o["service_amount"] == exp["service"], (o["service_amount"], exp["service"]))
            check(f"#{k} tax", o["tax_amount"] == exp["tax"], (o["tax_amount"], exp["tax"]))
            check(f"#{k} rounding", o["rounding"] == exp["rounding"], (o["rounding"], exp["rounding"]))
            check(f"#{k} total", o["total"] == exp["total"], (o["total"], exp))

            # --- payments: split, overpay in cash, partial then rest
            pay_total = o["total"]
            if pay_total == 0:
                r = httpx.post(f"{BASE}/api/orders/{oid}/payments", headers=C,
                               json={"payments": [{"method": "cash", "amount": 1, "tendered": 1}]})
                paid = 0 if r.status_code >= 400 else r.json()["paid_amount"]
            elif k % 4 == 0:
                half = pay_total // 2
                r = httpx.post(f"{BASE}/api/orders/{oid}/payments", headers=C, json={"payments": [
                    {"method": "cash", "amount": half, "tendered": half + 5000},
                    {"method": "card", "amount": pay_total - half}]})
                check(f"#{k} split payment", r.status_code == 200, r.text[:120])
                paid = r.json()["paid_amount"] if r.status_code == 200 else 0
                if r.status_code == 200:
                    o = r.json()
                    change = sum(p["change"] or 0 for p in o["payments"])
                    check(f"#{k} change computed from tendered", change == 5000, change)
            else:
                r = httpx.post(f"{BASE}/api/orders/{oid}/payments", headers=C,
                               json={"payments": [{"method": "cash", "amount": pay_total, "tendered": pay_total}]})
                check(f"#{k} full payment", r.status_code == 200, r.text[:120])
                if r.status_code == 200:
                    o = r.json()
                paid = r.json()["paid_amount"] if r.status_code == 200 else 0

            if r.status_code == 200:
                o = r.json()
                check(f"#{k} paid == total after full payment", o["paid_amount"] == o["total"], (o["paid_amount"], o["total"]))
                check(f"#{k} remaining is zero", o["remaining"] == 0, o["remaining"])
                check(f"#{k} order closed", o["status"] == "closed", o["status"])
                totals_paid += o["total"]

        print(f"\ncreated {n_orders} random orders")

        # --- reports must reconcile with the orders themselves
        sales_doc = httpx.get(BASE + "/api/reports/sales", headers=A).json()
        sales = sales_doc["summary"]
        rng = sales_doc["range"]           # the report covers ONE business day by default
        d1, d2 = rng["from"], rng["to"]
        dash = httpx.get(BASE + "/api/reports/dashboard", headers=A).json()["today"]
        shift = httpx.get(BASE + "/api/shifts/current", headers=A).json()
        con = sqlite3.connect(os.path.join(data, "cafe.db"))
        # the comparison must use the same window the report uses, not the whole demo history
        q = "select coalesce(sum(total),0) from orders where status='closed' and business_date between ? and ?"
        db_net = con.execute(q, (d1, d2)).fetchone()[0]
        db_tax = con.execute("select coalesce(sum(tax_amount),0) from orders where status='closed' and business_date between ? and ?", (d1, d2)).fetchone()[0]
        db_disc = con.execute("select coalesce(sum(discount_amount),0) from orders where status='closed' and business_date between ? and ?", (d1, d2)).fetchone()[0]
        con.close()
        check("sales report net == sum of closed orders in the DB", sales["net"] == db_net, (sales["net"], db_net))
        check("dashboard net == sales report net", dash["net"] == sales["net"], (dash["net"], sales["net"]))
        check("shift total == sales report net", shift["total_sales"] == sales["net"], (shift["total_sales"], sales["net"]))
        check("reported tax == sum of order tax", sales["tax"] == db_tax, (sales["tax"], db_tax))
        check("reported discounts == sum of order discounts", sales["discounts"] == db_disc, (sales["discounts"], db_disc))
        check("by_payment sums to the net collected", sum(p["amount"] for p in httpx.get(BASE + "/api/reports/sales", headers=A).json()["by_payment"]) == sales["net"],
              httpx.get(BASE + "/api/reports/sales", headers=A).json()["by_payment"])

        # --- a refund must reduce the net by exactly its amount
        con = sqlite3.connect(os.path.join(data, "cafe.db"))
        oid, total = con.execute("select id, total from orders where status='closed' and total>0 and business_date between ? and ? order by id desc limit 1", (d1, d2)).fetchone()
        con.close()
        sum_before = httpx.get(BASE + "/api/reports/sales", headers=A).json()["summary"]
        rr = httpx.post(f"{BASE}/api/orders/{oid}/refund", headers=A, json={"method": "cash", "amount": total, "reason": "تست مالی"})
        check("refund accepted", rr.status_code == 200, rr.text[:150])
        sum_after = httpx.get(BASE + "/api/reports/sales", headers=A).json()["summary"]
        # the report keeps net sales and refunds as two separate lines (net stays the gross-of-refunds
        # sales figure); what must hold is that the refund line moves by exactly the refunded amount
        check("the refunds line moves by exactly the refunded amount",
              sum_after["refunds"] - sum_before["refunds"] == total, (sum_before.get("refunds"), sum_after.get("refunds"), total))
        check("net sales (excluding refunds) is unchanged by a refund",
              sum_after["net"] == sum_before["net"], (sum_before["net"], sum_after["net"]))
        check("net minus refunds equals the money actually kept",
              sum_after["net"] - sum_after["refunds"] == sum_before["net"] - sum_before["refunds"] - total,
              (sum_before, sum_after))
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
        shutil.rmtree(data, ignore_errors=True)

    print(f"\n{checks[0] - len(fails)}/{checks[0]} financial checks passed")
    if fails:
        print("\nfailures:")
        for f in fails[:25]:
            print(" -", f)
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
