"""Direct thermal printing end to end on the demo server (:8001) with a fake network printer (TCP):

  admin   : printers section in Settings (add / save / test page)
  cashier : bill from the POS → ESC/POS raster reaches the printer; decoded to shots/print_bill.png for a visual check
  failure : printer off → warning + fallback to the browser print dialog, no error
Restores the printer list at the end.
"""
import socket
import sys
import threading
import time

import httpx
from PIL import Image
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
ok, fail = [], []
FA = str.maketrans("0123456789,", "۰۱۲۳۴۵۶۷۸۹٬")


def check(name, cond, info=""):
    (ok if cond else fail).append(name)
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


class FakePrinter:
    def __init__(self):
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        self.jobs = []
        threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        while True:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            buf = b""
            with c:
                while chunk := c.recv(65536):
                    buf += chunk
            self.jobs.append(buf)


def decode(job):
    """ESC/POS GS v 0 bands → PIL image."""
    rows, width, i = [], None, 0
    while (i := job.find(b"\x1dv0", i)) >= 0:
        xl, xh, yl, yh = job[i + 4], job[i + 5], job[i + 6], job[i + 7]
        row, h = xl + xh * 256, yl + yh * 256
        width = row * 8
        data = job[i + 8:i + 8 + row * h]
        rows += [data[r * row:(r + 1) * row] for r in range(h)]
        i += 8 + row * h
    img = Image.new("1", (width, len(rows)), 1)
    px = img.load()
    for y, r in enumerate(rows):
        for x in range(width):
            if r[x >> 3] & (0x80 >> (x & 7)):
                px[x, y] = 0
    return img


login = lambda u, p: httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]  # noqa: E731
admin_tok, cash_tok, mgr_tok = login("admin", "admin123"), login("reza", "cashier123"), login("sara", "manager123")
H = lambda t: {"Authorization": f"Bearer {t}"}  # noqa: E731
saved = httpx.get(B + "/api/system/printers", headers=H(admin_tok)).json()
fp = FakePrinter()
full = httpx.get(B + "/api/menu/full", headers=H(admin_tok)).json()
items = [i for i in full["items"] if i["is_available"] and not i["code"].startswith("__") and not i["modifier_group_ids"]][:3]
o = httpx.post(B + "/api/orders", headers=H(cash_tok), json={"type": "takeaway", "customer_name": "مشتری تست چاپ",
                                                              "lines": [{"menu_item_id": i["id"], "qty": k + 1} for k, i in enumerate(items)]}).json()
errors = []
try:
    with sync_playwright() as pw:
        br = pw.chromium.launch()

        def page(tok):
            ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}');" + " const ap = Node.prototype.appendChild; Node.prototype.appendChild = function (n) {"
                             " if (n && n.tagName === 'IFRAME') window.__printed = (window.__printed || 0) + 1; return ap.call(this, n) }")
            pg = ctx.new_page()
            pg.on("console", lambda m: m.type == "error" and "status of 4" not in m.text and "status of 502" not in m.text and errors.append(m.text[:200]))
            pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
            pg.on("response", lambda r: r.status >= 500 and r.status != 502 and errors.append(f"http {r.status} {r.url}"))
            return ctx, pg

        # admin: configure from the Settings page
        ctx, pg = page(admin_tok)
        httpx.put(B + "/api/system/printers", headers=H(admin_tok), json={"printers": []})
        pg.goto(B + "/admin/settings", wait_until="networkidle")
        pg.get_by_role("tab", name="فیش و چاپ").click()
        pg.get_by_role("button", name="افزودن چاپگر").click()
        pg.locator(".pr-host").fill("127.0.0.1")
        pg.locator(".pr-port input").fill(str(fp.port))
        pg.locator(".pr-save").click()
        pg.wait_for_timeout(800)
        cfg = httpx.get(B + "/api/system/printers", headers=H(admin_tok)).json()
        check("printer saved from Settings", len(cfg) == 1 and cfg[0]["port"] == fp.port and cfg[0]["receipt"], cfg)
        pg.locator(".printers button:has(.anticon-printer)").first.click()
        pg.wait_for_timeout(800)
        check("test page reached the printer", len(fp.jobs) == 1 and b"printer test OK" in fp.jobs[0])
        pg.screenshot(path="shots/print_settings.png")
        ctx.close()

        # cashier: bill from the POS → raster
        ctx, pg = page(cash_tok)
        pg.goto(B + "/pos", wait_until="networkidle")
        pg.locator(".ob-card", has_text=f"#{o['number']:,}".translate(FA)).filter(has_text="مشتری تست چاپ").first.click()
        pg.wait_for_timeout(600)
        pg.get_by_role("button", name="پیش‌فاکتور").click()
        for _ in range(50):
            if len(fp.jobs) >= 2:
                break
            time.sleep(0.1)
        check("bill printed directly (no dialog)", len(fp.jobs) == 2 and not pg.evaluate("window.__printed || 0"))
        if len(fp.jobs) >= 2:
            img = decode(fp.jobs[1])
            img.save("shots/print_bill.png")
            black = sum(1 for p in img.get_flattened_data() if p == 0) / (img.width * img.height)
            check("raster 576 px wide, sensible length & ink", img.width == 576 and 500 < img.height < 3000 and 0.02 < black < 0.4, (img.size, round(black, 3)))
            check("ends with paper cut", fp.jobs[1].endswith(b"\x1dVB\x00"))

        # printer off → warning + browser dialog
        httpx.put(B + "/api/system/printers", headers=H(admin_tok), json={"printers": [{**cfg[0], "port": 1}]})
        pg.reload(wait_until="networkidle")
        pg.locator(".ob-card", has_text=f"#{o['number']:,}".translate(FA)).filter(has_text="مشتری تست چاپ").first.click()
        pg.wait_for_timeout(600)
        pg.get_by_role("button", name="پیش‌فاکتور").click()
        pg.wait_for_timeout(2500)
        check("unreachable printer → warning shown", pg.locator(".ant-message", has_text="در دسترس نیست").count() >= 1)
        check("…and falls back to the browser print dialog", pg.evaluate("window.__printed || 0") == 1)
        pg.screenshot(path="shots/print_fallback.png")
        ctx.close()
        br.close()
finally:
    httpx.put(B + "/api/system/printers", headers=H(admin_tok), json={"printers": saved})
    httpx.post(f"{B}/api/orders/{o['id']}/cancel", headers=H(mgr_tok), json={"reason": "پایان تست چاپ"})
check("no console/page errors or 5xx", not errors, errors[:5])
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
