"""Round 9 visual check: pages in any skin × mode (device override via localStorage).
usage: python r9_theme_shots.py <tag> <skin:mode,...> <path,...> [width]
   e.g. python r9_theme_shots.py t1 classic:0,classic:1,latte:0 admin/dashboard,admin/settings?tab=theme,pos"""
import json, sys, urllib.request
from playwright.sync_api import sync_playwright
B = "http://localhost:8001"
OUT = "/home/user/qa/audit/r9/"
tag, combos, paths = sys.argv[1], sys.argv[2].split(","), sys.argv[3].split(",")
width = int(sys.argv[4]) if len(sys.argv) > 4 else 1440
tok = json.load(urllib.request.urlopen(urllib.request.Request(B + "/api/staff/auth/login", data=json.dumps({"username": "admin", "password": "admin123"}).encode(), headers={"content-type": "application/json"})))["token"]
errs = []
with sync_playwright() as p:
    b = p.chromium.launch()
    for combo in combos:
        skin, mode = combo.split(":")
        ctx = b.new_context(viewport={"width": width, "height": 900})
        pg = ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: m.type == "error" and "403" not in m.text and errs.append(m.text[:200]))
        pg.goto(B + "/login")
        pg.evaluate(f"localStorage.setItem('cafe_dark', '{mode}'); localStorage.setItem('cafe_skin', '{skin}'); localStorage.setItem('cafe_token', '{tok}')")
        for path in paths:
            pg.goto(B + "/" + path, wait_until="networkidle"); pg.wait_for_timeout(1200)
            name = path.replace("/", "-").replace("?", "_").replace("=", "-")
            pg.screenshot(path=f"{OUT}{tag}_{name}_{skin}{mode}.png")
        ctx.close()
    b.close()
print("errors:", errs[:10])
