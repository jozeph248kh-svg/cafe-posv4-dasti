"""
N-06 in a real browser: a queued "add these items to my bill" must never land on another bill.

Scenario (exactly the one the reviewer described):
  1. cashier opens table T and sends item A  → order #1 exists on the table
  2. the network drops for "POST /orders/{id}/lines" (route aborted in the browser)
  3. the cashier adds item B                  → it goes to the device's offline queue
  4. meanwhile, from another device: order #1 is paid and closed, and the *next* customer
     opens a new order #2 on the same table
  5. the network comes back → the queue is flushed

Before the fix the queue posted the items with `merge_if_busy: true`, so item B silently landed on
order #2 — i.e. on another customer's bill. Now the replay asks for a NEW order; the server refuses
while the table is occupied (`table_busy`), the entry stays in the queue with a visible error, and
after the table is freed a retry creates a fresh order that does contain item B.

    python qa/e2e_offline_stale_bill.py        # own data dir, own server on :8077
"""
import os
import subprocess
import sys
import tempfile
import time

import httpx
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8077"))
BASE = f"http://127.0.0.1:{PORT}"
FA = {str(i): d for i, d in enumerate("۰۱۲۳۴۵۶۷۸۹")}
results = []


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def start_server(env):
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)],
                            cwd=BACKEND, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(160):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return proc
        except Exception:
            pass
        time.sleep(0.25)
    proc.kill()
    raise SystemExit("server did not start")


def main():
    data = tempfile.mkdtemp(prefix="cafe-e2e-offline-")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = start_server(env)
    shots = os.path.join(ROOT, "qa", "shots")
    os.makedirs(shots, exist_ok=True)
    try:
        tok = httpx.post(BASE + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}).json()["token"]
        H = {"Authorization": "Bearer " + tok}
        mtok = httpx.post(BASE + "/api/staff/auth/login", json={"username": "sara", "password": "manager123"}).json()["token"]
        M = {"Authorization": "Bearer " + mtok}
        full = httpx.get(BASE + "/api/menu/full", headers=H).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        items = [i for i in full["items"]
                 if i["is_active"] and i["is_available"] and not (i["code"] or "").startswith("__")
                 and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"])]
        item_a, item_b = items[0], items[1]
        httpx.post(BASE + "/api/shifts/open", headers=H, json={"opening_cash": 0})
        table = next(t for a in httpx.get(BASE + "/api/orders/floor", headers=H).json() for t in a["tables"] if t["status"] == "free")

        with sync_playwright() as p:
            browser = p.chromium.launch()
            ctx = browser.new_context(viewport={"width": 1400, "height": 900}, locale="fa-IR")
            page = ctx.new_page()
            errors, blocked = [], {"lines": True}
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

            def route(r):
                # the network is down for "add items to an existing order" (the browser reports a failed request)
                if blocked["lines"] and r.request.method == "POST" and "/lines" in r.request.url:
                    r.abort("failed")
                else:
                    r.continue_()
            page.route("**/api/orders/**", route)

            page.goto(BASE + "/login", wait_until="networkidle")
            page.wait_for_timeout(600)
            for d in "3333":
                page.locator(".pin-key", has_text=FA[str(int(d))]).first.click()
            page.wait_for_timeout(1200)
            page.goto(BASE + "/pos", wait_until="networkidle")
            page.wait_for_timeout(1000)
            page.locator(".table-card", has_text=table["name"]).first.click()
            page.wait_for_timeout(500)
            o1 = httpx.post(BASE + "/api/orders", headers=H,
                            json={"type": "dine_in", "table_id": table["id"], "send": False,
                                  "lines": [{"menu_item_id": item_a["id"], "qty": 1}]})
            check("order #1 exists on the table", o1.status_code == 201, o1.text[:200])
            order1 = o1.json()
            # the POS must be showing that table's order for the next taps
            page.goto(BASE + "/pos", wait_until="networkidle")
            page.wait_for_timeout(800)
            page.locator(".table-card", has_text=table["name"]).first.click()
            page.wait_for_timeout(800)

            # ---- network down for /lines, cashier adds item B → queued
            page.locator(".item-card", has_text=item_b["name"]).first.click()
            page.wait_for_timeout(700)
            modal = page.locator(".ant-modal")
            if modal.count():
                add = modal.locator("button", has_text="افزودن").first
                if add.count():
                    add.click()
                    page.wait_for_timeout(500)
            sendbtn = page.locator(".btn-send")
            if sendbtn.count() and not sendbtn.first.is_disabled():
                sendbtn.first.click()
            else:
                page.get_by_text("ذخیره بدون ارسال").first.click()
            page.wait_for_timeout(1800)
            queued = page.evaluate("JSON.parse(localStorage.getItem('cafe_outbox')||'[]')")
            check("the offline queue holds the items", len(queued) == 1 and queued[0]["kind"] == "lines",
                  [(q.get("kind"), q.get("order_id")) for q in queued])
            page.screenshot(path=os.path.join(shots, "n06_queued.png"))

            # ---- another device: pay order #1, then the next customer opens order #2 on the same table
            pay = httpx.post(f"{BASE}/api/orders/{order1['id']}/payments", headers=H,
                             json={"payments": [{"method": "cash", "amount": order1["total"]}]})
            check("order #1 was paid and closed meanwhile", pay.status_code == 200 and pay.json()["status"] == "closed",
                  pay.text[:200])
            o2 = httpx.post(BASE + "/api/orders", headers=H,
                            json={"type": "dine_in", "table_id": table["id"], "lines": [{"menu_item_id": item_a["id"], "qty": 1}]})
            check("a new order #2 is opened on the same table", o2.status_code == 201, o2.text[:200])
            order2 = o2.json()

            # ---- network is back
            blocked["lines"] = False
            page.evaluate("window.dispatchEvent(new Event('online'))")
            page.wait_for_timeout(3000)

            o2_now = httpx.get(f"{BASE}/api/orders/{order2['id']}", headers=H).json()
            leaked = [l for l in o2_now["lines"] if l["menu_item_id"] == item_b["id"] and l["status"] != "void"]
            check("the queued item did NOT land on the other customer's bill (N-06)", not leaked,
                  [(l["menu_item_id"], l["qty"]) for l in o2_now["lines"]])
            left = page.evaluate("JSON.parse(localStorage.getItem('cafe_outbox')||'[]')")
            check("the entry stays in the queue with a visible error", len(left) == 1 and bool(left[0].get("error")),
                  left)
            page.screenshot(path=os.path.join(shots, "n06_refused.png"))

            # ---- the table is freed (order #2 cancelled) → the cashier retries from the badge
            httpx.post(f"{BASE}/api/orders/{order2['id']}/cancel", headers=M, json={"reason": "پایان تست N-06"})
            page.locator(".outbox-tag").click()
            page.wait_for_timeout(500)
            retry = page.locator(".ant-popover .ant-btn").first
            if retry.count():
                retry.click()
            page.wait_for_timeout(2500)
            left = page.evaluate("JSON.parse(localStorage.getItem('cafe_outbox')||'[]')")
            check("after freeing the table the retry empties the queue", left == [], left)
            actives = httpx.get(BASE + "/api/orders/active", headers=H).json()
            created = [o for o in actives if any(l["menu_item_id"] == item_b["id"] for l in o["lines"])]
            check("the items became their own order on that table", len(created) == 1 and created[0]["id"] != order2["id"],
                  [(o["id"], [l["name"] for l in o["lines"]]) for o in actives])
            for o in actives:                        # leave no open orders behind
                httpx.post(f"{BASE}/api/orders/{o['id']}/cancel", headers=M, json={"reason": "پایان تست N-06"})

            real_errors = [e for e in errors if "Failed to load resource" not in e and "net::ERR_FAILED" not in e]
            check("no unexpected page/console errors", not real_errors, real_errors[:3])
            browser.close()
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=10)
        except Exception:
            srv.kill()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
