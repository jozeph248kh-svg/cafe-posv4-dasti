"""
Browser check of the 100 %% discount bug: after a full comp the payment dialog used to be a dead end
(its button disabled, the bill never closable). Now the dialog closes the bill with no payment row.

    python qa/e2e_comped_bill.py        # own data dir, own server on :8092
"""
import os, subprocess, sys, tempfile, time
import httpx
from playwright.sync_api import sync_playwright
ROOT="/home/user/work/cafe-pos"; PORT=8092; BASE=f"http://127.0.0.1:{PORT}"
data=tempfile.mkdtemp(prefix="comp-e2e-")
env={**{k:v for k,v in os.environ.items() if not k.startswith("CAFE_")}, "CAFE_DATA_DIR":data,"CAFE_PORT":str(PORT),
     "CAFE_SAMPLE_USERS":"true","CAFE_DEMO_DATA":"true","CAFE_FORCE_PASSWORD_CHANGE":"false","CAFE_BACKGROUND_JOBS":"false"}
srv=subprocess.Popen([sys.executable,"-m","app.serve","--port",str(PORT)],cwd=ROOT+"/backend",env=env,
                     stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
for _ in range(200):
    try:
        if httpx.get(BASE+"/api/health",timeout=1).status_code==200: break
    except Exception: time.sleep(0.25)
ok=[]
def check(n,c,e=""):
    ok.append(bool(c)); print(("PASS " if c else "FAIL ")+n+(f"  → {e}" if not c else ""))
try:
    lg=lambda u,p:{"Authorization":"Bearer "+httpx.post(BASE+"/api/staff/auth/login",json={"username":u,"password":p}).json()["token"]}
    M,C=lg("sara","manager123"),lg("reza","cashier123")
    httpx.post(BASE+"/api/shifts/open",headers=C,json={"opening_cash":0})
    menu=httpx.get(BASE+"/api/menu/full",headers=M).json()
    it=next(i for i in menu["items"] if i["is_active"] and i["is_available"] and not i["modifier_group_ids"] and not (i["code"] or "").startswith("__"))
    floor=httpx.get(BASE+"/api/orders/floor",headers=C).json()
    table=next(t for a in floor for t in a["tables"] if t["status"]=="free")
    o=httpx.post(BASE+"/api/orders",headers=C,json={"type":"dine_in","table_id":table["id"],"lines":[{"menu_item_id":it["id"],"qty":2}]}).json()
    o=httpx.post(f"{BASE}/api/orders/{o['id']}/discount",headers=M,json={"type":"percent","value":100,"reason":"مهمان مدیر"}).json()
    check("the order is fully discounted (total 0, still open)", o["total"]==0 and o["status"]=="open")
    with sync_playwright() as p:
        br=p.chromium.launch(); ctx=br.new_context(viewport={"width":1400,"height":900},locale="fa-IR")
        ctx.add_init_script(f"localStorage.setItem('cafe_token','{C['Authorization'].split()[1]}')")
        page=ctx.new_page(); errs=[]
        page.on("pageerror",lambda e:errs.append(str(e)))
        page.on("console",lambda m: errs.append(m.text) if m.type=="error" else None)
        page.goto(BASE+"/pos",wait_until="networkidle"); page.wait_for_timeout(1500)
        page.locator(".table-card", has_text=table["name"]).first.click(); page.wait_for_timeout(1200)
        pay=page.locator("button", has_text="پرداخت")
        check("the POS offers the payment button on the comped table", pay.count()>0)
        pay.first.click(); page.wait_for_timeout(1500)
        print("   dialog text:", page.locator(".ant-modal").inner_text()[:160].replace("\n"," / "))
        btn=page.locator(".ant-modal-footer button.ant-btn-primary")
        check("the dialog's main button exists", btn.count()==1)
        label=btn.first.inner_text()
        check("its label says the bill is closed without payment", "بستن سفارش" in label, label)
        check("the button is enabled (was disabled before the fix)", btn.first.is_enabled(), label)
        btn.first.click(); page.wait_for_timeout(2000)
        after=httpx.get(f"{BASE}/api/orders/{o['id']}",headers=C).json()
        check("the order is closed", after["status"]=="closed", after["status"])
        check("no payment row was invented", after["payments"]==[] and after["paid_amount"]==0, after["payments"])
        check("the table is free again", all(t["status"]=="free" for a in httpx.get(BASE+"/api/orders/floor",headers=C).json() for t in a["tables"] if t["id"]==table["id"]))
        check("no page/console errors", not [e for e in errs if "Failed to load" not in e], errs[:2])
        br.close()
finally:
    srv.terminate()
    try: srv.wait(15)
    except Exception: srv.kill()
print(f"\n{sum(ok)}/{len(ok)} checks passed")
