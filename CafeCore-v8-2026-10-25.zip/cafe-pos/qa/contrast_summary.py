"""Group contrast_scan.py --json output by pattern: python contrast_summary.py out.json [top=40]"""
import collections, json, sys
r = json.load(open(sys.argv[1])); top = int(sys.argv[2]) if len(sys.argv) > 2 else 40
agg, ex = collections.Counter(), {}
for s in r:
    for x in s["items"]:
        k = (x["sev"], s["skin"], "dark" if s["mode"] == "1" else "light", x["cls"][:32], x["parent"][:28], x["fg"], x["bg"])
        agg[k] += 1; ex.setdefault(k, (s["where"], x["txt"], x["k"]))
print("FAIL:", sum(n for k, n in agg.items() if k[0] == "FAIL"), " AA:", sum(n for k, n in agg.items() if k[0] == "AA"), " patterns:", len(agg))
for k, n in sorted(agg.items(), key=lambda kv: (kv[0][0] != "FAIL", -kv[1]))[:top]: print(n, k, ex[k])
