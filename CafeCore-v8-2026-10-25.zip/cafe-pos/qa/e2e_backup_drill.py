"""End-to-end proof that a real server's data can come back — and that a killed backup does not break the shop.

Everything here runs against a REAL server process on a throw-away data folder (CAFE_DATA_DIR under /tmp), with
demo data, on SQLite and (if a scratch PostgreSQL is reachable) on PostgreSQL. The live database is never used.

What it proves:
  1. a backup taken through the API is verified and carries a manifest of the money in it
  2. the restore drill restores it into an isolated scratch target and every key figure matches
  3. `kill -9` in the middle of a backup leaves no usable-looking half file, and the next backup still works
     (stale lock + `.tmp`/`.part` leftovers are cleaned up)
  4. a corrupted newest backup is reported as a failed drill, not silently accepted
  5. the status endpoint answers with the last success / stale flag / recent errors

Run:  python qa/e2e_backup_drill.py [--pg "postgresql+psycopg://postgres@/cafe_bk?host=/tmp&port=5433"]
"""
import argparse
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
ok = fail = 0


def check(name: str, cond: bool, detail="") -> None:
    global ok, fail
    if cond:
        ok += 1
        print(f"PASS {name}")
    else:
        fail += 1
        print(f"FAIL {name} {str(detail)[:400]}")


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def start(data_dir: Path, port: int, db_url: str | None = None) -> subprocess.Popen:
    env = {k: v for k, v in os.environ.items() if not k.startswith("CAFE_")}
    env.update({"CAFE_DATA_DIR": str(data_dir), "CAFE_PORT": str(port), "CAFE_DEMO_DATA": "true",
                "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"})
    if db_url:
        env["CAFE_DATABASE_URL"] = db_url
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(port)], cwd=ROOT / "backend", env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for _ in range(120):
        try:
            if httpx.get(f"http://127.0.0.1:{port}/health", timeout=2).status_code == 200:
                return proc
        except httpx.HTTPError:
            time.sleep(0.5)
    proc.kill()
    raise SystemExit("server did not start:\n" + (proc.stdout.read() if proc.stdout else ""))


def login(base: str, user="admin", pwd="admin123") -> httpx.Client:
    c = httpx.Client(base_url=base, timeout=180)
    r = c.post("/api/staff/auth/login", json={"username": user, "password": pwd})
    if r.status_code == 200 and r.json().get("must_change_password"):
        c.headers["Authorization"] = "Bearer " + r.json()["token"]
        c.post("/api/staff/auth/password", json={"current_password": pwd, "new_password": "Qa!Demo1234"})
        r = c.post("/api/staff/auth/login", json={"username": user, "password": "Qa!Demo1234"})
    c.headers["Authorization"] = "Bearer " + r.json()["token"]
    return c


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pg", default=os.environ.get("CAFE_BACKUP_PG_URL"),
                    help="scratch PostgreSQL URL (its schema is wiped)")
    a = ap.parse_args()
    modes = [("sqlite", None)] + ([("postgresql", a.pg)] if a.pg else [])
    for label, url in modes:
        print(f"\n===== {label} =====")
        data = Path(f"/tmp/cafe-e2e-backup-{label}")
        shutil.rmtree(data, ignore_errors=True)
        port = free_port()
        base = f"http://127.0.0.1:{port}"
        proc = start(data, port, url)
        try:
            c = login(base)
            # the server takes a startup snapshot before serving (see main.lifespan) — so a fresh install is already
            # protected, and the status page must say so instead of "stale"
            st0 = c.get("/api/system/backups/status").json()
            check(f"[{label}] startup snapshot exists and is not stale",
                  st0["count"] >= 1 and st0["stale"] is False and st0["newest"] is not None, st0.get("newest"))
            check(f"[{label}] no drill has run yet", st0["drill_state"] == "never")

            r = c.post("/api/system/backups")
            check(f"[{label}] backup created", r.status_code == 200, r.text)
            name = r.json()["name"]
            backups_dir = data / "backups"
            check(f"[{label}] backup file + manifest exist",
                  (backups_dir / name).is_file() and (backups_dir / f"{name}.json").is_file())
            manifest = json.loads((backups_dir / f"{name}.json").read_text(encoding="utf-8"))
            check(f"[{label}] manifest holds money figures", manifest["figures"]["orders.count"] > 0
                  and manifest["figures"]["payments.sum"] > 0, manifest["figures"])

            r = c.post("/api/system/backups/drill")
            body = r.json()
            check(f"[{label}] drill restores into an isolated target", r.status_code == 200 and body["ok"], body)
            check(f"[{label}] drill compares the manifest (no differences)", body["differences"] == [], body.get("differences"))
            same = all(body["figures"][k] == manifest["figures"][k] for k in manifest["figures"])
            check(f"[{label}] every figure matches the manifest", same)
            print(f"     restored into: {body['restored_into']}  ({body['duration_ms']} ms)")
            print("     figures: " + ", ".join(f"{k}={v}" for k, v in list(body["figures"].items())[:6]))

            # ---------- killed mid-backup ----------
            before = {p.name for p in backups_dir.glob("cafe-*")}
            proc.send_signal(signal.SIGKILL)                 # abrupt stop, exactly like a power cut
            proc.wait(timeout=20)
            leftovers = [p.name for p in backups_dir.glob("*.tmp*")] + [p.name for p in backups_dir.glob("*.part")]
            proc = start(data, port, url)
            c = login(base)
            r = c.post("/api/system/backups")
            check(f"[{label}] backup works again after a killed process", r.status_code == 200, r.text)
            after = {p.name for p in backups_dir.glob("cafe-*")}
            check(f"[{label}] no half-written file was kept", not [n for n in after - before if ".tmp" in n or ".part" in n],
                  leftovers)

            # ---------- corrupted newest backup ----------
            newest = sorted(backups_dir.glob("cafe-*"))[-1]
            newest.write_bytes(b"broken")
            r = c.post("/api/system/backups/drill")
            check(f"[{label}] a corrupted backup fails the drill loudly", r.status_code == 400, r.text[:200])
            st = c.get("/api/system/backups/status").json()
            check(f"[{label}] status shows the failure", st["drill_state"] == "failed" and st["errors"], st.get("errors"))
            check(f"[{label}] last successful backup is still listed", st["last_successful_backup"] is not None)

            # ---------- stale warning ----------
            for p in backups_dir.glob("cafe-*"):
                p.unlink()
            st = c.get("/api/system/backups/status").json()
            check(f"[{label}] no backup at all ⇒ stale warning", st["stale"] is True and st["newest"] is None)
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                proc.kill()
    print(f"\n{ok}/{ok + fail} checks passed")
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
