import sqlite3, random, json, datetime as dt
random.seed(7)
c = sqlite3.connect('/tmp/perf/cafe.db')
items = c.execute("select id, name, price, station_id from menu_items where code not like '\\_\\_%' escape '\\' and is_active=1").fetchall()
users = [r[0] for r in c.execute("select id from users")]
tables = [r[0] for r in c.execute("select id from dining_tables")]
oid = c.execute("select max(id) from orders").fetchone()[0]
start = dt.date.today() - dt.timedelta(days=365)
O, L, P = [], [], []
lid = c.execute("select max(id) from order_lines").fetchone()[0]
for day in range(365):
    d = start + dt.timedelta(days=day)
    for n in range(1, 138):
        oid += 1
        t = random.choice(["dine_in"] * 6 + ["takeaway"] * 3 + ["delivery"])
        created = dt.datetime.combine(d, dt.time(random.randint(8, 23), random.randint(0, 59)))
        sub = 0
        for _ in range(random.randint(1, 5)):
            it = random.choice(items); q = random.randint(1, 3); lid += 1
            L.append((lid, oid, it[0], it[3], it[1], it[2], it[2], q, "[]", "served", created.isoformat(" "), created.isoformat(" ")))
            sub += it[2] * q
        status = "cancelled" if random.random() < 0.02 else "closed"
        tax = round(sub * 0.09); total = sub + tax
        O.append((oid, n, d.isoformat(), t, status, "pos", random.choice(tables) if t == "dine_in" else None, 2, random.choice(users),
                  random.choice(users), sub, 0, 0, tax, 0, total, total if status == "closed" else 0, created.isoformat(" "),
                  (created + dt.timedelta(minutes=40)).isoformat(" ") if status == "closed" else None))
        if status == "closed":
            P.append((oid, random.choice(["cash", "card", "card", "card"]), total, 0, 0, random.choice(users), created.isoformat(" ")))
c.executemany("insert into orders (id, number, business_date, type, status, source, table_id, guests, waiter_id, created_by, subtotal, discount_value, discount_amount, tax_amount, rounding, total, paid_amount, created_at, closed_at, service_amount) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)", O)
c.executemany("insert into order_lines (id, order_id, menu_item_id, station_id, name, base_price, unit_price, qty, modifiers, status, created_at, sent_at) values (?,?,?,?,?,?,?,?,?,?,?,?)", L)
c.executemany("insert into payments (order_id, method, amount, change, is_refund, created_by, created_at) values (?,?,?,?,?,?,?)", P)
c.commit()
print({t: c.execute(f"select count(*) from {t}").fetchone()[0] for t in ("orders", "order_lines", "payments")})
import os; print("db MB", round(os.path.getsize('/tmp/perf/cafe.db') / 1e6, 1))
