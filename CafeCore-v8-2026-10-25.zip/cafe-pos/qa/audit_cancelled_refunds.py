"""Read-only report: cancelled bills that carry refunds (and other money that a cancelled bill should not have).

Why this exists
---------------
The API refuses to cancel a bill that has payments, and refuses to refund a bill that is not closed, so this
combination cannot be produced through the application. It can still exist in an old or imported database — and it is
exactly the shape that used to distort reports (a refund reversing revenue of a bill that never counted as revenue;
see the round-14 audit).

What it does
------------
Nothing but SELECTs. It opens the database **read-only** (SQLite: `mode=ro`; PostgreSQL: a read-only transaction) and
prints, for the whole database and per bill:

  * cancelled bills that still have refund payments      → count, total refunded, per-bill detail
  * cancelled bills that still have normal payments      → count, total paid
  * cancelled bills whose `paid_amount` is not zero
  * refund lines (goods returned) hanging off cancelled bills
  * refunds that are attached to a bill which no longer exists (orphans, defensive)
  * totals by business day, so the size of a possible distortion in a report is visible

It never writes: no update, no delete, no migration. Exit code 1 when something suspicious exists, 0 when clean,
so it can be used in a check script.

Usage
-----
    python qa/audit_cancelled_refunds.py                       # the app's own database (data/cafe.db)
    python qa/audit_cancelled_refunds.py --db /path/cafe.db
    python qa/audit_cancelled_refunds.py --url postgresql+psycopg://user@/cafe?host=/tmp&port=5433
    python qa/audit_cancelled_refunds.py --json                # machine-readable
"""
import argparse
import json
import os
import sqlite3
import sys
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
sys.path.insert(0, BACKEND)

FINDINGS: dict = {}


def _rows_sqlite(path: str):
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)          # read-only: a typo here cannot damage data
    try:
        con.row_factory = sqlite3.Row

        def q(sql, *args):
            return [dict(r) for r in con.execute(sql, args).fetchall()]

        yield q
    finally:
        con.close()


def _rows_pg(url: str):
    from sqlalchemy import create_engine, text

    engine = create_engine(url)
    with engine.connect() as c:
        c.execute(text("SET TRANSACTION READ ONLY"))

        def q(sql, *args):
            res = c.execute(text(sql), dict(zip([f"p{i}" for i in range(len(args))], args)))
            return [dict(r._mapping) for r in res]
        yield q


def _norm(value):
    """PostgreSQL returns Decimal for SUM() — print money as a plain integer (SQLite already does)."""
    try:
        import decimal
        if isinstance(value, decimal.Decimal):
            return int(value) if value == value.to_integral_value() else float(value)
    except Exception:                     # noqa: BLE001
        pass
    if isinstance(value, str) and value.lstrip("-").isdigit():
        return int(value)
    return value


def _normalise(rows: list[dict]) -> list[dict]:
    return [{k: _norm(v) for k, v in row.items()} for row in rows]


def collect(q) -> dict:
    """All the suspicious shapes, in one place. Every query is a SELECT.

    Boolean columns are written as `p.is_refund` / `NOT p.is_refund` instead of `= 1` / `= 0`, because PostgreSQL
    rejects `boolean = integer` (SQLite accepts both).
    """
    refunds_on_cancelled = q("""
        SELECT o.id, o.number, o.business_date, o.status, o.total, o.paid_amount, o.cancel_reason,
               SUM(p.amount) AS refund_sum, COUNT(p.id) AS refund_count
        FROM payments p JOIN orders o ON o.id = p.order_id
        WHERE p.is_refund AND o.status = 'cancelled'
        GROUP BY o.id ORDER BY o.business_date, o.id""")
    payments_on_cancelled = q("""
        SELECT o.id, o.number, o.business_date, o.total, o.paid_amount, SUM(p.amount) AS paid_sum, COUNT(p.id) AS n
        FROM payments p JOIN orders o ON o.id = p.order_id
        WHERE NOT p.is_refund AND o.status = 'cancelled'
        GROUP BY o.id ORDER BY o.business_date, o.id""")
    paid_amount_on_cancelled = q("""
        SELECT id, number, business_date, total, paid_amount FROM orders
        WHERE status = 'cancelled' AND COALESCE(paid_amount, 0) <> 0
        ORDER BY business_date, id""")
    returns_on_cancelled = q("""
        SELECT r.order_id, o.number, o.business_date, COUNT(r.id) AS n, COALESCE(SUM(r.qty), 0) AS qty
        FROM order_refund_lines r JOIN orders o ON o.id = r.order_id
        WHERE o.status = 'cancelled'
        GROUP BY r.order_id, o.number, o.business_date ORDER BY o.business_date, r.order_id""")
    orphan_refunds = q("""
        SELECT p.id, p.order_id, p.amount, p.created_at FROM payments p
        LEFT JOIN orders o ON o.id = p.order_id
        WHERE p.is_refund AND o.id IS NULL ORDER BY p.id""")
    by_day = q("""
        SELECT o.business_date, COUNT(DISTINCT o.id) AS bills, COALESCE(SUM(p.amount), 0) AS refund_sum
        FROM payments p JOIN orders o ON o.id = p.order_id
        WHERE p.is_refund AND o.status = 'cancelled'
        GROUP BY o.business_date ORDER BY o.business_date""")
    totals = q("""
        SELECT (SELECT COUNT(*) FROM orders) AS orders,
               (SELECT COUNT(*) FROM orders WHERE status = 'cancelled') AS cancelled_orders,
               (SELECT COUNT(*) FROM payments) AS payments,
               (SELECT COUNT(*) FROM payments WHERE is_refund) AS refund_payments,
               (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE is_refund) AS refund_sum""")[0]
    return {key: (_normalise(value) if isinstance(value, list) else
                  ({k: _norm(v) for k, v in value.items()} if isinstance(value, dict) else value))
            for key, value in {
        "totals": totals, "refunds_on_cancelled": refunds_on_cancelled,
        "payments_on_cancelled": payments_on_cancelled,
        "paid_amount_on_cancelled": paid_amount_on_cancelled,
        "returns_on_cancelled": returns_on_cancelled, "orphan_refunds": orphan_refunds,
        "by_day": by_day,
    }.items()}


def report(data: dict) -> int:
    t = data["totals"]
    print("=" * 78)
    print("CafeCore — read-only audit: cancelled bills carrying money")
    print("=" * 78)
    print(f"orders={t['orders']}  cancelled={t['cancelled_orders']}  payments={t['payments']}  "
          f"refund payments={t['refund_payments']}  total refunded (negative)={t['refund_sum']}")

    susp = 0
    print("\n1) cancelled bills that still carry REFUND payments")
    if not data["refunds_on_cancelled"]:
        print("   none")
    for r in data["refunds_on_cancelled"]:
        susp += 1
        print(f"   bill #{r['number']} (id {r['id']}, {r['business_date']}): {r['refund_count']} refund(s) "
              f"totalling {abs(r['refund_sum']):,} toman · total={r['total']:,} · paid={r['paid_amount']:,}"
              f" · reason={r['cancel_reason'] or '-'}")

    print("\n2) cancelled bills that still carry NORMAL payments")
    if not data["payments_on_cancelled"]:
        print("   none")
    for r in data["payments_on_cancelled"]:
        susp += 1
        print(f"   bill #{r['number']} (id {r['id']}, {r['business_date']}): {r['n']} payment(s) "
              f"totalling {r['paid_sum']:,} toman")

    print("\n3) cancelled bills whose paid_amount is not zero")
    if not data["paid_amount_on_cancelled"]:
        print("   none")
    for r in data["paid_amount_on_cancelled"]:
        susp += 1
        print(f"   bill #{r['number']} (id {r['id']}, {r['business_date']}): paid_amount={r['paid_amount']:,} "
              f"of total={r['total']:,}")

    print("\n4) goods-return events attached to cancelled bills")
    if not data["returns_on_cancelled"]:
        print("   none")
    for r in data["returns_on_cancelled"]:
        susp += 1
        print(f"   bill #{r['number']} (id {r['order_id']}, {r['business_date']}): {r['n']} return row(s), "
              f"{r['qty']} unit(s)")

    print("\n5) refund payments whose bill no longer exists")
    if not data["orphan_refunds"]:
        print("   none")
    for r in data["orphan_refunds"]:
        susp += 1
        print(f"   payment id {r['id']} → order {r['order_id']} (missing), {r['amount']:,}, at {r['created_at']}")

    if data["by_day"]:
        print("\n6) how big a distortion would be, per business day")
        for r in data["by_day"]:
            print(f"   {r['business_date']}: {r['bills']} bill(s), refunds {abs(r['refund_sum']):,} toman")

    print("\n" + "-" * 78)
    if susp:
        print(f"RESULT: {susp} suspicious row group(s) found. Reports already ignore refunds of cancelled bills "
              f"(round-14 fix); this report is for the owner to decide whether such rows should be cleaned up "
              f"by hand. Nothing was modified.")
    else:
        print("RESULT: clean — no cancelled bill carries money.")
    print("-" * 78)
    return 1 if susp else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Read-only audit of cancelled bills with payments/refunds")
    ap.add_argument("--db", help="path to a SQLite database (default: the app's data/cafe.db)")
    ap.add_argument("--url", help="SQLAlchemy URL for PostgreSQL (overrides --db)")
    ap.add_argument("--json", action="store_true", help="print JSON instead of the report")
    a = ap.parse_args(argv)

    if a.url:
        gen = _rows_pg(a.url)
        source = a.url.split("@")[-1]
    else:
        from app.core.config import get_settings

        path = a.db or str(get_settings().data_dir / "cafe.db")
        if not os.path.exists(path):
            print(f"[ERROR] database not found: {path}", file=sys.stderr)
            return 2
        gen = _rows_sqlite(path)
        source = path
    q = next(gen)
    try:
        data = collect(q)
    finally:
        gen.close()
    if a.json:
        print(json.dumps({"source": source, **data}, ensure_ascii=False, indent=1, default=str))
        return 0
    print(f"source: {source}  (read-only; nothing is written, changed or deleted)\n")
    return report(data)


if __name__ == "__main__":
    sys.exit(main())
