"""
The P&L page in a real browser with a NEGATIVE result (reported defect R2-UI-001: the summary card showed the
loss, while the «درآمد خالص» / «سود ناخالص» rows printed the same number as a positive value).

Scenario: an expensive ingredient, a cheap sale, and a big fully-refunded taxed bill → revenue and gross profit go
negative. The browser must show them in parentheses / red, the loss in the total line, and the replacement-cost
indicator as its own row.

    python qa/e2e_pnl_negative.py         # own data dir, own server on :8093
"""
import os
import subprocess
import sys
import tempfile
import time

import httpx
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
PORT = int(os.environ.get("QA_PORT", "8093"))
BASE = f"http://127.0.0.1:{PORT}"
results = []


def check(name, ok, extra=""):
    results.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def start(env):
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(PORT)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(200):
        try:
            if httpx.get(BASE + "/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            time.sleep(0.25)
    p.kill()
    raise SystemExit("server did not start")


def main():
    data = tempfile.mkdtemp(prefix="cafe-e2e-pnl-")
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(PORT), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "false", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    srv = start(env)
    shots = os.path.join(ROOT, "qa", "shots")
    os.makedirs(shots, exist_ok=True)
    try:
        def lg(u, p):
            return {"Authorization": "Bearer " + httpx.post(BASE + "/api/staff/auth/login",
                                                            json={"username": u, "password": p}).json()["token"]}
        A, C, M = lg("admin", "admin123"), lg("reza", "cashier123"), lg("sara", "manager123")
        httpx.post(BASE + "/api/shifts/open", headers=C, json={"opening_cash": 0})
        httpx.put(BASE + "/api/system/settings", headers=A, json={"tax.enabled": True, "tax.percent": 9})
        ing = httpx.post(BASE + "/api/inventory/ingredients", headers=A,
                         json={"name": "دانه گران تست", "unit": "g", "opening_stock": 1000,
                               "cost_per_unit": 200_000, "min_stock": 0}).json()
        cat = httpx.get(BASE + "/api/menu/categories", headers=A).json()[0]["id"]
        item = httpx.post(BASE + "/api/menu/items", headers=A,
                          json={"category_id": cat, "name": "قهوه زیان‌ده تست", "price": 100_000}).json()
        httpx.put(f"{BASE}/api/inventory/recipes/item/{item['id']}", headers=A,
                  json=[{"ingredient_id": ing["id"], "qty": 1}])
        o = httpx.post(BASE + "/api/orders", headers=C,
                       json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
        httpx.post(f"{BASE}/api/orders/{o['id']}/payments", headers=C,
                   json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
        pnl = httpx.get(BASE + "/api/expenses/pnl", headers=A).json()
        check("the API reports a loss (gross profit < 0)", pnl["gross_profit"] < 0, pnl["gross_profit"])
        check("replacement cost arrives as its own indicator", pnl.get("replacement_cost", 0) > 0, pnl.get("replacement_cost"))

        with sync_playwright() as p:
            br = p.chromium.launch()
            ctx = br.new_context(viewport={"width": 1500, "height": 950}, locale="fa-IR")
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{A['Authorization'].split()[1]}')")
            page = ctx.new_page()
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.goto(BASE + "/admin/finance/pnl", wait_until="networkidle")
            page.wait_for_timeout(1500)
            rows = page.locator(".pnl-row").all_inner_texts()
            text = " | ".join(" ".join(r.split()) for r in rows)
            gross_row = next((r for r in rows if "سود ناخالص" in r), "")
            # the same magnitude as the API, but in parentheses (a negative number, not a positive one)
            import re as _re
            magnitude = f"{abs(pnl['gross_profit']):,}".translate(str.maketrans("0123456789,", "۰۱۲۳۴۵۶۷۸۹٬"))
            check("the gross-profit row shows the loss in parentheses",
                  "(" in gross_row and magnitude in gross_row, gross_row)
            check("the total line says زیان", "زیان خالص" in page.locator(".pnl-total").inner_text())
            check("the replacement cost is a separate row", "بهای جایگزینی روز" in text, text[:200])
            page.screenshot(path=os.path.join(shots, "pnl_negative.png"), full_page=True)
            check("no page or console errors", not [e for e in errors if "Failed to load" not in e], errors[:3])
            br.close()
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
