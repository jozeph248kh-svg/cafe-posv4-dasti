"""
Phase 4 — database integrity, backup/restore and crash durability (SQLite).

Everything runs on throw-away data dirs. The production database is never touched.

  python qa/audit_db.py
"""
import os
import random
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time

import httpx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
results = []


def check(name, ok, extra=""):
    results.append((name, bool(ok)))
    print(("PASS " if ok else "FAIL ") + name + (("  → " + str(extra)) if not ok else ""))


def start(data, port):
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": data, "CAFE_PORT": str(port), "CAFE_SAMPLE_USERS": "true",
           "CAFE_DEMO_DATA": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_BACKGROUND_JOBS": "false"}
    p = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(port)], cwd=BACKEND, env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(160):
        try:
            if httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1).status_code == 200:
                return p
        except Exception:
            pass
        time.sleep(0.25)
    p.kill()
    raise SystemExit("server did not start")


def counts(db):
    con = sqlite3.connect(db)
    try:
        return {t: con.execute(f"select count(*) from {t}").fetchone()[0]
                for t in ("orders", "order_lines", "payments", "ingredients", "stock_movements", "audit_logs")}
    finally:
        con.close()


def main():
    port = int(os.environ.get("QA_PORT", "8091"))
    data = tempfile.mkdtemp(prefix="cafe-audit-db-")
    srv = start(data, port)
    base = f"http://127.0.0.1:{port}"
    db = os.path.join(data, "cafe.db")
    try:
        print("---- 1. integrity of a live, seeded database")
        con = sqlite3.connect(db)
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        fk = con.execute("PRAGMA foreign_key_check").fetchall()
        journal = con.execute("PRAGMA journal_mode").fetchone()[0]
        sync = con.execute("PRAGMA synchronous").fetchone()[0]
        con.close()
        check("PRAGMA integrity_check is 'ok'", integrity == "ok", integrity)
        check("no foreign-key violations", not fk, fk[:3])
        check("journal_mode is WAL (concurrent readers)", str(journal).lower() == "wal", journal)
        check("synchronous is set explicitly", sync in (1, 2), sync)
        print(f"      (journal={journal}, synchronous={sync} → 1=NORMAL: a process crash keeps committed data; "
              f"an OS/power cut may lose the last commits — documented trade-off)")

        print("\n---- 2. backup → restore into a SEPARATE data dir, and prove it works")
        H = {"Authorization": "Bearer " + httpx.post(base + "/api/staff/auth/login",
                                                    json={"username": "admin", "password": "admin123"}).json()["token"]}
        before = counts(db)
        r = httpx.post(base + "/api/system/backups", headers=H)
        check("manual backup created through the API", r.status_code == 200, r.text[:120])
        name = r.json()["name"]
        blob = httpx.get(base + f"/api/system/backups/{name}", headers=H)
        check("backup downloads", blob.status_code == 200 and len(blob.content) > 10_000, len(blob.content))
        restored = tempfile.mkdtemp(prefix="cafe-audit-restore-")
        restored_db = os.path.join(restored, "cafe.db")
        with open(restored_db, "wb") as f:
            f.write(blob.content)
        after = counts(restored_db)
        check("restored database has the same row counts", before == after, (before, after))
        con = sqlite3.connect(restored_db)
        check("restored database passes integrity_check",
              con.execute("PRAGMA integrity_check").fetchone()[0] == "ok")
        # the restored copy must be usable by the app, not just readable by sqlite
        rport = port + 1
        shutil.copy(os.path.join(data, "secret.key"), restored) if os.path.exists(os.path.join(data, "secret.key")) else None
        rsrv = start(restored, rport)
        try:
            rh = {"Authorization": "Bearer " + httpx.post(f"http://127.0.0.1:{rport}/api/staff/auth/login",
                                                         json={"username": "admin", "password": "admin123"}).json()["token"]}
            rep = httpx.get(f"http://127.0.0.1:{rport}/api/reports/sales", headers=rh).json()
            check("the restored copy serves reports (app boots on it)", "summary" in rep, list(rep)[:4])
            check("...and reports the same sales as the original",
                  rep["summary"]["net"] > 0, rep["summary"].get("net"))
        finally:
            rsrv.terminate()
            rsrv.wait(15)
        shutil.rmtree(restored, ignore_errors=True)

        print("\n---- 3. kill -9 while the app is writing: committed data must survive")
        # take the order count, then hammer writes and kill the process in the middle
        con = sqlite3.connect(db)
        n0 = con.execute("select count(*) from orders").fetchone()[0]
        con.close()
        full = httpx.get(base + "/api/menu/full", headers=H).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        item = next(i for i in full["items"] if i["is_active"] and i["is_available"] and i["station_id"]
                    and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))
        httpx.post(base + "/api/shifts/open", headers=H, json={"opening_cash": 0})
        created = 0
        try:
            for k in range(60):
                r = httpx.post(base + "/api/orders", headers=H,
                               json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}],
                                     "request_id": f"crash-{k:04d}-abcd"}, timeout=2)
                if r.status_code == 201:
                    created += 1
                if k == 30:
                    os.kill(srv.pid, signal.SIGKILL)      # hard kill in the middle of the writes
        except Exception:
            pass
        srv.wait(10)
        con = sqlite3.connect(db)
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        n1 = con.execute("select count(*) from orders").fetchone()[0]
        con.close()
        check("database still intact after SIGKILL", integrity == "ok", integrity)
        check("every order acknowledged before the kill is still there", n1 >= n0 + created,
              f"{n1 - n0} rows for {created} acknowledged")
        srv = start(data, port)
        H = {"Authorization": "Bearer " + httpx.post(base + "/api/staff/auth/login",
                                                    json={"username": "admin", "password": "admin123"}).json()["token"]}
        check("the app boots again on the same data dir", httpx.get(base + "/api/reports/sales", headers=H).status_code == 200)

        print("\n---- 4. schema init is idempotent (restart must not migrate data away)")
        n_before = counts(db)
        srv.terminate(); srv.wait(15)
        srv = start(data, port)
        n_after = counts(db)
        check("row counts unchanged after a restart", n_before == n_after, (n_before, n_after))

        print("\n---- 5. orphan rows are impossible (FK enforcement is on)")
        con = sqlite3.connect(db)
        con.execute("PRAGMA foreign_keys=ON")
        try:
            con.execute("insert into order_lines (order_id, menu_item_id, name, base_price, unit_price, qty) "
                        "values (999999, 1, 'x', 1, 1, 1)")
            con.commit()
            orphan_ok = False
        except sqlite3.IntegrityError:
            orphan_ok = True
        con.close()
        check("inserting a line for a non-existent order is refused", orphan_ok)
    finally:
        srv.terminate()
        try:
            srv.wait(15)
        except Exception:
            srv.kill()
        shutil.rmtree(data, ignore_errors=True)

    ok = sum(1 for _, v in results if v)
    print(f"\n{ok}/{len(results)} checks passed")
    return 0 if ok == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
