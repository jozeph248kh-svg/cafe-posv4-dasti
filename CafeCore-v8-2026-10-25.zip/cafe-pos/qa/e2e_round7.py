"""Browser test of round 7 — blind cash count + «شیفت من» (end-of-shift report) on the demo server (:8001):

  cashier : clocks in, opens the main register, sells (cash + card). Header clock → «شیفت من»; cash is hidden while the
            drawer is open; Shifts page is blind; hands the drawer over with a blind count (difference shown only after
            saving, prefilled into the note); submits the report and clocks out in one click
  manager : Shifts page → «گزارش‌های پایان شیفت کارکنان» → opens the cashier's report → acknowledges it, prints it
  admin   : settings fields (ops tab)
  waiter  : PIN clock-out on the login screen is refused → «ورود و ارسال گزارش» → «شیفت من» → submit + clock out
Leaves the main register closed (as found). Fails on console errors (except expected 4xx), page errors or API 5xx;
screenshots in shots/r7_*.png.
"""
import sys
import time

import httpx
from playwright.sync_api import sync_playwright

B = "http://127.0.0.1:8001"
ok, fail = [], []


def check(name, cond, info=""):
    (ok if cond else fail).append(name + (f" — {info}" if info and not cond else ""))
    print(("✓ " if cond else "✗ ") + name + (f" — {info}" if info and not cond else ""))


def login(u, p):
    return httpx.post(B + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]


H = lambda t: {"Authorization": f"Bearer {t}"}  # noqa: E731
cash_tok, mgr_tok, wait_tok = login("reza", "cashier123"), login("sara", "manager123"), login("ali", "waiter123")
full = httpx.get(B + "/api/menu/full", headers=H(mgr_tok)).json()
item = next(i for i in full["items"] if i["is_available"] and not i["code"].startswith("__") and not i["modifier_group_ids"])
main = next(r for r in httpx.get(B + "/api/shifts/registers", headers=H(mgr_tok)).json() if r["is_main"])
assert not main["open_shift"], "main register must be closed before this test (close it from the Shifts page)"


def punch_in(tok):
    """Clock in (wait out the 60 s double-tap guard after a recent clock-out)."""
    if httpx.get(B + "/api/timeclock/me", headers=H(tok)).json()["on_clock"]:
        return time.time() - 120
    for _ in range(14):
        r = httpx.post(B + "/api/timeclock/me/punch", headers=H(tok))
        if r.status_code == 200:
            return time.time()
        assert r.json()["detail"]["code"] == "punch_too_soon", r.text
        time.sleep(5)
    raise AssertionError("could not clock in")


t_cash, t_wait = punch_in(cash_tok), punch_in(wait_tok)
r = httpx.post(B + "/api/shifts/open", headers=H(cash_tok), json={"opening_cash": 500_000})
check("cashier opened the main register", r.status_code == 200, r.text[:200])
sales = []
for method in ("cash", "card"):
    o = httpx.post(B + "/api/orders", headers=H(cash_tok), json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    p = httpx.post(f"{B}/api/orders/{o['id']}/payments", headers=H(cash_tok), json={"payments": [{"method": method, "amount": o["total"]}]})
    sales.append(o["total"]) if p.status_code == 200 else check(f"{method} sale", False, p.text[:200])
expected = httpx.get(B + "/api/shifts/current", headers=H(mgr_tok)).json()["expected_cash"]
check("manager sees the expected cash", expected == 500_000 + sales[0], expected)
check("cashier's /shifts/current is blind", httpx.get(B + "/api/shifts/current", headers=H(cash_tok)).json()["expected_cash"] is None)

errors = []
with sync_playwright() as pw:
    br = pw.chromium.launch()

    def ctx_for(tok):
        ctx = br.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        if tok:
            ctx.add_init_script(f"localStorage.setItem('cafe_token', '{tok}')")
        pg = ctx.new_page()
        pg.on("console", lambda m: m.type == "error" and not any(s in m.text for s in ("status of 403", "status of 400", "status of 409"))
              and errors.append("console: " + m.text[:200]))
        pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)[:200]))
        pg.on("response", lambda r: r.status >= 500 and errors.append(f"http {r.status} {r.url}"))
        pg.add_init_script("window.__printed = []; const _a = Node.prototype.appendChild; Node.prototype.appendChild = function (n) {"
                           " if (n.tagName === 'IFRAME') { setTimeout(() => { try { window.__printed.push(n.srcdoc || n.contentDocument.body.innerHTML) } catch (e) {} }, 50) }"
                           " return _a.call(this, n) }")
        return ctx, pg

    # ------------------------------------------------------------ cashier
    ctx, pg = ctx_for(cash_tok)
    pg.goto(B + "/", wait_until="networkidle")
    check("launcher has the «شیفت من» tile", pg.locator(".app-tile", has_text="شیفت من").count() == 1)
    pg.locator(".tc-btn").first.click()
    pg.wait_for_url("**/my-shift", timeout=5000)
    pg.wait_for_selector(".staff-report", timeout=8000)
    pg.wait_for_timeout(500)
    check("header clock → «شیفت من» while on the clock", "/my-shift" in pg.url)
    check("drawer held is shown with the hand-over button", pg.locator(".drawer-alert .handover-btn").count() == 1)
    check("cash hidden while the drawer is open", pg.locator(".cash-hidden").count() == 1 and pg.locator(".pay-cash", has_text="پنهان").count() == 1)
    check("send buttons disabled until hand-over", pg.locator(".send-report").is_disabled() and pg.locator(".send-and-out").is_disabled())
    pg.screenshot(path="shots/r7_my_shift_open.png", full_page=True)

    pg.goto(B + "/admin/shifts", wait_until="networkidle")
    pg.wait_for_timeout(800)
    check("Shifts page is blind for the cashier", pg.locator(".blind-banner").count() == 1 and pg.locator(".blind-value").count() == 2)
    check("cashier has no staff-reports card", pg.locator(".staff-reports").count() == 0)
    pg.screenshot(path="shots/r7_shifts_blind.png")

    pg.goto(B + "/my-shift", wait_until="networkidle")
    pg.wait_for_selector(".handover-btn")
    pg.locator(".handover-btn").click()
    pg.wait_for_selector(".blind-alert", timeout=5000)
    modal = pg.locator(".ant-modal", has=pg.locator(".blind-alert"))
    check("hand-over modal is blind (no expected amount)", "مورد انتظار در صندوق:" not in modal.inner_text())
    pg.locator(".drawer-counted input").fill(str(expected - 2000))
    pg.wait_for_timeout(300)
    check("no live difference while counting blind", modal.locator(".ant-alert-error, .ant-alert-success").count() == 0)
    pg.screenshot(path="shots/r7_handover_blind.png")
    pg.locator(".drawer-close-ok").click()
    pg.wait_for_selector(".drawer-result", timeout=8000)
    res = pg.locator(".drawer-result").inner_text()
    check("after saving: difference shown (2,000 short)", "کسری صندوق: ۲٬۰۰۰ تومان" in res, res[:200])
    pg.screenshot(path="shots/r7_handover_result.png")
    pg.locator(".ant-modal-confirm .ant-modal-close").click()
    pg.wait_for_selector(".drawer-diff", timeout=8000)
    pg.wait_for_timeout(500)
    note = pg.locator(".report-note textarea").input_value()
    check("difference prefilled into the note", "کسری صندوق" in note, note)
    check("cash visible after hand-over", pg.locator(".cash-hidden").count() == 0 and pg.locator(".pay-cash", has_text="پنهان").count() == 0
          and pg.locator(".drawer-diff").count() == 1, (pg.locator(".cash-hidden").count(), pg.locator(".drawer-diff").count()))
    pg.locator(".report-note textarea").fill(note + "اشتباه در پول خرد")
    left = 62 - (time.time() - t_cash)
    if left > 0:
        time.sleep(left)                                    # time clock double-tap guard (60 s)
    pg.locator(".send-and-out").click()
    pg.locator(".ant-modal-confirm", has_text="شیفت شما پایان یافت").wait_for(timeout=8000)
    check("report sent + clock-out in one click", httpx.get(B + "/api/timeclock/me", headers=H(cash_tok)).json()["on_clock"] is False)
    pg.screenshot(path="shots/r7_clocked_out.png")
    ctx.close()

    # ------------------------------------------------------------ manager
    ctx, pg = ctx_for(mgr_tok)
    pg.goto(B + "/admin/shifts", wait_until="networkidle")
    pg.wait_for_selector(".staff-reports .ant-table-row", timeout=8000)
    row = pg.locator(".staff-reports .ant-table-row", has_text="رضا").first
    check("manager sees the cashier's pending report", row.count() == 1 and "در انتظار" in row.inner_text())
    pg.screenshot(path="shots/r7_staff_reports.png")
    row.click()
    pg.wait_for_selector(".ant-drawer .staff-report", timeout=5000)
    dt = pg.locator(".ant-drawer").inner_text()
    check("report drawer: note + drawer difference", "اشتباه در پول خرد" in dt and "کسری صندوق" in dt, dt[:300])
    pg.locator("textarea.ack-note").fill("از حقوق کسر نشود")
    pg.locator(".ack-btn").click()
    pg.wait_for_timeout(1000)
    check("acknowledged", "تأییدشده توسط" in pg.locator(".ant-drawer").inner_text())
    pg.screenshot(path="shots/r7_report_ack.png")
    pg.locator(".ant-drawer .ant-btn", has_text="چاپ").click()
    pg.wait_for_timeout(800)
    printed = pg.evaluate("window.__printed.join('\\n')")
    check("staff report prints (80 mm HTML)", "گزارش پایان شیفت" in printed and "از حقوق کسر نشود" in printed, printed[:200])
    ctx.close()
    ctx, pg = ctx_for(login("admin", "admin123"))                       # settings.manage: owner
    pg.goto(B + "/admin/settings", wait_until="networkidle")
    pg.get_by_role("tab", name="صندوق و عملیات").click()
    pg.wait_for_timeout(400)
    t = pg.locator(".ant-tabs-tabpane-active").inner_text()
    check("settings: blind count, report required, shift hours", all(x in t for x in ("شمارش کور صندوق", "الزام گزارش پایان شیفت", "طول شیفت کاری")), t[:200])
    ctx.close()

    # ------------------------------------------------------------ waiter: PIN clock-out on the login screen
    ctx, pg = ctx_for(None)
    pg.goto(B + "/login", wait_until="networkidle")
    pg.locator(".ant-segmented-item", has_text="حضور و غیاب").click()
    pg.wait_for_timeout(300)
    left = 62 - (time.time() - t_wait)
    if left > 0:
        time.sleep(left)
    pg.keyboard.type("4444")
    pg.wait_for_selector(".report-needed", timeout=5000)
    check("PIN clock-out refused until the report is sent", "گزارش پایان شیفت" in pg.locator(".report-needed").inner_text())
    pg.screenshot(path="shots/r7_pin_needs_report.png")
    pg.locator(".to-report").click()
    pg.wait_for_url("**/my-shift", timeout=6000)
    pg.wait_for_selector(".send-and-out", timeout=8000)
    check("«ورود و ارسال گزارش» signs in to «شیفت من»", "/my-shift" in pg.url)
    pg.locator(".send-and-out").click()
    pg.locator(".ant-modal-confirm", has_text="شیفت شما پایان یافت").wait_for(timeout=8000)
    check("waiter clocked out after the report", httpx.get(B + "/api/timeclock/me", headers=H(wait_tok)).json()["on_clock"] is False)
    pg.locator(".ant-modal-confirm .ant-btn-primary").click()            # «خروج از حساب کاربری»
    pg.wait_for_url("**/login", timeout=5000)
    check("sign out after the shift", "/login" in pg.url)
    ctx.close()
    br.close()

main = next(r for r in httpx.get(B + "/api/shifts/registers", headers=H(mgr_tok)).json() if r["is_main"])
check("main register left closed", not main["open_shift"])
mine = httpx.get(B + "/api/shifts/staff-reports", headers=H(mgr_tok), params={"pending": True}).json()
check("waiter's report waits for review", any(x["name"] and "علی" in x["name"] for x in mine), [x["name"] for x in mine])
check("no console/page errors or 5xx", not errors, errors[:5])
print(f"\n{len(ok)} passed, {len(fail)} failed")
sys.exit(1 if fail else 0)
