#!/usr/bin/env bash
# Run everything CI runs, locally, in the same order.
#   bash test.sh            # backend + frontend unit tests
#   bash test.sh --build    # ... plus a production frontend build
set -euo pipefail
cd "$(dirname "$0")"

WITH_BUILD=0
[ "${1:-}" = "--build" ] && WITH_BUILD=1

step() { printf '\n\033[1m==> %s\033[0m\n' "$1"; }

step "Backend: lint (ruff)"
if command -v ruff >/dev/null 2>&1; then
  ruff check backend/app backend/tests
else
  echo "ruff not installed - skipping (pip install -r backend/requirements-dev.txt)"
fi

step "Backend: tests (pytest)"
(cd backend && python -m pytest)

if [ -d frontend/node_modules ]; then
  step "Frontend: lint (eslint)"
  (cd frontend && npm run lint --silent)

  step "Frontend: unit tests (vitest)"
  (cd frontend && npm test --silent)

  if [ "$WITH_BUILD" = "1" ]; then
    step "Frontend: production build"
    (cd frontend && npm run build)
  fi
else
  echo "frontend/node_modules missing - run 'cd frontend && npm ci' first"
fi

printf '\n\033[32mAll checks passed.\033[0m\n'
