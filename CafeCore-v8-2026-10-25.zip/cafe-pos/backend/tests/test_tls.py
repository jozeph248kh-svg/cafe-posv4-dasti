"""Optional LAN HTTPS: local CA + server certificate (SANs, renewal), and a real TLS handshake via app.serve."""
import os
import socket
import ssl
import subprocess
import sys
import time
from pathlib import Path

import httpx
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import ec

from app.core.tls import ensure_certs

BACKEND = Path(__file__).resolve().parents[1]


def _sans(path):
    cert = x509.load_pem_x509_certificates(path.read_bytes())[0]
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    return cert, {str(i) for i in san.get_values_for_type(x509.IPAddress)}, set(san.get_values_for_type(x509.DNSName))


def test_certificates_cover_lan_and_renew(tmp_path):
    p = ensure_certs(tmp_path, ["192.168.1.20"])
    ca = x509.load_pem_x509_certificate(p["ca"].read_bytes())
    cert, ips, dns = _sans(p["cert"])
    assert {"127.0.0.1", "192.168.1.20"} <= ips and "localhost" in dns
    assert cert.issuer == ca.subject
    ca.public_key().verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(cert.signature_hash_algorithm))
    assert ca.extensions.get_extension_for_class(x509.BasicConstraints).value.ca is True
    assert (cert.not_valid_after_utc - cert.not_valid_before_utc).days <= 825          # Apple limit
    if os.name == "posix":
        assert oct(os.stat(p["key"]).st_mode & 0o777) == "0o600"
    # same addresses → nothing re-issued
    serial = cert.serial_number
    ensure_certs(tmp_path, ["192.168.1.20"])
    assert _sans(p["cert"])[0].serial_number == serial
    # the server moved to another IP → new server certificate, same CA (devices keep trusting it)
    ensure_certs(tmp_path, ["10.0.0.7"])
    cert2, ips2, _ = _sans(p["cert"])
    assert cert2.serial_number != serial and "10.0.0.7" in ips2
    assert x509.load_pem_x509_certificate(p["ca"].read_bytes()).serial_number == ca.serial_number


def test_https_server_end_to_end(tmp_path):
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    env = {**os.environ, "CAFE_HTTPS": "true", "CAFE_DATA_DIR": str(tmp_path), "CAFE_HOST": "127.0.0.1",
           "CAFE_BACKGROUND_JOBS": "false", "CAFE_DEMO_DATA": "false"}
    env.pop("CAFE_DATABASE_URL", None)
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(port)], cwd=BACKEND, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        ca = tmp_path / "tls" / "ca.crt"
        for _ in range(150):
            if ca.exists():
                try:
                    r = httpx.get(f"https://127.0.0.1:{port}/api/health", verify=ssl.create_default_context(cafile=str(ca)), timeout=2)
                    break
                except httpx.HTTPError:
                    pass
            time.sleep(0.2)
        else:
            raise AssertionError(proc.stdout.read1().decode(errors="replace") if proc.poll() is not None else "server did not start")
        assert r.status_code == 200 and r.json()["status"] == "ok"
        ctx = ssl.create_default_context(cafile=str(ca))
        # verified against the local CA (not just "insecure"), hostname localhost also valid
        assert httpx.get(f"https://localhost:{port}/api/system/info", verify=ctx).json()["https"] is True
        c = httpx.get(f"https://127.0.0.1:{port}/ca.crt", verify=ctx)
        assert c.status_code == 200 and c.content == ca.read_bytes() and "x509" in c.headers["content-type"]
        # a client that doesn't trust the CA is refused
        try:
            httpx.get(f"https://127.0.0.1:{port}/api/health", timeout=3)
            raise AssertionError("untrusted certificate accepted")
        except httpx.ConnectError:
            pass
        # plain HTTP on the HTTPS port does not serve the app
        try:
            plain = httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=3)
            assert plain.status_code != 200
        except httpx.HTTPError:
            pass
    finally:
        proc.terminate()
        try:
            proc.wait(10)
        except subprocess.TimeoutExpired:
            proc.kill()


def test_ca_download_off_when_https_disabled(client):
    from app.core.config import get_settings
    if (get_settings().data_dir / "tls" / "ca.crt").exists():
        return
    r = client.get("/ca.crt")
    assert r.status_code == 404 and r.json()["detail"]["code"] == "https_off"
