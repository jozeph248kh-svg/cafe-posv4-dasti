"""SQLite → PostgreSQL migration tool (app/migrate_to_pg.py).

The pre-check runs everywhere. The full copy needs an EMPTY scratch PostgreSQL database (its public schema is
wiped first — the test refuses to do that on a database that does not look like a scratch one):
    CAFE_TEST_MIGRATE_PG_URL="postgresql+psycopg://postgres@/cafe_mig_test?host=/tmp&port=5433" pytest tests/test_migrate_to_pg.py

The full-copy test builds its **own** source database (schema from the app metadata + a few valid orders) in
`tmp_path`, so it never depends on demo data, on what other tests left behind, or on the state of the suite's
database. (Before, it assumed the suite database already had orders; with `CAFE_DEMO_DATA=false` it has none and
the sequence assertion failed for a data reason, not a migration reason.)
"""
import os
import sqlite3
from datetime import date, datetime, time, timedelta
from pathlib import Path

import pytest
from conftest import PG_URL

from app import migrate_to_pg as M

pytestmark = pytest.mark.skipif(bool(PG_URL), reason="the source is the suite's SQLite database")


def _source() -> Path:
    from app.core.config import get_settings
    return get_settings().data_dir / "cafe.db"


def test_precheck_lists_values_postgres_would_refuse(client, tmp_path):
    from sqlalchemy import create_engine, inspect
    snap = tmp_path / "snap.db"
    M.snapshot(_source(), snap)
    with sqlite3.connect(snap) as c:                    # SQLite ignores VARCHAR lengths; PostgreSQL does not
        c.execute("UPDATE menu_categories SET name = ? WHERE id = (SELECT MIN(id) FROM menu_categories)", ("x" * 200,))
    eng = create_engine(f"sqlite:///{snap.as_posix()}")
    try:
        md = M._metadata()
        problems = M.precheck(eng, md, set(inspect(eng).get_table_names()))
    finally:
        eng.dispose()
    assert any(p.startswith("menu_categories.name: 1 value") for p in problems), problems
    assert M.snapshot is not None and _source().exists()


def test_refuses_a_non_postgres_target(client):
    with pytest.raises(M.MigrationError):
        M.migrate(_source(), "sqlite:///elsewhere.db", log=lambda *_: None)


# ---------------------------------------------------------------- an isolated source database
SEED_ORDERS = 3
TODAY = date(2026, 1, 15)          # a fixed day: the test must not depend on the wall clock


def _seed_source(tmp_path: Path) -> Path:
    """A brand-new SQLite database with the app's schema and `SEED_ORDERS` valid, closed orders.

    Everything the migration reads comes from here — no demo data, no other test, no shared state.
    """
    from sqlalchemy import create_engine

    md = M._metadata()
    db = tmp_path / "source.db"
    eng = create_engine(f"sqlite:///{db.as_posix()}")
    try:
        md.create_all(eng)                      # the same metadata the migration compares against
        t = md.tables
        with eng.begin() as c:
            c.execute(t["roles"].insert(), [{"id": 1, "name": "seed_cashier", "title": "صندوقدار تست"}])
            c.execute(t["users"].insert(), [{"id": 1, "username": "seed_user", "full_name": "کاربر تست",
                                             "password_hash": "x" * 60, "role_id": 1, "is_active": True}])
            c.execute(t["menu_categories"].insert(), [{"id": 1, "name": "دسته تست", "color": "#6366f1",
                                                       "section": "restaurant", "sort": 0, "is_active": True}])
            c.execute(t["menu_items"].insert(), [{"id": 1, "category_id": 1, "name": "قهوه تست",
                                                  "price": 100_000, "is_active": True, "is_available": True,
                                                  "sort": 0, "show_in_qr": True}])
            for k in range(1, SEED_ORDERS + 1):
                qty, unit = k, 100_000
                total = qty * unit
                c.execute(t["orders"].insert(), [{
                    "id": k, "number": k, "business_date": TODAY, "type": "takeaway", "status": "closed",
                    "source": "pos", "guests": 1, "subtotal": total, "total": total, "paid_amount": total,
                    "closed_at": datetime.combine(TODAY, time(12, 0)) + timedelta(minutes=k),
                    "created_at": datetime.combine(TODAY, time(12, 0)) + timedelta(minutes=k)}])
                c.execute(t["order_lines"].insert(), [{
                    "id": k, "order_id": k, "menu_item_id": 1, "name": "قهوه تست", "base_price": unit,
                    "unit_price": unit, "qty": qty, "modifiers": [], "status": "served",
                    "created_at": datetime.combine(TODAY, time(12, 0)) + timedelta(minutes=k)}])
                c.execute(t["payments"].insert(), [{
                    "id": k, "order_id": k, "method": "cash", "amount": total, "change": 0, "is_refund": False,
                    "created_at": datetime.combine(TODAY, time(12, 0)) + timedelta(minutes=k)}])
    finally:
        eng.dispose()
    return db


def _assert_scratch_target(url: str) -> None:
    """The test wipes the target's public schema: refuse anything that does not look like a scratch database."""
    from sqlalchemy import make_url

    name = (make_url(url).database or "").lower()
    if not any(word in name for word in ("test", "mig", "scratch", "tmp", "ci")):
        pytest.fail(f"refusing to DROP SCHEMA of {name!r}: CAFE_TEST_MIGRATE_PG_URL must point at a scratch database")


@pytest.mark.skipif(not os.environ.get("CAFE_TEST_MIGRATE_PG_URL"), reason="set CAFE_TEST_MIGRATE_PG_URL to a scratch PostgreSQL DB")
def test_full_copy_is_verified_and_atomic(client, admin, monkeypatch, tmp_path):
    from sqlalchemy import create_engine, func, inspect, select, text
    url = os.environ["CAFE_TEST_MIGRATE_PG_URL"]
    _assert_scratch_target(url)
    src = _seed_source(tmp_path)

    # the source really has the orders this test is about (the old failure was exactly this being 0)
    md = M._metadata()
    with sqlite3.connect(src) as c:
        assert c.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == SEED_ORDERS
        expected = dict(c.execute("SELECT id, total FROM orders ORDER BY id").fetchall())
        # what a complete copy has to move: every row of every table of this seed database
        expected_rows = sum(c.execute(f'SELECT COUNT(*) FROM "{t.name}"').fetchone()[0]
                            for t in md.sorted_tables
                            if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t.name,)).fetchone())

    with create_engine(url).begin() as c:
        c.execute(text("DROP SCHEMA public CASCADE"))
        c.execute(text("CREATE SCHEMA public"))
    # a verification mismatch rolls back everything — schema included
    with monkeypatch.context() as mp:
        mp.setattr(M, "verify", lambda *a, **k: ["orders.total: sum 1 in SQLite, 2 in PostgreSQL"])
        with pytest.raises(M.MigrationError, match="verification failed"):
            M.migrate(src, url, log=lambda *_: None)
    e = create_engine(url)
    assert inspect(e).get_table_names() == []
    e.dispose()
    res = M.migrate(src, url, log=lambda *_: None)
    # every row of every table arrived — the number is derived from the seed, not a magic constant
    assert res["rows"] == expected_rows, (res["rows"], expected_rows)
    assert res["tables"] > 40                              # the whole schema (all modules) was created
    orders = md.tables["orders"]
    lines, pays = md.tables["order_lines"], md.tables["payments"]
    eng = create_engine(url)
    try:
        with eng.connect() as c:
            n = c.execute(select(func.count()).select_from(orders)).scalar()
            top = c.execute(select(func.max(orders.c.id))).scalar()
            # read the sequence WITHOUT consuming a value (nextval would eat the very id the next step checks)
            seq = c.execute(text("SELECT pg_get_serial_sequence('orders', 'id')")).scalar()
            last_value, is_called = c.execute(text(f"SELECT last_value, is_called FROM {seq}")).one()
            got = dict(c.execute(select(orders.c.id, orders.c.total).order_by(orders.c.id)).all())
            line_rows = c.execute(select(func.count()).select_from(lines)).scalar()
            pay_rows = c.execute(select(func.count()).select_from(pays)).scalar()
        # 1) row counts and the data itself arrived unchanged
        assert n == SEED_ORDERS and got == expected, (n, got, expected)
        assert line_rows == SEED_ORDERS and pay_rows == SEED_ORDERS
        # 2) the sequence sits exactly past the copied ids, ready to hand out the next one
        assert top == SEED_ORDERS and last_value == top + 1 and is_called is False, (top, last_value, is_called)
        # 3) …and really works: a new order gets that id instead of colliding with a copied one
        with eng.begin() as c:
            new_id = c.execute(orders.insert().values(
                number=SEED_ORDERS + 1, business_date=TODAY, type="takeaway", status="open", source="pos",
                guests=1, subtotal=1, total=1, paid_amount=0).returning(orders.c.id)).scalar()
        assert new_id == SEED_ORDERS + 1, new_id
        with eng.connect() as c:                       # the copied rows are still there, untouched
            assert c.execute(select(orders.c.total).where(orders.c.id == 1)).scalar() == expected[1]
        # 4) a second run must refuse (target not empty) and change nothing
        with pytest.raises(M.MigrationError, match="not empty"):
            M.migrate(src, url, log=lambda *_: None)
        with eng.connect() as c:
            assert c.execute(select(func.count()).select_from(orders)).scalar() == n + 1
    finally:
        eng.dispose()
