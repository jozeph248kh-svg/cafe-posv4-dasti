"""Round-3 audit (Arena-1 review): legacy/mixed COGS, refund COGS timing, refund tax allocation.

Item 1 — an order that has BOTH frozen lines (`cost_amount`) and legacy lines (NULL) had the whole order's
         sale-movement cost distributed over the NULL lines only, so the frozen lines were counted twice.
         A NULL line with no historical movement was also reported as a certain 0.
Item 2 — where the COGS of a restocked refund lands (sale day vs. event day). This is an accounting policy
         decision, so these tests only *pin today's behaviour* and document the alternative; no logic changed.
Item 3 — the tax reversed by a refund was computed per refund with round(amount × tax/total); several partial
         refunds of the same bill could lose or gain a toman, so the reversed VAT never matched the bill's VAT.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    """Open a register for this file and restore every pricing setting it touches (other files expect the
    defaults — the whole suite shares one database)."""
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    client.put("/api/system/settings", headers=admin, json=old)
    close_register(client, admin)


def _ing(client, admin, name, cost, stock=5_000.0):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": stock, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    it = r.json()
    client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
               json=[{"ingredient_id": i, "qty": q} for i, q in recipe]).raise_for_status()
    return it


def _sell(client, cashier, lines, pay=True):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": lines})
    assert o.status_code == 201, o.text
    o = o.json()
    if pay:
        r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                        json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
        assert r.status_code == 200, r.text
        o = r.json()
    return o


def _pnl(client, admin):
    r = client.get("/api/expenses/pnl", headers=admin)
    assert r.status_code == 200, r.text
    return r.json()


def _sales(client, admin):
    r = client.get("/api/reports/sales", headers=admin)
    assert r.status_code == 200, r.text
    return r.json()


def _settings(client, admin, **kw):
    assert client.put("/api/system/settings", headers=admin, json=kw).status_code == 200


# ================================================================ item 1 — mixed snapshot/NULL lines
def test_a_mixed_order_does_not_count_the_frozen_line_twice(client, admin, cashier):
    """Item 1: the order's movement cost covers ALL its lines; only the part above the frozen lines may be
    allocated to the NULL line. Before the fix the whole movement (250) went to the legacy line on top of the
    frozen 100 → COGS 350 for a bill whose materials cost 250."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    a = _ing(client, admin, "شیر تست ترکیبی", 10)          # 10 g × 10 = 100
    b = _ing(client, admin, "دانه تست ترکیبی", 15)         # 10 g × 15 = 150
    ia = _item(client, admin, "لاته تست ترکیبی", 200_000, [(a["id"], 10)])
    ib = _item(client, admin, "موکا تست ترکیبی", 200_000, [(b["id"], 10)])
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": ia["id"], "qty": 1}, {"menu_item_id": ib["id"], "qty": 1}])
    assert _pnl(client, admin)["cogs"] - before["cogs"] == 250      # 100 + 150 from the snapshots

    with SessionLocal() as db:                                       # simulate one legacy line of the same order
        legacy = db.query(OrderLine).filter(OrderLine.order_id == o["id"],
                                            OrderLine.menu_item_id == ib["id"]).one()
        legacy.cost_amount = None
        db.commit()
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 250, f"COGS شد {after['cogs'] - before['cogs']}، باید ۲۵۰ باشد"
    assert after["cogs_estimated_lines"] - before["cogs_estimated_lines"] == 1   # one row is estimated


def test_a_legacy_line_without_a_movement_is_unknown_not_a_certain_zero(client, admin, cashier):
    """Item 1: no snapshot AND no historical sale movement = the cost cannot be reconstructed. It must be
    reported as unknown, never as a confident 0."""
    from app.core.db import SessionLocal
    from app.modules.inventory.models import StockMovement
    from app.modules.orders.models import OrderLine

    ing = _ing(client, admin, "دانه تست نامعلوم", 40)
    item = _item(client, admin, "قهوه تست نامعلوم", 90_000, [(ing["id"], 5)])     # 200
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])
    with SessionLocal() as db:                     # the row predates the snapshot AND its movements are gone
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.cost_amount = None
        db.query(StockMovement).filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                                       StockMovement.ref_id == o["id"]).delete()
        db.commit()
    after = _pnl(client, admin)
    assert after["cogs_unknown_lines"] - before["cogs_unknown_lines"] == 1, \
        "خط بدون snapshot و بدون حرکت باید «نامعلوم» شمرده شود"
    assert after["cogs"] == before["cogs"]         # and it must not silently add a made-up cost


def test_a_legacy_line_with_a_movement_is_estimated_from_it_and_marked_so(client, admin, cashier):
    """The estimate based on a real historical movement is a different status from "unknown" (item 1)."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    ing = _ing(client, admin, "دانه تست برآورد", 30)
    item = _item(client, admin, "قهوه تست برآورد", 80_000, [(ing["id"], 4)])      # 120
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 2}])
    with SessionLocal() as db:
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.cost_amount = None
        db.commit()
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 240          # 2 units × 120 from the historical movement
    assert after["cogs_estimated_lines"] - before["cogs_estimated_lines"] == 1
    assert after["cogs_unknown_lines"] == before["cogs_unknown_lines"]


def test_legacy_estimate_does_not_follow_a_recipe_change(client, admin, cashier):
    """Item 1: a recipe that changed after the sale must not rewrite the estimate — the movement is the source."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    ing = _ing(client, admin, "دانه تست رسپی", 50)
    item = _item(client, admin, "قهوه تست رسپی", 70_000, [(ing["id"], 6)])       # 300 at sale time
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])
    client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin,
               json=[{"ingredient_id": ing["id"], "qty": 60}]).raise_for_status()   # recipe ×10 afterwards
    with SessionLocal() as db:
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.cost_amount = None
        db.commit()
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 300, (after["cogs"] - before["cogs"])   # not 3,000


def test_a_legacy_modifier_line_is_estimated_from_the_movement(client, admin, cashier):
    """Item 1: the movement of a sale includes the modifier's ingredients, so a legacy modifier line is still
    costed correctly (no missing syrup cost, no double count)."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    base = _ing(client, admin, "شیر تست افزودنی قدیمی", 10)          # 100
    syrup = _ing(client, admin, "سیروپ تست افزودنی قدیمی", 20)        # 100
    grp = client.post("/api/menu/modifier-groups", headers=admin, json={
        "name": "گروه تست قدیمی", "min_select": 0, "max_select": 1,
        "options": [{"name": "معمولی", "price_delta": 0, "is_default": True, "is_available": True},
                    {"name": "سیروپ", "price_delta": 15_000, "is_default": False, "is_available": True}]}).json()
    syrup_opt = next(o for o in grp["options"] if o["name"] == "سیروپ")
    client.put(f"/api/inventory/recipes/option/{syrup_opt['id']}", headers=admin,
               json=[{"ingredient_id": syrup["id"], "qty": 5}]).raise_for_status()
    cats = client.get("/api/menu/categories", headers=admin).json()
    item = client.post("/api/menu/items", headers=admin, json={
        "category_id": cats[0]["id"], "name": "لاته تست قدیمی", "price": 150_000,
        "modifier_group_ids": [grp["id"]]}).json()
    client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin,
               json=[{"ingredient_id": base["id"], "qty": 10}]).raise_for_status()
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1, "modifier_option_ids": [syrup_opt["id"]]}])
    with SessionLocal() as db:
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.cost_amount = None
        db.commit()
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 200, (after["cogs"] - before["cogs"])


def test_selling_into_negative_stock_still_records_a_cost(client, admin, cashier):
    """Item 1: the shop may sell below zero (approved policy). The cost of that sale must still be frozen."""
    ing = _ing(client, admin, "دانه تست منفی", 25, stock=10)
    item = _item(client, admin, "قهوه تست منفی", 60_000, [(ing["id"], 4)])       # 100 per unit
    before = _pnl(client, admin)
    _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 5}])             # needs 20 g of 10 g
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 500                                 # 5 × 100
    ings = {i["id"]: i for i in client.get("/api/inventory/ingredients", headers=admin).json()}
    assert ings[ing["id"]]["stock"] < 0                                          # negative stock still allowed


# ================================================================ item 2 — refund COGS timing (policy, pinned)
def test_restock_cost_is_booked_on_the_return_day_not_the_sale_day(client, admin, cashier, mgr):
    """Item 2 — **rewritten in round 4 to the owner's policy** (the old version pinned the opposite behaviour).

    Round 3 recorded the returned material cost on the day of the SALE (the only date the data model had). Since
    round 4 every physical return is its own event (`order_refund_lines`), so:
      * the sale day keeps its cost forever (a closed day is never rewritten),
      * the return day carries the negative COGS of exactly what came back.
    """
    from app.core.db import SessionLocal
    from app.core.utils import business_day
    from app.modules.orders.models import Order, OrderRefundLine, Payment
    from datetime import datetime, timedelta

    ing = _ing(client, admin, "دانه تست زمان برگشت", 100)
    item = _item(client, admin, "قهوه تست زمان برگشت", 150_000, [(ing["id"], 2)])      # 200 per unit
    today = business_day()
    yesterday = today - timedelta(days=1)

    def pnl_day(day):
        r = client.get("/api/expenses/pnl", headers=admin,
                       params={"date_from": day.isoformat(), "date_to": day.isoformat()})
        assert r.status_code == 200, r.text
        return r.json()

    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 2}])               # COGS 400 today
    with SessionLocal() as db:                       # the sale happened yesterday (a closed business day)
        order = db.get(Order, o["id"])
        order.business_date = yesterday
        order.number = int(db.query(__import__("sqlalchemy").func.max(Order.number))
                           .filter(Order.business_date == yesterday).scalar() or 0) + 1
        order.closed_at = datetime.combine(yesterday, datetime.min.time()) + timedelta(hours=20)
        for p in db.query(Payment).filter(Payment.order_id == order.id):
            p.created_at = order.closed_at
        db.commit()

    day1_before = pnl_day(yesterday)["cogs"]
    day2_before = pnl_day(today)["cogs"]

    client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                json={"method": "cash", "amount": o["total"], "reason": "برگشت فردا",
                      "restock": [{"line_id": o["lines"][0]["id"], "qty": 2}]}).raise_for_status()

    # the closed sale day is untouched …
    assert pnl_day(yesterday)["cogs"] == day1_before, "روز فروش نباید تغییر کند"
    # … and the whole returned material cost lands on the day of the return
    assert pnl_day(today)["cogs"] - day2_before == -400, "بهای مرجوعی باید در روز وقوع ثبت شود"
    with SessionLocal() as db:
        ev = db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).one()
        assert (ev.qty, ev.unit_cost) == (2.0, 200.0)        # quantity + frozen historical unit cost
        assert ev.created_at is not None and ev.created_by is not None


# ================================================================ item 3 — refund VAT allocation
def test_three_partial_refunds_reverse_exactly_the_bill_tax(client, admin, cashier, mgr):
    """Item 3: 110,000 with 10,000 VAT refunded in three parts. Per-refund rounding loses a toman; the total
    reversed VAT must equal the bill's VAT exactly."""
    _settings(client, admin, **{"tax.enabled": True, "tax.percent": 10, "service.enabled": False})
    ing = _ing(client, admin, "دانه تست مالیات چندباره", 100)
    item = _item(client, admin, "قهوه تست مالیات چندباره", 100_000, [(ing["id"], 1)])
    before = _pnl(client, admin)
    o = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])
    assert o["total"] == 110_000 and o["tax_amount"] == 10_000
    for amount in (36_667, 36_667):                      # two odd parts …
        r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                        json={"method": "cash", "amount": amount, "reason": "جزئی"})
        assert r.status_code == 200, r.text
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 110_000 - 36_667 * 2, "reason": "مانده"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["sales"]["tax"] == before["sales"]["tax"], \
        f"مالیات معکوس‌شده دقیقاً برابر مالیات فاکتور نشد: {after['sales']['tax']} != {before['sales']['tax']}"
    assert after["revenue"] == before["revenue"]         # and the net revenue returns to zero, exactly


def test_tax_allocation_holds_with_service_and_odd_percentages(client, admin, cashier, mgr):
    """Item 3: a different VAT rate plus a service charge — the sum of the reversed parts must still match."""
    _settings(client, admin, **{"tax.enabled": True, "tax.percent": 7, "service.enabled": True, "service.percent": 12})
    ing = _ing(client, admin, "دانه تست مالیات ۷", 100)
    item = _item(client, admin, "قهوه تست مالیات ۷", 87_500, [(ing["id"], 1)])
    before = _pnl(client, admin)
    cats = client.get("/api/orders/floor", headers=cashier).json()
    table = next(t for a in cats for t in a["tables"] if t["status"] == "free")
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "dine_in", "table_id": table["id"],
                          "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]}).json()
    assert o["tax_amount"] > 0 and o["service_amount"] > 0
    for part in (20_000, 19_999, 1_000):
        r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                        json={"method": "cash", "amount": part, "reason": "جزئی"})
        assert r.status_code == 200, r.text
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": o["total"] - 40_999, "reason": "مانده"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["sales"]["tax"] == before["sales"]["tax"], (after["sales"]["tax"], before["sales"]["tax"])
    assert after["revenue"] == before["revenue"]
