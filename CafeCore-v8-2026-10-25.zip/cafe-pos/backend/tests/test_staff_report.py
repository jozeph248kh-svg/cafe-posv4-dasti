"""Round 7: blind cash count + «شیفت من» (end-of-shift report of every employee, drawer hand-over, manager review)
and the clock-out gate (report + hand-over before clocking out)."""
import time
from datetime import datetime, timedelta

import pytest
from conftest import _login, close_register, line

from sqlalchemy import func

from app.core import ratelimit
from app.core.db import SessionLocal
from app.modules.timeclock import service as TC
from app.modules.timeclock.models import TimeEntry


@pytest.fixture(autouse=True)
def _clean(client, admin):
    ratelimit.reset()
    close_register(client, admin)
    with SessionLocal() as db:
        first = (db.query(func.max(TimeEntry.id)).scalar() or 0) + 1
    yield
    close_register(client, admin)
    ratelimit.reset()
    # punches here are dated hours ahead (monkeypatched clock); move them a day back so later tests' punches are not
    # refused by the double-tap guard, and close anything a failed test left open
    with SessionLocal() as db:
        for e in db.query(TimeEntry).filter(TimeEntry.id >= first):
            e.clock_out = (e.clock_out or e.clock_in + timedelta(minutes=1)) - timedelta(days=1)
            e.clock_in -= timedelta(days=1)
            e.business_date -= timedelta(days=1)
        db.commit()


@pytest.fixture(scope="module")
def manager(client):
    return _login(client, "sara", "manager123")


def _later(monkeypatch, hours):
    """Time clock only (double-tap guard): the clock-out happens `hours` after the clock-in."""
    real = datetime.now()
    monkeypatch.setattr(TC, "now", lambda: real + timedelta(hours=hours))


def _settings(client, admin, **vals):
    keys = {k.replace("__", "."): v for k, v in vals.items()}
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    client.put("/api/system/settings", headers=admin, json=keys).raise_for_status()
    return old


def _sale(client, h, menu, method, code="101", qty=1):
    o = client.post("/api/orders", headers=h, json={"type": "takeaway", "lines": [line(menu, code, qty)]}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=h, json={"payments": [{"method": method, "amount": o["total"]}]})
    assert r.status_code == 200, r.text
    return o


def test_defaults_and_permission(client, admin, manager, cashier):
    s = client.get("/api/system/settings", headers=admin).json()
    assert s["shift.blind_close"] is True and s["shift.report_required"] is True and s["shift.hours"] == 8
    me = client.get("/api/staff/auth/me", headers=manager).json()
    assert "shifts.supervise" in me["permissions"]                       # granted once to managers
    assert "shifts.supervise" not in client.get("/api/staff/auth/me", headers=cashier).json()["permissions"]
    assert client.put("/api/system/settings", headers=admin, json={"shift.hours": 40}).status_code == 400   # range 1..16


def test_blind_count_masks_open_drawer_by_role(client, admin, manager, cashier, waiter, menu):
    s = client.post("/api/shifts/open", headers=cashier, json={"opening_cash": 300_000}).json()
    o = _sale(client, cashier, menu, "cash")
    _sale(client, cashier, menu, "card")

    blind = client.get("/api/shifts/current", headers=cashier).json()
    assert blind["blind"] is True and blind["expected_cash"] is None and blind["total_sales"] is None
    assert "cash" not in blind["payments"] and blind["payments"]["card"] > 0 and blind["opening_cash"] == 300_000
    # the same masking everywhere a cashier can read an open shift
    assert client.get(f"/api/shifts/{s['id']}", headers=cashier).json()["expected_cash"] is None
    assert next(x for x in client.get("/api/shifts", headers=cashier).json() if x["id"] == s["id"])["expected_cash"] is None
    moved = client.post("/api/shifts/cash", headers=cashier, json={"kind": "in", "amount": 10_000, "reason": "خرد"}).json()
    assert moved["expected_cash"] is None

    full = client.get("/api/shifts/current", headers=manager).json()
    assert full["blind"] is False and full["expected_cash"] == 300_000 + o["total"] + 10_000 and full["payments"]["cash"] == o["total"]

    w = client.get("/api/shifts/current", headers=waiter).json()           # no shifts.manage: only "open, by whom"
    assert w["restricted"] is True and w["opened_by"] and "expected_cash" not in w and "payments" not in w

    old = _settings(client, admin, shift__blind_close=False)
    try:
        assert client.get("/api/shifts/current", headers=cashier).json()["expected_cash"] == full["expected_cash"]
    finally:
        client.put("/api/system/settings", headers=admin, json=old).raise_for_status()
    assert client.get("/api/shifts/current", headers=cashier).json()["expected_cash"] is None

    # counted blind → the result appears only after closing
    closed = client.post("/api/shifts/close", headers=cashier, json={"counted_cash": full["expected_cash"] - 3_000}).json()
    assert closed["status"] == "closed" and closed["blind"] is False
    assert closed["expected_cash"] == full["expected_cash"] and closed["difference"] == -3_000


def test_report_handover_submit_and_review(client, admin, manager, cashier, waiter, menu, monkeypatch):
    assert client.get("/api/timeclock/me", headers=cashier).json()["on_clock"] is False
    time.sleep(1.05)        # clock-in has 1 s resolution: keep the previous test's sales out of this shift
    assert client.post("/api/timeclock/me/punch", headers=cashier).json()["action"] == "in"
    client.post("/api/shifts/open", headers=cashier, json={"opening_cash": 200_000}).raise_for_status()
    a = _sale(client, cashier, menu, "cash", qty=2)
    b = _sale(client, cashier, menu, "card", code="701")
    left = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101")]}).json()

    rep = client.get("/api/shifts/my-report", headers=cashier).json()
    d = rep["data"]
    assert rep["status"]["on_clock"] is True and rep["status"]["shift_hours"] == 8 and rep["status"]["can_clock_out"] is False
    assert d["orders"]["closed"] == 2 and d["orders"]["open"] == 1 and d["orders"]["sales"] == a["total"] + b["total"]
    assert d["payments"]["card"] == b["total"] and d["payments_count"] == 2
    assert d["payments"]["cash"] is None and d["collected_total"] is None and d["cash_hidden"] is True   # drawer still open
    assert d["drawer"]["opening_cash"] == 200_000 and left["id"] in {x["id"] for x in d["open_orders"]}
    assert d["top_items"][0]["qty"] >= 2

    # the drawer must be handed over first — for the report and for the clock-out
    r = client.post("/api/shifts/my-report", headers=cashier, json={"note": "x"})
    assert r.status_code == 409 and r.json()["detail"]["code"] == "drawer_open"
    _later(monkeypatch, 8)
    r = client.post("/api/timeclock/me/punch", headers=cashier)
    assert r.status_code == 409 and r.json()["detail"]["code"] == "drawer_open"

    client.post(f"/api/orders/{left['id']}/cancel", headers=admin, json={"reason": "تست"})
    expected = client.get("/api/shifts/current", headers=manager).json()["expected_cash"]
    closed = client.post("/api/shifts/close", headers=cashier, json={"counted_cash": expected - 1_000}).json()
    assert closed["difference"] == -1_000

    d = client.get("/api/shifts/my-report", headers=cashier).json()["data"]
    assert d["drawer"] is None and d["cash_hidden"] is False and d["payments"]["cash"] == a["total"]
    assert d["drawers_closed"][0]["difference"] == -1_000

    r = client.post("/api/shifts/my-report", headers=cashier, json={"note": "۱۰۰۰ تومان کسری؛ بقیه پول خرد"})
    assert r.status_code == 201, r.text
    first = r.json()
    assert first["note"].startswith("۱۰۰۰") and first["data"]["payments"]["cash"] == a["total"] and first["acknowledged_at"] is None
    again = client.post("/api/shifts/my-report", headers=cashier, json={"note": "اصلاح"}).json()
    assert again["id"] == first["id"] and again["note"] == "اصلاح"                         # same clock-in → updated

    # review: supervisors only
    assert client.get("/api/shifts/staff-reports", headers=waiter).status_code == 403
    assert client.get(f"/api/shifts/staff-reports/{first['id']}", headers=waiter).status_code == 403
    assert client.post(f"/api/shifts/staff-reports/{first['id']}/ack", headers=cashier, json={}).status_code == 403
    assert client.get(f"/api/shifts/staff-reports/{first['id']}", headers=cashier).status_code == 200   # own report
    pending = client.get("/api/shifts/staff-reports?pending=true", headers=manager).json()
    assert first["id"] in {x["id"] for x in pending}
    ack = client.post(f"/api/shifts/staff-reports/{first['id']}/ack", headers=manager, json={"note": "کسری ثبت شد"}).json()
    assert ack["acknowledged_by"] and ack["manager_note"] == "کسری ثبت شد"
    assert first["id"] not in {x["id"] for x in client.get("/api/shifts/staff-reports?pending=true", headers=manager).json()}
    assert client.get("/api/shifts/my-report", headers=cashier).json()["status"]["can_clock_out"] is True

    r = client.post("/api/timeclock/me/punch", headers=cashier)
    assert r.status_code == 200 and r.json()["action"] == "out", r.text
    mine = client.get("/api/shifts/my-reports", headers=cashier).json()
    assert mine[0]["id"] == first["id"] and mine[0]["acknowledged_at"]


def test_own_report_needs_another_manager(client, manager):
    r = client.post("/api/shifts/my-report", headers=manager, json={})
    assert r.status_code == 201
    r2 = client.post(f"/api/shifts/staff-reports/{r.json()['id']}/ack", headers=manager, json={})
    assert r2.status_code == 409 and r2.json()["detail"]["code"] == "own_report"


def test_report_without_clock_starts_after_last_report(client, waiter):
    first = client.post("/api/shifts/my-report", headers=waiter, json={}).json()
    rep = client.get("/api/shifts/my-report", headers=waiter).json()
    assert rep["status"]["on_clock"] is False and rep["status"]["can_clock_out"] is False
    assert rep["period_start"] >= first["period_end"][:19]


def test_pin_punch_gate_and_setting_off(client, admin, chef, monkeypatch):
    assert client.post("/api/timeclock/punch", json={"pin": "6666"}).json()["action"] == "in"
    _later(monkeypatch, 3)
    r = client.post("/api/timeclock/punch", json={"pin": "6666"})
    assert r.status_code == 409 and r.json()["detail"]["code"] == "shift_report_required"
    old = _settings(client, admin, shift__report_required=False)
    try:
        r = client.post("/api/timeclock/punch", json={"pin": "6666"})
        assert r.status_code == 200 and r.json()["action"] == "out"
    finally:
        client.put("/api/system/settings", headers=admin, json=old).raise_for_status()


def test_waiter_report_counts_orders_they_took(client, admin, waiter, menu):
    t = next(t for a in client.get("/api/orders/floor", headers=waiter).json() for t in a["tables"] if not t.get("order_id"))
    before = client.get("/api/shifts/my-report", headers=waiter).json()["data"]["orders"]["count"]
    o = client.post("/api/orders", headers=waiter, json={"type": "dine_in", "table_id": t["id"], "lines": [line(menu, "101")]}).json()
    d = client.get("/api/shifts/my-report", headers=waiter).json()["data"]
    assert d["orders"]["count"] == before + 1 and o["id"] in {x["id"] for x in d["open_orders"]}
    client.post(f"/api/orders/{o['id']}/cancel", headers=admin, json={"reason": "تست"})
