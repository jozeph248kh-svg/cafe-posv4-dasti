"""`GET /orders/active` got faster — this pins that it still returns exactly the same payload.

The endpoint used to load every open order as an ORM object (with its lines, payments, table and waiter eagerly)
and copy it through `to_out()`. It now runs three column queries and builds the same `OrderOut` objects.
Every active row is compared with `GET /orders/{id}` — which still goes through the ORM `to_out()` path — so a
missing field, a changed value or a dropped relation fails here.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


@pytest.fixture()
def board(client, cashier, mgr, menu):
    """A board with everything the payload has to carry: dine-in with a table, takeaway, delivery, modifiers,
    notes, an item discount, a voided line, a part payment and one already closed order."""
    free = [t for a in client.get("/api/orders/floor", headers=cashier).json() for t in a["tables"] if t["status"] == "free"]
    made = []
    o = client.post("/api/orders", headers=cashier, json={
        "type": "dine_in", "table_id": free[0]["id"], "guests": 3, "customer_name": "آزمون فعال ۱",
        "customer_phone": "09120000001", "note": "بدون پیاز",
        "lines": [line(menu, "101", 2), line(menu, "301", 1)]}).json()
    made.append(o["id"])
    o2 = client.post("/api/orders", headers=cashier, json={
        "type": "takeaway", "customer_name": "آزمون فعال ۲", "lines": [line(menu, "104", 1, extra=())]}).json()
    made.append(o2["id"])
    o3 = client.post("/api/orders", headers=cashier, json={
        "type": "delivery", "customer_name": "آزمون فعال ۳", "customer_phone": "09120000003",
        "customer_address": "خیابان تست ۱", "lines": [line(menu, "601", 2)]}).json()
    made.append(o3["id"])

    # an item discount + a voided line + a note on a line
    lid = o["lines"][0]["id"]
    client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr,
                json={"type": "percent", "value": 10, "reason": "تست"})
    client.post(f"/api/orders/{o['id']}/lines/{o['lines'][1]['id']}/void", headers=mgr, json={"reason": "اشتباه"})
    client.patch(f"/api/orders/{o2['id']}/lines/{o2['lines'][0]['id']}", headers=cashier, json={"note": "بدون شکر"})
    # a part payment on the delivery order
    client.post(f"/api/orders/{o3['id']}/payments", headers=cashier, json={"payments": [{"method": "cash", "amount": 50_000, "tendered": 60_000}]})
    # one order that is closed and must NOT appear
    done = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "104")]}).json()
    client.post(f"/api/orders/{done['id']}/payments", headers=cashier,
                json={"payments": [{"method": "cash", "amount": done["total"]}]})
    yield made, done["id"]
    for oid in made:
        client.post(f"/api/orders/{oid}/cancel", headers=mgr, json={"reason": "پایان تست"})


def test_active_payload_is_identical_to_the_order_endpoint(client, cashier, board):
    made, closed_id = board
    active = client.get("/api/orders/active", headers=cashier)
    assert active.status_code == 200
    rows = active.json()
    ids = [r["id"] for r in rows]
    assert closed_id not in ids                       # a paid order is not "active"
    for oid in made:
        assert oid in ids
    # every row is byte-for-byte the payload of GET /orders/{id} (which still uses the ORM path)
    for row in rows:
        single = client.get(f"/api/orders/{row['id']}", headers=cashier).json()
        assert row == single, row["id"]
    # order of the list is unchanged: oldest first
    stamps = [r["created_at"] for r in rows]
    assert stamps == sorted(stamps)


def test_active_keeps_every_field_of_the_payload(client, cashier, board):
    made, _closed = board
    row = next(r for r in client.get("/api/orders/active", headers=cashier).json() if r["id"] == made[0])
    assert row["table_name"] and row["waiter_name"] and row["customer_name"] == "آزمون فعال ۱"
    assert row["note"] == "بدون پیاز" and row["remaining"] == row["total"] - row["paid_amount"]
    assert len(row["lines"]) == 2
    discounted = next(l for l in row["lines"] if l["discount_type"] == "percent")
    assert discounted["discount_amount"] > 0 and discounted["total"] == discounted["unit_price"] * discounted["qty"]
    voided = next(l for l in row["lines"] if l["status"] == "void")
    assert voided["void_reason"] == "اشتباه"
    delivery = next(r for r in client.get("/api/orders/active", headers=cashier).json() if r["id"] == made[2])
    assert delivery["payments"] and delivery["payments"][0]["change"] == 10_000
    assert delivery["paid_amount"] == 50_000 and delivery["remaining"] == delivery["total"] - 50_000


def test_active_type_filter_still_works(client, cashier, board):
    rows = client.get("/api/orders/active", headers=cashier, params={"type": "delivery"}).json()
    assert rows and all(r["type"] == "delivery" for r in rows)


def test_the_empty_result_short_circuits(client, admin):
    """No rows must return [] without the line/payment queries (and without an `IN ()` error on any backend)."""
    from app.core.db import SessionLocal
    from app.modules.orders.service import orders_out

    with SessionLocal() as db:
        assert orders_out(db, "no-such-status") == []
