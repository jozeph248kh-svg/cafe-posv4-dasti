"""Refused money-taking attempts must be in the audit trail — even though their transaction is rolled back.

For a cash business the interesting events are not only the tenders that went through: a cashier trying to take
more than the bill, a wrong change, a double click. Those attempts have to be answerable afterwards (who, which
bill, how much was attempted, which method, when, why it was refused) while the money side must stay untouched.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _order(client, h, menu, qty=2):
    o = client.post("/api/orders", headers=h, json={"type": "takeaway", "lines": [line(menu, "101", qty)]})
    assert o.status_code == 201, o.text
    return o.json()


def _pay(client, h, oid, *payments, request_id=None):
    body = {"payments": list(payments)}
    if request_id:
        body["request_id"] = request_id
    return client.post(f"/api/orders/{oid}/payments", headers=h, json=body)


def _rejections(client, admin, number):
    rows = client.get("/api/system/audit", headers=admin,
                      params={"q": f"#{number}", "action": "payment.rejected", "limit": 50}).json()
    return [r for r in rows if r["action"] == "payment.rejected"]


def _order_now(client, h, oid):
    return client.get(f"/api/orders/{oid}", headers=h).json()


# ---------------------------------------------------------------- success
def test_a_successful_payment_is_recorded_and_not_flagged_as_rejected(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]})
    assert r.status_code == 200 and r.json()["status"] == "closed"
    assert not _rejections(client, admin, o["number"])
    taken = client.get("/api/system/audit", headers=admin,
                       params={"q": f"#{o['number']}", "action": "payment.take", "limit": 20}).json()
    assert len(taken) == 1 and taken[0]["details"]["amount"] == o["total"]


# ---------------------------------------------------------------- refusal + rollback
def test_an_overpayment_is_refused_rolled_back_and_recorded(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    too_much = o["total"] + 250_000
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": too_much})
    assert r.status_code == 400, r.text
    assert r.json()["detail"]["code"] == "overpayment"

    # the money side is untouched: no payment row, no change to the bill, still open
    now = _order_now(client, cashier, o["id"])
    assert now["payments"] == [] and now["paid_amount"] == 0 and now["remaining"] == o["total"]
    assert now["status"] == "open"

    # …but the attempt is in the audit trail, with who / which bill / how much / which method / why
    rows = _rejections(client, admin, o["number"])
    assert len(rows) == 1, rows
    row = rows[0]
    assert row["user_name"] == "رضا کریمی"
    assert row["created_at"]
    assert row["details"]["amount"] == too_much
    assert row["details"]["method"] == "card"
    assert row["details"]["reason_code"] == "overpayment"
    assert row["details"]["remaining"] == o["total"]
    assert "بیشتر از مانده" in row["details"]["reason"]

    # and the audit row survived the rollback of the payment transaction (independent commit)
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})


def test_a_cash_tender_below_the_amount_is_refused_and_recorded(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"], "tendered": 1_000})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "tendered_too_low"
    rows = _rejections(client, admin, o["number"])
    assert len(rows) == 1
    assert rows[0]["details"]["tendered"] == 1_000 and rows[0]["details"]["reason_code"] == "tendered_too_low"
    assert _order_now(client, cashier, o["id"])["paid_amount"] == 0
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})


def test_paying_a_closed_bill_is_refused_and_recorded(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    assert _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}).status_code == 200
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]})
    assert r.status_code == 400
    rows = _rejections(client, admin, o["number"])
    assert len(rows) == 1 and rows[0]["details"]["reason_code"] in ("order_not_open", "already_paid")
    assert len(_order_now(client, cashier, o["id"])["payments"]) == 1      # the second attempt took no money


# ---------------------------------------------------------------- retry / idempotency
def test_retrying_the_same_request_never_charges_twice_and_never_logs_a_rejection(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    rid = "rejretry0001"
    first = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}, request_id=rid)
    again = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}, request_id=rid)
    assert first.status_code == 200 and again.status_code == 200
    now = _order_now(client, cashier, o["id"])
    assert len(now["payments"]) == 1 and now["paid_amount"] == o["total"]
    assert not _rejections(client, admin, o["number"])           # a replay is not a refusal


def test_a_refused_retry_then_the_correct_amount_succeeds(client, cashier, admin, menu):
    o = _order(client, cashier, menu)
    # cash may be over-tendered (change is given); a card payment above the bill is a real refusal
    assert _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"] + 5_000}).status_code == 400
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]})
    assert r.status_code == 200 and r.json()["status"] == "closed"
    rows = _rejections(client, admin, o["number"])
    assert len(rows) == 1                                        # exactly one refusal, one listed failure
    assert len(r.json()["payments"]) == 1                        # the refusal did not leave a payment behind


# ---------------------------------------------------------------- the audit row is independent of the rollback
def test_a_failure_while_writing_the_audit_row_does_not_record_the_payment(client, cashier, admin, menu, monkeypatch):
    """If the audit write explodes, the refused payment must still be refused (never silently accepted) and the
    API must answer with the original business error — not a 500."""
    from app.modules.orders import service as svc

    o = _order(client, cashier, menu)

    def boom(*a, **k):
        raise RuntimeError("audit store is down")
    monkeypatch.setattr(svc, "log_action", boom)

    r = _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"] + 10_000})
    assert r.status_code == 400, r.text
    assert r.json()["detail"]["code"] == "overpayment"
    monkeypatch.undo()

    now = _order_now(client, cashier, o["id"])
    assert now["payments"] == [] and now["paid_amount"] == 0 and now["status"] == "open"
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})


def test_the_refusal_survives_even_though_the_request_is_rolled_back(client, cashier, admin, menu):
    """Direct proof of the ordering: the same session that failed cannot be the one that loses the audit row."""
    from app.core.db import SessionLocal

    o = _order(client, cashier, menu)
    assert _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"] * 3}).status_code == 400
    with SessionLocal() as db:                                  # a completely separate connection sees the row
        from app.core.models import AuditLog
        rows = db.query(AuditLog).filter(AuditLog.action == "payment.rejected").order_by(AuditLog.id.desc()).limit(20).all()
        assert any(r.entity_id == str(o["id"]) for r in rows)
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})
