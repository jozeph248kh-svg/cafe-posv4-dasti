"""The POS «sitting time» colours read two business settings, so the settings themselves need guards.

Why these tests exist: every busy table on the floor screen turns amber from `pos.table_warn_minutes` and red
from `pos.table_limit_minutes`, and prints the overtime past the limit. If a key stops being registered (or loses
its range check) the shop silently falls back to 60/90 AND a manager could store a nonsense value — 0 minutes
turns every table red instantly, 100 000 makes the colour meaningless. Nobody would notice until a waiter is
looking at a wrong colour during service.
"""

WARN, LIMIT, LEGACY = "pos.table_warn_minutes", "pos.table_limit_minutes", "pos.table_target_minutes"


def test_sitting_settings_are_registered_with_sane_defaults(client, admin):
    from app.core import settings_store

    assert settings_store.DEFAULTS[WARN] == 60
    assert settings_store.DEFAULTS[LIMIT] == 90
    public = client.get("/api/system/settings", headers=admin).json()
    assert (public[WARN], public[LIMIT]) == (60, 90)
    assert public[WARN] < public[LIMIT], "the default warning must come before the limit"


def test_both_values_are_editable_and_survive_a_reload(client, admin):
    saved = {k: client.get("/api/system/settings", headers=admin).json()[k] for k in (WARN, LIMIT)}
    try:
        client.put("/api/system/settings", headers=admin, json={WARN: 45, LIMIT: 75}).raise_for_status()
        now = client.get("/api/system/settings", headers=admin).json()
        assert (now[WARN], now[LIMIT]) == (45, 75)
    finally:
        client.put("/api/system/settings", headers=admin, json=saved).raise_for_status()


def test_nonsense_values_are_rejected_and_never_stored(client, admin):
    saved = {k: client.get("/api/system/settings", headers=admin).json()[k] for k in (WARN, LIMIT)}
    try:
        client.put("/api/system/settings", headers=admin, json={WARN: 45, LIMIT: 75}).raise_for_status()
        for key, bad in ((WARN, 0), (WARN, -5), (WARN, 601), (LIMIT, 0), (LIMIT, 4), (LIMIT, 601)):
            r = client.put("/api/system/settings", headers=admin, json={key: bad})
            assert r.status_code in (400, 422), f"{key}={bad} should be rejected, got {r.status_code} {r.text}"
        for key, wrong_type in ((WARN, "soon"), (LIMIT, True), (LIMIT, None)):
            r = client.put("/api/system/settings", headers=admin, json={key: wrong_type})
            assert r.status_code in (400, 422), f"{key}={wrong_type!r} should be rejected, got {r.status_code}"
        now = client.get("/api/system/settings", headers=admin).json()
        assert (now[WARN], now[LIMIT]) == (45, 75), "a rejected value must not be stored"
    finally:
        client.put("/api/system/settings", headers=admin, json=saved).raise_for_status()


def test_a_warning_above_the_limit_is_allowed_but_the_floor_screen_clamps_it(client, admin):
    """Cross-field validation would be a new rule nobody asked for; the screen clamps instead (see FloorView).

    This test pins the *data* side: both numbers are stored independently, so the UI must not assume warn < limit.
    """
    saved = {k: client.get("/api/system/settings", headers=admin).json()[k] for k in (WARN, LIMIT)}
    try:
        client.put("/api/system/settings", headers=admin, json={WARN: 120, LIMIT: 90}).raise_for_status()
        now = client.get("/api/system/settings", headers=admin).json()
        assert (now[WARN], now[LIMIT]) == (120, 90)
    finally:
        client.put("/api/system/settings", headers=admin, json=saved).raise_for_status()


def test_the_ranges_cover_a_real_cafe():
    from app.core import settings_store

    lo, hi = settings_store.RANGES[LIMIT]
    assert lo >= 5 and hi >= 8 * 60, "a sitting limit must allow at least a full dinner service"
    assert settings_store.RANGES[WARN][0] >= 1
