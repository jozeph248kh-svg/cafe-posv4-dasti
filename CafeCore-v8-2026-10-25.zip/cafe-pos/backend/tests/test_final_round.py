"""Final round: the reviewer's part-2 list, each item with its own reproducing test.

1. taking money is in the audit trail (who, how much, when, and what happened)
2. splitting an order keeps the bill-level discount (see also test_review5.py)
3. a refund corrects Customer.total_spent without double counting and stays consistent with the financial report
4. a refund reaches the central branch server (see also test_review5.py)
5. a duplicate line id in a split request is a clean 400 (see also test_review5.py)
6. secret.key is private, and the code survives the OSes where chmod/open behave differently
"""
import os
import stat

import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _audit(client, admin, q, action=None):
    params = {"q": q, "limit": 50}
    if action:
        params["action"] = action
    return client.get("/api/system/audit", headers=admin, params=params).json()


def _pay(client, h, oid, *payments, **extra):
    return client.post(f"/api/orders/{oid}/payments", headers=h, json={"payments": list(payments), **extra})


# ---------------------------------------------------------------- 1. money in the audit trail
def test_every_tender_is_in_the_audit_trail_with_user_amount_and_time(client, cashier, admin, menu):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 2)]}).json()
    first = 100_000                       # two different amounts, so the two audit rows cannot collide
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": first})
    assert r.status_code == 200, r.text
    rest = r.json()["remaining"]
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": rest, "tendered": rest + 50_000})
    assert r.status_code == 200 and r.json()["status"] == "closed", r.text

    rows = _audit(client, admin, f"#{o['number']}", action="payment.take")
    assert len(rows) == 2, rows                                  # one row per tender, not one per order
    by_amount = {r["details"]["amount"]: r for r in rows}
    assert set(by_amount) == {first, rest}
    assert by_amount[first]["details"]["method"] == "card" and by_amount[rest]["details"]["method"] == "cash"
    for r in rows:
        assert r["user_name"] == "رضا کریمی"                      # who took the money
        assert r["created_at"]                                # when
        assert f"#{o['number']}" in r["summary"]               # which bill
        assert r["action"] == "payment.take"


def test_a_replayed_payment_is_recorded_once(client, cashier, admin, menu):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "104")]}).json()
    rid = "finalpay0001"
    r1 = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}, request_id=rid)
    r2 = _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}, request_id=rid)
    assert r1.status_code == 200 and r2.status_code == 200
    o2 = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert len(o2["payments"]) == 1 and o2["paid_amount"] == o["total"]      # the retry did not charge twice
    assert len(_audit(client, admin, f"#{o['number']}", action="payment.take")) == 1


def test_a_refused_tender_writes_no_payment_and_no_audit_row(client, cashier, admin, menu):
    """Today a rejected tender leaves no trace (see decision D7 in the report) — this test pins today's
    behaviour so a future change is a conscious one, and proves no phantom money is recorded."""
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "104")]}).json()
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"] + 10_000})
    assert r.status_code == 400
    after = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert after["payments"] == [] and after["paid_amount"] == 0 and after["status"] == "open"
    assert not [x for x in _audit(client, admin, f"#{o['number']}", action="payment.take")
                if x["details"].get("amount") == o["total"] + 10_000]


def test_a_refund_is_in_the_audit_trail_with_its_approver(client, cashier, mgr, admin, menu):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "104")]}).json()
    assert _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}).status_code == 200
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={"method": "cash", "amount": 50_000, "reason": "مرجوعی"})
    assert r.status_code == 200, r.text
    rows = _audit(client, admin, f"#{o['number']}", action="payment.refund")
    assert rows and rows[0]["details"]["amount"] == 50_000 and rows[0]["user_name"] == "سارا احمدی"


# ---------------------------------------------------------------- 3. total_spent after a refund
def _customer(client, h, phone):
    return next((c for c in client.get("/api/customers", headers=h, params={"q": phone}).json() if c["phone"] == phone), None)


def test_customer_spend_follows_refunds_and_matches_the_books(client, cashier, mgr, menu):
    phone = "09127654321"
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "customer_name": "آزمون بازپرداخت", "customer_phone": phone,
                          "lines": [line(menu, "101", 3)]}).json()
    assert _pay(client, cashier, o["id"], {"method": "cash", "amount": o["total"]}).status_code == 200
    c = _customer(client, mgr, phone)
    assert c["total_spent"] == o["total"] and c["visits"] == 1

    # first refund: 40% of the bill
    part = round(o["total"] * 0.4)
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                       json={"method": "cash", "amount": part, "reason": "مرجوعی ۱"}).status_code == 200
    assert _customer(client, mgr, phone)["total_spent"] == o["total"] - part

    # second refund: the rest → the customer spent nothing, and the number never goes below zero
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                       json={"method": "cash", "amount": o["total"] - part, "reason": "مرجوعی ۲"}).status_code == 200
    assert _customer(client, mgr, phone)["total_spent"] == 0
    # a third refund beyond what was paid is refused and changes nothing
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                       json={"method": "cash", "amount": 1_000, "reason": "اضافه"}).status_code == 400
    assert _customer(client, mgr, phone)["total_spent"] == 0

    # independent recomputation from the order history of that phone
    hist_resp = client.get("/api/orders", headers=mgr, params={"q": phone, "size": 200})
    assert hist_resp.status_code == 200, hist_resp.text[:400]
    hist = hist_resp.json()["items"]
    assert [row["id"] for row in hist] == [o["id"]]        # the phone number really is found by the search
    net = 0
    for row in hist:
        full = client.get(f"/api/orders/{row['id']}", headers=mgr).json()
        if full["status"] != "closed":
            continue
        net += sum(p["amount"] for p in full["payments"])                  # refunds are negative payments
    assert net == 0                                           # nothing was actually spent → matches total_spent


# ---------------------------------------------------------------- 6. secret.key across OSes
def test_secret_key_is_created_private(tmp_path):
    from app.core.config import Settings

    s = Settings(data_dir=tmp_path, secret_key=None)
    key = s.jwt_secret()
    p = tmp_path / "secret.key"
    assert p.read_text().strip() == key and len(key) > 30
    if os.name != "nt":
        assert stat.S_IMODE(p.stat().st_mode) == 0o600


def test_an_existing_loose_key_is_tightened_and_still_works(tmp_path):
    from app.core.config import Settings

    p = tmp_path / "secret.key"
    p.write_text("legacy-key-value")
    os.chmod(p, 0o644)
    s = Settings(data_dir=tmp_path, secret_key=None)
    assert s.jwt_secret() == "legacy-key-value"
    if os.name != "nt":
        assert stat.S_IMODE(p.stat().st_mode) == 0o600


def test_a_filesystem_that_refuses_chmod_does_not_break_login(tmp_path, monkeypatch):
    """Windows / a read-only mount: tightening the mode may fail — reading the key must still work."""
    from app.core.config import Settings

    p = tmp_path / "secret.key"
    p.write_text("key-on-an-odd-filesystem")
    os.chmod(p, 0o644)

    def boom(*a, **k):
        raise PermissionError("not supported here")
    monkeypatch.setattr(os, "chmod", boom)
    assert Settings(data_dir=tmp_path, secret_key=None).jwt_secret() == "key-on-an-odd-filesystem"


def test_two_workers_created_at_once_agree_on_the_key(tmp_path, monkeypatch):
    """O_EXCL loses the race for the second process — it must read the winner's key, not crash."""
    from app.core.config import Settings

    s = Settings(data_dir=tmp_path, secret_key=None)
    key = s.jwt_secret()
    (tmp_path / "secret.key").unlink()
    real_open = os.open
    state = {"first": True}

    def racing_open(path, flags, mode=0o777, **kw):
        if state["first"]:                    # another worker writes the file between exists() and open()
            state["first"] = False
            (tmp_path / "secret.key").write_text(key)
        return real_open(path, flags, mode, **kw)
    monkeypatch.setattr(os, "open", racing_open)
    assert Settings(data_dir=tmp_path, secret_key=None).jwt_secret() == key


def test_order_search_by_phone_works_on_every_backend(client, cashier, mgr, menu):
    """PG-01: a phone number is all digits — on PostgreSQL an 11-digit value overflowed `orders.number`
    (32-bit) and the whole search answered 422, so orders could not be found by phone at all."""
    phone = "09121112233"
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "customer_name": "جستجوی تلفن", "customer_phone": phone,
                          "lines": [line(menu, "104")]}).json()
    try:
        for q, expect in ((phone, o["id"]), ("0912", o["id"]), (str(o["number"]), o["id"])):
            r = client.get("/api/orders", headers=mgr, params={"q": q, "size": 50})
            assert r.status_code == 200, (q, r.text[:200])
            assert o["id"] in [row["id"] for row in r.json()["items"]], q
        # a number that cannot be an order number must not blow up either
        r = client.get("/api/orders", headers=mgr, params={"q": "999999999999999999999"})
        assert r.status_code == 200 and r.json()["items"] == []
    finally:
        client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
