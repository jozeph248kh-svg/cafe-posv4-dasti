"""Network thermal printers: config validation, ESC/POS raster bytes received by a fake TCP printer, errors."""
import base64
import socket
import threading

from app.core import escpos
from tests.conftest import _login


class FakePrinter:
    """Accepts TCP connections and records every byte (like a printer on port 9100)."""
    def __init__(self):
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        self.jobs: list[bytes] = []
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while True:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            buf = b""
            with c:
                while chunk := c.recv(65536):
                    buf += chunk
            self.jobs.append(buf)

    def close(self):
        self.sock.close()


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _wait(fp, n):
    import time
    for _ in range(100):
        if len(fp.jobs) >= n:
            return
        time.sleep(0.02)


def test_raster_job_layout():
    data = bytes([0xFF, 0x00] * 300)               # 16 px wide (2 bytes/row) × 300 rows → 2 bands (256 + 44)
    out = escpos.raster_job(16, 300, data, drawer=True, copies=2)
    assert out.startswith(escpos.INIT + escpos.DRAWER)
    one = out[len(escpos.INIT + escpos.DRAWER):]
    assert one[:len(one) // 2] == one[len(one) // 2:]             # two identical copies
    job = one[:len(one) // 2]
    assert job.startswith(escpos.INIT) and job.endswith(escpos.CUT)
    h1 = escpos.GS + b"v0" + bytes([0, 2, 0, 0, 1])               # 256 rows
    h2 = escpos.GS + b"v0" + bytes([0, 2, 0, 44, 0])
    i1, i2 = job.index(h1), job.index(h2)
    assert job[i1 + 8:i1 + 8 + 512] == data[:512] and job[i2 + 8:i2 + 8 + 88] == data[512:]
    for bad in [(15, 300, data), (16, 0, b""), (16, 300, data[:-1])]:
        try:
            escpos.raster_job(*bad)
            raise AssertionError("accepted a bad raster")
        except ValueError:
            pass


def test_printers_config_and_print(client, admin, cashier, waiter):
    fp = FakePrinter()
    try:
        base = {"name": "صندوق", "host": "127.0.0.1", "port": fp.port, "width": 384, "receipt": True, "drawer": True}
        # only settings.manage can configure; validation of host / width / duplicates
        assert client.put("/api/system/printers", headers=cashier, json={"printers": [{"id": 1, **base}]}).status_code == 403
        assert client.put("/api/system/printers", headers=admin, json={"printers": [{"id": 1, **base, "host": "bad host;rm"}]}).status_code == 422
        assert client.put("/api/system/printers", headers=admin, json={"printers": [{"id": 1, **base, "width": 500}]}).status_code == 422
        r = client.put("/api/system/printers", headers=admin, json={"printers": [{"id": 1, **base}, {"id": 1, **base, "name": "x"}]})
        assert r.status_code == 400 and r.json()["detail"]["code"] == "duplicate"
        dead = _free_port()
        r = client.put("/api/system/printers", headers=admin, json={"printers": [
            {"id": 1, **base}, {"id": 2, "name": "آشپزخانه", "host": "127.0.0.1", "port": dead, "width": 576, "station_ids": [1]}]})
        assert r.status_code == 200 and r.json()[1]["receipt"] is False
        # the generic settings endpoint can't overwrite it
        client.put("/api/system/settings", headers=admin, json={"print.printers": []})
        assert len(client.get("/api/system/printers", headers=waiter).json()) == 2

        # test page
        assert client.post("/api/system/printers/1/test", headers=waiter).status_code == 403
        assert client.post("/api/system/printers/1/test", headers=admin).status_code == 200
        _wait(fp, 1)
        assert fp.jobs[0].startswith(escpos.INIT) and b"printer test OK" in fp.jobs[0] and fp.jobs[0].endswith(escpos.CUT)

        # a browser-rendered raster from any logged-in device
        rows = bytes([0b10000001] * 48) * 10             # 384 px = 48 bytes/row, 10 rows
        body = {"printer_id": 1, "width": 384, "height": 10, "data": base64.b64encode(rows).decode(), "drawer": True}
        r = client.post("/api/system/print", headers=cashier, json=body)
        assert r.status_code == 200, r.text
        _wait(fp, 2)
        assert fp.jobs[1] == escpos.raster_job(384, 10, rows, drawer=True)
        # drawer kick is ignored for a printer without a drawer; wrong width / bad data / unknown printer
        assert client.post("/api/system/print", headers=cashier, json={**body, "width": 576}).json()["detail"]["code"] == "bad_raster"
        assert client.post("/api/system/print", headers=cashier, json={**body, "height": 11}).json()["detail"]["code"] == "bad_raster"
        assert client.post("/api/system/print", headers=cashier, json={**body, "data": "!!notbase64"}).status_code == 422
        assert client.post("/api/system/print", headers=cashier, json={**body, "printer_id": 99}).status_code == 404
        # printer off → clear error, not a 500 and not a hang
        r = client.post("/api/system/print", headers=cashier, json={**body, "printer_id": 2, "width": 576,
                                                                       "data": base64.b64encode(bytes(72 * 10)).decode()})
        assert r.status_code == 502 and r.json()["detail"]["code"] == "printer_unreachable" and "آشپزخانه" in r.json()["detail"]["message"]
        assert client.post("/api/system/print", json=body).status_code == 401
    finally:
        fp.close()
        client.put("/api/system/printers", headers=_login(client, "admin", "admin123"), json={"printers": []})
