"""The read-only audit script for «cancelled bills that carry money».

The API makes this shape impossible (a bill with payments cannot be cancelled, a bill that is not closed cannot be
refunded), so it can only arrive from an old or imported database. The script's whole job is to *look* — these tests
pin two things: it finds the suspicious rows, and it changes nothing while doing so.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest
from conftest import _login, close_register

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "qa" / "audit_cancelled_refunds.py"
ON_PG = bool(os.environ.get("CAFE_TEST_DATABASE_URL"))


def _copy_db(dest: Path) -> Path:
    """A consistent copy of the suite's SQLite database (the backup API, not a file copy — WAL safe)."""
    from app.core.backup import sqlite_path

    src = sqlite_path()
    a = sqlite3.connect(src)
    b = sqlite3.connect(dest)
    try:
        a.backup(b)
    finally:
        b.close()
        a.close()
    return dest


@pytest.fixture(scope="module", autouse=True)
def _cleanup(client, admin):
    yield
    close_register(client, admin)


def _make_suspicious(path: Path) -> int:
    """Attach a refund to one real bill and cancel that bill behind the API's back. Returns the refund amount."""
    con = sqlite3.connect(path)
    try:
        row = con.execute("SELECT id, paid_amount FROM orders WHERE status='closed' AND paid_amount > 0 "
                          "ORDER BY id LIMIT 1").fetchone()
        assert row, "the suite database has no closed paid bill to work with"
        oid, paid = row
        amount = min(int(paid), 25_000)
        con.execute("INSERT INTO payments (order_id, method, amount, change, is_refund, note, created_at) "
                    "VALUES (?, 'cash', ?, 0, 1, 'legacy import', datetime('now'))", (oid, -amount))
        con.execute("UPDATE orders SET status='cancelled', paid_amount = paid_amount - ? WHERE id = ?", (amount, oid))
        con.commit()
        return amount
    finally:
        con.close()


def _run(args):
    env = {k: v for k, v in os.environ.items() if not k.startswith("CAFE_")}
    return subprocess.run([sys.executable, str(SCRIPT), *args], capture_output=True, text=True, env=env, timeout=180)


def _paid_bill(client, admin, cashier) -> dict:
    """One real closed+paid bill, so the copy has something to attach the legacy refund to."""
    mgr = _login(client, "sara", "manager123")
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    menu = client.get("/api/menu/full", headers=admin).json()
    item = next(i for i in menu["items"] if i["price"] > 0)
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


@pytest.mark.skipif(ON_PG, reason="builds a SQLite copy of the database")
def test_the_audit_finds_a_cancelled_bill_carrying_a_refund_and_changes_nothing(client, admin, cashier, tmp_path):
    _paid_bill(client, admin, cashier)
    db = _copy_db(tmp_path / "cafe.db")
    amount = _make_suspicious(db)
    before = db.read_bytes(), db.stat().st_mtime_ns

    out = _run(["--db", str(db)])
    assert out.returncode == 1, out.stdout + out.stderr
    assert "cancelled bills that still carry REFUND payments" in out.stdout
    assert f"{amount:,}" in out.stdout
    assert "Nothing was modified" in out.stdout

    after = db.read_bytes(), db.stat().st_mtime_ns
    assert after == before, "the audit script modified the database it was only supposed to read"

    data = json.loads(_run(["--db", str(db), "--json"]).stdout)
    assert data["refunds_on_cancelled"], data
    assert data["refunds_on_cancelled"][0]["refund_sum"] == -amount
    assert data["by_day"], "the per-day size of the distortion must be reported"


@pytest.mark.skipif(ON_PG, reason="builds a SQLite copy of the database")
def test_the_audit_says_clean_on_an_untouched_database(client, admin, cashier, tmp_path):
    _paid_bill(client, admin, cashier)                       # a normal, healthy bill
    db = _copy_db(tmp_path / "clean.db")
    out = _run(["--db", str(db)])
    assert out.returncode == 0, out.stdout + out.stderr
    assert "clean — no cancelled bill carries money" in out.stdout


@pytest.mark.skipif(ON_PG, reason="builds a SQLite copy of the database")
def test_the_audit_refuses_a_missing_database_instead_of_crashing(tmp_path):
    out = _run(["--db", str(tmp_path / "nope.db")])
    assert out.returncode == 2 and "database not found" in out.stderr


@pytest.mark.skipif(not ON_PG, reason="PostgreSQL run only")
def test_the_audit_runs_read_only_on_postgresql():
    """The same script must work on PostgreSQL, inside a READ ONLY transaction."""
    url = os.environ["CAFE_TEST_DATABASE_URL"]
    out = _run(["--url", url, "--json"])
    assert out.returncode == 0, out.stderr[:500]
    data = json.loads(out.stdout)
    assert "refunds_on_cancelled" in data and "totals" in data
    # the suite database is created through the API, so it must be clean
    assert data["refunds_on_cancelled"] == []
