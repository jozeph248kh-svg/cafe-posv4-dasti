"""Money and stock correctness with hand-calculated expectations.

Pricing policy (documented in README):
  subtotal  = Σ active lines (unit price incl. modifiers × qty)
  discount  = percent of subtotal (rounded) or fixed amount (capped at subtotal)
  service   = (subtotal − discount) × service% — dine-in only
  tax       = (subtotal − discount + service) × tax%
  total     = round_to_step(subtotal − discount + service + tax)
All amounts are integer TOMAN; the card reader receives RIAL (×10).
"""
import pytest
from conftest import _login, close_register


@pytest.fixture(scope="module", autouse=True)
def _leave_register_closed(client, admin):
    """Other test files expect no open cash shift; close the one these tests open."""
    yield
    close_register(client, admin)


@pytest.fixture()
def pricing(client, admin):
    old = client.get("/api/system/settings", headers=admin).json()
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    yield lambda **kw: client.put("/api/system/settings", headers=admin, json=kw).raise_for_status()
    client.put("/api/system/settings", headers=admin, json={k: old[k] for k in keys})


@pytest.fixture()
def item(client, admin):
    """A fresh menu item with a known price and no modifiers."""
    cats = client.get("/api/menu/categories", headers=admin).json()
    counter = item.n = getattr(item, "n", 0) + 1
    r = client.post("/api/menu/items", headers=admin, json={"category_id": cats[0]["id"], "name": f"آیتم تست مالی {counter}",
                                                            "code": f"T9{counter:02d}", "price": 123_457})
    assert r.status_code == 201, r.text
    return r.json()


def _shift(client, h):
    client.post("/api/shifts/open", json={"opening_cash": 0}, headers=h)


def _free_table(client, h):
    return next(t for a in client.get("/api/orders/floor", headers=h).json() for t in a["tables"] if t["status"] == "free")


def _pay(client, h, oid, *payments, **extra):
    return client.post(f"/api/orders/{oid}/payments", headers=h, json={"payments": list(payments), **extra})


def test_total_formula_dine_in(client, cashier, pricing, item):
    pricing(**{"tax.enabled": True, "tax.percent": 9, "service.enabled": True, "service.percent": 10, "rounding.step": 1000})
    t = _free_table(client, cashier)
    o = client.post("/api/orders", headers=cashier, json={"type": "dine_in", "table_id": t["id"],
                                                          "lines": [{"menu_item_id": item["id"], "qty": 3}]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=_login(client, "sara", "manager123"),
                    json={"type": "percent", "value": 15, "reason": "تست"}).json()
    subtotal = 123_457 * 3                                  # 370371
    discount = round(subtotal * 15 / 100)                   # 55556
    base = subtotal - discount                              # 314815
    service = round(base * 10 / 100)                        # 31482 (dine-in)
    tax = round((base + service) * 9 / 100)                 # 31167
    raw = base + service + tax                              # 377464
    total = round(raw / 1000) * 1000                        # 377000
    assert (o["subtotal"], o["discount_amount"], o["service_amount"], o["tax_amount"], o["total"]) == (subtotal, discount, service, tax, total)
    assert o["rounding"] == total - raw
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})


def test_takeaway_has_no_service_and_amount_discount_is_capped(client, cashier, pricing, item):
    pricing(**{"tax.enabled": True, "tax.percent": 10, "service.enabled": True, "service.percent": 10, "rounding.step": 0})
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    assert o["service_amount"] == 0 and o["tax_amount"] == round(123_457 * 0.10) and o["total"] == 123_457 + round(123_457 * 0.10)
    mgr = _login(client, "sara", "manager123")
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr, json={"type": "amount", "value": 999_999_999, "reason": "تست سقف"}).json()
    assert o["discount_amount"] == 123_457 and o["total"] == 0          # never negative
    client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


def test_payment_rules(client, cashier, pricing, item):
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 2}]}).json()
    total = 246_914
    assert o["total"] == total
    # card above the remaining amount is refused (would be an unreal overpayment)
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": total + 1})
    assert r.status_code == 400
    # cash tendered below the amount is refused
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": 100_000, "tendered": 50_000})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "tendered_too_low"
    # split: card 100,000 + cash rest with change
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": 100_000})
    assert r.status_code == 200 and r.json()["status"] == "open" and r.json()["paid_amount"] == 100_000
    r = _pay(client, cashier, o["id"], {"method": "cash", "amount": 200_000, "tendered": 200_000})
    o2 = r.json()
    assert o2["status"] == "closed" and o2["paid_amount"] == total
    cash = next(p for p in o2["payments"] if p["method"] == "cash")
    assert cash["amount"] == total - 100_000 and cash["change"] == 200_000 - (total - 100_000)
    # a paid (closed) order cannot be paid again
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": 1000})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "order_not_open"
    # nor cancelled
    r = client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "x تست"})
    assert r.status_code == 400


def test_refunds_are_bounded_authorised_and_audited(client, cashier, admin, pricing, item):
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    _pay(client, cashier, o["id"], {"method": "card", "amount": 123_457})
    body = {"method": "card", "amount": 50_000, "reason": "برگشت مشتری"}
    r = client.post(f"/api/orders/{o['id']}/refund", headers=cashier, json=body)
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"     # cashier needs a manager
    r = client.post(f"/api/orders/{o['id']}/refund", headers={**cashier, "X-Manager-Pin": "2222"}, json={**body, "request_id": "refund-dup-01"})
    assert r.status_code == 200 and r.json()["paid_amount"] == 73_457
    r = client.post(f"/api/orders/{o['id']}/refund", headers={**cashier, "X-Manager-Pin": "2222"}, json={**body, "request_id": "refund-dup-01"})
    assert r.json()["paid_amount"] == 73_457                                                 # retry is idempotent
    r = client.post(f"/api/orders/{o['id']}/refund", headers={**cashier, "X-Manager-Pin": "2222"}, json={**body, "amount": 80_000})
    assert r.status_code == 400                                                              # more than what is left
    logs = client.get("/api/system/audit", headers=admin, params={"action": "payment.refund"}).json()
    entries = [x for x in logs if f"#{o['number']} " in x["summary"]]
    assert len(entries) == 1                                                                 # replay not logged twice
    e = entries[0]
    assert "50,000" in e["summary"] and "برگشت مشتری" in e["summary"]
    assert e["user_name"] and e["approver_name"] and e["created_at"]


def test_failed_payment_leaves_no_trace(client, admin, cashier, pricing, item):
    """Split payment where the 2nd leg fails (wallet without a customer): the valid card leg must NOT be stored,
    the order stays open and no stock is consumed – the whole request is one transaction."""
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    moves_before = len(client.get("/api/inventory/movements", headers=admin, params={"limit": 1000}).json())
    r = _pay(client, cashier, o["id"], {"method": "card", "amount": 100_000}, {"method": "wallet", "amount": 23_457})
    assert r.status_code == 400, r.text
    after = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert after["status"] == "open" and after["paid_amount"] == 0 and after["payments"] == []
    assert len(client.get("/api/inventory/movements", headers=admin, params={"limit": 1000}).json()) == moves_before
    # and a normal payment still works afterwards
    assert _pay(client, cashier, o["id"], {"method": "card", "amount": 123_457}).json()["status"] == "closed"


def test_inventory_end_to_end_weighted_cost_and_single_deduction(client, admin, cashier, pricing, item):
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    ing = client.post("/api/inventory/ingredients", headers=admin, json={"name": "قهوه تست مالی", "unit": "g", "min_stock": 100,
                                                                         "cost_per_unit": 0, "opening_stock": 0}).json()
    # two purchases at different prices → weighted average cost
    for qty, cost in ((1000, 10.0), (3000, 14.0)):
        r = client.post("/api/inventory/purchases", headers=admin, json={"purchase_date": "2026-10-01",
                                                                         "lines": [{"ingredient_id": ing["id"], "qty": qty, "unit_cost": cost}]})
        assert r.status_code == 201
    ing = next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])
    assert ing["stock"] == 4000 and ing["cost_per_unit"] == pytest.approx((1000 * 10 + 3000 * 14) / 4000)   # 13.0
    # recipe: 18 g per item
    assert client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin, json=[{"ingredient_id": ing["id"], "qty": 18}]).status_code == 200
    # sell 3 → 54 g consumed exactly once, linked to the order, valued at average cost
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 3}], "send": True}).json()
    # a cancelled order consumes nothing
    o2 = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 5}]}).json()
    client.post(f"/api/orders/{o2['id']}/cancel", headers={**cashier, "X-Manager-Pin": "2222"}, json={"reason": "مشتری منصرف شد"})
    _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"]})
    ing = next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])
    assert ing["stock"] == 4000 - 54
    moves = [m for m in client.get("/api/inventory/movements", headers=admin, params={"ingredient_id": ing["id"]}).json()
             if m["kind"] == "sale"]
    assert len(moves) == 1 and moves[0]["qty"] == -54 and moves[0]["ref_id"] == o["id"] and moves[0]["unit_cost"] == pytest.approx(13.0)
    # emitting the close event again must not consume twice
    from app.core import events
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order
    with SessionLocal() as db:
        order = db.get(Order, o["id"])
        events.emit("order.closed", db=db, order=order, user=order.creator if hasattr(order, "creator") else None)
        db.commit()
    ing = next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])
    assert ing["stock"] == 4000 - 54
    # waste is recorded and reduces stock; bad quantities are refused
    assert client.post(f"/api/inventory/ingredients/{ing['id']}/adjust", headers=admin, json={"kind": "waste", "qty": 46, "note": "ریخت"}).status_code == 200
    assert client.post(f"/api/inventory/ingredients/{ing['id']}/adjust", headers=admin, json={"kind": "adjust", "qty": "inf"}).status_code in (400, 422)
    ing = next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])
    assert ing["stock"] == 3900


def test_sales_report_reconciles_with_known_orders(client, admin, cashier, pricing, item):
    """Report deltas must equal the hand-computed effect of a known batch of orders (closed, cancelled, refunded)."""
    pricing(**{"tax.enabled": True, "tax.percent": 10, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)

    def summary():
        r = client.get("/api/reports/sales", headers=admin).json()
        pays = {p["method"]: p["amount"] for p in r["by_payment"]}
        it = next((i for i in r["by_item"] if i["id"] == item["id"]), {"qty": 0, "revenue": 0})
        return r["summary"], pays, it

    s0, p0, i0 = summary()
    unit_tax = round(123_457 * 0.10)
    # A: 2 items, card, closed
    a = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 2}]}).json()
    _pay(client, cashier, a["id"], {"method": "card", "amount": a["total"]})
    # B: 1 item, cash, closed, then 20,000 refunded
    b = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    _pay(client, cashier, b["id"], {"method": "cash", "amount": b["total"], "tendered": b["total"]})
    client.post(f"/api/orders/{b['id']}/refund", headers={**cashier, "X-Manager-Pin": "2222"}, json={"method": "cash", "amount": 20_000, "reason": "برگشت"})
    # C: cancelled → not in sales
    c = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 4}]}).json()
    client.post(f"/api/orders/{c['id']}/cancel", headers={**cashier, "X-Manager-Pin": "2222"}, json={"reason": "لغو تست"})

    s1, p1, i1 = summary()
    assert a["total"] == 2 * 123_457 + round(2 * 123_457 * 0.10) and b["total"] == 123_457 + unit_tax
    assert s1["orders"] - s0["orders"] == 2
    assert s1["gross"] - s0["gross"] == 3 * 123_457
    assert s1["tax"] - s0["tax"] == a["tax_amount"] + b["tax_amount"]
    assert s1["net"] - s0["net"] == a["total"] + b["total"]
    assert s1["refunds"] - s0["refunds"] == 20_000
    assert s1["cancelled"] - s0["cancelled"] == 1
    assert p1.get("card", 0) - p0.get("card", 0) == a["total"]
    assert p1.get("cash", 0) - p0.get("cash", 0) == b["total"] - 20_000           # by_payment is net of refunds
    assert i1["qty"] - i0["qty"] == 3 and i1["revenue"] - i0["revenue"] == 3 * 123_457


def test_refund_is_reported_on_the_day_it_is_paid_out(client, admin, cashier, pricing, item):
    """Yesterday's order refunded today: today's report shows the refund, yesterday's closed figures don't change."""
    from datetime import timedelta

    from app.core.db import SessionLocal
    from app.modules.orders.models import Order
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    _pay(client, cashier, o["id"], {"method": "card", "amount": 123_457})
    with SessionLocal() as db:                                    # pretend the sale happened yesterday
        row = db.get(Order, o["id"])
        row.business_date = row.business_date - timedelta(days=1)
        yday = row.business_date
        for p in row.payments:
            p.created_at = p.created_at - timedelta(days=1)
        db.commit()
    today = yday + timedelta(days=1)
    rep = lambda d: client.get("/api/reports/sales", headers=admin, params={"date_from": d, "date_to": d}).json()
    y0, t0 = rep(yday), rep(today)
    pnl0 = client.get("/api/expenses/pnl", headers=admin, params={"date_from": today, "date_to": today}).json()
    r = client.post(f"/api/orders/{o['id']}/refund", headers={**cashier, "X-Manager-Pin": "2222"},
                    json={"method": "card", "amount": 30_000, "reason": "برگشت روز بعد"})
    assert r.status_code == 200
    y1, t1 = rep(yday), rep(today)
    assert y1["summary"] == y0["summary"] and y1["by_payment"] == y0["by_payment"]        # closed day unchanged
    assert t1["summary"]["refunds"] - t0["summary"]["refunds"] == 30_000
    card = lambda r: next((p["amount"] for p in r["by_payment"] if p["method"] == "card"), 0)
    assert card(t0) - card(t1) == 30_000
    pnl1 = client.get("/api/expenses/pnl", headers=admin, params={"date_from": today, "date_to": today}).json()
    assert pnl0["revenue"] - pnl1["revenue"] == 30_000 and pnl1["sales"]["refunds"] - pnl0["sales"]["refunds"] == 30_000


def test_refund_returns_selected_items_to_stock(client, cashier, admin, pricing, item):
    """A refund may hand items back: their recipe goes back into stock once, never more than was sold."""
    pricing(**{"tax.enabled": False, "service.enabled": False, "rounding.step": 0})
    _shift(client, cashier)
    ing = client.post("/api/inventory/ingredients", headers=admin, json={"name": "شیشه نوشابه تست برگشت", "unit": "pcs", "min_stock": 0,
                                                                         "cost_per_unit": 0, "opening_stock": 50}).json()
    assert client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin, json=[{"ingredient_id": ing["id"], "qty": 2}]).status_code == 200
    stock = lambda: next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])["stock"]  # noqa: E731
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 3}]}).json()
    _pay(client, cashier, o["id"], {"method": "card", "amount": o["total"]})
    assert stock() == 50 - 6
    line = o["lines"][0]["id"]
    mgr = {**cashier, "X-Manager-Pin": "2222"}
    body = {"method": "card", "amount": 123_457, "reason": "نوشابه باز نشده"}
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={**body, "restock": [{"line_id": line, "qty": 4}]})
    assert r.status_code == 400 and stock() == 44                                         # more than sold → nothing happens
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={**body, "restock": [{"line_id": 999_999, "qty": 1}]})
    assert r.status_code == 400
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={**body, "request_id": "restock-once-1", "restock": [{"line_id": line, "qty": 1}]})
    assert r.status_code == 200 and r.json()["lines"][0]["returned_qty"] == 1 and stock() == 46
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={**body, "request_id": "restock-once-1", "restock": [{"line_id": line, "qty": 1}]})
    assert r.status_code == 200 and stock() == 46                                         # replay: not restocked twice
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={**body, "restock": [{"line_id": line, "qty": 3}]})
    assert r.status_code == 400                                                           # only 2 left to return
    moves = [m for m in client.get("/api/inventory/movements", headers=admin, params={"ingredient_id": ing["id"]}).json() if m["kind"] == "return"]
    assert len(moves) == 1 and moves[0]["qty"] == 2 and f"#{o['number']}" in moves[0]["note"]


def test_purchase_units_convert_to_stock_units(client, admin):
    """Bought by the carton / kilo, stocked and costed in grams; the server resolves the factor (never the client)."""
    body = {"name": "شکر تست واحد", "unit": "g", "min_stock": 0, "cost_per_unit": 0, "opening_stock": 0,
            "purchase_units": [{"name": " کارتن ", "factor": 12000}]}
    r = client.post("/api/inventory/ingredients", headers=admin, json=body)
    assert r.status_code == 201, r.text
    ing = r.json()
    assert ing["purchase_units"] == [{"name": "کارتن", "factor": 12000}]
    assert [u["name"] for u in ing["unit_options"]] == ["گرم", "کیلوگرم", "کارتن"]
    dup = {**body, "name": "شکر تکراری", "purchase_units": [{"name": "کیلوگرم", "factor": 900}]}
    assert client.post("/api/inventory/ingredients", headers=admin, json=dup).status_code == 422
    buy = lambda lines: client.post("/api/inventory/purchases", headers=admin, json={"purchase_date": "2026-10-01", "lines": lines})  # noqa: E731
    r = buy([{"ingredient_id": ing["id"], "qty": 2, "total": 4_800_000, "purchase_unit": "کارتن"},
             {"ingredient_id": ing["id"], "qty": 1.5, "unit_cost": 300_000, "purchase_unit": "کیلوگرم"},
             {"ingredient_id": ing["id"], "qty": 500, "unit_cost": 100}])                       # old format: stock unit
    assert r.status_code == 201, r.text
    p = r.json()
    assert p["total"] == 4_800_000 + 450_000 + 50_000
    l1, l2, l3 = p["lines"]
    assert (l1["qty"], l1["unit_cost"], l1["purchase_unit"], l1["pu_qty"], l1["pu_price"]) == (24_000, 200, "کارتن", 2, 2_400_000)
    assert (l2["qty"], l2["unit_cost"], l2["purchase_unit"]) == (1500, 300, "کیلوگرم")
    assert l3["purchase_unit"] is None and l3["qty"] == 500
    got = next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == ing["id"])
    assert got["stock"] == 26_000 and round(got["cost_per_unit"], 4) == round(5_300_000 / 26_000, 4)
    r = buy([{"ingredient_id": ing["id"], "qty": 1, "unit_cost": 10, "purchase_unit": "پالت"}])
    assert r.status_code == 422 and r.json()["detail"]["code"] == "unit_unknown"
    assert buy([{"ingredient_id": ing["id"], "qty": 1}]).status_code == 422                      # no price
    # editing without purchase_units (older client) keeps them
    upd = {k: got[k] for k in ("name", "unit", "category", "min_stock", "cost_per_unit", "is_active")}
    assert client.put(f"/api/inventory/ingredients/{ing['id']}", headers=admin, json=upd).json()["purchase_units"][0]["name"] == "کارتن"
    client.put(f"/api/inventory/ingredients/{ing['id']}", headers=admin, json={**upd, "is_active": False})


def test_every_tender_is_in_the_audit_trail(client, admin, cashier, menu):
    """A cash business must be able to answer "who took this money, when, on which shift" from the
    audit log alone (the zapper/forensics check). Payments used to be the one thing missing from it."""
    from tests.conftest import close_register, line as make_line
    close_register(client, admin)
    client.post("/api/shifts/open", headers=cashier, json={"opening_cash": 0})
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [make_line(menu, "101", 1)]}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    trail = client.get("/api/system/audit", headers=admin, params={"action": "payment"}).json()
    takes = [a for a in trail if a["action"] == "payment.take" and f"#{o['number']}" in a["summary"]]
    assert takes, [a["action"] for a in trail][:10]
    assert takes[0]["user_name"] and "نقد" in takes[0]["summary"]
    assert takes[0]["details"]["amount"] == o["total"]
    close_register(client, admin)
