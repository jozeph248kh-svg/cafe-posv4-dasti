"""The restore drill and the failure modes of backup/restore.

The point of these tests is the rule the owner set: **a backup file existing is not success — the data must come
back**. Every drill here restores into an isolated scratch target (a temp file for SQLite, a throw-away database for
PostgreSQL) and compares the key figures with the manifest written when the backup was taken. The live database is
checked to be byte-for-byte untouched after every drill.

Also covered: missing disk space, unreadable folder, corrupt file, two backups at once, a lock left behind by a
killed process, the 24-hour staleness warning, and the guarantee that rotation never deletes the last good backup.
"""
import json
import os
import stat
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest

from app.core import backup as bk
from app.core.config import get_settings

ON_PG = bool(os.environ.get("CAFE_TEST_DATABASE_URL"))
sqlite_only = pytest.mark.skipif(ON_PG, reason="SQLite file backup")
pg_only = pytest.mark.skipif(not ON_PG, reason="PostgreSQL dump backup")

# ─────────────────────────────────────────────────────────────── helpers


@pytest.fixture(scope="module")
def mgr(client):
    """A manager token (refunds need the manager permission)."""
    from conftest import _login
    return _login(client, "sara", "manager123")


def _live_digest() -> tuple[int, int, str]:
    """(size, mtime_ns, sha256) of the live SQLite database — proves a drill changed nothing."""
    p = bk.sqlite_path()
    if not p or not p.exists():
        return (0, 0, "")
    return (p.stat().st_size, p.stat().st_mtime_ns, bk._sha256(p))


def _seed_sale(client, cashier, admin) -> dict:
    """One real paid order so the drill has money to compare (counts alone would be a weak check)."""
    if not client.get("/api/shifts/current", headers=cashier).json():
        client.post("/api/shifts/open", headers=cashier, json={"opening_cash": 0}).raise_for_status()
    menu = client.get("/api/menu/full", headers=admin).json()
    item = next(i for i in menu["items"] if i["price"] > 0)
    r = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 2}]})
    assert r.status_code == 201, r.text
    o = r.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


# ─────────────────────────────────────────────────────────────── the drill proves the data


@sqlite_only
def test_drill_restores_into_a_scratch_file_and_matches_the_manifest(client, cashier, admin):
    _seed_sale(client, cashier, admin)
    path = bk.create_backup("manual")
    manifest = bk.read_manifest(path)
    assert manifest and manifest["figures"]["orders.count"] > 0

    before = _live_digest()
    took = datetime.now()
    result = bk.restore_drill(path)
    live_figures_during = bk.live_figures()

    assert result["ok"] is True, result
    assert result["differences"] == []
    assert result["restored_into"] == "sqlite:temp-file", "the drill must use a temp file, never the live DB"
    assert result["sha256_ok"] is True
    assert result["duration_ms"] >= 0 and (datetime.now() - took).total_seconds() < 60

    # the restored copy agrees with BOTH the manifest and the live database (nothing changed in between)
    restored = result["figures"]
    for key in ("orders.count", "orders.total_sum", "orders.paid_sum", "orders.tax_sum",
                "payments.count", "payments.sum", "refunds.count", "refunds.cost_sum",
                "inventory.movement_qty", "inventory.ingredients"):
        assert restored[key] == manifest["figures"][key] == live_figures_during[key], key
    assert restored["payments.sum"] > 0 and restored["orders.total_sum"] > 0

    # the live database was not touched by the drill
    assert _live_digest() == before
    assert bk.live_figures() == live_figures_during


@sqlite_only
def test_drill_creates_the_backup_folder_if_it_was_deleted(client, admin):
    """A shop that wiped data/backups/ must still get a working backup + drill, not a crash."""
    folder = get_settings().backups_dir
    import shutil

    shutil.rmtree(folder, ignore_errors=True)
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code in (200, 201), r.text
    assert bk.read_manifest(folder / r.json()["name"]) is not None


@sqlite_only
def test_drill_detects_a_tampered_backup_instead_of_calling_it_healthy(tmp_path, client, cashier, admin):
    _seed_sale(client, cashier, admin)
    path = bk.create_backup("manual")
    # remove a payment from the copy behind the manifest's back → the figures no longer match
    import sqlite3

    con = sqlite3.connect(path)
    con.execute("DELETE FROM payments WHERE id = (SELECT MAX(id) FROM payments)")
    con.commit()
    con.close()
    result = bk.restore_drill(path)
    assert result["ok"] is False
    assert result["differences"], "a changed backup must produce a visible difference list"
    assert any(d["field"] == "payments.count" for d in result["differences"])
    assert result["sha256_ok"] is False


@sqlite_only
def test_corrupt_backup_fails_the_drill_and_records_an_error(client, admin):
    path = bk.create_backup("manual")
    path.write_bytes(b"this is not a database" * 100)
    result = bk.drill_and_record()
    assert result["ok"] is False and result["error"]
    status = client.get("/api/system/backups/status", headers=admin).json()
    assert status["drill_state"] == "failed"
    assert status["errors"] and status["errors"][0]["kind"] == "drill"
    assert status["recent"][0]["status"] == "failed"


@sqlite_only
def test_drill_api_returns_figures_and_the_status_page_shows_them(client, cashier, admin):
    _seed_sale(client, cashier, admin)
    client.post("/api/system/backups", headers=admin).raise_for_status()
    r = client.post("/api/system/backups/drill", headers=admin)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] and body["figures"]["orders.count"] >= 1

    status = client.get("/api/system/backups/status", headers=admin).json()
    assert status["drill_state"] == "ok"
    assert status["last_drill"]["backup"] == body["backup"]
    assert status["newest"]["verified_manifest"] is True
    assert status["stale"] is False
    assert status["count"] >= 1 and status["total_size"] > 0
    assert [r["kind"] for r in status["recent"]][:2] == ["drill", "backup"]


# ─────────────────────────────────────────────────────────────── the 24-hour warning


@sqlite_only
def test_status_warns_when_the_newest_backup_is_older_than_24_hours(tmp_path, monkeypatch):
    folder = tmp_path / "backups"
    folder.mkdir()
    old = datetime.now() - timedelta(hours=25, minutes=5)
    (folder / f"cafe-{old:%Y%m%d-%H%M%S}-daily.db").write_bytes(b"x")
    monkeypatch.setattr(type(get_settings()), "backups_dir", property(lambda self: folder))
    st = bk.status(None)
    assert st["stale"] is True and st["newest"]["age_hours"] > 24

    fresh = folder / f"cafe-{datetime.now():%Y%m%d-%H%M%S}-manual.db"
    fresh.write_bytes(b"x")
    st = bk.status(None)
    assert st["stale"] is False, "a fresh backup must clear the warning"


@sqlite_only
def test_status_without_any_backup_is_stale_not_crashing(monkeypatch, tmp_path):
    folder = tmp_path / "empty"
    folder.mkdir()
    monkeypatch.setattr(type(get_settings()), "backups_dir", property(lambda self: folder))
    st = bk.status(None)
    assert st["stale"] is True and st["newest"] is None and st["count"] == 0


# ─────────────────────────────────────────────────────────────── failure modes


@sqlite_only
def test_low_disk_space_refuses_to_start_and_says_why(client, admin, monkeypatch):
    real = bk.shutil.disk_usage

    def fake(path):
        class U:
            total, used, free = 10_000, 9_000, 1_000
        return U()

    monkeypatch.setattr(bk.shutil, "disk_usage", fake)
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code == 400 and r.json()["detail"]["code"] == "backup_failed"
    assert "فضای خالی" in r.json()["detail"]["message"]
    monkeypatch.setattr(bk.shutil, "disk_usage", real)
    status = client.get("/api/system/backups/status", headers=admin).json()
    assert status["errors"] and "فضای خالی" in (status["errors"][0]["detail"] or "")


@sqlite_only
def test_unwritable_backup_folder_is_reported_not_silently_ignored(client, admin, monkeypatch, tmp_path):
    folder = tmp_path / "readonly"
    folder.mkdir(mode=0o500)
    monkeypatch.setattr(type(get_settings()), "backups_dir", property(lambda self: folder))
    try:
        if os.access(folder, os.W_OK):                      # running as root ignores the permission bits
            pytest.skip("filesystem permissions are not enforced for this user")
        r = client.post("/api/system/backups", headers=admin)
        assert r.status_code == 400, r.text
        assert r.json()["detail"]["code"] == "backup_failed"
    finally:
        os.chmod(folder, stat.S_IRWXU)


@sqlite_only
def test_two_backups_at_once_are_serialised_or_refused(tmp_path):
    """The real invariant: two backups are never *inside* the critical section at the same time.

    Every caller must either get the lock (and then finish) or a clear «already running» error. Asserting on
    ``max_concurrent`` instead of on "at least one error" makes the test deterministic — with four threads the
    scheduler may let them take turns, which is just as correct as refusing.
    """
    folder = tmp_path / "b"
    folder.mkdir()
    errors: list[str] = []
    made: list[Path] = []
    state = {"now": 0, "max": 0}
    guard = threading.Lock()
    start_all = threading.Barrier(4)

    def worker():
        start_all.wait()
        try:
            with bk.backup_lock(folder):
                with guard:
                    state["now"] += 1
                    state["max"] = max(state["max"], state["now"])
                time.sleep(0.15)                       # a real backup takes far longer than this
                with guard:
                    state["now"] -= 1
                made.append(folder / f"fake-{len(made)}.db")
        except bk.BackupError as e:
            errors.append(str(e))

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(made) + len(errors) == 4, "every caller must either finish or be refused"
    assert state["max"] == 1, f"{state['max']} backups were inside the lock at once"
    assert all("در حال اجراست" in e for e in errors), errors
    assert not (folder / bk.LOCK_NAME).exists(), "the lock must be released even when it refused a caller"


@sqlite_only
def test_a_lock_left_by_a_killed_process_does_not_block_backups_forever(tmp_path):
    folder = tmp_path / "b"
    folder.mkdir()
    lock = folder / bk.LOCK_NAME
    # pid 999999 does not exist; a real backup must take the lock over instead of failing until sunrise
    lock.write_text(json.dumps({"pid": 999_999, "at": datetime.now().timestamp()}), encoding="utf-8")
    with bk.backup_lock(folder):
        assert lock.exists()
    assert not lock.exists()

    # an ancient lock (older than LOCK_MAX_AGE) is ignored even if the pid looks alive
    lock.write_text(json.dumps({"pid": os.getpid(), "at": (datetime.now() - timedelta(hours=2)).timestamp()}),
                    encoding="utf-8")
    with bk.backup_lock(folder):
        pass
    assert not lock.exists()


@sqlite_only
def test_leftovers_of_a_killed_backup_are_cleaned_up(tmp_path):
    folder = tmp_path / "b"
    folder.mkdir()
    (folder / "cafe-20261025-101010-hourly.db.tmp").write_bytes(b"half a backup")
    (folder / "cafe-20261025-101010-hourly.dump.part").write_bytes(b"half a dump")
    bk._rotate(folder)
    assert not list(folder.glob("*.tmp*")) and not list(folder.glob("*.part"))


@sqlite_only
def test_rotation_never_deletes_the_last_remaining_backup(tmp_path, monkeypatch):
    folder = tmp_path / "b"
    folder.mkdir()
    old = datetime.now() - timedelta(days=400)
    only = folder / f"cafe-{old:%Y%m%d-%H%M%S}-daily.db"
    only.write_bytes(b"the only backup this shop has")
    monkeypatch.setattr(get_settings(), "backup_keep", 1) if False else None
    bk.consolidate(folder, cutoff_hour=5, today=date.today())
    assert only.exists(), "an expired backup is still better than no backup at all"


@sqlite_only
def test_manual_backups_and_the_newest_safety_copy_are_never_rotated_away(tmp_path):
    folder = tmp_path / "b"
    folder.mkdir()
    for day in range(1, 6):
        stamp = datetime.now() - timedelta(days=day * 40)
        (folder / f"cafe-{stamp:%Y%m%d-%H%M%S}-pre-restore.db").write_bytes(b"x")
        (folder / f"cafe-{stamp:%Y%m%d-%H%M%S}-manual.db").write_bytes(b"x")
    newest_manual = sorted(folder.glob("*manual.db"))[-1]
    newest_safety = sorted(folder.glob("*pre-restore.db"))[-1]
    bk.consolidate(folder, cutoff_hour=5, today=date.today())
    bk._rotate(folder)
    assert newest_manual.exists() and newest_safety.exists()


@sqlite_only
def test_backup_files_are_not_world_readable(client, admin):
    name = client.post("/api/system/backups", headers=admin).json()["name"]
    path = get_settings().backups_dir / name
    mode = stat.S_IMODE(path.stat().st_mode)
    assert mode & 0o077 == 0, f"backup is readable by others: {oct(mode)}"
    assert stat.S_IMODE(bk.manifest_path(path).stat().st_mode) & 0o077 == 0


@sqlite_only
def test_manifest_contains_no_personal_data(client, cashier, admin):
    """A manifest travels with the backup (support tickets, chat) — it may hold totals, never customers."""
    _seed_sale(client, cashier, admin)
    path = bk.create_backup("manual")
    text = bk.manifest_path(path).read_text(encoding="utf-8")
    data = json.loads(text)
    assert set(data["figures"]) == set(bk.FIGURES_SQL)
    for leak in ("phone", "0912", "customer", "password", "admin", "secret"):
        assert leak not in text.lower(), f"manifest leaks {leak}"
    assert "sha256" in data and data["source"] == "sqlite"


@sqlite_only
def test_backup_name_is_still_the_only_thing_that_can_be_downloaded(client, admin):
    """No path traversal, no reading a manifest/other file through the download endpoint."""
    for bad in ("../cafe.db", "..%2Fcafe.db", "secret.key", "cafe-20260101-000000-manual.db.json"):
        r = client.get(f"/api/system/backups/{bad}", headers=admin)
        assert r.status_code in (400, 404, 422), f"{bad} must not be served ({r.status_code})"


# ─────────────────────────────────────────────────────────────── PostgreSQL (dump + drill)


@pg_only
def test_pg_backup_is_a_verified_dump_with_a_manifest(client, admin):
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code in (200, 201), r.text
    name = r.json()["name"]
    assert name.endswith(".dump")
    path = get_settings().backups_dir / name
    assert path.exists() and bk.verify(path)["integrity"] == "ok"
    assert bk.read_manifest(path)["source"] == "postgresql"
    assert not list(get_settings().backups_dir.glob("*.part"))


@pg_only
def test_pg_drill_restores_into_a_scratch_database_and_matches(client, cashier, admin):
    _seed_sale(client, cashier, admin)
    path = bk.create_backup("manual")
    live = bk.live_figures()
    result = bk.restore_drill(path)
    assert result["ok"] is True, result
    assert result["restored_into"].startswith("postgresql:cafe_drill_")
    for key in ("orders.count", "orders.total_sum", "payments.sum", "refunds.cost_sum", "inventory.movement_qty"):
        assert result["figures"][key] == live[key], key
    # the scratch database is dropped again, and the live data is unchanged
    assert bk.live_figures() == live
    tools = bk.pg_tools()
    if tools["psql"]:
        out = bk._run([tools["psql"], *bk._pg_conn_args(bk._pg_dsn()), "-tAc",
                       f"SELECT count(*) FROM pg_database WHERE datname = '{result['restored_into'].split(':')[1]}'"],
                      bk._pg_env(bk._pg_dsn()))
        assert out.stdout.strip() == "0", "the drill database must not be left behind"


# ─────────────────────────────────────────────────────────────── scheduled backups on PostgreSQL


@pg_only
def test_pg_auto_backup_runs_on_the_schedule_and_skips_when_nothing_changed(client, admin):
    """The hourly job must work on PostgreSQL too (it used to return immediately: there is no file to stat)."""
    first = bk.auto_backup(force=True)
    assert first is not None and first.suffix == ".dump"
    assert bk.read_manifest(first)["source"] == "postgresql"
    # nothing written in between → the change token is unchanged → no second file
    assert bk.auto_backup() is None or bk.auto_backup() is None
    # a real write makes it due again
    client.post("/api/system/backups", headers=admin).raise_for_status()
    second = bk.auto_backup(force=True)
    assert second is not None and second.name != first.name


@pg_only
def test_pg_shift_close_backup_is_a_dump(client):
    path = bk.shift_closed_backup()
    assert path is not None and path.name.endswith("-daily.dump") or path.name.endswith(".dump")
    assert bk.verify(path)["integrity"] == "ok"


def test_every_figure_query_really_runs_on_the_current_schema(client, cashier, admin):
    """Regression guard for a silent no-op.

    A figure whose SQL names a column that does not exist returns `None` on both sides of the comparison, so the
    drill would pass while checking nothing (this really happened: `order_refund_lines.amount` never existed —
    refunded money lives in `payments`). Any new figure must therefore produce a real number on a normal database.
    """
    _seed_sale(client, cashier, admin)
    figures = bk.live_figures()
    assert set(figures) == set(bk.FIGURES_SQL)
    broken = {k: v for k, v in figures.items() if v is None or isinstance(v, str)}
    assert not broken, f"these figures do not actually run: {broken}"
    assert figures["orders.count"] > 0 and figures["payments.sum"] > 0


def test_a_refund_is_reflected_in_the_payment_figures(client, cashier, admin, mgr):
    """Money that went back must be visible in the backup manifest (it is a payments row, not a refund-line column)."""
    order = _seed_sale(client, cashier, admin)
    before = bk.live_figures()
    r = client.post(f"/api/orders/{order['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 10_000, "reason": "آزمون پشتیبان"})
    assert r.status_code == 200, r.text
    after = bk.live_figures()
    assert after["payments.sum"] == before["payments.sum"] - 10_000
    assert after["payments.refund_sum"] == before["payments.refund_sum"] - 10_000
