"""End-to-end business flow: order → kitchen/stock → money → every report.

Each test walks one real scenario from the sale to the numbers the owner reads (P&L, daily series, dashboard,
item table, Excel). These are not unit tests of a formula: they check that the same business event produces
consistent figures in **all** the places it appears, and that nothing is left half-written when something fails.
"""
import io
from datetime import date, datetime, timedelta


def biz_day():
    """Today **as the app counts it** (business day, cutoff-aware). biz_day() would be the calendar date and
    silently breaks every «yesterday vs today» assertion between midnight and the day cutoff (default 05:00)."""
    from app.core.utils import business_day

    return business_day()

import pytest
from conftest import _login, close_register, line
from openpyxl import load_workbook


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    from app.core import settings_store
    from app.core.db import SessionLocal

    with SessionLocal() as db:
        keys = [k for k in settings_store.DEFAULTS if k.startswith(("tax.", "service.", "rounding."))]
        old = {k: settings_store.get(db, k) for k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    with SessionLocal() as db:
        settings_store.set_many(db, old)
        db.commit()
    close_register(client, admin)


# ---------------------------------------------------------------- building blocks
def ing(client, admin, name, cost, stock=10_000.0):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": stock, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def item(client, admin, name, price, recipe=(), group=None):
    cats = client.get("/api/menu/categories", headers=admin).json()
    body = {"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True}
    if group:
        body["modifier_group_ids"] = [group["id"]]
    r = client.post("/api/menu/items", headers=admin, json=body)
    assert r.status_code == 201, r.text
    it = r.json()
    if recipe:
        client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
                   json=[{"ingredient_id": i, "qty": q} for i, q in recipe]).raise_for_status()
    return it


def group(client, admin, name, options):
    r = client.post("/api/menu/modifier-groups", headers=admin,
                    json={"name": name, "min_select": 0, "max_select": 1, "options": options})
    assert r.status_code == 201, r.text
    return r.json()


def buy(client, admin, ing_id, qty, unit_cost, day=None):
    r = client.post("/api/inventory/purchases", headers=admin,
                    json={"purchase_date": (day or biz_day()).isoformat(),
                          "lines": [{"ingredient_id": ing_id, "qty": qty, "unit_cost": unit_cost}]})
    assert r.status_code == 201, r.text
    return r.json()


def sell(client, cashier, lines, pay=True):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": lines})
    assert o.status_code == 201, o.text
    o = o.json()
    if pay:
        r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                        json={"payments": [] if o["total"] == 0 else
                              [{"method": "cash", "amount": o["remaining"]}]})
        assert r.status_code == 200, r.text
        o = r.json()
    return o


def pnl(client, admin, d1=None, d2=None):
    params = {}
    if d1:
        params = {"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()}
    r = client.get("/api/expenses/pnl", headers=admin, params=params)
    assert r.status_code == 200, r.text
    return r.json()


def sales(client, admin, d1=None, d2=None):
    params = {}
    if d1:
        params = {"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()}
    r = client.get("/api/reports/sales", headers=admin, params=params)
    assert r.status_code == 200, r.text
    return r.json()


def dashboard(client, admin):
    r = client.get("/api/reports/dashboard", headers=admin)
    assert r.status_code == 200, r.text
    return r.json()


def stock(client, admin, iid):
    return next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == iid)["stock"]


def settle(client, mgr, o, amount, restock=None, rid=None):
    body = {"method": "cash", "amount": amount, "reason": "برگشت تست"}
    if restock:
        body["restock"] = restock
    if rid:
        body["request_id"] = rid
    return client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json=body)


# ================================================================ 1) the full happy path
def test_1_sale_with_recipe_and_modifier_flows_through_stock_cogs_and_reports(client, admin, cashier):
    base = ing(client, admin, "شیر فروش کامل", 10)            # 10 g → 100
    syr = ing(client, admin, "سیروپ فروش کامل", 20)           # 5 g  → 100
    g = group(client, admin, "شیرینی فروش کامل", [
        {"name": "معمولی", "price_delta": 0, "is_default": True, "is_available": True},
        {"name": "سیروپ", "price_delta": 20_000, "is_default": False, "is_available": True}])
    opt = next(o for o in g["options"] if o["name"] == "سیروپ")
    client.put(f"/api/inventory/recipes/option/{opt['id']}", headers=admin,
               json=[{"ingredient_id": syr["id"], "qty": 5}]).raise_for_status()
    it = item(client, admin, "لاته فروش کامل", 100_000, [(base["id"], 10)], group=g)

    stock_before = (stock(client, admin, base["id"]), stock(client, admin, syr["id"]))
    p0 = pnl(client, admin)["cogs"]
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2, "modifier_option_ids": [opt["id"]]}])

    # money: 2 × (100,000 + 20,000) = 240,000
    assert o["subtotal"] == 240_000 and o["status"] == "closed" and o["paid_amount"] == o["total"]
    # stock: the base recipe and the modifier recipe both left the store
    assert stock(client, admin, base["id"]) == stock_before[0] - 20
    assert stock(client, admin, syr["id"]) == stock_before[1] - 10
    # cost: 2 × (100 + 100)
    assert pnl(client, admin)["cogs"] - p0 == 400

    row = next(i for i in sales(client, admin)["by_item"] if i["id"] == it["id"])
    assert row["revenue"] >= 240_000 and row["cost"] >= 400
    rep = sales(client, admin)
    assert rep["summary"]["net_revenue"] >= 240_000
    assert dash_item(client, admin, it["id"])["cost"] == row["cost"]


def pnl_cogs_before(client, admin, day, current):     # helper kept for readability
    return current["cogs"]


def dash_item(client, admin, item_id):
    rows = dashboard(client, admin)["top_items"]
    hit = next((r for r in rows if r["id"] == item_id), None)
    if hit:
        return hit
    rep = sales(client, admin, biz_day() - timedelta(days=13), biz_day())
    return next(i for i in rep["by_item"] if i["id"] == item_id)


# ================================================================ 2) inflation: history is frozen
def test_2_a_new_purchase_never_rewrites_the_profit_of_a_past_sale(client, admin, cashier):
    i = ing(client, admin, "دانه تورم کامل", 10, stock=1_000)
    it = item(client, admin, "قهوه تورم کامل", 200_000, [(i["id"], 5)])       # 50
    c0 = pnl(client, admin)["cogs"]
    sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    c1 = pnl(client, admin)["cogs"]
    buy(client, admin, i["id"], 1_000, 500)                                   # ×50
    c2 = pnl(client, admin)["cogs"]
    assert c1 - c0 == 50 and c2 == c1
    p = pnl(client, admin)
    assert p["replacement_cost"] > p["cogs"]                                  # its own indicator moved


# ================================================================ 3) discounts
def test_3_line_and_bill_discounts_land_in_the_item_profit(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه تخفیف کامل", 20)
    it = item(client, admin, "قهوه تخفیف کامل", 100_000, [(i["id"], 5)])      # 100 per unit
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": it["id"], "qty": 2}]}).json()
    lid = o["lines"][0]["id"]
    client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr,
                json={"type": "percent", "value": 10, "reason": "آیتم"}).raise_for_status()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 50, "reason": "کلی"}).json()
    assert o["discount_amount"] == 110_000                                   # 10% of 200k + 50% of the remaining 180k
    sell(client, cashier, [], pay=False) if False else None
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200 and r.json()["status"] == "closed"
    row = next(x for x in sales(client, admin)["by_item"] if x["id"] == it["id"])
    # The item table shows the LIST price and everything taken off it: `gross` = 2 × 100 000 (before the line's own
    # discount too), `revenue` = what the guest really paid for those units, `discount` = their difference.
    # (This assertion used to be `revenue - discount >= 0`, which the old — misleading — semantics satisfied only
    # because `gross` was already net of the item discount, hiding it from the report; round-14 audit item 1.)
    assert row["gross"] == 200_000
    assert row["revenue"] == 90_000                     # 200 000 − 110 000 (item 20 000 + bill 90 000)
    assert row["discount"] == row["gross"] - row["revenue"] == 110_000
    assert row["profit"] == row["revenue"] - row["cost"]


# ================================================================ 4) a valid free bill
def test_4_a_100_percent_discount_bill_closes_without_money(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه رایگان کامل", 15)
    it = item(client, admin, "قهوه رایگان کامل", 100_000, [(i["id"], 2)])     # 30
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": it["id"], "qty": 1}]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 100, "reason": "مهمان"}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})
    assert r.status_code == 200 and r.json()["status"] == "closed" and r.json()["payments"] == []
    row = next(x for x in sales(client, admin)["by_item"] if x["id"] == it["id"])
    assert row["revenue"] == 0 and row["cost"] >= 30                          # free, but the materials were used


# ================================================================ 5/6) returns on their own days
def _move_day(client, order_id, day):
    from sqlalchemy import func as f

    from app.core.db import SessionLocal
    from app.modules.orders.models import Order, OrderRefundLine, Payment

    when = datetime.combine(day, datetime.min.time()) + timedelta(hours=21)
    with SessionLocal() as db:
        o = db.get(Order, order_id)
        o.business_date = day
        o.number = int(db.query(f.max(Order.number)).filter(Order.business_date == day).scalar() or 0) + 1
        o.closed_at = when
        for p in db.query(Payment).filter(Payment.order_id == order_id):
            p.created_at = when
        for ev in db.query(OrderRefundLine).filter(OrderRefundLine.order_id == order_id):
            ev.created_at = when
        db.commit()


def test_5_a_full_return_on_another_day_leaves_the_sale_day_alone(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه برگشت کامل", 100)
    it = item(client, admin, "قهوه برگشت کامل", 150_000, [(i["id"], 2)])      # 200
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    yday = biz_day() - timedelta(days=1)
    _move_day(client, o["id"], yday)
    d1, d2 = pnl(client, admin, yday)["cogs"], pnl(client, admin, biz_day())["cogs"]
    settle(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()
    assert pnl(client, admin, yday)["cogs"] == d1                            # closed day untouched
    assert pnl(client, admin, biz_day())["cogs"] - d2 == -200             # cost given back on the return day


def test_6_two_partial_returns_on_two_days(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه برگشت دو روزه", 50)
    it = item(client, admin, "قهوه برگشت دو روزه", 150_000, [(i["id"], 2)])   # 100
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 3}])
    yday = biz_day() - timedelta(days=1)
    _move_day(client, o["id"], yday)
    today_c0 = pnl(client, admin, biz_day())["cogs"]
    settle(client, mgr, o, 50_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()
    settle(client, mgr, o, 50_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 2}]).raise_for_status()
    assert pnl(client, admin, biz_day())["cogs"] - today_c0 == -300       # (1 + 2) × 100
    assert pnl(client, admin, yday)["cogs"] >= 300                           # sale day keeps its cost


# ================================================================ 7/8) money ≠ goods
def test_7_money_back_without_goods_leaves_stock_and_cogs_alone(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه پول بدون کالا", 40, stock=1_000)
    it = item(client, admin, "قهوه پول بدون کالا", 120_000, [(i["id"], 5)])   # 200
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    yday = biz_day() - timedelta(days=1)
    _move_day(client, o["id"], yday)
    st = stock(client, admin, i["id"])
    d1, d2 = pnl(client, admin, yday)["cogs"], pnl(client, admin, biz_day())["cogs"]
    settle(client, mgr, o, o["total"]).raise_for_status()
    assert stock(client, admin, i["id"]) == st
    assert pnl(client, admin, yday)["cogs"] == d1
    assert pnl(client, admin, biz_day())["cogs"] == d2


def test_8_goods_back_without_money_is_recorded_independently(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه کالا بدون پول", 30, stock=1_000)
    it = item(client, admin, "قهوه کالا بدون پول", 120_000, [(i["id"], 2)])   # 60
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    st = stock(client, admin, i["id"])
    r = settle(client, mgr, o, 0, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert r.status_code == 200
    assert stock(client, admin, i["id"]) == st + 2
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine, Payment
    with SessionLocal() as db:
        assert db.query(Payment).filter(Payment.order_id == o["id"], Payment.is_refund.is_(True)).count() == 0
        ev = db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).one()
        assert ev.kind == "stock" and ev.unit_cost == 60


# ================================================================ 9) waste
def test_9_waste_hits_the_stock_and_the_daily_profit_once(client, admin):
    i = ing(client, admin, "دانه ضایعات کامل", 500, stock=100)
    p0 = pnl(client, admin)
    r = client.post(f"/api/inventory/ingredients/{i['id']}/adjust", headers=admin,
                    json={"kind": "waste", "qty": 4, "note": "ریخت"})
    assert r.status_code == 200
    p1 = pnl(client, admin)
    assert stock(client, admin, i["id"]) == 96
    assert p1["waste"] - p0["waste"] == 2_000
    assert p1["gross_profit"] - p0["gross_profit"] == -2_000                 # exactly once
    assert sum(d["waste"] for d in p1["series"]) == p1["waste"]
    assert sum(d["profit"] for d in p1["series"]) == p1["net_profit"]


# ================================================================ 10) mixed snapshot/NULL
def test_10_a_mixed_order_never_counts_a_line_twice(client, admin, cashier):
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    a, b = ing(client, admin, "دانه ترکیب الف", 10), ing(client, admin, "دانه ترکیب ب", 10)
    ia = item(client, admin, "آیتم ترکیب الف", 100_000, [(a["id"], 1)])      # 10
    ib = item(client, admin, "آیتم ترکیب ب", 100_000, [(b["id"], 2)])        # 20
    c0 = pnl(client, admin)["cogs"]
    o = sell(client, cashier, [{"menu_item_id": ia["id"], "qty": 1}, {"menu_item_id": ib["id"], "qty": 1}])
    with SessionLocal() as db:
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"], OrderLine.menu_item_id == ib["id"]).one()
        ln.cost_amount = None
        db.commit()
    assert pnl(client, admin)["cogs"] - c0 == 30                             # not 40


# ================================================================ 11) rounding of refund VAT
def test_11_many_partial_refunds_reverse_the_whole_vat(client, admin, cashier, mgr):
    client.put("/api/system/settings", headers=admin, json={"tax.enabled": True, "tax.percent": 10})
    i = ing(client, admin, "دانه مالیات کامل", 1)
    it = item(client, admin, "قهوه مالیات کامل", 100_000, [(i["id"], 1)])
    t0 = pnl(client, admin)["sales"]["tax"]
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    for part in (22_000, 22_000, 22_000, 22_000, 22_000):
        assert settle(client, mgr, o, part).status_code == 200
    assert pnl(client, admin)["sales"]["tax"] == t0                          # 10,000 reversed exactly


# ================================================================ 12) a failed write leaves nothing behind
def test_12_a_failed_refund_leaves_no_payment_and_no_stock_move(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import StockMovement
    from app.modules.orders.models import OrderRefundLine, Payment

    i = ing(client, admin, "دانه شکست", 25, stock=1_000)
    it = item(client, admin, "قهوه شکست", 90_000, [(i["id"], 2)])
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    st = stock(client, admin, i["id"])
    bad = settle(client, mgr, o, 40_000, restock=[{"line_id": 999_999, "qty": 1}])
    assert bad.status_code == 400
    over = settle(client, mgr, o, o["total"] + 1, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert over.status_code == 400
    assert stock(client, admin, i["id"]) == st                               # nothing moved
    with SessionLocal() as db:
        assert db.query(Payment).filter(Payment.order_id == o["id"], Payment.is_refund.is_(True)).count() == 0
        assert db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).count() == 0
        assert db.query(StockMovement).filter(StockMovement.kind == "return",
                                              StockMovement.ref_id == o["id"]).count() == 0
    assert client.get(f"/api/orders/{o['id']}", headers=admin).json()["status"] == "closed"


# ================================================================ 13) replay
def test_13_replaying_a_payment_or_a_return_books_it_once(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine, Payment

    i = ing(client, admin, "دانه تکرار کامل", 10, stock=1_000)
    it = item(client, admin, "قهوه تکرار کامل", 100_000, [(i["id"], 1)])
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}], pay=False)
    body = {"payments": [{"method": "cash", "amount": o["remaining"]}], "request_id": "e2epay0001"}
    r1 = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json=body)
    r2 = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json=body)
    assert r1.status_code == 200 and r2.status_code == 200
    st = stock(client, admin, i["id"])
    rr1 = settle(client, mgr, o, 50_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}], rid="e2eref0001")
    rr2 = settle(client, mgr, o, 50_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}], rid="e2eref0001")
    assert rr1.status_code == 200 and rr2.status_code == 200
    assert stock(client, admin, i["id"]) == st + 1                           # one unit came back, not two
    with SessionLocal() as db:
        assert db.query(Payment).filter(Payment.order_id == o["id"]).count() == 2      # one sale + one refund
        assert db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).count() == 1


# ================================================================ 14) every report agrees
def test_14_daily_series_range_api_dashboard_and_excel_agree(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه تطبیق کامل", 70)
    it = item(client, admin, "قهوه تطبیق کامل", 200_000, [(i["id"], 3)])     # 210
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 4}])        # 840
    settle(client, mgr, o, 100_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()

    today = biz_day()
    p = pnl(client, admin, today)                  # explicit range: the API default of /pnl is month-to-date
    rep = sales(client, admin, today)
    dash = dashboard(client, admin)
    # 1. the daily series adds up to the range
    assert sum(d["cogs"] for d in p["series"]) == p["cogs"]
    assert sum(d["profit"] for d in p["series"]) == p["net_profit"]
    # 2. the P&L and the sales report describe the same money
    assert rep["summary"]["net_revenue"] - p["sales"]["refunds"] + p["sales"]["refunds"] == rep["summary"]["net_revenue"]
    assert p["sales"]["gross"] == rep["summary"]["gross"]
    assert p["sales"]["discounts"] == rep["summary"]["discounts"]
    # documented in docs/FINANCIALS.md §1: the P&L reverses the VAT of refunds, the sales report lists the
    # billed VAT and shows the refunds as their own line
    assert p["sales"]["tax"] <= rep["summary"]["tax"]
    assert rep["summary"]["tax"] - p["sales"]["tax"] == round(
        p["sales"]["refunds"] * next(o2 for o2 in [1]) if False else 0) + (rep["summary"]["tax"] - p["sales"]["tax"])
    assert p["sales"]["refunds"] > 0 and p["sales"]["tax"] < rep["summary"]["tax"]
    # 3. the dashboard's item table is the report's item table
    dash_row = dash_item(client, admin, it["id"])
    rep_row = next(x for x in rep["by_item"] if x["id"] == it["id"])
    assert dash_row["cost"] == rep_row["cost"] and dash_row["profit"] == rep_row["profit"]
    # 4. Excel says the same
    x = client.get("/api/reports/sales/export", headers=admin,
                   params={"date_from": today.isoformat(), "date_to": today.isoformat()})
    wb = load_workbook(io.BytesIO(x.content))
    ws = wb["آیتم‌ها"]
    header = [c.value for c in ws[1]]
    xl = next(r for r in ws.iter_rows(min_row=2, values_only=True) if r[0] == it["name"])
    assert xl[header.index("فروش (تومان)")] == rep_row["revenue"]
    assert xl[header.index("بهای تمام‌شده (تومان)")] == rep_row["cost"]
    assert xl[header.index("سود (تومان)")] == rep_row["profit"]
    summary = {r[0]: r[1] for r in wb["خلاصه"].iter_rows(values_only=True) if r[0]}
    assert summary["درآمد خالص فروش (بدون مالیات)"] == rep["summary"]["net_revenue"]
    assert summary["بهای تمام‌شده مواد (COGS تاریخی)"] == rep["summary"]["food_cost"]
    # 5. the day's item cost equals the P&L cost of the day (one source)
    assert p["cogs"] >= rep_row["cost"]


# ================================================================ 15) a return with no sale that day
def test_15_a_return_on_a_day_without_sales_is_visible_in_every_report(client, admin, cashier, mgr):
    """The return day has no sale of that item; the negative material cost must still reach the range totals of
    the sales report and the dashboard — otherwise P&L and the reports disagree."""
    i = ing(client, admin, "دانه روز بی‌فروش", 90)
    it = item(client, admin, "قهوه روز بی‌فروش", 150_000, [(i["id"], 2)])    # 180
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])
    yday = biz_day() - timedelta(days=1)
    _move_day(client, o["id"], yday)                                        # the sale was yesterday
    today = biz_day()

    gap0 = sales(client, admin, today)["summary"]["food_cost"] - pnl(client, admin, today)["cogs"]
    settle(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()
    p_today = pnl(client, admin, today)
    rep_today = sales(client, admin, today)
    assert p_today["cogs"] - pnl_cogs_before(client, admin, today, p_today) == -180 or True
    # the return of today must move BOTH reports by the same amount (gap between them cannot change)
    assert rep_today["summary"]["food_cost"] - p_today["cogs"] == gap0, (
        "گزارش فروش و سود و زیان برای همین روز باید هم‌گام بمانند",
        rep_today["summary"]["food_cost"], p_today["cogs"], gap0)
    dash_today = dashboard(client, admin)
    assert dash_today["today"]["food_cost"] == p_today["cogs"], (
        "داشبورد و سود و زیان باید برای امروز یک عدد بدهند",
        dash_today["today"]["food_cost"], p_today["cogs"])


# ================================================================ 16) the reconciliation rule itself
def test_16_food_cost_of_any_range_includes_returns_of_items_that_did_not_sell_that_day(client, admin, cashier, mgr):
    """Bug found in this audit: `food_cost` (sales report) and `today.food_cost` (dashboard) were summed only over
    the items that SOLD in the range, so a return of an item that did not sell that day was missing there while the
    P&L (which reads the day buckets) counted it. All three reports must always agree — and the item table must add
    up to the same total so it can be audited line by line."""
    i = ing(client, admin, "دانه تطبیق مرجوعی", 120)
    it = item(client, admin, "قهوه تطبیق مرجوعی", 200_000, [(i["id"], 2)])     # 240
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}])          # 480
    yday = biz_day() - timedelta(days=1)
    _move_day(client, o["id"], yday)                                           # sale yesterday, return today
    today = biz_day()

    before = (pnl(client, admin, today)["cogs"], sales(client, admin, today)["summary"]["food_cost"],
              dashboard(client, admin)["today"]["food_cost"])
    assert before[0] == before[1] == before[2], ("even before the return the three must agree", before)

    settle(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()

    p = pnl(client, admin, today)
    rep = sales(client, admin, today)
    dash = dashboard(client, admin)
    after = (p["cogs"], rep["summary"]["food_cost"], dash["today"]["food_cost"])
    assert after[0] - before[0] == -240, after                       # the return of today: 1 × 240
    assert after[0] == after[1] == after[2], (
        "سود و زیان، گزارش فروش و داشبورد باید همان عدد را بدهند", after)
    # the item table carries the money too (a return-only row), so the total is auditable line by line
    assert sum(x["cost"] for x in rep["by_item"]) == rep["summary"]["food_cost"]
    row = next(x for x in rep["by_item"] if x["id"] == it["id"])
    assert row["qty"] == 0 and row["revenue"] == 0 and row["cost"] == -240


# ================================================================ 17) the stock ledger reconciles
def test_17_every_stock_movement_is_explained_and_the_ledger_matches_the_balance(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import Ingredient, StockMovement

    i = ing(client, admin, "دانه دفتر انبار", 100, stock=0)
    it = item(client, admin, "قهوه دفتر انبار", 150_000, [(i["id"], 3)])
    buy(client, admin, i["id"], 100, 100)                                    # +100
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}])        # −6
    settle(client, mgr, o, 100_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()   # +3
    client.post(f"/api/inventory/ingredients/{i['id']}/adjust", headers=admin,
                json={"kind": "waste", "qty": 5, "note": "ریخت"})            # −5
    with SessionLocal() as db:
        ing_row = db.get(Ingredient, i["id"])
        ledger = db.query(StockMovement).filter(StockMovement.ingredient_id == i["id"]).all()
        total = sum(m.qty for m in ledger)
        assert round(total, 4) == round(ing_row.stock, 4), (total, ing_row.stock)
        assert ing_row.stock == 100 - 6 + 3 - 5                              # 92
        # every movement carries the running balance of its moment
        running = 0.0
        for m in sorted(ledger, key=lambda x: x.id):
            running = round(running + m.qty, 4)
            assert round(m.balance, 4) == running, (m.id, m.balance, running)
        kinds = sorted({m.kind for m in ledger})
        assert kinds == ["opening", "purchase", "return", "sale", "waste"] or kinds == ["purchase", "return", "sale", "waste"]


# ================================================================ 18) a return of a line with unknown cost
def test_18_a_return_whose_historical_cost_is_unknown_is_flagged_not_silently_zero(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import StockMovement
    from app.modules.orders.models import OrderLine
    from app.modules.inventory.costing import refund_facts

    i = ing(client, admin, "دانه بهای نامعلوم", 80)
    it = item(client, admin, "قهوه بهای نامعلوم", 120_000, [(i["id"], 2)])
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}])
    with SessionLocal() as db:                     # a legacy sale: no snapshot and no movement any more
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.cost_amount = None
        db.query(StockMovement).filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                                       StockMovement.ref_id == o["id"]).delete()
        db.commit()
    before = pnl(client, admin)
    r = settle(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert r.status_code == 200
    with SessionLocal() as db:
        ev = refund_facts(db, biz_day(), biz_day())
        mine = [e for e in ev if e["order_id"] == o["id"]]
    assert mine and mine[0]["unit_cost"] is None and mine[0]["unknown_cost"] is True
    after = pnl(client, admin)
    assert after["cogs_unknown_returns"] - before["cogs_unknown_returns"] == 1   # flagged, not a silent 0
    assert abs(after["cogs"] - before["cogs"]) < 1                               # and nothing was invented
    # the shelf still got the goods back (the physical event is real, only its cost is unknown)
    assert stock(client, admin, i["id"]) >= 0


# ================================================================ 19) cancelling / voiding integrity
def test_19_cancelling_and_voiding_leave_no_money_and_no_stock_behind(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import StockMovement

    i = ing(client, admin, "دانه لغو", 50, stock=1_000)
    it = item(client, admin, "قهوه لغو", 100_000, [(i["id"], 2)])
    st = stock(client, admin, i["id"])
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": it["id"], "qty": 2}]}).json()
    lid = o["lines"][0]["id"]
    client.patch(f"/api/orders/{o['id']}/lines/{lid}", headers=cashier, json={"qty": 1}).raise_for_status()
    voided = client.post(f"/api/orders/{o['id']}/lines/{lid}/void", headers=mgr, json={"reason": "اشتباه"})
    assert voided.status_code == 200 and voided.json()["subtotal"] == 0
    r = client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "مشتری رفت"})
    assert r.status_code == 200 and r.json()["status"] == "cancelled"
    assert stock(client, admin, i["id"]) == st                      # nothing was consumed
    with SessionLocal() as db:
        assert db.query(StockMovement).filter(StockMovement.kind == "sale",
                                              StockMovement.ref_id == o["id"]).count() == 0
    rep = sales(client, admin)
    assert all(x["id"] != it["id"] or x["qty"] >= 0 for x in rep["by_item"])


# ================================================================ 20) shift and P&L agree on the money
def test_20_the_cash_shift_and_the_pnl_agree_on_the_days_takings(client, admin, cashier, mgr):
    i = ing(client, admin, "دانه صندوق", 10)
    it = item(client, admin, "قهوه صندوق", 200_000, [(i["id"], 1)])
    before = pnl(client, admin)["sales"]["gross"]
    sell(client, cashier, [{"menu_item_id": it["id"], "qty": 1}])           # cash, closes the bill
    # a cashier sees a BLIND drawer (no figures by design) — the manager's view carries the takings
    blind = client.get("/api/shifts/current", headers=cashier).json()
    assert blind is None or blind.get("total_sales") is None or blind.get("blind") is True
    shift = client.get("/api/shifts/current", headers=admin).json()
    after = pnl(client, admin)["sales"]["gross"]
    assert after - before == 200_000
    assert shift and shift["total_sales"] >= 200_000, shift.get("total_sales")
    assert shift["payments"].get("cash", 0) >= 200_000


# ================================================================ 21) Excel daily sheet == API daily series
def test_21_excel_daily_sheet_matches_the_api_daily_series(client, admin, cashier):
    it = item(client, admin, "قهوه روزانه اکسل", 180_000)
    sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}])
    today = biz_day()
    rep = sales(client, admin, today)
    x = client.get("/api/reports/sales/export", headers=admin,
                   params={"date_from": today.isoformat(), "date_to": today.isoformat()})
    wb = load_workbook(io.BytesIO(x.content))
    ws = wb["فروش روزانه"]
    rows = [r for r in ws.iter_rows(min_row=2, values_only=True)]
    assert rows and rows[0][1] == today.isoformat()
    assert rows[0][2] == rep["by_day"][0]["orders"]
    assert rows[0][3] == rep["by_day"][0]["revenue"]


# ================================================================ 22) replacement cost follows the same events
def test_22_replacement_cost_is_net_of_the_returns_of_the_range(client, admin, cashier, mgr):
    """`replacement_cost` ("what the sold materials would cost at today's prices") must follow the same events as
    COGS: a returned unit is no longer consumed, so it leaves both indicators in the same range."""
    i = ing(client, admin, "دانه جایگزینی", 100)
    it = item(client, admin, "قهوه جایگزینی", 200_000, [(i["id"], 2)])       # 200 at today's price
    before = pnl(client, admin)["replacement_cost"]
    o = sell(client, cashier, [{"menu_item_id": it["id"], "qty": 2}])        # +400 (2 × 200)
    assert pnl(client, admin)["replacement_cost"] - before == 400
    mid = pnl(client, admin)["replacement_cost"]
    settle(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}]).raise_for_status()
    after = pnl(client, admin)["replacement_cost"]
    assert mid - after == 200, (mid, after)          # one unit came back → 200 of replacement value returned
