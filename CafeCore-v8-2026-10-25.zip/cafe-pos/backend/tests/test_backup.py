"""Backup / restore / migration safety.

In-process tests use the test DB from conftest; the end-to-end test runs a REAL server on a temp data folder,
takes a backup through the API, stops the server, restores with the CLI and restarts.
"""
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
import pytest

from app.core import backup as bk
from app.core.config import get_settings

BACKEND = Path(__file__).resolve().parents[1]
ON_PG = bool(os.environ.get("CAFE_TEST_DATABASE_URL"))
# The same features exist on both engines, but the *file* layer differs (SQLite copy vs pg_dump), so the tests that
# manipulate the SQLite file directly only run there. PostgreSQL equivalents live in test_backup_drill.py.
sqlite_only = pytest.mark.skipif(ON_PG, reason="manipulates the SQLite database file")


@pytest.mark.skipif(not ON_PG, reason="PostgreSQL run only")
def test_pg_backup_uses_pg_dump_instead_of_a_file_copy(client, admin):
    """This used to answer «backup_unsupported»; PostgreSQL now gets a real pg_dump backup (rewritten test)."""
    assert client.get("/api/system/backups/policy", headers=admin).json()["database"] == "postgresql"
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code in (200, 201), r.text
    assert r.json()["name"].endswith(".dump")


@pytest.mark.skipif(not ON_PG, reason="PostgreSQL run only")
def test_pg_backup_without_pg_dump_installed_explains_the_problem(client, admin, monkeypatch):
    """A shop that installed the server but not the client tools must get an instruction, not a stack trace."""
    monkeypatch.setattr(bk, "pg_tools", lambda: {k: None for k in ("pg_dump", "pg_restore", "createdb", "dropdb", "psql")})
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code == 400, r.text
    assert r.json()["detail"]["code"] == "backup_failed"
    assert "pg_dump" in r.json()["detail"]["message"]
    st = client.get("/api/system/backups/status", headers=admin).json()
    assert st["errors"] and "pg_dump" in (st["errors"][0]["detail"] or "")


def _counts(db: Path) -> dict:
    con = sqlite3.connect(db)
    try:
        return {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("orders", "payments", "users", "order_lines")}
    finally:
        con.close()


@sqlite_only
def test_backup_via_api_is_consistent_and_downloadable(client, admin):
    r = client.post("/api/system/backups", headers=admin)
    assert r.status_code in (200, 201), r.text
    name = r.json()["name"]
    path = get_settings().backups_dir / name
    assert path.exists() and bk.verify(path)["integrity"] == "ok"
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    assert con.execute("PRAGMA journal_mode").fetchone()[0] == "delete"       # single self-contained file
    con.close()
    assert not list(get_settings().backups_dir.glob("*.tmp*")) and not list(get_settings().backups_dir.glob("*-wal"))
    assert _counts(path)["orders"] == _counts(bk.sqlite_path())["orders"]
    assert name in [b["name"] for b in client.get("/api/system/backups", headers=admin).json()]
    d = client.get(f"/api/system/backups/{name}", headers=admin)
    assert d.status_code == 200 and d.content[:16] == b"SQLite format 3\x00"


@sqlite_only
def test_corrupt_or_foreign_backup_gives_clear_error(tmp_path):
    junk = tmp_path / "junk.db"
    junk.write_bytes(os.urandom(8192))
    with pytest.raises(bk.BackupError, match="خراب"):
        bk.verify(junk)
    empty = tmp_path / "empty.db"
    empty.write_bytes(b"")
    with pytest.raises(bk.BackupError, match="خالی"):
        bk.verify(empty)
    other = tmp_path / "other.db"
    con = sqlite3.connect(other)
    con.execute("CREATE TABLE notes (id INTEGER)")
    con.commit()
    con.close()
    with pytest.raises(bk.BackupError, match="Cafe POS نیست"):
        bk.verify(other)
    # a real backup cut in half (e.g. interrupted copy to a USB stick)
    good = bk.create_backup("manual")
    half = tmp_path / "half.db"
    half.write_bytes(good.read_bytes()[: good.stat().st_size // 2])
    with pytest.raises(bk.BackupError):
        bk.verify(half)


@sqlite_only
def test_restore_replaces_data_and_keeps_previous_copy(tmp_path):
    snap = bk.create_backup("manual")
    expected = _counts(snap)
    target = tmp_path / "live.db"
    shutil.copy(snap, target)
    con = sqlite3.connect(target)                 # the "live" DB drifts after the backup was taken
    con.execute("PRAGMA foreign_keys=OFF")
    con.execute("DELETE FROM payments")
    con.execute("DELETE FROM order_lines")
    con.execute("DELETE FROM orders")
    con.commit()
    con.close()
    res = bk.restore_backup(snap, target=target)
    assert _counts(target) == expected
    safety = Path(res["safety_copy"])
    assert safety.exists() and "pre-restore" in safety.name and _counts(safety)["orders"] == 0


@sqlite_only
def test_failed_restore_leaves_current_db_untouched(tmp_path):
    target = tmp_path / "live.db"
    shutil.copy(bk.create_backup("manual"), target)
    before = _counts(target)
    junk = tmp_path / "junk.db"
    junk.write_bytes(os.urandom(4096))
    with pytest.raises(bk.BackupError):
        bk.restore_backup(junk, target=target)
    assert _counts(target) == before


def _touch(d, stamp, tag):
    p = d / f"cafe-{stamp}-{tag}.db"
    p.write_bytes(b"x")
    return p


def test_rotation_keeps_manual_and_limits_safety_copies(tmp_path):
    for d in range(1, 9):
        for tag in ("manual", "pre-upgrade"):
            _touch(tmp_path, f"202601{d:02d}-120000", tag)
    (tmp_path / "cafe-x.tmp").write_bytes(b"x")
    bk._rotate(tmp_path)
    names = sorted(p.name for p in tmp_path.iterdir())
    assert len([n for n in names if n.endswith("-manual.db")]) == 8                 # never deleted automatically
    assert len([n for n in names if n.endswith("-pre-upgrade.db")]) == 5
    assert not any(n.endswith(".tmp") for n in names)


def test_hourly_snapshots_collapse_to_the_last_one_per_finished_day(tmp_path):
    from datetime import date
    for h in range(10, 23):                                     # 22 Oct, 10:00 … 22:00
        _touch(tmp_path, f"20261022-{h:02d}0000", "hourly")
    _touch(tmp_path, "20261023-013000", "hourly")               # 01:30 → still business day 22 Oct (cutoff 05:00)
    _touch(tmp_path, "20261023-110000", "hourly")               # today (23 Oct)
    _touch(tmp_path, "20261023-120000", "hourly")
    _touch(tmp_path, "20261022-150000", "manual")
    bk.consolidate(tmp_path, cutoff_hour=5, today=date(2026, 10, 23))
    names = sorted(p.name for p in tmp_path.iterdir())
    assert names == ["cafe-20261022-150000-manual.db",
                     "cafe-20261023-013000-daily.db",           # last snapshot of the 22nd's business day, now daily
                     "cafe-20261023-110000-hourly.db", "cafe-20261023-120000-hourly.db"]   # today: untouched


def test_shift_close_keeps_one_backup_for_the_day(tmp_path):
    from datetime import date
    for h in (10, 11, 12):
        _touch(tmp_path, f"20261023-{h:02d}0000", "hourly")
    _touch(tmp_path, "20261023-123000", "daily")                # snapshot taken when the shift closed
    bk.consolidate(tmp_path, cutoff_hour=5, today=date(2026, 10, 23), close_day=date(2026, 10, 23))
    assert sorted(p.name for p in tmp_path.iterdir()) == ["cafe-20261023-123000-daily.db"]


def test_daily_backups_are_kept_for_14_business_days(tmp_path, monkeypatch):
    from datetime import date, timedelta
    monkeypatch.setattr(get_settings(), "backup_keep", 14)
    today = date(2026, 10, 23)
    for back in range(0, 20):
        d = today - timedelta(days=back)
        _touch(tmp_path, f"{d:%Y%m%d}-230000", "daily")
    _touch(tmp_path, "20260901-120000", "auto")                 # legacy automatic name, also expires
    bk.consolidate(tmp_path, cutoff_hour=5, today=today)
    days = sorted(p.name[5:13] for p in tmp_path.iterdir())
    assert len(days) == 14 and days[0] == f"{today - timedelta(days=13):%Y%m%d}" and days[-1] == f"{today:%Y%m%d}"


@sqlite_only
def test_auto_backup_only_when_due_and_data_changed(client, admin, monkeypatch):
    import os
    import time
    src = bk.sqlite_path()
    monkeypatch.setattr(get_settings(), "backup_interval_minutes", 60)
    assert bk.parse_name(bk.auto_backup(force=True))[1] == "hourly"
    assert bk.auto_backup() is None                             # less than an hour since the last snapshot
    monkeypatch.setattr(get_settings(), "backup_interval_minutes", 0)
    old = time.time() - 3600
    for f in (src, src.with_name(src.name + "-wal")):
        if f.exists():
            os.utime(f, (old, old))
    assert bk.auto_backup() is None                             # nothing written since → no new file
    future = time.time() + 5
    for f in (src, src.with_name(src.name + "-wal")):
        if f.exists():
            os.utime(f, (future, future))
    p = bk.auto_backup()
    assert p is not None and bk.parse_name(p)[1] == "hourly"     # (same-second names get a "-" suffix)
    bk.verify(p)


@sqlite_only
def test_shift_closed_backup_replaces_todays_hourlies(client, admin):
    from datetime import datetime
    d = get_settings().backups_dir
    bk.create_backup("hourly")
    today = bk.business_day_of(datetime.now(), 5)
    p = bk.shift_closed_backup()
    todays = [x for x in d.glob("cafe-*.db") if (i := bk.parse_name(x)) and i[1] in bk.AUTO_TAGS
              and bk.business_day_of(i[0], 5) == today]
    assert todays == [p] and p.name.endswith("-daily.db")


@sqlite_only
def test_additive_migration_preserves_data(tmp_path):
    """Simulate a database from the previous version (no payments.request_id) and upgrade it."""
    from sqlalchemy import create_engine

    from app.core.db import Base
    from app.core.migrate import plan, upgrade
    old = tmp_path / "old.db"
    shutil.copy(bk.create_backup("manual"), old)
    con = sqlite3.connect(old)
    for (idx,) in con.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='payments' AND sql LIKE '%request_id%'").fetchall():
        con.execute(f"DROP INDEX {idx}")
    con.execute("ALTER TABLE payments DROP COLUMN request_id")
    con.commit()
    con.close()
    before = _counts(old)
    eng = create_engine(f"sqlite:///{old}")
    made = []
    stmts = upgrade(eng, Base.metadata, backup=lambda tag: made.append(tag) or tmp_path / "x")
    assert any("request_id" in s for s in stmts) and made == ["pre-upgrade"]
    assert plan(eng, Base.metadata) == []                                        # idempotent
    eng.dispose()
    assert _counts(old) == before
    con = sqlite3.connect(old)
    cols = [r[1] for r in con.execute("PRAGMA table_info(payments)")]
    con.close()
    assert "request_id" in cols


# ------------------------------------------------------------------ end-to-end with a real server + CLI
def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _env(data, port):
    return {**os.environ, "CAFE_DATA_DIR": data, "CAFE_DEMO_DATA": "false", "CAFE_SAMPLE_USERS": "true",
            "CAFE_BACKGROUND_JOBS": "false", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_PORT": str(port)}


def _start(data, port):
    proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port),
                             "--log-level", "warning"], cwd=BACKEND, env=_env(data, port),
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    for _ in range(100):
        try:
            if httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1).status_code == 200:
                return proc
        except httpx.HTTPError:
            time.sleep(0.2)
    proc.kill()
    raise RuntimeError(proc.stderr.read().decode()[-2000:])


def _stop(proc):
    proc.terminate()
    proc.wait(15)


def _restore_cli(data, port, *args):
    return subprocess.run([sys.executable, "-m", "app.restore", *args], cwd=BACKEND, env=_env(data, port),
                          capture_output=True, text=True, timeout=60)


@sqlite_only
def test_real_backup_restore_restart_cycle():
    data = tempfile.mkdtemp(prefix="cafe-bk-")
    port = _free_port()
    base = f"http://127.0.0.1:{port}"
    proc = _start(data, port)
    try:
        login = lambda u, p: {"Authorization": "Bearer " + httpx.post(base + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]}
        h, adm = login("reza", "cashier123"), login("admin", "admin123")
        httpx.post(base + "/api/shifts/open", headers=h, json={"opening_cash": 0})
        full = httpx.get(base + "/api/menu/full", headers=h).json()
        groups = {g["id"]: g for g in full["modifier_groups"]}
        item = next(i for i in full["items"] if i["is_active"] and not (i["code"] or "").startswith("__")
                    and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))

        def order():
            o = httpx.post(base + "/api/orders", headers=h, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
            httpx.post(base + f"/api/orders/{o['id']}/payments", headers=h, json={"payments": [{"method": "card", "amount": o["total"]}]})
            return o["id"]
        kept = [order() for _ in range(3)]
        name = httpx.post(base + "/api/system/backups", headers=adm).json()["name"]
        lost = [order() for _ in range(2)]                       # made after the backup → gone after restore
        r = _restore_cli(data, port, name, "--yes")
        assert r.returncode == 2 and "running" in r.stdout       # refuses while the server is up
    finally:
        _stop(proc)

    junk = Path(data) / "junk.db"
    junk.write_bytes(os.urandom(4096))
    r = _restore_cli(data, port, str(junk), "--yes")
    assert r.returncode == 3 and "[ERROR]" in r.stdout

    r = _restore_cli(data, port, name, "--yes")
    assert r.returncode == 0, r.stdout + r.stderr
    assert list((Path(data) / "backups").glob("cafe-*-pre-restore.db"))

    proc = _start(data, port)                                     # restart on the restored DB
    try:
        h = {"Authorization": "Bearer " + httpx.post(base + "/api/staff/auth/login", json={"username": "reza", "password": "cashier123"}).json()["token"]}
        for oid in kept:
            o = httpx.get(base + f"/api/orders/{oid}", headers=h).json()
            assert o["status"] == "closed" and o["paid_amount"] == o["total"]
        for oid in lost:
            assert httpx.get(base + f"/api/orders/{oid}", headers=h).status_code == 404
    finally:
        _stop(proc)
    shutil.rmtree(data, ignore_errors=True)


@pytest.mark.skipif(not ON_PG, reason="PostgreSQL run only")
def test_pg_additive_migration_adds_missing_columns_with_defaults(client, admin):
    """An older PostgreSQL schema (column missing) is upgraded in place: column added, existing rows get the default."""
    from sqlalchemy import inspect, text

    from app.core.db import Base, engine
    from app.core.migrate import plan, upgrade
    with engine.begin() as c:
        c.execute(text("ALTER TABLE discount_presets DROP COLUMN auto_apply"))
        c.execute(text("ALTER TABLE order_lines DROP COLUMN returned_qty"))
    try:
        stmts = plan(engine, Base.metadata)
        assert any("auto_apply" in x and "DEFAULT false" in x for x in stmts), stmts
        assert any("returned_qty" in x and "BIGINT" in x and "DEFAULT 0" in x for x in stmts), stmts
    finally:
        upgrade(engine, Base.metadata)            # always put the columns back: later tests share this database
    cols = {c["name"]: c for c in inspect(engine).get_columns("discount_presets")}
    assert "auto_apply" in cols and plan(engine, Base.metadata) == []
    assert client.get("/api/orders/discounts/presets", headers=admin, params={"all": 1}).status_code == 200


def test_restore_cli_refuses_on_non_sqlite_database(monkeypatch, capsys):
    """The offline restore tool only knows SQLite files; on PostgreSQL it must stop with a pointer to pg_restore."""
    from types import SimpleNamespace

    import app.restore as restore_cli

    fake = SimpleNamespace(db_url="postgresql+psycopg://u@db/cafe", backups_dir=Path(tempfile.mkdtemp()), port=1)
    monkeypatch.setattr(restore_cli, "get_settings", lambda: fake)
    monkeypatch.setattr(restore_cli, "restore_backup", lambda *a, **k: pytest.fail("must not restore"))
    assert restore_cli.main(["whatever.db", "--yes"]) == 5
    assert "pg_restore" in capsys.readouterr().out
