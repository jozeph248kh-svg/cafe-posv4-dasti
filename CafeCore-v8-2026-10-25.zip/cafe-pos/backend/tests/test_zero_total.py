"""A bill that is fully discounted (100 % / «مهمان مدیر») has nothing to pay — but it must still be closable.

Real report from the shop: after a 100 % discount the payment dialog is dead (the submit button is disabled
because the remaining amount is 0) and the order can never be closed — it stays open on the table forever.
The cause: `add_payments()` required at least one payment with amount > 0, and its first check refused any
request once `remaining <= 0` ("مبلغ سفارش قبلاً کامل پرداخت شده است"). A zero-total bill therefore had no
path to "closed": only cancelling it, which would erase the sale from the books.

The fix keeps every existing rule (nothing is paid twice, nothing above the bill, no payment rows with amount 0)
and adds the missing case: when the order's total is 0 the settle call (an empty payment list) closes the bill.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _comped_order(client, cashier, mgr, menu, code="101", qty=2):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, code, qty)]}).json()
    r = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 100, "reason": "مهمان مدیر"})
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["total"] == 0 and o["remaining"] == 0 and o["status"] == "open"
    return o


def test_a_fully_discounted_bill_can_be_closed_without_payment(client, cashier, mgr, admin, menu):
    o = _comped_order(client, cashier, mgr, menu)
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})
    assert r.status_code == 200, r.text
    closed = r.json()
    assert closed["status"] == "closed"
    assert closed["total"] == 0 and closed["paid_amount"] == 0 and closed["payments"] == []
    assert closed["discount_amount"] == closed["subtotal"]          # the comp is visible in the money figures
    assert closed["closed_at"]

    # a sale with no payment is a money event: it must be in the audit trail
    rows = client.get("/api/system/audit", headers=admin,
                      params={"q": f"#{closed['number']}", "action": "order.close", "limit": 20}).json()
    assert rows and rows[0]["details"]["total"] == 0 and rows[0]["details"]["discount_amount"] == closed["subtotal"]


def test_the_comped_sale_is_in_the_sales_report_as_a_discount_not_a_cancellation(client, cashier, mgr, admin, menu):
    o = _comped_order(client, cashier, mgr, menu, code="104", qty=1)
    assert client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []}).status_code == 200
    rep = client.get("/api/reports/sales", headers=admin).json()
    assert rep["summary"]["orders"] >= 1                             # counted as a sale
    assert rep["summary"]["discounts"] >= o["subtotal"]              # and its comp is in the discounts line
    assert rep["summary"]["net"] >= 0


def test_closing_it_twice_is_harmless_and_logs_once(client, cashier, mgr, admin, menu):
    o = _comped_order(client, cashier, mgr, menu, code="104", qty=1)
    rid = "compclose01"
    first = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": [], "request_id": rid})
    second = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": [], "request_id": rid})
    third = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})       # fresh id
    assert first.status_code == 200 and second.status_code == 200 and third.status_code == 200
    assert second.json()["status"] == "closed" and third.json()["status"] == "closed"
    rows = client.get("/api/system/audit", headers=admin,
                      params={"q": f"#{o['number']}", "action": "order.close", "limit": 20}).json()
    assert len(rows) == 1                                           # one close, no duplicate history


def test_a_comped_bill_still_consumes_its_ingredients(client, cashier, mgr, admin, menu):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import StockMovement
    o = _comped_order(client, cashier, mgr, menu, code="101", qty=1)
    assert client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []}).status_code == 200
    with SessionLocal() as db:
        moves = db.query(StockMovement).filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                                               StockMovement.ref_id == o["id"]).count()
    assert moves >= 1                                               # same as a paid order: the stock really left


def test_a_comped_bill_with_unsent_items_still_reaches_the_kitchen(client, cashier, mgr, admin, menu):
    from app.core.db import SessionLocal
    from app.modules.kitchen.models import KitchenTicket
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "601", 1)]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 100, "reason": "مهمان مدیر"}).json()
    assert client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []}).status_code == 200
    with SessionLocal() as db:
        assert db.query(KitchenTicket).filter(KitchenTicket.order_id == o["id"]).count() >= 1


# ---------------------------------------------------------------- nothing else may change
def test_an_empty_payment_list_on_a_normal_bill_is_refused(client, cashier, menu):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "104", 1)]}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "payment_required"
    now = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert now["status"] == "open" and now["payments"] == [] and now["paid_amount"] == 0
    client.post(f"/api/orders/{o['id']}/cancel", headers=_login(client, "sara", "manager123"), json={"reason": "پایان تست"})


def test_money_cannot_be_taken_on_a_zero_bill(client, cashier, mgr, menu):
    o = _comped_order(client, cashier, mgr, menu, code="104", qty=1)
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": 50_000, "tendered": 50_000}]})
    assert r.status_code == 400
    now = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert now["paid_amount"] == 0 and now["payments"] == []          # no money recorded, bill still open
    assert client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []}).status_code == 200


def test_a_normal_paid_bill_behaves_exactly_as_before(client, cashier, menu):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 1)]}).json()
    first = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                        json={"payments": [{"method": "cash", "amount": o["total"]}]})
    assert first.status_code == 200 and first.json()["status"] == "closed"
    again = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                        json={"payments": [{"method": "cash", "amount": o["total"]}]})
    assert again.status_code == 400                                       # paying a closed bill is still refused
    empty = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})
    assert empty.status_code == 400
    assert len(client.get(f"/api/orders/{o['id']}", headers=cashier).json()["payments"]) == 1
