"""Round-2 financial audit: the eight reported defects, each pinned by a test.

Reported by the independent audit (R2-FIN-001, R2-INV-001..003, R2-REP-001, R2-UI-001) plus the two carried-over
items (zero-total bill, item profit vs bill discount). Every test below reproduced a real defect before the fix.

Definitions the fixes implement (see docs/FINANCIALS.md):
  net sales revenue = Σ closed bills (total − VAT) − Σ refunds (tax part excluded, revenue part reversed)
  COGS              = the material cost of what was SOLD, frozen at the moment of the sale
                      (item recipe + every chosen modifier recipe), minus the frozen cost of units actually
                      restocked by a refund
  gross profit      = net sales revenue − COGS − waste          (waste reduces gross profit, as before, once)
  net profit        = gross profit − operating expenses
  replacement cost  = the same recipes valued at TODAY's weighted-average cost — a separate indicator, never
                      substituted for historical COGS
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    """Open a register for this file and restore every pricing setting it touches (other files expect the
    defaults — the whole suite shares one database)."""
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    client.put("/api/system/settings", headers=admin, json=old)
    close_register(client, admin)


# ---------------------------------------------------------------- helpers
def _ing(client, admin, name, cost, stock=0.0, unit="g"):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": unit, "opening_stock": stock, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe=None, group=None):
    cats = client.get("/api/menu/categories", headers=admin).json()
    body = {"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True}
    if group:
        body["modifier_group_ids"] = [group["id"]]
    r = client.post("/api/menu/items", headers=admin, json=body)
    assert r.status_code == 201, r.text
    item = r.json()
    if recipe:
        rr = client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin,
                        json=[{"ingredient_id": i, "qty": q} for i, q in recipe])
        assert rr.status_code == 200, rr.text
    return item


def _group(client, admin, name, options):
    r = client.post("/api/menu/modifier-groups", headers=admin,
                    json={"name": name, "min_select": 0, "max_select": 1, "options": options})
    assert r.status_code == 201, r.text
    return r.json()


def _buy(client, admin, ing_id, qty, unit_cost):
    from datetime import date
    r = client.post("/api/inventory/purchases", headers=admin,
                    json={"purchase_date": date.today().isoformat(),
                          "lines": [{"ingredient_id": ing_id, "qty": qty, "unit_cost": unit_cost}]})
    assert r.status_code == 201, r.text
    return r.json()


def _sell(client, cashier, item, qty=1, option_ids=(), pay=True):
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": qty,
                                                         "modifier_option_ids": list(option_ids)}]})
    assert o.status_code == 201, o.text
    o = o.json()
    if pay:
        r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                        json={"payments": [] if o["total"] == 0 else [{"method": "cash", "amount": o["remaining"]}]})
        assert r.status_code == 200, r.text
        o = r.json()
    return o


def _pnl(client, admin):
    r = client.get("/api/expenses/pnl", headers=admin)
    assert r.status_code == 200, r.text
    return r.json()


def _sales(client, admin):
    r = client.get("/api/reports/sales", headers=admin)
    assert r.status_code == 200, r.text
    return r.json()


def _settings(client, admin, **kw):
    r = client.put("/api/system/settings", headers=admin, json=kw)
    assert r.status_code == 200, r.text


# ================================================================ bug 1 — R2-FIN-001
def test_full_refund_of_a_taxed_bill_leaves_zero_revenue(client, admin, cashier, mgr):
    """A full refund must reverse the revenue *and* the VAT, not drive revenue negative by the tax amount."""
    _settings(client, admin, **{"tax.enabled": True, "tax.percent": 9, "service.enabled": False, "service.percent": 0})
    ing = _ing(client, admin, "دانه تست مالیات", 100)
    item = _item(client, admin, "قهوه تست مالیات", 100_000, recipe=[(ing["id"], 1)])
    before = _pnl(client, admin)

    o = _sell(client, cashier, item, 1)
    assert o["tax_amount"] == 9_000 and o["total"] == 109_000
    # the bill's revenue (net of VAT) is 100,000 — the tax is collected, not earned
    assert _pnl(client, admin)["revenue"] - before["revenue"] == 100_000

    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 109_000, "reason": "کنسلی کامل"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["revenue"] == before["revenue"], (after["revenue"], before["revenue"])
    assert after["sales"]["refunds"] - before["sales"]["refunds"] == 109_000
    # the VAT that was taken from the customer is gone too (it is not revenue and not tax due any more)
    assert after["sales"]["tax"] == before["sales"]["tax"]


def test_partial_refund_reverses_revenue_and_tax_in_proportion(client, admin, cashier, mgr):
    _settings(client, admin, **{"tax.enabled": True, "tax.percent": 10, "service.enabled": False, "service.percent": 0})
    ing = _ing(client, admin, "دانه تست مالیات ۲", 100)
    item = _item(client, admin, "قهوه تست مالیات ۲", 200_000, recipe=[(ing["id"], 1)])
    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 1)                       # 200,000 + 20,000 VAT
    assert o["total"] == 220_000
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 110_000, "reason": "نصف"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    # half of the money back = half of the revenue (100,000) and half of the VAT (10,000)
    assert after["revenue"] - before["revenue"] == 100_000
    assert after["sales"]["tax"] - before["sales"]["tax"] == 10_000


def test_refund_on_a_later_day_is_booked_on_the_refund_day(client, admin, cashier, mgr):
    """The refund's revenue reversal belongs to the day the money went back, not to the day of the sale."""
    from app.core.db import SessionLocal
    from app.core.utils import business_day
    from app.modules.orders.models import Payment

    _settings(client, admin, **{"tax.enabled": True, "tax.percent": 10})
    ing = _ing(client, admin, "دانه تست روز دیگر", 100)
    item = _item(client, admin, "قهوه تست روز دیگر", 100_000, recipe=[(ing["id"], 1)])
    today = business_day()
    q = {"date_from": today.isoformat(), "date_to": today.isoformat()}

    def pnl_today():
        r = client.get("/api/expenses/pnl", headers=admin, params=q)
        assert r.status_code == 200, r.text
        return r.json()

    before_sale = pnl_today()
    o = _sell(client, cashier, item, 1)                      # 100,000 + 10,000 VAT, today
    before = pnl_today()
    assert before["revenue"] - before_sale["revenue"] == 100_000
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 110_000, "reason": "روز بعد"})
    assert r.status_code == 200, r.text
    with SessionLocal() as db:                               # pretend the money went back yesterday
        from datetime import datetime, timedelta
        p = db.query(Payment).filter(Payment.order_id == o["id"], Payment.is_refund.is_(True)).first()
        p.created_at = datetime.now() - timedelta(days=1)
        db.commit()
    after = pnl_today()
    assert after["revenue"] == before["revenue"]             # today is untouched by yesterday's refund
    assert after["sales"]["refunds"] == before["sales"]["refunds"]   # …not in today's money-back line either
    assert after["cogs"] == before["cogs"]                   # nor does a refund-without-restock change today's COGS


# ================================================================ bug 2 — R2-INV-001
def test_cogs_includes_the_recipe_of_the_chosen_modifier(client, admin, cashier):
    base_ing = _ing(client, admin, "شیر تست افزودنی", 10)          # 100 g × 10 = 1,000
    mod_ing = _ing(client, admin, "سیروپ تست افزودنی", 20)         # 50 g × 20 = 1,000
    grp = _group(client, admin, "شیرین‌کننده تست", [
        {"name": "معمولی", "price_delta": 0, "is_default": True, "is_available": True},
        {"name": "با سیروپ", "price_delta": 20_000, "is_default": False, "is_available": True},
    ])
    syrup = next(o for o in grp["options"] if o["name"] == "با سیروپ")
    client.put(f"/api/inventory/recipes/option/{syrup['id']}", headers=admin,
               json=[{"ingredient_id": mod_ing["id"], "qty": 50}]).raise_for_status()
    item = _item(client, admin, "لاته تست افزودنی", 120_000, recipe=[(base_ing["id"], 100)], group=grp)

    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 1, option_ids=[syrup["id"]])
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 2_000, (after["cogs"] - before["cogs"])   # base 1,000 + syrup 1,000

    # …and the stock of both ingredients moved (the inventory side always knew about the modifier)
    ings = {i["id"]: i for i in client.get("/api/inventory/ingredients", headers=admin).json()}
    assert ings[base_ing["id"]]["stock"] == pytest.approx(-100)
    assert ings[mod_ing["id"]]["stock"] == pytest.approx(-50)
    # the item's own cost in the report includes the modifier too (no double count, no gap)
    rep = _sales(client, admin)
    row = next(i for i in rep["by_item"] if i["id"] == item["id"])
    assert row["cost"] == 2_000


# ================================================================ bug 3 — R2-INV-002
def test_a_full_refund_with_restock_reverses_cogs(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تست مرجوعی", 500, stock=10_000)
    item = _item(client, admin, "قهوه تست مرجوعی", 150_000, recipe=[(ing["id"], 2)])   # 1,000 per unit
    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 2)                                              # COGS 2,000
    assert _pnl(client, admin)["cogs"] - before["cogs"] == 2_000

    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": o["total"], "reason": "برگشت کامل",
                          "restock": [{"line_id": o["lines"][0]["id"], "qty": 2}]})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["cogs"] == before["cogs"]           # both units came back: the goods were not consumed


def test_a_refund_without_restock_keeps_the_cogs(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تست بدون برگشت", 400, stock=10_000)
    item = _item(client, admin, "قهوه تست بدون برگشت", 150_000, recipe=[(ing["id"], 2)])
    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 2)
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": o["total"], "reason": "دور ریخته شد"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 1_600    # the materials were used up: the cost stays


def test_a_partial_restock_reverses_only_that_quantity(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تست برگشت جزئی", 300, stock=10_000)
    item = _item(client, admin, "قهوه تست برگشت جزئی", 150_000, recipe=[(ing["id"], 2)])   # 600 per unit
    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 3)                                          # COGS 1,800
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 150_000, "reason": "یکی برگشت",
                          "restock": [{"line_id": o["lines"][0]["id"], "qty": 1}]})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["cogs"] - before["cogs"] == 1_200                            # 2 units stayed consumed
    # the same number must appear in the item table (COGS per item after the return)
    rep = _sales(client, admin)
    assert next(i for i in rep["by_item"] if i["id"] == item["id"])["cost"] >= 1_200


# ================================================================ bug 4 — R2-INV-003
def test_a_new_purchase_does_not_change_the_profit_of_past_sales(client, admin, cashier):
    ing = _ing(client, admin, "دانه تست تورم", 10, stock=100)
    item = _item(client, admin, "قهوه تست تورم", 100_000, recipe=[(ing["id"], 5)])    # COGS 50 at cost 10
    before = _pnl(client, admin)
    _sell(client, cashier, item, 1)
    after_sale = _pnl(client, admin)
    assert after_sale["cogs"] - before["cogs"] == 50

    _buy(client, admin, ing["id"], 100, 30)                     # the price triples the next day
    after_buy = _pnl(client, admin)
    assert after_buy["cogs"] == after_sale["cogs"]              # the historic profit did not move
    assert after_buy["gross_profit"] == after_sale["gross_profit"]

    # the inventory value follows the new weighted average …
    ings = {i["id"]: i for i in client.get("/api/inventory/ingredients", headers=admin).json()}
    assert ings[ing["id"]]["cost_per_unit"] > 10
    # … and the replacement cost is its own indicator (recipe at TODAY's cost), not a rewrite of COGS
    assert after_buy["replacement_cost"] >= 5 * ings[ing["id"]]["cost_per_unit"] - 1
    assert after_buy["replacement_cost"] > after_buy["cogs"]


def test_historical_cogs_survives_many_purchases_and_is_visible_in_the_item_table(client, admin, cashier):
    ing = _ing(client, admin, "دانه تست تورم ۲", 100, stock=1_000)
    item = _item(client, admin, "قهوه تست تورم ۲", 500_000, recipe=[(ing["id"], 2)])   # COGS 200
    rep0 = _sales(client, admin)
    row0 = next((i for i in rep0["by_item"] if i["id"] == item["id"]), {"cost": 0})
    _sell(client, cashier, item, 1)
    _buy(client, admin, ing["id"], 1_000, 900)
    rep1 = _sales(client, admin)
    row1 = next(i for i in rep1["by_item"] if i["id"] == item["id"])
    assert row1["cost"] - row0["cost"] == 200, (row1["cost"], row0["cost"])


# ================================================================ bug 5 — R2-REP-001
def test_the_daily_series_counts_waste_and_adds_up_to_the_net_profit(client, admin):
    ing = _ing(client, admin, "دانه تست ضایعات", 1_000, stock=100)
    before = _pnl(client, admin)
    r = client.post(f"/api/inventory/ingredients/{ing['id']}/adjust", headers=admin,
                    json={"kind": "waste", "qty": 3, "note": "ریخت"})
    assert r.status_code == 200, r.text
    after = _pnl(client, admin)
    assert after["waste"] - before["waste"] == 3_000
    assert after["gross_profit"] - before["gross_profit"] == -3_000
    # the daily series must carry the same waste (it used to ignore it)
    assert sum(d["profit"] for d in after["series"]) == after["net_profit"]
    assert sum(d["cumulative"] for d in after["series"][-1:]) == after["net_profit"]


def test_series_and_summary_agree_on_a_mixed_day(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تست سری", 50, stock=1_000)
    item = _item(client, admin, "قهوه تست سری", 200_000, recipe=[(ing["id"], 4)])
    _sell(client, cashier, item, 2)
    client.post(f"/api/inventory/ingredients/{ing['id']}/adjust", headers=admin,
                json={"kind": "waste", "qty": 2, "note": "تست"})
    from datetime import date
    client.post("/api/expenses", headers=admin,
                json={"category_id": client.get("/api/expenses/categories", headers=admin).json()[0]["id"],
                      "amount": 25_000, "expense_date": date.today().isoformat(), "note": "تست سری"})
    p = _pnl(client, admin)
    assert sum(d["profit"] for d in p["series"]) == p["net_profit"]
    for key in ("revenue", "cogs", "expenses"):
        assert sum(d[key] for d in p["series"]) == p[key], key
    assert sum(d["waste"] for d in p["series"]) == p["waste"]


# ================================================================ bug 6 — R2-UI-001  (API side of the sign)
def test_a_negative_net_profit_is_returned_with_its_sign(client, admin):
    """The UI must not lose the sign; the API has to give it a sign to show."""
    ing = _ing(client, admin, "دانه تست زیان", 9_000_000, stock=10)
    item = _item(client, admin, "قهوه تست زیان", 10_000, recipe=[(ing["id"], 1)])
    _sell(client, cashier=_login(client, "reza", "cashier123"), item=item, qty=1) if False else None
    p = _pnl(client, admin)
    assert isinstance(p["net_profit"], int)          # a plain signed number, not a formatted string
    assert isinstance(p["gross_profit"], int)


# ================================================================ Excel / API parity
def test_the_excel_export_matches_the_api_numbers(client, admin, cashier):
    import io

    from openpyxl import load_workbook
    _sell(client, cashier, _item(client, admin, "قهوه تست اکسل", 90_000), 1)
    rep = _sales(client, admin)
    r = client.get("/api/reports/sales/export", headers=admin)
    assert r.status_code == 200 and r.content[:2] == b"PK"
    wb = load_workbook(io.BytesIO(r.content))
    assert "آیتم‌ها" in wb.sheetnames
    ws = wb["آیتم‌ها"]
    header = [c.value for c in ws[1]]
    assert "فروش (تومان)" in header and "بهای تمام‌شده (تومان)" in header and "سود (تومان)" in header
    sheet_profit = sum((row[header.index("سود (تومان)")] or 0) for row in ws.iter_rows(min_row=2, values_only=True))
    api_profit = sum(i["profit"] for i in rep["by_item"])
    assert sheet_profit == api_profit


# ================================================================ legacy rows (no frozen cost) + migration
def test_a_legacy_sale_without_a_frozen_cost_is_valued_from_its_stock_movements(client, admin, cashier):
    """Sales written before this column existed have cost_amount = NULL. They must still be costed from the
    historical sale movements (never from today's price), and the report has to say the figure is estimated."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order, OrderLine
    from app.modules.inventory.models import StockMovement

    ing = _ing(client, admin, "دانه تست قدیمی", 40, stock=1_000)
    item = _item(client, admin, "قهوه تست قدیمی", 100_000, recipe=[(ing["id"], 3)])     # 120 per unit
    before = _pnl(client, admin)
    o = _sell(client, cashier, item, 1)
    assert _pnl(client, admin)["cogs"] - before["cogs"] == 120
    with SessionLocal() as db:                       # simulate a row written before the migration
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).first()
        ln.cost_amount = None
        db.commit()
    _buy(client, admin, ing["id"], 100, 400)         # the price goes ×10
    after = _pnl(client, admin)
    assert after["cogs"] == before["cogs"] + 120     # still the historical cost, not 1,200
    assert after["cogs_estimated_lines"] >= 1        # …and the report admits it had to estimate that row
    assert "cogs_unknown_lines" in after             # unknown and estimated are two different states


def test_the_new_column_is_added_to_an_existing_database(client, admin):
    """Additive migration: a database from the previous release gets the column without any data rewrite."""
    from sqlalchemy import inspect

    from app.core.db import engine

    cols = {c["name"] for c in inspect(engine).get_columns("order_lines")}
    assert "cost_amount" in cols
    # the old rows kept their values (nothing rewritten): the column is nullable and the existing sales still list
    assert client.get("/api/orders", headers=admin).status_code == 200


# ================================================================ bug 7 — zero-total bill (DB side)
def test_a_zero_total_bill_closes_without_any_payment_row_in_the_database(client, admin, cashier, mgr):
    """A valid 100 %-discounted bill: closed, audited, stock consumed — and NOT ONE fake payment row."""
    from app.core.db import SessionLocal
    from app.core.models import AuditLog
    from app.modules.inventory.models import StockMovement
    from app.modules.orders.models import Order, Payment

    ing = _ing(client, admin, "دانه تست صفرمبلغ", 250, stock=1_000)
    item = _item(client, admin, "قهوه تست صفرمبلغ", 180_000, recipe=[(ing["id"], 2)])
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 100, "reason": "مهمان مدیر"}).json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []})
    assert r.status_code == 200 and r.json()["status"] == "closed"

    with SessionLocal() as db:
        assert db.query(Payment).filter(Payment.order_id == o["id"]).count() == 0        # no fake money
        order = db.get(Order, o["id"])
        assert order.paid_amount == 0 and order.total == 0 and order.closed_at is not None
        assert order.lines[0].cost_amount == 500                                        # COGS frozen (2 × 250)
        assert db.query(StockMovement).filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                                              StockMovement.ref_id == o["id"]).count() >= 1
        assert db.query(AuditLog).filter(AuditLog.action == "order.close",
                                         AuditLog.entity_id == str(o["id"])).count() == 1
    # an EMPTY order (no items) is still refused — free ≠ nothing
    empty = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": []})
    assert empty.status_code == 201                                            # an empty basket can be opened…
    r = client.post(f"/api/orders/{empty.json()['id']}/payments", headers=cashier, json={"payments": []})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "empty_order"  # …but not settled as a sale
    client.post(f"/api/orders/{empty.json()['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
