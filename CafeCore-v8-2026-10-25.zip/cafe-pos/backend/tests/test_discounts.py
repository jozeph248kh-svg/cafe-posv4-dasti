"""Discounts: item + bill discounts, presets, per-role/per-user ceilings and manager approval."""
import pytest
from conftest import _login, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture()
def order(client, cashier, mgr, menu):
    """A takeaway order: 2 × item 101 + 1 × item 104 (no tax/service on takeaway is irrelevant: we check discounts)."""
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 2), line(menu, "104")]}).json()
    yield o
    client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


def _roles(client, admin):
    return {r["title"]: r for r in client.get("/api/orders/discounts/limits", headers=admin).json()["roles"]}


def _audit(client, admin, text):
    return client.get("/api/system/audit", headers=admin, params={"q": text, "limit": 20}).json()


def test_presets_route_is_not_shadowed_by_order_id(client, cashier):
    r = client.get("/api/orders/discounts/presets", headers=cashier)
    assert r.status_code == 200 and isinstance(r.json(), list)
    me = client.get("/api/orders/discounts/my-limit", headers=cashier).json()
    assert me == {"can_discount": True, "max_pct": 10, "max_amount": None, "can_manage": False, "reason_required": True,
                  "max_daily": None, "max_monthly": None, "used_today": None, "used_month": None}


def test_cashier_ceiling_and_manager_approval(client, cashier, admin, order):
    oid = order["id"]
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 10, "reason": "مشتری دائمی"})
    assert r.status_code == 200 and r.json()["discount_amount"] == round(order["subtotal"] * 0.10)      # within 10%
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 25, "reason": "جبران"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required" and "10٪" in r.json()["detail"]["message"]
    r = client.post(f"/api/orders/{oid}/discount", headers={**cashier, "X-Manager-Pin": "3333"},   # own PIN: ceiling still 10%
                    json={"type": "percent", "value": 25, "reason": "جبران"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_invalid"
    r = client.post(f"/api/orders/{oid}/discount", headers={**cashier, "X-Manager-Pin": "2222"}, json={"type": "percent", "value": 25, "reason": "جبران"})
    assert r.status_code == 200 and r.json()["discount_amount"] == round(order["subtotal"] * 0.25)
    log = _audit(client, admin, f"#{order['number']}: 25٪")
    assert log and log[0]["approver_name"] == "سارا احمدی"
    # lowering / removing never needs a PIN
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": None})
    assert r.status_code == 200 and r.json()["discount_amount"] == 0


def test_amount_discount_is_checked_as_a_percentage_too(client, cashier, order):
    big = round(order["subtotal"] * 0.5)
    r = client.post(f"/api/orders/{order['id']}/discount", headers=cashier, json={"type": "amount", "value": big, "reason": "x"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"


def test_item_discount_and_stacking_is_limited(client, cashier, order):
    oid, l101 = order["id"], next(x for x in order["lines"] if x["qty"] == 2)
    r = client.post(f"/api/orders/{oid}/lines/{l101['id']}/discount", headers=cashier, json={"type": "percent", "value": 10, "reason": "سوخته"})
    assert r.status_code == 200, r.text
    o = r.json()
    ld = round(l101["total"] * 0.10)
    line_out = next(x for x in o["lines"] if x["id"] == l101["id"])
    assert line_out["discount_amount"] == ld and line_out["discount_reason"] == "سوخته"
    assert o["line_discount_amount"] == ld and o["discount_amount"] == ld and o["total"] == o["subtotal"] - ld + o["tax_amount"] + o["rounding"]
    # bill discount on top: 10% of what's left — total would exceed the cashier's 10% → needs approval
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 10, "reason": "مشتری"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"
    o = client.post(f"/api/orders/{oid}/discount", headers={**cashier, "X-Manager-Pin": "2222"}, json={"type": "percent", "value": 10, "reason": "مشتری"}).json()
    bill = round((o["subtotal"] - ld) * 0.10)
    assert o["discount_amount"] == ld + bill and o["line_discount_amount"] == ld


def test_split_shares_a_fixed_item_discount_by_quantity(client, cashier, mgr, order):
    oid, l101 = order["id"], next(x for x in order["lines"] if x["qty"] == 2)
    client.post(f"/api/orders/{oid}/lines/{l101['id']}/discount", headers=mgr, json={"type": "amount", "value": 20_000, "reason": "تست"}).raise_for_status()
    new = client.post(f"/api/orders/{oid}/split", headers=mgr, json={"lines": [{"line_id": l101["id"], "qty": 1}]}).json()
    old = client.get(f"/api/orders/{oid}", headers=mgr).json()
    assert new["line_discount_amount"] == 10_000 and old["line_discount_amount"] == 10_000
    client.post(f"/api/orders/{new['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


def test_presets_rules(client, cashier, mgr, admin, order):
    oid = order["id"]
    mk = lambda **kw: client.post("/api/orders/discounts/presets", headers=mgr, json={"name": "تست", **kw})  # noqa: E731
    assert client.post("/api/orders/discounts/presets", headers=cashier, json={"name": "x"}).status_code == 403
    staff = mk(name="کارمندی", kind="percent", value=10, max_amount=5_000, color="#16a34a").json()
    o = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"preset_id": staff["id"]}).json()
    assert o["discount_amount"] == 5_000 and o["discount_preset_id"] == staff["id"]          # 10% capped at 5,000

    guest = mk(name="مهمان مدیر", kind="percent", value=5, requires_manager=True, reason_required=True).json()
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"preset_id": guest["id"]})
    assert r.status_code == 400                                                                 # reason required
    r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"preset_id": guest["id"], "reason": "آقای الف"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"           # even though 5% < 10%
    r = client.post(f"/api/orders/{oid}/discount", headers={**cashier, "X-Manager-Pin": "2222"}, json={"preset_id": guest["id"], "reason": "آقای الف"})
    assert r.status_code == 200 and r.json()["discount_reason"] == "مهمان مدیر — آقای الف"

    never = mk(name="هپی‌آور", kind="percent", value=5, start_time="03:00", end_time="03:01").json()
    listed = {p["id"]: p for p in client.get("/api/orders/discounts/presets", headers=cashier, params={"order_id": oid}).json()}
    if listed[never["id"]]["unavailable"]:
        r = client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"preset_id": never["id"]})
        assert r.status_code == 400 and r.json()["detail"]["code"] == "discount_unavailable"

    item_only = mk(name="آیتم سوخته", kind="percent", value=0, scope="item").json()               # open value
    assert client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"preset_id": item_only["id"], "value": 5}).status_code == 400
    lid = order["lines"][0]["id"]
    assert client.post(f"/api/orders/{oid}/lines/{lid}/discount", headers=cashier, json={"preset_id": item_only["id"]}).status_code == 400
    o = client.post(f"/api/orders/{oid}/lines/{lid}/discount", headers=mgr, json={"preset_id": item_only["id"], "value": 100}).json()
    assert next(x for x in o["lines"] if x["id"] == lid)["discount_amount"] == order["lines"][0]["total"]   # comp the item

    assert client.post("/api/orders/discounts/presets", headers=mgr, json={"name": "بد", "kind": "percent", "value": 150}).status_code == 400
    for p in (staff, guest, never, item_only):
        assert client.delete(f"/api/orders/discounts/presets/{p['id']}", headers=mgr).status_code == 204


def test_manager_sets_cashier_ceiling(client, cashier, mgr, admin, order):
    oid = order["id"]
    roles = _roles(client, admin)
    cashier_role, manager_role = roles["صندوقدار"], roles["مدیر داخلی"]
    assert client.get("/api/orders/discounts/limits", headers=cashier).status_code == 403
    try:
        assert client.put("/api/orders/discounts/limits", headers=mgr, json={"kind": "role", "id": cashier_role["id"], "max_discount_pct": 20}).status_code == 200
        assert client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 20, "reason": "x"}).status_code == 200
        # a personal ceiling overrides the role's
        reza = next(u for u in client.get("/api/orders/discounts/limits", headers=mgr).json()["users"] if u["full_name"] == "رضا کریمی")
        client.put("/api/orders/discounts/limits", headers=mgr, json={"kind": "user", "id": reza["id"], "max_discount_pct": 5}).raise_for_status()
        client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": None}).raise_for_status()   # lowering: always allowed
        assert client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 6, "reason": "x"}).status_code == 403
        assert client.post(f"/api/orders/{oid}/discount", headers=cashier, json={"type": "percent", "value": 5, "reason": "x"}).status_code == 200
        client.put("/api/orders/discounts/limits", headers=mgr, json={"kind": "user", "id": reza["id"]}).raise_for_status()
        # nobody can hand out more than they have; admin's role has no ceiling to set
        client.put("/api/orders/discounts/limits", headers=admin, json={"kind": "role", "id": manager_role["id"], "max_discount_pct": 30}).raise_for_status()
        r = client.put("/api/orders/discounts/limits", headers=mgr, json={"kind": "role", "id": cashier_role["id"], "max_discount_pct": 50})
        assert r.status_code == 403
        r = client.put("/api/orders/discounts/limits", headers=mgr, json={"kind": "role", "id": cashier_role["id"]})       # = unlimited
        assert r.status_code == 403
        admin_role = roles["مدیر کل"]
        assert client.put("/api/orders/discounts/limits", headers=admin, json={"kind": "role", "id": admin_role["id"], "max_discount_pct": 5}).status_code == 400
        assert _audit(client, admin, "سقف تخفیف «صندوقدار»")
    finally:
        client.put("/api/orders/discounts/limits", headers=admin, json={"kind": "role", "id": manager_role["id"]})
        client.put("/api/orders/discounts/limits", headers=admin, json={"kind": "role", "id": cashier_role["id"], "max_discount_pct": 10})


def test_waiter_without_permission_needs_a_pin(client, waiter, order):
    r = client.post(f"/api/orders/{order['id']}/discount", headers=waiter, json={"type": "percent", "value": 1})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"
    assert client.get("/api/orders/discounts/my-limit", headers=waiter).json()["max_pct"] == 0
