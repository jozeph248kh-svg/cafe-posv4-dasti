"""Phone numbers are the join key between orders, the customer file, loyalty and SMS.

These tests pin the canonical form `09xxxxxxxxx` (and `0xxxxxxxxxx` for landlines) so the same
person typed in different ways always lands on one record — the bug this file was written for:
`0098912…` (the way many contact books export an international number) and `912…` (no leading
zero) used to be stored verbatim, creating a duplicate customer, missing the loyalty wallet and
sending SMS to an invalid number.
"""
import pytest

from app.core.errors import AppError
from app.core.utils import normalize_phone

CANONICAL = "09123456789"


@pytest.mark.parametrize("typed", [
    "09123456789",
    "0912 345 6789",
    "0912-345-6789",
    "۰۹۱۲۳۴۵۶۷۸۹",          # Persian digits
    "٠٩١٢٣٤٥٦٧٨٩",          # Arabic-Indic digits
    "+989123456789",
    "+98 912 345 6789",
    "989123456789",
    "00989123456789",        # international prefix typed as 00 — used to be stored verbatim
    "0098 912 345 6789",
    "9123456789",            # no leading zero — used to be stored verbatim
])
def test_every_way_of_typing_a_mobile_gives_one_canonical_number(typed):
    assert normalize_phone(typed) == CANONICAL


@pytest.mark.parametrize("typed,expected", [
    ("02188776655", "02188776655"),
    ("021 8877 6655", "02188776655"),
    ("+982188776655", "02188776655"),
    ("00982188776655", "02188776655"),
])
def test_landlines_keep_their_area_code(typed, expected):
    assert normalize_phone(typed) == expected


def test_empty_input_is_none():
    assert normalize_phone("") is None and normalize_phone(None) is None


def test_masked_numbers_are_rejected_instead_of_stored():
    with pytest.raises(AppError):
        normalize_phone("0912***4567")


def test_the_same_customer_is_not_duplicated_by_a_differently_typed_number(client, admin):
    phone = "09127770888"
    first = client.post("/api/customers", headers=admin, json={"name": "مشتری شماره ۱", "phone": phone})
    assert first.status_code in (201, 400), first.text
    # the same person, this time typed with the 00 international prefix and a space
    other = client.post("/api/customers", headers=admin, json={"name": "مشتری شماره ۲", "phone": "00989127770888"})
    assert other.status_code == 400, f"a second record was created for the same number: {other.text}"
    rows = client.get("/api/customers", headers=admin, params={"q": phone}).json()
    assert len([c for c in rows if c["phone"] == phone]) == 1
