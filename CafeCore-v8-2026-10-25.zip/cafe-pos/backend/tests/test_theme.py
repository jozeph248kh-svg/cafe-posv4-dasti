"""Round 9: business theme / skins — public read, permission-checked strict write, audit + generic-settings isolation."""
import copy

import pytest

COLORS = {"primary": "#4f46e5", "bg": "#f4f5fb", "card": "#ffffff", "text": "#0f172a", "muted": "#5b6678", "border": "#e5e7ef",
          "sider": "#111827", "success": "#10b981", "warning": "#f59e0b", "error": "#ef4444", "info": "#3b82f6"}
DARK = {**COLORS, "bg": "#0b0f19", "card": "#141a2a", "text": "#e5e7eb", "muted": "#9aa6b8", "border": "#263049"}
SKIN = {"id": "my-brand", "name": "برند من", "base": "classic", "light": COLORS, "dark": DARK,
        "palette": ["#6366f1", "#10b981", "#f59e0b"], "radius": 14, "font_scale": 1.1, "density": "compact", "font": "tahoma"}


@pytest.fixture(autouse=True)
def _restore(client, admin):
    yield
    r = client.put("/api/system/theme", headers=admin, json={"skin": "classic", "custom": []})
    assert r.status_code == 200, r.text


def test_default_theme_is_public_and_classic(client):
    r = client.get("/api/system/theme")                      # no token: the login page needs it
    assert r.status_code == 200
    assert r.json() == {"skin": "classic", "custom": []}


def test_write_requires_settings_permission(client, waiter, cashier):
    body = {"skin": "latte", "custom": []}
    assert client.put("/api/system/theme", json=body).status_code == 401
    assert client.put("/api/system/theme", headers=waiter, json=body).status_code == 403
    assert client.put("/api/system/theme", headers=cashier, json=body).status_code == 403
    assert client.get("/api/system/theme").json()["skin"] == "classic"


def test_admin_saves_builtin_and_custom_skin(client, admin):
    r = client.put("/api/system/theme", headers=admin, json={"skin": "latte", "custom": []})
    assert r.status_code == 200, r.text
    assert client.get("/api/system/theme").json()["skin"] == "latte"

    r = client.put("/api/system/theme", headers=admin, json={"skin": "my-brand", "custom": [SKIN]})
    assert r.status_code == 200, r.text
    got = client.get("/api/system/theme").json()
    assert got["skin"] == "my-brand" and got["custom"][0]["name"] == "برند من"
    assert got["custom"][0]["font"] == "tahoma" and got["custom"][0]["density"] == "compact" and got["custom"][0]["radius"] == 14

    audit = client.get("/api/system/audit", headers=admin, params={"q": "تم"}).json()
    rows = audit.get("items", audit) if isinstance(audit, dict) else audit
    assert any(a.get("action") == "theme.update" for a in rows), rows[:3]


def test_generic_settings_endpoint_cannot_touch_theme(client, admin):
    client.put("/api/system/settings", headers=admin, json={"ui.theme": {"skin": "rose", "custom": []}})
    assert client.get("/api/system/theme").json()["skin"] == "classic"


@pytest.mark.parametrize("mutate, status", [
    (lambda b: b["custom"][0]["light"].update(primary="red"), 422),                  # not a hex colour
    (lambda b: b["custom"][0]["light"].update(primary="#12345"), 422),
    (lambda b: b["custom"][0]["dark"].pop("text"), 422),                              # missing colour
    (lambda b: b["custom"][0]["light"].update(evil="#000000"), 422),                  # unknown colour key
    (lambda b: b["custom"][0].update(radius=99), 422),
    (lambda b: b["custom"][0].update(font_scale=3), 422),
    (lambda b: b["custom"][0].update(font="comic"), 422),
    (lambda b: b["custom"][0].update(palette=["#000000"]), 422),
    (lambda b: b["custom"][0].update(id="Bad Id!"), 422),
    (lambda b: b["custom"][0].update(name="x" * 41), 422),
    (lambda b: b.update(skin="does-not-exist"), 400),
    (lambda b: b["custom"][0].update(id="classic"), 400),                             # collides with a built-in
    (lambda b: b["custom"].append(copy.deepcopy(b["custom"][0])), 400),               # duplicate id
    (lambda b: b.update(custom=[{**copy.deepcopy(SKIN), "id": f"s{i:02d}"} for i in range(21)], skin="classic"), 422),
])
def test_invalid_themes_are_rejected(client, admin, mutate, status):
    body = {"skin": "my-brand", "custom": [copy.deepcopy(SKIN)]}
    mutate(body)
    r = client.put("/api/system/theme", headers=admin, json=body)
    assert r.status_code == status, r.text
    assert client.get("/api/system/theme").json()["skin"] == "classic"
