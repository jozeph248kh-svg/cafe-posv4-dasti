"""Packaging & deployment guards: the things that made earlier releases ship without a UI.

These are deliberately file-level assertions: they fail the moment somebody re-introduces the old
`dist` folder name in a launcher, or splits the "UI is missing" answer into two different messages.
"""
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
import pytest

from app.core.config import FRONTEND_DIST, PROJECT_DIR, get_settings

ROOT = PROJECT_DIR


def test_prebuilt_ui_is_where_the_backend_serves_it_from():
    assert FRONTEND_DIST == ROOT / "frontend" / "ui"
    assert (FRONTEND_DIST / "index.html").is_file(), "the prebuilt UI must be committed (the shop PC has no Node.js)"
    assert len(list((FRONTEND_DIST / "assets").glob("*.js"))) > 10


def test_vite_builds_into_that_folder():
    cfg = (ROOT / "frontend" / "vite.config.js").read_text(encoding="utf-8")
    assert re.search(r"outDir:\s*'ui'", cfg), "vite must build into frontend/ui"


@pytest.mark.parametrize("name", ["start.bat", "run.sh", "README.md", "DEVELOPMENT.md"])
def test_launchers_and_docs_do_not_point_at_the_old_dist_folder(name):
    text = (ROOT / name).read_text(encoding="utf-8", errors="replace")
    bad = re.findall(r"frontend[\\/]dist\b", text)
    assert not bad, f"{name} still references frontend/dist — the UI lives in frontend/ui now"


def test_windows_launcher_checks_the_ui_folder_it_actually_ships():
    bat = (ROOT / "start.bat").read_text(encoding="utf-8", errors="replace")
    assert "frontend\\ui\\index.html" in bat


def test_ci_fails_when_the_prebuilt_ui_disappears():
    ci = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
    assert "frontend/ui/index.html" in ci and "git ls-files frontend/ui" in ci


def test_missing_ui_answers_503_with_instructions():
    """Both mount paths (folder absent / folder present but empty) share one answer."""
    from app.main import ui_missing_response

    r = ui_missing_response("pos")
    assert r.status_code == 503
    body = r.body.decode()
    assert "npm run build" in body and "frontend/ui" in body
    assert r.headers["content-type"].startswith("text/plain")


def test_unknown_api_paths_stay_json_404_even_without_a_ui():
    from app.main import ui_missing_response

    r = ui_missing_response("api/does-not-exist")
    assert r.status_code == 404 and b"not_found" in r.body


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_the_real_launcher_does_not_advertise_the_framework(tmp_path):
    """`python -m app.serve` is what start.bat/run.sh run — check its headers, not just the source."""
    port = _free_port()
    env = {**{k: v for k, v in os.environ.items() if not k.startswith("CAFE_")},
           "CAFE_DATA_DIR": str(tmp_path), "CAFE_PORT": str(port), "CAFE_BACKGROUND_JOBS": "false",
           "CAFE_SAMPLE_USERS": "true", "CAFE_FORCE_PASSWORD_CHANGE": "false"}
    proc = subprocess.Popen([sys.executable, "-m", "app.serve", "--port", str(port)],
                            cwd=str(ROOT / "backend"), env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(160):
            try:
                r = httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1)
                break
            except Exception:
                time.sleep(0.25)
        else:
            pytest.fail("the launcher never answered")
        headers = {k.lower(): v for k, v in r.headers.items()}
        assert r.status_code == 200
        assert "uvicorn" not in headers.get("server", "").lower()
        assert "server" not in headers or headers["server"] in ("", "-"), headers
        assert "x-powered-by" not in headers
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:  # noqa: BLE001
            proc.kill()


@pytest.fixture()
def sms_snapshot(client, admin):
    """Other test files (test_phase2) expect the SMS module in its seeded state: put it back afterwards."""
    from app.core.db import SessionLocal
    from app.core import settings_store

    keys = [k for k in settings_store.DEFAULTS if k.startswith("sms.")]   # the whole module state, not just the key
    with SessionLocal() as db:
        old = {k: settings_store.get(db, k) for k in keys}
    yield old
    with SessionLocal() as db:
        settings_store.set_many(db, old)
        db.commit()


def test_sms_status_never_returns_the_provider_key(client, admin, sms_snapshot):
    """Part 1 / item 1 — the API key of the SMS provider must not reach the browser."""
    key = "very-secret-sms-key-1234"
    body = {"enabled": True, "provider": "kavenegar", "config": {"kavenegar": {"api_key": key, "sender": "1000"}},
            "optout_footer": "", "reminder_minutes": 120, "quiet_start": 23, "quiet_end": 8}
    assert client.put("/api/sms/config", headers=admin, json=body).status_code == 200
    for url in ("/api/sms/status", "/api/sms/config", "/api/system/settings"):
        assert key not in client.get(url, headers=admin).text, f"{url} leaks the provider key"
    shown = client.get("/api/sms/status", headers=admin).json()["config"]["kavenegar"]["api_key"]
    assert shown.startswith("•") and shown.endswith(key[-4:])
    # the form posts the mask back → the server keeps the real key instead of storing the mask
    body["config"]["kavenegar"]["api_key"] = shown
    assert client.put("/api/sms/config", headers=admin, json=body).status_code == 200
    assert client.get("/api/sms/status", headers=admin).json()["config"]["kavenegar"]["api_key"] == shown
    # a different, real key still replaces it
    body["config"]["kavenegar"]["api_key"] = "another-real-key-9999"
    assert client.put("/api/sms/config", headers=admin, json=body).status_code == 200
    assert client.get("/api/sms/status", headers=admin).json()["config"]["kavenegar"]["api_key"].endswith("9999")


def test_data_dir_key_file_is_private_in_the_running_app(client):
    """Part 2 / item 6 on a real boot, not only on a Settings object."""
    p = Path(get_settings().data_dir) / "secret.key"
    assert p.is_file()
    if os.name == "nt":
        pytest.skip("POSIX permission bits do not exist on Windows")
    import stat as st
    assert st.S_IMODE(p.stat().st_mode) == 0o600, oct(st.S_IMODE(p.stat().st_mode))
