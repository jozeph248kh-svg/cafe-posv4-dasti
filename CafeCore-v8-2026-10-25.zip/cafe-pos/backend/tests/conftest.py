import os
import shutil
import tempfile

import pytest

_DATA = tempfile.mkdtemp(prefix="cafe-test-")
os.environ["CAFE_DATA_DIR"] = _DATA
os.environ["CAFE_DEMO_DATA"] = "false"
os.environ["CAFE_BACKGROUND_JOBS"] = "false"
os.environ["CAFE_SAMPLE_USERS"] = "true"          # tests use the sample staff accounts
os.environ["CAFE_FORCE_PASSWORD_CHANGE"] = "false"  # enabled explicitly in test_security
os.environ.pop("CAFE_DATABASE_URL", None)
# Opt-in: run the whole suite on PostgreSQL. The target database is WIPED (schema public dropped) — use a scratch DB.
#   CAFE_TEST_DATABASE_URL=postgresql+psycopg://postgres@/cafe_test?host=/tmp&port=5433 pytest tests
PG_URL = os.environ.get("CAFE_TEST_DATABASE_URL")
if PG_URL:
    from sqlalchemy import create_engine, text

    with create_engine(PG_URL).begin() as _c:
        _c.execute(text("DROP SCHEMA public CASCADE"))
        _c.execute(text("CREATE SCHEMA public"))
    os.environ["CAFE_DATABASE_URL"] = PG_URL

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
    shutil.rmtree(_DATA, ignore_errors=True)


def _login(client, username, password):
    r = client.post("/api/staff/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="session")
def admin(client):
    return _login(client, "admin", "admin123")


@pytest.fixture(scope="session")
def cashier(client):
    return _login(client, "reza", "cashier123")


@pytest.fixture(scope="session")
def waiter(client):
    return _login(client, "ali", "waiter123")


@pytest.fixture(scope="session")
def chef(client):
    return _login(client, "chef", "kitchen123")


@pytest.fixture(scope="session")
def menu(client, admin):
    data = client.get("/api/menu/full", headers=admin).json()
    by_code = {i["code"]: i for i in data["items"]}
    groups = {g["id"]: g for g in data["modifier_groups"]}
    return {"items": by_code, "groups": groups}


def line(menu, code, qty=1, extra=()):
    """Build a valid order line: picks the default option for every required modifier group."""
    item = menu["items"][code]
    opts = []
    for gid in item["modifier_group_ids"]:
        g = menu["groups"][gid]
        if g["min_select"] >= 1:
            opts.append(next((o for o in g["options"] if o["is_default"]), g["options"][0])["id"])
    return {"menu_item_id": item["id"], "qty": qty, "modifier_option_ids": opts + list(extra)}


def close_register(client, admin):
    """Test isolation: settle any half-paid order left by an earlier test and close the shared cash shift."""
    if not client.get("/api/shifts/current", headers=admin).json():
        return
    for o in client.get("/api/orders/active", headers=admin).json():
        due = o["total"] - o["paid_amount"]
        if o["paid_amount"] > 0 and due > 0:
            client.post(f"/api/orders/{o['id']}/payments", headers=admin,
                        json={"payments": [{"method": "card", "amount": due}]}).raise_for_status()
    r = client.post("/api/shifts/close", headers=admin, json={"counted_cash": 0, "note": "test isolation"})
    assert r.status_code == 200, r.text
