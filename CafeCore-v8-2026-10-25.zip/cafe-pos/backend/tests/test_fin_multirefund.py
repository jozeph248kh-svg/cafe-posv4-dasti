"""Several partial and full refunds on several bills across several months.

The scenario a real café produces and the unit tests of one bill never see:

  * three bills, each with **both** an item discount and a bill discount, VAT, and a recipe (so there is material cost)
  * one of them fully refunded, one refunded three times in parts on three different days, one refunded with goods
    coming back to the store (`restock`) and no money moving
  * the sale months and the refund months are different, so the period reports have to stay stable

For every step the four screens must agree: sales report, P&L, refunds, cash drawer (and the tax ledger).
"""
from datetime import datetime, timedelta

import pytest
from conftest import _login, close_register


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _settings(client, admin, mgr):
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    client.put("/api/system/settings", headers=admin, json=old)
    close_register(client, admin)


def _ing(client, admin, name, cost):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": 100_000.0, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    it = r.json()
    client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
               json=[{"ingredient_id": i, "qty": q} for i, q in recipe]).raise_for_status()
    return it


def _bill(client, cashier, mgr, item, qty, item_disc, bill_disc):
    """Create, discount twice (item + bill), pay. Returns the closed order."""
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": qty}]})
    assert o.status_code == 201, o.text
    o = o.json()
    lid = o["lines"][0]["id"]
    if item_disc:
        r = client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr,
                        json={"type": "amount", "value": item_disc, "reason": "تخفیف آیتم آزمون"})
        assert r.status_code == 200, r.text
    if bill_disc:
        r = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                        json={"type": "amount", "value": bill_disc, "reason": "تخفیف فاکتور آزمون"})
        assert r.status_code == 200, r.text
        o = r.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _move(order_id, days_ago):
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order, OrderRefundLine, Payment
    from sqlalchemy import func as f

    when = datetime.now() - timedelta(days=days_ago)
    with SessionLocal() as db:
        o = db.get(Order, order_id)
        o.business_date = when.date()
        o.number = int(db.query(f.max(Order.number)).filter(Order.business_date == when.date()).scalar() or 0) + 1
        o.closed_at = when
        for p in db.query(Payment).filter(Payment.order_id == order_id):
            p.created_at = when
        for r in db.query(OrderRefundLine).filter(OrderRefundLine.order_id == order_id):
            r.created_at = when
        db.commit()


def _move_payment(pid, days_ago):
    """Move a refund payment **and the return events it created** to another day.

    Both matter: the money is booked on the payment day, the material cost of returned goods on the
    `order_refund_lines` day. Moving only one of them would fake a situation the application never produces.
    """
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine, Payment

    when = datetime.now() - timedelta(days=days_ago)
    with SessionLocal() as db:
        db.get(Payment, pid).created_at = when
        for line in db.query(OrderRefundLine).filter(OrderRefundLine.refund_payment_id == pid):
            line.created_at = when
        db.commit()


def _last_refund(order_json):
    """The refund payment this call just created — the *newest* one, not the first in the list."""
    return max((p["id"] for p in order_json["payments"] if p["is_refund"]), default=None)


def _refund(client, mgr, order, amount, restock=None, method="cash"):
    body = {"method": method, "amount": amount, "reason": "ممیزی چند مرجوعی"}
    if restock:
        body["restock"] = restock
    return client.post(f"/api/orders/{order['id']}/refund", headers=mgr, json=body)


def _pnl(client, admin, d1, d2):
    r = client.get("/api/expenses/pnl", headers=admin, params={"date_from": d1.isoformat(), "date_to": d2.isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _sales(client, admin, d1, d2):
    r = client.get("/api/reports/sales", headers=admin, params={"date_from": d1.isoformat(), "date_to": d2.isoformat()})
    assert r.status_code == 200, r.text
    return r.json()["summary"]


def _ledger(client, mgr, d1, d2):
    r = client.get("/api/reports/insights/tax", headers=mgr, params={"date_from": d1.isoformat(), "date_to": d2.isoformat()})
    assert r.status_code == 200, r.text
    return r.json()["totals"]


def _today():
    from app.core.utils import business_day
    return business_day()


def _snap(client, admin, mgr, d1, d2):
    """All three screens for one range, so every assertion can be a delta (the suite shares one database)."""
    return {"sales": _sales(client, admin, d1, d2), "pnl": _pnl(client, admin, d1, d2),
            "ledger": _ledger(client, mgr, d1, d2)}


def _reconcile(client, admin, mgr, d1, d2):
    """The one identity every screen has to satisfy for the same range."""
    sales, pnl, ledger = _sales(client, admin, d1, d2), _pnl(client, admin, d1, d2), _ledger(client, mgr, d1, d2)
    assert pnl["revenue"] + pnl["sales"]["tax"] + pnl["sales"]["refunds"] == sales["net"], (sales, pnl["sales"],
                                                                                           pnl["revenue"])
    assert sales["refunds"] == pnl["sales"]["refunds"] == ledger["refunds"]
    assert ledger["total"] - ledger["refunds"] == sales["net"] - sales["refunds"]
    assert ledger["tax"] == sales["tax"]
    return sales, pnl, ledger


def test_three_bills_three_months_and_a_mix_of_partial_full_and_goods_only_refunds(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه چند‌مرجوعی", 200)                 # 4 g → 800 per unit
    item = _item(client, admin, "قهوه چند‌مرجوعی", 500_000, [(ing["id"], 4)])
    today = _today()
    day_60, day_30 = today - timedelta(days=60), today - timedelta(days=30)

    # COGS baselines (the suite shares one database, so every COGS assertion below is a delta)
    day4 = today - timedelta(days=4)
    base_today = _pnl(client, admin, today, today)
    cogs_today0, cogs_day4_0 = base_today["cogs"], _pnl(client, admin, day4, day4)["cogs"]
    unknown0 = base_today["cogs_unknown_returns"]

    # ---- three bills, each with an item discount AND a bill discount, in three different months ----
    a = _bill(client, cashier, mgr, item, qty=3, item_disc=60_000, bill_disc=90_000)     # month −60
    b = _bill(client, cashier, mgr, item, qty=2, item_disc=20_000, bill_disc=50_000)     # month −30
    c = _bill(client, cashier, mgr, item, qty=4, item_disc=0, bill_disc=200_000)         # today
    for o, days in ((a, 60), (b, 30)):
        _move(o["id"], days)
    for o in (a, b, c):
        assert o["line_discount_amount"] + (o["discount_amount"] - o["line_discount_amount"]) == o["discount_amount"]
        assert o["tax_amount"] > 0 and o["discount_amount"] > 0

    # baselines
    sales_a0, pnl_a0, _ = _reconcile(client, admin, mgr, day_60, day_60)
    sales_b0, pnl_b0, _ = _reconcile(client, admin, mgr, day_30, day_30)
    cash0 = client.get("/api/shifts/current", headers=mgr).json()["expected_cash"]
    w1, w2 = today - timedelta(days=11), today - timedelta(days=1)          # a window with refunds only
    win0 = _snap(client, admin, mgr, w1, w2)
    all0 = _snap(client, admin, mgr, day_60, today)

    # ---- 1) bill A: FULL refund in a later month ----
    r = _refund(client, mgr, a, a["paid_amount"])
    assert r.status_code == 200, r.text
    _move_payment(_last_refund(r.json()), 10)

    # ---- 2) bill B: three partial refunds on three different days (one of them carrying goods back) ----
    third = b["paid_amount"] // 3
    parts = [third, third, b["paid_amount"] - 2 * third]
    days = [6, 4, 2]
    refund_tax_total = 0
    for amount, when, with_goods in zip(parts, days, (False, True, False)):
        restock = [{"line_id": b["lines"][0]["id"], "qty": 1}] if with_goods else None
        r = _refund(client, mgr, b, amount, restock=restock)
        assert r.status_code == 200, r.text
        _move_payment(_last_refund(r.json()), when)

    # ---- 3) bill C: goods-only return today (no money moves) ----
    r = _refund(client, mgr, c, 0, restock=[{"line_id": c["lines"][0]["id"], "qty": 2}])
    assert r.status_code == 200, r.text

    # ---------- the two closed months never changed ----------
    sales_a1, pnl_a1, _ = _reconcile(client, admin, mgr, day_60, day_60)
    sales_b1, pnl_b1, _ = _reconcile(client, admin, mgr, day_30, day_30)
    assert sales_a1 == sales_a0 and pnl_a1["revenue"] == pnl_a0["revenue"] and pnl_a1["cogs"] == pnl_a0["cogs"], \
        "a later refund rewrote a closed month"
    assert sales_b1 == sales_b0 and pnl_b1["revenue"] == pnl_b0["revenue"] and pnl_b1["cogs"] == pnl_b0["cogs"]

    # ---------- the refund window: ten days with refunds only (no bill of its own) ----------
    _reconcile(client, admin, mgr, w1, w2)                     # the identity holds before the comparison too
    win1 = _snap(client, admin, mgr, w1, w2)
    def d(sec, key, sub=None):
        def get(snap):
            return snap[sec][sub][key] if sub else snap[sec][key]
        return get(win1) - get(win0)
    assert d("sales", "net") == 0, "no bill was issued in this window"
    assert d("sales", "refunds") == a["paid_amount"] + b["paid_amount"]
    reversed_a = round(a["paid_amount"] * a["tax_amount"] / a["total"])
    reversed_b = round(b["paid_amount"] * b["tax_amount"] / b["total"])
    assert reversed_a == a["tax_amount"], "a full refund must reverse the whole VAT of the bill"
    assert reversed_b == b["tax_amount"], "three partial refunds must add up to the bill's VAT exactly"
    # billing view keeps the VAT gross; the earned-revenue view takes the reversed VAT out (that is D3, documented)
    assert d("sales", "tax") == 0
    assert d("pnl", "tax", "sales") == -(reversed_a + reversed_b)
    assert d("pnl", "revenue") == -((a["total"] - a["tax_amount"]) + (b["total"] - b["tax_amount"]))
    assert d("ledger", "refunds") == d("sales", "refunds")

    # ---------- COGS: only the goods that physically came back reduce it, on the return day ----------
    cost_per_unit = 4 * 200                                     # 800 per unit, frozen at sale time
    pnl_c = _pnl(client, admin, today, today)
    # bill C sold 4 units today → 4 × 800 = 3 200 cost, minus the 2 returned units = 1 600 (measured as a delta)
    assert pnl_c["cogs"] - cogs_today0 == pytest.approx(4 * cost_per_unit - 2 * cost_per_unit, abs=1), pnl_c["cogs"]
    # our returns carry a frozen historical cost, so none of them is flagged «unknown» (delta: other test files
    # may legitimately leave an unknown-cost return in the shared database)
    assert pnl_c["cogs_unknown_returns"] == unknown0
    # bill B's returned goods hit ITS return day (4 days ago), never the sale day
    assert _pnl(client, admin, day_30, day_30)["cogs"] == pnl_b0["cogs"], "the sale day must not change"
    return_day = _pnl(client, admin, day4, day4)
    assert return_day["cogs"] - cogs_day4_0 == pytest.approx(-cost_per_unit, abs=1), return_day["cogs"]

    # ---------- the sales report's per-item row tells the same story ----------
    rep = client.get("/api/reports/sales", headers=admin,
                     params={"date_from": today.isoformat(), "date_to": today.isoformat()}).json()
    row = next(r for r in rep["by_item"] if r["id"] == item["id"])
    charged_c = c["subtotal"] - c["discount_amount"]
    assert row["revenue"] == charged_c
    assert row["gross"] == c["subtotal"]
    assert row["discount"] == c["discount_amount"]

    # ---------- cash drawer: the cash refunds of A and B walked out of the till ----------
    cash1 = client.get("/api/shifts/current", headers=mgr).json()["expected_cash"]
    # cash0 already contains the takings of all three bills; only the two cash refunds left the drawer since then
    assert cash1 - cash0 == -(a["paid_amount"] + b["paid_amount"]), (cash1, cash0)

    # ---------- the whole range, all months together (deltas again) ----------
    all1 = _reconcile(client, admin, mgr, day_60, today)
    _ = all1
    sales_all = _snap(client, admin, mgr, day_60, today)
    def da(sec, key, sub=None):
        def get(snap):
            return snap[sec][sub][key] if sub else snap[sec][key]
        return get(sales_all) - get(all0)
    assert da("sales", "refunds") == a["paid_amount"] + b["paid_amount"]
    assert da("sales", "tax") - da("pnl", "tax", "sales") == reversed_a + reversed_b
    assert da("pnl", "revenue") == -((a["total"] - a["tax_amount"]) + (b["total"] - b["tax_amount"]))
