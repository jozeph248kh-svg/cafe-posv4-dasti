"""End-to-end business flows through the HTTP API (the same calls the POS / KDS make)."""
from conftest import close_register, line


def ingredient(client, admin, name):
    return next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["name"] == name)


def floor_tables(client, h):
    return [t for a in client.get("/api/orders/floor", headers=h).json() for t in a["tables"]]


def test_health_and_modules(client):
    r = client.get("/api/health").json()
    assert r["status"] == "ok"
    for m in ("orders", "kitchen", "inventory", "shifts", "reports", "public", "customers"):
        assert m in r["modules"]


def test_auth(client):
    assert client.post("/api/staff/auth/login", json={"username": "admin", "password": "bad"}).status_code == 401
    r = client.post("/api/staff/auth/pin", json={"pin": "4444"})
    assert r.status_code == 200 and r.json()["user"]["username"] == "ali"
    assert client.post("/api/staff/auth/pin", json={"pin": "9999"}).status_code == 401
    assert client.get("/api/orders/active").status_code == 401


def test_permissions(client, waiter, chef):
    assert client.get("/api/reports/dashboard", headers=waiter).status_code == 403
    assert client.get("/api/orders/active", headers=chef).status_code == 403
    assert client.get("/api/kitchen/tickets", headers=chef).status_code == 200
    assert client.post("/api/shifts/open", json={"opening_cash": 0}, headers=waiter).status_code == 403


def test_menu_admin_lists_every_sellable_item(client, admin):
    """Regression: the admin list filtered system items with LIKE '__%' ("_" = any char) and hid every coded item."""
    full = client.get("/api/menu/full", headers=admin).json()["items"]
    admin_items = client.get("/api/menu/items", headers=admin).json()
    sellable = {i["id"] for i in full if not (i.get("code") or "").startswith("__")}
    assert sellable and sellable <= {i["id"] for i in admin_items}
    assert not any((i.get("code") or "").startswith("__") for i in admin_items)     # system items stay hidden


def test_modifier_validation(client, waiter, menu):
    t = floor_tables(client, waiter)[0]
    bad = {"menu_item_id": menu["items"]["801"]["id"], "qty": 1, "modifier_option_ids": []}   # steak needs doneness
    r = client.post("/api/orders", json={"type": "dine_in", "table_id": t["id"], "lines": [bad]}, headers=waiter)
    assert r.status_code == 400 and r.json()["detail"]["code"] == "modifier_required"


def test_full_dine_in_flow(client, admin, cashier, waiter, chef, menu):
    close_register(client, admin)          # this scenario starts with the register closed
    tables = floor_tables(client, waiter)
    t1, t2 = tables[1], tables[2]
    beans_before = ingredient(client, admin, "دانه قهوه عربیکا")["stock"]

    # waiter opens a table and sends 2 lattes + burger to the kitchen
    r = client.post("/api/orders", json={"type": "dine_in", "table_id": t1["id"], "guests": 3,
                                         "lines": [line(menu, "104", 2), line(menu, "802")], "send": True}, headers=waiter)
    assert r.status_code == 201, r.text
    o = r.json()
    assert all(l["status"] == "sent" for l in o["lines"])
    assert o["subtotal"] == 2 * menu["items"]["104"]["price"] + menu["items"]["802"]["price"]
    assert o["tax_amount"] == round(o["subtotal"] * 0.10)

    # table can't be opened twice
    r = client.post("/api/orders", json={"type": "dine_in", "table_id": t1["id"]}, headers=waiter)
    assert r.json()["detail"]["code"] == "table_busy"

    # kitchen sees one ticket per station (bar + hot kitchen)
    tickets = [k for k in client.get("/api/kitchen/tickets", headers=chef).json() if k["order_id"] == o["id"]]
    assert len(tickets) == 2
    bar = next(k for k in tickets if any(i["name"] == "لاته" for i in k["items"]))
    assert client.post(f"/api/kitchen/tickets/{bar['id']}/bump", headers=chef).json()["status"] == "preparing"
    assert client.post(f"/api/kitchen/tickets/{bar['id']}/bump", headers=chef).json()["status"] == "ready"
    o = client.get(f"/api/orders/{o['id']}", headers=waiter).json()
    assert next(l for l in o["lines"] if l["name"] == "لاته")["status"] == "ready"
    assert next(t for t in floor_tables(client, waiter) if t["id"] == t1["id"])["status"] == "ready"

    # add a dessert, then transfer table
    o = client.post(f"/api/orders/{o['id']}/lines", json={"lines": [line(menu, "901")], "send": True}, headers=waiter).json()
    o = client.post(f"/api/orders/{o['id']}/transfer", json={"table_id": t2["id"]}, headers=waiter).json()
    assert o["table_id"] == t2["id"]

    # waiter cannot void a sent item without manager approval
    burger = next(l for l in o["lines"] if l["name"] == "برگر کلاسیک")
    r = client.post(f"/api/orders/{o['id']}/lines/{burger['id']}/void", json={"reason": "مشتری منصرف شد"}, headers=waiter)
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"
    r = client.post(f"/api/orders/{o['id']}/lines/{burger['id']}/void", json={"reason": "مشتری منصرف شد"},
                    headers={**waiter, "X-Manager-Pin": "4444"})
    assert r.json()["detail"]["code"] == "override_invalid"
    r = client.post(f"/api/orders/{o['id']}/lines/{burger['id']}/void", json={"reason": "مشتری منصرف شد"},
                    headers={**waiter, "X-Manager-Pin": "2222"})
    assert r.status_code == 200
    o = r.json()
    assert o["subtotal"] == 2 * menu["items"]["104"]["price"] + menu["items"]["901"]["price"]
    hot = [k for k in client.get("/api/kitchen/tickets", headers=chef).json() if k["order_id"] == o["id"] and any(i["name"] == "برگر کلاسیک" for i in k["items"])]
    assert all(k["status"] == "void" or all(i["is_void"] for i in k["items"] if i["name"] == "برگر کلاسیک") for k in hot)

    # cashier's discount ceiling is 10% (seed) → 15% needs a manager PIN
    r = client.post(f"/api/orders/{o['id']}/discount", json={"type": "percent", "value": 15, "reason": "مشتری دائمی"}, headers=cashier)
    assert r.json()["detail"]["code"] == "override_required"
    o = client.post(f"/api/orders/{o['id']}/discount", json={"type": "percent", "value": 15, "reason": "مشتری دائمی"},
                    headers={**cashier, "X-Manager-Pin": "2222"}).json()
    assert o["discount_amount"] == round(o["subtotal"] * 0.15)

    # payment requires an open shift
    r = client.post(f"/api/orders/{o['id']}/payments", json={"payments": [{"method": "card", "amount": 1000}]}, headers=cashier)
    assert r.json()["detail"]["code"] == "shift_closed"
    shift = client.post("/api/shifts/open", json={"opening_cash": 1_000_000}, headers=cashier).json()
    assert shift["status"] == "open"

    # split payment: part card, rest cash with change
    total = o["total"]
    o = client.post(f"/api/orders/{o['id']}/payments", json={"payments": [{"method": "card", "amount": 200_000}]}, headers=cashier).json()
    assert o["status"] == "open" and o["paid_amount"] == 200_000
    o = client.post(f"/api/orders/{o['id']}/payments",
                    json={"payments": [{"method": "cash", "amount": total - 200_000, "tendered": total - 200_000 + 50_000}]}, headers=cashier).json()
    assert o["status"] == "closed"
    assert o["payments"][-1]["change"] == 50_000
    assert next(t for t in floor_tables(client, waiter) if t["id"] == t2["id"])["status"] == "free"

    # inventory deducted by recipe (2 lattes × 18g beans)
    assert ingredient(client, admin, "دانه قهوه عربیکا")["stock"] == beans_before - 36

    # refund needs payments.refund (manager)
    r = client.post(f"/api/orders/{o['id']}/refund", json={"method": "cash", "amount": 50_000, "reason": "کیفیت"}, headers=cashier)
    assert r.json()["detail"]["code"] == "override_required"
    o = client.post(f"/api/orders/{o['id']}/refund", json={"method": "cash", "amount": 50_000, "reason": "کیفیت"},
                    headers={**cashier, "X-Manager-Pin": "1111"}).json()
    assert any(p["is_refund"] and p["amount"] == -50_000 for p in o["payments"])

    # shift totals
    # blind count (shift.blind_close default on): the cashier sees card totals but not what the drawer should hold
    blind = client.get("/api/shifts/current", headers=cashier).json()
    assert blind["blind"] is True and blind["payments"]["card"] == 200_000
    assert blind["expected_cash"] is None and blind["total_sales"] is None and "cash" not in blind["payments"]
    cur = client.get("/api/shifts/current", headers=admin).json()        # shifts.supervise sees everything
    assert cur["blind"] is False and cur["payments"]["card"] == 200_000
    assert cur["expected_cash"] == 1_000_000 + (total - 200_000) - 50_000
    client.post("/api/shifts/cash", json={"kind": "out", "amount": 100_000, "reason": "خرید نان"}, headers=cashier)
    closed = client.post("/api/shifts/close", json={"counted_cash": cur["expected_cash"] - 100_000 - 5_000}, headers=cashier).json()
    assert closed["status"] == "closed" and closed["difference"] == -5_000
    assert closed["expected_cash"] == cur["expected_cash"] - 100_000     # after counting, the result is shown to the cashier


def test_split_and_merge(client, admin, menu):
    client.post("/api/shifts/open", json={"opening_cash": 0}, headers=admin)
    tables = floor_tables(client, admin)
    a = client.post("/api/orders", json={"type": "dine_in", "table_id": tables[5]["id"],
                                         "lines": [line(menu, "101", 3), line(menu, "701")], "send": True}, headers=admin).json()
    esp = next(l for l in a["lines"] if l["name"] == "اسپرسو")
    r = client.post(f"/api/orders/{a['id']}/split", json={"lines": [{"line_id": esp["id"], "qty": 1}]}, headers=admin)
    assert r.status_code == 200, r.text
    new = r.json()
    assert new["id"] != a["id"] and sum(l["qty"] for l in new["lines"]) == 1
    a = client.get(f"/api/orders/{a['id']}", headers=admin).json()
    assert next(l for l in a["lines"] if l["name"] == "اسپرسو")["qty"] == 2
    assert len(a["lines"]) == 2

    # pay the split part separately
    paid = client.post(f"/api/orders/{new['id']}/payments", json={"payments": [{"method": "card", "amount": new["total"]}]}, headers=admin).json()
    assert paid["status"] == "closed"

    # merge another table into the first
    b = client.post("/api/orders", json={"type": "dine_in", "table_id": tables[6]["id"], "lines": [line(menu, "204")], "send": True}, headers=admin).json()
    r = client.post(f"/api/orders/{b['id']}/merge", json={"target_order_id": a["id"]}, headers=admin)
    assert r.status_code == 200, r.text
    a = client.get(f"/api/orders/{a['id']}", headers=admin).json()
    assert any(l["name"] == "لیموناد خانگی" for l in a["lines"])
    assert client.get(f"/api/orders/{b['id']}", headers=admin).json()["status"] == "cancelled"

    # cancel (manager)
    c = client.post(f"/api/orders/{a['id']}/cancel", json={"reason": "تست"}, headers=admin).json()
    assert c["status"] == "cancelled"


def test_takeaway_delivery_customer(client, cashier, menu):
    r = client.post("/api/orders", json={"type": "delivery", "lines": [line(menu, "702")]}, headers=cashier)
    assert r.status_code == 400   # needs phone + address
    o = client.post("/api/orders", json={"type": "delivery", "customer_name": "مهسا", "customer_phone": "۰۹۱۲۷۷۷۸۸۸۸",
                                         "customer_address": "تهران، ونک", "lines": [line(menu, "702")]}, headers=cashier).json()
    client.post("/api/shifts/open", json={"opening_cash": 0}, headers=cashier)
    o = client.post(f"/api/orders/{o['id']}/payments", json={"payments": [{"method": "online", "amount": o["total"]}]}, headers=cashier).json()
    assert o["status"] == "closed"
    c = client.get("/api/customers/by-phone/09127778888", headers=cashier).json()
    assert c and c["visits"] == 1 and c["total_spent"] == o["total"]
    hist = client.get(f"/api/customers/{c['id']}/orders", headers=cashier).json()
    assert hist[0]["id"] == o["id"]


def test_inventory_purchase_and_waste(client, admin):
    milk = ingredient(client, admin, "شیر پرچرب")
    r = client.post("/api/inventory/purchases", json={"purchase_date": "2026-10-20", "invoice_no": "A-1",
                                                      "lines": [{"ingredient_id": milk["id"], "qty": milk["stock"], "unit_cost": milk["cost_per_unit"] * 2}]}, headers=admin)
    assert r.status_code == 201, r.text
    m2 = ingredient(client, admin, "شیر پرچرب")
    assert m2["stock"] == milk["stock"] * 2
    assert abs(m2["cost_per_unit"] - milk["cost_per_unit"] * 1.5) < 0.01     # weighted average
    r = client.post(f"/api/inventory/ingredients/{milk['id']}/adjust", json={"kind": "waste", "qty": 500, "note": "ترش شد"}, headers=admin)
    assert r.json()["stock"] == m2["stock"] - 500


def test_reports(client, admin):
    r = client.get("/api/reports/sales", headers=admin).json()
    assert r["summary"]["orders"] >= 2
    assert r["by_item"] and r["by_payment"]
    d = client.get("/api/reports/dashboard", headers=admin).json()
    assert "live" in d and "low_stock" in d
    x = client.get("/api/reports/sales/export", headers=admin)
    assert x.status_code == 200 and x.content[:2] == b"PK"


def test_public_menu_and_service_call(client, admin, waiter):
    token = client.get("/api/floor/tables", headers=admin).json()[0]["qr_token"]
    m = client.get(f"/api/public/menu?table={token}").json()
    assert m["table"]["name"] and m["items"]
    assert client.post("/api/public/call", json={"token": "nope", "kind": "waiter"}).status_code == 404
    assert client.post("/api/public/call", json={"token": token, "kind": "waiter"}).json() == {"ok": True}
    assert client.post("/api/public/call", json={"token": token, "kind": "waiter"}).json()["duplicate"] is True
    calls = client.get("/api/public/calls", headers=waiter).json()
    assert len(calls) == 1
    client.post(f"/api/public/calls/{calls[0]['id']}/ack", headers=waiter)
    assert client.get("/api/public/calls", headers=waiter).json() == []


def test_audit_trail(client, admin):
    logs = client.get("/api/system/audit", headers=admin).json()
    items = logs["items"] if isinstance(logs, dict) else logs
    actions = {l["action"] for l in items}
    assert {"order.void", "shift.close"} <= actions


def test_websocket_realtime(client, admin, waiter, menu):
    import pytest
    from starlette.websockets import WebSocketDisconnect
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws?token=bad") as ws:
            ws.receive_text()
    token = admin["Authorization"].split()[1]
    with client.websocket_connect(f"/ws?token={token}") as ws:
        ws.send_text("ping")
        assert "pong" in ws.receive_text()
        t = [t for a in client.get("/api/orders/floor", headers=waiter).json() for t in a["tables"] if t["status"] == "free"][0]
        client.post("/api/orders", json={"type": "dine_in", "table_id": t["id"], "lines": [line(menu, "101")], "send": True}, headers=waiter)
        topics = set()
        for _ in range(4):
            topics.add(__import__("json").loads(ws.receive_text())["topic"])
            if {"order.changed", "kitchen.ticket"} <= topics:
                break
        assert {"order.changed", "kitchen.ticket"} <= topics
