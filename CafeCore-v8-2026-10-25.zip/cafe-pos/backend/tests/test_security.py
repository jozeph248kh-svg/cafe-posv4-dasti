"""Security: authentication, brute force limits, permission matrix, privilege escalation, secrets, error leaks."""
import re

import pytest
from conftest import _login

from app.core import ratelimit
from app.core.config import get_settings
from app.main import app

PUBLIC = {
    "GET /api/health", "GET /api/modules", "GET /api/system/info", "GET /api/inventory/units",
    "POST /api/staff/auth/login", "POST /api/staff/auth/pin",
    "GET /api/public/menu", "POST /api/public/call", "GET /api/staff/auth/options",
    "GET /api/online/public/info", "GET /api/online/public/menu", "POST /api/online/public/orders",
    "GET /api/online/public/orders/{token}", "POST /api/marketplace/webhook/{key}",
    "POST /api/online/public/promo",          # guest checks a promo code against the cart (rate-limited)
    "POST /api/online/public/otp/send", "POST /api/online/public/otp/verify",   # SMS code for limited promo codes (rate-limited)
    "POST /api/timeclock/punch",              # staff clock in/out with their PIN on the shared terminal (rate-limited)
    "GET /api/system/theme",                  # colours only: the login screen and guest pages are themed too
    # branch machine endpoints authenticate with the branch key, not a user token (checked separately below)
}


@pytest.fixture(autouse=True)
def _clean_limits():
    ratelimit.reset()
    yield
    ratelimit.reset()


def _routes():
    for path, ops in app.openapi()["paths"].items():
        for m in ops:
            yield m.upper(), path


def test_every_private_endpoint_requires_login(client):
    leaks = []
    for m, p in _routes():
        if f"{m} {p}" in PUBLIC:
            continue
        r = client.request(m, re.sub(r"\{[^}]+\}", "1", p), json={})
        if r.status_code not in (401, 403):
            leaks.append((r.status_code, m, p))
    assert not leaks, leaks


def test_branch_sync_requires_branch_key(client):
    for p in ("/api/branches/sync/ping", "/api/branches/sync/catalog"):
        assert client.get(p).status_code == 401
        assert client.get(p, headers={"Authorization": "Bearer br_wrong"}).status_code == 401


SENSITIVE = [  # (method, path, body) – each needs a permission the kitchen/waiter roles don't have
    ("POST", "/api/orders/1/payments", {"payments": [{"method": "cash", "amount": 1000}]}),
    ("POST", "/api/orders/1/refund", {"method": "cash", "amount": 1000, "reason": "test"}),
    ("POST", "/api/orders/1/discount", {"type": "percent", "value": 50}),
    ("POST", "/api/orders/1/cancel", {"reason": "test"}),
    ("PUT", "/api/system/settings", {"tax.percent": 0}),
    ("GET", "/api/staff/users", None),
    ("POST", "/api/staff/roles", {"name": "x_role", "title": "x role", "permissions": []}),
    ("GET", "/api/system/backups", None),
    ("POST", "/api/system/backups", None),
    ("GET", "/api/reports/sales", None),
    ("POST", "/api/inventory/ingredients/1/adjust", {"qty": 5, "kind": "adjust", "note": "x"}),
    ("GET", "/api/system/audit", None),
    ("PUT", "/api/menu/items/1", {"name": "x", "price": 1}),
    ("POST", "/api/loyalty/customers/1/topup", {"amount": 1000}),
]


@pytest.mark.parametrize("method,path,body", SENSITIVE)
def test_sensitive_operations_forbidden_for_kitchen_and_waiter(client, chef, waiter, method, path, body):
    for h in (chef, waiter):
        r = client.request(method, path, headers=h, json=body)
        assert r.status_code == 403, (method, path, r.status_code, r.text[:200])


def test_discount_and_void_need_manager_override(client, waiter, menu):
    from conftest import line
    tables = [t for a in client.get("/api/orders/floor", headers=waiter).json() for t in a["tables"] if t["status"] == "free"]
    o = client.post("/api/orders", json={"type": "dine_in", "table_id": tables[-1]["id"], "lines": [line(menu, "101")], "send": True},
                    headers=waiter).json()
    r = client.post(f"/api/orders/{o['id']}/discount", json={"type": "percent", "value": 50, "reason": "مشتری دائمی"}, headers=waiter)
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required"
    r = client.post(f"/api/orders/{o['id']}/discount", json={"type": "percent", "value": 50, "reason": "مشتری دائمی"},
                    headers={**waiter, "X-Manager-Pin": "4444"})          # a waiter's own PIN is not a manager PIN
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_invalid"
    r = client.post(f"/api/orders/{o['id']}/discount", json={"type": "percent", "value": 50, "reason": "مشتری دائمی"},
                    headers={**waiter, "X-Manager-Pin": "2222"})
    assert r.status_code == 200 and r.json()["discount_amount"] > 0
    client.post(f"/api/orders/{o['id']}/cancel", json={"reason": "تست"}, headers={**waiter, "X-Manager-Pin": "2222"})


def test_login_bruteforce_is_limited(client):
    n = get_settings().login_max_failures
    for _ in range(n):
        assert client.post("/api/staff/auth/login", json={"username": "reza", "password": "nope"}).status_code == 401
    r = client.post("/api/staff/auth/login", json={"username": "reza", "password": "cashier123"})
    assert r.status_code == 429 and r.json()["detail"]["code"] == "too_many_attempts"


def test_login_lockout_survives_a_restart(client):
    """The counters are persisted (data/login_failures.json): restarting the server must not reset a lock-out."""
    from app.core import ratelimit
    ratelimit.reset()
    n = get_settings().login_max_failures
    for _ in range(n):
        assert client.post("/api/staff/auth/login", json={"username": "sara", "password": "nope"}).status_code == 401
    ratelimit.forget_memory()                                   # = process restart: memory empty, file kept
    r = client.post("/api/staff/auth/login", json={"username": "sara", "password": "manager123"})
    assert r.status_code == 429 and r.json()["detail"]["code"] == "too_many_attempts"
    path = get_settings().data_dir / "login_failures.json"
    path.write_text("{not json", encoding="utf-8")              # a damaged file never blocks logins
    ratelimit.forget_memory()
    assert client.post("/api/staff/auth/login", json={"username": "sara", "password": "manager123"}).status_code == 200
    ratelimit.reset()


def test_pin_bruteforce_is_limited(client):
    n = get_settings().login_max_failures
    for i in range(n):
        assert client.post("/api/staff/auth/pin", json={"pin": f"90{i:02d}"}).status_code == 401
    assert client.post("/api/staff/auth/pin", json={"pin": "4444"}).status_code == 429


def test_manager_override_pin_bruteforce_is_limited(client, waiter):
    n = get_settings().login_max_failures
    for i in range(n):
        r = client.post("/api/orders/999999/cancel", json={"reason": "x"}, headers={**waiter, "X-Manager-Pin": f"80{i:02d}"})
        assert r.status_code == 403
    r = client.post("/api/orders/999999/cancel", json={"reason": "x"}, headers={**waiter, "X-Manager-Pin": "2222"})
    assert r.status_code == 429


def test_inactive_user_loses_access_immediately(client, admin):
    roles = {r["name"]: r["id"] for r in client.get("/api/staff/roles", headers=admin).json()}
    u = client.post("/api/staff/users", headers=admin, json={"username": "temp_cash", "full_name": "موقت", "role_id": roles["cashier"],
                                                             "password": "Temp-pass-91", "pin": "7171"}).json()
    h = _login(client, "temp_cash", "Temp-pass-91")
    assert client.get("/api/orders/active", headers=h).status_code == 200
    client.put(f"/api/staff/users/{u['id']}", headers=admin, json={"username": "temp_cash", "full_name": "موقت",
                                                                  "role_id": roles["cashier"], "is_active": False})
    assert client.get("/api/orders/active", headers=h).status_code == 401           # old token revoked
    assert client.post("/api/staff/auth/login", json={"username": "temp_cash", "password": "Temp-pass-91"}).status_code == 403
    assert client.post("/api/staff/auth/pin", json={"pin": "7171"}).status_code == 401


def test_staff_manager_cannot_escalate(client, admin):
    roles = {r["name"]: r for r in client.get("/api/staff/roles", headers=admin).json()}
    r = client.post("/api/staff/roles", headers=admin, json={"name": "hr", "title": "منابع انسانی",
                                                             "permissions": ["staff.manage", "kitchen.access"]})
    assert r.status_code == 201, r.text
    hr_role = r.json()
    client.post("/api/staff/users", headers=admin, json={"username": "hr_user", "full_name": "کارگزینی", "role_id": hr_role["id"],
                                                         "password": "Hr-pass-1234"})
    hr = _login(client, "hr_user", "Hr-pass-1234")
    me = next(u for u in client.get("/api/staff/users", headers=hr).json() if u["username"] == "hr_user")
    admin_user = next(u for u in client.get("/api/staff/users", headers=hr).json() if u["username"] == "admin")
    # 1) grant itself the super-admin role
    r = client.put(f"/api/staff/users/{me['id']}", headers=hr, json={"username": "hr_user", "full_name": "کارگزینی", "role_id": roles["admin"]["id"]})
    assert r.status_code == 403
    # 2) create a role with permissions it doesn't hold
    r = client.post("/api/staff/roles", headers=hr, json={"name": "evil", "title": "evil role", "permissions": ["settings.manage"]})
    assert r.status_code == 403
    # 3) widen its own role
    r = client.put(f"/api/staff/roles/{hr_role['id']}", headers=hr, json={"name": "hr", "title": "منابع انسانی", "permissions": ["staff.manage", "payments.refund"]})
    assert r.status_code == 403
    # 4) take over the admin account (reset its password)
    r = client.put(f"/api/staff/users/{admin_user['id']}", headers=hr, json={"username": "admin", "full_name": "مدیر سیستم",
                                                                          "role_id": roles["admin"]["id"], "password": "Hacked-123"})
    assert r.status_code == 403
    # 5) create a manager-level user
    r = client.post("/api/staff/users", headers=hr, json={"username": "x_mgr", "full_name": "مدیر جدید", "role_id": roles["manager"]["id"],
                                                          "password": "Mgr-pass-123"})
    assert r.status_code == 403
    # allowed: a user with a role inside its own permissions
    r = client.post("/api/staff/users", headers=hr, json={"username": "cook2", "full_name": "آشپز دوم", "role_id": roles["kitchen"]["id"],
                                                          "password": "Cook-pass-123"})
    assert r.status_code == 201, r.text
    assert _login(client, "admin", "admin123")


def test_settings_endpoint_hides_secrets_and_validates(client, admin, chef):
    r = client.put("/api/sms/config", headers=admin, json={"enabled": True, "provider": "kavenegar",
                                                           "config": {"kavenegar": {"api_key": "SECRET-KEY-123", "sender": "1000"}},
                                                           "optout_footer": "لغو۱۱", "reminder_minutes": 120, "quiet_start": 23, "quiet_end": 8})
    assert r.status_code == 200, r.text
    for h in (chef, admin):
        s = client.get("/api/system/settings", headers=h).json()
        assert "sms.config" not in s and "branch.api_key" not in s
        assert "SECRET-KEY-123" not in str(s)
    # secrets/module keys can't be overwritten through the generic endpoint
    client.put("/api/system/settings", headers=admin, json={"branch.api_key": "x", "sms.provider": "test"})
    assert client.get("/api/sms/status", headers=admin).json()["provider"] == "kavenegar"
    # values are type/range checked so totals can't be broken
    for bad in ({"tax.percent": "abc"}, {"tax.percent": 150}, {"service.percent": -5}, {"tax.enabled": "yes"}, {"day.cutoff_hour": 30}):
        r = client.put("/api/system/settings", headers=admin, json=bad)
        assert r.status_code == 400, (bad, r.text)
    r = client.put("/api/system/settings", headers=admin, json={"sms.provider": "test"})
    client.put("/api/sms/config", headers=admin, json={"enabled": True, "provider": "test", "config": {}, "optout_footer": "لغو۱۱",
                                                       "reminder_minutes": 120, "quiet_start": 23, "quiet_end": 8})


def test_forced_password_change_for_factory_passwords(client, admin, monkeypatch):
    roles = {r["name"]: r["id"] for r in client.get("/api/staff/roles", headers=admin).json()}
    client.post("/api/staff/users", headers=admin, json={"username": "new_waiter", "full_name": "گارسون تازه", "role_id": roles["waiter"],
                                                         "password": "waiter123", "pin": "8181"})
    monkeypatch.setattr(get_settings(), "force_password_change", True)
    r = client.post("/api/staff/auth/login", json={"username": "new_waiter", "password": "waiter123"})
    assert r.status_code == 200 and r.json()["must_change_password"] is True
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    assert client.get("/api/orders/active", headers=h).json()["detail"]["code"] == "password_change_required"
    assert client.get("/api/staff/auth/me", headers=h).json()["must_change_password"] is True
    assert client.post("/api/staff/auth/pin", json={"pin": "8181"}).status_code == 403       # PIN can't bypass it
    bad = client.post("/api/staff/auth/password", headers=h, json={"current_password": "waiter123", "new_password": "admin123"})
    assert bad.status_code == 400                                                            # another factory password
    r = client.post("/api/staff/auth/password", headers=h, json={"current_password": "waiter123", "new_password": "Brand-New-77"})
    assert r.status_code == 200 and r.json()["must_change_password"] is False
    h2 = {"Authorization": f"Bearer {r.json()['token']}"}
    assert client.get("/api/orders/active", headers=h2).status_code == 200
    assert client.get("/api/staff/auth/me", headers=h).status_code == 401                    # old token revoked
    assert client.post("/api/staff/auth/pin", json={"pin": "8181"}).status_code == 200


def test_login_options_are_public_and_minimal(client, monkeypatch):
    r = client.get("/api/staff/auth/options")
    assert r.status_code == 200
    # sample staff (conftest) have PINs; "timeclock" only says whether the module is on (GET /api/modules is public too)
    assert r.json() == {"pin_enabled": True, "sample_users": True, "timeclock": True}
    monkeypatch.setattr(get_settings(), "sample_users", False)
    assert client.get("/api/staff/auth/options").json()["sample_users"] is False


def test_internal_errors_do_not_leak(client):
    from fastapi.testclient import TestClient

    def boom():
        raise RuntimeError("SELECT secret FROM users -- internal detail")
    app.add_api_route("/api/__boom", boom)
    app.router.routes.insert(0, app.router.routes.pop())      # before the SPA catch-all
    try:
        r = TestClient(app, raise_server_exceptions=False).get("/api/__boom")
    finally:
        app.router.routes = [rt for rt in app.router.routes if getattr(rt, "path", "") != "/api/__boom"]
    assert r.status_code == 500
    assert r.json()["detail"]["code"] == "internal"
    assert "secret" not in r.text and "Traceback" not in r.text


def test_invalid_input_never_500(client, admin):
    """Garbage/oversized values on money endpoints must give 4xx, not crash."""
    cases = [
        ("POST", "/api/orders", {"type": "takeaway", "lines": [{"menu_item_id": 10**30, "qty": 1}]}),
        ("POST", "/api/orders", {"type": "takeaway", "lines": [{"menu_item_id": "abc", "qty": -1}]}),
        ("POST", "/api/orders/1/payments", {"payments": [{"method": "cash", "amount": 10**20}]}),
        ("POST", "/api/orders/1/payments", {"payments": [{"method": "bitcoin", "amount": 100}]}),
        ("POST", "/api/orders/1/payments", {"payments": []}),
        ("POST", "/api/orders/1/discount", {"type": "percent", "value": -10}),
        ("POST", "/api/orders/999999/refund", {"method": "cash", "amount": 1, "reason": "xx"}),
        ("POST", "/api/staff/auth/login", {"username": "a" * 10000, "password": "b" * 10000}),
        ("PUT", "/api/system/settings", {"tax.percent": None}),
    ]
    for m, p, body in cases:
        r = client.request(m, p, headers=admin, json=body)
        assert 400 <= r.status_code < 500, (p, body, r.status_code, r.text[:200])


def test_upload_requires_manage_permission_and_real_image(client, waiter, admin):
    png = b"\x89PNG\r\n\x1a\n" + b"\0" * 64
    assert client.post("/api/system/upload", headers=waiter, files={"file": ("a.png", png, "image/png")}).status_code == 403
    assert client.post("/api/system/upload", headers=admin, files={"file": ("a.png", b"<script>", "image/png")}).status_code == 400
    assert client.post("/api/system/upload", headers=admin, files={"file": ("a.png", png, "image/png")}).status_code == 200


def test_websocket_requires_valid_token(client):
    from starlette.websockets import WebSocketDisconnect
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/ws?token=bad") as ws:
            ws.receive_text()


def test_backup_download_rejects_traversal(client, admin):
    for name in ("..", "..%2Fcafe.db", "secret.key", "cafe.db"):
        assert client.get(f"/api/system/backups/{name}", headers=admin).status_code == 404


def test_ws_events_are_filtered_by_permission(client, chef, admin):
    from app.core.realtime import allowed, hub
    k = frozenset({"kitchen.access"})
    assert not allowed(k, "customer.updated") and not allowed(k, "shift.changed") and not allowed(k, "online.new")
    assert allowed(k, "order.updated") and allowed(k, "kds.ticket") and allowed(frozenset({"*"}), "customer.updated")
    token = chef["Authorization"].split()[1]
    with client.websocket_connect(f"/ws?token={token}") as ws:
        hub.publish("customer.updated", {"phone": "09120000000"})     # must NOT reach the kitchen screen
        hub.publish("order.updated", {"id": 1})
        msg = ws.receive_json()
        assert msg["topic"] == "order.updated"


def test_ws_closed_when_user_deactivated(client, admin):
    from starlette.websockets import WebSocketDisconnect
    roles = {r["name"]: r["id"] for r in client.get("/api/staff/roles", headers=admin).json()}
    u = client.post("/api/staff/users", headers=admin, json={"username": "kds_tab", "full_name": "تبلت آشپزخانه", "role_id": roles["kitchen"],
                                                             "password": "Kds-pass-123"}).json()
    token = _login(client, "kds_tab", "Kds-pass-123")["Authorization"].split()[1]
    with client.websocket_connect(f"/ws?token={token}") as ws:
        ws.send_text("ping")
        assert ws.receive_json()["topic"] == "pong"
        client.put(f"/api/staff/users/{u['id']}", headers=admin, json={"username": "kds_tab", "full_name": "تبلت آشپزخانه",
                                                                      "role_id": roles["kitchen"], "is_active": False})
        with pytest.raises(WebSocketDisconnect):
            for _ in range(5):
                ws.receive_json()
    with pytest.raises(WebSocketDisconnect):                     # and can't reconnect with the old token
        with client.websocket_connect(f"/ws?token={token}") as ws:
            ws.receive_text()


def test_ws_refuses_token_that_must_change_password(client, admin, monkeypatch):
    from starlette.websockets import WebSocketDisconnect
    roles = {r["name"]: r["id"] for r in client.get("/api/staff/roles", headers=admin).json()}
    client.post("/api/staff/users", headers=admin, json={"username": "fresh_chef", "full_name": "آشپز تازه", "role_id": roles["kitchen"],
                                                         "password": "kitchen123"})
    monkeypatch.setattr(get_settings(), "force_password_change", True)
    token = client.post("/api/staff/auth/login", json={"username": "fresh_chef", "password": "kitchen123"}).json()["token"]
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect(f"/ws?token={token}") as ws:
            ws.receive_text()


def test_tokens_are_redacted_from_access_logs():
    import logging

    from app.main import _RedactTokens
    rec = logging.LogRecord("uvicorn.access", logging.INFO, "", 0, '%s - "%s %s HTTP/%s" %d', 
                            ("1.2.3.4:5", "GET", "/ws?token=eyJhbGciOi.secret.sig&x=1", "1.1", 101), None)
    _RedactTokens().filter(rec)
    line = rec.getMessage()
    assert "eyJ" not in line and "token=***" in line and "x=1" in line
    for name in ("uvicorn.access", "uvicorn.error"):              # the WebSocket "[accepted]" line uses uvicorn.error
        assert any(isinstance(f, _RedactTokens) for f in logging.getLogger(name).filters), name


def test_excel_export_neutralises_formulas(client, admin, waiter, menu):
    """A void reason typed by staff must not become an executable formula in the manager's spreadsheet."""
    import io

    from conftest import line
    from openpyxl import load_workbook
    o = client.post("/api/orders", headers=waiter, json={"type": "takeaway", "lines": [line(menu, "101")], "send": True}).json()
    evil = '=HYPERLINK("http://evil.example","x")'
    r = client.post(f"/api/orders/{o['id']}/lines/{o['lines'][0]['id']}/void", headers={**waiter, "X-Manager-Pin": "2222"},
                    json={"reason": evil})
    assert r.status_code == 200, r.text
    x = client.get("/api/reports/sales/export", headers=admin)
    assert x.status_code == 200
    wb = load_workbook(io.BytesIO(x.content))
    cells = [c for row in wb["حذفیات"].iter_rows() for c in row if c.value == evil]
    assert cells and all(c.data_type == "s" for c in cells)
    assert wb["خلاصه"]["B4"].value == "تومان"                      # amounts' unit is stated
    client.post(f"/api/orders/{o['id']}/cancel", headers={**waiter, "X-Manager-Pin": "2222"}, json={"reason": "پایان تست"})


def test_out_of_range_number_is_a_clean_422_not_500(client, admin):
    """A number beyond the database's 64-bit range (SQLite OverflowError / PostgreSQL DataError) → 422, nothing saved."""
    before = len(client.get("/api/menu/categories", headers=admin).json())
    r = client.post("/api/menu/categories", json={"name": "خیلی بزرگ", "sort": 10**19}, headers=admin)
    assert r.status_code == 422 and r.json()["detail"]["code"] == "number_too_large"
    assert len(client.get("/api/menu/categories", headers=admin).json()) == before
