"""Menu and floor administration (the write endpoints) plus the pricing maths and the job runner.

These are the endpoints the owner uses when setting the café up: stations, categories, modifier
groups, items and the room/table layout. They had no direct tests — the older suites created data
through the demo seed instead, so a break in (say) "delete a category" would only be found by hand.
"""
import pytest

from app.core.errors import AppError
from app.modules.orders import pricing
from app.modules.orders.pricing import discount_of


# ---------------------------------------------------------------- pricing (pure)
@pytest.mark.parametrize("typ,value,cap,base,expected", [
    (None, 10, None, 100_000, 0),            # no discount type
    ("percent", 10, None, 100_000, 10_000),
    ("percent", 0, None, 100_000, 0),
    ("percent", 150, None, 100_000, 100_000),  # >100% is clamped by the caller, not here
    ("amount", 30_000, None, 100_000, 30_000),
    ("amount", 300_000, None, 100_000, 100_000),  # a fixed discount can never exceed the base
    ("percent", 50, 20_000, 100_000, 20_000),   # the cap wins
    ("percent", 10, None, 0, 0),                # nothing to discount
])
def test_discount_of(typ, value, cap, base, expected):
    assert discount_of(typ, value, cap, base) == expected


def test_next_number_starts_at_one_and_increments_per_business_day(client, admin):
    from datetime import date

    from app.core.db import SessionLocal
    from app.modules.orders.models import Order

    day = date(2031, 1, 1)          # a day no other test uses
    with SessionLocal() as db:
        assert pricing.next_number(db, day) == 1
        db.add(Order(number=1, business_date=day, type="takeaway", status="open", guests=1, total=0, subtotal=0))
        db.commit()
        try:
            assert pricing.next_number(db, day) == 2
            assert pricing.next_number(db, date(2031, 1, 2)) == 1     # a new day starts again
        finally:
            db.query(Order).filter(Order.business_date == day).delete()
            db.commit()


# ---------------------------------------------------------------- menu: stations & categories
def test_station_crud(client, admin):
    r = client.post("/api/menu/stations", headers=admin, json={"name": "ایستگاه تست", "sort": 99})
    assert r.status_code == 201, r.text
    sid = r.json()["id"]
    assert client.put(f"/api/menu/stations/{sid}", headers=admin, json={"name": "ایستگاه ویرایش", "sort": 98}).json()["name"] == "ایستگاه ویرایش"
    assert client.delete(f"/api/menu/stations/{sid}", headers=admin).status_code == 204


def test_category_crud_and_reorder(client, admin):
    a = client.post("/api/menu/categories", headers=admin, json={"name": "دسته تست الف", "sort": 1}).json()
    b = client.post("/api/menu/categories", headers=admin, json={"name": "دسته تست ب", "sort": 2}).json()
    assert client.put(f"/api/menu/categories/{a['id']}", headers=admin, json={"name": "دسته ویرایش", "sort": 1}).json()["name"] == "دسته ویرایش"
    r = client.post("/api/menu/categories/reorder", headers=admin, json=[b["id"], a["id"]])   # index = new sort
    assert r.status_code == 204
    names = [c["name"] for c in client.get("/api/menu/categories", headers=admin).json()]
    assert names.index("دسته تست ب") < names.index("دسته ویرایش")
    assert client.delete(f"/api/menu/categories/{a['id']}", headers=admin).status_code == 204
    assert client.delete(f"/api/menu/categories/{b['id']}", headers=admin).status_code == 204


def test_modifier_group_crud(client, admin):
    r = client.post("/api/menu/modifier-groups", headers=admin, json={
        "name": "گروه تست", "min_select": 0, "max_select": 2,
        "options": [{"name": "گزینه ۱", "price_delta": 0}, {"name": "گزینه ۲", "price_delta": 5000}],
    })
    assert r.status_code == 201, r.text
    gid = r.json()["id"]
    up = client.put(f"/api/menu/modifier-groups/{gid}", headers=admin, json={
        "name": "گروه ویرایش", "min_select": 0, "max_select": 1, "options": [{"name": "تنها", "price_delta": 1000}],
    })
    assert up.status_code == 200 and up.json()["name"] == "گروه ویرایش"
    assert client.delete(f"/api/menu/modifier-groups/{gid}", headers=admin).status_code == 204


# ---------------------------------------------------------------- menu: items
def test_item_crud_availability_and_delete(client, admin):
    cat = client.post("/api/menu/categories", headers=admin, json={"name": "دسته آیتم", "sort": 5}).json()
    st = client.post("/api/menu/stations", headers=admin, json={"name": "ایستگاه آیتم", "sort": 5}).json()
    created = client.post("/api/menu/items", headers=admin, json={
        "name": "آیتم تست", "code": "T-901", "category_id": cat["id"], "price": 90_000, "station_id": st["id"],
    })
    assert created.status_code == 201, created.text
    item = created.json()
    assert item["price"] == 90_000 and item["is_active"]

    # price change
    up = client.put(f"/api/menu/items/{item['id']}", headers=admin, json={**item, "price": 95_000})
    assert up.status_code == 200 and up.json()["price"] == 95_000

    # availability toggle is its own endpoint (the POS switch)
    off = client.patch(f"/api/menu/items/{item['id']}/availability?available=false", headers=admin)
    assert off.status_code == 200 and off.json()["is_available"] is False
    on = client.patch(f"/api/menu/items/{item['id']}/availability?available=true", headers=admin)
    assert on.json()["is_available"] is True

    # delete is a soft delete: the item stays in the list (history, reports) but is switched off
    assert client.delete(f"/api/menu/items/{item['id']}", headers=admin).status_code == 204
    rows = [i for i in client.get("/api/menu/items", headers=admin).json() if i["code"] == "T-901"]
    assert len(rows) == 1 and rows[0]["is_active"] is False
    client.delete(f"/api/menu/stations/{st['id']}", headers=admin)
    client.delete(f"/api/menu/categories/{cat['id']}", headers=admin)


# ---------------------------------------------------------------- floor: areas & tables
def test_area_and_table_crud_with_qr(client, admin):
    area = client.post("/api/floor/areas", headers=admin, json={"name": "سالن تست", "sort": 3}).json()
    assert client.put(f"/api/floor/areas/{area['id']}", headers=admin, json={"name": "سالن ویرایش", "sort": 3}).json()["name"] == "سالن ویرایش"

    t = client.post("/api/floor/tables", headers=admin, json={"name": "میز تست", "seats": 4, "shape": "square", "area_id": area["id"], "is_active": True})
    assert t.status_code == 201, t.text
    table = t.json()
    assert table["qr_token"]                       # every table gets its own QR token

    moved = client.put(f"/api/floor/tables/{table['id']}", headers=admin, json={**table, "seats": 6})
    assert moved.json()["seats"] == 6

    new_qr = client.post(f"/api/floor/tables/{table['id']}/regenerate-qr", headers=admin).json()["qr_token"]
    assert new_qr != table["qr_token"]             # invalidating a leaked sticker works

    assert client.post("/api/floor/tables/positions", headers=admin, json=[{"id": table["id"], "x": 2, "y": 1}]).status_code == 204

    # deleting a table is a soft delete so old orders keep their table name
    assert client.delete(f"/api/floor/tables/{table['id']}", headers=admin).status_code == 204
    assert all(x["id"] != table["id"] or not x["is_active"] for x in client.get("/api/floor/tables", headers=admin).json())
    client.delete(f"/api/floor/areas/{area['id']}", headers=admin)


def test_menu_and_floor_writes_need_the_permission(client, waiter):
    assert client.post("/api/menu/categories", headers=waiter, json={"name": "x", "sort": 0}).status_code == 403
    assert client.post("/api/floor/areas", headers=waiter, json={"name": "x", "sort": 0}).status_code == 403


# ---------------------------------------------------------------- job runner
def test_a_failing_job_is_recorded_and_does_not_raise(client):
    from app.core.db import SessionLocal
    from app.core.jobs import Job, run_job

    def boom(db):
        raise RuntimeError("network down")

    job = Job(name="test.boom", every=5, fn=boom)
    run_job(job)                                   # must swallow the exception
    assert job.last_error and "network down" in job.last_error
    assert job.last_run > 0

    ok = Job(name="test.ok", every=5, fn=lambda db: None)
    run_job(ok)
    assert ok.last_error is None
    assert SessionLocal is not None
