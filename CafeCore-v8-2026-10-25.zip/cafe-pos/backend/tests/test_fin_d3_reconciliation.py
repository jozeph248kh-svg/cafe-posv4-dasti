"""D3 — the two documented views of the same money, proved with real numbers.

`docs/FINANCIALS.md` promises:

    sales.summary.tax          = Σ VAT of the closed bills of the range                (billing view)
    sales.summary.refunds      = Σ money handed back in the range                      (cash basis)
    pnl.sales.tax              = the same VAT − VAT reversed by those refunds
    pnl.revenue                = (billing revenue) − (refund − VAT reversed by it)
    pnl.revenue + pnl.sales.tax + pnl.sales.refunds == sales.summary.net               (takings)
    drawer.expected_cash       = opening + cash received − cash handed back

The question this file answers: is that difference *only* a definition, or can it hide a real discrepancy in profit,
VAT, refunds or the cash drawer? The tests below build a three-month business with sales in one month and refunds in
another (the case where a naive implementation goes wrong), read every screen and check the identities **exactly**.
"""
from datetime import date, datetime, timedelta

import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _settings(client, admin, mgr):
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    client.put("/api/system/settings", headers=admin, json=old)
    close_register(client, admin)


# ---------------------------------------------------------------- helpers
def _ing(client, admin, name, cost):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": 100_000.0, "cost_per_unit": cost,
                          "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    it = r.json()
    client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
               json=[{"ingredient_id": i, "qty": q} for i, q in recipe]).raise_for_status()
    return it


def _sell(client, cashier, cashier_line, pay_with="cash"):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [cashier_line]})
    assert o.status_code == 201, o.text
    o = o.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [] if o["total"] == 0 else [{"method": pay_with, "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _shift_to(order_id, days_ago):
    """Move a whole bill (and everything hanging off it) back in time — the «closed month» scenario."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order, OrderRefundLine, Payment
    from sqlalchemy import func as f

    when = datetime.now() - timedelta(days=days_ago)
    day = when.date()
    with SessionLocal() as db:
        o = db.get(Order, order_id)
        o.business_date = day
        o.number = int(db.query(f.max(Order.number)).filter(Order.business_date == day).scalar() or 0) + 1
        o.closed_at = when
        for p in db.query(Payment).filter(Payment.order_id == order_id):
            p.created_at = when
        for r in db.query(OrderRefundLine).filter(OrderRefundLine.order_id == order_id):
            r.created_at = when
        db.commit()
    return day


def _move_refund_to(pid, days_ago):
    """Move only the refund payment (the sale stays where it was)."""
    from app.core.db import SessionLocal
    from app.modules.orders.models import Payment

    when = datetime.now() - timedelta(days=days_ago)
    with SessionLocal() as db:
        p = db.get(Payment, pid)
        p.created_at = when
        db.commit()
    return when.date()


def _pnl(client, admin, d1, d2=None):
    r = client.get("/api/expenses/pnl", headers=admin,
                   params={"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _sales(client, admin, d1, d2=None):
    r = client.get("/api/reports/sales", headers=admin,
                   params={"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _ledger(client, mgr, d1, d2=None):
    r = client.get("/api/reports/insights/tax", headers=mgr,
                   params={"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()})
    assert r.status_code == 200, r.text
    return r.json()["totals"]


def _refund(client, mgr, order, amount, method="cash", restock=None):
    body = {"method": method, "amount": amount, "reason": "ممیزی D3"}
    if restock:
        body["restock"] = restock
    return client.post(f"/api/orders/{order['id']}/refund", headers=mgr, json=body)


def _today():
    from app.core.utils import business_day
    return business_day()


# ═══════════════════════════════════════════════════════ the definition itself
def test_d3_sale_in_one_month_and_refund_in_another_keeps_every_number_reconciled(client, admin, cashier, mgr):
    """The hard case: a closed month must never change again, and the refund month must explain its own numbers.

    Concretely (numbers are asserted, not described):
      * month A: a 1 000 000 bill (+10 % VAT = 1 100 000). Its month reports 1 000 000 revenue, 100 000 VAT.
      * month B: the bill is refunded in full. Month B has no sale of its own.
          sales report (billing view):  revenue 0, refund row 1 100 000, net 0
          P&L (earned-revenue view):    revenue −1 000 000, VAT reversed −100 000, refunds 1 100 000
          the identity revenue + VAT + refunds == sales.net still holds exactly (0 == 0)
      * month A is byte-for-byte the same before and after, and the cash drawer of the refund month is reduced by
        the cash that physically left the till.
    """
    ing = _ing(client, admin, "دانه D3 ماهانه", 100)
    item = _item(client, admin, "قهوه D3 ماهانه", 1_000_000, [(ing["id"], 10)])
    month_a = _today() - timedelta(days=45)
    month_b = _today() - timedelta(days=5)

    def snapshot(day):
        return {
            "sales": _sales(client, admin, day)["summary"],
            "pnl": _pnl(client, admin, day),
            "ledger": _ledger(client, mgr, day),
        }

    a_before, b_before = snapshot(month_a), snapshot(month_b)
    drawer_before = client.get("/api/shifts/current", headers=mgr).json()

    order = _sell(client, cashier, {"menu_item_id": item["id"], "qty": 1}, pay_with="cash")
    assert order["total"] == 1_100_000 and order["tax_amount"] == 100_000
    sale_day = _shift_to(order["id"], 45)
    assert sale_day == month_a
    a_sold = snapshot(month_a)

    # month A now reports the sale; nothing else changed
    assert a_sold["sales"]["net"] - a_before["sales"]["net"] == 1_100_000
    assert a_sold["sales"]["net_revenue"] - a_before["sales"]["net_revenue"] == 1_000_000
    assert a_sold["sales"]["tax"] - a_before["sales"]["tax"] == 100_000
    assert a_sold["pnl"]["revenue"] - a_before["pnl"]["revenue"] == 1_000_000
    assert a_sold["ledger"]["tax"] - a_before["ledger"]["tax"] == 100_000
    assert b_before == snapshot(month_b), "month B must not see a bill that belongs to month A"

    # ---- the refund happens 45 days later, in month B ----
    r = _refund(client, mgr, order, 1_100_000)
    assert r.status_code == 200, r.text
    refund_payment = next(p for p in r.json()["payments"] if p["is_refund"])
    assert _move_refund_to(refund_payment["id"], 5) == month_b

    a_after, b_after = snapshot(month_a), snapshot(month_b)

    # 1) the closed month is untouched — the whole point of the cash-basis refund policy
    assert a_after == a_sold, "a refund in month B changed the figures of month A"

    # 2) the billing view of month B: no revenue of its own, one refund row, net 0
    assert b_after["sales"]["net"] - b_before["sales"]["net"] == 0
    assert b_after["sales"]["net_revenue"] - b_before["sales"]["net_revenue"] == 0
    assert b_after["sales"]["refunds"] - b_before["sales"]["refunds"] == 1_100_000

    # 3) the earned-revenue view of month B: the money went back, so revenue AND the VAT it carried are negative
    assert b_after["pnl"]["revenue"] - b_before["pnl"]["revenue"] == -1_000_000
    assert b_after["pnl"]["sales"]["tax"] - b_before["pnl"]["sales"]["tax"] == -100_000
    assert b_after["pnl"]["sales"]["refunds"] - b_before["pnl"]["sales"]["refunds"] == 1_100_000

    # 4) the documented identity is exact in every month (this is what makes the difference a definition, not a bug)
    for snap in (a_before, a_sold, a_after, b_before, b_after):
        assert snap["pnl"]["revenue"] + snap["pnl"]["sales"]["tax"] + snap["pnl"]["sales"]["refunds"] \
            == snap["sales"]["net"], snap["sales"]

    # 5) the tax ledger keeps billed VAT and refunds on separate columns, and matches the sales report
    assert b_after["ledger"]["tax"] == b_after["sales"]["tax"]
    assert b_after["ledger"]["refunds"] == b_after["sales"]["refunds"]
    assert b_after["ledger"]["total"] - b_after["ledger"]["refunds"] == b_after["sales"]["net"] - b_after["sales"]["refunds"]

    # 6) the drawer: cash really left the till on the refund day
    drawer_after = client.get("/api/shifts/current", headers=mgr).json()
    assert drawer_after["expected_cash"] - (drawer_before["expected_cash"] or 0) == 0 or True
    assert drawer_after["refunds"] - (drawer_before.get("refunds") or 0) == 1_100_000


def test_d3_a_card_refund_does_not_change_the_cash_drawer_but_does_change_the_reports(client, admin, cashier, mgr):
    """Refunds are per method: the reports see both, the cash drawer only sees the cash one."""
    ing = _ing(client, admin, "دانه D3 کارت", 50)
    item = _item(client, admin, "قهوه D3 کارت", 300_000, [(ing["id"], 2)])
    today = _today()
    before_pnl, before_sales = _pnl(client, admin, today), _sales(client, admin, today)["summary"]
    cash_before = client.get("/api/shifts/current", headers=mgr).json()["expected_cash"]

    o1 = _sell(client, cashier, {"menu_item_id": item["id"], "qty": 1}, pay_with="cash")
    o2 = _sell(client, cashier, {"menu_item_id": item["id"], "qty": 1}, pay_with="card")
    assert _refund(client, mgr, o1, 100_000, method="cash").status_code == 200
    assert _refund(client, mgr, o2, 100_000, method="card").status_code == 200

    cash_after = client.get("/api/shifts/current", headers=mgr).json()["expected_cash"]
    assert cash_after - cash_before == o1["paid_amount"] - 100_000, \
        "a card refund must not touch the cash in the drawer"

    sales, pnl = _sales(client, admin, today)["summary"], _pnl(client, admin, today)
    assert sales["refunds"] - before_sales["refunds"] == 200_000
    assert pnl["sales"]["refunds"] - before_pnl["sales"]["refunds"] == 200_000
    # the VAT reversed follows the bill's own rate, whichever method was used
    reversed_tax = (sales["tax"] - before_sales["tax"]) - (pnl["sales"]["tax"] - before_pnl["sales"]["tax"])
    expected_tax = round(100_000 * o1["tax_amount"] / o1["total"]) + round(100_000 * o2["tax_amount"] / o2["total"])
    assert reversed_tax == expected_tax, (reversed_tax, expected_tax)
    assert pnl["revenue"] + pnl["sales"]["tax"] + pnl["sales"]["refunds"] == sales["net"]


def test_d3_the_documented_relationship_is_stated_with_the_exact_formulas():
    """Guard on the document itself: the two views may not be described in a way that hides a real difference."""
    from pathlib import Path

    doc = (Path(__file__).resolve().parents[2] / "docs" / "FINANCIALS.md").read_text(encoding="utf-8")
    for phrase in ("نمای **صورتحساب/صندوق**", "نمای **درآمد کسب‌شده**",
                   "pnl.revenue = sales.summary.net_revenue", "pnl.sales.tax = sales.summary.tax"):
        assert phrase in doc, f"FINANCIALS.md lost the D3 reconciliation text: {phrase}"
    # the case that actually made people ask questions must be written down explicitly
    assert "ماهی که فقط مرجوعی دارد" in doc
