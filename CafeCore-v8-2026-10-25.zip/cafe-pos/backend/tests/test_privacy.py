"""Customer phone privacy: users without `customers.phone` see 0912***4567 everywhere in the API, but can still
search by a full number, attach a picked customer to an order, and edit records without destroying the number."""
from datetime import datetime, timedelta

from app.core.privacy import mask_phone, mask_tree

PHONE = "09127770001"
MASKED = "0912***0001"


def test_mask_helpers():
    assert mask_phone(PHONE) == MASKED and mask_phone(MASKED) == MASKED and mask_phone("12345") == "***"
    assert mask_phone(None) is None
    tree = {"phone": PHONE, "x": [{"customer_phone": PHONE, "phones": [PHONE]}], "to": PHONE, "name": "n"}
    assert mask_tree(tree) == {"phone": MASKED, "x": [{"customer_phone": MASKED, "phones": [MASKED]}], "to": PHONE, "name": "n"}
    assert mask_tree(tree, sms=True)["to"] == MASKED


def test_waiter_sees_masked_numbers_cashier_sees_full(client, admin, cashier, waiter):
    r = client.post("/api/customers", headers=admin, json={"name": "مشتری حریم", "phone": PHONE})
    assert r.status_code in (201, 400), r.text                      # 400 = already there from a previous run
    rows = client.get("/api/customers", headers=waiter, params={"q": PHONE}).json()
    assert rows and rows[0]["phone"] == MASKED                       # full-number search works, output masked
    assert client.get("/api/customers", headers=cashier, params={"q": PHONE}).json()[0]["phone"] == PHONE
    assert client.get("/api/staff/permissions", headers=admin).json()["customers"]["items"]["customers.phone"]


def test_picked_customer_and_masked_echo_never_lose_the_number(client, admin, waiter):
    cust = client.get("/api/customers", headers=admin, params={"q": PHONE}).json()[0]
    # the waiter picked the customer from the search: the form holds the masked number + customer_id
    r = client.post("/api/orders", headers=waiter, json={"type": "takeaway", "customer_name": cust["name"],
                                                          "customer_phone": MASKED, "customer_id": cust["id"]})
    assert r.status_code in (200, 201), r.text
    oid = r.json()["id"]
    assert r.json()["customer_phone"] == MASKED                      # the waiter's response is masked …
    assert client.get(f"/api/orders/{oid}", headers=admin).json()["customer_phone"] == PHONE   # … stored in full
    # saving the order-info form again echoes the masked number → unchanged
    assert client.patch(f"/api/orders/{oid}", headers=waiter, json={"customer_phone": MASKED, "note": "بی‌سس"}).status_code == 200
    o = client.get(f"/api/orders/{oid}", headers=admin).json()
    assert o["customer_phone"] == PHONE and o["note"] == "بی‌سس"
    # a masked number without a customer to resolve it is refused on create (never stored truncated)
    r = client.post("/api/orders", headers=waiter, json={"type": "takeaway", "customer_phone": MASKED})
    assert r.status_code == 422 and r.json()["detail"]["code"] == "phone_masked"
    assert client.post(f"/api/orders/{oid}/cancel", headers=admin, json={"reason": "تست حریم خصوصی"}).status_code == 200


def test_reservation_edit_by_masked_user_keeps_the_number(client, admin, waiter):
    start = (datetime.now() + timedelta(days=20)).replace(hour=20, minute=0, second=0, microsecond=0)
    body = {"customer_name": "رزرو حریم", "phone": "09127770002", "guests": 2, "start_at": start.isoformat()}
    r = client.post("/api/reservations", headers=waiter, json=body)
    assert r.status_code == 201 and r.json()["phone"] == "0912***0002", r.text
    rid = r.json()["id"]
    r = client.put(f"/api/reservations/{rid}", headers=waiter, json={**body, "phone": "0912***0002", "guests": 4})
    assert r.status_code == 200, r.text
    day = client.get("/api/reservations", headers=admin, params={"day": start.date().isoformat()}).json()
    row = next(x for x in (day if isinstance(day, list) else day["items"]) if x["id"] == rid)
    assert row["phone"] == "09127770002" and row["guests"] == 4
    assert client.post(f"/api/reservations/{rid}/status", headers=admin, json={"status": "cancelled"}).status_code == 200


def test_sms_credentials_never_leave_the_server(client, admin):
    """GET /api/sms/status used to return `sms.config` verbatim — the provider API key, in clear text,
    to every browser that opened the SMS page. It must be masked now, and saving the masked value back
    must keep the real credential (an untouched form field must not erase it)."""
    secret = "SECRET-KEY-1234567890"
    r = client.put("/api/sms/config", headers=admin, json={
        "enabled": True, "provider": "kavenegar", "config": {"kavenegar": {"api_key": secret, "sender": "10004346"}},
        "optout_footer": "لغو۱۱", "reminder_minutes": 120, "quiet_start": 23, "quiet_end": 8,
    })
    assert r.status_code == 200, r.text

    status = client.get("/api/sms/status", headers=admin).json()
    assert secret not in str(status), "the API key is still returned to the client"
    assert status["config"]["kavenegar"]["api_key"].startswith("••••")
    assert status["config"]["kavenegar"]["sender"] == "10004346"      # non-secret fields stay readable

    # the form posts the masked value back untouched → the stored secret must survive
    masked = status["config"]
    r = client.put("/api/sms/config", headers=admin, json={
        "enabled": True, "provider": "kavenegar", "config": masked,
        "optout_footer": status["optout_footer"], "reminder_minutes": status["reminder_minutes"],
        "quiet_start": status["quiet_start"], "quiet_end": status["quiet_end"],
    })
    assert r.status_code == 200, r.text
    from app.core import settings_store
    from app.core.db import SessionLocal
    with SessionLocal() as db:
        assert settings_store.get(db, "sms.config")["kavenegar"]["api_key"] == secret
