"""Several cash registers: each device sends X-Register-Id; shifts, opening cash, payments and the cash count are kept
per register. No header = the main register (single-register cafes behave exactly as before)."""
from conftest import line


def _pay(client, h, oid, method, amount):
    return client.post(f"/api/orders/{oid}/payments", json={"payments": [{"method": method, "amount": amount}]}, headers=h)


def test_registers_keep_separate_shifts_and_cash(client, admin, cashier, waiter, menu):
    regs = client.get("/api/shifts/registers", headers=waiter).json()          # any signed-in device can pick
    main = next(r for r in regs if r["is_main"])
    assert client.post("/api/shifts/registers", headers=waiter, json={"name": "صندوق تست"}).status_code == 403
    r = client.post("/api/shifts/registers", headers=admin, json={"name": "صندوق بیرون‌بر تست"})
    assert r.status_code == 201, r.text
    reg2 = r.json()
    assert client.post("/api/shifts/registers", headers=admin, json={"name": "صندوق بیرون‌بر تست"}).status_code == 400
    dev2 = {**cashier, "X-Register-Id": str(reg2["id"])}
    main_open_before = client.get("/api/shifts/current", headers=admin).json()     # supervisor: sees the expected cash
    opened_main = False
    try:
        # main register closed → a payment from a device without a register fails with the register's name
        if main_open_before:
            client.post("/api/shifts/close", headers=admin, json={"counted_cash": main_open_before["expected_cash"], "register_id": main["id"]}).raise_for_status()
        o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101")]}).json()
        r = _pay(client, cashier, o["id"], "cash", o["total"])
        assert r.status_code == 400 and r.json()["detail"]["code"] == "shift_closed" and main["name"] in r.json()["detail"]["message"]

        # device 2 opens its own register and takes the payment
        s2 = client.post("/api/shifts/open", headers=dev2, json={"opening_cash": 500_000})
        assert s2.status_code == 200 and s2.json()["register_id"] == reg2["id"], s2.text
        assert client.post("/api/shifts/open", headers=dev2, json={"opening_cash": 0}).json()["detail"]["code"] == "shift_open"
        assert client.get("/api/shifts/current", headers=cashier).json() is None                   # main is still closed
        assert _pay(client, dev2, o["id"], "cash", o["total"]).status_code == 200
        blind = client.get("/api/shifts/current", headers=dev2).json()           # the cashier counts blind
        assert blind["id"] == s2.json()["id"] and blind["expected_cash"] is None and "cash" not in blind["payments"]
        cur2 = client.get("/api/shifts/current", headers={**admin, "X-Register-Id": str(reg2["id"])}).json()
        assert cur2["id"] == s2.json()["id"] and cur2["payments"]["cash"] == o["total"] and cur2["expected_cash"] == 500_000 + o["total"]
        assert client.post("/api/shifts/cash", headers=dev2, json={"kind": "out", "amount": 100_000, "reason": "خرید یخ"}).status_code == 200

        # main register opened from another device; a half-paid order on main does not block closing register 2
        client.post("/api/shifts/open", headers=admin, json={"opening_cash": 0, "register_id": main["id"]}).raise_for_status()
        opened_main = True
        half = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 2)]}).json()
        assert _pay(client, cashier, half["id"], "card", 10_000).status_code == 200
        assert client.get("/api/shifts/current", headers=cashier).json()["payments"] == {"card": 10_000}
        # deactivating a register with an open shift is refused
        upd = {"name": reg2["name"], "is_active": False, "sort": 0}
        assert client.put(f"/api/shifts/registers/{reg2['id']}", headers=admin, json=upd).json()["detail"]["code"] == "register_busy"
        regs = {r["id"]: r for r in client.get("/api/shifts/registers", headers=cashier).json()}
        assert regs[reg2["id"]]["open_shift"] and regs[main["id"]]["open_shift"]
        closed = client.post("/api/shifts/close", headers=dev2, json={"counted_cash": 500_000 + o["total"] - 100_000 - 2_000})
        assert closed.status_code == 200 and closed.json()["difference"] == -2_000 and closed.json()["register_name"] == reg2["name"]
        # the main register's half-paid order still blocks closing main
        r = client.post("/api/shifts/close", headers=cashier, json={"counted_cash": 0})
        assert r.status_code == 400 and "نیمه‌پرداخت" in r.json()["detail"]["message"]
        client.post(f"/api/orders/{half['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "card", "amount": half["total"] - 10_000}]}).raise_for_status()

        # history and the cash-reconciliation report know the register
        hist = client.get("/api/shifts", headers=admin, params={"register_id": reg2["id"]}).json()
        assert [h["id"] for h in hist] == [s2.json()["id"]]
        from app.core.utils import business_day
        d = business_day().isoformat()
        rep = client.get("/api/reports/insights/shifts", headers=admin, params={"date_from": d, "date_to": d})
        assert rep.status_code == 200, rep.text
        assert any(x.get("register") == reg2["name"] for x in rep.json()["rows"])

        # a register that no longer exists / was disabled → the device is told to pick again (never silently main)
        for bad in ("999999", "abc", "-3"):
            r = client.get("/api/shifts/current", headers={**cashier, "X-Register-Id": bad})
            assert r.status_code == 409 and r.json()["detail"]["code"] == "register_invalid", bad
        assert client.put(f"/api/shifts/registers/{reg2['id']}", headers=admin, json=upd).status_code == 200
        o3 = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101")]}).json()
        r = _pay(client, dev2, o3["id"], "cash", o3["total"])
        assert r.status_code == 409 and r.json()["detail"]["code"] == "register_invalid"
        assert reg2["id"] not in {x["id"] for x in client.get("/api/shifts/registers", headers=cashier).json()}
        assert reg2["id"] in {x["id"] for x in client.get("/api/shifts/registers", headers=admin, params={"all": 1}).json()}
        client.post(f"/api/orders/{o3['id']}/cancel", headers=admin, json={"reason": "تست"})
        # the last active register can't be disabled
        for x in client.get("/api/shifts/registers", headers=admin).json():
            if x["id"] != main["id"] and x["is_active"]:
                client.put(f"/api/shifts/registers/{x['id']}", headers=admin, json={"name": x["name"], "is_active": False, "sort": x["sort"]})
        r = client.put(f"/api/shifts/registers/{main['id']}", headers=admin, json={"name": main["name"], "is_active": False, "sort": 0})
        assert r.status_code == 400 and r.json()["detail"]["code"] in ("register_last", "register_busy")
    finally:
        cur = client.get("/api/shifts/current", headers=dev2)
        if cur.status_code == 200 and cur.json():
            client.post("/api/shifts/close", headers=dev2, json={"counted_cash": 0})
        if opened_main and not main_open_before:
            m = client.get("/api/shifts/current", headers=cashier).json()
            if m:
                client.post("/api/shifts/close", headers=admin, json={"counted_cash": m["expected_cash"], "register_id": main["id"]})
        if main_open_before and not client.get("/api/shifts/current", headers=cashier).json():
            client.post("/api/shifts/open", headers=admin, json={"opening_cash": 0, "register_id": main["id"]})
