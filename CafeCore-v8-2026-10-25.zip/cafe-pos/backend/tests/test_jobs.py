"""Background senders (SMS outbox, Moadian) must never deliver the same row twice, even when the job, a manual
«ارسال الان» and another server process run at the same moment; and a send cut off by a crash is not left stuck."""
import threading
import time
from datetime import timedelta

from conftest import line


def _parallel(fn, n=2):
    errs: list = []

    def run():
        try:
            fn()
        except Exception as e:  # noqa: BLE001
            errs.append(e)
    ts = [threading.Thread(target=run) for _ in range(n)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(30)
    assert not errs, errs


def test_sms_outbox_is_sent_once_under_concurrency(client, monkeypatch):
    from app.core.db import SessionLocal
    from app.core.utils import now
    from app.modules.sms import service as S
    from app.modules.sms.models import SmsMessage

    calls: list[str] = []

    class Slow:
        key = "test"

        def send(self, to, text):
            calls.append(text)
            time.sleep(0.15)              # the network call: the other sender runs meanwhile
            return f"P-{len(calls)}"
    monkeypatch.setattr(S, "provider", lambda db: Slow())
    with SessionLocal() as db:
        ms = [S.enqueue(db, f"0912777{i:04d}", f"jobs-test {i}", "manual") for i in range(4)]
        db.commit()
        ids = [m.id for m in ms]
    try:
        def job():
            with SessionLocal() as db:
                S.process_queue(db)
                db.commit()
        _parallel(job, 3)
        mine = [c for c in calls if c.startswith("jobs-test")]
        assert sorted(mine) == [f"jobs-test {i}" for i in range(4)], mine          # each exactly once
        with SessionLocal() as db:
            rows = db.query(SmsMessage).filter(SmsMessage.id.in_(ids)).all()
            assert {r.status for r in rows} == {"sent"} and all(r.attempts == 1 and r.provider_id for r in rows)
            # manual send of an already-sent message does nothing
            S.send_one(db, rows[0], Slow())
            assert len([c for c in calls if c.startswith("jobs-test")]) == 4

            # a message claimed long ago (server died mid-send) → failed with a clear note, never silently resent
            stuck = S.enqueue(db, "09127779999", "jobs-test stuck", "manual")
            fresh = S.enqueue(db, "09127779998", "jobs-test fresh", "manual")
            db.flush()
            stuck.status, stuck.sending_at = "sending", now() - timedelta(minutes=30)
            fresh.status, fresh.sending_at = "sending", now()
            db.commit()
            ids += [stuck.id, fresh.id]
            S.process_queue(db)
            db.commit()
            db.refresh(stuck)
            db.refresh(fresh)
            assert stuck.status == "failed" and "نیمه‌کاره" in stuck.error
            assert fresh.status == "sending"                     # may still be in flight in another process
            assert "jobs-test stuck" not in calls and "jobs-test fresh" not in calls
    finally:
        with SessionLocal() as db:
            db.query(SmsMessage).filter(SmsMessage.id.in_(ids)).delete(synchronize_session=False)
            db.commit()


def test_moadian_invoices_are_submitted_once_under_concurrency(client, admin, cashier, menu, monkeypatch):
    from app.core.db import SessionLocal
    from app.core.utils import now
    from app.modules.moadian import service as S
    from app.modules.moadian.models import TaxInvoice

    cfg = {"enabled": True, "mode": "mock", "auto_send": False, "memory_id": "a11216", "economic_code": "14000000000", "vat_percent": 10,
           "price_includes_vat": True, "default_sstid": "2710000138624", "default_mu": "1627", "min_amount": 0}
    assert client.put("/api/moadian/config", json=cfg, headers=admin).status_code == 200
    o = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702")]}, headers=cashier).json()
    sent: list[str] = []

    class Slow:
        def send(self, invoices):
            sent.extend(p["header"]["taxid"] for p in invoices)
            time.sleep(0.2)
            return [{"taxId": p["header"]["taxid"], "referenceNumber": "R-" + p["header"]["taxid"], "uid": "u"} for p in invoices]
    monkeypatch.setattr(S, "make_client", lambda db: Slow())
    ids: list[int] = []
    try:
        with SessionLocal() as db:
            for i in range(3):
                tid = f"JOBTEST{i:015d}"
                t = TaxInvoice(order_id=o["id"], serial=990000 + i, tax_id=tid, payload={"header": {"taxid": tid}, "body": []}, status="queued")
                db.add(t)
                db.flush()
                ids.append(t.id)
            db.commit()

        def job():
            with SessionLocal() as db:
                S.send_queue(db)
                db.commit()
        _parallel(job, 3)
        assert sorted(x for x in sent if x.startswith("JOBTEST")) == [f"JOBTEST{i:015d}" for i in range(3)], sent
        with SessionLocal() as db:
            rows = db.query(TaxInvoice).filter(TaxInvoice.id.in_(ids)).all()
            assert {r.status for r in rows} == {"sent"} and all(r.attempts == 1 and r.reference for r in rows)
            # interrupted send → re-queued after the stale window (the tax system identifies invoices by taxId)
            rows[0].status, rows[0].sending_at = "sending", now() - timedelta(hours=1)
            db.commit()
            assert S.recover_stale(db) == 1
            db.refresh(rows[0])
            assert rows[0].status == "queued" and rows[0].errors[0]["code"] == "INTERRUPTED"
    finally:
        with SessionLocal() as db:
            db.query(TaxInvoice).filter(TaxInvoice.id.in_(ids)).delete(synchronize_session=False)
            db.commit()
        client.put("/api/moadian/config", json={**cfg, "enabled": False}, headers=admin)
        client.post(f"/api/orders/{o['id']}/cancel", json={"reason": "تست"}, headers=admin)
