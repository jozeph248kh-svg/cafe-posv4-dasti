"""Management reports: discounts, staff, cash reconciliation, menu engineering, tables, kitchen, tax, customers, Z, Excel."""
import io

import pytest
from conftest import _login, close_register, line

from app.core.utils import business_day


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module")
def sold(client, admin, mgr, cashier, chef, menu):
    """One paid dine-in order today with an item discount, a bill discount, a kitchen ticket made ready and a closed shift."""
    close_register(client, admin)
    table = next(t for a in client.get("/api/orders/floor", headers=cashier).json() for t in a["tables"] if t["status"] == "free")
    o = client.post("/api/orders", headers=cashier, json={"type": "dine_in", "table_id": table["id"], "guests": 3, "customer_phone": "09120000999",
                                                          "customer_name": "مشتری گزارش", "lines": [line(menu, "101", 2), line(menu, "104")], "send": True}).json()
    lid = o["lines"][0]["id"]
    client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr, json={"type": "percent", "value": 50, "reason": "تست گزارش آیتم"}).raise_for_status()
    o = client.post(f"/api/orders/{o['id']}/discount", headers={**cashier, "X-Manager-Pin": "2222"},
                    json={"type": "percent", "value": 20, "reason": "تست گزارش فاکتور"}).json()
    for t in client.get("/api/kitchen/tickets", headers=chef).json():
        if t["order_id"] == o["id"]:
            client.post(f"/api/kitchen/tickets/{t['id']}/status", headers=chef, json={"status": "ready"}).raise_for_status()
    client.post("/api/shifts/open", json={"opening_cash": 0}, headers=cashier).raise_for_status()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": [{"method": "cash", "amount": o["total"]}]}).json()
    assert o["status"] == "closed"
    client.post("/api/shifts/close", headers=admin, json={"counted_cash": o["total"] - 5_000, "note": "کسری تست"}).raise_for_status()
    return o


def _get(client, h, section, **params):
    day = business_day().isoformat()
    r = client.get(f"/api/reports/insights/{section}", headers=h, params={"date_from": day, "date_to": day, **params})
    assert r.status_code == 200, r.text
    return r.json()


def test_discount_report(client, admin, sold):
    d = _get(client, admin, "discounts")
    reasons = {r["reason"]: r for r in d["by_reason"]}
    assert "تست گزارش آیتم" in reasons and "تست گزارش فاکتور" in reasons
    row = next(o for o in d["orders"] if o["id"] == sold["id"])
    assert row["discount"] == sold["discount_amount"] and row["items_discount"] == sold["line_discount_amount"]
    assert row["by"] == "رضا کریمی" and row["approver"] == "سارا احمدی"
    assert d["summary"]["total"] >= sold["discount_amount"] and d["summary"]["health"] in ("ok", "warn", "high")
    assert any(a["user"] == "سارا احمدی" for a in d["by_approver"])


def test_staff_shift_and_tax_reports(client, admin, sold):
    staff = _get(client, admin, "staff")["rows"]
    reza = next(r for r in staff if r["name"] == "رضا کریمی")
    assert reza["orders"] >= 1 and reza["discounts"] > 0 and reza["avg_check"] > 0
    sh = _get(client, admin, "shifts")
    assert sh["available"] and any(r["difference"] == -5_000 and r["note"] and "کسری تست" in r["note"] for r in sh["rows"])
    assert sh["summary"]["short"] >= 5_000
    tax = _get(client, admin, "tax")
    assert tax["totals"]["discounts"] >= sold["discount_amount"]
    assert tax["totals"]["net_sales"] == tax["totals"]["gross"] - tax["totals"]["discounts"]


def test_menu_engineering_and_modifiers(client, admin, sold):
    m = _get(client, admin, "menu")
    assert m["rows"] and {r["class"] for r in m["rows"]} <= {"star", "plowhorse", "puzzle", "dog"}
    assert abs(m["popularity_threshold"] - 70 / len(m["rows"])) < 0.01
    assert sum(c["count"] for c in m["classes"]) == len(m["rows"])
    assert all(r["id"] not in {x["id"] for x in m["rows"]} for r in m["unsold"])
    assert "rows" in _get(client, admin, "modifiers")


def test_tables_kitchen_customers(client, admin, sold):
    t = _get(client, admin, "tables")
    tbl = next(r for r in t["rows"] if r["orders"])
    assert t["summary"]["guests"] >= 3 and tbl["per_guest"] > 0
    k = _get(client, admin, "kitchen")
    assert k["available"] and k["summary"]["count"] >= 1 and k["by_station"]
    c = _get(client, admin, "customers")
    assert any(x["phone"] == "09120000999" for x in c["top"]) and c["summary"]["customers"] >= 1


def test_compare_z_and_excel(client, admin, sold):
    from openpyxl import load_workbook
    cmp = _get(client, admin, "compare")
    assert cmp["current"]["orders"] >= 1 and "previous" in cmp
    z = client.get("/api/reports/insights/z", headers=admin).json()
    assert z["summary"]["orders"] >= 1 and z["discounts"]["total"] >= sold["discount_amount"] and z["by_payment"]
    day = business_day().isoformat()
    r = client.get("/api/reports/insights/export", headers=admin, params={"date_from": day, "date_to": day})
    assert r.status_code == 200
    wb = load_workbook(io.BytesIO(r.content))
    assert {"تخفیف‌ها", "عملکرد پرسنل", "مغایرت صندوق", "مهندسی منو", "دفتر مالیات"} <= set(wb.sheetnames)


def test_insights_permissions_and_unknown_section(client, admin, waiter):
    assert client.get("/api/reports/insights/discounts", headers=waiter).status_code == 403
    assert client.get("/api/reports/insights/nope", headers=admin).status_code == 404
