"""Concurrency against a REAL server process (uvicorn + SQLite file), like several POS devices on the LAN.

Each scenario fires simultaneous requests from threads and checks the invariants that matter for money:
no double payment, no overpayment, unique order numbers, one open order per table.
"""
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import httpx
import pytest

BACKEND = Path(__file__).resolve().parents[1]
N = 8


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def server():
    data = tempfile.mkdtemp(prefix="cafe-conc-")
    port = _free_port()
    env = {**os.environ, "CAFE_DATA_DIR": data, "CAFE_DEMO_DATA": "false", "CAFE_SAMPLE_USERS": "true",
           "CAFE_BACKGROUND_JOBS": "false", "CAFE_FORCE_PASSWORD_CHANGE": "false", "CAFE_PORT": str(port),
           "CAFE_LOGIN_MAX_FAILURES": "1000"}
    proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(port),
                             "--log-level", "warning"], cwd=os.environ.get("CAFE_BACKEND_DIR", BACKEND), env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    base = f"http://127.0.0.1:{port}"
    for _ in range(100):
        try:
            if httpx.get(base + "/api/health", timeout=1).status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.2)
    else:
        proc.kill()
        raise RuntimeError(proc.stderr.read().decode()[-2000:])
    yield base
    proc.terminate()
    proc.wait(10)


def _auth(base, u="reza", p="cashier123"):
    t = httpx.post(base + "/api/staff/auth/login", json={"username": u, "password": p}).json()["token"]
    return {"Authorization": f"Bearer {t}"}


def _simple_item(base, h):
    full = httpx.get(base + "/api/menu/full", headers=h).json()
    groups = {g["id"]: g for g in full["modifier_groups"]}
    return next(i for i in full["items"] if i["is_active"] and i["is_available"] and not (i["code"] or "").startswith("__")
                and all(groups[g]["min_select"] == 0 for g in i["modifier_group_ids"]))


def _blast(fn, n=N):
    """Run fn(i) in n threads released at the same instant; return results."""
    gate, out = threading.Barrier(n), [None] * n

    def run(i):
        gate.wait()
        out[i] = fn(i)
    ts = [threading.Thread(target=run, args=(i,)) for i in range(n)]
    for t in ts:
        t.start()
    for t in ts:
        t.join(60)
    return out


def _order(base, h, item, qty=2):
    r = httpx.post(base + "/api/orders", headers=h, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": qty}]})
    assert r.status_code == 201, r.text
    return r.json()


def test_parallel_full_payment_is_taken_once(server):
    h = _auth(server)
    httpx.post(server + "/api/shifts/open", headers=h, json={"opening_cash": 0})
    item = _simple_item(server, h)
    o = _order(server, h, item)
    codes = _blast(lambda i: httpx.post(f"{server}/api/orders/{o['id']}/payments", headers=h, timeout=60,
                                        json={"payments": [{"method": "card", "amount": o["total"]}]}).status_code)
    final = httpx.get(f"{server}/api/orders/{o['id']}", headers=h).json()
    assert codes.count(200) == 1, codes
    assert all(c in (200, 400) for c in codes), codes
    assert final["status"] == "closed"
    assert final["paid_amount"] == final["total"]
    assert len([p for p in final["payments"] if not p["is_refund"]]) == 1


def test_parallel_partial_payments_never_exceed_total(server):
    h = _auth(server)
    item = _simple_item(server, h)
    o = _order(server, h, item, qty=4)
    half = o["total"] // 2
    _blast(lambda i: httpx.post(f"{server}/api/orders/{o['id']}/payments", headers=h, timeout=60,
                                json={"payments": [{"method": "card", "amount": half}]}).status_code)
    final = httpx.get(f"{server}/api/orders/{o['id']}", headers=h).json()
    assert final["paid_amount"] <= final["total"], final
    assert sum(p["amount"] for p in final["payments"]) == final["paid_amount"]


def test_parallel_order_numbers_are_unique(server):
    h = _auth(server)
    item = _simple_item(server, h)
    res = _blast(lambda i: httpx.post(server + "/api/orders", headers=h, timeout=60,
                                      json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 1}]}))
    assert all(r.status_code == 201 for r in res), [r.text for r in res if r.status_code != 201]
    nums = [r.json()["number"] for r in res]
    assert len(set(nums)) == len(nums), nums


def test_parallel_same_table_gets_one_open_order(server):
    h = _auth(server)
    item = _simple_item(server, h)
    floor = httpx.get(server + "/api/orders/floor", headers=h).json()
    table = next(t for a in floor for t in a["tables"] if t["status"] == "free")
    res = _blast(lambda i: httpx.post(server + "/api/orders", headers=h, timeout=60,
                                      json={"type": "dine_in", "table_id": table["id"], "lines": [{"menu_item_id": item["id"], "qty": 1}]}))
    assert [r.status_code for r in res].count(201) == 1, [r.status_code for r in res]
    # free the table again (on a PostgreSQL run this server shares the database with the other test files)
    created = next(r.json() for r in res if r.status_code == 201)
    r = httpx.post(f"{server}/api/orders/{created['id']}/cancel", headers=_auth(server, "admin", "admin123"),
                   json={"reason": "پایان تست هم‌زمانی"}, timeout=60)
    assert r.status_code == 200, r.text


def test_idempotent_payment_retry(server):
    h = _auth(server)
    item = _simple_item(server, h)
    o = _order(server, h, item, qty=4)
    body = {"payments": [{"method": "card", "amount": o["total"] // 4}], "request_id": "retry-test-0001"}
    codes = _blast(lambda i: httpx.post(f"{server}/api/orders/{o['id']}/payments", headers=h, json=body, timeout=60).status_code, 4)
    final = httpx.get(f"{server}/api/orders/{o['id']}", headers=h).json()
    assert codes == [200] * 4
    assert final["paid_amount"] == o["total"] // 4          # applied exactly once
