"""Round-4: the cost of returned goods is booked on the day the goods came back.

Owner's policy (fixed, not configurable):
  * a sale keeps the cost of its own day forever — a later return must not rewrite a closed day;
  * the material cost of what really came back is subtracted from COGS **on the date of the return event**;
  * a money refund alone is not a return: no restock → no COGS change;
  * only what physically went back on the shelf (and is written to the stock ledger) counts;
  * a partial return is proportional to the returned quantity, at the historical frozen cost.
"""
import pytest
from conftest import _login, close_register, line


def bd():
    """Today **as the app counts it**: between midnight and the day cutoff (default 05:00) the business day is
    still yesterday. Using date.today() here made these tests fail for anyone running the suite after midnight —
    the app books the sale on 2026-10-24 while the test looks at 2026-10-25. Not a product bug: a test bug."""
    from app.core.utils import business_day

    return business_day()


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    from app.core import settings_store
    from app.core.db import SessionLocal

    with SessionLocal() as db:
        keys = [k for k in settings_store.DEFAULTS if k.startswith(("tax.", "service.", "rounding."))]
        old = {k: settings_store.get(db, k) for k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    with SessionLocal() as db:
        settings_store.set_many(db, old)
        db.commit()
    close_register(client, admin)


# ---------------------------------------------------------------- helpers
def _ing(client, admin, name, cost, stock=5_000.0):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": stock, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    it = r.json()
    client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
               json=[{"ingredient_id": i, "qty": q} for i, q in recipe]).raise_for_status()
    return it


def _sell(client, cashier, item, qty=1):
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": qty}]})
    assert o.status_code == 201, o.text
    o = o.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _pnl_day(client, admin, day):
    r = client.get("/api/expenses/pnl", headers=admin,
                   params={"date_from": day.isoformat(), "date_to": day.isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _move_to_yesterday(order_id, also_events=True):
    """Pretend the sale (and, if asked, its return events) happened yesterday — the closed-day scenario."""
    from datetime import datetime, timedelta

    from app.core.db import SessionLocal
    from app.modules.orders.models import Order, OrderRefundLine, Payment

    from sqlalchemy import func as _f

    yday = bd() - timedelta(days=1)
    when = datetime.combine(yday, datetime.min.time()) + timedelta(hours=20)
    with SessionLocal() as db:
        o = db.get(Order, order_id)
        o.business_date = yday
        o.number = int(db.query(_f.max(Order.number)).filter(Order.business_date == yday).scalar() or 0) + 1
        o.closed_at = when
        for p in db.query(Payment).filter(Payment.order_id == order_id):
            p.created_at = when
        if also_events:
            for ev in db.query(OrderRefundLine).filter(OrderRefundLine.order_id == order_id):
                ev.created_at = when
        db.commit()
    return yday


def _refund(client, mgr, order, amount, restock=None, request_id=None):
    body = {"method": "cash", "amount": amount, "reason": "مرجوعی تست"}
    if restock:
        body["restock"] = restock
    if request_id:
        body["request_id"] = request_id
    return client.post(f"/api/orders/{order['id']}/refund", headers=mgr, json=body)


# ================================================================ 1) sale day / return day
def test_a_later_return_does_not_touch_the_sale_day_and_lands_on_the_return_day(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه سیاست روز", 10)
    item = _item(client, admin, "قهوه سیاست روز", 150_000, [(ing["id"], 2)])       # 20 per unit
    o = _sell(client, cashier, item, 1)
    yday = _move_to_yesterday(o["id"])                       # the sale happened yesterday
    from datetime import date
    today = bd()

    day1, day2 = _pnl_day(client, admin, yday)["cogs"], _pnl_day(client, admin, today)["cogs"]

    r = _refund(client, mgr, o, o["total"], restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert r.status_code == 200, r.text

    assert _pnl_day(client, admin, yday)["cogs"] == day1, "روز فروش نباید تغییر کند"
    assert _pnl_day(client, admin, today)["cogs"] - day2 == -20, "بهای مرجوعی باید در روز وقوع منفی ثبت شود"


# ================================================================ 2) partial returns on two days
def test_two_partial_returns_on_two_days_are_booked_on_their_own_days(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه مرجوعی دو روزه", 30)
    item = _item(client, admin, "قهوه مرجوعی دو روزه", 150_000, [(ing["id"], 3)])   # 90 per unit
    o = _sell(client, cashier, item, 4)                                             # COGS 360
    yday = _move_to_yesterday(o["id"])
    from datetime import date
    today = bd()
    day1, day2 = _pnl_day(client, admin, yday)["cogs"], _pnl_day(client, admin, today)["cogs"]

    r1 = _refund(client, mgr, o, 100_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert r1.status_code == 200, r1.text
    assert _pnl_day(client, admin, today)["cogs"] - day2 == -90
    assert _pnl_day(client, admin, yday)["cogs"] == day1

    r2 = _refund(client, mgr, o, 100_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 2}])
    assert r2.status_code == 200, r2.text
    assert _pnl_day(client, admin, today)["cogs"] - day2 == -270          # 90 + 180
    assert _pnl_day(client, admin, yday)["cogs"] == day1
    # the ledger keeps the two events apart
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine
    with SessionLocal() as db:
        evs = db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).order_by(OrderRefundLine.id).all()
        assert [(e.qty, round(e.unit_cost, 2)) for e in evs] == [(1.0, 90.0), (2.0, 90.0)]


# ================================================================ 3) money back, goods stay
def test_a_refund_without_restock_changes_no_cogs_on_any_day(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه بدون برگشت", 50)
    item = _item(client, admin, "قهوه بدون برگشت", 150_000, [(ing["id"], 2)])       # 100
    o = _sell(client, cashier, item, 1)
    yday = _move_to_yesterday(o["id"])
    from datetime import date
    today = bd()
    day1, day2 = _pnl_day(client, admin, yday)["cogs"], _pnl_day(client, admin, today)["cogs"]
    r = _refund(client, mgr, o, o["total"])                    # money only
    assert r.status_code == 200, r.text
    assert _pnl_day(client, admin, yday)["cogs"] == day1
    assert _pnl_day(client, admin, today)["cogs"] == day2
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine
    with SessionLocal() as db:
        assert db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).count() == 0


# ================================================================ 4) goods back, no money
def test_goods_can_come_back_without_money_and_still_hit_the_return_day(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه فقط کالا", 25)
    item = _item(client, admin, "قهوه فقط کالا", 120_000, [(ing["id"], 4)])         # 100
    o = _sell(client, cashier, item, 1)
    yday = _move_to_yesterday(o["id"])
    from datetime import date
    today = bd()
    day1, day2 = _pnl_day(client, admin, yday)["cogs"], _pnl_day(client, admin, today)["cogs"]
    r = _refund(client, mgr, o, 0, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])
    assert r.status_code == 200, r.text
    assert _pnl_day(client, admin, yday)["cogs"] == day1
    assert _pnl_day(client, admin, today)["cogs"] - day2 == -100
    # no fake money was recorded
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderRefundLine, Payment
    with SessionLocal() as db:
        assert db.query(Payment).filter(Payment.order_id == o["id"], Payment.is_refund.is_(True)).count() == 0
        ev = db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).one()
        assert ev.kind == "stock" and ev.refund_payment_id is None and ev.unit_cost == 100


# ================================================================ 5) never more than what was sold
def test_more_than_the_sold_quantity_is_refused(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه سقف", 10)
    item = _item(client, admin, "قهوه سقف", 100_000, [(ing["id"], 1)])
    o = _sell(client, cashier, item, 3)
    lid = o["lines"][0]["id"]
    assert _refund(client, mgr, o, 10_000, restock=[{"line_id": lid, "qty": 2}]).status_code == 200
    r = _refund(client, mgr, o, 10_000, restock=[{"line_id": lid, "qty": 2}])       # 4 of 3
    assert r.status_code == 400                                                     # more than sold
    r = _refund(client, mgr, o, 10_000, restock=[{"line_id": lid, "qty": 1}, {"line_id": lid, "qty": 1}])
    assert r.status_code == 400 and r.json()["detail"]["code"] == "duplicate_line"


# ================================================================ 6) replay is idempotent
def test_replaying_the_same_request_books_nothing_twice(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.inventory.models import Ingredient, StockMovement
    from app.modules.orders.models import OrderRefundLine

    ing = _ing(client, admin, "دانه تکرار", 20, stock=1_000)
    item = _item(client, admin, "قهوه تکرار", 100_000, [(ing["id"], 1)])
    o = _sell(client, cashier, item, 2)
    lid = o["lines"][0]["id"]
    with SessionLocal() as db:
        stock_before = db.get(Ingredient, ing["id"]).stock
    rid = "refundretry01"
    r1 = _refund(client, mgr, o, 50_000, restock=[{"line_id": lid, "qty": 1}], request_id=rid)
    r2 = _refund(client, mgr, o, 50_000, restock=[{"line_id": lid, "qty": 1}], request_id=rid)
    assert r1.status_code == 200 and r2.status_code == 200
    with SessionLocal() as db:
        assert db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).count() == 1
        stock_after = db.get(Ingredient, ing["id"]).stock
        returns = db.query(StockMovement).filter(StockMovement.kind == "return",
                                                 StockMovement.ref_id == o["id"]).count()
        from app.modules.orders.models import Order
        assert db.get(Order, o["id"]).lines[0].returned_qty == 1        # not 2
    assert stock_after == stock_before + 1                     # the shelf got one unit, not two
    assert returns == 1


# ================================================================ 7) series adds up
def test_the_daily_series_adds_up_to_the_range_total_after_returns(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه جمع", 40)
    item = _item(client, admin, "قهوه جمع", 130_000, [(ing["id"], 5)])              # 200
    o1 = _sell(client, cashier, item, 2)
    _sell(client, cashier, item, 1)
    _refund(client, mgr, o1, 100_000, restock=[{"line_id": o1["lines"][0]["id"], "qty": 1}])
    p = client.get("/api/expenses/pnl", headers=admin).json()
    assert sum(d["cogs"] for d in p["series"]) == p["cogs"]
    assert sum(d["profit"] for d in p["series"]) == p["net_profit"]


# ================================================================ 8) every report agrees
def test_api_dashboard_items_and_excel_agree_after_a_return(client, admin, cashier, mgr):
    import io

    from openpyxl import load_workbook

    ing = _ing(client, admin, "دانه گزارش", 60)
    item = _item(client, admin, "قهوه گزارش", 140_000, [(ing["id"], 2)])           # 120 per unit
    before = client.get("/api/reports/sales", headers=admin).json()                # baseline before the sale
    row0 = next((i for i in before["by_item"] if i["id"] == item["id"]), {"cost": 0})
    o = _sell(client, cashier, item, 3)                                            # 360
    _refund(client, mgr, o, 100_000, restock=[{"line_id": o["lines"][0]["id"], "qty": 1}])   # −120

    rep = client.get("/api/reports/sales", headers=admin).json()
    row = next(i for i in rep["by_item"] if i["id"] == item["id"])
    dash = client.get("/api/reports/dashboard", headers=admin).json()
    assert row["cost"] - row0["cost"] == 240, (row["cost"], row0["cost"])   # 3 × 120 − 1 × 120
    # the dashboard's total material cost for today must be the same number the report gives for today
    assert dash["today"]["food_cost"] == rep["summary"]["food_cost"], \
        (dash["today"]["food_cost"], rep["summary"]["food_cost"])
    # …and when this item is inside the dashboard's top-8 slice, its own row has to match too
    top = next((i for i in dash["top_items"] if i["id"] == item["id"]), None)
    if top is not None:
        assert top["cost"] == row["cost"]
    x = client.get("/api/reports/sales/export", headers=admin)
    wb = load_workbook(io.BytesIO(x.content))
    ws = wb["آیتم‌ها"]
    header = [c.value for c in ws[1]]
    xl = next(r for r in ws.iter_rows(min_row=2, values_only=True) if r[0] == item["name"])
    assert xl[header.index("بهای تمام‌شده (تومان)")] == row["cost"]
    assert xl[header.index("سود (تومان)")] == row["profit"]


# ================================================================ 9) legacy rows stay apart
def test_a_legacy_return_without_details_is_flagged_and_stays_on_its_own_day(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine, OrderRefundLine

    ing = _ing(client, admin, "دانه قدیمی مرجوعی", 15)
    item = _item(client, admin, "قهوه قدیمی مرجوعی", 100_000, [(ing["id"], 2)])     # 30
    o = _sell(client, cashier, item, 2)                                            # 60
    with SessionLocal() as db:                     # an old database: returned_qty > 0 but no event row at all
        ln = db.query(OrderLine).filter(OrderLine.order_id == o["id"]).one()
        ln.returned_qty = 1
        db.commit()
        assert db.query(OrderRefundLine).filter(OrderRefundLine.order_id == o["id"]).count() == 0
    from datetime import date
    today = bd()
    # the legacy return is subtracted on the sale day (the only date it has) and reported as legacy
    assert _pnl_day(client, admin, today)["cogs"] >= 30
    from app.modules.inventory.costing import legacy_return_facts
    with SessionLocal() as db:
        legacy = legacy_return_facts(db, today, today)
    mine = [r for r in legacy if r["order_id"] == o["id"]]
    assert mine and mine[0]["source"] == "legacy" and mine[0]["amount"] == -30


# ================================================================ 10 + 11) earlier rounds still hold
def test_multi_partial_refund_tax_still_reverses_exactly(client, admin, cashier, mgr):
    client.put("/api/system/settings", headers=admin, json={"tax.enabled": True, "tax.percent": 10,
                                                           "service.enabled": False})
    ing = _ing(client, admin, "دانه مالیات دور۴", 1)
    item = _item(client, admin, "قهوه مالیات دور۴", 100_000, [(ing["id"], 1)])
    tax_before = client.get("/api/expenses/pnl", headers=admin).json()["sales"]["tax"]
    o = _sell(client, cashier, item, 1)
    assert o["tax_amount"] == 10_000
    for part in (36_667, 36_667, 36_666):
        assert _refund(client, mgr, o, part).status_code == 200
    tax_after = client.get("/api/expenses/pnl", headers=admin).json()["sales"]["tax"]
    assert tax_after == tax_before, (tax_before, tax_after)


def test_mixed_snapshot_null_order_still_costs_correctly(client, admin, cashier):
    from app.core.db import SessionLocal
    from app.modules.orders.models import OrderLine

    a = _ing(client, admin, "دانه ترکیبی ۴", 10)
    b = _ing(client, admin, "دانه ترکیبی ۴ب", 10)
    ia = _item(client, admin, "آیتم ترکیبی ۴", 100_000, [(a["id"], 1)])            # 10
    ib = _item(client, admin, "آیتم ترکیبی ۴ب", 100_000, [(b["id"], 2)])           # 20
    before = client.get("/api/expenses/pnl", headers=admin).json()["cogs"]
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway",
                                                          "lines": [{"menu_item_id": ia["id"], "qty": 1},
                                                                    {"menu_item_id": ib["id"], "qty": 1}]}).json()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]}).json()
    with SessionLocal() as db:
        legacy = db.query(OrderLine).filter(OrderLine.order_id == o["id"], OrderLine.menu_item_id == ib["id"]).one()
        legacy.cost_amount = None
        db.commit()
    after = client.get("/api/expenses/pnl", headers=admin).json()
    assert after["cogs"] - before == 30                       # 10 (snapshot) + 20 (residual), not 40
