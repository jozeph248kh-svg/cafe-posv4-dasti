"""Regression tests for the five issues raised in the external code review.

1. splitting an order that carries a bill-level discount silently dropped (or changed) money
2. a duplicate `line_id` in the split request ended in an internal error
3. a refund never reached the central server in branch mode
4. the customer's `total_spent` (and therefore the loyalty tier) ignored refunds
5. the generated secret key file was created with the process umask (often 0644 → readable by other users)
"""
import os
import stat

import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    """Payments need an open cash register (shift)."""
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _orders(client, h, *ids):
    return [client.get(f"/api/orders/{i}", headers=h).json() for i in ids]


# ---------------------------------------------------------------- 1. split + bill discount
def test_split_keeps_a_percent_bill_discount_on_both_bills(client, cashier, mgr, menu):
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [line(menu, "101", 2), line(menu, "104")]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "percent", "value": 10, "reason": "مشتری دائمی"}).json()
    before_total, before_discount = o["total"], o["discount_amount"]
    moved = next(x for x in o["lines"] if x["qty"] == 2)
    new = client.post(f"/api/orders/{o['id']}/split", headers=mgr, json={"lines": [{"line_id": moved["id"], "qty": 1}]}).json()
    old = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
    try:
        # the moved lines must not lose the bill discount entirely
        assert new["discount_amount"] > 0, "تخفیف کلی فاکتور روی فاکتور جدید اعمال نشد"
        # the two bills together must give the same discount (per-bill rounding may differ by 1 toman)
        assert abs((old["discount_amount"] + new["discount_amount"]) - before_discount) <= 1
        # … and the customer must never pay more than the undivided bill
        assert old["total"] + new["total"] <= before_total + 1
    finally:
        client.post(f"/api/orders/{new['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


def test_split_shares_a_fixed_bill_discount_exactly(client, cashier, mgr, menu):
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [line(menu, "101", 2), line(menu, "104")]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "amount", "value": 30_000, "reason": "تخفیف نقدی"}).json()
    before_total, before_discount = o["total"], o["discount_amount"]
    moved = next(x for x in o["lines"] if x["qty"] == 2)
    new = client.post(f"/api/orders/{o['id']}/split", headers=mgr, json={"lines": [{"line_id": moved["id"], "qty": 1}]}).json()
    old = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
    try:
        assert old["discount_amount"] + new["discount_amount"] == before_discount
        assert old["total"] + new["total"] == before_total
    finally:
        client.post(f"/api/orders/{new['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


def test_split_survives_a_fixed_bill_discount_larger_than_the_remaining_bill(client, cashier, mgr, menu):
    """A fixed discount can be bigger than what stays behind: it must be shared, not clamped onto one bill."""
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [line(menu, "101", 2), line(menu, "104")]}).json()
    o = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "amount", "value": round(o["subtotal"] * 0.85), "reason": "تخفیف ویژه"}).json()
    before_total, before_discount = o["total"], o["discount_amount"]
    moved = next(x for x in o["lines"] if x["qty"] == 2)
    new = client.post(f"/api/orders/{o['id']}/split", headers=mgr, json={"lines": [{"line_id": moved["id"], "qty": 1}]}).json()
    old = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
    try:
        assert old["discount_amount"] + new["discount_amount"] == before_discount
        assert old["total"] + new["total"] == before_total
    finally:
        client.post(f"/api/orders/{new['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


# ---------------------------------------------------------------- 2. duplicate line id
def test_split_with_a_duplicate_line_id_is_a_clean_400(client, cashier, mgr, menu):
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [line(menu, "101", 2), line(menu, "104")]}).json()
    lid = next(x for x in o["lines"] if x["qty"] == 2)["id"]
    r = client.post(f"/api/orders/{o['id']}/split", headers=mgr,
                    json={"lines": [{"line_id": lid, "qty": 2}, {"line_id": lid, "qty": 2}]})
    assert r.status_code == 400, r.text
    assert r.json()["detail"]["code"] == "duplicate_line"
    # nothing was moved: the original order is untouched
    o2 = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
    assert len(o2["lines"]) == len(o["lines"]) and o2["total"] == o["total"]
    client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


# ---------------------------------------------------------------- 3. refund → central server
@pytest.fixture()
def branch_mode(client, admin):
    # `branch.*` settings are owned by the branches module (the generic settings endpoint refuses them)
    cfg = {"mode": "branch", "central_url": "http://central.invalid", "api_key": "br_test_key"}
    client.put("/api/branches/local/config", headers=admin, json=cfg).raise_for_status()
    yield
    client.put("/api/branches/local/config", headers=admin,
               json={"mode": "standalone", "central_url": "", "api_key": ""}).raise_for_status()


def test_refund_is_pushed_to_the_central_server(client, cashier, mgr, admin, menu, branch_mode):
    from app.core.db import SessionLocal
    from app.modules.branches.models import SyncOutbox

    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 2)]}).json()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["total"]}]}).json()
    assert o["status"] == "closed"
    with SessionLocal() as db:                      # the sale was queued for the central server
        sale = db.query(SyncOutbox).filter(SyncOutbox.kind == "sale", SyncOutbox.ref_id == o["id"]).order_by(SyncOutbox.id.desc()).first()
        assert sale and sale.payload["total"] == o["total"] and sale.payload.get("refunds", 0) == 0
        for row in db.query(SyncOutbox).filter(SyncOutbox.status == "pending"):   # pretend the last push succeeded
            row.status = "sent"
        db.commit()

    refund = 100_000
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": refund, "reason": "مرجوعی مشتری"})
    assert r.status_code == 200, r.text
    with SessionLocal() as db:
        row = (db.query(SyncOutbox).filter(SyncOutbox.kind == "sale", SyncOutbox.ref_id == o["id"],
                                           SyncOutbox.status == "pending").order_by(SyncOutbox.id.desc()).first())
        assert row is not None, "بازپرداخت به سرور مرکزی ارسال نشد"
        assert row.payload["refunds"] == refund
        assert row.payload["payments"]["cash"] == o["total"] - refund


@pytest.fixture()
def loopback_branch(client, admin, monkeypatch):
    """A central server in the same app: outgoing branch HTTP is routed straight back into the TestClient."""
    import httpx
    from app.core.db import SessionLocal
    from app.modules.branches.models import SyncOutbox
    with SessionLocal() as db:                       # test isolation: drop sales queued by the earlier tests
        db.query(SyncOutbox).delete()
        db.commit()
    b = client.post("/api/branches", headers=admin, json={"name": "شعبه آزمون", "code": "RV5"}).json()
    key = client.post(f"/api/branches/{b['id']}/rotate-key", headers=admin).json()["api_key"]
    monkeypatch.setattr(httpx, "post", lambda url, headers=None, json=None, timeout=None:
                        client.post(url.replace("http://central", ""), headers=headers, json=json))
    monkeypatch.setattr(httpx, "get", lambda url, headers=None, timeout=None, params=None:
                        client.get(url.replace("http://central", ""), headers=headers))
    client.put("/api/branches/local/config", headers=admin,
               json={"mode": "branch", "central_url": "http://central", "api_key": key}).raise_for_status()
    yield b
    client.put("/api/branches/local/config", headers=admin,
               json={"mode": "standalone", "central_url": "", "api_key": ""}).raise_for_status()


def test_refund_shows_up_in_the_central_report(client, cashier, mgr, admin, menu, loopback_branch):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [line(menu, "101", 2)]}).json()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["total"]}]}).json()
    assert client.post("/api/branches/local/push", headers=admin).status_code == 200
    rep = client.get("/api/branches/report", headers=admin).json()
    row = next(x for x in rep["branches"] if x["name"] == "شعبه آزمون")
    assert row["sales"] == o["total"] and row["refunds"] == 0 and row["net"] == o["total"]

    refund = 90_000
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                       json={"method": "cash", "amount": refund, "reason": "مرجوعی"}).status_code == 200
    assert client.post("/api/branches/local/push", headers=admin).status_code == 200
    rep = client.get("/api/branches/report", headers=admin).json()
    row = next(x for x in rep["branches"] if x["name"] == "شعبه آزمون")
    assert row["orders"] == 1                                        # the refund updated the sale, it did not duplicate it
    assert row["sales"] == o["total"]                                # gross of refunds — same rule as the local report
    assert row["refunds"] == refund and row["net"] == o["total"] - refund
    assert row["payments"]["cash"] == o["total"] - refund
    assert rep["totals"]["refunds"] == sum(x["refunds"] for x in rep["branches"]) >= refund
    assert rep["totals"]["net"] == sum(x["net"] for x in rep["branches"])


# ---------------------------------------------------------------- 4. customer total_spent
def test_customer_total_spent_follows_a_refund(client, cashier, mgr, menu):
    phone = "09121234599"
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "customer_name": "مشتری تستی", "customer_phone": phone,
                          "lines": [line(menu, "101", 2)]}).json()
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["total"]}]}).json()
    cust = next(c for c in client.get("/api/customers", headers=mgr, params={"q": phone}).json() if c["phone"] == phone)
    assert cust["total_spent"] == o["total"]
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json={"method": "cash", "amount": 100_000, "reason": "مرجوعی"})
    assert r.status_code == 200, r.text
    cust = next(c for c in client.get("/api/customers", headers=mgr, params={"q": phone}).json() if c["phone"] == phone)
    assert cust["total_spent"] == o["total"] - 100_000, "خرج‌کرد مشتری پس از بازپرداخت اصلاح نشد"


# ---------------------------------------------------------------- 5. secret key permissions
def test_secret_key_file_is_private(tmp_path):
    from app.core.config import Settings

    s = Settings(data_dir=tmp_path, secret_key=None)
    key = s.jwt_secret()
    p = tmp_path / "secret.key"
    assert p.read_text().strip() == key
    mode = stat.S_IMODE(os.stat(p).st_mode)
    assert mode == 0o600, f"مجوز فایل کلید {oct(mode)} است، باید 0600 باشد"


def test_an_existing_world_readable_secret_key_is_tightened(tmp_path):
    from app.core.config import Settings

    p = tmp_path / "secret.key"
    p.write_text("legacy-key-value")
    os.chmod(p, 0o644)
    s = Settings(data_dir=tmp_path, secret_key=None)
    assert s.jwt_secret() == "legacy-key-value"
    assert stat.S_IMODE(os.stat(p).st_mode) == 0o600


def test_percent_split_never_loses_the_discount_over_many_shapes(client, cashier, mgr, menu):
    """Sweep: whatever is moved and whatever the percent is, the customer never pays more than the undivided bill
    (per-bill rounding may shift a couple of toman; losing the discount entirely is what must never happen)."""
    import random
    rnd = random.Random(4242)
    worst_discount, worst_total = 0, 0
    for _ in range(25):
        pct = rnd.choice([5, 10, 12.5, 15, 20, 33, 50])
        pct = int(pct) if float(pct).is_integer() else pct
        lines = [line(menu, rnd.choice(["101", "104", "301", "401", "501", "601", "701", "801"]), rnd.randint(1, 3))
                 for _ in range(rnd.randint(2, 4))]
        o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": lines})
        if o.status_code != 201:
            continue
        o = o.json()
        r = client.post(f"/api/orders/{o['id']}/discount", headers=mgr, json={"type": "percent", "value": pct, "reason": "آزمون"})
        if r.status_code != 200:
            client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
            continue
        o = r.json()
        before_total, before_discount = o["total"], o["discount_amount"]
        target = rnd.choice(o["lines"])
        qty = rnd.randint(1, target["qty"])
        new = client.post(f"/api/orders/{o['id']}/split", headers=mgr, json={"lines": [{"line_id": target["id"], "qty": qty}]})
        if new.status_code != 200:
            client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
            continue
        new = new.json()
        old = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
        worst_discount = max(worst_discount, abs(old["discount_amount"] + new["discount_amount"] - before_discount))
        worst_total = max(worst_total, old["total"] + new["total"] - before_total)
        client.post(f"/api/orders/{new['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
        client.post(f"/api/orders/{o['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})
    assert worst_discount <= 2, f"تخفیف تا {worst_discount} تومان جابه‌جا شد"
    assert worst_total <= 2, f"مشتری تا {worst_total} تومان بیشتر پرداخت می‌کند"
