"""The dashboard got faster — these tests pin that it still says exactly the same thing.

`dashboard_report()` replaced three full `sales_report()` calls with a handful of GROUP BY queries. The reference
below is the *old* assembly (built from `sales_report`, which still serves /reports/sales), so any drift in a
number — discounts, service, tax, refunds, voids, cancellations, food cost, the hourly/payment/type split, the
14-day strip, the item and category tables, the live counters — fails here.
"""
import pytest
from sqlalchemy import func
from conftest import _login, close_register, line
from datetime import date, timedelta


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def legacy_dashboard(db):
    """The pre-optimisation implementation, verbatim (kept here on purpose as the reference)."""
    from app.core import settings_store
    from app.core.utils import business_day
    from app.modules.kitchen.models import KitchenTicket
    from app.modules.inventory.models import Ingredient
    from app.modules.orders.models import Order
    from app.modules.reports.service import sales_report
    from app.core.utils import now

    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    t = sales_report(db, today, today)
    y = sales_report(db, today - timedelta(days=1), today - timedelta(days=1))
    last14 = sales_report(db, today - timedelta(days=13), today)
    open_orders = db.query(Order).filter(Order.status == "open").all()
    low = []
    try:
        low = [{"id": i.id, "name": i.name, "stock": i.stock, "unit": i.unit, "min_stock": i.min_stock}
               for i in db.query(Ingredient).filter(Ingredient.is_active.is_(True), Ingredient.stock <= Ingredient.min_stock).all()]
    except Exception:
        pass
    kitchen = {}
    try:
        late_min = settings_store.get(db, "kitchen.late_minutes", 15)
        active = db.query(KitchenTicket).filter(KitchenTicket.status.in_(("new", "preparing"))).all()
        kitchen = {"active_tickets": len(active),
                   "late": sum(1 for k in active if (now() - k.created_at).total_seconds() > late_min * 60)}
    except Exception:
        pass
    return {
        "today": t["summary"], "yesterday": y["summary"],
        "by_hour": t["by_hour"], "by_payment": t["by_payment"], "by_type": t["by_type"],
        "top_items": last14["by_item"][:8], "by_category": last14["by_category"], "last14": last14["by_day"],
        "live": {"open_orders": len(open_orders), "open_amount": sum(o.total for o in open_orders),
                 "occupied_tables": len({o.table_id for o in open_orders if o.table_id}),
                 "guests": sum(o.guests for o in open_orders if o.type == "dine_in"), **kitchen},
        "low_stock": low,
    }


def _spread_history(db, order_ids=None):
    """Give **this test's** orders a realistic history: several business days, several hours, all the awkward cases
    the dashboard has to sum (cancelled, merged, void lines, refunds, discounts, tax, service).

    Only the orders created by this test are moved: spreads of orders other test files left behind would shift the
    day of the void/refund cases below and make the comparison depend on test order (test isolation, not app logic).
    """
    from app.core.utils import business_day
    from app.modules.orders.models import Order, OrderLine
    from datetime import datetime, timedelta as td
    today = business_day()          # the app's day, not the calendar day (they differ before the 05:00 cutoff)
    q = db.query(Order)
    if order_ids:
        q = q.filter(Order.id.in_(order_ids))
    rows = q.order_by(Order.id).all()
    # (business_date, number) is unique: when orders move to another day they must be renumbered for that day,
    # otherwise this test collides with orders another test file created (test isolation, not app logic)
    used: dict = {}
    for i, o in enumerate(rows):
        # the first orders (discount + refund, void, cancelled) stay today so today's summary exercises them
        day = today if i < 3 else today - timedelta(days=i % 4)
        if day != o.business_date:
            nxt = used.get(day) or (db.query(func.max(Order.number)).filter(Order.business_date == day).scalar() or 0)
            nxt += 1
            used[day] = nxt
            o.number = nxt
        o.business_date = day
        o.created_at = datetime.combine(day, datetime.min.time()) + td(hours=8 + (i * 3) % 12)
        if o.status == "closed":
            o.closed_at = o.created_at
        for j, ln in enumerate(o.lines):
            ln.created_at = o.created_at
    db.commit()
    return len(rows)


def _build_activity(client, cashier, mgr, menu, db):
    """Closed / cancelled / merged / voided / refunded / discounted orders, on different days and hours."""
    from app.modules.orders.models import Order

    free = [t for a in client.get("/api/orders/floor", headers=cashier).json() for t in a["tables"] if t["status"] == "free"]
    made = []
    for k, code in enumerate(["101", "104", "301", "401", "501", "601"]):
        dine = k % 2 == 0
        body = {"type": "dine_in" if dine else "takeaway", "guests": 1 + k % 3,
                "lines": [line(menu, code, 1 + k % 3), line(menu, "801", 1)]}
        if dine:
            body["table_id"] = free[k // 2]["id"]
        r = client.post("/api/orders", headers=cashier, json=body)
        assert r.status_code == 201, r.text
        made.append(r.json()["id"])
    first = made[0]
    client.post(f"/api/orders/{first}/discount", headers=mgr, json={"type": "percent", "value": 12, "reason": "تست"})
    # a void line
    o = client.get(f"/api/orders/{made[1]}", headers=mgr).json()
    client.post(f"/api/orders/{made[1]}/lines/{o['lines'][0]['id']}/void", headers=mgr, json={"reason": "اشتباه"})
    # a cancelled order and a merged one
    client.post(f"/api/orders/{made[2]}/cancel", headers=mgr, json={"reason": "مشتری رفت"})
    client.post(f"/api/orders/{made[3]}/merge", headers=mgr, json={"target_order_id": made[4]})
    # pay two orders (one with cash + change, one with card) and refund part of the first
    for oid in (made[0], made[4]):
        full = client.get(f"/api/orders/{oid}", headers=mgr).json()
        client.post(f"/api/orders/{oid}/payments", headers=cashier,
                    json={"payments": [{"method": "cash" if oid == made[0] else "card", "amount": full["remaining"],
                                        "tendered": full["remaining"] + 20_000 if oid == made[0] else None}]})
    client.post(f"/api/orders/{made[0]}/refund", headers=mgr, json={"method": "cash", "amount": 30_000, "reason": "مرجوعی"})
    # a second payment method on another closed order
    full = client.get(f"/api/orders/{made[5]}", headers=mgr).json()
    client.post(f"/api/orders/{made[5]}/payments", headers=cashier,
                json={"payments": [{"method": "online", "amount": full["remaining"]}]})
    _spread_history(db, made)
    return made


def test_dashboard_matches_the_old_computation(client, admin, cashier, mgr, menu):
    from app.core.db import SessionLocal
    from app.core.utils import business_day
    from app.modules.reports.service import dashboard_report

    with SessionLocal() as db:
        _build_activity(client, cashier, mgr, menu, db)
    with SessionLocal() as db:
        expected = legacy_dashboard(db)
        db.expire_all()
        got = dashboard_report(db, business_day())

    # the dataset really exercises the awkward cases (otherwise "equal" would prove nothing)
    assert expected["today"]["refunds"] > 0 and expected["today"]["voids"] > 0
    assert expected["today"]["cancelled"] > 0 and expected["today"]["discounts"] > 0
    assert expected["today"]["tax"] > 0 and expected["today"]["food_cost"] > 0
    assert len(expected["top_items"]) == len(got["top_items"]) and len(expected["by_payment"]) >= 2
    # ---- the money summaries, field by field
    assert got["today"] == expected["today"]
    assert got["yesterday"] == expected["yesterday"]
    # ---- the live counters (open orders, tables, guests, kitchen)
    assert got["live"] == expected["live"]
    # ---- the hourly strip: same 24 entries
    assert got["by_hour"] == expected["by_hour"]
    # ---- payment split and type split: same values (list order is canonical now, so compare as maps)
    assert {p["method"]: p["amount"] for p in got["by_payment"]} == {p["method"]: p["amount"] for p in expected["by_payment"]}
    assert {t["type"]: (t["revenue"], t["orders"]) for t in got["by_type"]} == {t["type"]: (t["revenue"], t["orders"]) for t in expected["by_type"]}
    # ---- the 14-day strip
    assert got["last14"] == expected["last14"]
    # ---- item table, categories and the top-8 slice
    assert {i["id"]: i for i in got["top_items"]} == {i["id"]: i for i in expected["top_items"]}
    assert [i["id"] for i in got["top_items"]] == [i["id"] for i in expected["top_items"]]
    assert {c["id"]: (c["qty"], c["revenue"]) for c in got["by_category"]} == {c["id"]: (c["qty"], c["revenue"]) for c in expected["by_category"]}
    assert len(got["low_stock"]) == len(expected["low_stock"])


def test_dashboard_endpoint_serves_the_same_payload(client, admin):
    r = client.get("/api/reports/dashboard", headers=admin)
    assert r.status_code == 200
    body = r.json()
    for key in ("today", "yesterday", "by_hour", "by_payment", "by_type", "top_items", "by_category", "last14", "live", "low_stock"):
        assert key in body, key
    assert len(body["by_hour"]) == 24 and len(body["last14"]) == 14
    # `net_revenue` = net − tax (the P&L definition of net sales revenue); `net` stays the gross takings
    assert set(body["today"]) == {"orders", "gross", "discounts", "service", "tax", "net", "net_revenue", "refunds", "avg_ticket",
                                  "guests", "cancelled", "cancelled_amount", "voids", "voids_amount",
                                  "food_cost", "food_cost_pct",
                                  # legacy-cost transparency (estimated vs unknown)
                                  "food_cost_estimated_lines", "food_cost_unknown_lines", "food_cost_unknown_returns"}


def test_dashboard_on_an_empty_period_does_not_divide_by_zero(client, admin):
    from app.core.db import SessionLocal
    from app.modules.reports.service import dashboard_report

    with SessionLocal() as db:
        got = dashboard_report(db, date(1990, 1, 1))
    assert got["today"]["orders"] == 0 and got["today"]["avg_ticket"] == 0 and got["today"]["food_cost_pct"] == 0
    assert sum(d["revenue"] for d in got["last14"]) == 0
