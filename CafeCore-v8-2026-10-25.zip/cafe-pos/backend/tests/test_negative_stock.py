"""Negative stock: selling is allowed, but the manager gets one visible alert per shortage.

The policy (approved by the owner): the till never blocks a sale because of the store's numbers; instead the
shortage is recorded, announced in real time and listed for the manager.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _ingredient(client, admin, name, stock, unit="g"):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": unit, "category": "تست", "opening_stock": stock, "min_stock": 0,
                          "cost_per_unit": 10})
    assert r.status_code == 201, r.text
    return r.json()


def _menu_item(client, admin, name, price, ingredient_id, qty_per_item):
    cats = client.get("/api/menu/categories", headers=admin).json()
    item = client.post("/api/menu/items", headers=admin,
                       json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True}).json()
    r = client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin,
                   json=[{"ingredient_id": ingredient_id, "qty": qty_per_item}])
    assert r.status_code == 200, r.text
    return item


def _sell(client, cashier, item, qty):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": qty}]})
    assert o.status_code == 201, o.text
    o = o.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["total"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _alerts(client, admin, open_only=True):
    r = client.get("/api/inventory/alerts", headers=admin, params={"open_only": str(open_only).lower()})
    assert r.status_code == 200, r.text
    return r.json()


def _stock(client, admin, iid):
    return next(i for i in client.get("/api/inventory/ingredients", headers=admin).json() if i["id"] == iid)


def test_a_sale_with_enough_stock_creates_no_alert(client, admin, cashier):
    ing = _ingredient(client, admin, "شیر تست کافی", 10_000)
    item = _menu_item(client, admin, "کافه‌لاته تست کافی", 90_000, ing["id"], 100)
    _sell(client, cashier, item, 3)                                    # 300 g of 10,000 g
    assert _stock(client, admin, ing["id"])["stock"] == pytest.approx(9_700)
    assert not [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]


def test_a_sale_beyond_the_stock_is_allowed_and_alerts_once(client, admin, cashier):
    ing = _ingredient(client, admin, "شیر تست کمبود", 500)             # 500 g in stock
    item = _menu_item(client, admin, "کافه‌لاته تست کمبود", 120_000, ing["id"], 100)
    o = _sell(client, cashier, item, 8)                                # needs 800 g → 300 g short
    assert o["status"] == "closed"                                     # the sale was NOT refused

    after = _stock(client, admin, ing["id"])
    assert after["stock"] == pytest.approx(-300)
    alerts = [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]
    assert len(alerts) == 1
    a = alerts[0]
    assert a["name"] == "شیر تست کمبود" and a["unit"] == "g"
    assert a["stock_before"] == pytest.approx(500)                     # stock before the sale
    assert a["stock_after"] == pytest.approx(-300)                     # stock after the sale
    assert a["shortage"] == pytest.approx(300)                         # how much is missing
    assert a["occurrences"] == 1

    # the audit trail has the same event for the manager's log
    log = client.get("/api/system/audit", headers=admin, params={"q": "شیر تست کمبود", "action": "inventory.negative"}).json()
    assert log and log[0]["details"]["shortage"] == pytest.approx(300)


def test_repeating_the_same_shortage_does_not_spam_new_alerts(client, admin, cashier):
    ing = _ingredient(client, admin, "شیر تست تکرار", 300)
    item = _menu_item(client, admin, "کافه‌لاته تست تکرار", 100_000, ing["id"], 100)
    _sell(client, cashier, item, 4)                                    # −100
    first = [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]
    assert len(first) == 1 and first[0]["stock_after"] == pytest.approx(-100)
    # a second sale keeps it negative — same episode, no second alert row
    _sell(client, cashier, item, 2)                                    # −300 total
    second = [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]
    assert len(second) == 1
    assert second[0]["id"] == first[0]["id"]                           # same alert, not a duplicate
    assert second[0]["stock_after"] == pytest.approx(-300)             # …but the worse shortage is recorded
    assert second[0]["shortage"] == pytest.approx(300) and second[0]["occurrences"] == 2


def test_stock_back_to_zero_closes_the_alert_and_a_new_shortage_opens_a_new_one(client, admin, cashier):
    ing = _ingredient(client, admin, "شیر تست بازگشت", 200)
    item = _menu_item(client, admin, "کافه‌لاته تست بازگشت", 100_000, ing["id"], 100)
    _sell(client, cashier, item, 3)                                    # −100
    a1 = [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]
    assert len(a1) == 1 and a1[0]["stock_after"] == pytest.approx(-100)

    # stock is corrected by a purchase → the alert is closed
    client.post(f"/api/inventory/ingredients/{ing['id']}/adjust", headers=admin, json={"kind": "adjust", "qty": 500})
    assert _stock(client, admin, ing["id"])["stock"] == pytest.approx(400)
    assert not [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]

    _sell(client, cashier, item, 6)                                    # −200 → a fresh episode
    a2 = [a for a in _alerts(client, admin) if a["ingredient_id"] == ing["id"]]
    assert len(a2) == 1 and a2[0]["id"] != a1[0]["id"]
    assert a2[0]["shortage"] == pytest.approx(200) and a2[0]["occurrences"] == 1


def test_alerts_are_visible_to_a_manager_and_need_a_permission(client, admin, waiter):
    assert client.get("/api/inventory/alerts", headers=admin).status_code == 200
    assert client.get("/api/inventory/alerts", headers=waiter).status_code == 403
