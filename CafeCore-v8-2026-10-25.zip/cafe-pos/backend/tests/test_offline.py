"""Offline queue replay: order create / add-lines are idempotent by request_id, and a queued dine-in order whose
table got an order meanwhile is merged into it (no duplicate orders, lines or kitchen tickets)."""
from tests.conftest import _login, line


def _free_table(client, h):
    return next(t for a in client.get("/api/orders/floor", headers=h).json() for t in a["tables"] if t["status"] == "free")


def _tickets(oid):
    from app.core.db import SessionLocal
    from app.modules.kitchen.models import KitchenTicket
    with SessionLocal() as db:
        return db.query(KitchenTicket).filter(KitchenTicket.order_id == oid).count()


def _qty(o):
    return sum(l["qty"] for l in o["lines"] if l["status"] != "void")


def test_offline_replay_is_idempotent_and_merges(client, waiter, menu):
    mgr = _login(client, "sara", "manager123")
    made = []
    try:
        t = _free_table(client, waiter)
        body = {"type": "dine_in", "table_id": t["id"], "lines": [line(menu, "101", 2)], "send": True,
                "request_id": "offline-create-0001", "merge_if_busy": True}
        r1 = client.post("/api/orders", headers=waiter, json=body)
        assert r1.status_code == 201, r1.text
        o = r1.json()
        made.append(o["id"])
        assert _qty(o) == 2 and _tickets(o["id"]) == 1
        # the same request again (response was lost / queue replayed) → the same order, nothing added
        r2 = client.post("/api/orders", headers=waiter, json=body)
        assert r2.status_code == 201 and r2.json()["id"] == o["id"] and _qty(r2.json()) == 2
        assert _tickets(o["id"]) == 1
        busy = [tb for ar in client.get("/api/orders/floor", headers=waiter).json() for tb in ar["tables"] if tb["id"] == t["id"]]
        assert busy[0]["status"] != "free"

        # add lines with a request id, twice → added once (identical pending lines would otherwise merge qty)
        add = {"lines": [line(menu, "104", 1)], "send": True, "request_id": "offline-lines-0001"}
        a1 = client.post(f"/api/orders/{o['id']}/lines", headers=waiter, json=add)
        assert a1.status_code == 200 and _qty(a1.json()) == 3 and _tickets(o["id"]) == 2
        a2 = client.post(f"/api/orders/{o['id']}/lines", headers=waiter, json=add)
        assert a2.status_code == 200 and _qty(a2.json()) == 3 and _tickets(o["id"]) == 2

        # a request id can't be reused for another order or another kind of write
        other = client.post("/api/orders", headers=waiter, json={"type": "takeaway", "lines": [line(menu, "101")]}).json()
        made.append(other["id"])
        r = client.post(f"/api/orders/{other['id']}/lines", headers=waiter, json=add)
        assert r.status_code == 409 and r.json()["detail"]["code"] == "duplicate_request"
        r = client.post(f"/api/orders/{other['id']}/lines", headers=waiter, json={**add, "request_id": "offline-create-0001"})
        assert r.status_code == 409

        # another device queued an order for the same table while offline → merged into the open order
        queued = {"type": "dine_in", "table_id": t["id"], "lines": [line(menu, "101", 1)], "send": True,
                  "request_id": "offline-create-0002"}
        r = client.post("/api/orders", headers=waiter, json=queued)      # without merge: the normal busy-table error
        assert r.status_code == 400 and r.json()["detail"]["code"] == "table_busy"
        m = client.post("/api/orders", headers=waiter, json={**queued, "merge_if_busy": True})
        assert m.status_code == 201 and m.json()["id"] == o["id"] and _qty(m.json()) == 4 and _tickets(o["id"]) == 3
        m2 = client.post("/api/orders", headers=waiter, json={**queued, "merge_if_busy": True})
        assert m2.json()["id"] == o["id"] and _qty(m2.json()) == 4 and _tickets(o["id"]) == 3

        # bad request ids are rejected by validation
        r = client.post("/api/orders", headers=waiter, json={**queued, "request_id": "bad id!"})
        assert r.status_code == 422
    finally:
        for oid in made:
            client.post(f"/api/orders/{oid}/cancel", headers=mgr, json={"reason": "پایان تست"})
