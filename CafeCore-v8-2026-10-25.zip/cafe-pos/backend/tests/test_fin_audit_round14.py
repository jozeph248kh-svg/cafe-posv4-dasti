"""Round-14 financial audit — one executable test per reported risk.

Each item below is a claim that arrived with the audit request. The test is written so that it FAILS if the defect is
present in the current version and PASSES if the behaviour is correct. Where a defect was already fixed in an earlier
round, the test is still here: it is the standing guard for that fix (the round is named in the docstring).

Items
  1  item- and bill-level discount are applied in the sales report AND in the profit reports
  2  a refund belonging to a cancelled order must not change revenue or any report
  3  COGS is corrected after the goods physically come back to the store
  4  historical profit uses the cost frozen at sale time, not today's prices
  5  tax is reversed correctly on a full and on partial refunds
  6  no double counting of COGS in orders that carry both legacy (NULL cost) and new (frozen) lines
  7  sales report, P&L, cash drawer, payments and refunds reconcile for the same range
  8  a replayed payment/refund request books the money once (idempotency)
  9  permissions: discount, refund, cash register and QR order data
"""
from datetime import date, timedelta

import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    """A register for this file + restore the pricing settings it touches (the suite shares one database)."""
    keys = ("tax.enabled", "tax.percent", "service.enabled", "service.percent", "rounding.step")
    old = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    client.put("/api/system/settings", headers=admin, json=old)
    close_register(client, admin)


# ---------------------------------------------------------------- helpers
def _ing(client, admin, name, cost, stock=10_000.0):
    r = client.post("/api/inventory/ingredients", headers=admin,
                    json={"name": name, "unit": "g", "opening_stock": stock, "cost_per_unit": cost, "min_stock": 0})
    assert r.status_code == 201, r.text
    return r.json()


def _item(client, admin, name, price, recipe):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    it = r.json()
    rr = client.put(f"/api/inventory/recipes/item/{it['id']}", headers=admin,
                    json=[{"ingredient_id": i, "qty": q} for i, q in recipe])
    assert rr.status_code == 200, rr.text
    return it


def _sell(client, cashier, lines, discount=None):
    body = {"type": "takeaway", "lines": lines}
    if discount:
        body.update(discount)
    o = client.post("/api/orders", headers=cashier, json=body)
    assert o.status_code == 201, o.text
    o = o.json()
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [] if o["total"] == 0 else [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _pnl(client, admin, d1, d2=None):
    r = client.get("/api/expenses/pnl", headers=admin,
                   params={"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _sales(client, admin, d1, d2=None):
    r = client.get("/api/reports/sales", headers=admin,
                   params={"date_from": d1.isoformat(), "date_to": (d2 or d1).isoformat()})
    assert r.status_code == 200, r.text
    return r.json()


def _today():
    """Today as the app counts it (cutoff-aware) — date.today() breaks every «today» assertion after midnight."""
    from app.core.utils import business_day
    return business_day()


def _refund(client, who, order, amount, restock=None, request_id=None):
    body = {"method": "cash", "amount": amount, "reason": "ممیزی مالی"}
    if restock:
        body["restock"] = restock
    if request_id:
        body["request_id"] = request_id
    return client.post(f"/api/orders/{order['id']}/refund", headers=who, json=body)


# ═══════════════════════════════════════════════════════ 1) discounts in sales + profit
def test_1_item_and_bill_discount_reach_both_the_sales_report_and_the_profit_reports(client, admin, cashier, mgr):
    """Fixed in an earlier round (`item_net_facts`); this is the standing guard, now covering both reports."""
    ing = _ing(client, admin, "دانه تخفیف ممیزی", 100)                     # 10 g × 100 = 1000 cost per unit
    item = _item(client, admin, "قهوه تخفیف ممیزی", 100_000, [(ing["id"], 10)])
    today = _today()
    before_pnl, before_sales = _pnl(client, admin, today), _sales(client, admin, today)["summary"]

    # one bill, 2 × 100 000, with BOTH an item discount (20 000) and a bill discount (30 000)
    o = client.post("/api/orders", headers=cashier,
                    json={"type": "takeaway", "lines": [{"menu_item_id": item["id"], "qty": 2}]}).json()
    lid = o["lines"][0]["id"]
    r = client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr,
                    json={"type": "amount", "value": 20_000, "reason": "تخفیف آیتم ممیزی"})
    assert r.status_code == 200, r.text
    r = client.post(f"/api/orders/{o['id']}/discount", headers=mgr,
                    json={"type": "amount", "value": 30_000, "reason": "تخفیف فاکتور ممیزی"})
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["discount_amount"] == 50_000 and o["line_discount_amount"] == 20_000, o
    o = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]}).json()

    after_sales = _sales(client, admin, today)["summary"]
    after_pnl = _pnl(client, admin, today)
    net_added = o["total"] - o["tax_amount"]
    assert after_pnl["revenue"] - before_pnl["revenue"] == net_added
    assert after_sales["net_revenue"] - before_sales["net_revenue"] == net_added
    assert after_sales["discounts"] - before_sales["discounts"] == 50_000

    # per-item profit uses the money actually charged (list − item discount − share of the bill discount)
    row = next(r for r in _sales(client, admin, today)["by_item"] if r["id"] == item["id"])
    charged = o["subtotal"] - o["discount_amount"]
    assert row["revenue"] == charged, (row["revenue"], charged)
    assert row["profit"] == charged - row["cost"]
    assert row["discount"] == 50_000


# ═══════════════════════════════════════════════════════ 2) refund of a cancelled order
def test_2_a_refund_that_belongs_to_a_cancelled_order_never_touches_revenue(client, admin, cashier, mgr):
    """A cancelled bill was never revenue; a refund row hanging off it must not subtract anything.

    The live API refuses refunds on non-closed bills (asserted below). The dangerous case is legacy/imported data:
    a bill that was closed, refunded, and later marked cancelled. Reports must ignore such a refund instead of
    turning the day's revenue negative or under-reporting it.
    """
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order

    ing = _ing(client, admin, "دانه لغو ممیزی", 50)
    item = _item(client, admin, "قهوه لغو ممیزی", 60_000, [(ing["id"], 4)])
    today = _today()
    baseline = _pnl(client, admin, today)          # before this bill existed
    baseline_sales = _sales(client, admin, today)["summary"]
    order = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])

    # a cancelled bill can never be refunded through the API
    with SessionLocal() as db:
        db.get(Order, order["id"]).status = "cancelled"
        db.commit()
    denied = _refund(client, mgr, order, 10_000)
    assert denied.status_code in (400, 409), denied.text
    with SessionLocal() as db:                                   # put it back and refund it for real
        db.get(Order, order["id"]).status = "closed"
        db.commit()

    before = _pnl(client, admin, today)
    r = _refund(client, mgr, order, order["paid_amount"])
    assert r.status_code == 200, r.text
    refunded = _pnl(client, admin, today)
    assert refunded["revenue"] == before["revenue"] - (order["total"] - order["tax_amount"])

    # now the legacy situation: same bill, refunded, then marked cancelled
    with SessionLocal() as db:
        db.get(Order, order["id"]).status = "cancelled"
        db.commit()
    after_cancel = _pnl(client, admin, today)
    assert after_cancel["revenue"] == baseline["revenue"], (
        f"a cancelled bill is neither revenue nor a refund: expected {baseline['revenue']}, "
        f"got {after_cancel['revenue']}")
    assert after_cancel["sales"]["refunds"] == baseline["sales"]["refunds"]
    assert after_cancel["sales"]["tax"] == baseline["sales"]["tax"]
    sales = _sales(client, admin, today)["summary"]
    assert sales["refunds"] == baseline_sales["refunds"]
    assert sales["net"] == baseline_sales["net"]
    assert sales["net_revenue"] == baseline_sales["net_revenue"]
    # the dashboard and the tax ledger read the same numbers (no «-60,000» anywhere)
    dash = client.get("/api/reports/dashboard", headers=admin).json()
    assert dash["today"]["net"] >= 0


# ═══════════════════════════════════════════════════════ 3) COGS after a physical return
def test_3_cogs_is_reduced_by_goods_that_come_back_to_the_store(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه برگشت ممیزی", 200)                      # 5 g × 200 = 1000/unit
    item = _item(client, admin, "قهوه برگشت ممیزی", 80_000, [(ing["id"], 5)])
    today = _today()
    order = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 3}])   # COGS 3000
    with_return = _pnl(client, admin, today)

    r = _refund(client, mgr, order, 0, restock=[{"line_id": order["lines"][0]["id"], "qty": 2}])
    assert r.status_code == 200, r.text
    after = _pnl(client, admin, today)
    assert after["cogs"] - with_return["cogs"] == -2000, after["cogs"] - with_return["cogs"]

    # the goods are really on the shelf again: the movements show a `return` row with the returned quantity
    moves = client.get("/api/inventory/movements", headers=admin,
                       params={"ingredient_id": ing["id"], "limit": 200}).json()
    returns = [m for m in moves if m["kind"] == "return" and m["ref_id"] == order["id"]]
    assert returns, [m["kind"] for m in moves]
    assert sum(m["qty"] for m in returns) == 5 * 2, returns       # 2 units × 5 g


# ═══════════════════════════════════════════════════════ 4) historical profit
def test_4_past_profit_uses_the_cost_frozen_at_sale_time_not_today_prices(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تاریخی ممیزی", 100)
    item = _item(client, admin, "قهوه تاریخی ممیزی", 50_000, [(ing["id"], 10)])   # cost 1000
    today = _today()
    _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 2}])             # COGS 2000
    before = _pnl(client, admin, today)

    # a new purchase at double the price must not rewrite the cost of the sale that already happened
    client.post("/api/inventory/purchases", headers=admin,
                json={"purchase_date": today.isoformat(),
                      "lines": [{"ingredient_id": ing["id"], "qty": 1000, "unit_cost": 200}]}).raise_for_status()
    after = _pnl(client, admin, today)
    assert after["cogs"] == before["cogs"], (before["cogs"], after["cogs"])
    assert after["gross_profit"] == before["gross_profit"]
    # …while the «what would it cost today» indicator does move
    assert after["replacement_cost"] > before["replacement_cost"]


# ═══════════════════════════════════════════════════════ 5) tax on refunds
def test_5_tax_is_reversed_correctly_on_a_full_refund_and_across_partial_ones(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه مالیات ممیزی", 10)
    item = _item(client, admin, "قهوه مالیات ممیزی", 111_000, [(ing["id"], 1)])
    today = _today()

    # full refund: the whole VAT of the bill comes back, revenue returns exactly to where it was before the sale
    baseline = _pnl(client, admin, today)
    a = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])
    sold = _pnl(client, admin, today)
    assert sold["revenue"] - baseline["revenue"] == a["total"] - a["tax_amount"]
    assert _refund(client, mgr, a, a["paid_amount"]).status_code == 200
    gone = _pnl(client, admin, today)
    assert gone["revenue"] == baseline["revenue"], (gone["revenue"], baseline["revenue"])
    assert gone["sales"]["tax"] == baseline["sales"]["tax"]
    assert gone["sales"]["refunds"] - baseline["sales"]["refunds"] == a["paid_amount"]   # the money did go back

    # three partial refunds of one bill: the parts must add up to the bill's VAT exactly (no rounding drift)
    before_b = _pnl(client, admin, today)                    # before the second bill existed
    b = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 3}])
    before_partials = _pnl(client, admin, today)
    third = b["paid_amount"] // 3
    for amount in (third, third, b["paid_amount"] - 2 * third):
        assert _refund(client, mgr, b, amount).status_code == 200
    final = _pnl(client, admin, today)
    assert final["revenue"] == before_b["revenue"]
    assert final["sales"]["tax"] == before_b["sales"]["tax"], (before_b["sales"]["tax"], final["sales"]["tax"])
    assert final["sales"]["refunds"] - before_b["sales"]["refunds"] == b["paid_amount"]


# ═══════════════════════════════════════════════════════ 6) legacy + new COGS data
def test_6_an_order_with_legacy_and_frozen_lines_does_not_double_count_cogs(client, admin, cashier, mgr):
    """Fixed in round 3 (`_allocate_legacy`); the guard stays: the sale movement is counted once."""
    from app.core.db import SessionLocal
    from app.modules.inventory.costing import cogs_by_day
    from app.modules.orders.models import OrderLine

    ing = _ing(client, admin, "دانه مختلط ممیزی", 100)
    item = _item(client, admin, "قهوه مختلط ممیزی", 40_000, [(ing["id"], 3)])    # 300 per unit
    today = _today()
    order = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 2}])      # COGS 600
    before = _pnl(client, admin, today)["cogs"]

    # simulate an upgraded database: one line keeps the frozen cost, the other lost it (NULL)
    with SessionLocal() as db:
        lines = db.query(OrderLine).filter(OrderLine.order_id == order["id"]).all()
        assert len(lines) >= 1
        lines[0].cost_amount = None
        db.commit()

    after = _pnl(client, admin, today)["cogs"]
    assert after == before, f"the same goods must cost the same with or without the frozen column ({before} → {after})"
    with SessionLocal() as db:
        total = sum(cogs_by_day(db, today, today).values())
    assert total >= after - 0.01


# ═══════════════════════════════════════════════════════ 7) reconciliation
def test_7_sales_pnl_cash_drawer_payments_and_refunds_reconcile(client, admin, cashier, mgr):
    """Every screen must tell the same story — measured as *deltas*, so the test is independent of other bills."""
    ing = _ing(client, admin, "دانه تطبیق ممیزی", 30)
    item = _item(client, admin, "قهوه تطبیق ممیزی", 90_000, [(ing["id"], 2)])
    today = _today()
    params = {"date_from": today.isoformat(), "date_to": today.isoformat()}

    def snapshot():
        pnl = _pnl(client, admin, today)
        return {
            "sales": _sales(client, admin, today)["summary"],
            "pnl": {"revenue": pnl["revenue"], "sales": pnl["sales"]},       # only the money figures this test uses
            "ledger": client.get("/api/reports/insights/tax", headers=mgr, params=params).json()["totals"],
            "shift": client.get("/api/shifts/current", headers=mgr).json(),
        }

    before = snapshot()
    a = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 2}])
    b = _sell(client, cashier, [{"menu_item_id": item["id"], "qty": 1}])
    assert _refund(client, mgr, b, 20_000).status_code == 200
    after = snapshot()

    def d(section, key, sub=None):
        get = (lambda snap, k: (snap[section][sub][k] if sub else snap[section][k]))
        return get(after, key) - get(before, key)
    taken = a["paid_amount"] + b["paid_amount"]
    refunded = 20_000

    # 1) takings: the two reports agree, and nothing is lost between the bills and the report
    assert d("sales", "net") == a["total"] + b["total"]
    assert d("pnl", "revenue") + d("pnl", "tax", "sales") + d("pnl", "refunds", "sales") == d("sales", "net")

    # 2) refunds are reported once, in both places, and the cash drawer agrees with the money that moved
    assert d("sales", "refunds") == refunded
    assert d("pnl", "refunds", "sales") == refunded
    assert d("ledger", "refunds") == refunded
    assert d("shift", "expected_cash") == taken - refunded

    # 3) the billing view (sales) vs. the net revenue (P&L): the difference is exactly the revenue part of the refund
    before_sales, after_sales = before["sales"], after["sales"]
    assert after_sales["net_revenue"] - before_sales["net_revenue"] == (a["total"] - a["tax_amount"]) + (b["total"] - b["tax_amount"])
    reversed_tax = d("sales", "tax") - d("pnl", "tax", "sales")
    assert reversed_tax == round(refunded * b["tax_amount"] / b["total"])
    assert d("pnl", "revenue") == (a["total"] - a["tax_amount"]) + (b["total"] - b["tax_amount"]) - (refunded - reversed_tax)

    # 4) the payments ledger (per payment method) matches what was received
    by_payment = {row["method"]: row["amount"] for row in _sales(client, admin, today)["by_payment"]}
    assert by_payment.get("cash", 0) >= taken - refunded


# ═══════════════════════════════════════════════════════ 8) idempotency
def test_8_a_replayed_payment_or_refund_request_books_the_money_once(client, admin, cashier, mgr):
    ing = _ing(client, admin, "دانه تکرار ممیزی", 20)
    item = _item(client, admin, "قهوه تکرار ممیزی", 70_000, [(ing["id"], 1)])
    today = _today()

    # a payment submission retried after a dropped connection carries the same request_id
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway",
                                                          "lines": [{"menu_item_id": item["id"], "qty": 1}]}).json()
    rid = "audit-dup-payment-1"
    body = {"payments": [{"method": "cash", "amount": o["total"]}], "request_id": rid}
    first = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json=body)
    assert first.status_code == 200, first.text
    pnl_once = _pnl(client, admin, today)
    replay = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json=body)
    assert replay.status_code in (200, 409), replay.text
    assert replay.json().get("paid_amount") == first.json().get("paid_amount"), replay.text
    assert _pnl(client, admin, today) == pnl_once

    # the same refund submission twice
    rid2 = "audit-dup-refund-1"
    r1 = _refund(client, mgr, first.json(), 15_000, request_id=rid2)
    assert r1.status_code == 200, r1.text
    snapshot = _pnl(client, admin, today)
    r2 = _refund(client, mgr, first.json(), 15_000, request_id=rid2)
    assert r2.status_code == 200, r2.text
    assert _pnl(client, admin, today) == snapshot, "a replayed refund must not move money a second time"


# ═══════════════════════════════════════════════════════ 9) permissions
def test_9_permissions_guard_discount_refund_register_and_qr_order_data(client, admin, cashier, waiter, chef):
    """A waiter may take orders but must not discount, refund, open/close the register or read the QR endpoints."""
    ing = _ing(client, admin, "دانه مجوز ممیزی", 10)
    item = _item(client, admin, "قهوه مجوز ممیزی", 30_000, [(ing["id"], 1)])
    o = client.post("/api/orders", headers=waiter, json={"type": "takeaway",
                                                         "lines": [{"menu_item_id": item["id"], "qty": 1}]})
    assert o.status_code == 201, o.text
    o = o.json()

    # discount on the bill
    r = client.post(f"/api/orders/{o['id']}/discount", headers=waiter,
                    json={"discount_type": "amount", "discount_value": 1_000, "discount_reason": "ممیزی"})
    assert r.status_code in (400, 403), r.text

    # the register is a manager's business
    assert client.post("/api/shifts/close", headers=waiter, json={"counted_cash": 0}).status_code in (400, 403)
    assert client.post("/api/shifts/open", headers=waiter, json={"opening_cash": 0}).status_code in (400, 403)

    # money leaves the till only with the refund permission
    client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                json={"payments": [{"method": "cash", "amount": o["total"]}]}).raise_for_status()
    assert _refund(client, waiter, o, 5_000).status_code in (400, 403)
    assert _refund(client, chef, o, 5_000).status_code in (400, 403)

    # QR / guest endpoints are public but never expose the staff order book
    for path in ("/api/orders", "/api/orders/active", "/api/public/calls", "/api/reports/sales"):
        assert client.get(path).status_code in (401, 403), path


# ═══════════════════════════════════════════════════════ 2b) the same rule on the central-branch path
def test_2b_the_branch_sync_payload_never_sends_refunds_for_a_cancelled_bill():
    """The shop's own report ignores such a refund; the payload pushed to the central server must agree."""
    from types import SimpleNamespace

    from app.modules.branches.service import sale_payload

    def fake(status, refunds, total=99_000):
        pay = [SimpleNamespace(method="cash", amount=total, is_refund=False)]
        if refunds:
            pay.append(SimpleNamespace(method="cash", amount=-refunds, is_refund=True))
        return SimpleNamespace(id=1, number=1, business_date=date(2026, 10, 25), type="takeaway", source="pos",
                               status=status, subtotal=total, discount_amount=0, total=total, guests=1,
                               payments=pay, closed_at=None, cancelled_at=None, active_lines=[])

    assert sale_payload(fake("closed", 20_000))["refunds"] == 20_000
    payload = sale_payload(fake("cancelled", 20_000))
    assert payload["total"] == 0 and payload["refunds"] == 0, payload
