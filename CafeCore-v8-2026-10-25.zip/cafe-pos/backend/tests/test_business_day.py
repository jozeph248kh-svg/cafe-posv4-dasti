"""`day.cutoff_hour` (default 05:00) decides which business day a moment belongs to: at 01:00 the
café is still on last night's day. Orders and the sales reports have always honoured the setting;
two reports did not and quietly used a hard-coded 05:00 — the branch snapshot (what the central
dashboard shows as "today") and the marketplace settlement report. For a shop that closes at 03:00
but sets the cutoff to 08:00, those two screens disagreed with the rest of the app by one day.
"""
from datetime import date, datetime

from app.core import settings_store
from app.core.db import SessionLocal
from app.core.utils import business_day


def _freeze(monkeypatch, when: datetime):
    monkeypatch.setattr("app.core.utils.now", lambda: when)          # business_day() reads this
    for mod in ("app.modules.branches.service", "app.modules.marketplace.router"):
        monkeypatch.setattr(f"{mod}.now", lambda: when, raising=False)


def _set_cutoff(db, value: int) -> int:
    old = settings_store.get(db, "day.cutoff_hour", 5)
    settings_store.set_many(db, {"day.cutoff_hour": value})
    db.commit()
    return old


def test_branch_snapshot_counts_the_configured_business_day(client, monkeypatch):
    # `client` starts the app (and creates the schema); the test itself works on the same database
    from app.modules.branches.service import snapshot
    from app.modules.orders.models import Order

    when = datetime(2026, 5, 1, 6, 0, 0)        # 06:00 — belongs to 30 April when the cutoff is 08:00
    _freeze(monkeypatch, when)
    with SessionLocal() as db:
        old = _set_cutoff(db, 8)
        before = snapshot(db)["today_sales"]
        order = Order(number=9901, business_date=business_day(when, 8), type="takeaway", status="closed",
                      guests=1, subtotal=1000, total=1000, paid_amount=1000, created_at=when, closed_at=when,
                      source="pos")
        db.add(order)
        db.commit()
        try:
            assert business_day(when, 8) == date(2026, 4, 30)
            assert snapshot(db)["today_sales"] - before == 1000
        finally:
            db.delete(order)
            _set_cutoff(db, old)


def test_marketplace_report_defaults_to_the_configured_business_day(client, monkeypatch):
    from app.modules.marketplace.router import report

    when = datetime(2026, 5, 1, 6, 0, 0)
    _freeze(monkeypatch, when)
    with SessionLocal() as db:
        old = _set_cutoff(db, 8)
        try:
            out = report(date_from=None, date_to=None, db=db)      # default window: the last 30 business days
            assert out["to"] == date(2026, 4, 30)
            assert out["from"] == date(2026, 4, 1)
        finally:
            _set_cutoff(db, old)
