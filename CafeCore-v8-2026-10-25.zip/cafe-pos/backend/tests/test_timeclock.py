"""Time clock: PIN punches, double-tap guard, manual corrections, wages and the labour-vs-sales report."""
from datetime import datetime, timedelta

import pytest

from app.core import ratelimit
from app.modules.timeclock import service as S


@pytest.fixture(autouse=True)
def _limits():
    ratelimit.reset()
    yield
    ratelimit.reset()


def _shift_clock(monkeypatch, hours):
    real = datetime.now()
    monkeypatch.setattr(S, "now", lambda: real + timedelta(hours=hours))


def test_pin_punch_toggles_and_refuses_double_tap(client, admin, chef, monkeypatch):
    assert client.post("/api/timeclock/punch", json={"pin": "0000"}).status_code == 401
    assert client.post("/api/timeclock/punch", json={"pin": "12ab"}).status_code == 422
    r = client.post("/api/timeclock/punch", json={"pin": "6666"})
    assert r.status_code == 200 and r.json()["action"] == "in", r.text
    r = client.post("/api/timeclock/punch", json={"pin": "6666"})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "punch_too_soon"        # accidental second tap
    now_ = [e for e in client.get("/api/timeclock/now", headers=admin).json() if e["source"] == "pin"]
    assert len(now_) >= 1
    _shift_clock(monkeypatch, 2)
    r = client.post("/api/timeclock/punch", json={"pin": "6666"})                       # shift.report_required (default)
    assert r.status_code == 409 and r.json()["detail"]["code"] == "shift_report_required", r.text
    assert client.post("/api/shifts/my-report", json={"note": "پایان شیفت"}, headers=chef).status_code == 201
    r = client.post("/api/timeclock/punch", json={"pin": "6666"})
    assert r.status_code == 200 and r.json()["action"] == "out" and 119 <= r.json()["minutes"] <= 121


def test_self_punch_from_the_header(client, cashier, monkeypatch):
    assert client.get("/api/timeclock/me", headers=cashier).json()["on_clock"] is False
    r = client.post("/api/timeclock/me/punch", headers=cashier)
    assert r.status_code == 200 and r.json()["action"] == "in" and r.json()["on_clock"] is True
    _shift_clock(monkeypatch, 1)
    r = client.post("/api/timeclock/me/punch", headers=cashier)
    assert r.status_code == 409 and r.json()["detail"]["code"] == "shift_report_required"
    assert client.get("/api/timeclock/me", headers=cashier).json()["on_clock"] is True             # still on the clock
    assert client.post("/api/shifts/my-report", json={}, headers=cashier).status_code == 201
    r = client.post("/api/timeclock/me/punch", headers=cashier)
    assert r.json()["action"] == "out" and r.json()["on_clock"] is False
    assert client.get("/api/timeclock/entries", headers=cashier).status_code == 403          # managing needs timeclock.manage


def test_manual_entries_wages_and_labor_report(client, admin):
    users = client.get("/api/timeclock/wages", headers=admin).json()
    chef = next(u for u in users if u["name"] and u["user_id"] and u["name"] != "مدیر سیستم")
    day = (datetime.now() - timedelta(days=40)).replace(hour=10, minute=0, second=0, microsecond=0)
    body = {"user_id": chef["user_id"], "clock_in": day.isoformat(), "clock_out": (day + timedelta(hours=4)).isoformat(), "note": "فراموشی"}
    r = client.post("/api/timeclock/entries", headers=admin, json=body)
    assert r.status_code == 201 and r.json()["minutes"] == 240 and r.json()["source"] == "manual", r.text
    eid = r.json()["id"]
    over = {**body, "clock_in": (day + timedelta(hours=3)).isoformat(), "clock_out": (day + timedelta(hours=5)).isoformat()}
    assert client.post("/api/timeclock/entries", headers=admin, json=over).status_code == 400            # overlaps
    bad = {**body, "clock_out": (day - timedelta(hours=1)).isoformat()}
    assert client.post("/api/timeclock/entries", headers=admin, json=bad).status_code == 400             # out before in
    future = {**body, "clock_in": (datetime.now() + timedelta(days=1)).isoformat(), "clock_out": None}
    assert client.post("/api/timeclock/entries", headers=admin, json=future).status_code == 400
    assert client.put("/api/timeclock/wages", headers=admin, json={"user_id": chef["user_id"], "hourly_wage": 100_000}).status_code == 200
    d = day.date().isoformat()
    rep = client.get("/api/timeclock/labor", headers=admin, params={"date_from": d, "date_to": d}).json()
    row = next(s for s in rep["staff"] if s["user_id"] == chef["user_id"])
    assert row["hours"] == 4 and row["cost"] == 400_000
    t = rep["totals"]
    assert t["cost"] >= 400_000
    if t["sales"]:
        assert t["labor_pct"] == round(t["cost"] * 100 / t["sales"], 1) and t["splh"] == round(t["sales"] / t["hours"])
    # edit → recomputed and audited; delete
    r = client.put(f"/api/timeclock/entries/{eid}", headers=admin, json={**body, "clock_out": (day + timedelta(hours=6)).isoformat()})
    assert r.status_code == 200 and r.json()["minutes"] == 360
    logs = client.get("/api/system/audit", headers=admin, params={"q": "اصلاح حضور"}).json()
    assert any("اصلاح حضور" in x["summary"] for x in logs)
    assert client.delete(f"/api/timeclock/entries/{eid}", headers=admin).status_code == 204
    rep = client.get("/api/timeclock/labor", headers=admin, params={"date_from": d, "date_to": d}).json()
    assert not any(s["user_id"] == chef["user_id"] and s["hours"] >= 4 for s in rep["staff"])


def test_monthly_salary_and_insurance_in_labor_cost(client, admin):
    """Monthly salary = fixed cost per calendar day (÷30), worked or not; employer insurance share added for insured staff."""
    users = [u for u in client.get("/api/timeclock/wages", headers=admin).json() if u["name"] != "مدیر سیستم"]
    sal, hr = users[0], users[1]
    cfg = client.get("/api/timeclock/config", headers=admin).json()
    assert cfg["insurance_pct"] == 23
    day = (datetime.now() - timedelta(days=70)).replace(hour=10, minute=0, second=0, microsecond=0)
    eids = []
    try:
        assert client.put("/api/timeclock/config", headers=admin, json={"insurance_pct": 20}).status_code == 200
        assert client.put("/api/timeclock/config", headers=admin, json={"insurance_pct": 80}).status_code == 422
        r = client.put("/api/timeclock/wages", headers=admin, json={"user_id": sal["user_id"], "hourly_wage": 0, "pay_type": "monthly", "monthly_salary": 0})
        assert r.status_code == 422 and r.json()["detail"]["code"] == "salary_required"
        r = client.put("/api/timeclock/wages", headers=admin, json={"user_id": sal["user_id"], "hourly_wage": 0, "pay_type": "monthly",
                                                                  "monthly_salary": 3_000_000, "insured": True})
        assert r.status_code == 200 and r.json()["pay_type"] == "monthly"
        assert client.put("/api/timeclock/wages", headers=admin, json={"user_id": hr["user_id"], "hourly_wage": 50_000, "pay_type": "hourly",
                                                                      "insured": True}).status_code == 200
        for uid in (sal["user_id"], hr["user_id"]):
            r = client.post("/api/timeclock/entries", headers=admin, json={"user_id": uid, "clock_in": day.isoformat(),
                                                                           "clock_out": (day + timedelta(hours=2)).isoformat()})
            assert r.status_code == 201, r.text
            eids.append(r.json()["id"])
        d1, d3 = day.date().isoformat(), (day.date() + timedelta(days=2)).isoformat()
        rep = client.get("/api/timeclock/labor", headers=admin, params={"date_from": d1, "date_to": d3}).json()
        rows = {s["user_id"]: s for s in rep["staff"]}
        assert rows[sal["user_id"]]["cost"] == 360_000 and rows[sal["user_id"]]["hours"] == 2        # 3 days × 100,000 × 1.2
        assert rows[hr["user_id"]]["cost"] == 120_000                                                  # 2 h × 50,000 × 1.2
        assert rep["totals"]["insurance_pct"] == 20 and sal["name"] not in rep["totals"]["no_wage"]
        assert len(rep["days"]) == 3                       # salary days count even without any clocked hours
        logs = client.get("/api/system/audit", headers=admin, params={"q": "حقوق ماهانه"}).json()
        assert any("3,000,000" in x["summary"] for x in logs)
        # the old client format (hourly_wage only) keeps the other fields
        assert client.put("/api/timeclock/wages", headers=admin, json={"user_id": sal["user_id"], "hourly_wage": 0}).json()["pay_type"] == "monthly"
    finally:
        for eid in eids:
            client.delete(f"/api/timeclock/entries/{eid}", headers=admin)
        for u in (sal, hr):
            client.put("/api/timeclock/wages", headers=admin, json={"user_id": u["user_id"], "hourly_wage": u["hourly_wage"], "pay_type": u["pay_type"],
                                                                   "monthly_salary": u["monthly_salary"], "insured": u["insured"]})
        client.put("/api/timeclock/config", headers=admin, json={"insurance_pct": cfg["insurance_pct"]})


def test_request_datetimes_are_local_and_sane(client, admin):
    """Found by qa/fuzz.py: a Unix number or an ISO string with an offset became a tz-aware datetime and crashed (500)
    when compared with the stored local times. Now: absurd dates → 422; offsets → converted to server local time."""
    users = client.get("/api/timeclock/wages", headers=admin).json()
    uid = next(u["user_id"] for u in users if u["user_id"] and u["name"] != "مدیر سیستم")
    for bad in (1.5, -1, "1970-01-01T00:00:00"):
        r = client.post("/api/timeclock/entries", headers=admin, json={"user_id": uid, "clock_in": bad, "clock_out": None})
        assert r.status_code == 422, (bad, r.text)
    local = (datetime.now() - timedelta(days=50)).replace(hour=9, minute=0, second=0, microsecond=0)
    aware = local.astimezone()                                     # same instant, with the server's UTC offset
    body = {"user_id": uid, "clock_in": aware.isoformat(), "clock_out": (aware + timedelta(hours=2)).isoformat()}
    r = client.post("/api/timeclock/entries", headers=admin, json=body)
    assert r.status_code == 201 and r.json()["minutes"] == 120, r.text
    assert r.json()["clock_in"].startswith(local.isoformat()[:16])
    assert client.delete(f"/api/timeclock/entries/{r.json()['id']}", headers=admin).status_code == 204
    r = client.get("/api/reservations/availability", headers=admin, params={"start_at": "1970-01-01T10:00:00"})
    assert r.status_code == 422
