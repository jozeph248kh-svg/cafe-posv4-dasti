"""Profit per item must match the money that was really taken.

The per-item table (reports → «آیتم‌ها و سودآوری», the Excel sheet «آیتم‌ها», and the menu-engineering
report) counted every sold line at its **list price** and only subtracted per-line discounts. A whole-bill
discount — including the 100 % «مهمان مدیر» comp — never reached it, so a comped item showed a healthy
profit on a sale that brought in nothing (and a 50 % bill discount inflated every item's profit).

These tests pin the money view: revenue per item is what the customer paid for those items after the item's
own discount *and* its share of the bill discount, allocated in proportion to the line amounts (the same rule
the split feature uses). The sums must add up to the report's own gross − discounts.
"""
import pytest
from conftest import _login, close_register, line


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _order(client, cashier, lines):
    o = client.post("/api/orders", headers=cashier, json={"type": "takeaway", "lines": lines})
    assert o.status_code == 201, o.text
    return o.json()


def _bill_discount(client, mgr, oid, value, typ="percent"):
    r = client.post(f"/api/orders/{oid}/discount", headers=mgr, json={"type": typ, "value": value, "reason": "تست سود"})
    assert r.status_code == 200, r.text
    return r.json()


def _pay(client, cashier, o):
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier, json={"payments": []} if o["total"] == 0 else
                    {"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


def _items(client, admin, **params):
    r = client.get("/api/reports/sales", headers=admin, params=params or {})
    assert r.status_code == 200, r.text
    return r.json()


def _snap(client, admin):
    """The report right now. Tests assert on differences, because every test in this file shares one database."""
    rep = _items(client, admin)
    per_item = {i["id"]: dict(i) for i in rep["by_item"]}
    return {"rep": rep, "items": per_item, "summary": dict(rep["summary"])}


def _delta(before, after, item_id, field):
    return after["items"].get(item_id, {}).get(field, 0) - before["items"].get(item_id, {}).get(field, 0)


def _close_prices(menu, code):
    """list price of one unit of `code` with its default modifiers (what the sale is worth)."""
    item = menu["items"][code]
    extra = 0
    for gid in item["modifier_group_ids"]:
        g = menu["groups"][gid]
        if g["min_select"] >= 1:
            opt = next((o for o in g["options"] if o["is_default"]), g["options"][0])
            extra += opt.get("price_delta") or 0
    return item["price"] + extra


# ---------------------------------------------------------------- the reported case: a 100 % comp
def test_a_comped_item_shows_zero_revenue_and_a_loss(client, cashier, mgr, admin, menu):
    iid = menu["items"]["101"]["id"]
    before = _snap(client, admin)
    o = _order(client, cashier, [line(menu, "101", 2)])
    o = _bill_discount(client, mgr, o["id"], 100)
    _pay(client, cashier, o)
    after = _snap(client, admin)
    assert _delta(before, after, iid, "qty") == 2
    assert _delta(before, after, iid, "revenue") == 0, after["items"].get(iid)   # nothing was paid for these two
    cost = _delta(before, after, iid, "cost")
    assert cost > 0 and _delta(before, after, iid, "profit") == -cost            # the cost stayed: a loss


def test_a_half_bill_discount_halves_the_item_revenue(client, cashier, mgr, admin, menu):
    iid = menu["items"]["601"]["id"]
    unit = _close_prices(menu, "601")
    before = _snap(client, admin)
    o = _order(client, cashier, [line(menu, "601", 2)])
    gross = o["subtotal"]
    o = _bill_discount(client, mgr, o["id"], 50)
    _pay(client, cashier, o)
    after = _snap(client, admin)
    assert gross == unit * 2
    assert _delta(before, after, iid, "revenue") == pytest.approx(gross / 2, abs=1)
    assert _delta(before, after, iid, "profit") == pytest.approx(gross / 2 - _delta(before, after, iid, "cost"), abs=1)


def test_the_item_table_adds_up_to_gross_minus_discounts(client, cashier, mgr, admin, menu):
    """The per-item revenues must reconcile with the report's own summary (the money view, not list prices)."""
    before = _snap(client, admin)
    o1 = _order(client, cashier, [line(menu, "101", 2), line(menu, "104", 1)])
    o1 = _bill_discount(client, mgr, o1["id"], 30)
    _pay(client, cashier, o1)
    o2 = _order(client, cashier, [line(menu, "301", 1)])
    _pay(client, cashier, o2)
    after = _snap(client, admin)
    items_total = sum(after["items"].get(k, {}).get("revenue", 0) for k in after["items"]) - \
                  sum(before["items"].get(k, {}).get("revenue", 0) for k in before["items"])
    money = (after["summary"]["gross"] - after["summary"]["discounts"]) - \
            (before["summary"]["gross"] - before["summary"]["discounts"])
    assert items_total == pytest.approx(money, abs=3), (items_total, money)


def test_the_bill_discount_is_shared_between_the_items_of_one_bill(client, cashier, mgr, admin, menu):
    """Two items of different value in the same bill: the whole-bill discount follows their share."""
    ia, ib = menu["items"]["101"]["id"], menu["items"]["801"]["id"]
    unit_a, unit_b = _close_prices(menu, "101"), _close_prices(menu, "801")
    before = _snap(client, admin)
    o = _order(client, cashier, [line(menu, "101", 1), line(menu, "801", 1)])   # espresso (cheap) + a dish
    o = _bill_discount(client, mgr, o["id"], 50)
    _pay(client, cashier, o)
    after = _snap(client, admin)
    ra, rb = _delta(before, after, ia, "revenue"), _delta(before, after, ib, "revenue")
    assert ra + rb == pytest.approx((unit_a + unit_b) / 2, abs=2)
    assert 0 < ra < rb                                                    # cheaper item carries the smaller share
    assert ra == pytest.approx(unit_a / 2, abs=1)


def test_an_item_discount_and_a_bill_discount_stack_correctly(client, cashier, mgr, admin, menu):
    iid = menu["items"]["601"]["id"]
    before = _snap(client, admin)
    o = _order(client, cashier, [line(menu, "601", 2)])
    lid = o["lines"][0]["id"]
    client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=mgr,
                json={"type": "percent", "value": 10, "reason": "آیتم"}).raise_for_status()
    o = client.get(f"/api/orders/{o['id']}", headers=mgr).json()
    after_item = o["subtotal"] - o["line_discount_amount"]
    o = _bill_discount(client, mgr, o["id"], 50)
    _pay(client, cashier, o)
    after = _snap(client, admin)
    assert _delta(before, after, iid, "revenue") == pytest.approx(after_item * 0.5, abs=1)


def test_a_plain_sale_without_discount_is_unchanged(client, cashier, admin, menu):
    """Regression guard: with no discount at all the numbers are exactly what they always were."""
    iid = menu["items"]["104"]["id"]
    before = _snap(client, admin)
    o = _order(client, cashier, [line(menu, "104", 2)])
    _pay(client, cashier, o)
    after = _snap(client, admin)
    assert _delta(before, after, iid, "revenue") == o["subtotal"] == _close_prices(menu, "104") * 2
    assert _delta(before, after, iid, "profit") == _delta(before, after, iid, "revenue") - _delta(before, after, iid, "cost")


# ---------------------------------------------------------------- menu engineering (the profit tab)
def test_menu_engineering_uses_the_paid_price(client, cashier, mgr, admin, menu):
    # an item that no earlier test in this file sold, so its per-unit averages are exactly this comp
    iid = menu["items"]["201"]["id"]
    o = _order(client, cashier, [line(menu, "201", 3)])
    o = _bill_discount(client, mgr, o["id"], 100)
    _pay(client, cashier, o)
    r = client.get("/api/reports/insights/menu", headers=admin)
    assert r.status_code == 200, r.text
    row = next(x for x in r.json()["rows"] if x["id"] == iid)
    assert row["qty"] == 3
    assert row["revenue"] == 0                                                 # charged nothing for them
    assert row["cm"] == -row["unit_cost"]                                      # the margin per unit is the loss
    assert row["total_cm"] == -row["unit_cost"] * 3
    assert row["discount"] == pytest.approx(_close_prices(menu, "201") * 3, abs=1)


# ---------------------------------------------------------------- the dashboard must agree with the report
def test_dashboard_top_items_matches_the_sales_report(client, cashier, mgr, admin, menu):
    o = _order(client, cashier, [line(menu, "101", 2), line(menu, "801", 1)])
    o = _bill_discount(client, mgr, o["id"], 40)
    _pay(client, cashier, o)
    from datetime import timedelta
    from app.core.db import SessionLocal
    from app.core.utils import business_day
    with SessionLocal() as db:
        from app.core import settings_store
        today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    # the dashboard's item table covers the last 14 business days — compare against the same range
    rep = _items(client, admin, date_from=(today - timedelta(days=13)).isoformat(), date_to=today.isoformat())
    dash = client.get("/api/reports/dashboard", headers=admin).json()
    assert dash["top_items"], "the dashboard has no items to compare"
    for row in dash["top_items"]:
        same = next(i for i in rep["by_item"] if i["id"] == row["id"])
        assert row["revenue"] == same["revenue"] and row["profit"] == same["profit"], (row, same)
