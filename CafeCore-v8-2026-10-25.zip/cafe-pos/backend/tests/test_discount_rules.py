"""Discount engine: automatic presets, buy-X-get-Y, combo, promo codes (POS + online), daily/monthly ceilings,
server-side reason requirement, and the unique (business_date, number) safeguard."""
import pytest
from conftest import _login, line

from app.core import ratelimit


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture()
def presets(client, admin):
    """Create presets inside a test; all are deleted afterwards (the test DB is shared)."""
    made = []

    def mk(**kw):
        r = client.post("/api/orders/discounts/presets", headers=admin, json={"name": kw.pop("name", "تست"), **kw})
        assert r.status_code == 201, r.text
        made.append(r.json()["id"])
        return r.json()
    yield mk
    for pid in made:
        client.delete(f"/api/orders/discounts/presets/{pid}", headers=admin)


@pytest.fixture()
def orders(client, cashier, mgr):
    made = []

    def mk(*lines, **kw):
        r = client.post("/api/orders", headers=cashier, json={"type": kw.pop("type", "takeaway"), "lines": list(lines), **kw})
        assert r.status_code == 201, r.text
        made.append(r.json()["id"])
        return r.json()
    yield mk
    for oid in made:
        client.post(f"/api/orders/{oid}/cancel", headers=mgr, json={"reason": "پایان تست"})


def _get(client, admin, oid):
    return client.get(f"/api/orders/{oid}", headers=admin).json()


def _item(menu, code):
    return menu["items"][code]


def _unit(client, admin, oid, code, menu):
    """Unit price (base + default modifiers) of the line with this item in the order."""
    o = _get(client, admin, oid)
    return next(l["unit_price"] for l in o["lines"] if l["menu_item_id"] == _item(menu, code)["id"])


# ------------------------------------------------------------------ reason (server-side)
def test_custom_discount_needs_a_reason_unless_turned_off(client, admin, cashier, orders, menu):
    o = orders(line(menu, "101"))
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"type": "percent", "value": 5})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "reason_required"
    client.put("/api/system/settings", headers=admin, json={"discount.reason_required": False}).raise_for_status()
    try:
        assert client.get("/api/orders/discounts/my-limit", headers=cashier).json()["reason_required"] is False
        r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"type": "percent", "value": 5})
        assert r.status_code == 200 and r.json()["discount_amount"] > 0
    finally:
        client.put("/api/system/settings", headers=admin, json={"discount.reason_required": True}).raise_for_status()


# ------------------------------------------------------------------ automatic presets
def test_auto_item_preset_applies_and_manual_wins(client, admin, cashier, mgr, presets, orders, menu):
    cat = _item(menu, "101")["category_id"]
    presets(name="هپی‌آور قهوه", kind="percent", value=20, scope="item", auto_apply=True, target_category_ids=[cat])
    o = orders(line(menu, "101", 2), line(menu, "104"))
    other_cat = _item(menu, "104")["category_id"] != cat
    l101 = next(l for l in o["lines"] if l["menu_item_id"] == _item(menu, "101")["id"])
    assert l101["discount_auto"] and l101["discount_amount"] == round(l101["total"] * 0.2)
    assert l101["discount_reason"] == "هپی‌آور قهوه"
    if other_cat:
        l104 = next(l for l in o["lines"] if l["menu_item_id"] == _item(menu, "104")["id"])
        assert not l104["discount_type"]
    # automatic discount is not the cashier's: a 10% manual bill discount on top needs no PIN (cashier ceiling 10%)
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"type": "percent", "value": 10, "reason": "مشتری دائمی"})
    assert r.status_code == 200, r.text
    # a manual item discount replaces the automatic one; removing it brings the automatic one back
    r = client.post(f"/api/orders/{o['id']}/lines/{l101['id']}/discount", headers=mgr, json={"type": "percent", "value": 50, "reason": "تست"})
    l = next(x for x in r.json()["lines"] if x["id"] == l101["id"])
    assert not l["discount_auto"] and l["discount_amount"] == round(l["total"] * 0.5)
    r = client.post(f"/api/orders/{o['id']}/lines/{l101['id']}/discount", headers=mgr, json={"type": None})
    l = next(x for x in r.json()["lines"] if x["id"] == l101["id"])
    assert l["discount_auto"] and l["discount_amount"] == round(l["total"] * 0.2)


def test_auto_preset_outside_its_hours_does_nothing(client, presets, orders, menu):
    from app.core.utils import now
    h = (now().hour + 3) % 24
    presets(name="خارج ساعت", kind="percent", value=30, scope="item", auto_apply=True,
            start_time=f"{h:02d}:00", end_time=f"{(h + 1) % 24:02d}:00")
    o = orders(line(menu, "101"))
    assert o["discount_amount"] == 0


def test_auto_bill_preset_follows_min_subtotal(client, admin, cashier, presets, orders, menu):
    o = orders(line(menu, "101"))
    threshold = o["subtotal"] + 1
    presets(name="خرید بالای حد", kind="amount", value=30_000, scope="order", auto_apply=True, min_subtotal=threshold)
    o = _get(client, admin, o["id"])
    assert o["discount_amount"] == 0                                            # below the threshold
    o = client.post(f"/api/orders/{o['id']}/lines", headers=cashier, json={"lines": [line(menu, "101")]}).json()
    assert o["discount_auto"] and o["discount_amount"] == 30_000 and o["discount_reason"] == "خرید بالای حد"
    lid = o["lines"][0]["id"]
    o = client.delete(f"/api/orders/{o['id']}/lines/{lid}", headers=cashier).json()   # pending line → back below
    assert o["discount_amount"] == 0 and not o["discount_auto"]


def test_auto_preset_validation(client, admin):
    bad = [dict(kind="percent", value=0, auto_apply=True),                            # open value
           dict(kind="percent", value=10, auto_apply=True, code="X1"),                # auto + code
           dict(kind="percent", value=10, auto_apply=True, requires_manager=True),
           dict(kind="bogo", buy_qty=0, get_qty=1), dict(kind="combo", value=100_000, combo_parts=[])]
    for b in bad:
        assert client.post("/api/orders/discounts/presets", headers=admin, json={"name": "نامعتبر", **b}).status_code == 400, b


# ------------------------------------------------------------------ buy X get Y / combo
def test_bogo_cheapest_unit_free(client, admin, cashier, presets, orders, menu):
    cat = _item(menu, "101")["category_id"]
    same_cat = [c for c, i in menu["items"].items() if i["category_id"] == cat and not c.startswith("__")][:2]
    p = presets(name="یکی بخر یکی ببر", kind="bogo", buy_qty=1, get_qty=1, value=100, target_category_ids=[cat])
    assert p["scope"] == "order" and p["value"] == 100
    o = orders(line(menu, same_cat[0], 2), line(menu, same_cat[1], 1))
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"preset_id": p["id"]})
    assert r.status_code in (200, 403), r.text
    if r.status_code == 403:                                                    # above the cashier's 10%: manager
        r = client.post(f"/api/orders/{o['id']}/discount", headers={**cashier, "X-Manager-Pin": "2222"}, json={"preset_id": p["id"]})
    o = r.json()
    units = sorted([_unit(client, admin, o["id"], same_cat[0], menu)] * 2 + [_unit(client, admin, o["id"], same_cat[1], menu)], reverse=True)
    assert o["discount_type"] == "bogo" and o["discount_amount"] == units[1]   # groups of 2: [u0,u1] → u1 free; u2 alone
    # not applicable → clear error, nothing saved
    o2 = orders(line(menu, same_cat[0], 1))
    r = client.post(f"/api/orders/{o2['id']}/discount", headers={**cashier, "X-Manager-Pin": "2222"}, json={"preset_id": p["id"]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "discount_not_applicable"
    assert _get(client, admin, o2["id"])["discount_type"] is None


def test_combo_price(client, admin, cashier, presets, orders, menu):
    a, b = _item(menu, "101"), _item(menu, "104")
    assert a["category_id"] != b["category_id"] or a["id"] != b["id"]
    p = presets(name="کمبو صبحانه", kind="combo", value=150_000,
                combo_parts=[{"item_ids": [a["id"]], "qty": 1}, {"item_ids": [b["id"]], "qty": 1}], auto_apply=True)
    o = orders(line(menu, "101", 2), line(menu, "104"))                           # one complete set (+1 extra 101)
    ua, ub = _unit(client, admin, o["id"], "101", menu), _unit(client, admin, o["id"], "104", menu)
    assert o["discount_auto"] and o["discount_reason"] == p["name"]
    assert o["discount_amount"] == max(ua + ub - 150_000, 0)
    o = client.post(f"/api/orders/{o['id']}/lines", headers=cashier, json={"lines": [line(menu, "104")]}).json()
    assert o["discount_amount"] == 2 * max(ua + ub - 150_000, 0)                 # two sets now


# ------------------------------------------------------------------ promo codes
def test_promo_code_at_register(client, admin, cashier, presets, orders, menu):
    presets(name="کد افتتاحیه", kind="percent", value=30, code=" open 30 ", max_uses=1)
    listed = [p["name"] for p in client.get("/api/orders/discounts/presets", headers=cashier).json()]
    assert "کد افتتاحیه" not in listed                                           # codes are typed, not picked
    o = orders(line(menu, "101", 2))
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"code": "NOPE"})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "invalid_code"
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"code": "open30"})   # 30% > cashier 10%: no PIN
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["discount_code"] == "OPEN30" and o["discount_amount"] == round(o["subtotal"] * 0.3)
    # the code's discount doesn't use up the cashier's ceiling: +5% on an item still fits (manual 5% < 10%)
    o2 = orders(line(menu, "101"))
    r = client.post(f"/api/orders/{o2['id']}/discount", headers=cashier, json={"code": "OPEN30"})
    assert r.status_code == 400 and "ظرفیت" in r.json()["detail"]["message"]   # max_uses = 1


def test_promo_code_per_customer_needs_phone(client, cashier, presets, orders, menu):
    presets(name="اولین خرید", kind="amount", value=20_000, code="FIRST", per_customer_limit=1)
    o = orders(line(menu, "101"))
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"code": "first"})
    assert r.status_code == 400 and "موبایل" in r.json()["detail"]["message"]
    o = orders(line(menu, "101"), customer_phone="09121112233", customer_name="مشتری تست")
    assert client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"code": "first"}).status_code == 200
    o = orders(line(menu, "101"), customer_phone="09121112233", customer_name="مشتری تست")
    r = client.post(f"/api/orders/{o['id']}/discount", headers=cashier, json={"code": "first"})
    assert r.status_code == 400 and "قبلاً" in r.json()["detail"]["message"]


def test_promo_code_online_checkout_and_accept(client, admin, mgr, presets, menu):
    ratelimit.reset()
    from app.modules.online import service as osvc
    osvc._hits.clear()
    keys = ("online.enabled", "online.accepting", "online.pickup", "online.min_order")
    saved = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    client.put("/api/system/settings", headers=admin, json={"online.enabled": True, "online.accepting": True, "online.pickup": True,
                                                              "online.min_order": 0}).raise_for_status()
    try:
        _online_promo_flow(client, admin, mgr, presets, menu)
    finally:
        client.put("/api/system/settings", headers=admin, json=saved).raise_for_status()


def _online_promo_flow(client, admin, mgr, presets, menu):
    presets(name="آنلاین ۱۵", kind="percent", value=15, code="WEB15")
    lines = [line(menu, "101", 2)]
    q = client.post("/api/online/public/promo", json={"code": "web15", "mode": "pickup", "lines": lines})
    assert q.status_code == 200, q.text
    assert client.post("/api/online/public/promo", json={"code": "zzz", "mode": "pickup", "lines": lines}).status_code == 400
    r = client.post("/api/online/public/orders", json={"mode": "pickup", "customer_name": "مهمان آنلاین", "phone": "09123334455",
                                                        "promo_code": "WEB15", "lines": lines})
    assert r.status_code == 201, r.text
    t = r.json()
    assert t["subtotal"] - q.json()["discount"] + t["tax"] == t["total"]
    rid = next(x["id"] for x in client.get("/api/online/requests", headers=admin).json() if x["token"] == t["token"])
    acc = client.post(f"/api/online/requests/{rid}/accept", headers=admin, json={})
    assert acc.status_code == 200, acc.text
    oid = client.get(f"/api/online/public/orders/{t['token']}").json()
    order = next(o for o in client.get("/api/orders/active", headers=admin).json() if o["customer_phone"] == "09123334455")
    assert order["discount_code"] == "WEB15" and order["discount_amount"] == q.json()["discount"], oid
    client.post(f"/api/orders/{order['id']}/cancel", headers=mgr, json={"reason": "پایان تست"})


# ------------------------------------------------------------------ daily / monthly ceilings
def test_daily_ceiling(client, admin, cashier, orders, menu):
    roles = {r["title"]: r for r in client.get("/api/orders/discounts/limits", headers=admin).json()["roles"]}
    role = roles["صندوقدار"]
    before = {k: role[k] for k in ("max_discount_pct", "max_discount_amount", "max_discount_daily", "max_discount_monthly")}
    try:
        client.put("/api/orders/discounts/limits", headers=admin,
                   json={"kind": "role", "id": role["id"], **before, "max_discount_daily": 30_000}).raise_for_status()
        o1 = orders(line(menu, "101", 3))
        used = client.get("/api/orders/discounts/my-limit", headers=cashier).json()["used_today"]
        r = client.post(f"/api/orders/{o1['id']}/discount", headers=cashier, json={"type": "amount", "value": max(30_000 - used, 1), "reason": "مشتری دائمی"})
        if 30_000 - used >= 1:
            assert r.status_code == 200, r.text
        o2 = orders(line(menu, "101", 3))
        r = client.post(f"/api/orders/{o2['id']}/discount", headers=cashier, json={"type": "amount", "value": 5_000, "reason": "مشتری دائمی"})
        assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required" and "روزانه" in r.json()["detail"]["message"]
        r = client.post(f"/api/orders/{o2['id']}/discount", headers={**cashier, "X-Manager-Pin": "2222"},
                        json={"type": "amount", "value": 5_000, "reason": "مشتری دائمی"})
        assert r.status_code == 200                                               # manager-approved: doesn't count
        me = client.get("/api/orders/discounts/my-limit", headers=cashier).json()
        assert me["max_daily"] == 30_000 and me["used_today"] <= 30_000
    finally:
        client.put("/api/orders/discounts/limits", headers=admin, json={"kind": "role", "id": role["id"], **before}).raise_for_status()


# ------------------------------------------------------------------ order number uniqueness
def test_unique_order_number_index_never_blocks_startup(tmp_path, caplog):
    from sqlalchemy import create_engine, inspect, text

    from app.core import migrate
    from app.core.db import Base
    eng = create_engine(f"sqlite:///{tmp_path / 'm.db'}")
    Base.metadata.create_all(eng)
    with eng.begin() as c:
        c.execute(text("DROP INDEX ux_orders_day_number"))
        for _ in range(2):                                                         # an old install with a duplicate
            c.execute(text("INSERT INTO orders (number, business_date, type, status, source, guests, discount_value, subtotal, "
                           "discount_amount, line_discount_amount, service_amount, tax_amount, rounding, total, paid_amount, "
                           "discount_auto, created_at) VALUES (7, :d, 'takeaway', 'closed', 'pos', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "
                           "CURRENT_TIMESTAMP)"), {"d": "2026-01-01"})
    stmts = migrate.upgrade(eng, Base.metadata)
    assert any("ux_orders_day_number" in s for s in stmts)
    assert "ux_orders_day_number" not in {i["name"] for i in inspect(eng).get_indexes("orders")}
    assert "duplicates" in caplog.text
    with eng.begin() as c:                                                         # data untouched
        assert c.execute(text("SELECT COUNT(*) FROM orders")).scalar() == 2


def test_online_limited_promo_needs_sms_code(client, admin, mgr, presets, menu, monkeypatch):
    """online.promo_otp: a per-customer promo code online needs the phone verified by an SMS code (one-time token)."""
    import re
    from datetime import timedelta

    from app.core.db import SessionLocal
    from app.modules.online import service as osvc
    from app.modules.sms import service as sms
    from app.modules.sms.models import SmsMessage
    ratelimit.reset()
    osvc._hits.clear()
    from app.core import settings_store

    def sms_on(v):                                     # sms.* is protected from /system/settings (own config endpoint)
        with SessionLocal() as db:
            old = settings_store.get(db, "sms.enabled", False)
            settings_store.set_many(db, {"sms.enabled": v})
            db.commit()
        return old
    keys = ("online.enabled", "online.accepting", "online.pickup", "online.min_order", "online.promo_otp")
    saved = {k: v for k, v in client.get("/api/system/settings", headers=admin).json().items() if k in keys}
    client.put("/api/system/settings", headers=admin, json={"online.enabled": True, "online.accepting": True, "online.pickup": True,
                                                              "online.min_order": 0, "online.promo_otp": True}).raise_for_status()
    sms_before = sms_on(True)
    phone, other = "09127001122", "09127001133"
    rid = None
    try:
        presets(name="یک‌بار برای هر نفر", kind="percent", value=10, code="ONCE10", per_customer_limit=1)
        presets(name="عمومی", kind="percent", value=5, code="ALL5")
        lines = [line(menu, "101", 2)]
        promo = lambda code, **kw: client.post("/api/online/public/promo", json={"code": code, "mode": "pickup", "phone": phone, "lines": lines, **kw})  # noqa: E731
        assert promo("ALL5").status_code == 200                                         # not limited per customer → no code needed
        r = promo("ONCE10")
        assert r.status_code == 403 and r.json()["detail"]["code"] == "otp_required"
        assert client.post("/api/online/public/otp/send", json={"phone": phone}).status_code == 200
        r = client.post("/api/online/public/otp/send", json={"phone": phone})
        assert r.status_code == 429 and r.json()["detail"]["code"] == "otp_wait"
        with SessionLocal() as db:
            m = db.query(SmsMessage).filter(SmsMessage.to == phone, SmsMessage.kind == "otp").order_by(SmsMessage.id.desc()).first()
            code = re.search(r"\d{5}", m.text).group(0)
            mid = m.id
        wrong = f"{(int(code) + 1) % 100000:05d}"
        r = client.post("/api/online/public/otp/verify", json={"phone": phone, "code": wrong})
        assert r.status_code == 400 and r.json()["detail"]["code"] == "otp_wrong" and r.json()["detail"]["left"] == 4
        fa = code.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))                   # typed on a Persian keyboard
        r = client.post("/api/online/public/otp/verify", json={"phone": phone, "code": fa})
        assert r.status_code == 200, r.text
        token = r.json()["otp_token"]
        assert client.post("/api/online/public/otp/verify", json={"phone": phone, "code": code}).json()["detail"]["code"] == "otp_expired"
        assert promo("ONCE10", otp_token=token).status_code == 200
        r = client.post("/api/online/public/promo", json={"code": "ONCE10", "mode": "pickup", "phone": other, "lines": lines, "otp_token": token})
        assert r.status_code == 403                                                      # token is bound to the verified phone
        order = {"mode": "pickup", "customer_name": "مهمان کد", "phone": phone, "promo_code": "ONCE10", "lines": lines}
        assert client.post("/api/online/public/orders", json=order).status_code == 403
        r = client.post("/api/online/public/orders", json={**order, "otp_token": token})
        assert r.status_code == 201 and r.json()["discount"] > 0, r.text
        tok = r.json()["token"]
        assert promo("ONCE10", otp_token=token).status_code == 403                       # consumed by the checkout
        # the code never stays readable in the SMS log
        with SessionLocal() as db:
            sms.process_queue(db)
            db.commit()
            m = db.get(SmsMessage, mid)
            assert m.status == "sent" and code not in m.text and "•••••" in m.text
        # 5 wrong tries lock the code
        monkeypatch.setattr(osvc, "OTP_RESEND", timedelta(0))
        assert client.post("/api/online/public/otp/send", json={"phone": other}).status_code == 200
        for i in range(5):
            r = client.post("/api/online/public/otp/verify", json={"phone": other, "code": "99999" if i % 2 else "88888"})
        assert r.json()["detail"]["code"] == "otp_locked"
        # SMS off → fail closed
        sms_on(False)
        r = client.post("/api/online/public/otp/send", json={"phone": "09127001144"})
        assert r.status_code == 503 and r.json()["detail"]["code"] == "sms_unavailable"
        rid = next(x["id"] for x in client.get("/api/online/requests", headers=admin).json() if x["token"] == tok)
    finally:
        if rid:
            client.post(f"/api/online/requests/{rid}/reject", headers=admin, json={"reason": "پایان تست"})
        client.put("/api/system/settings", headers=admin, json=saved).raise_for_status()
        sms_on(sms_before)
        osvc._hits.clear()
