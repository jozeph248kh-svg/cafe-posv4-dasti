"""Phase 2 modules: expenses / P&L, loyalty (wallet, cashback, credit), delivery, reservations, online orders."""
from datetime import timedelta

from conftest import line


def _bday():
    """The app's business day (day ends at day.cutoff_hour, default 05:00) — tests run after midnight too."""
    from app.core.utils import business_day
    return business_day()


def _shift(client, h):
    client.post("/api/shifts/open", json={"opening_cash": 0}, headers=h)


def _pay(client, h, oid, method, amount, **kw):
    return client.post(f"/api/orders/{oid}/payments", json={"payments": [{"method": method, "amount": amount, **kw}]}, headers=h)


# ------------------------------------------------------------------ expenses
def test_expenses_and_pnl(client, admin, cashier):
    assert client.get("/api/expenses", headers=cashier).status_code == 403
    cats = client.get("/api/expenses/categories", headers=admin).json()
    assert len(cats) >= 8
    _shift(client, cashier)
    before = client.get("/api/shifts/current", headers=admin).json()["cash_out"]
    today = _bday().isoformat()
    r = client.post("/api/expenses", json={"category_id": cats[0]["id"], "expense_date": today, "amount": 120_000, "method": "card", "from_register": True}, headers=admin)
    assert r.status_code == 400          # register payouts are cash-only
    e = client.post("/api/expenses", json={"category_id": cats[0]["id"], "expense_date": today, "amount": 120_000, "method": "cash", "from_register": True, "payee": "نانوایی"}, headers=admin).json()
    assert client.get("/api/shifts/current", headers=admin).json()["cash_out"] == before + 120_000
    lst = client.get("/api/expenses", params={"date_from": today, "date_to": today}, headers=admin).json()
    assert lst["total"] >= 120_000 and any(x["id"] == e["id"] for x in lst["items"])
    p = client.get("/api/expenses/pnl", params={"date_from": today, "date_to": today}, headers=admin).json()
    assert p["expenses"] >= 120_000
    assert p["net_profit"] == p["gross_profit"] - p["expenses"]
    # deleting a register expense puts the cash back
    assert client.delete(f"/api/expenses/{e['id']}", headers=admin).status_code == 204
    assert client.get("/api/shifts/current", headers=admin).json()["cash_in"] >= 120_000


# ------------------------------------------------------------------ loyalty
def test_wallet_cashback_and_credit(client, admin, cashier, menu):
    _shift(client, cashier)
    phone = "09350001122"
    # first order creates the customer → cashback on close
    o = client.post("/api/orders", json={"type": "takeaway", "customer_name": "نگار", "customer_phone": phone, "lines": [line(menu, "802", 3)]}, headers=cashier).json()
    o = _pay(client, cashier, o["id"], "card", o["total"]).json()
    acc = client.get(f"/api/loyalty/by-phone/{phone}", headers=cashier).json()
    assert acc["wallet"] > 0 and acc["wallet"] == acc["cashback_total"]
    assert acc["wallet"] == o["total"] * acc["tier"]["pct"] // 100 // 1000 * 1000
    cid = acc["customer_id"]

    # top-up in cash goes into the register
    cash_in = client.get("/api/shifts/current", headers=cashier).json()["cash_in"]
    r = client.post(f"/api/loyalty/customers/{cid}/topup", json={"amount": 500_000, "method": "cash"}, headers=cashier).json()
    assert r["wallet"] == acc["wallet"] + 500_000
    assert client.get("/api/shifts/current", headers=cashier).json()["cash_in"] == cash_in + 500_000
    wallet = r["wallet"]

    # pay with wallet: insufficient → error, partial → ok; no cashback on wallet portion
    o2 = client.post("/api/orders", json={"type": "takeaway", "customer_phone": phone, "lines": [line(menu, "802", 4)]}, headers=cashier).json()
    r = _pay(client, cashier, o2["id"], "wallet", o2["total"])
    assert r.status_code == 400 and r.json()["detail"]["code"] == "wallet_insufficient"
    r = _pay(client, cashier, o2["id"], "wallet", wallet)
    assert r.status_code == 200, r.text
    assert client.get(f"/api/loyalty/by-phone/{phone}", headers=cashier).json()["wallet"] == 0
    o2 = _pay(client, cashier, o2["id"], "cash", o2["total"] - wallet).json()
    assert o2["status"] == "closed"
    acc2 = client.get(f"/api/loyalty/by-phone/{phone}", headers=cashier).json()
    assert acc2["wallet"] == (o2["total"] - wallet) * acc2["tier"]["pct"] // 100 // 1000 * 1000

    # wallet payment without a phone is rejected
    o3 = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702")]}, headers=cashier).json()
    assert _pay(client, cashier, o3["id"], "wallet", 1000).json()["detail"]["code"] == "customer_required"

    # credit sale with a limit, then settle
    client.put(f"/api/loyalty/customers/{cid}/limit", json={"credit_limit": 300_000}, headers=admin)
    o4 = client.post("/api/orders", json={"type": "takeaway", "customer_phone": phone, "lines": [line(menu, "802", 2)]}, headers=cashier).json()
    assert _pay(client, cashier, o4["id"], "credit", o4["total"]).json()["detail"]["code"] == "credit_limit"
    o4 = _pay(client, cashier, o4["id"], "credit", 250_000).json()
    _pay(client, cashier, o4["id"], "card", o4["total"] - 250_000)
    d = client.get(f"/api/loyalty/customers/{cid}", headers=admin).json()
    assert d["debt"] == 250_000 and d["credit_txns"][0]["kind"] == "sale"
    assert client.post(f"/api/loyalty/customers/{cid}/settle", json={"amount": 999_999, "method": "cash"}, headers=cashier).status_code == 400
    r = client.post(f"/api/loyalty/customers/{cid}/settle", json={"amount": 250_000, "method": "cash"}, headers=cashier).json()
    assert r["debt"] == 0

    # manual adjust needs loyalty.adjust (cashier lacks it)
    assert client.post(f"/api/loyalty/customers/{cid}/adjust", json={"target": "wallet", "amount": 10_000, "reason": "جبران"}, headers=cashier).status_code == 403
    assert client.post(f"/api/loyalty/customers/{cid}/adjust", json={"target": "wallet", "amount": 10_000, "reason": "جبران"}, headers=admin).status_code == 200

    # refund of the first order claws back its cashback proportionally
    w_before = client.get(f"/api/loyalty/by-phone/{phone}", headers=cashier).json()["wallet"]
    client.post(f"/api/orders/{o['id']}/refund", json={"method": "card", "amount": o["total"], "reason": "مرجوعی کامل"}, headers=admin)
    w_after = client.get(f"/api/loyalty/by-phone/{phone}", headers=cashier).json()["wallet"]
    assert w_after < w_before
    s = client.get("/api/loyalty/summary", headers=admin).json()
    assert s["members"] >= 1 and len(s["tiers"]) == 4


# ------------------------------------------------------------------ delivery
def test_delivery_dispatch_and_courier_settlement(client, admin, cashier, chef, menu):
    _shift(client, cashier)
    zones = client.get("/api/delivery/zones", headers=cashier).json()
    assert len(zones) == 4
    c = client.post("/api/delivery/couriers", json={"name": "پیک تست", "phone": "09120000001", "default_fee": 30_000}, headers=admin).json()
    assert client.post("/api/delivery/couriers", json={"name": "x2"}, headers=cashier).status_code == 403

    o = client.post("/api/orders", json={"type": "delivery", "customer_name": "سارا", "customer_phone": "09121230000", "customer_address": "خیابان آزادی",
                                         "lines": [line(menu, "802")], "send": True}, headers=cashier).json()
    base_total = o["total"]
    d = client.put(f"/api/delivery/orders/{o['id']}", json={"zone_id": zones[1]["id"]}, headers=cashier).json()
    assert d["customer_fee"] == zones[1]["customer_fee"] and d["courier_fee"] == zones[1]["courier_fee"]
    o = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert o["subtotal"] == menu["items"]["802"]["price"] + zones[1]["customer_fee"]
    assert o["total"] > base_total
    # fee line never reaches the kitchen
    tickets = [t for t in client.get("/api/kitchen/tickets", headers=chef).json() if t["order_id"] == o["id"]]
    assert all("ارسال" not in i["name"] for t in tickets for i in t["items"])
    # changing zone updates the same fee line
    client.put(f"/api/delivery/orders/{o['id']}", json={"zone_id": zones[0]["id"]}, headers=cashier)
    o = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert sum(1 for l in o["lines"] if "ارسال" in l["name"] and l["status"] != "void") == 1
    assert o["subtotal"] == menu["items"]["802"]["price"] + zones[0]["customer_fee"]

    # dispatch: out without courier fails; assign → out (unpaid ⇒ courier collects) → delivered
    assert client.post(f"/api/delivery/orders/{o['id']}/status", json={"status": "out"}, headers=cashier).json()["detail"]["code"] == "courier_required"
    d = client.put(f"/api/delivery/orders/{o['id']}", json={"courier_id": c["id"]}, headers=cashier).json()
    assert d["status"] == "assigned"
    d = client.post(f"/api/delivery/orders/{o['id']}/status", json={"status": "out"}, headers=cashier).json()
    assert d["collect"] and d["collect_amount"] == o["total"]
    board = client.get("/api/delivery/board", headers=cashier).json()
    assert any(r["order_id"] == o["id"] and r["status"] == "out" for r in board["orders"])
    assert next(x for x in board["couriers"] if x["id"] == c["id"])["out"] == 1
    client.post(f"/api/delivery/orders/{o['id']}/status", json={"status": "delivered"}, headers=cashier)

    un = client.get(f"/api/delivery/couriers/{c['id']}/unsettled", headers=cashier).json()
    assert un["collected"] == o["total"] and un["fees"] == zones[0]["courier_fee"]
    cur = client.get("/api/shifts/current", headers=admin).json()        # expected cash: supervisors only (blind count)
    r = client.post(f"/api/delivery/couriers/{c['id']}/settle", json={"method": "cash"}, headers=cashier).json()
    assert r["net"] == o["total"] - zones[0]["courier_fee"]
    o = client.get(f"/api/orders/{o['id']}", headers=cashier).json()
    assert o["status"] == "closed" and o["payments"][-1]["method"] == "cash"
    cur2 = client.get("/api/shifts/current", headers=admin).json()
    assert cur2["expected_cash"] - cur["expected_cash"] == r["net"]
    # settled → locked
    assert client.post(f"/api/delivery/orders/{o['id']}/status", json={"status": "waiting"}, headers=cashier).status_code == 400
    assert client.post(f"/api/delivery/couriers/{c['id']}/settle", json={"method": "cash"}, headers=cashier).status_code == 400

    # delivery fee is not a menu sale in reports; courier fee shows as an expense in P&L
    today = _bday().isoformat()
    rep = client.get("/api/reports/sales", params={"date_from": today, "date_to": today}, headers=admin).json()
    assert all("ارسال" not in i["name"] for i in rep["by_item"])
    pnl = client.get("/api/expenses/pnl", params={"date_from": today, "date_to": today}, headers=admin).json()
    assert any(b["id"] == -1 for b in pnl["expenses_by_category"])
    assert all(i["code"] != "__delivery__" for i in client.get("/api/menu/items", headers=admin).json())


# ------------------------------------------------------------------ reservations
def test_reservations_and_waitlist(client, admin, waiter, chef):
    from datetime import datetime
    tables = [t for a in client.get("/api/orders/floor", headers=waiter).json() for t in a["tables"]]
    tb = next(t for t in tables if t["status"] == "free" and t["seats"] >= 4)
    start = (datetime.now() + timedelta(days=1)).replace(hour=20, minute=0, second=0, microsecond=0)
    body = {"customer_name": "آقای رزرو", "phone": "09120009999", "guests": 4, "start_at": start.isoformat(), "duration": 90, "table_id": tb["id"]}
    assert client.post("/api/reservations", json=body, headers=chef).status_code == 403
    r = client.post("/api/reservations", json=body, headers=waiter)
    assert r.status_code == 201, r.text
    rid = r.json()["id"]
    # overlapping booking on the same table is rejected; back-to-back is fine
    clash = client.post("/api/reservations", json={**body, "start_at": (start + timedelta(minutes=60)).isoformat()}, headers=waiter)
    assert clash.json()["detail"]["code"] == "table_reserved"
    ok = client.post("/api/reservations", json={**body, "customer_name": "بعدی", "start_at": (start + timedelta(minutes=90)).isoformat()}, headers=waiter)
    assert ok.status_code == 201
    av = client.get("/api/reservations/availability", params={"start_at": start.isoformat(), "guests": 4}, headers=waiter).json()
    assert next(a for a in av if a["id"] == tb["id"])["free"] is False
    day = client.get("/api/reservations", params={"day": start.date().isoformat()}, headers=waiter).json()
    assert any(x["id"] == rid for x in day["items"])

    # seating opens an order on the table
    s = client.post(f"/api/reservations/{rid}/status", json={"status": "seated"}, headers=waiter).json()
    assert s["status"] == "seated" and s["order_id"]
    o = client.get(f"/api/orders/{s['order_id']}", headers=waiter).json()
    assert o["table_id"] == tb["id"] and o["guests"] == 4
    client.post(f"/api/orders/{o['id']}/cancel", json={"reason": "تست"}, headers=admin)

    # waitlist
    w = client.post("/api/reservations/waitlist", json={"customer_name": "منتظر", "guests": 2, "quoted_minutes": 10}, headers=waiter).json()
    assert w["status"] == "waiting"
    assert client.post(f"/api/reservations/waitlist/{w['id']}/status", json={"status": "notified"}, headers=waiter).json()["status"] == "notified"
    assert client.post(f"/api/reservations/waitlist/{w['id']}/status", json={"status": "seated"}, headers=waiter).json()["detail"]["code"] == "table_required"
    w = client.post(f"/api/reservations/waitlist/{w['id']}/status", json={"status": "seated", "table_id": tb["id"], "open_order": False}, headers=waiter).json()
    assert w["status"] == "seated" and w["table"] == tb["name"]


# ------------------------------------------------------------------ online / QR ordering
def test_online_and_qr_ordering(client, admin, cashier, waiter, chef, menu):
    _shift(client, cashier)
    info = client.get("/api/online/public/info").json()
    assert info["enabled"] and info["delivery"] and info["zones"]
    pm = client.get("/api/online/public/menu").json()
    assert pm["items"] and all("groups" in i for i in pm["items"])
    zone = info["zones"][0]

    base = {"mode": "delivery", "customer_name": "مهمان آنلاین", "phone": "09351112233", "address": "تهران، خیابان ولیعصر، کوچه ۵، پلاک ۱", "zone_id": zone["id"]}
    # required modifiers are enforced like the POS
    item_req = next(i for i in menu["items"].values() if any(menu["groups"][g]["min_select"] for g in i["modifier_group_ids"]))
    r = client.post("/api/online/public/orders", json={**base, "lines": [{"menu_item_id": item_req["id"], "qty": 1}]})
    assert r.json()["detail"]["code"] == "modifier_required"
    # minimum order
    cheap = min((i for i in menu["items"].values() if not i["modifier_group_ids"]), key=lambda i: i["price"])
    r = client.post("/api/online/public/orders", json={**base, "lines": [{"menu_item_id": cheap["id"], "qty": 1}]})
    assert r.json()["detail"]["code"] == "min_order"
    assert client.post("/api/online/public/orders", json={**base, "phone": "123", "lines": [line(menu, "802", 2)]}).json()["detail"]["code"] == "phone_invalid"

    t = client.post("/api/online/public/orders", json={**base, "pay_method": "cash", "lines": [line(menu, "802", 2)]})
    assert t.status_code == 201, t.text
    t = t.json()
    assert t["stage"] == "pending" and t["delivery_fee"] == zone["fee"]
    assert t["total"] == t["subtotal"] + t["delivery_fee"] + t["tax"]

    pending = client.get("/api/online/requests", headers=cashier).json()
    req = next(p for p in pending if p["token"] == t["token"])
    assert client.get("/api/online/requests", headers=chef).status_code == 403
    acc = client.post(f"/api/online/requests/{req['id']}/accept", json={"eta_minutes": 35}, headers=cashier).json()
    o = client.get(f"/api/orders/{acc['order_id']}", headers=cashier).json()
    assert o["type"] == "delivery" and o["source"] == "online" and o["total"] == t["total"]
    d = client.get(f"/api/delivery/orders/{o['id']}", headers=cashier).json()
    assert d["zone_id"] == zone["id"] and d["collect"] is True
    tr = client.get(f"/api/online/public/orders/{t['token']}").json()
    assert tr["stage"] == "preparing" and tr["number"] == o["number"] and tr["eta_minutes"] == 35
    assert client.post(f"/api/online/requests/{req['id']}/accept", json={}, headers=cashier).status_code == 400

    # reject flow
    t2 = client.post("/api/online/public/orders", json={**base, "phone": "09351112244", "lines": [line(menu, "802", 2)]}).json()
    rid = next(p for p in client.get("/api/online/requests", headers=cashier).json() if p["token"] == t2["token"])["id"]
    client.post(f"/api/online/requests/{rid}/reject", json={"reason": "اتمام مواد"}, headers=cashier)
    tr = client.get(f"/api/online/public/orders/{t2['token']}").json()
    assert tr["stage"] == "rejected" and tr["reject_reason"] == "اتمام مواد"

    from app.modules.online import service as osvc
    osvc._hits.clear()
    # QR table ordering: adds to the table's open order when there is one
    tables = [x for a in client.get("/api/orders/floor", headers=waiter).json() for x in a["tables"]]
    free = next(x for x in tables if x["status"] == "free")
    tok = next(x for x in client.get("/api/floor/tables", headers=admin).json() if x["id"] == free["id"])["qr_token"]
    assert client.post("/api/online/public/orders", json={"mode": "table", "table_token": "bad", "lines": [line(menu, "702")]}).status_code == 404
    q1 = client.post("/api/online/public/orders", json={"mode": "table", "table_token": tok, "lines": [line(menu, "702")]}).json()
    rid = next(p for p in client.get("/api/online/requests", headers=waiter).json() if p["token"] == q1["token"])["id"]
    o1 = client.post(f"/api/online/requests/{rid}/accept", json={}, headers=waiter).json()
    q2 = client.post("/api/online/public/orders", json={"mode": "table", "table_token": tok, "lines": [line(menu, "104")]}).json()
    rid = next(p for p in client.get("/api/online/requests", headers=waiter).json() if p["token"] == q2["token"])["id"]
    o2 = client.post(f"/api/online/requests/{rid}/accept", json={}, headers=waiter).json()
    assert o1["order_id"] == o2["order_id"]
    o = client.get(f"/api/orders/{o1['order_id']}", headers=waiter).json()
    assert o["table_id"] == free["id"] and len([l for l in o["lines"] if l["status"] != "void"]) == 2
    assert all(l["status"] == "sent" for l in o["lines"])
    client.post(f"/api/orders/{o['id']}/cancel", json={"reason": "تست"}, headers=admin)


# ------------------------------------------------------------------ phase 3: SMS
def test_sms_providers_and_events(client, admin, cashier, monkeypatch):
    import httpx

    from app.core.db import SessionLocal
    from app.modules.sms import providers as P
    from app.modules.sms import service as S

    # provider adapters speak the documented wire formats
    calls = []

    def fake_post(url, **kw):
        calls.append((url, kw))
        if "kavenegar" in url:
            return httpx.Response(200, json={"return": {"status": 200, "message": "تایید شد"}, "entries": [{"messageid": 8792343}]})
        if "sms.ir" in url:
            return httpx.Response(200, json={"status": 1, "message": "موفق", "data": {"packId": "x", "messageIds": [555], "cost": 1}})
        return httpx.Response(200, json={"recId": 3741437414, "status": "ارسال موفق بود"})
    monkeypatch.setattr(httpx, "post", fake_post)
    assert P.Kavenegar({"api_key": "K", "sender": "1000"}).send("09120000001", "سلام") == "8792343"
    assert calls[-1][0] == "https://api.kavenegar.com/v1/K/sms/send.json" and calls[-1][1]["data"]["receptor"] == "09120000001"
    assert P.SmsIr({"api_key": "K", "line": "3000"}).send("09120000001", "سلام") == "555"
    assert calls[-1][1]["headers"]["X-API-KEY"] == "K" and calls[-1][1]["json"]["mobiles"] == ["09120000001"]
    assert P.MeliPayamak({"token": "T", "sender": "5000"}).send("09120000001", "سلام") == "3741437414"
    assert calls[-1][0].endswith("/api/send/simple/T")
    monkeypatch.setattr(httpx, "post", lambda url, **kw: httpx.Response(200, json={"return": {"status": 418, "message": "اعتبار کافی نیست"}}))
    import pytest
    with pytest.raises(P.SmsError):
        P.Kavenegar({"api_key": "K"}).send("09120000001", "x")
    assert P.parts("a" * 70) == 1 and P.parts("a" * 71) == 2

    # business event → queued SMS → sent by the background job (test provider)
    st = client.get("/api/sms/status", headers=admin).json()
    assert st["provider"] == "test" and st["credit"]
    assert client.get("/api/sms/status", headers=cashier).status_code == 403
    start = __import__("datetime").datetime.now().replace(microsecond=0) + __import__("datetime").timedelta(days=2)
    r = client.post("/api/reservations", json={"customer_name": "تست پیامک", "phone": "09125550001", "guests": 2, "start_at": start.isoformat()}, headers=cashier)
    assert r.status_code == 201, r.text
    msgs = client.get("/api/sms/messages", params={"q": "09125550001"}, headers=admin).json()["items"]
    assert msgs and msgs[0]["status"] == "queued" and msgs[0]["kind"] == "reservation_created" and "تست پیامک" in msgs[0]["text"]
    with SessionLocal() as db:
        monkeypatch.setattr(S, "_quiet", lambda db: False)
        assert S.process_queue(db) >= 1
        db.commit()
    assert client.get("/api/sms/messages", params={"q": "09125550001"}, headers=admin).json()["items"][0]["status"] == "sent"

    # failures retry up to 3 times then stay failed
    assert client.post("/api/sms/test", json={"to": "09120000000"}, headers=admin).json()["detail"]["code"] == "send_failed"
    assert client.post("/api/sms/test", json={"to": "09121234567"}, headers=admin).status_code == 200

    # templates can be edited / disabled
    client.put("/api/sms/templates", json={"items": {"reservation_created": {"enabled": False, "text": "x"}}}, headers=admin)
    client.post("/api/reservations", json={"customer_name": "بی‌پیامک", "phone": "09125550002", "guests": 2, "start_at": start.isoformat()}, headers=cashier)
    assert client.get("/api/sms/messages", params={"q": "09125550002"}, headers=admin).json()["total"] == 0
    client.put("/api/sms/templates", json={"items": {"reservation_created": {"enabled": True, "text": "رزرو {name} ثبت شد"}}}, headers=admin)

    # campaign: opt-out respected, regulator footer appended
    for i, ph in enumerate(["09126660001", "09126660002", "09126660003"]):
        client.post("/api/customers", json={"name": f"کمپین {i}", "phone": ph}, headers=admin)
    client.post("/api/sms/optout", json={"phone": "09126660002"}, headers=admin)
    seg = {"type": "phones", "phones": ["09126660001", "09126660002", "09126660003", "123"]}
    pv = client.post("/api/sms/campaigns/preview", json={"segment": {"type": "all"}, "text": "تخفیف ویژه"}, headers=admin).json()
    assert pv["count"] >= 2 and "لغو۱۱" in pv["text"] and "09126660002" not in [x["phone"] for x in pv["sample"]]
    c = client.post("/api/sms/campaigns", json={"title": "تست", "text": "سلام {name}", "segment": seg}, headers=admin).json()
    assert c["total"] == 2
    rows = client.get("/api/sms/messages", params={"kind": "campaign"}, headers=admin).json()["items"]
    assert all(r["to"] != "09126660002" for r in rows) and all("لغو۱۱" in r["text"] for r in rows if r["campaign_id"] == c["id"])


# ------------------------------------------------------------------ phase 3: card reader
def test_cardreader_flow(client, admin, cashier, menu, monkeypatch):
    import httpx

    from app.modules.cardreader import drivers as D
    monkeypatch.setattr(D.threading.Event, "wait", lambda self, t=None: self.is_set())   # skip the 3s simulator delay
    for name, drv in (("صندوق", "simulator"), ("دستی", "manual")):
        client.post("/api/cardreader/terminals", json={"name": name, "driver": drv, "psp": "sadad"}, headers=admin)
    ts = client.get("/api/cardreader/terminals", headers=cashier).json()
    sim = next(t for t in ts if t["driver"] == "simulator")
    _shift(client, cashier)
    o = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702")]}, headers=cashier).json()
    total = o["total"]
    r = client.post("/api/cardreader/charge", json={"terminal_id": sim["id"], "amount": total, "order_id": o["id"], "uid": "t-1"}, headers=cashier).json()
    assert r["status"] == "approved" and r["rrn"] and r["card"].startswith("603799")
    assert client.post("/api/cardreader/charge", json={"terminal_id": sim["id"], "amount": total, "uid": "t-1"}, headers=cashier).status_code == 400
    bad = client.post("/api/cardreader/charge", json={"terminal_id": sim["id"], "amount": 113000, "uid": "t-2"}, headers=cashier).json()
    assert bad["status"] == "declined"
    assert client.get("/api/cardreader/txns", params={"unlinked": True}, headers=admin).json()["unlinked"] >= 1
    # paying with the RRN links the transaction to the payment
    paid = client.post(f"/api/orders/{o['id']}/payments", json={"payments": [{"method": "card", "amount": total, "reference": r["rrn"]}]}, headers=cashier).json()
    assert paid["status"] == "closed"
    tx = next(x for x in client.get("/api/cardreader/txns", headers=admin).json()["items"] if x["uid"] == "t-1")
    assert tx["payment_id"] and tx["order_id"] == o["id"]
    # bridge driver speaks the documented contract
    t = client.post("/api/cardreader/terminals", json={"name": "پل", "psp": "sadad", "driver": "bridge", "url": "http://10.0.0.5:8090", "token": "S", "device_ip": "192.168.1.227:8888"}, headers=admin).json()
    assert client.get("/api/cardreader/terminals", headers=cashier).json()[-1]["token"] is None
    seen = {}

    def fake_post(url, json=None, headers=None, timeout=None):
        seen.update(url=url, body=json, headers=headers)
        return httpx.Response(200, json={"status": "approved", "rrn": "123456789012", "trace": "4455", "card": "6104****1111", "code": "00"})
    monkeypatch.setattr(httpx, "post", fake_post)
    r2 = client.post("/api/cardreader/charge", json={"terminal_id": t["id"], "amount": 250000}, headers=cashier).json()
    assert r2["status"] == "approved" and seen["url"] == "http://10.0.0.5:8090/sale" and seen["body"]["amount"] == 2_500_000
    assert seen["headers"]["Authorization"] == "Bearer S" and seen["body"]["device"] == "192.168.1.227:8888"
    # manual entry
    man = next(x for x in ts if x["driver"] == "manual")
    m = client.post("/api/cardreader/manual", json={"terminal_id": man["id"], "amount": 90000, "rrn": "99887766"}, headers=cashier).json()
    assert m["status"] == "approved"
    assert client.post("/api/cardreader/terminals", json={"name": "x"}, headers=cashier).status_code == 403


# ------------------------------------------------------------------ phase 3: marketplace (SnappFood)
def test_marketplace_flow(client, admin, cashier, menu):
    import json as _json

    from app.modules.marketplace.service import sign
    _shift(client, cashier)
    chans = client.get("/api/marketplace/channels", headers=admin).json()
    sf = next(c for c in chans if c["key"] == "snappfood")
    secret = sf["config"]["webhook_secret"]
    assert "webhook_secret" not in client.get("/api/marketplace/channels", headers=cashier).json()[0]["config"]
    from app.core.db import SessionLocal
    from app.modules.menu.models import MenuItem
    with SessionLocal() as db:
        mi = db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.price > 0).first()
        mid, mname, mprice = mi.id, mi.name, mi.price
    payload = {"id": "SF100200", "customer": {"name": "آرش", "phone": "09121110000"}, "items": [
        {"id": "P1", "name": mname, "qty": 2, "price": mprice}, {"id": "P9", "name": "پک ویژه", "qty": 1, "price": 100000}], "vendor_discount": 10000}
    body = _json.dumps(payload).encode()
    assert client.post("/api/marketplace/webhook/snappfood", content=body, headers={"X-Signature": "bad"}).status_code == 401
    r = client.post("/api/marketplace/webhook/snappfood", content=body, headers={"X-Signature": sign(secret, body), "Content-Type": "application/json"})
    assert r.status_code == 200, r.text
    # retries are idempotent
    r2 = client.post("/api/marketplace/webhook/snappfood", content=body, headers={"X-Signature": sign(secret, body)})
    assert r2.json()["id"] == r.json()["id"]
    mo = client.get("/api/marketplace/orders", params={"active": True}, headers=cashier).json()[0]
    assert mo["unmapped"] == 1 and mo["commission"] == round((2 * mprice + 100000 - 10000) * 0.22)
    assert client.post(f"/api/marketplace/orders/{mo['id']}/accept", headers=cashier).json()["detail"]["code"] == "unmapped"
    mo = client.post(f"/api/marketplace/orders/{mo['id']}/map", json={"maps": {"1": mid}}, headers=cashier).json()
    assert mo["unmapped"] == 0
    mo = client.post(f"/api/marketplace/orders/{mo['id']}/accept", headers=cashier).json()
    assert mo["status"] == "accepted" and mo["order_id"] and mo["outbound"][-1]["status"] == "accepted"
    o = client.get(f"/api/orders/{mo['order_id']}", headers=cashier).json()
    assert o["source"] == "snappfood" and o["discount_amount"] == 10000
    mo = client.post(f"/api/marketplace/orders/{mo['id']}/picked", headers=cashier).json()
    o = client.get(f"/api/orders/{mo['order_id']}", headers=cashier).json()
    assert o["status"] == "closed" and o["payments"][0]["method"] == "online"
    # the mapping is remembered for the next order
    p2 = {**payload, "id": "SF100201"}
    b2 = _json.dumps(p2).encode()
    client.post("/api/marketplace/webhook/snappfood", content=b2, headers={"X-Signature": sign(secret, b2)})
    mo2 = next(x for x in client.get("/api/marketplace/orders", params={"active": True}, headers=cashier).json() if x["external_id"] == "SF100201")
    assert mo2["unmapped"] == 0
    client.post(f"/api/marketplace/orders/{mo2['id']}/accept", headers=cashier)
    # marketplace cancels → internal order is cancelled
    cb = _json.dumps({"event": "order.cancelled", "id": "SF100201", "reason": "مشتری لغو کرد"}).encode()
    assert client.post("/api/marketplace/webhook/snappfood", content=cb, headers={"X-Signature": sign(secret, cb)}).json()["status"] == "cancelled"
    assert client.get(f"/api/orders/{mo2['order_id'] if mo2['order_id'] else mo['order_id']}", headers=cashier).status_code == 200
    # simulate + manual quick entry
    assert client.post(f"/api/marketplace/channels/{sf['id']}/simulate", headers=cashier).status_code == 200
    tp = next(c for c in chans if c["key"] == "tapsifood")
    m = client.post("/api/marketplace/orders/manual", json={"channel_id": tp["id"], "external_id": "TP-55", "items": [{"menu_item_id": mid, "qty": 1}]}, headers=cashier).json()
    assert m["status"] == "accepted" and m["commission"] == round(mprice * 0.18)
    # report + settlement books the commission as an expense
    rep = client.get("/api/marketplace/report", headers=admin).json()
    row = next(x for x in rep["channels"] if x["channel"]["key"] == "snappfood")
    assert row["orders"] >= 1 and row["outstanding"] == mo["net"]
    s = client.post("/api/marketplace/settlements", json={"channel_id": sf["id"], "amount": mo["net"], "date": str(_bday()), "reference": "TR-1"}, headers=admin).json()
    assert s["orders_count"] == 1 and s["diff"] == 0
    exp = client.get("/api/expenses", headers=admin).json()
    rows = exp["items"] if isinstance(exp, dict) else exp
    assert any(e["amount"] == mo["commission"] for e in rows)
    assert client.post("/api/marketplace/settlements", json={"channel_id": sf["id"], "amount": 1, "date": str(_bday())}, headers=cashier).status_code == 403


# ------------------------------------------------------------------ phase 3: Moadian (tax system)
def test_moadian_crypto_and_client(monkeypatch):
    import json as _json
    from datetime import datetime

    import httpx

    from app.modules.moadian import client as C
    from app.modules.moadian import crypto as K
    assert K.verhoeff("236") == 3 and K.verhoeff_valid("2363")
    tid = K.tax_id("A11216", datetime(2023, 5, 20, 12, 0), 1)
    assert len(tid) == 22 and tid.startswith("A1121604C29") and tid[11:21] == "0000000001"
    key, csr = K.generate_key_and_csr("کافه تست", "14000000000")
    assert "CERTIFICATE REQUEST" in csr
    cert = K.self_signed(key)
    tok = K.jws({"a": 1}, key, cert)
    hdr = _json.loads(K.b64url_dec(tok.split(".")[0]))
    assert hdr["crit"] == ["sigT"] and hdr["alg"] == "RS256" and K.jws_verify(tok) == {"a": 1}
    server_key, _ = K.generate_key_and_csr("server", "1234567890")
    enc = K.jwe("سلام", K.public_b64(server_key), "kid1")
    assert _json.loads(K.b64url_dec(enc.split(".")[0]))["enc"] == "A256GCM" and K.jwe_decrypt(enc, server_key) == "سلام"

    # real client against a fake server: packet must be decryptable by the server and signed by us
    seen = {}

    def fake(method, url, headers=None, params=None, json=None, timeout=None):
        if url.endswith("nonce"):
            return httpx.Response(200, json={"nonce": "N1", "expDate": 0})
        if url.endswith("server-information"):
            return httpx.Response(200, json={"publicKeys": [{"key": K.public_b64(server_key), "id": "KID"}]})
        if url.endswith("invoice"):
            seen["auth"], seen["packets"] = headers["Authorization"], json
            return httpx.Response(200, json={"result": [{"uid": "u1", "referenceNumber": "R1", "taxId": "X"}]})
        return httpx.Response(404, json={"errors": [{"code": "404", "message": "nf"}]})
    monkeypatch.setattr(httpx, "request", fake)
    cl = C.Client("sandbox", "A11216", key, cert)
    res = cl.send([{"header": {"taxid": tid}, "body": [], "payments": []}])
    assert res[0]["referenceNumber"] == "R1"
    assert K.jws_verify(seen["auth"].removeprefix("Bearer ")) == {"nonce": "N1", "clientId": "A11216"}
    pkt = seen["packets"][0]
    assert pkt["header"]["fiscalId"] == "A11216" and K.jws_verify(K.jwe_decrypt(pkt["payload"], server_key))["header"]["taxid"] == tid


def test_moadian_flow(client, admin, cashier, menu):
    from app.core.db import SessionLocal
    from app.modules.moadian import client as C
    from app.modules.moadian import service as S
    C.MockClient.delay = 0
    _shift(client, cashier)
    cfg = {"enabled": True, "mode": "mock", "auto_send": True, "memory_id": "a11216", "economic_code": "14000000000", "vat_percent": 10,
           "price_includes_vat": True, "default_sstid": "", "default_mu": "1627", "min_amount": 0}
    assert client.put("/api/moadian/config", json=cfg, headers=admin).status_code == 200
    assert client.get("/api/moadian/status", headers=cashier).status_code == 403
    # item without product id → invoice is held locally with a clear error
    o = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702", 2)]}, headers=cashier).json()
    _pay(client, cashier, o["id"], "card", o["total"])
    inv = client.get("/api/moadian/invoices", headers=admin).json()["items"][0]
    assert inv["status"] == "not_sent" and "۱۳ رقمی" in inv["errors"][0]["message"]
    client.put("/api/moadian/config", json={**cfg, "default_sstid": "2710000138624"}, headers=admin)
    inv = client.post(f"/api/moadian/invoices/{inv['id']}/retry", headers=admin).json()
    assert inv["status"] == "queued" and inv["tax_id"].startswith("A11216") and inv["serial"] == 1
    # payload sanity (amounts in rial, VAT extracted from inclusive price, totals consistent)
    p = client.get(f"/api/moadian/invoices/{inv['id']}/payload", headers=admin).json()
    h = p["header"]
    assert h["inty"] == 2 and h["ins"] == 1 and h["tbill"] == sum(b["tsstam"] for b in p["body"]) and abs(h["tbill"] - o["total"] * 10) <= 2
    assert h["tadis"] + h["tvam"] == h["tbill"] and all(b["adis"] == b["prdis"] - b["dis"] for b in p["body"])
    # the second order is auto-queued with the next serial
    o2 = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702")]}, headers=cashier).json()
    _pay(client, cashier, o2["id"], "cash", o2["total"])
    with SessionLocal() as db:
        assert S.send_queue(db) == 2
        db.commit()
        assert S.inquire(db) == 0       # sent less than 10 seconds ago
    with SessionLocal() as db:
        from app.modules.moadian.models import TaxInvoice
        for t in db.query(TaxInvoice):
            t.sent_at = t.sent_at.replace(year=t.sent_at.year - 1) if t.sent_at else None
        db.commit()
        assert S.inquire(db) == 2
        db.commit()
    rows = client.get("/api/moadian/invoices", headers=admin).json()["items"]
    assert {r["status"] for r in rows} == {"success"} and sorted(r["serial"] for r in rows) == [1, 2]
    # cancellation invoice references the original
    c = client.post(f"/api/moadian/invoices/{rows[-1]['id']}/cancel", headers=admin).json()
    assert c["kind"] == "cancel" and c["ref_tax_id"] == rows[-1]["tax_id"] and c["serial"] == 3
    cp = client.get(f"/api/moadian/invoices/{c['id']}/payload", headers=admin).json()
    assert cp["header"]["ins"] == 3 and cp["header"]["irtaxid"] == rows[-1]["tax_id"]
    assert client.post(f"/api/moadian/invoices/{rows[-1]['id']}/cancel", headers=admin).status_code == 400
    client.put("/api/moadian/config", json={**cfg, "enabled": False}, headers=admin)


# ------------------------------------------------------------------ phase 3: multi-branch sync
def test_branch_sync(client, admin, cashier, menu, monkeypatch):
    import httpx

    from app.core.db import SessionLocal
    from app.modules.branches import service as BS
    # central side: register a branch → one-time API key
    b = client.post("/api/branches", json={"name": "شعبه ونک", "code": "VNK"}, headers=admin).json()
    key = b["api_key"]
    assert key.startswith("br_") and client.get("/api/branches/sync/ping", headers={"Authorization": "Bearer wrong"}).status_code == 401

    # the same app plays the branch: route its outgoing HTTP into the TestClient
    def fpost(url, headers=None, json=None, timeout=None):
        return client.post(url.replace("http://central", ""), headers=headers, json=json)

    def fget(url, headers=None, timeout=None, params=None):
        return client.get(url.replace("http://central", ""), headers=headers)
    monkeypatch.setattr(httpx, "post", fpost)
    monkeypatch.setattr(httpx, "get", fget)
    assert client.put("/api/branches/local/config", json={"mode": "branch", "central_url": ""}, headers=admin).status_code == 400
    client.put("/api/branches/local/config", json={"mode": "branch", "central_url": "http://central/", "api_key": key}, headers=admin)
    assert client.post("/api/branches/local/test", headers=admin).json()["branch"] == "شعبه ونک"

    # offline: sales queue up in the outbox
    _shift(client, cashier)
    o = client.post("/api/orders", json={"type": "takeaway", "lines": [line(menu, "702", 2)]}, headers=cashier).json()
    _pay(client, cashier, o["id"], "cash", o["total"])
    st = client.get("/api/branches/local/status", headers=admin).json()
    assert st["mode"] == "branch" and st["pending"] == 1
    monkeypatch.setattr(httpx, "post", lambda *a, **k: (_ for _ in ()).throw(httpx.ConnectError("offline")))
    assert client.post("/api/branches/local/push", headers=admin).status_code == 400
    st = client.get("/api/branches/local/status", headers=admin).json()
    assert st["pending"] == 1 and "offline" in st["last_error"]
    # back online: the background job pushes it (idempotent on repeat)
    monkeypatch.setattr(httpx, "post", fpost)
    with SessionLocal() as db:
        assert BS.push(db)["sent"] == 1
        db.commit()
    with SessionLocal() as db:
        from app.modules.branches.models import SyncOutbox
        db.query(SyncOutbox).update({"status": "pending"})
        db.commit()
        BS.push(db)
        db.commit()
    rep = client.get("/api/branches/report", headers=admin).json()
    vnk = next(x for x in rep["branches"] if x["name"] == "شعبه ونک")
    assert vnk["orders"] == 1 and vnk["sales"] == o["total"] and vnk["payments"]["cash"] == o["total"] and vnk["online"] is True
    assert vnk["snapshot"]["today_orders"] >= 1 and rep["top_items"]
    # catalog pull: matched by name, prices follow the central menu
    res = client.post("/api/branches/local/pull-catalog", params={"prices_only": True}, headers=admin).json()
    assert res["created"] == 0 and res["updated"] + res["unchanged"] > 5
    # key rotation invalidates the old key
    client.post(f"/api/branches/{b['id']}/rotate-key", headers=admin)
    assert client.get("/api/branches/sync/ping", headers={"Authorization": f"Bearer {key}"}).status_code == 401
    client.put("/api/branches/local/config", json={"mode": "standalone", "central_url": ""}, headers=admin)


def test_marketplace_required_modifiers(client, admin, cashier):
    from app.core.db import SessionLocal
    from app.modules.menu.models import MenuItem
    with SessionLocal() as db:
        item = next((m for m in db.query(MenuItem).filter(MenuItem.is_active.is_(True)) if any(g.min_select > 0 for g in m.modifier_groups)), None)
        mid = item.id if item else None
    if not mid:
        return
    ch = client.get("/api/marketplace/channels", headers=admin).json()[0]
    r = client.post("/api/marketplace/orders/manual", json={"channel_id": ch["id"], "external_id": "MOD-1", "items": [{"menu_item_id": mid, "qty": 1}]}, headers=cashier)
    assert r.status_code == 201 and r.json()["status"] == "accepted", r.text
