"""Final security audit — one executable check per item of the checklist.

Each test states what the product promises and fails when the promise is broken. Items that were already fixed in an
earlier round are kept as narrow standing guards (they are cheap and they are the only proof the fix still holds).
Items that turn out to be broken here are fixed in this round (see the report).
"""
import threading
import time

import pytest
from conftest import _login, close_register


@pytest.fixture(scope="module")
def mgr(client):
    return _login(client, "sara", "manager123")


@pytest.fixture(scope="module", autouse=True)
def _register(client, admin, mgr):
    if not client.get("/api/shifts/current", headers=mgr).json():
        client.post("/api/shifts/open", headers=mgr, json={"opening_cash": 0}).raise_for_status()
    yield
    close_register(client, admin)


def _item(client, admin, name="قهوه امنیتی", price=50_000):
    cats = client.get("/api/menu/categories", headers=admin).json()
    r = client.post("/api/menu/items", headers=admin,
                    json={"category_id": cats[0]["id"], "name": name, "price": price, "is_active": True})
    assert r.status_code == 201, r.text
    return r.json()


def _open_order(client, who, item, qty=1):
    r = client.post("/api/orders", headers=who, json={"type": "takeaway",
                                                      "lines": [{"menu_item_id": item["id"], "qty": qty}]})
    assert r.status_code == 201, r.text
    return r.json()


def _closed_order(client, cashier, item, qty=1):
    o = _open_order(client, cashier, item, qty)
    r = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                    json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert r.status_code == 200, r.text
    return r.json()


# ═══════════════════════════════════ 1) permissions of ordinary staff
def test_one_waiter_and_cashier_cannot_discount_pay_out_or_touch_settings(client, admin, cashier, waiter, chef):
    item = _item(client, admin)
    o = _open_order(client, waiter, item)

    # discount (bill and item) is a manager decision
    assert client.post(f"/api/orders/{o['id']}/discount", headers=waiter,
                       json={"type": "amount", "value": 1_000, "reason": "x"}).status_code in (400, 403)
    lid = o["lines"][0]["id"]
    assert client.post(f"/api/orders/{o['id']}/lines/{lid}/discount", headers=waiter,
                       json={"type": "amount", "value": 1_000, "reason": "x"}).status_code in (400, 403)

    # money out of the till needs `payments.refund`
    paid = client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                       json={"payments": [{"method": "cash", "amount": o["remaining"]}]})
    assert paid.status_code == 200, paid.text
    for who in (waiter, chef):
        assert client.post(f"/api/orders/{o['id']}/refund", headers=who,
                           json={"method": "cash", "amount": 5_000, "reason": "x"}).status_code in (400, 403)

    # management surfaces stay closed to everyone without the permission
    for path in ("/api/system/backups", "/api/system/backups/status", "/api/staff/users",
                 "/api/expenses/pnl", "/api/reports/sales", "/api/audit"):
        r = client.get(path, headers=waiter)
        assert r.status_code in (403, 404), f"{path} answered {r.status_code} to a waiter"

    # `GET /system/settings` IS readable by every device on purpose (the POS needs tax %, cutoff hour…),
    # so the real requirement is: no secret inside it, and nobody without the permission may write it.
    readable = client.get("/api/system/settings", headers=waiter)
    assert readable.status_code == 200
    body = readable.json()
    assert "sms.config" not in body and "branch.api_key" not in body, "a secret setting leaked to a waiter"
    for key, value in body.items():
        text = str(value)
        assert "api_key" not in text.lower() and "http://" not in text or key in ("business.instagram",), key
    # …and a cashier may take money but not change the business rules
    assert client.put("/api/system/settings", headers=cashier, json={"tax.percent": 0}).status_code in (403, 404)
    assert client.put("/api/system/settings", headers=waiter, json={"tax.percent": 0}).status_code in (403, 404)


# ═══════════════════════════════════ 2) manager PIN
def test_a_missing_or_unknown_manager_pin_never_approves_a_sensitive_action(client, admin, waiter, cashier):
    """Two ways this could go wrong: «no PIN configured anywhere» behaving as «approved», and a PIN that belongs to
    a user *without* the permission being accepted."""
    item = _item(client, admin, "قهوه پین ممیزی")
    o = _open_order(client, waiter, item)

    # 1) no PIN at all on the request → refused with the explicit «needs a manager» code
    r = client.post(f"/api/orders/{o['id']}/discount", headers=waiter,
                    json={"type": "amount", "value": 1_000, "reason": "بدون پین"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_required", r.text

    # 2) a made-up PIN → refused
    r = client.post(f"/api/orders/{o['id']}/discount", headers={**waiter, "X-Manager-Pin": "000000"},
                    json={"type": "amount", "value": 1_000, "reason": "پین غلط"})
    assert r.status_code == 403 and r.json()["detail"]["code"] == "override_invalid", r.text

    # 3) a real PIN that belongs to a non-manager (the waiter's own) must not approve a manager-only action
    #    (the item void permission is the manager-only one used here)
    r = client.post(f"/api/orders/{o['id']}/lines/{o['lines'][0]['id']}/void",
                    headers={**waiter, "X-Manager-Pin": "4444"}, json={"reason": "تلاش گارسون"})
    assert r.status_code in (400, 403), r.text

    # 4) with a genuine manager PIN the same call succeeds (proves the check is not just «always no»)
    r = client.post(f"/api/orders/{o['id']}/discount", headers={**waiter, "X-Manager-Pin": "2222"},
                    json={"type": "amount", "value": 1_000, "reason": "تأیید مدیر"})
    assert r.status_code == 200, r.text
    assert r.json()["discount_amount"] == 1_000


# ═══════════════════════════════════ 3) QR / shared table
def test_a_qr_token_cannot_read_other_orders_or_put_a_discount_on_the_bill(client, admin, waiter):
    from app.core.db import SessionLocal
    from app.modules.floor.models import DiningTable
    from app.modules.online.models import OnlineOrder

    with SessionLocal() as db:
        table = db.query(DiningTable).filter(DiningTable.qr_token.isnot(None)).first()
        assert table, "the demo data must contain a table with a QR token"
        token = table.qr_token
        # two guest orders, so we can check cross-reading
        a = OnlineOrder(mode="table", table_id=table.id, items=[{"name": "x", "qty": 1}], subtotal=1000,
                        total=1000, status="pending", token="audit-token-a-123456")
        b = OnlineOrder(mode="table", table_id=table.id, items=[{"name": "y", "qty": 1}], subtotal=2000,
                        total=2000, status="pending", token="audit-token-b-123456")
        db.add_all([a, b])
        db.commit()

    # a token only ever opens its own order
    ra = client.get("/api/online/public/orders/audit-token-a-123456")
    assert ra.status_code == 200 and ra.json()["subtotal"] == 1000
    assert "audit-token-b-123456" not in ra.text

    # a guest cannot choose the price, the discount or the total — the server recomputes everything
    cats = client.get("/api/online/public/menu").json()
    item = next(i for i in cats["items"] if i["is_available"])
    r = client.post("/api/online/public/orders", json={
        "mode": "table", "table_token": token, "pay_method": "cash",
        "lines": [{"menu_item_id": item["id"], "qty": 1, "unit_price": 1, "discount": 999_999}],
    })
    if r.status_code == 201:
        body = r.json()
        assert body["subtotal"] == item["price"], body
    else:                                   # QR ordering disabled in this installation → nothing to tamper with
        assert r.status_code in (403, 404), r.text

    # the table token is not a staff credential
    assert client.get("/api/orders/active", headers={"Authorization": f"Bearer {token}"}).status_code == 401
    assert client.get("/api/reports/sales", headers={"Authorization": f"Bearer {token}"}).status_code == 401


# ═══════════════════════════════════ 4) card reader: a failure must not leave a «pending» transaction
def test_a_card_reader_that_breaks_leaves_no_transaction_pending(client, admin, cashier):
    """`pending` is the state the POS shows as «در حال انتظار». If an unexpected error escapes, the drawer looks
    busy forever and the transaction can later be matched to a payment it never had."""
    from app.core.db import SessionLocal
    from app.modules.cardreader import drivers as D
    from app.modules.cardreader.models import CardTxn, PosTerminal

    # always its own terminal: reusing another file's bridge (which may carry a 300 s timeout) made this test slow
    # and order-dependent — the assertion «never hangs the POS» has to be measured on a known configuration
    with SessionLocal() as db:
        term = PosTerminal(name="پل آزمون امنیتی", psp="other", driver="bridge", url="http://127.0.0.1:9/dead",
                           timeout_sec=20, is_active=True)
        db.add(term)
        db.commit()
        tid = term.id

    started = time.monotonic()
    r = client.post("/api/cardreader/charge", headers=cashier,
                    json={"terminal_id": tid, "amount": 10_000, "uid": "audit-crash-1"}, timeout=120)
    assert time.monotonic() - started < 60, "the charge call must never hang the POS thread"
    assert r.status_code in (200, 400, 502, 503), r.text

    with SessionLocal() as db:
        x = db.query(CardTxn).filter(CardTxn.uid == "audit-crash-1").first()
        assert x is not None
        assert x.status != "pending", f"a broken reader left the transaction in «pending» ({x.status})"
        assert x.finished_at is not None, "the failed transaction must be closed with a timestamp"


def test_a_driver_that_raises_closes_the_transaction_instead_of_leaving_it_pending(client, admin, cashier):
    """The dangerous shape: the row is committed as `pending` *before* the device answers (that is how the POS can
    show progress), so any unexpected exception must finalise it — otherwise the drawer shows a stuck transaction
    forever and reconciliation can later match it to a payment that never happened."""
    from app.core.db import SessionLocal
    from app.modules.cardreader import drivers as D
    from app.modules.cardreader.models import CardTxn, PosTerminal

    with SessionLocal() as db:
        term = db.query(PosTerminal).filter(PosTerminal.driver == "simulator").first()
        if not term:
            term = PosTerminal(name="شبیه‌ساز آزمون خطا", psp="other", driver="simulator", is_active=True)
            db.add(term)
            db.commit()
        tid = term.id

    original = D.RUN["simulator"]

    def boom(*_a, **_k):
        raise RuntimeError("driver blew up")

    D.RUN["simulator"] = boom
    try:
        r = client.post("/api/cardreader/charge", headers=cashier,
                        json={"terminal_id": tid, "amount": 5_000, "uid": "audit-crash-2"})
        assert r.status_code == 502, r.text
        assert "detail" in r.json()
    finally:
        D.RUN["simulator"] = original

    with SessionLocal() as db:
        x = db.query(CardTxn).filter(CardTxn.uid == "audit-crash-2").first()
        assert x is not None
        assert x.status == "error", f"the transaction was left as {x.status}"
        assert x.finished_at is not None
        assert not db.query(CardTxn).filter(CardTxn.status == "pending").count(), "a pending row stayed behind"


def test_the_same_card_transaction_cannot_be_sent_twice(client, admin, cashier):
    from app.core.db import SessionLocal
    from app.modules.cardreader.models import PosTerminal

    with SessionLocal() as db:
        term = db.query(PosTerminal).filter(PosTerminal.driver == "simulator").first()
        if not term:
            term = PosTerminal(name="شبیه‌ساز آزمون امنیتی", psp="other", driver="simulator", is_active=True)
            db.add(term)
            db.commit()
        tid = term.id

    uid = "audit-dup-card-1"
    first = client.post("/api/cardreader/charge", headers=cashier,
                        json={"terminal_id": tid, "amount": 10_000, "uid": uid}, timeout=120)
    assert first.status_code == 200, first.text
    second = client.post("/api/cardreader/charge", headers=cashier,
                         json={"terminal_id": tid, "amount": 10_000, "uid": uid}, timeout=120)
    assert second.status_code == 400 and second.json()["detail"]["code"] == "duplicate", second.text


# ═══════════════════════════════════ 5) refunds
def test_a_cancelled_bill_cannot_be_refunded_and_a_replay_books_money_once(client, admin, cashier, mgr):
    from app.core.db import SessionLocal
    from app.modules.orders.models import Order

    item = _item(client, admin, "قهوه مرجوعی امنیتی")
    o = _closed_order(client, cashier, item)

    # idempotency: the same submission twice
    rid = "audit-sec-refund-1"
    body = {"method": "cash", "amount": 10_000, "reason": "آزمون", "request_id": rid}
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json=body).status_code == 200
    first = client.get(f"/api/orders/{o['id']}", headers=admin).json()
    assert client.post(f"/api/orders/{o['id']}/refund", headers=mgr, json=body).status_code == 200
    second = client.get(f"/api/orders/{o['id']}", headers=admin).json()
    assert first["paid_amount"] == second["paid_amount"], "a replayed refund moved money twice"

    # a cancelled bill accepts no refund
    with SessionLocal() as db:
        db.get(Order, o["id"]).status = "cancelled"
        db.commit()
    r = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": 1_000, "reason": "لغوشده"})
    assert r.status_code in (400, 409), r.text

    # more than was paid is refused
    item2 = _item(client, admin, "قهوه مرجوعی بیش از پرداخت")
    o2 = _closed_order(client, cashier, item2)
    r = client.post(f"/api/orders/{o2['id']}/refund", headers=mgr,
                    json={"method": "cash", "amount": o2["paid_amount"] + 1, "reason": "بیشتر"})
    assert r.status_code in (400, 409), r.text


# ═══════════════════════════════════ 6) stock returns
def test_returning_more_units_than_were_sold_is_refused_and_never_double_booked(client, admin, cashier, mgr):
    ing = client.post("/api/inventory/ingredients", headers=admin,
                      json={"name": "دانه برگشت امنیتی", "unit": "g", "opening_stock": 1000.0,
                            "cost_per_unit": 10, "min_stock": 0}).json()
    cats = client.get("/api/menu/categories", headers=admin).json()
    item = client.post("/api/menu/items", headers=admin,
                       json={"category_id": cats[0]["id"], "name": "قهوه برگشت امنیتی", "price": 20_000,
                             "is_active": True}).json()
    client.put(f"/api/inventory/recipes/item/{item['id']}", headers=admin,
               json=[{"ingredient_id": ing["id"], "qty": 2}]).raise_for_status()

    o = _closed_order(client, cashier, item, qty=2)
    lid = o["lines"][0]["id"]

    over = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                       json={"method": "cash", "amount": 0, "reason": "بیش از فروش",
                             "restock": [{"line_id": lid, "qty": 3}]})
    assert over.status_code in (400, 409), over.text

    ok = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                     json={"method": "cash", "amount": 0, "reason": "برگشت", "restock": [{"line_id": lid, "qty": 2}]})
    assert ok.status_code == 200, ok.text

    again = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                        json={"method": "cash", "amount": 0, "reason": "تکرار برگشت",
                              "restock": [{"line_id": lid, "qty": 1}]})
    assert again.status_code in (400, 409), "a second return of the same units must be refused"

    dup = client.post(f"/api/orders/{o['id']}/refund", headers=mgr,
                      json={"method": "cash", "amount": 0, "reason": "یک قلم دو بار",
                            "restock": [{"line_id": lid, "qty": 1}, {"line_id": lid, "qty": 1}]})
    assert dup.status_code in (400, 409), dup.text


# ═══════════════════════════════════ 7) health must notice a dead database
def test_health_reports_a_broken_database_instead_of_ok(client, monkeypatch):
    from sqlalchemy import create_engine

    import app.core.db as core_db

    healthy = client.get("/api/health")
    assert healthy.status_code == 200 and healthy.json()["status"] == "ok"
    assert healthy.json().get("db") == "ok"

    # a database that cannot be opened (the data folder vanished / the disk is gone)
    broken = create_engine("sqlite:////nonexistent-folder-cafe-audit/cafe.db")
    monkeypatch.setattr(core_db, "engine", broken)
    down = client.get("/api/health")
    assert down.status_code == 503, f"health said {down.status_code} while the database was unreachable"
    assert down.json()["status"] != "ok"
    assert down.json().get("db") == "down"


# ═══════════════════════════════════ 8) sensitive data never leaves the server
def test_staff_order_and_money_data_are_not_readable_without_the_right_permission(client, admin, cashier, waiter):
    item = _item(client, admin, "قهوه داده حساس")
    # a bill with a customer phone, so the masking rule has something to hide
    o = client.post("/api/orders", headers=cashier, json={
        "type": "takeaway", "customer_name": "مشتری آزمون", "customer_phone": "09121234567",
        "lines": [{"menu_item_id": item["id"], "qty": 1}]})
    assert o.status_code == 201, o.text
    o = o.json()
    client.post(f"/api/orders/{o['id']}/payments", headers=cashier,
                json={"payments": [{"method": "cash", "amount": o["remaining"]}]}).raise_for_status()

    for path in ("/api/orders/active", "/api/orders/floor"):
        assert client.get(path, headers=waiter).status_code == 200      # the floor screen the waiter needs
    for path in ("/api/reports/insights/tax", "/api/reports/insights/customers",
                 "/api/expenses", "/api/audit", "/api/staff/users"):
        assert client.get(path, headers=waiter).status_code in (403, 404), path

    # A waiter may search customers (that is part of taking an order), but must not read the phone numbers:
    # core/privacy.py masks them for any role without `customers.pii`.
    phones = [c["phone"] for c in client.get("/api/customers", headers=waiter).json() if c.get("phone")]
    assert phones, "the test needs at least one customer with a phone number"
    assert all("•" in p or "*" in p for p in phones), f"a waiter saw a raw phone number: {phones[:1]}"
    # …while a cashier (who has the permission) sees the number itself
    cash_phones = [c["phone"] for c in client.get("/api/customers", headers=cashier).json() if c.get("phone")]
    if cash_phones:
        assert any("•" not in p and "*" not in p for p in cash_phones)
    assert client.get("/api/customers").status_code == 401
