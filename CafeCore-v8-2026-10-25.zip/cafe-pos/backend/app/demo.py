"""Demo data: 30 days of realistic sales history + a live 'right now' state (open tables, kitchen tickets).

Runs once on an empty database when CAFE_DEMO_DATA=true. Delete data/cafe.db to start clean.
"""
import logging
import random
from datetime import datetime, time, timedelta

from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.models import User
from app.core.utils import business_day, now

log = logging.getLogger("demo")

HOUR_WEIGHTS = {8: 3, 9: 5, 10: 6, 11: 5, 12: 9, 13: 11, 14: 8, 15: 4, 16: 4, 17: 6, 18: 8, 19: 11, 20: 13, 21: 12, 22: 7, 23: 3}
CUSTOMERS = [("نیما رستمی", "09121234567", "سعادت‌آباد، خیابان سرو، پلاک ۱۲"), ("الهام نوری", "09359876543", "شهرک غرب، فلامک شمالی، واحد ۴"),
             ("کاوه صادقی", "09191112233", "ونک، خیابان ملاصدرا، کوچه دوم"), ("ترانه فرهادی", "09124445566", "پونک، بلوار عدل، برج نگین"),
             ("بهرام مقدم", "09367778899", "جردن، خیابان طاهری، پلاک ۸")]


def _pick_lines(rng, items, groups_default, hour, otype):
    cafe = [i for i in items if i.category.section == "cafe"]
    food = [i for i in items if i.category.section == "restaurant"]
    n = rng.choices([1, 2, 3, 4, 5], [25, 35, 22, 12, 6])[0]
    out = []
    for _ in range(n):
        pool = cafe if (hour < 12 or hour in (16, 17) or rng.random() < 0.45) else food
        if otype == "delivery":
            pool = food
        weights = [3 if (i.tags or "").find("پرفروش") >= 0 else 1 for i in pool]
        out.append(rng.choices(pool, weights)[0])
    return out


def _make_line(rng, OrderLine, item, groups_default):
    mods = []
    for g in item.modifier_groups:
        if g.min_select >= 1:
            opt = groups_default.get(g.id) if rng.random() < 0.75 else rng.choice(g.options)
            mods.append({"id": opt.id, "name": opt.name, "price": opt.price_delta, "group": g.name})
        elif rng.random() < 0.15 and g.options:
            opt = rng.choice(g.options)
            mods.append({"id": opt.id, "name": opt.name, "price": opt.price_delta, "group": g.name})
    return OrderLine(menu_item_id=item.id, station_id=item.station_id, name=item.name, base_price=item.price,
                     unit_price=item.price + sum(m["price"] for m in mods), qty=rng.choices([1, 2, 3], [80, 16, 4])[0],
                     modifiers=mods, status="served")


def run(db: Session) -> None:
    from app.modules.floor.models import DiningTable
    from app.modules.menu.models import MenuItem, ModifierGroup
    from app.modules.orders.models import Order, OrderLine, Payment
    from app.modules.orders.service import recalc

    if db.query(Order).count():
        return
    rng = random.Random(1405)
    users = {u.username: u for u in db.query(User).all()}
    waiters = [users[u] for u in ("ali", "maryam", "reza") if u in users]
    cashier = users.get("reza") or next(iter(users.values()))
    items = db.query(MenuItem).filter(MenuItem.is_active.is_(True)).all()
    tables = db.query(DiningTable).filter(DiningTable.is_active.is_(True)).all()
    groups_default = {g.id: next((o for o in g.options if o.is_default), g.options[0]) for g in db.query(ModifierGroup).all() if g.options}
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    today = business_day(cutoff_hour=cutoff)

    try:
        from app.modules.shifts.handlers import main_register
        from app.modules.shifts.models import Shift
        reg_id = main_register(db).id
    except ImportError:
        Shift, reg_id = None, None
    try:
        from app.modules.customers.models import Customer
    except ImportError:
        Customer = None
    cust_stats = {}
    try:
        from app.modules.kitchen.models import KitchenTicket, KitchenTicketItem
    except ImportError:
        KitchenTicket = KitchenTicketItem = None
    _demo_presets(db)

    current = now()
    for back in range(30, -1, -1):
        d = today - timedelta(days=back)
        shift = None
        if back == 0 and Shift:      # today: an open shift that already has some sales
            shift = Shift(register_id=reg_id, opened_by=cashier.id, opened_at=datetime.combine(d, time(8, 0)), opening_cash=2_000_000)
            db.add(shift)
            db.flush()
        elif Shift:
            shift = Shift(register_id=reg_id, opened_by=cashier.id, opened_at=datetime.combine(d, time(8, 0)), opening_cash=2_000_000, status="closed",
                          closed_by=cashier.id, closed_at=datetime.combine(d, time(23, 45)))
            db.add(shift)
            db.flush()
        weekend = d.weekday() in (3, 4)          # Thursday / Friday
        count = int(rng.gauss(52 if weekend else 38, 6)) + (30 - back) // 3
        cash_total = 0
        hours = rng.choices(list(HOUR_WEIGHTS), list(HOUR_WEIGHTS.values()), k=max(count, 10))
        times = sorted(datetime.combine(d, time(h, rng.randint(0, 59), rng.randint(0, 59))) for h in hours)
        if back == 0:
            times = [t for t in times if t < current - timedelta(minutes=75)]
        for num, created in enumerate(times, 1):
            hour = created.hour
            otype = rng.choices(["dine_in", "takeaway", "delivery"], [62, 28, 10])[0]
            cust = rng.choice(CUSTOMERS) if otype == "delivery" or rng.random() < 0.08 else None
            o = Order(number=num, business_date=d, type=otype, status="closed", source="pos",
                      table_id=rng.choice(tables).id if otype == "dine_in" else None, guests=rng.choices([1, 2, 3, 4, 6], [20, 40, 15, 18, 7])[0],
                      customer_name=cust[0] if cust else None, customer_phone=cust[1] if cust else None,
                      customer_address=cust[2] if cust and otype == "delivery" else None,
                      waiter_id=rng.choice(waiters).id, created_by=cashier.id, created_at=created,
                      closed_at=created + timedelta(minutes=rng.randint(15, 70)))
            for it in _pick_lines(rng, items, groups_default, hour, otype):
                ln = _make_line(rng, OrderLine, it, groups_default)
                ln.created_at = ln.sent_at = created
                o.lines.append(ln)
            if rng.random() < 0.03 and len(o.lines) > 1:
                o.lines[-1].status, o.lines[-1].void_reason, o.lines[-1].voided_by = "void", rng.choice(["اشتباه در ثبت", "مشتری منصرف شد", "تأخیر زیاد"]), users["sara"].id
            if rng.random() < 0.07:
                o.discount_type, o.discount_value, o.discount_reason = "percent", rng.choice([10, 15, 20]), rng.choice(["مشتری دائمی", "جبران تأخیر", "همکار"])
                o.discount_by = cashier.id
                o.discount_approved_by = users["sara"].id if o.discount_value > 10 and "sara" in users else None
            if rng.random() < 0.03:                    # an item discount now and then (burnt / late / manager's guest)
                ln = rng.choice(o.lines)
                if ln.status != "void":
                    ln.discount_type, ln.discount_value = "percent", rng.choice([100, 50, 20])
                    ln.discount_reason = {100: "آیتم معیوب / سوخته", 50: "جبران تأخیر / نارضایتی", 20: "مشتری دائمی"}[ln.discount_value]
                    ln.discount_by = cashier.id
                    ln.discount_approved_by = users["sara"].id if ln.discount_value > 10 and "sara" in users else None
            db.add(o)
            recalc(db, o)
            if KitchenTicket:
                _demo_tickets(db, rng, o, created, KitchenTicket, KitchenTicketItem)
            method = rng.choices(["card", "cash", "online"], [68, 25, 7])[0]
            if rng.random() < 0.08 and o.total > 400_000:
                part = round(o.total * 0.4 / 1000) * 1000
                pays = [("cash", part), ("card", o.total - part)]
            else:
                pays = [(method, o.total)]
            for m, amt in pays:
                o.payments.append(Payment(method=m, amount=amt, shift_id=shift.id if shift else None, created_by=cashier.id, created_at=o.closed_at))
                if m == "cash":
                    cash_total += amt
            o.paid_amount = o.total
            if cust:
                st = cust_stats.setdefault(cust[1], [cust, 0, 0, None])
                st[1] += 1
                st[2] += o.total
                st[3] = o.closed_at
        # a cancelled order now and then
        if back > 0 and rng.random() < 0.3:
            db.add(Order(number=len(times) + 1, business_date=d, type="takeaway", status="cancelled", created_by=cashier.id,
                         created_at=datetime.combine(d, time(rng.randint(10, 22), 10)), cancel_reason="مشتری منصرف شد",
                         cancelled_at=datetime.combine(d, time(rng.randint(10, 22), 20)), waiter_id=cashier.id))
        if shift and back > 0:
            db.flush()
            from app.modules.shifts.router import compute
            shift.summary = compute(db, shift)
            shift.expected_cash = shift.summary["expected_cash"]
            shift.counted_cash = shift.expected_cash + rng.choice([0, 0, 0, -20_000, 10_000, -50_000])
        db.flush()

    if Customer:
        for phone, (c, visits, spent, last) in cust_stats.items():
            db.add(Customer(name=c[0], phone=phone, address=c[2], visits=visits, total_spent=spent, last_visit=last))

    _extras(db, rng, users, today)

    # make a couple of ingredients low so alerts show up
    try:
        from app.modules.inventory.models import Ingredient
        for ing in db.query(Ingredient).filter(Ingredient.name.in_(["چیزکیک (برش)", "نعناع تازه", "سیروپ فندق"])).all():
            ing.stock = round(ing.min_stock * 0.6)
    except ImportError:
        pass
    db.commit()
    _live(db, rng, users, items, tables, groups_default)
    log.info("demo data created")


def _extras(db: Session, rng, users, today) -> None:
    """Purchase invoices and an audit trail so the admin pages look lived-in."""
    from app.core.models import AuditLog
    try:
        from app.modules.inventory.models import (
            Ingredient,
            Purchase,
            PurchaseLine,
            Supplier,
        )
        sups = db.query(Supplier).order_by(Supplier.id).all()
        ings = db.query(Ingredient).all()
        for k in range(9):
            d = today - timedelta(days=3 * k + 1)
            sup = sups[k % len(sups)] if sups else None
            p = Purchase(supplier_id=sup.id if sup else None, invoice_no=str(4100 + k * 7), purchase_date=d, created_by=users["sara"].id,
                         created_at=datetime.combine(d, time(10, 30)))
            for ing in rng.sample(ings, min(len(ings), rng.randint(2, 5))):
                qty = {"g": 5000, "ml": 10000, "kg": 10, "l": 10, "pcs": 50}.get(ing.unit, 10) * rng.choice([1, 2])
                p.lines.append(PurchaseLine(ingredient_id=ing.id, qty=qty, unit_cost=round(ing.cost_per_unit * rng.uniform(0.95, 1.05), 2)))
            p.total = round(sum(ln.qty * ln.unit_cost for ln in p.lines))
            db.add(p)
    except ImportError:
        pass
    sara, reza, admin = users["sara"], users["reza"], users["admin"]
    events = [
        (reza, sara, "order.void", "ابطال «کاپوچینو» از سفارش #۴۲ — اشتباه در ثبت"),
        (reza, sara, "order.discount", "تخفیف ۱۵٪ روی سفارش #۵۷ — مشتری دائمی"),
        (sara, None, "menu.update", "تغییر قیمت «پاستا آلفردو» از ۳۲۰,۰۰۰ به ۳۴۵,۰۰۰ تومان"),
        (sara, None, "inventory.waste", "ثبت ضایعات ۲ لیتر «شیر» — تاریخ گذشته"),
        (reza, None, "shift.close", "بستن شیفت صندوق — مغایرت ۲۰,۰۰۰- تومان"),
        (reza, sara, "order.cancel", "لغو سفارش #۱۸ — مشتری منصرف شد"),
        (admin, None, "user.create", "ایجاد کاربر «مریم احمدی»"),
        (sara, None, "inventory.purchase", "ثبت فاکتور خرید ۴۱۲۱"),
        (reza, sara, "order.refund", "بازپرداخت ۸۵,۰۰۰ تومان سفارش #۳۳ — کیفیت نامناسب"),
        (admin, None, "settings.update", "ویرایش تنظیمات (مالیات و سرویس)"),
    ]
    for k in range(30):
        u, ap, act, summ = events[k % len(events)]
        at = datetime.combine(today - timedelta(days=k // 2), time(rng.randint(10, 22), rng.randint(0, 59)))
        db.add(AuditLog(user_id=u.id, user_name=u.full_name, approver_name=ap.full_name if ap else None, action=act, summary=summ, created_at=at))


def _live(db: Session, rng, users, items, tables, groups_default) -> None:
    """Open shift + a few busy tables right now, so POS / KDS have something to show."""
    from app.modules.orders import service
    from app.modules.orders.schemas import LineIn, OrderCreate

    cashier = users.get("reza")
    try:
        from app.modules.shifts.handlers import main_register
        from app.modules.shifts.models import Shift
        if not db.query(Shift).filter(Shift.status == "open").first():
            db.add(Shift(register_id=main_register(db).id, opened_by=cashier.id, opened_at=now() - timedelta(hours=3), opening_cash=2_000_000))
            db.flush()
    except ImportError:
        pass

    def line(it):
        req = [groups_default[g.id].id for g in it.modifier_groups if g.min_select >= 1 and g.id in groups_default]
        return LineIn(menu_item_id=it.id, qty=rng.choice([1, 1, 2]), modifier_option_ids=req)

    by_code = {i.code: i for i in items}
    plans = [(0, ["104", "103", "901"], 2, "ali", 34), (2, ["802", "701", "203"], 3, "maryam", 18), (4, ["801", "501", "204", "204"], 4, "ali", 9),
             (7, ["101", "102"], 2, "maryam", 4), (13, ["303", "105", "302"], 2, "ali", 26)]
    for idx, codes, guests, waiter, minutes_ago in plans:
        if idx >= len(tables):
            continue
        o = service.create_order(db, OrderCreate(type="dine_in", table_id=tables[idx].id, guests=guests, waiter_id=users[waiter].id,
                                                 lines=[line(by_code[c]) for c in codes if c in by_code], send=True), users[waiter])
        db.flush()
        t = now() - timedelta(minutes=minutes_ago)
        o.created_at = t
        for l in o.lines:
            l.created_at = l.sent_at = t
        try:
            from app.modules.kitchen.models import KitchenTicket
            for k in db.query(KitchenTicket).filter(KitchenTicket.order_id == o.id).all():
                k.created_at = t
                if minutes_ago > 20:
                    k.status = "preparing"
        except ImportError:
            pass
        db.commit()
    # takeaway waiting
    service.create_order(db, OrderCreate(type="takeaway", customer_name="آرش", lines=[line(by_code["202"]), line(by_code["402"])], send=True), cashier)
    db.commit()


def _demo_tickets(db, rng, o, created, KitchenTicket, KitchenTicketItem) -> None:
    """Finished kitchen tickets with realistic timings so the kitchen-speed report has data."""
    db.flush()
    by_station = {}
    for ln in o.lines:
        if ln.station_id and ln.status != "void":
            by_station.setdefault(ln.station_id, []).append(ln)
    for station_id, lines in by_station.items():
        name = _station_names(db).get(station_id, "")
        base = 5 if "بار" in name else 14 if "گرم" in name else 8  # the coffee bar is quicker than the hot kitchen
        busy = 1.4 if created.hour in (13, 14, 20, 21) else 1.0
        prep = max(2.0, rng.gauss(base * busy, base * 0.35))
        start = created + timedelta(minutes=rng.uniform(0.3, 2.5))
        ready = created + timedelta(minutes=prep)
        t = KitchenTicket(order_id=o.id, station_id=station_id, order_number=o.number, order_type=o.type, status="done",
                          created_at=created, started_at=min(start, ready), ready_at=ready, done_at=ready + timedelta(minutes=2))
        t.items = [KitchenTicketItem(order_line_id=ln.id, name=ln.name, qty=ln.qty, is_done=True) for ln in lines]
        db.add(t)


_STATIONS: dict = {}


def _station_names(db) -> dict:
    if not _STATIONS:
        from app.modules.menu.models import Station
        _STATIONS.update({s.id: s.name for s in db.query(Station).all()})
    return _STATIONS


def _demo_presets(db) -> None:
    try:
        from app.modules.orders.models import DiscountPreset
    except ImportError:
        return
    if db.query(DiscountPreset).count():
        return
    for i, p in enumerate([
        dict(name="کارمندی", kind="percent", value=20, scope="order", color="#0ea5e9", reason_required=True),
        dict(name="هپی‌آور عصر", kind="percent", value=15, scope="order", start_time="16:00", end_time="19:00", color="#f59e0b"),
        dict(name="جبران تأخیر", kind="percent", value=10, scope="order", max_amount=200_000, color="#9333ea"),
        dict(name="مهمان مدیریت", kind="percent", value=100, scope="both", requires_manager=True, reason_required=True, color="#e11d48"),
        dict(name="آیتم معیوب", kind="percent", value=100, scope="item", reason_required=True, color="#64748b"),
        dict(name="تخفیف دلخواه مبلغی", kind="amount", value=0, scope="order", color="#16a34a"),
    ]):
        db.add(DiscountPreset(sort=i, **p))
    # automatic / promo-code / buy-X-get-Y / combo examples
    from datetime import timedelta

    from app.core.utils import now
    from app.modules.menu.models import MenuCategory
    cat = {c.name: c.id for c in db.query(MenuCategory).all()}
    ids = lambda *names: [cat[n] for n in names if n in cat]  # noqa: E731
    for i, p in enumerate([
        dict(name="هپی‌آور نوشیدنی سرد", kind="percent", value=20, scope="item", auto_apply=True, start_time="16:00", end_time="19:00",
             target_category_ids=ids("نوشیدنی سرد"), color="#0ea5e9"),
        dict(name="پیتزای دوم نیم‌بها", kind="bogo", value=50, scope="order", buy_qty=1, get_qty=1, target_category_ids=ids("پیتزا"),
             color="#f97316"),
        dict(name="قهوه و کیک", kind="combo", value=320_000, scope="order", color="#a16207",
             combo_parts=[{"category_ids": ids("قهوه گرم"), "item_ids": [], "qty": 1}, {"category_ids": ids("دسر و کیک"), "item_ids": [], "qty": 1}]),
        dict(name="خوش‌آمد مشتری جدید", kind="percent", value=20, scope="order", code="WELCOME20", max_amount=150_000,
             per_customer_limit=1, valid_to=(now() + timedelta(days=60)).date(), color="#9333ea"),
    ], start=10):
        db.add(DiscountPreset(sort=i, **p))