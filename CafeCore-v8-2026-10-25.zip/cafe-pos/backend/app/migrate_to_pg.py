"""Move a cafe database from SQLite (the default) to PostgreSQL — one time, all or nothing, verified.

    python -m app.migrate_to_pg --target "postgresql+psycopg://cafe:PASS@127.0.0.1/cafe"          # source: data/cafe.db
    python -m app.migrate_to_pg --source D:\\cafe\\data\\cafe.db --target "..." --yes

Steps
  1. Snapshot the SQLite file with SQLite's backup API (consistent even if a write is in flight; the original file is
     only read). Stop the server first anyway — anything written after the snapshot would not be moved.
  2. Bring the snapshot's schema up to this version (additive, on the snapshot only), create the schema on PostgreSQL.
     The target database must be empty.
  3. Pre-check data SQLite accepts but PostgreSQL refuses (text longer than its column, NUL characters) and list it.
  4. Copy every table in foreign-key order, move the id sequences past the copied ids, and verify: row count of every
     table and the sum of every integer column (money, quantities, counters) must match. Schema, copy and
     verification are ONE PostgreSQL transaction — any error or mismatch → nothing at all is written.
Then set CAFE_DATABASE_URL to the target and start the server. Files in data/ (uploads, keys) stay where they are.
"""
from __future__ import annotations

import argparse
import sqlite3
import sys
import tempfile
from pathlib import Path

from sqlalchemy import Integer, String, create_engine, func, inspect, select, text
from sqlalchemy.engine import Engine

BATCH = 500


class MigrationError(RuntimeError):
    pass


def _metadata():
    from app.core import models as _core  # noqa: F401  (register core tables)
    from app.core.config import get_settings
    from app.core.db import Base
    from app.core.modules import registry
    registry.discover(get_settings().enabled_modules)
    return Base.metadata


def snapshot(src: Path, dest: Path) -> None:
    if not src.exists():
        raise MigrationError(f"source database not found: {src}")
    with sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True) as a, sqlite3.connect(dest) as b:
        a.backup(b)


def _int_columns(table) -> list:
    return [c for c in table.columns if isinstance(c.type, Integer) and not c.primary_key]


def precheck(src: Engine, metadata, tables: set[str]) -> list[str]:
    """Values PostgreSQL would reject although SQLite stored them."""
    problems = []
    with src.connect() as c:
        for t in metadata.sorted_tables:
            if t.name not in tables:
                continue
            for col in t.columns:
                if not isinstance(col.type, String):
                    continue
                if col.type.length:
                    n = c.execute(select(func.count()).where(func.length(col) > col.type.length)).scalar()
                    if n:
                        problems.append(f"{t.name}.{col.name}: {n} value(s) longer than {col.type.length} characters")
                n = c.execute(select(func.count()).where(func.instr(col, "\x00") > 0)).scalar()
                if n:
                    problems.append(f"{t.name}.{col.name}: {n} value(s) contain a NUL character")
    return problems


def copy(s, d, src: Engine, metadata, tables: set[str], log=print) -> dict[str, int]:
    """s: SQLite connection, d: PostgreSQL connection inside the migration transaction."""
    copied: dict[str, int] = {}
    for t in metadata.sorted_tables:
        if t.name not in tables:
            copied[t.name] = 0
            continue
        have = {c["name"] for c in inspect(src).get_columns(t.name)}
        cols = [c for c in t.columns if c.name in have]
        pk = list(t.primary_key.columns)
        q = select(*cols).order_by(*pk) if pk else select(*cols)
        n = 0
        batch: list[dict] = []
        for row in s.execute(q).mappings():
            batch.append(dict(row))
            if len(batch) >= BATCH:
                d.execute(t.insert(), batch)
                n += len(batch)
                batch = []
        if batch:
            d.execute(t.insert(), batch)
            n += len(batch)
        copied[t.name] = n
        if n:
            log(f"  {t.name}: {n}")
    # sequences: next id after the copied ones (tables without a serial id return NULL and are ignored)
    for t in metadata.sorted_tables:
        pk = list(t.primary_key.columns)
        if len(pk) == 1 and isinstance(pk[0].type, Integer) and pk[0].autoincrement in (True, "auto"):
            d.execute(text(f"SELECT setval(pg_get_serial_sequence(:t, :c), COALESCE((SELECT MAX(\"{pk[0].name}\") FROM \"{t.name}\"), 0) + 1, false)"),
                      {"t": t.name, "c": pk[0].name})
    return copied


def verify(s, d, metadata, tables: set[str]) -> list[str]:
    diffs = []
    for t in metadata.sorted_tables:
        if t.name not in tables:
            continue
        a = s.execute(select(func.count()).select_from(t)).scalar()
        b = d.execute(select(func.count()).select_from(t)).scalar()
        if a != b:
            diffs.append(f"{t.name}: {a} rows in SQLite, {b} in PostgreSQL")
            continue
        ints = _int_columns(t)
        if not ints:
            continue
        sa = s.execute(select(*[func.coalesce(func.sum(c), 0) for c in ints])).one()
        sb = d.execute(select(*[func.coalesce(func.sum(c), 0) for c in ints])).one()
        for c, x, y in zip(ints, sa, sb, strict=True):
            if int(x) != int(y):
                diffs.append(f"{t.name}.{c.name}: sum {x} in SQLite, {y} in PostgreSQL")
    return diffs


def migrate(source: Path, target_url: str, log=print) -> dict:
    if not target_url.startswith("postgresql"):
        raise MigrationError("target must be a postgresql+psycopg:// URL")
    metadata = _metadata()
    from app.core.migrate import upgrade
    with tempfile.TemporaryDirectory() as tmp:
        snap = Path(tmp) / "snapshot.db"
        log(f"1/5 snapshot of {source}")
        snapshot(source, snap)
        src = create_engine(f"sqlite:///{snap.as_posix()}")
        dst = create_engine(target_url, pool_pre_ping=True)
        try:
            log("2/5 schema + pre-check")
            upgrade(src, metadata)                      # the snapshot only — never the original
            tables = set(inspect(src).get_table_names())
            problems = precheck(src, metadata, tables)
            if problems:
                raise MigrationError("data PostgreSQL would refuse — fix these in the app first:\n  " + "\n  ".join(problems))
            # one PostgreSQL transaction (DDL is transactional there): schema, copy, sequences, verification
            with src.connect() as s, dst.begin() as d:
                metadata.create_all(d)
                busy = [(t.name, n) for t in metadata.sorted_tables if (n := d.execute(select(func.count()).select_from(t)).scalar())]
                if busy:
                    raise MigrationError("target database is not empty (" + ", ".join(f"{k}: {v}" for k, v in busy[:5])
                                         + ") — use a new empty database")
                log("3/5 copy")
                copied = copy(s, d, src, metadata, tables, log)
                log("4/5 verify")
                diffs = verify(s, d, metadata, tables)
                if diffs:
                    raise MigrationError("verification failed:\n  " + "\n  ".join(diffs))
                log("5/5 commit")
            return {"tables": len([t for t in copied if t in tables]), "rows": sum(copied.values())}
        finally:
            src.dispose()
            dst.dispose()


def main(argv=None) -> int:
    from app.core.config import get_settings
    ap = argparse.ArgumentParser(prog="python -m app.migrate_to_pg", description="Copy the SQLite database to an empty PostgreSQL database.")
    ap.add_argument("--source", type=Path, default=get_settings().data_dir / "cafe.db", help="SQLite file (default: data/cafe.db)")
    ap.add_argument("--target", required=True, help="postgresql+psycopg://user:pass@host/dbname (must be empty)")
    ap.add_argument("--yes", action="store_true", help="don't ask for confirmation")
    a = ap.parse_args(argv)
    if not a.yes:
        print("Stop the cafe server first: anything written after the snapshot is not moved.")
        if input("Continue? [y/N] ").strip().lower() not in ("y", "yes"):
            return 1
    try:
        res = migrate(a.source, a.target)
    except MigrationError as e:
        print(f"\nFAILED — nothing was written to the target.\n{e}", file=sys.stderr)
        return 2
    print(f"\nDONE: {res['rows']} rows in {res['tables']} tables copied and verified.")
    print("Next: set CAFE_DATABASE_URL to the target URL and start the server. Keep data/cafe.db as a backup.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
