"""Server launcher used by start.bat / run.sh:  python -m app.serve [--port 8000] [--open]

Plain HTTP by default. With CAFE_HTTPS=true it creates/renews the local certificates (app/core/tls.py) and serves
HTTPS on the same port; --open launches the browser at the right address once the server is up.
"""
import argparse
import os
import threading
import webbrowser

import uvicorn

from app.core.config import get_settings


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--open", action="store_true", help="open the browser after startup")
    args = ap.parse_args()
    if args.port:
        os.environ["CAFE_PORT"] = str(args.port)      # banner / LAN URLs use the real port
    s = get_settings()
    port = s.port
    ssl = {}
    if s.https:
        from app.core.tls import ensure_certs
        from app.modules.system.router import lan_addresses
        paths = ensure_certs(s.data_dir, lan_addresses())
        ssl = {"ssl_certfile": str(paths["cert"]), "ssl_keyfile": str(paths["key"])}
    if args.open:
        url = f"{'https' if s.https else 'http'}://localhost:{port}"
        threading.Timer(4, lambda: webbrowser.open(url)).start()
    uvicorn.run("app.main:app", host=s.host, port=port, proxy_headers=False,
                server_header=False, **ssl)      # do not advertise the framework/version


if __name__ == "__main__":
    main()
