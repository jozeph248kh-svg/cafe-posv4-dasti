"""Brute-force protection for login, PIN login and manager-PIN overrides.

A 4-digit PIN has only 10 000 combinations, so failed attempts are counted per key (IP, IP+username, user) inside a
sliding window; once the limit is reached further attempts are refused with 429 until the window expires.

The counters live in memory (single-process server) and are mirrored to `data/login_failures.json` (atomic write),
so restarting the server does NOT reset a lock-out. A file is used instead of the database on purpose: login runs
inside a write transaction, and a second connection writing to SQLite from the same request would wait on itself.
"""
import json
import logging
import os
import threading
import time
from collections import defaultdict, deque

from fastapi import status

from .config import get_settings
from .errors import AppError

log = logging.getLogger("cafe")
_lock = threading.Lock()
_fails: dict[str, deque] = defaultdict(deque)
_loaded = False


def _path():
    return get_settings().data_dir / "login_failures.json"


def _load() -> None:
    """Once per process: read the persisted failures (still inside the window)."""
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return
    except (OSError, ValueError) as e:
        log.warning("login_failures.json unreadable, starting empty: %s", e)
        return
    window, t = get_settings().login_window_sec, time.time()
    for k, ts in (raw if isinstance(raw, dict) else {}).items():
        q = deque(sorted(float(x) for x in ts if isinstance(x, (int, float)) and t - float(x) <= window))
        if q:
            _fails[k] = q


def _save() -> None:
    p = _path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps({k: list(q) for k, q in _fails.items() if q}), encoding="utf-8")
        os.replace(tmp, p)
    except OSError as e:                      # never block a login because the disk is unhappy
        log.warning("could not persist login failures: %s", e)


def _prune(q: deque, now: float, window: int) -> None:
    while q and now - q[0] > window:
        q.popleft()


def check(*keys: str) -> None:
    s = get_settings()
    t = time.time()
    with _lock:
        _load()
        for k in keys:
            q = _fails.get(k)
            if not q:
                continue
            _prune(q, t, s.login_window_sec)
            if len(q) >= s.login_max_failures:
                wait = int(s.login_window_sec - (t - q[0])) + 1
                raise AppError(f"تلاش‌های ناموفق زیاد بود؛ {max(wait // 60, 1)} دقیقه دیگر دوباره تلاش کنید",
                               status.HTTP_429_TOO_MANY_REQUESTS, "too_many_attempts", retry_after=wait)


def fail(*keys: str) -> None:
    t = time.time()
    window = get_settings().login_window_sec
    with _lock:
        _load()
        for k in keys:
            _fails[k].append(t)
        for q in _fails.values():
            _prune(q, t, window)
        for k in [k for k, q in _fails.items() if not q]:
            del _fails[k]
        _save()


def success(*keys: str) -> None:
    with _lock:
        _load()
        if any(_fails.pop(k, None) for k in keys):
            _save()


def reset() -> None:          # tests
    with _lock:
        _fails.clear()
        _save()


def forget_memory() -> None:  # tests: simulate a server restart (memory gone, file stays)
    global _loaded
    with _lock:
        _fails.clear()
        _loaded = False


def client_ip(request) -> str:
    return (request.client.host if request and request.client else "?") or "?"
