from fastapi import HTTPException, status


class AppError(HTTPException):
    """HTTP error with a machine-readable `code` (used by the frontend)."""

    def __init__(self, message: str, status_code: int = status.HTTP_400_BAD_REQUEST, code: str = "error", **extra):
        super().__init__(status_code=status_code, detail={"message": message, "code": code, **extra})


def not_found(what: str = "مورد") -> AppError:
    return AppError(f"{what} یافت نشد", status.HTTP_404_NOT_FOUND, "not_found")
