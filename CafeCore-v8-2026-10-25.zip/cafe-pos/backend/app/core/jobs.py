"""Periodic background jobs declared by modules: `Module(jobs=[Job("sms.send", 5, fn)])`.

Each run gets its own DB session; a failing job is logged and retried on the next tick, never crashing the server.
Jobs run in a worker thread so slow network calls (SMS, tax system, central server) never block the event loop.
"""
import asyncio
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field

from sqlalchemy.orm import Session

log = logging.getLogger("jobs")


@dataclass
class Job:
    name: str
    every: float                       # seconds between runs
    fn: Callable[[Session], None]
    last_run: float = field(default=0.0, repr=False)
    last_error: str | None = field(default=None, repr=False)


_tasks: list[asyncio.Task] = []


def run_job(job: Job) -> None:
    from app.core.db import SessionLocal
    with SessionLocal() as db:
        try:
            job.fn(db)
            db.commit()
            job.last_error = None
        except Exception as e:  # noqa: BLE001
            db.rollback()
            job.last_error = str(e)[:300]
            log.exception("job %s failed", job.name)
    job.last_run = time.time()


async def _loop(job: Job) -> None:
    await asyncio.sleep(3)
    while True:
        await asyncio.to_thread(run_job, job)
        await asyncio.sleep(job.every)


def start(jobs: list[Job]) -> None:
    for j in jobs:
        _tasks.append(asyncio.create_task(_loop(j), name=f"job:{j.name}"))
    if jobs:
        log.info("background jobs: %s", ", ".join(j.name for j in jobs))


async def stop() -> None:
    for t in _tasks:
        t.cancel()
    _tasks.clear()
