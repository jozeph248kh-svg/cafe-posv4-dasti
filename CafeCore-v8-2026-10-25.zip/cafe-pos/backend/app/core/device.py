"""Per-device context sent by the browser: which cash register (drawer) this device works on.

The POS stores the chosen register in localStorage and sends `X-Register-Id` with every request; payments and cash
movements then go to that register's open shift. No header → the main register (single-register cafes never notice).
"""
from contextvars import ContextVar

INVALID = -1
device_register: ContextVar[int | None] = ContextVar("device_register", default=None)


class DeviceMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        raw = next((v for k, v in scope.get("headers") or [] if k == b"x-register-id"), None)
        val = None
        if raw is not None and raw.strip():
            try:
                val = int(raw)
                if val <= 0 or val > 2**31:
                    val = INVALID
            except ValueError:
                val = INVALID
        token = device_register.set(val)
        try:
            await self.app(scope, receive, send)
        finally:
            device_register.reset(token)
