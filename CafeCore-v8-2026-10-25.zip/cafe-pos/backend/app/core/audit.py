from sqlalchemy.orm import Session

from .models import AuditLog, User


def log_action(db: Session, user: User | None, action: str, summary: str, *, entity: str | None = None,
               entity_id=None, details: dict | None = None, approver: User | None = None) -> None:
    db.add(AuditLog(
        user_id=user.id if user else None,
        user_name=user.full_name if user else None,
        approver_name=approver.full_name if approver and (not user or approver.id != user.id) else None,
        action=action, entity=entity, entity_id=str(entity_id) if entity_id is not None else None,
        summary=summary, details=details,
    ))
