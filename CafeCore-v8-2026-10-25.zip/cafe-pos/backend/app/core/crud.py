from typing import TypeVar

from sqlalchemy.orm import Session

from .errors import not_found

T = TypeVar("T")


def get_or_404(db: Session, model: type[T], obj_id, what: str = "مورد") -> T:
    obj = db.get(model, obj_id)
    if obj is None:
        raise not_found(what)
    return obj
