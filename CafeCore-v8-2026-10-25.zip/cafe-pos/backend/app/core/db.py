"""Database engine, session factory and declarative base.

Concurrency model (SQLite): reads run concurrently (WAL). Every *mutating* HTTP request opens its transactions with
`BEGIN IMMEDIATE`, which takes SQLite's single write lock before the first read — so two devices can never both read
the same order/stock/balance and then write conflicting results (lost update, double payment, duplicate order number).
Other writers wait (busy_timeout) instead of failing. See `write_intent` / `WriteIntentMiddleware`.
"""
from collections.abc import Iterator
from contextvars import ContextVar
from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, MetaData, create_engine, event, func
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from .config import get_settings

NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, server_default=func.now())


write_intent: ContextVar[bool] = ContextVar("write_intent", default=False)


@compiles(Integer, "postgresql")
def _pg_integer(type_, compiler, **kw):
    # SQLite integers are 64-bit; money (toman, up to 10^12) and counters must have the same range on PostgreSQL,
    # whose INTEGER is 32-bit. Only table columns (DDL) are widened — casts in queries keep INTEGER.
    # Auto-increment primary keys still use SERIAL.
    return "BIGINT" if isinstance(kw.get("type_expression"), Column) else compiler.visit_integer(type_, **kw)


PG_WRITE_LOCK = 7_420_001          # advisory-lock key shared by all write requests on PostgreSQL


def _make_engine(url: str):
    is_sqlite = url.startswith("sqlite")
    eng = create_engine(
        url,
        connect_args={"check_same_thread": False, "timeout": 30} if is_sqlite else {},
        pool_pre_ping=True,
    )
    if is_sqlite:
        @event.listens_for(eng, "connect")
        def _sqlite_pragmas(dbapi_conn, _):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")      # concurrent readers + one writer (multi-device)
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA busy_timeout=30000")
            cur.close()

        @event.listens_for(eng, "begin")
        def _begin(conn):
            # pysqlite starts transactions lazily (only before DML). For write requests start one eagerly and
            # IMMEDIATE so the reads that precede the writes are serialised with other writers.
            if write_intent.get():
                conn.exec_driver_sql("BEGIN IMMEDIATE")
    elif eng.dialect.name == "postgresql":
        @event.listens_for(eng, "begin")
        def _pg_begin(conn):
            # Same guarantee as SQLite's BEGIN IMMEDIATE: write requests run one at a time, so read-then-write logic
            # (order numbers, payments, stock, balances) can't interleave. Released automatically at COMMIT/ROLLBACK.
            if write_intent.get():
                conn.exec_driver_sql("SELECT pg_advisory_xact_lock(%s)" % PG_WRITE_LOCK)
    return eng


engine = _make_engine(get_settings().db_url)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
