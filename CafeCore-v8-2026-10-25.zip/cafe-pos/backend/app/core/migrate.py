"""Additive schema migrations (SQLite and PostgreSQL).

`create_all()` creates missing tables but never touches existing ones, so a new column in an upgraded version would
crash an existing install. `upgrade()` compares the models with the live database and only ADDS what is missing:
new nullable/defaulted columns and new indexes. It never drops, renames or rewrites data. A backup is taken
automatically before the first change. Destructive changes must be written as explicit, reviewed scripts.
"""
import logging

from sqlalchemy import Engine, inspect, text
from sqlalchemy.schema import CreateIndex

log = logging.getLogger("migrate")


def _default_sql(col, dialect=None) -> str | None:
    if col.server_default is not None:
        arg = col.server_default.arg
        if isinstance(arg, str):
            return arg
        if hasattr(arg, "text"):
            return arg.text
        return str(arg.compile(dialect=dialect))          # e.g. false() → 0 on SQLite, false on PostgreSQL
    d = col.default
    if d is not None and d.is_scalar:
        v = d.arg
        if isinstance(v, bool):
            return ("true" if v else "false") if dialect is not None and dialect.name == "postgresql" else ("1" if v else "0")
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, str):
            return "'" + v.replace("'", "''") + "'"
    return None


def plan(engine: Engine, metadata) -> list[str]:
    insp = inspect(engine)
    tables = set(insp.get_table_names())
    stmts: list[str] = []
    for table in metadata.sorted_tables:
        if table.name not in tables:
            continue                       # create_all() handles brand-new tables
        have = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in have:
                continue
            ddl = f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {engine.dialect.type_compiler_instance.process(col.type, type_expression=col)}'
            default = _default_sql(col, engine.dialect)
            if default is not None:
                ddl += f" DEFAULT {default}"
            elif not col.nullable:
                raise RuntimeError(f"cannot add NOT NULL column without default: {table.name}.{col.name}")
            stmts.append(ddl)
        idx_have = {i["name"] for i in insp.get_indexes(table.name)}
        for idx in table.indexes:
            if idx.name not in idx_have:
                stmts.append(str(CreateIndex(idx).compile(engine)).replace("CREATE INDEX", "CREATE INDEX IF NOT EXISTS")
                             .replace("CREATE UNIQUE INDEX", "CREATE UNIQUE INDEX IF NOT EXISTS"))
    return stmts


def upgrade(engine: Engine, metadata, backup=None) -> list[str]:
    if engine.dialect.name not in ("sqlite", "postgresql"):
        return []
    stmts = plan(engine, metadata)
    if not stmts:
        return []
    if backup:
        path = backup("pre-upgrade")
        log.warning("schema upgrade: backup saved to %s", path)
    with engine.begin() as conn:
        for s in stmts:
            log.warning("schema upgrade: %s", s)
            if s.startswith("CREATE UNIQUE INDEX"):
                # existing rows may violate a new uniqueness rule: never block start-up or touch data — report it
                try:
                    with conn.begin_nested():
                        conn.execute(text(s))
                except Exception as e:  # noqa: BLE001
                    log.error("schema upgrade: unique index NOT created, existing rows have duplicates (review them): %s",
                              str(e).splitlines()[0])
                continue
            conn.execute(text(s))
    return stmts
