"""Plug-in module system.

Each package in `app/modules/` exposes a `module = Module(...)` object in its `__init__.py`.
The loader discovers them, resolves dependencies, mounts routers under `/api/<name>`,
registers permissions and event handlers. To add a feature, drop in a new module package.
"""
import importlib
import logging
import pkgutil
from collections.abc import Callable
from dataclasses import dataclass, field

from fastapi import APIRouter, FastAPI
from sqlalchemy.orm import Session

log = logging.getLogger("modules")


@dataclass
class Module:
    name: str
    title: str
    version: str = "1.0.0"
    description: str = ""
    depends: list[str] = field(default_factory=list)
    routers: list[APIRouter] = field(default_factory=list)
    permissions: dict[str, str] = field(default_factory=dict)   # code -> Persian title
    seed: Callable[[Session], None] | None = None               # base data on first install
    demo: Callable[[Session], None] | None = None               # optional demo data
    setup: Callable[[], None] | None = None                     # subscribe events etc.
    jobs: list = field(default_factory=list)                    # app.core.jobs.Job — periodic background work
    core: bool = False                                          # cannot be disabled


class Registry:
    def __init__(self) -> None:
        self.modules: dict[str, Module] = {}

    def discover(self, enabled: str = "*") -> list[Module]:
        import app.modules as pkg

        found: dict[str, Module] = {}
        for info in pkgutil.iter_modules(pkg.__path__):
            mod = importlib.import_module(f"app.modules.{info.name}")
            m: Module | None = getattr(mod, "module", None)
            if m:
                found[m.name] = m

        wanted = set(found) if enabled.strip() == "*" else {x.strip() for x in enabled.split(",")}
        wanted |= {n for n, m in found.items() if m.core}

        # resolve dependencies (topological order)
        ordered: list[Module] = []
        visiting: set[str] = set()

        def visit(name: str) -> None:
            if name in self.modules:
                return
            if name not in found:
                raise RuntimeError(f"Module dependency '{name}' not found")
            if name in visiting:
                raise RuntimeError(f"Circular module dependency at '{name}'")
            visiting.add(name)
            for dep in found[name].depends:
                visit(dep)
            self.modules[name] = found[name]
            ordered.append(found[name])

        for name in sorted(wanted):
            visit(name)
        return ordered

    def mount(self, app: FastAPI) -> None:
        for m in self.modules.values():
            if m.setup:
                m.setup()
            for r in m.routers:
                app.include_router(r, prefix=f"/api/{m.name}", tags=[m.title])
            log.info("module loaded: %s v%s", m.name, m.version)

    @property
    def jobs(self) -> list:
        return [j for m in self.modules.values() for j in m.jobs]

    @property
    def permissions(self) -> dict[str, dict[str, str]]:
        return {m.name: {"title": m.title, "items": m.permissions} for m in self.modules.values() if m.permissions}

    def all_permission_codes(self) -> set[str]:
        return {code for m in self.modules.values() for code in m.permissions}


registry = Registry()
