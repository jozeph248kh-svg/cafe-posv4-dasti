"""Realtime hub: pushes events to every connected device (POS, KDS, waiter phones) over WebSocket.

`publish()` is thread-safe and can be called from sync endpoints. Messages queued on a DB session via
`publish_after_commit()` are only sent once the transaction commits successfully.
"""
import asyncio
import json
import logging
import threading
from typing import Any

from fastapi import WebSocket
from sqlalchemy import event
from sqlalchemy.orm import Session

log = logging.getLogger("realtime")


# Topics with personal/business data are only delivered to devices whose user may see them (any of the permissions).
# Topics not listed (order/floor/menu/kitchen changes) carry only ids/statuses and go to every logged-in device.
TOPIC_PERMS: dict[str, tuple[str, ...]] = {
    "customer.": ("customers.manage", "loyalty.manage", "pos.access"),
    "online.": ("online.manage", "pos.access"),
    "market.": ("market.orders", "market.manage"),
    "delivery.": ("delivery.dispatch", "delivery.manage", "pos.access"),
    "reservation.": ("reservations.manage", "pos.access"),
    "shift.": ("shifts.manage", "pos.access"),
    "inventory.": ("inventory.view", "kitchen.access"),
}


def allowed(perms: frozenset[str], topic: str) -> bool:
    if "*" in perms:
        return True
    for prefix, need in TOPIC_PERMS.items():
        if topic.startswith(prefix):
            return any(p in perms for p in need)
    return True


class Hub:
    def __init__(self) -> None:
        self.clients: dict[WebSocket, frozenset[str]] = {}      # socket -> permissions of its user
        self.owners: dict[WebSocket, int] = {}                  # socket -> user id
        self.loop: asyncio.AbstractEventLoop | None = None
        self.queue: asyncio.Queue | None = None

    async def start(self) -> None:
        self.loop = asyncio.get_running_loop()
        self.queue = asyncio.Queue()
        asyncio.create_task(self._pump())

    async def _pump(self) -> None:
        while True:
            msg = await self.queue.get()
            data = json.dumps(msg, ensure_ascii=False, default=str)
            dead = []
            for ws, perms in list(self.clients.items()):
                if not allowed(perms, msg["topic"]):
                    continue
                try:
                    await ws.send_text(data)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.remove(ws)

    def add(self, ws: WebSocket, user_id: int, perms: frozenset[str]) -> None:
        self.clients[ws] = perms
        self.owners[ws] = user_id

    def remove(self, ws: WebSocket) -> None:
        self.clients.pop(ws, None)
        self.owners.pop(ws, None)

    def kick(self, user_ids) -> None:
        """Close the live sockets of these users (deactivated / password or role changed).
        Their app reconnects with its token: a revoked token is refused, a valid one gets the new permissions."""
        if not self.loop:
            return
        ids = set(user_ids)
        for ws, uid in list(self.owners.items()):
            if uid in ids:
                self.remove(ws)
                asyncio.run_coroutine_threadsafe(ws.close(code=4401), self.loop)

    def publish(self, topic: str, data: Any = None) -> None:
        if not self.loop or not self.queue:
            return
        self.loop.call_soon_threadsafe(self.queue.put_nowait, {"topic": topic, "data": data})


hub = Hub()


def publish_after_commit(db: Session, topic: str, data: Any = None) -> None:
    db.info.setdefault("pending_events", []).append((topic, data))


def call_after_commit(db: Session, fn, *args) -> None:
    """Run a slow side effect (outbound HTTP call) in a worker thread once the transaction committed.

    Keeps network latency out of DB transactions (which hold SQLite's write lock) and never fires for rolled-back work.
    """
    db.info.setdefault("pending_calls", []).append((fn, args))


def _run_safely(fn, args) -> None:
    try:
        fn(*args)
    except Exception:  # noqa: BLE001 - side effects must never crash the worker
        log.exception("after-commit call failed")


@event.listens_for(Session, "after_commit")
def _flush_events(session: Session) -> None:
    for topic, data in session.info.pop("pending_events", []):
        hub.publish(topic, data)
    for fn, args in session.info.pop("pending_calls", []):
        threading.Thread(target=_run_safely, args=(fn, args), daemon=True).start()


@event.listens_for(Session, "after_rollback")
def _drop_events(session: Session) -> None:
    session.info.pop("pending_events", None)
    session.info.pop("pending_calls", None)
