"""Minimal ESC/POS for network thermal printers (raw TCP, usually port 9100).

Persian text is not sent as characters: printer code pages can't shape Arabic script reliably. The browser draws the
receipt (correct shaping, RTL, the app's font) and sends a 1-bit image; here it is wrapped as `GS v 0` raster bands.
"""
import socket

ESC, GS = b"\x1b", b"\x1d"
INIT = ESC + b"@"
CUT = GS + b"V" + bytes([66, 0])               # feed to the cutter and partial cut
DRAWER = ESC + b"p" + bytes([0, 25, 250])      # kick cash drawer on pin 2 (50 ms on / 500 ms off)
WIDTHS = (384, 512, 576)                       # 58 mm, 72 mm, 80 mm heads at 203 dpi
MAX_HEIGHT = 8000
BAND = 256                                     # rows per GS v 0 command: some printers have small input buffers


class PrinterError(Exception):
    pass


def raster_job(width: int, height: int, data: bytes, *, cut: bool = True, drawer: bool = False, copies: int = 1) -> bytes:
    """`data`: packed 1-bit rows, MSB = leftmost pixel, 1 = black; len == width/8 * height."""
    row = width // 8
    if width % 8 or not (0 < height <= MAX_HEIGHT) or len(data) != row * height:
        raise ValueError("bad raster size")
    one = bytearray(INIT)
    for y in range(0, height, BAND):
        h = min(BAND, height - y)
        one += GS + b"v0" + bytes([0, row & 0xFF, row >> 8, h & 0xFF, h >> 8]) + data[y * row:(y + h) * row]
    one += ESC + b"d" + bytes([3])                  # feed 3 lines
    if cut:
        one += CUT
    return (INIT + DRAWER if drawer else b"") + bytes(one) * max(1, min(copies, 5))


def text_job(lines: list[str], *, cut: bool = True) -> bytes:
    """ASCII-only test page (no shaping needed) — checks the connection and the cutter."""
    body = INIT + ESC + b"a\x01" + b"".join(l.encode("ascii", "replace") + b"\n" for l in lines) + ESC + b"d" + bytes([3])
    return body + (CUT if cut else b"")


def send(host: str, port: int, payload: bytes, timeout: float = 5.0) -> None:
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(payload)
    except OSError as e:
        raise PrinterError(str(e)) from e
