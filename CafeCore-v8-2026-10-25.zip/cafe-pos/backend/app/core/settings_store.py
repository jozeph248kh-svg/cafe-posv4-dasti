"""Business settings stored in DB (editable from the admin panel). Modules may register defaults."""
from typing import Any

from sqlalchemy.orm import Session

from .models import Setting

DEFAULTS: dict[str, Any] = {
    "business.name": "کافه رستوران من",
    "business.phone": "",
    "business.address": "",
    "business.logo": None,
    "receipt.footer": "از انتخاب شما سپاسگزاریم 🌿",
    "receipt.show_logo": True,
    "currency.label": "تومان",
    "tax.enabled": True,
    "tax.percent": 10,
    "service.enabled": True,
    "service.percent": 0,
    "rounding.step": 0,                 # round totals to nearest N (0 = off)
    "shift.required": True,             # payments require an open cash shift
    "day.cutoff_hour": 5,
    "kitchen.late_minutes": 15,         # KDS tickets turn red after this
    "kitchen.sound": True,
    "qr.call_enabled": True,            # guests can call a waiter from the QR menu
    "business.wifi": "",
    "business.instagram": "",
}


# Keys that hold credentials. They are never returned by the generic settings endpoint (any logged-in device can read
# it) and can only be changed through their module's dedicated, permission-checked endpoint.
SECRET_KEYS: set[str] = set()
# Keys owned by a module endpoint (validated there) or internal state — not writable via the generic endpoint.
PROTECTED_PREFIXES: set[str] = set()

# Allowed ranges for numeric settings (inclusive).
RANGES: dict[str, tuple[float, float]] = {
    "tax.percent": (0, 100), "service.percent": (0, 100), "rounding.step": (0, 1_000_000),
    "day.cutoff_hour": (0, 23), "kitchen.late_minutes": (1, 240),
}


def register_defaults(values: dict[str, Any], *, secrets: set[str] | None = None, protected: set[str] | None = None,
                      ranges: dict[str, tuple[float, float]] | None = None) -> None:
    for k, v in values.items():
        DEFAULTS.setdefault(k, v)
    SECRET_KEYS.update(secrets or ())
    PROTECTED_PREFIXES.update(protected or ())
    RANGES.update(ranges or {})


def is_protected(key: str) -> bool:
    return key in SECRET_KEYS or any(key.startswith(p) for p in PROTECTED_PREFIXES)


def public_view(data: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in data.items() if k not in SECRET_KEYS}


def validate(key: str, value: Any) -> Any:
    """Type/range check against the registered default so bad input can't break order calculations."""
    from .errors import AppError
    default = DEFAULTS.get(key)
    if isinstance(default, bool):
        if not isinstance(value, bool):
            raise AppError(f"مقدار «{key}» باید بله/خیر باشد", code="invalid_setting", key=key)
    elif isinstance(default, (int, float)) and not isinstance(default, bool):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise AppError(f"مقدار «{key}» باید عدد باشد", code="invalid_setting", key=key)
        if isinstance(default, int) and float(value).is_integer():
            value = int(value)
    if key in RANGES and value is not None:
        lo, hi = RANGES[key]
        if not (lo <= value <= hi):
            raise AppError(f"مقدار «{key}» باید بین {lo:g} و {hi:g} باشد", code="invalid_setting", key=key)
    if isinstance(value, str) and len(value) > 2000:
        raise AppError(f"مقدار «{key}» بیش از حد طولانی است", code="invalid_setting", key=key)
    return value


def get_all(db: Session) -> dict[str, Any]:
    data = dict(DEFAULTS)
    data.update({s.key: s.value for s in db.query(Setting).all()})
    return data


def get(db: Session, key: str, default: Any = None) -> Any:
    row = db.get(Setting, key)
    if row is not None:
        return row.value
    return DEFAULTS.get(key, default)


def set_many(db: Session, values: dict[str, Any]) -> None:
    for k, v in values.items():
        if k not in DEFAULTS:
            continue
        row = db.get(Setting, k)
        if row:
            row.value = v
        else:
            db.add(Setting(key=k, value=v))
