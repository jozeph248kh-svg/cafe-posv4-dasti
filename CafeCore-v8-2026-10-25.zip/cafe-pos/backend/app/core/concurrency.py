"""ASGI middleware that marks mutating requests so their DB transactions take the SQLite write lock up-front."""
import re

from .db import write_intent

MUTATING = {"POST", "PUT", "PATCH", "DELETE"}
# Endpoints that wait on external devices/services while a session is open. They must not hold the global write lock
# for the duration of a network call (card reader waits up to 90 s for the customer). None of them performs a
# read-modify-write on shared financial state; their writes are single-row inserts/updates.
EXEMPT = re.compile(
    r"^/api/(cardreader/(charge|terminals/\d+/ping)|sms/test|moadian/(test|run)"
    r"|branches/local/(test|push|pull-catalog)|system/print$|system/printers/\d+/test$)"
)


class WriteIntentMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope["method"] in MUTATING and not EXEMPT.match(scope["path"]):
            token = write_intent.set(True)
            try:
                await self.app(scope, receive, send)
            finally:
                write_intent.reset(token)
            return
        await self.app(scope, receive, send)
