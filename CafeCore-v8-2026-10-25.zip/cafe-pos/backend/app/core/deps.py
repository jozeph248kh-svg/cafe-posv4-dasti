"""Auth dependencies: current user, permission checks and manager PIN override."""
from dataclasses import dataclass

import jwt
from fastapi import Depends, Header, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import privacy, ratelimit
from .db import get_db
from .errors import AppError
from .models import User
from .security import decode_token, hash_pin

bearer = HTTPBearer(auto_error=False)


PWC_ALLOWED = ("/api/staff/auth/me", "/api/staff/auth/password")


def user_from_token(db: Session, token: str, path: str | None = None) -> User:
    try:
        payload = decode_token(token)
    except jwt.ExpiredSignatureError:
        raise AppError("نشست شما منقضی شده است", status.HTTP_401_UNAUTHORIZED, "token_expired")
    except jwt.PyJWTError:
        raise AppError("توکن نامعتبر است", status.HTTP_401_UNAUTHORIZED, "invalid_token")
    user = db.get(User, int(payload["sub"]))
    if not user or not user.is_active or user.token_version != payload.get("ver"):
        raise AppError("دسترسی شما لغو شده است", status.HTTP_401_UNAUTHORIZED, "invalid_token")
    if payload.get("pwc") and path not in PWC_ALLOWED:
        raise AppError("ابتدا رمز عبور پیش‌فرض را تغییر دهید", status.HTTP_403_FORBIDDEN, "password_change_required")
    return user


def current_user(request: Request, creds: HTTPAuthorizationCredentials | None = Depends(bearer),
                 db: Session = Depends(get_db)) -> User:
    if not creds:
        raise AppError("ابتدا وارد شوید", status.HTTP_401_UNAUTHORIZED, "unauthenticated")
    user = user_from_token(db, creds.credentials, request.url.path)
    request.state.must_change_password = bool(decode_token(creds.credentials).get("pwc"))
    request.state.mask_phones = not user.can(privacy.PERM)        # see app/core/privacy.py
    return user


def require(*perms: str):
    """Dependency: user must have ALL listed permissions."""
    def dep(user: User = Depends(current_user)) -> User:
        for p in perms:
            if not user.can(p):
                raise AppError("شما مجوز انجام این کار را ندارید", status.HTTP_403_FORBIDDEN, "forbidden", permission=p)
        return user
    return dep


@dataclass
class Actor:
    user: User
    approver: User          # the user whose permission authorised the action (may equal user)


def require_or_override(perm: str):
    """User must have `perm`, or a manager can authorise by sending their PIN in `X-Manager-Pin`."""
    def dep(
        request: Request,
        user: User = Depends(current_user),
        x_manager_pin: str | None = Header(default=None),
        db: Session = Depends(get_db),
    ) -> Actor:
        if user.can(perm):
            return Actor(user, user)
        if x_manager_pin:
            keys = (f"override:{user.id}", f"pin-ip:{ratelimit.client_ip(request)}")
            ratelimit.check(*keys)
            approver = db.query(User).filter(User.pin_hash == hash_pin(x_manager_pin)).first()
            if approver and approver.can(perm):
                ratelimit.success(*keys)
                return Actor(user, approver)
            ratelimit.fail(*keys)
            raise AppError("رمز مدیر نامعتبر است یا مجوز لازم را ندارد", status.HTTP_403_FORBIDDEN, "override_invalid", permission=perm)
        raise AppError("این عملیات نیاز به تأیید مدیر دارد", status.HTTP_403_FORBIDDEN, "override_required", permission=perm)
    return dep
