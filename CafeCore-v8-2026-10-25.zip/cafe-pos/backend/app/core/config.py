"""Application configuration (env vars or `.env` file, prefix CAFE_)."""
import os
import secrets
import stat
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[2]          # backend/
PROJECT_DIR = BASE_DIR.parent                          # project root
FRONTEND_DIST = PROJECT_DIR / "frontend" / "ui"      # built by `npm run build` (vite outDir)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CAFE_", env_file=BASE_DIR / ".env", extra="ignore")

    app_name: str = "Cafe POS"
    version: str = "1.0.0"
    data_dir: Path = PROJECT_DIR / "data"
    database_url: str | None = None                    # default: sqlite in data_dir
    secret_key: str | None = None                      # default: generated & persisted in data_dir
    token_ttl_hours: int = 14
    host: str = "0.0.0.0"
    port: int = 8000
    https: bool = False                                # serve HTTPS with a local CA (python -m app.serve; see core/tls.py)
    enabled_modules: str = "*"                         # comma separated list or "*"
    demo_data: bool = False                            # seed demo sales history on first run (CAFE_DEMO_DATA=true)
    sample_users: bool | None = None                   # sample staff with known passwords; default: same as demo_data
    force_password_change: bool = True                 # users still on a factory password must change it first
    api_docs: bool = False                             # expose /api/docs (developer use)
    cors_origins: str = ""                             # comma separated; empty = same-origin only (the app serves the UI)
    login_max_failures: int = 5                        # per IP+account (or IP for PIN) within the window
    login_window_sec: int = 300
    background_jobs: bool = True                       # SMS queue, reminders, branch sync, tax inquiries
    backup_keep: int = 14                              # business days of daily backups to keep
    backup_interval_minutes: int = 60                  # hourly snapshots while data changes

    @property
    def seed_sample_users(self) -> bool:
        return self.demo_data if self.sample_users is None else self.sample_users

    @property
    def db_url(self) -> str:
        return self.database_url or f"sqlite:///{(self.data_dir / 'cafe.db').as_posix()}"

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"

    @property
    def backups_dir(self) -> Path:
        return self.data_dir / "backups"

    def jwt_secret(self) -> str:
        if self.secret_key:
            return self.secret_key
        key_file = self.data_dir / "secret.key"
        if not key_file.exists():
            key_file.parent.mkdir(parents=True, exist_ok=True)
            try:
                # the key signs every login token (and protects stored secrets): create it 0600, never with the
                # process umask — on a shared machine another local user must not be able to read it.
                # (On Windows the mode is advisory; the file still gets the usual ACL of the data folder.)
                fd = os.open(key_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:                                  # two workers started at once: use the winner's key
                pass
            else:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(secrets.token_urlsafe(48))
        if key_file.exists():
            try:
                if stat.S_IMODE(key_file.stat().st_mode) & 0o077:     # an older install: tighten it on sight
                    os.chmod(key_file, 0o600)
            except OSError:                                            # read-only / odd filesystem: not fatal
                pass
        return key_file.read_text().strip()


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    for d in (s.data_dir, s.uploads_dir, s.backups_dir):
        d.mkdir(parents=True, exist_ok=True)
    return s
