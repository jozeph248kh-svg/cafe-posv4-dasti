"""Customer phone-number privacy.

Users without the permission `customers.phone` see phone numbers masked (0912***4567) in every JSON response of
the API. The masking is done centrally by `PhoneMaskMiddleware` (so a new endpoint can't forget it); the
`current_user` dependency marks the request with `mask_phones`. Searching by a full number still works — only
the output is masked. Public endpoints (QR menu, online ordering) are never masked: they have no staff user.

A masked value echoed back by an edit form must never overwrite the real number → `phone_update()` keeps the
stored value, and `normalize_phone()` refuses masked input on create.
"""
import json

PERM = "customers.phone"
KEYS = {"phone", "customer_phone", "receptor"}
LIST_KEYS = {"phones"}
SMS_KEYS = {"to"}                       # sms_messages.to — only under /api/sms
MASK = "***"


def mask_phone(p: str | None) -> str | None:
    if not p or not isinstance(p, str):
        return p
    if MASK in p:
        return p
    return p[:4] + MASK + p[-4:] if len(p) >= 9 else MASK


def is_masked(p: str | None) -> bool:
    return bool(p) and "*" in p


def mask_tree(obj, sms: bool = False):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(v, str) and (k in KEYS or (sms and k in SMS_KEYS)):
                out[k] = mask_phone(v)
            elif k in LIST_KEYS and isinstance(v, list):
                out[k] = [mask_phone(x) if isinstance(x, str) else x for x in v]
            else:
                out[k] = mask_tree(v, sms)
        return out
    if isinstance(obj, list):
        return [mask_tree(x, sms) for x in obj]
    return obj


class PhoneMaskMiddleware:
    """Pure ASGI: buffers only JSON responses of requests marked `mask_phones` and rewrites them."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope["path"].startswith("/api/"):
            return await self.app(scope, receive, send)
        start: dict | None = None
        body = bytearray()

        async def _send(msg):
            nonlocal start
            if msg["type"] == "http.response.start":
                headers = dict(msg.get("headers") or [])
                marked = (scope.get("state") or {}).get("mask_phones")
                if marked and headers.get(b"content-type", b"").startswith(b"application/json"):
                    start = msg                     # defer until the whole body is known
                    return
                return await send(msg)
            if start is None or msg["type"] != "http.response.body":
                return await send(msg)
            body.extend(msg.get("body", b""))
            if msg.get("more_body"):
                return
            data = bytes(body)
            if b"phone" in data or b"receptor" in data or b'"to"' in data:
                try:
                    data = json.dumps(mask_tree(json.loads(data), sms=scope["path"].startswith("/api/sms")),
                                      ensure_ascii=False, separators=(",", ":")).encode()
                except ValueError:
                    pass
            headers = [(k, v) for k, v in start.get("headers", []) if k != b"content-length"]
            headers.append((b"content-length", str(len(data)).encode()))
            await send({**start, "headers": headers})
            await send({"type": "http.response.body", "body": data})

        await self.app(scope, receive, _send)
