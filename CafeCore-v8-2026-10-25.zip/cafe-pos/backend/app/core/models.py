"""Core tables shared by all modules: roles, users, settings, audit log."""
from datetime import datetime
from typing import Any

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base, TimestampMixin


class Role(Base, TimestampMixin):
    __tablename__ = "roles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40), unique=True)
    title: Mapped[str] = mapped_column(String(80))
    permissions: Mapped[list[str]] = mapped_column(JSON, default=list)
    is_system: Mapped[bool] = mapped_column(Boolean, default=False)
    # discount ceilings for users of this role (NULL = no ceiling; the permission `orders.discount` is still required)
    max_discount_pct: Mapped[int | None] = mapped_column(Integer)
    max_discount_amount: Mapped[int | None] = mapped_column(Integer)
    max_discount_daily: Mapped[int | None] = mapped_column(Integer)     # toman per business day (self-approved)
    max_discount_monthly: Mapped[int | None] = mapped_column(Integer)   # toman per Jalali month (self-approved)

    def allows(self, perm: str) -> bool:
        return "*" in self.permissions or perm in self.permissions


class User(Base, TimestampMixin):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20))
    password_hash: Mapped[str] = mapped_column(String(100))
    pin_hash: Mapped[str | None] = mapped_column(String(64), unique=True)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    token_version: Mapped[int] = mapped_column(Integer, default=1)
    last_login: Mapped[datetime | None] = mapped_column(DateTime)
    max_discount_pct: Mapped[int | None] = mapped_column(Integer)       # personal override of the role's ceiling
    max_discount_amount: Mapped[int | None] = mapped_column(Integer)
    max_discount_daily: Mapped[int | None] = mapped_column(Integer)     # toman per business day (self-approved)
    max_discount_monthly: Mapped[int | None] = mapped_column(Integer)   # toman per Jalali month (self-approved)

    role: Mapped[Role] = relationship(lazy="joined")

    def can(self, perm: str) -> bool:
        return self.is_active and self.role.allows(perm)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[Any] = mapped_column(JSON)


class AuditLog(Base, TimestampMixin):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    user_name: Mapped[str | None] = mapped_column(String(80))
    approver_name: Mapped[str | None] = mapped_column(String(80))
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity: Mapped[str | None] = mapped_column(String(40))
    entity_id: Mapped[str | None] = mapped_column(String(40))
    summary: Mapped[str] = mapped_column(Text)
    details: Mapped[dict | None] = mapped_column(JSON)


class BackupRun(Base, TimestampMixin):
    """One backup or restore-drill attempt (success or failure).

    Kept in the database so the status page and the audit trail can answer «when did the last *successful* backup
    happen?» and «why did it fail?» — a log line in a console nobody reads is not an answer.
    """
    __tablename__ = "backup_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(10), index=True)          # backup | drill
    status: Mapped[str] = mapped_column(String(10), index=True)        # ok | failed
    file: Mapped[str | None] = mapped_column(String(120))
    size: Mapped[int | None] = mapped_column(Integer)
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    detail: Mapped[str | None] = mapped_column(Text)                   # Persian error / differences summary
