"""In-process domain event bus — the glue between modules.

Modules never import each other's services to react to things; instead one module `emit`s
an event (inside the same DB transaction) and others subscribe to it. Example:
    orders  -> emit("order.closed", db=db, order=order)
    inventory subscribes and deducts ingredients; disabling inventory changes nothing in orders.
"""
import logging
from collections import defaultdict
from collections.abc import Callable

log = logging.getLogger("events")
_handlers: dict[str, list[Callable]] = defaultdict(list)


def subscribe(name: str, handler: Callable) -> None:
    _handlers[name].append(handler)


def on(name: str):
    def deco(fn: Callable) -> Callable:
        subscribe(name, fn)
        return fn
    return deco


def emit(name: str, **payload) -> None:
    for handler in _handlers.get(name, []):
        handler(**payload)


def clear() -> None:
    _handlers.clear()
