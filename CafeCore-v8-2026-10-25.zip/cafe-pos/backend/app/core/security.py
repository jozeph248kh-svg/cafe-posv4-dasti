import hashlib
import hmac
from datetime import UTC, datetime, timedelta

import bcrypt
import jwt

from .config import get_settings


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=11)).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except ValueError:
        return False


def hash_pin(pin: str) -> str:
    """Deterministic keyed hash so a PIN can be looked up (and kept unique) without storing it."""
    return hmac.new(get_settings().jwt_secret().encode(), f"pin:{pin}".encode(), hashlib.sha256).hexdigest()


def create_token(user_id: int, token_version: int, must_change_password: bool = False) -> str:
    s = get_settings()
    payload = {
        "sub": str(user_id),
        "ver": token_version,
        "exp": datetime.now(UTC) + timedelta(hours=s.token_ttl_hours),
    }
    if must_change_password:
        payload["pwc"] = True     # restricted token: only /auth/me and /auth/password are allowed
    return jwt.encode(payload, s.jwt_secret(), algorithm="HS256")


def decode_token(token: str) -> dict:
    return jwt.decode(token, get_settings().jwt_secret(), algorithms=["HS256"])
