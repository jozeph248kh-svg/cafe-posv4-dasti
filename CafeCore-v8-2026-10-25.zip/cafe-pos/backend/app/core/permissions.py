"""Helpers for modules that introduce new permissions after the first install."""
from sqlalchemy.orm import Session

from .models import Role, Setting


def grant_once(db: Session, key: str, grants: dict[str, list[str]]) -> None:
    """Add permissions to existing roles exactly once per install (admins may revoke them later)."""
    flag = f"_grant.{key}"
    if db.get(Setting, flag) or not db.query(Role).count():
        return
    for role in db.query(Role).filter(Role.name.in_(list(grants))).all():
        if "*" in role.permissions:
            continue
        role.permissions = sorted(set(role.permissions) | set(grants[role.name]))
    db.add(Setting(key=flag, value=True))
