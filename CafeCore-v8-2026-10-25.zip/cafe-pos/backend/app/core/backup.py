"""Database backups, restore and the **restore drill** (بازیابی آزمایشی).

* `create_backup()` dispatches on the engine: SQLite uses its online backup API (consistent snapshot even while the
  app is writing; WAL-safe) and verifies the copy with `PRAGMA integrity_check`; PostgreSQL uses `pg_dump -Fc`
  (custom format, verified with `pg_restore --list`). Either way the file is written to a temporary name, verified,
  then renamed — a half-written backup can never look like a good one.
* Every backup gets a `.json` manifest with the **key figures of the data it captured** (order/payment/refund counts
  and money sums, stock quantities). `restore_drill()` restores the backup into an **isolated scratch database**
  (a temp file for SQLite, a throw-away database for PostgreSQL — never the live DB) and compares the figures it
  finds there with the manifest. A backup is only "confirmed" once that drill has passed.
* A file lock (`backup.lock`) makes concurrent backups impossible; a lock left behind by a killed process is
  detected (dead pid / too old) and ignored.
* Automatic backups: an `hourly` snapshot while data changes (`CAFE_BACKUP_INTERVAL_MINUTES`, default 60). When a
  business day is over — or a cash shift is closed — only the LAST snapshot of that day is kept (renamed `daily`) and the
  day's other hourly files are deleted. Daily backups are kept for `CAFE_BACKUP_KEEP` business days (default 14).
* Manual backups are never deleted automatically; safety copies taken before upgrades/restores keep the newest 5.
* `restore_backup()` is used by the offline CLI `python -m app.restore` (the server must be stopped).
"""
import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import tempfile
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from .config import get_settings

log = logging.getLogger("backup")

NAME_RE = r"^cafe-\d{8}-\d{6}-[a-z-]+\.(db|dump)$"
REQUIRED_TABLES = {"users", "roles", "orders", "payments", "settings"}
SUFFIXES = {".db": "sqlite", ".dump": "postgresql"}
LOCK_NAME = "backup.lock"
LOCK_MAX_AGE = 30 * 60          # a lock older than this belongs to a process that is gone
STALE_AFTER_HOURS = 24          # "the last good backup is too old" warning (requirement: 24 h)



class BackupError(RuntimeError):
    pass


# ---------------------------------------------------------------- key figures (what a backup promises to contain)
# The drill compares these numbers between a restored copy and the manifest written when the backup was taken.
# Everything is integer toman / integer counts (the project never stores fractional money), so equality is exact.
FIGURES_SQL: dict[str, str] = {
    "orders.count": "SELECT COUNT(*) FROM orders",
    "orders.closed": "SELECT COUNT(*) FROM orders WHERE status = 'closed'",
    "orders.cancelled": "SELECT COUNT(*) FROM orders WHERE status = 'cancelled'",
    "orders.total_sum": "SELECT COALESCE(SUM(total), 0) FROM orders",
    "orders.paid_sum": "SELECT COALESCE(SUM(paid_amount), 0) FROM orders",
    "orders.tax_sum": "SELECT COALESCE(SUM(tax_amount), 0) FROM orders",
    "orders.discount_sum": "SELECT COALESCE(SUM(discount_amount), 0) FROM orders",
    "order_lines.count": "SELECT COUNT(*) FROM order_lines",
    "order_lines.qty_sum": "SELECT COALESCE(SUM(qty), 0) FROM order_lines",
    "payments.count": "SELECT COUNT(*) FROM payments",
    "payments.sum": "SELECT COALESCE(SUM(amount), 0) FROM payments",
    "payments.refund_sum": "SELECT COALESCE(SUM(amount), 0) FROM payments WHERE is_refund",
    # `order_refund_lines` has no money column: the refunded *money* lives in `payments` (negative, is_refund),
    # this table records the returned goods and the historical cost frozen at sale time.
    "refunds.count": "SELECT COUNT(*) FROM order_refund_lines",
    "refunds.cost_sum": "SELECT COALESCE(SUM(qty * COALESCE(unit_cost, 0)), 0) FROM order_refund_lines",
    "refunds.qty_sum": "SELECT COALESCE(SUM(qty), 0) FROM order_refund_lines",
    "inventory.movements": "SELECT COUNT(*) FROM stock_movements",
    "inventory.movement_qty": "SELECT COALESCE(SUM(qty), 0) FROM stock_movements",
    "inventory.ingredients": "SELECT COUNT(*) FROM ingredients",
    "users.count": "SELECT COUNT(*) FROM users",
    "settings.count": "SELECT COUNT(*) FROM settings",
}
# Tables that are allowed to be missing in a very old backup — they report `null` instead of failing the drill.
OPTIONAL_FIGURES = {"refunds.count", "refunds.cost_sum", "refunds.qty_sum", "inventory.movements",
                    "inventory.movement_qty", "inventory.ingredients"}


def _figures_from_connection(con, dialect: str = "sqlite") -> dict[str, Any]:
    """Run FIGURES_SQL on any DBAPI connection (the restored scratch copy or the live database).

    Number handling: SQLite returns int for SUM(integer); PostgreSQL returns Decimal (and float for SUM(float)) —
    all are normalised to int when they are whole numbers, so the two engines produce identical manifests.
    """
    out: dict[str, Any] = {}
    for key, sql in FIGURES_SQL.items():
        try:
            raw = con.execute(sql).fetchone()[0]
        except Exception:                                  # noqa: BLE001 — a missing (old) table is not a crash
            out[key] = None if key in OPTIONAL_FIGURES else f"missing:{key.split('.')[0]}"
            continue
        if raw is None:
            out[key] = 0
        elif isinstance(raw, float) and raw.is_integer():
            out[key] = int(raw)
        elif isinstance(raw, float):
            out[key] = round(raw, 6)
        else:
            out[key] = int(raw)
    return out


def live_figures() -> dict[str, Any]:
    """Key figures of the **live** database (same query set the drill uses on the restored copy)."""
    from .db import engine

    if engine.dialect.name == "sqlite":
        src = sqlite_path()
        if not src or not src.exists():
            return {}
        con = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True)
        try:
            return _figures_from_connection(con)
        finally:
            con.close()
    from sqlalchemy import text

    with engine.connect() as c:
        try:
            c.execute(text("SET statement_timeout = 10000"))    # a stuck server must not hang the status page
        except Exception:                                       # noqa: BLE001 — e.g. SQLite has no such setting
            pass
        out = {}
        for key, sql in FIGURES_SQL.items():
            try:
                raw = c.execute(text(sql)).scalar()
            except Exception:                              # noqa: BLE001
                out[key] = None if key in OPTIONAL_FIGURES else f"missing:{key.split('.')[0]}"
                continue
            out[key] = 0 if raw is None else (int(raw) if float(raw).is_integer() else round(float(raw), 6))
        return out


def manifest_path(backup: Path) -> Path:
    return backup.with_name(backup.name + ".json")


def read_manifest(backup: Path) -> dict | None:
    try:
        return json.loads(manifest_path(backup).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_manifest(backup: Path, figures: dict[str, Any], source: str) -> Path:
    data = {
        "version": 1,
        "file": backup.name,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "size": backup.stat().st_size,
        "sha256": _sha256(backup),
        "source": source,                    # sqlite | postgresql
        "figures": figures,
    }
    path = manifest_path(backup)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


# ---------------------------------------------------------------- one backup at a time
class backup_lock:
    """Cross-process lock so two backup/drill runs can never interleave.

    O_CREAT|O_EXCL gives atomicity; the pid inside lets us ignore a lock left behind by a killed process, so a crash
    during a backup does not disable backups until someone deletes a file by hand.
    """

    def __init__(self, folder: Path | None = None):
        self.folder = folder or get_settings().backups_dir
        self.path = self.folder / LOCK_NAME
        self.held = False

    def _stale(self) -> bool:
        try:
            info = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return False                                   # vanished: the holder just released it
        except (OSError, ValueError):
            # A lock file whose content cannot be read is *not* automatically stale: the holder may still be writing
            # it. Only age can prove otherwise (this race is why three threads once held the lock at the same time).
            try:
                return datetime.now().timestamp() - self.path.stat().st_mtime > LOCK_MAX_AGE
            except OSError:
                return False
        pid, started = info.get("pid"), info.get("at", 0)
        if datetime.now().timestamp() - started > LOCK_MAX_AGE:
            return True
        if not isinstance(pid, int):
            return True
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return True
        except PermissionError:
            return False                                   # alive, owned by another user
        except OSError:
            return True
        return False

    def __enter__(self):
        """Create the lock **atomically with its content**.

        `O_CREAT|O_EXCL` creates an empty file and the pid is written afterwards; a second process could read that
        half-written file, decide it is garbage, delete the winner's lock and take over — two backups at once
        (observed in a test with four threads). Writing a private temp file and hard-linking it into place is atomic:
        the lock only ever exists with complete content.
        """
        self.folder.mkdir(parents=True, exist_ok=True)
        for _ in range(3):
            tmp = self.folder / f".lock-{os.getpid()}-{secrets.token_hex(4)}"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump({"pid": os.getpid(), "at": datetime.now().timestamp()}, f)
                    f.flush()
                    os.fsync(f.fileno())
                os.chmod(tmp, 0o600)
                try:
                    os.link(tmp, self.path)                # atomic and exclusive: fails if the lock already exists
                except FileExistsError:
                    if self._stale():
                        self.path.unlink(missing_ok=True)  # a dead run's lock: take it over
                        continue
                    raise BackupError("یک پشتیبان‌گیری دیگر در حال اجراست؛ چند لحظه بعد دوباره تلاش کنید") from None
                except OSError:                            # e.g. a filesystem without hard links
                    fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                    with os.fdopen(fd, "w", encoding="utf-8") as f:
                        json.dump({"pid": os.getpid(), "at": datetime.now().timestamp()}, f)
            except OSError as e:                           # read-only folder, no permission, disk full…
                raise BackupError(f"پوشهٔ پشتیبان قابل نوشتن نیست ({e.strerror or e})؛ دسترسی پوشه را بررسی کنید") from e
            finally:
                tmp.unlink(missing_ok=True)
            self.held = True
            return self
        raise BackupError("قفل پشتیبان‌گیری آزاد نشد؛ فایل backup.lock را بررسی کنید")

    def __exit__(self, *exc):
        if self.held:
            self.path.unlink(missing_ok=True)
            self.held = False
        return False


def sqlite_path() -> Path | None:
    url = get_settings().db_url
    return Path(url.replace("sqlite:///", "")) if url.startswith("sqlite:///") else None


def verify(path: Path) -> dict:
    """Integrity + structure check, for either engine. Raises BackupError if the file is not a usable backup."""
    if path.suffix == ".dump":
        return verify_dump(path)
    return _verify_sqlite(path)


SQLITE_TMP_SUFFIXES = {".tmp", ".part"}          # in-flight files are still plain SQLite databases


def _verify_sqlite(path: Path) -> dict:
    """SQLite integrity + structure check (also used on the `.tmp` file before it is renamed)."""
    if path.suffix not in SUFFIXES and path.suffix not in SQLITE_TMP_SUFFIXES:
        raise BackupError(f"نوع فایل پشتیبان پشتیبانی نمی‌شود: {path.name}")
    if not path.exists() or path.stat().st_size == 0:
        raise BackupError(f"فایل پشتیبان وجود ندارد یا خالی است: {path.name}")
    try:
        con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
        try:
            res = con.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            counts = {t: con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in ("orders", "payments", "users")
                      if t in tables}
        finally:
            con.close()
    except sqlite3.DatabaseError as e:
        raise BackupError(f"فایل پشتیبان خراب است یا پایگاه داده SQLite نیست ({e})") from e
    if res != "ok":
        raise BackupError(f"بررسی سلامت فایل پشتیبان ناموفق بود: {res}")
    missing = REQUIRED_TABLES - tables
    if missing:
        raise BackupError(f"این فایل، پشتیبان Cafe POS نیست (جدول‌های {', '.join(sorted(missing))} وجود ندارد)")
    return {"integrity": res, "counts": counts}


# ---------------------------------------------------------------- PostgreSQL (pg_dump / pg_restore)
PG_BIN = Path("/usr/lib/postgresql")          # Debian/Ubuntu keep the client tools here, even when not on PATH


def pg_tools() -> dict[str, str | None]:
    """Locate pg_dump/pg_restore/createdb/dropdb. Returns None for the ones that are not installed."""
    found: dict[str, str | None] = {}
    for name in ("pg_dump", "pg_restore", "createdb", "dropdb", "psql"):
        exe = shutil.which(name)
        if not exe and PG_BIN.is_dir():
            for cand in sorted(PG_BIN.glob(f"*/bin/{name}"), reverse=True):
                if cand.is_file():
                    exe = str(cand)
                    break
        found[name] = exe
    return found


def _pg_dsn(url: str | None = None) -> dict[str, Any]:
    """Connection parts for the CLI tools (they take -h/-p/-U/-d, not SQLAlchemy URLs)."""
    from sqlalchemy.engine import make_url

    u = make_url(url or get_settings().db_url)
    # `postgresql+psycopg://user@/db?host=/tmp&port=5433` → host /tmp (a unix socket directory), port 5433
    return {"dbname": u.database, "user": u.username, "password": u.password,
            "host": u.host or (u.query.get("host") or ""), "port": str(u.port or u.query.get("port") or "")}


def _pg_env(parts: dict[str, Any], lock_timeout_ms: int = 15_000) -> dict[str, str]:
    """Environment for the CLI tools: password + a lock timeout so a blocked dump/restore fails fast and safely."""
    env = {k: v for k, v in os.environ.items()}
    if parts.get("password"):
        env["PGPASSWORD"] = str(parts["password"])
    env.setdefault("PGOPTIONS", f"-c lock_timeout={lock_timeout_ms}")
    return env


def _run(cmd: list[str], env: dict[str, str], timeout: int = 300, what: str = "ابزار پایگاه‌داده") -> subprocess.CompletedProcess:
    """Run a CLI tool, never hanging forever.

    A dump/restore that waits on a lock (another session holding a table, a stuck query) would otherwise block the
    backup thread until the operator reboots the machine — so every call has a hard timeout and turns into a clear
    BackupError whose text lands on the status page.
    """
    try:
        return subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as e:
        raise BackupError(f"{what} بیش از {timeout} ثانیه طول کشید و متوقف شد (احتمالاً یک نشست دیگر پایگاه‌داده را "
                          f"قفل کرده است)") from e


def _pg_conn_args(parts: dict[str, Any]) -> list[str]:
    args = []
    if parts["host"]:
        args += ["-h", str(parts["host"])]
    if parts["port"]:
        args += ["-p", str(parts["port"])]
    if parts["user"]:
        args += ["-U", str(parts["user"])]
    return args


def pg_dump_to(dest: Path, url: str | None = None) -> Path:
    """`pg_dump -Fc` into `dest` (custom format: one file, compressed, restorable table by table)."""
    tools = pg_tools()
    if not tools["pg_dump"] or not tools["pg_restore"]:
        raise BackupError("ابزارهای PostgreSQL (pg_dump/pg_restore) روی این سیستم نصب نیستند؛ "
                          "برای پشتیبان‌گیری PostgreSQL آن‌ها را نصب کنید (postgresql-client)")
    parts = _pg_dsn(url)
    tmp = dest.with_name(dest.name + ".part")
    res = _run([tools["pg_dump"], *_pg_conn_args(parts), "-Fc", "--no-owner", "--no-privileges",
                "-f", str(tmp), parts["dbname"]], _pg_env(parts), what="pg_dump")
    if res.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise BackupError(f"pg_dump ناموفق بود: {res.stderr.strip()[:300]}")
    tmp.replace(dest)
    return dest


def verify_dump(path: Path) -> dict:
    """A pg_dump custom-format file must be readable by pg_restore and contain the core tables."""
    if not path.exists() or path.stat().st_size == 0:
        raise BackupError(f"فایل پشتیبان وجود ندارد یا خالی است: {path.name}")
    tools = pg_tools()
    if not tools["pg_restore"]:
        raise BackupError("pg_restore برای بررسی فایل پشتیبان PostgreSQL نصب نیست")
    res = _run([tools["pg_restore"], "--list", str(path)], {}, what="pg_restore --list")
    if res.returncode != 0:
        raise BackupError(f"فایل پشتیبان PostgreSQL قابل خواندن نیست ({res.stderr.strip()[:200]})")
    listed = res.stdout
    missing = [t for t in sorted(REQUIRED_TABLES) if f"TABLE DATA public {t} " not in listed and f"TABLE {t} " not in listed]
    if missing:
        raise BackupError(f"این فایل، پشتیبان Cafe POS نیست (جدول‌های {', '.join(missing)} وجود ندارد)")
    return {"integrity": "ok", "tables": listed.count("TABLE DATA")}


def _scratch_db_name() -> str:
    return f"cafe_drill_{datetime.now():%H%M%S}_{secrets.token_hex(3)}"


def pg_restore_into_scratch(path: Path, url: str | None = None) -> tuple[str, dict[str, Any]]:
    """Restore a dump into a BRAND-NEW throw-away database. Returns (db name, connection parts).

    The live database is never touched: the scratch database is created empty, filled, read, and dropped again by
    the caller. Creating/dropping a separate database is the only way to *prove* a dump restores without risking
    real data — restoring over the live DB is exactly what this drill must never do.
    """
    tools = pg_tools()
    for tool in ("createdb", "dropdb", "pg_restore"):
        if not tools[tool]:
            raise BackupError(f"ابزار {tool} نصب نیست؛ اجرای بازیابی آزمایشی PostgreSQL ممکن نیست")
    parts = _pg_dsn(url)
    name = _scratch_db_name()
    env = _pg_env(parts)
    res = _run([tools["createdb"], *_pg_conn_args(parts), name], env, timeout=120, what="createdb")
    if res.returncode != 0:
        raise BackupError(f"ساخت پایگاه‌دادهٔ موقت برای آزمون بازیابی ناموفق بود: {res.stderr.strip()[:200]}")
    res = _run([tools["pg_restore"], *_pg_conn_args(parts), "-d", name, "--no-owner", "--no-privileges",
                "--single-transaction", str(path)], env, what="pg_restore")
    if res.returncode != 0:
        _run([tools["dropdb"], *_pg_conn_args(parts), "--if-exists", name], env, timeout=120)
        raise BackupError(f"بازیابی فایل پشتیبان در پایگاه‌دادهٔ موقت ناموفق بود: {res.stderr.strip()[:300]}")
    return name, parts


def drop_scratch_db(name: str, parts: dict[str, Any]) -> None:
    tools = pg_tools()
    if tools["dropdb"]:
        _run([tools["dropdb"], *_pg_conn_args(parts), "--if-exists", name], _pg_env(parts), timeout=120)


def _figures_from_pg(parts: dict[str, Any], dbname: str) -> dict[str, Any]:
    import psycopg

    kw: dict[str, Any] = {"dbname": dbname}
    if parts["host"]:
        kw["host"] = parts["host"]
    if parts["port"]:
        kw["port"] = parts["port"]
    if parts["user"]:
        kw["user"] = parts["user"]
    if parts["password"]:
        kw["password"] = parts["password"]
    with psycopg.connect(**kw) as con:
        return _figures_from_connection(con, "postgresql")


AUTO_TAGS = ("hourly", "daily", "auto")                    # "auto" = legacy name, treated as daily
_STAMP = re.compile(r"^cafe-(\d{8}-\d{6})-([a-z-]+?)-*\.(?:db|dump)$")   # SQLite file or PostgreSQL dump


def parse_name(p: Path) -> tuple[datetime, str] | None:
    m = _STAMP.match(p.name)
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y%m%d-%H%M%S"), m.group(2)
    except ValueError:
        return None


def business_day_of(dt: datetime, cutoff_hour: int) -> date:
    return (dt - timedelta(hours=cutoff_hour)).date()


def _auto_backups(backups_dir: Path) -> list[tuple[datetime, str, Path]]:
    """Automatic backups, oldest first. Two snapshots in the same second (a shift closing right after an hourly
    run) are ordered so the `daily` one wins — otherwise consolidation would delete the daily and rename nothing.
    """
    out = []
    for p in [*backups_dir.glob("cafe-*.db"), *backups_dir.glob("cafe-*.dump")]:
        info = parse_name(p)
        if info and info[1] in AUTO_TAGS:
            out.append((info[0], info[1], p))
    return sorted(out, key=lambda i: (i[0], 1 if i[1] == "daily" else 0, i[2].name))


def protected_paths(backups_dir: Path) -> set[Path]:
    """Backups that must never be deleted automatically.

    Requirement: «جلوگیری از حذف تصادفی آخرین بکاپ سالم». We protect the newest file of every kind (hourly/daily/
    manual/safety) — a rotation bug or a wrong retention setting then still leaves one restorable copy behind.
    """
    keep: set[Path] = set()
    for tag in ("manual", "pre-upgrade", "pre-restore"):
        for ext in ("db", "dump"):
            files = sorted(backups_dir.glob(f"cafe-*-{tag}*.{ext}"))
            if files:
                keep.add(files[-1])              # the newest hand-made / safety copy is never auto-deleted
    return keep


def _delete_batch(backups_dir: Path, doomed: list[Path], protected: set[Path]) -> None:
    """Delete a batch of rotated-away files, but never the last restorable backup in the folder.

    The folder always keeps at least the newest file: even a wrong `CAFE_BACKUP_KEEP` (e.g. 0) or an old clock
    cannot leave a shop with zero backups.
    """
    survivors = [p for p in backups_dir.glob("cafe-*") if p.suffix in SUFFIXES and p not in doomed]
    if not survivors and doomed:
        newest = max(doomed, key=lambda p: (parse_name(p) or (datetime.min, ""))[0])
        log.warning("keeping %s: it would have been the last backup", newest.name)
        doomed = [p for p in doomed if p != newest]
    for path in doomed:
        _guarded_unlink(path, protected)


def _guarded_unlink(path: Path, protected: set[Path]) -> None:
    if path in protected:
        log.warning("not deleting the last backup of its kind: %s", path.name)
        return
    path.unlink(missing_ok=True)
    manifest_path(path).unlink(missing_ok=True)


def consolidate(backups_dir: Path, cutoff_hour: int = 5, today: date | None = None, close_day: date | None = None) -> None:
    """Keep one backup per finished business day (the newest), plus `close_day` (a shift was just closed).

    Today's hourly snapshots stay until the day is over (or a shift closes). Dailies older than the retention window
    (`backup_keep` business days) are removed. Manual and safety copies are handled separately in `_rotate`.
    """
    today = today or business_day_of(datetime.now(), cutoff_hour)
    by_day: dict[date, list[tuple[datetime, str, Path]]] = {}
    for item in _auto_backups(backups_dir):
        by_day.setdefault(business_day_of(item[0], cutoff_hour), []).append(item)
    keep_from = today - timedelta(days=max(get_settings().backup_keep, 1) - 1)
    keep_safe = protected_paths(backups_dir)
    doomed: list[Path] = []
    for day, items in by_day.items():
        if day < keep_from:
            doomed += [p for *_, p in items]
            continue
        if day == today and day != close_day:
            continue                                      # day still running: keep its hourly snapshots
        *older, (stamp, tag, newest) = items
        doomed += [p for *_, p in older]
        if tag != "daily":
            target = newest.with_name(f"cafe-{stamp:%Y%m%d-%H%M%S}-daily{newest.suffix}")
            if not target.exists():
                newest.rename(target)
    _delete_batch(backups_dir, doomed, keep_safe)


def _rotate(backups_dir: Path, cutoff_hour: int = 5) -> None:
    for junk in [*backups_dir.glob("*.tmp*"), *backups_dir.glob("*.part")]:
        junk.unlink(missing_ok=True)                     # left over by an interrupted/killed backup
    consolidate(backups_dir, cutoff_hour)
    keep_safe = protected_paths(backups_dir)
    doomed: list[Path] = []
    for tag in ("pre-upgrade", "pre-restore"):
        safety = sorted([*backups_dir.glob(f"cafe-*-{tag}.db"), *backups_dir.glob(f"cafe-*-{tag}.dump")])
        doomed += safety[: max(len(safety) - 5, 0)]
    _delete_batch(backups_dir, doomed, keep_safe)


def create_backup(tag: str = "manual", src: Path | None = None, cutoff_hour: int = 5) -> Path | None:
    """Take a verified backup of the live database and write its manifest. Returns the backup path.

    `src` is only used by the tests and by the migration safety copy (SQLite file). With PostgreSQL the engine is
    detected from the configured URL. Returns None when there is simply nothing to back up (no database file yet).
    """
    from .db import engine

    if engine.dialect.name == "postgresql":
        return _create_pg_backup(tag)
    src = src or sqlite_path()
    if not src or not src.exists():
        return None
    s = get_settings()
    s.backups_dir.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(s.backups_dir).free
    if free < src.stat().st_size * 2 + 20 * 1024 * 1024:
        raise BackupError("فضای خالی دیسک برای پشتیبان‌گیری کافی نیست")
    with backup_lock(s.backups_dir):
        return _create_sqlite_file(tag, src, cutoff_hour, s)


def _create_sqlite_file(tag: str, src: Path, cutoff_hour: int, s) -> Path:
    dest = s.backups_dir / f"cafe-{datetime.now():%Y%m%d-%H%M%S}-{tag}.db"
    n = 1
    while dest.exists():                                   # two backups in the same second
        dest = s.backups_dir / f"cafe-{datetime.now():%Y%m%d-%H%M%S}-{tag}{'-' * n}.db"
        n += 1
    tmp = dest.with_suffix(".tmp")
    a = sqlite3.connect(src)
    b = sqlite3.connect(tmp)
    try:
        a.backup(b)
        b.execute("PRAGMA journal_mode=DELETE")     # a backup is ONE self-contained file (no -wal/-shm to forget)
    finally:
        b.close()
        a.close()
    try:
        verify(tmp)
    except BackupError:
        tmp.unlink(missing_ok=True)
        raise
    tmp.replace(dest)
    try:
        os.chmod(dest, 0o600)                          # a backup holds every sale; keep it owner-only
    except OSError:
        pass
    con = sqlite3.connect(f"file:{dest.as_posix()}?mode=ro", uri=True)
    try:
        figures = _figures_from_connection(con)
    finally:
        con.close()
    _write_manifest(dest, figures, "sqlite")
    _rotate(s.backups_dir, cutoff_hour)
    return dest


def _create_pg_backup(tag: str) -> Path:
    """PostgreSQL backup: pg_dump → verify → manifest. Locked, so runs are serialised."""
    s = get_settings()
    s.backups_dir.mkdir(parents=True, exist_ok=True)
    with backup_lock(s.backups_dir):
        dest = s.backups_dir / f"cafe-{datetime.now():%Y%m%d-%H%M%S}-{tag}.dump"
        n = 1
        while dest.exists():
            dest = s.backups_dir / f"cafe-{datetime.now():%Y%m%d-%H%M%S}-{tag}{'-' * n}.dump"
            n += 1
        free = shutil.disk_usage(s.backups_dir).free
        if free < 20 * 1024 * 1024:
            raise BackupError("فضای خالی دیسک برای پشتیبان‌گیری کافی نیست")
        pg_dump_to(dest)
        try:
            verify_dump(dest)
        except BackupError:
            dest.unlink(missing_ok=True)
            raise
        try:
            os.chmod(dest, 0o600)
        except OSError:
            pass
        figures, scratch = _drill_pg(dest)              # the manifest describes what the dump really restores to
        log.info("pg backup %s verified by a scratch restore (%s)", dest.name, scratch)
        _write_manifest(dest, figures, "postgresql")
        _rotate(s.backups_dir)
        return dest


def _cutoff(db) -> int:
    if db is None:
        return 5
    from .settings_store import get as setting
    return int(setting(db, "day.cutoff_hour", 5))


def _changed_since(src: Path, stamp: datetime) -> bool:
    """Cheap change detection: SQLite writes touch the -wal file (or the db file itself after a checkpoint)."""
    files = [src, src.with_name(src.name + "-wal")]
    newest = max((f.stat().st_mtime for f in files if f.exists()), default=0)
    return datetime.fromtimestamp(newest) > stamp


def _pg_change_token() -> int | None:
    """Cheap "did anything get written?" for PostgreSQL: the transaction counter of our own database.

    SQLite backups compare the database file's mtime; PostgreSQL has no file to stat, so the hourly job would either
    back up every hour regardless of activity or never. `xact_commit` from pg_stat_database increases with every
    committed transaction and resets when the server restarts — a reset makes the token differ, which simply means
    "take one backup now", which is the safe direction.
    """
    from sqlalchemy import text

    from .db import engine
    try:
        with engine.connect() as c:
            c.execute(text("SET statement_timeout = 5000"))
            return int(c.execute(text("SELECT xact_commit FROM pg_stat_database "
                                      "WHERE datname = current_database()")).scalar() or 0)
    except Exception:                                  # noqa: BLE001 — never block a backup on the change check
        log.warning("could not read the PostgreSQL change token; taking the backup anyway")
        return None


def auto_backup(db=None, force: bool = False) -> Path | None:
    """Background job (every few minutes) and startup: an hourly snapshot when the data changed since the last one."""
    from .db import engine

    s = get_settings()
    if engine.dialect.name == "postgresql":
        s.backups_dir.mkdir(parents=True, exist_ok=True)
        cutoff = _cutoff(db)
        _rotate(s.backups_dir, cutoff)
        autos = _auto_backups(s.backups_dir)
        last = autos[-1][0] if autos else None
        due = last is None or datetime.now() - last >= timedelta(minutes=s.backup_interval_minutes)
        if force or due:
            token = _pg_change_token()
            previous = (read_manifest(autos[-1][2]) or {}).get("change_token") if autos else None
            if force or last is None or token is None or token != previous:
                path = _create_pg_backup("hourly")
                man = read_manifest(path)
                if man is not None:
                    man["change_token"] = token
                    manifest_path(path).write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
                return path
        return None
    src = sqlite_path()
    if not src or not src.exists():
        return None
    s.backups_dir.mkdir(parents=True, exist_ok=True)
    cutoff = _cutoff(db)
    _rotate(s.backups_dir, cutoff)                       # also finishes yesterday's consolidation after a restart
    autos = _auto_backups(s.backups_dir)
    last = autos[-1][0] if autos else None
    due = last is None or datetime.now() - last >= timedelta(minutes=s.backup_interval_minutes)
    if force or (due and (last is None or _changed_since(src, last))):
        return create_backup("hourly", cutoff_hour=cutoff)
    return None


def shift_closed_backup(db=None) -> Path | None:
    """A cash shift was closed: snapshot now and keep only this one for the business day (hourlies removed)."""
    s = get_settings()
    cutoff = _cutoff(db)
    path = create_backup("daily", cutoff_hour=cutoff)
    if path:
        consolidate(s.backups_dir, cutoff, close_day=business_day_of(datetime.now(), cutoff))
    return path


daily_backup = auto_backup          # backwards-compatible name


# ---------------------------------------------------------------- restore drill (the part that proves a backup)
def _drill_sqlite(backup: Path) -> tuple[dict[str, Any], str]:
    """Restore the SQLite backup into a temp file in a temp folder and read its figures.

    The live database is never opened for writing and never replaced: the drill copies the *backup* into
    `tempfile.mkdtemp()`, reads it there, and the temp folder is removed afterwards.
    """
    folder = Path(tempfile.mkdtemp(prefix="cafe-drill-"))
    scratch = folder / backup.name
    try:
        shutil.copy2(backup, scratch)
        con = sqlite3.connect(f"file:{scratch.as_posix()}?mode=ro", uri=True)
        try:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise BackupError(f"بررسی سلامت نسخهٔ بازیابی‌شده ناموفق بود: {integrity}")
            figures = _figures_from_connection(con)
        finally:
            con.close()
        return figures, "sqlite:temp-file"
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _drill_pg(backup: Path) -> tuple[dict[str, Any], str]:
    """Restore the dump into a throw-away database, read its figures, drop it. The live DB is untouched."""
    name, parts = pg_restore_into_scratch(backup)
    try:
        return _figures_from_pg(parts, name), f"postgresql:{name}"
    finally:
        drop_scratch_db(name, parts)


def compare_figures(expected: dict[str, Any], actual: dict[str, Any]) -> list[dict[str, Any]]:
    """Differences between the manifest (what was captured) and the restore (what came back)."""
    diffs = []
    for key, want in (expected or {}).items():
        got = (actual or {}).get(key)
        if want is None and got is None:
            continue
        if want != got:
            diffs.append({"field": key, "expected": want, "actual": got})
    for key, got in (actual or {}).items():
        if key not in (expected or {}) and got is not None:
            diffs.append({"field": key, "expected": None, "actual": got})
    return diffs


def restore_drill(backup: Path | None = None) -> dict:
    """Restore the newest (or the given) backup into an isolated scratch database and compare the key figures.

    This is the only thing that turns "a file was written" into "the data can come back". It records the result,
    never modifies the live database, and is safe to run while the app is running.
    """
    s = get_settings()
    backup = backup or newest_backup()
    if not backup or not backup.exists():
        raise BackupError("نسخهٔ پشتیبانی برای آزمون بازیابی وجود ندارد")
    started = datetime.now()
    info = verify(backup)
    manifest = read_manifest(backup)
    expected = (manifest or {}).get("figures") or {}
    scratches: list[str] = []
    try:
        figures, scratch = _drill_pg(backup) if backup.suffix == ".dump" else _drill_sqlite(backup)
        scratches.append(scratch)
    except BackupError as e:
        return {"ok": False, "backup": backup.name, "error": str(e),
                "duration_ms": int((datetime.now() - started).total_seconds() * 1000)}
    diffs = compare_figures(expected, figures)
    result = {
        "ok": not diffs,
        "backup": backup.name,
        "restored_into": scratches[0],
        "duration_ms": int((datetime.now() - started).total_seconds() * 1000),
        "sha256_ok": bool(manifest and manifest.get("sha256") == _sha256(backup)),
        "figures": figures,
        "differences": diffs,
        "integrity": info.get("integrity"),
        "checked_at": datetime.now().isoformat(timespec="seconds"),
    }
    if diffs:
        result["error"] = "داده‌های بازیابی‌شده با نسخهٔ پشتیبان یکسان نیست"
    _write_drill_state(result)
    return result


def _drill_state_path() -> Path:
    return get_settings().backups_dir / "drill-state.json"


def _write_drill_state(result: dict) -> None:
    """Keep the last drill result next to the backups as well as in the DB.

    Reason: the status page must be able to show the truth even when the database is the thing that is broken —
    a state file cannot depend on the database it is reporting about.
    """
    path = _drill_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    history = read_drill_state().get("history", []) if path.exists() else []
    history.insert(0, result)
    data = {"last": result, "history": history[:20]}
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        os.chmod(path, 0o600)
    except OSError:
        log.exception("could not write drill state")


def read_drill_state() -> dict:
    try:
        return json.loads(_drill_state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def newest_backup(folder: Path | None = None) -> Path | None:
    """Newest backup file by the timestamp inside its name (not the mtime, which copying can change)."""
    folder = folder or get_settings().backups_dir
    best: tuple[datetime, Path] | None = None
    for p in folder.glob("cafe-*"):
        if p.suffix not in SUFFIXES:
            continue
        info = parse_name(p)
        if not info:
            continue
        if best is None or info[0] > best[0]:
            best = (info[0], p)
    return best[1] if best else None


def status(db=None) -> dict:
    """Everything the backup status page needs — and the staleness warning the owner asked for."""
    from .db import engine

    s = get_settings()
    folder = s.backups_dir
    files = sorted([p for p in folder.glob("cafe-*") if p.suffix in SUFFIXES]) if folder.exists() else []
    newest = newest_backup(folder)
    now = datetime.now()
    stamp = parse_name(newest)[0] if newest else None
    age_hours = round((now - stamp).total_seconds() / 3600, 1) if stamp else None
    manifest = read_manifest(newest) if newest else None
    drill = read_drill_state().get("last") if read_drill_state() else None
    runs = recent_runs(db)
    last_ok = next((r for r in runs if r["kind"] == "backup" and r["status"] == "ok"), None)
    return {
        "database": engine.dialect.name,
        "folder": str(folder),
        "enabled": s.background_jobs,
        "interval_minutes": s.backup_interval_minutes,
        "keep_days": s.backup_keep,
        "count": len(files),
        "total_size": sum(p.stat().st_size for p in files),
        "newest": None if not newest else {
            "name": newest.name,
            "size": newest.stat().st_size,
            "created_at": stamp.isoformat(timespec="seconds") if stamp else None,
            "age_hours": age_hours,
            "kind": parse_name(newest)[1],
            "verified_manifest": bool(manifest),
        },
        "stale": (age_hours is None) or (age_hours > STALE_AFTER_HOURS),
        "stale_after_hours": STALE_AFTER_HOURS,
        "last_successful_backup": last_ok,
        "last_drill": drill,
        "drill_state": "never" if not drill else ("ok" if drill.get("ok") else "failed"),
        "recent": runs[:10],
        "errors": [r for r in runs if r["status"] == "failed"][:5],
        "pg_tools": pg_tools() if engine.dialect.name == "postgresql" else None,
        "disk_free": shutil.disk_usage(folder).free if folder.exists() else None,
    }


def recent_runs(db=None, limit: int = 10) -> list[dict]:
    """Backup/drill history from the `backup_runs` table (falls back to an empty list when unavailable)."""
    from .db import SessionLocal

    own = db is None
    session = SessionLocal() if own else db
    try:
        from .models import BackupRun

        rows = session.query(BackupRun).order_by(BackupRun.id.desc()).limit(limit).all()
        return [{"id": r.id, "kind": r.kind, "status": r.status, "file": r.file, "size": r.size,
                 "duration_ms": r.duration_ms, "detail": r.detail,
                 "at": r.created_at.isoformat(timespec="seconds") if r.created_at else None} for r in rows]
    except Exception:                                       # noqa: BLE001 — status must never crash the page
        try:
            session.rollback()
        except Exception:                                   # noqa: BLE001
            pass
        return []
    finally:
        if own:
            session.close()


def record_run(db, kind: str, status_: str, *, file: str | None = None, size: int | None = None,
               duration_ms: int | None = None, detail: str | None = None) -> None:
    """Write one backup/drill attempt to the history table (best effort: never breaks the caller)."""
    try:
        from .models import BackupRun

        db.add(BackupRun(kind=kind, status=status_, file=file, size=size, duration_ms=duration_ms,
                         detail=(detail or "")[:1000] or None))
        db.commit()
    except Exception:                                       # noqa: BLE001
        try:
            db.rollback()
        except Exception:                                   # noqa: BLE001
            pass
        log.exception("could not record backup run")


def drill_and_record(db=None) -> dict:
    """Run the drill and store the outcome (used by the API, the CLI and the background job)."""
    from .db import SessionLocal

    own = db is None
    session = SessionLocal() if own else db
    started = datetime.now()
    try:
        result = restore_drill()
    except BackupError as e:
        result = {"ok": False, "error": str(e), "duration_ms": int((datetime.now() - started).total_seconds() * 1000)}
    record_run(session, "drill", "ok" if result.get("ok") else "failed", file=result.get("backup"),
               duration_ms=result.get("duration_ms"),
               detail=None if result.get("ok") else str(result.get("error"))[:1000])
    if own:
        session.close()
    return result


def restore_backup(backup: Path, target: Path | None = None) -> dict:
    """Replace the live database with `backup`. The server MUST be stopped (checked by the CLI).

    Steps: verify the backup → safety copy of the current DB (pre-restore) → copy pages with the SQLite backup API
    (handles WAL correctly, unlike copying files) → verify the result. The current data is untouched if any step fails
    before the copy, and recoverable from the pre-restore copy otherwise.
    """
    target = target or sqlite_path()
    if not target:
        raise BackupError("بازیابی فقط برای پایگاه داده SQLite پشتیبانی می‌شود")
    info = verify(backup)
    safety = create_backup("pre-restore", src=target) if target.exists() else None
    src = sqlite3.connect(f"file:{backup.as_posix()}?mode=ro", uri=True)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
        dst.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    finally:
        dst.close()
        src.close()
    after = verify(target)
    if after["counts"] != info["counts"]:
        raise BackupError(f"پس از بازیابی، تعداد رکوردها با فایل پشتیبان یکسان نیست؛ نسخه قبلی: {safety}")
    return {"restored_from": str(backup), "safety_copy": str(safety) if safety else None, "counts": after["counts"]}
