"""Optional HTTPS for the local network (CAFE_HTTPS=true).

A private certificate authority is created once per installation (data/tls/ca.crt + ca.key). It signs a server
certificate for this computer's LAN addresses / hostname; the server certificate is re-issued automatically when the
addresses change or it gets close to expiry. Each device trusts the CA once (download http(s)://<server>/ca.crt) and
then sees a normal padlock — no browser warnings, wss:// for live updates, secure-context browser features.
"""
import datetime as dt
import ipaddress
import os
import socket
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

SERVER_DAYS = 800          # Apple devices reject server certificates valid for more than 825 days
CA_YEARS = 10
RENEW_BEFORE_DAYS = 30


def _write_key(path: Path, key) -> None:
    path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _ensure_ca(d: Path):
    key_p, crt_p = d / "ca.key", d / "ca.crt"
    if key_p.exists() and crt_p.exists():
        return serialization.load_pem_private_key(key_p.read_bytes(), None), x509.load_pem_x509_certificate(crt_p.read_bytes())
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"Cafe POS Local CA ({socket.gethostname()[:30]})"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Cafe POS")])
    ski = x509.SubjectKeyIdentifier.from_public_key(key.public_key())
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(_now() - dt.timedelta(days=1)).not_valid_after(_now() + dt.timedelta(days=365 * CA_YEARS))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False,
                                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .add_extension(ski, critical=False)
            .sign(key, hashes.SHA256()))
    _write_key(key_p, key)
    crt_p.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return key, cert


def _names(ips: list[str]) -> tuple[set[str], set[str]]:
    host = socket.gethostname()
    dns = {"localhost", host} | ({f"{host}.local"} if host and "." not in host else set())
    return {d for d in dns if d}, {"127.0.0.1", *ips}


def _covers(cert: x509.Certificate, dns: set[str], ips: set[str]) -> bool:
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return False
    have_ip = {str(i) for i in san.get_values_for_type(x509.IPAddress)}
    have_dns = set(san.get_values_for_type(x509.DNSName))
    return ips <= have_ip and dns <= have_dns and cert.not_valid_after_utc - _now() > dt.timedelta(days=RENEW_BEFORE_DAYS)


def ensure_certs(data_dir: Path, ips: list[str]) -> dict[str, Path]:
    """Create/renew the CA and server certificate. Returns paths: ca, cert (server + CA chain), key."""
    d = Path(data_dir) / "tls"
    d.mkdir(parents=True, exist_ok=True)
    ca_key, ca_cert = _ensure_ca(d)
    crt_p, key_p = d / "server.crt", d / "server.key"
    dns, ip_set = _names(ips)
    if crt_p.exists() and key_p.exists():
        current = x509.load_pem_x509_certificates(crt_p.read_bytes())[0]
        if _covers(current, dns, ip_set) and current.issuer == ca_cert.subject:
            return {"ca": d / "ca.crt", "cert": crt_p, "key": key_p}
    key = ec.generate_private_key(ec.SECP256R1())
    san = [x509.DNSName(n) for n in sorted(dns)] + [x509.IPAddress(ipaddress.ip_address(i)) for i in sorted(ip_set)]
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, socket.gethostname()[:60] or "cafe-pos")]))
            .issuer_name(ca_cert.subject).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(_now() - dt.timedelta(days=1)).not_valid_after(_now() + dt.timedelta(days=SERVER_DAYS))
            .add_extension(x509.SubjectAlternativeName(san), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
            .sign(ca_key, hashes.SHA256()))
    _write_key(key_p, key)
    crt_p.write_bytes(cert.public_bytes(serialization.Encoding.PEM) + ca_cert.public_bytes(serialization.Encoding.PEM))
    return {"ca": d / "ca.crt", "cert": crt_p, "key": key_p}
