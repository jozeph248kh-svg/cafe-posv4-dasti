from datetime import date, datetime, time, timedelta
from typing import Annotated

from pydantic import AfterValidator


def now() -> datetime:
    return datetime.now().replace(microsecond=0)


def business_day(dt: datetime | None = None, cutoff_hour: int = 5) -> date:
    """Business date: orders placed after midnight (until cutoff) belong to the previous day."""
    dt = dt or now()
    return (dt - timedelta(hours=cutoff_hour)).date()


def day_bounds(d: date, cutoff_hour: int = 5) -> tuple[datetime, datetime]:
    start = datetime.combine(d, time(cutoff_hour))
    return start, start + timedelta(days=1)


def _local_naive(v: datetime) -> datetime:
    """Inputs may arrive as ISO strings with an offset or as Unix numbers (→ aware UTC). The database stores the
    server's local wall-clock time without tzinfo, so convert and strip; also reject absurd years (e.g. epoch 1970)."""
    if v.tzinfo is not None:
        v = v.astimezone().replace(tzinfo=None)
    if not 2000 <= v.year <= 2100:
        raise ValueError("تاریخ معتبر نیست")
    return v


LocalDateTime = Annotated[datetime, AfterValidator(_local_naive)]
"""Use for every datetime that comes FROM a request (body or query)."""


_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def normalize_phone(p: str | None) -> str | None:
    """'۰۹۱۲ ۳۴۵-۶۷۸۹' / '+98912…' -> '0912…' so lookups match however the number was typed.

    Every phone number in the database goes through here, so the same customer typed in slightly
    different ways must always land on the same string: '0912…', '+98912…', '0098912…' (the form
    contact books export), '98912…' and '912…' (no leading zero) all become '0912…'.
    """
    if not p:
        return None
    if "*" in p:                    # a masked number (0912***4567) echoed back by a form — never store it
        from app.core.errors import AppError
        raise AppError("شماره تلفن را کامل وارد کنید", 422, "phone_masked")
    digits = "".join(ch for ch in p.translate(_DIGITS) if ch.isdigit())
    if digits.startswith("00"):                       # international prefix typed as 00 instead of +
        digits = digits[2:]
    if digits.startswith("98") and len(digits) == 12:  # country code without the + or 00
        digits = "0" + digits[2:]
    if len(digits) == 10 and digits.startswith("9"):   # mobile typed without the leading zero
        digits = "0" + digits
    return digits or None


_FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def fa_digits(v) -> str:
    return str(v).translate(_FA)


def fa_money(v: int | float | None) -> str:
    return fa_digits(f"{int(v or 0):,}").replace(",", "٬")


def to_jalali(d: date) -> tuple[int, int, int]:
    """Gregorian → Jalali (Solar Hijri), the standard arithmetic algorithm (valid for 1900–2100)."""
    gy, gm, gd = d.year, d.month, d.day
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + (365 * gy) + ((gy2 + 3) // 4) - ((gy2 + 99) // 100) + ((gy2 + 399) // 400) + gd + g_d_m[gm - 1]
    jy = -1595 + (33 * (days // 12053))
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    jm = 1 + days // 31 if days < 186 else 7 + (days - 186) // 30
    jd = 1 + (days % 31 if days < 186 else (days - 186) % 30)
    return jy, jm, jd


JALALI_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]


def jalali_str(d: date, long: bool = False) -> str:
    y, m, dd = to_jalali(d)
    return fa_digits(f"{dd} {JALALI_MONTHS[m - 1]}") if long else fa_digits(f"{y}/{m:02d}/{dd:02d}")


def phone_update(new: str | None, old: str | None) -> str | None:
    """For edit forms: a masked value means «unchanged» (the user could only see the masked number)."""
    if new and "*" in new:
        return old
    return normalize_phone(new)
