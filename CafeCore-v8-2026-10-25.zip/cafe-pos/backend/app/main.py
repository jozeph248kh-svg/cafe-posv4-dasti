"""Cafe POS — application entry point.

Modules are discovered from `app/modules/*`, their tables are created, seeds run and routers are mounted
under `/api/<module>`. The built React app (frontend/ui) is served from `/`.
"""
import logging
import re
from contextlib import asynccontextmanager

from fastapi import FastAPI, Query, Response, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import DataError, IntegrityError, OperationalError

from app.core import jobs
from app.core import models as _core_models  # noqa: F401  (register core tables)
from app.core.backup import auto_backup, drill_and_record
from app.core.concurrency import WriteIntentMiddleware
from app.core.config import FRONTEND_DIST, get_settings
from app.core.db import Base, SessionLocal, engine
from app.core.deps import user_from_token
from app.core.device import DeviceMiddleware
from app.core.errors import AppError
from app.core.privacy import PhoneMaskMiddleware
from app.core.modules import registry
from app.core.realtime import hub

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("cafe")


class _RedactTokens(logging.Filter):
    """Access logs must not contain bearer tokens (the WebSocket passes it as ?token=)."""
    def filter(self, record: logging.LogRecord) -> bool:
        if record.args and isinstance(record.args, tuple):
            record.args = tuple(re.sub(r"token=[^&\s\"]+", "token=***", a) if isinstance(a, str) else a for a in record.args)
        return True


for _name in ("uvicorn.access", "uvicorn.error"):    # uvicorn logs "WebSocket /ws?token=… [accepted]" on uvicorn.error
    logging.getLogger(_name).addFilter(_RedactTokens())
settings = get_settings()
modules = registry.discover(settings.enabled_modules)


def init_data() -> None:
    from app.core.backup import create_backup
    from app.core.migrate import upgrade
    upgrade(engine, Base.metadata, backup=create_backup)   # additive only, backup first
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        for m in modules:
            if m.seed:
                m.seed(db)
                db.commit()
        if settings.demo_data:
            from app import demo
            try:
                demo.run(db)
            except Exception:      # demo data must never block startup
                log.exception("demo data failed")
                db.rollback()
            for m in modules:          # per-module demo data (each must be idempotent)
                if m.demo:
                    try:
                        m.demo(db)
                        db.commit()
                    except Exception:
                        log.exception("demo data failed for %s", m.name)
                        db.rollback()


def _banner() -> None:
    """Print the addresses other devices (kitchen tablet, waiter phones) should open."""
    try:
        from app.modules.system.router import lan_addresses
        ips = lan_addresses()
    except Exception:  # noqa: BLE001
        ips = []
    sc = "https" if settings.https else "http"
    lines = ["", "=" * 58, "  Cafe POS is running", f"  This computer : {sc}://localhost:{settings.port}"]
    lines += [f"  Other devices : {sc}://{ip}:{settings.port}" for ip in ips]
    lines += ["  (phones/tablets must be on the same Wi-Fi network)"]
    if settings.https:
        lines += [f"  HTTPS: install the certificate once on each device: {sc}://<address>:{settings.port}/ca.crt"]
    lines += ["=" * 58, ""]
    print("\n".join(lines), flush=True)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_data()
    await hub.start()
    if settings.background_jobs:
        jobs.start([*registry.jobs, jobs.Job("backup.auto", 300, auto_backup),
                    # prove the newest backup is restorable, once a day (never touches the live database)
                    jobs.Job("backup.drill", 24 * 3600, lambda db: drill_and_record(db))])
    try:
        from app.core.db import SessionLocal
        with SessionLocal() as db:
            auto_backup(db)
    except Exception:
        log.exception("backup failed")
    _banner()
    yield
    await jobs.stop()


app = FastAPI(title=settings.app_name, version=settings.version, lifespan=lifespan, redoc_url=None,
              docs_url="/api/docs" if settings.api_docs else None,
              openapi_url="/api/openapi.json" if settings.api_docs else None)
if settings.cors_origins.strip():   # the UI is served by this same server, so CORS is only needed for custom setups
    app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
                       allow_methods=["*"], allow_headers=["*"])
app.add_middleware(PhoneMaskMiddleware)          # inner to gzip: masks before compression
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(WriteIntentMiddleware)
app.add_middleware(DeviceMiddleware)            # X-Register-Id → which cash drawer this device uses
registry.mount(app)


@app.exception_handler(AppError)
async def app_error_handler(_, exc: AppError):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


def _err(status: int, message: str, code: str) -> JSONResponse:
    return JSONResponse(status_code=status, content={"detail": {"message": message, "code": code}})


@app.exception_handler(IntegrityError)
async def integrity_error_handler(request, exc: IntegrityError):
    log.warning("integrity error on %s %s: %s", request.method, request.url.path, str(exc.orig)[:200])
    return _err(409, "این اطلاعات با رکورد دیگری تداخل دارد (تکراری یا وابسته)", "conflict")


@app.exception_handler(OperationalError)
async def db_operational_error_handler(request, exc: OperationalError):
    log.error("database error on %s %s: %s", request.method, request.url.path, str(exc.orig)[:200])
    if "locked" in str(exc.orig).lower() or "busy" in str(exc.orig).lower():
        return _err(503, "سرور در حال انجام عملیات دیگری است؛ چند لحظه بعد دوباره تلاش کنید", "db_busy")
    return _err(500, "خطای پایگاه داده؛ عملیات انجام نشد", "db_error")


@app.exception_handler(OverflowError)
async def overflow_error_handler(request, exc: OverflowError):
    # e.g. an id/amount larger than SQLite's 64-bit integer
    return _err(422, "عدد واردشده بیش از حد بزرگ است", "number_too_large")


@app.exception_handler(DataError)
async def data_error_handler(request, exc: DataError):
    # PostgreSQL checks value ranges itself (e.g. an id beyond its 32-bit INTEGER): bad input, not a server fault
    log.warning("data error on %s %s: %s", request.method, request.url.path, str(exc.orig).splitlines()[0][:200])
    if "out of range" in str(exc.orig):
        return _err(422, "عدد واردشده بیش از حد بزرگ است", "number_too_large")
    return _err(422, "مقدار واردشده معتبر نیست", "invalid_value")


@app.exception_handler(Exception)
async def unhandled_error_handler(request, exc: Exception):
    # never leak tracebacks/SQL to clients; full details go to the server log
    log.exception("unhandled error on %s %s", request.method, request.url.path)
    return _err(500, "خطای داخلی سرور؛ عملیات انجام نشد", "internal")


@app.get("/api/health")
def health(response: Response):
    """Liveness **and** readiness.

    A process that is running but cannot reach its database must not report «ok»: the POS would keep sending
    orders to an endpoint that can only fail them, and a monitoring script would stay silent (final security
    audit). `db` says what was actually checked; the HTTP status turns 503 when the probe fails, so anything that
    watches for 200 notices immediately.
    """
    db_state = "ok"
    try:
        from sqlalchemy import text

        from app.core.db import engine
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
    except Exception:                                  # noqa: BLE001 — the probe must never raise
        db_state = "down"
        log.warning("health: database probe failed", exc_info=True)
    payload = {"status": "ok" if db_state == "ok" else "degraded", "db": db_state, "version": settings.version,
               "modules": [m.name for m in modules], "clients": len(hub.clients)}
    if db_state != "ok":
        response.status_code = 503
    return payload


@app.get("/ca.crt", include_in_schema=False)
def ca_certificate():
    """Local HTTPS certificate authority (public part) — installed once on each device to trust this server."""
    ca = settings.data_dir / "tls" / "ca.crt"
    if not ca.exists():
        return JSONResponse({"detail": {"message": "HTTPS فعال نیست", "code": "https_off"}}, status_code=404)
    return FileResponse(ca, media_type="application/x-x509-ca-cert", filename="cafe-pos-ca.crt")


@app.get("/api/modules")
def list_modules():
    return [{"name": m.name, "title": m.title, "version": m.version, "description": m.description, "core": m.core}
            for m in modules]


@app.websocket("/ws")
async def ws(websocket: WebSocket, token: str = Query(...)):
    with SessionLocal() as db:
        try:
            user = user_from_token(db, token, "/ws")
        except AppError:
            await websocket.close(code=4401)
            return
    await websocket.accept()
    perms = frozenset(["*"] if "*" in user.role.permissions else user.role.permissions)
    hub.add(websocket, user.id, perms)
    log.info("ws connected: %s (%d clients)", user.username, len(hub.clients))
    try:
        while True:
            msg = await websocket.receive_text()
            if msg == "ping":
                await websocket.send_text('{"topic":"pong"}')
    except WebSocketDisconnect:
        pass
    finally:
        hub.remove(websocket)


app.mount("/uploads", StaticFiles(directory=settings.uploads_dir), name="uploads")

def ui_missing_response(full_path: str = ""):
    """The API is up but the prebuilt UI is missing/empty: answer with instructions, never a blank 500.

    One implementation for both mount paths, so the message the shop sees is the same whether the whole
    `frontend/ui` folder is absent or the folder is there without `index.html`.
    """
    if full_path.startswith(("api/", "ws")):
        return JSONResponse({"detail": {"message": "یافت نشد", "code": "not_found"}}, status_code=404)
    return PlainTextResponse(
        "Cafe POS API is running, but the web UI is not installed.\n"
        "Build it with:  cd frontend && npm run build   (creates frontend/ui)\n"
        "or unpack the full release package (it ships with the UI).\n\n"
        "سرور بالا آمده ولی رابط کاربری نصب نشده است؛ بسته‌ی کامل را از حالت فشرده خارج کنید یا frontend را build کنید.",
        status_code=503)


if FRONTEND_DIST.exists() and (FRONTEND_DIST / "index.html").is_file():
    app.mount("/assets", StaticFiles(directory=FRONTEND_DIST / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        if full_path.startswith(("api/", "ws")):
            return JSONResponse({"detail": {"message": "یافت نشد", "code": "not_found"}}, status_code=404)
        file = (FRONTEND_DIST / full_path).resolve()
        if full_path and file.is_file() and FRONTEND_DIST.resolve() in file.parents:
            return FileResponse(file)
        index = FRONTEND_DIST / "index.html"
        if not index.is_file():
            # a half-installed bundle (UI folder present but empty) must say what to do, not 500
            return ui_missing_response(full_path)
        return FileResponse(index, headers={"Cache-Control": "no-cache"})


else:
    @app.get("/{full_path:path}", include_in_schema=False)
    def ui_missing(full_path: str):
        return ui_missing_response(full_path)
