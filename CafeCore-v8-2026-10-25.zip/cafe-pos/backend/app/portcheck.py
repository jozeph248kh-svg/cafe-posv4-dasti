"""Used by start.bat before starting the server: a clear message instead of uvicorn's "[Errno 98] address already in use"."""
import socket
import sys


def main() -> int:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("0.0.0.0", port))
        except OSError:
            print(f"[ERROR] Port {port} is already in use.")
            print(f"        Cafe POS may already be running: open http://localhost:{port}")
            print("        Or start it on another port, e.g.  Windows: set PORT=8080   Linux: PORT=8080 bash start.bat")
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
