from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


class SmsMessage(Base, TimestampMixin):
    """Outbox: every SMS goes through this table and is sent by a background job (requests never wait on the provider)."""
    __tablename__ = "sms_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    to: Mapped[str] = mapped_column(String(20), index=True)
    text: Mapped[str] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(30), index=True)          # event key | campaign | manual | test
    ref: Mapped[str | None] = mapped_column(String(60), index=True)    # de-duplication key, e.g. "resv-remind:12"
    campaign_id: Mapped[int | None] = mapped_column(ForeignKey("sms_campaigns.id"), index=True)
    status: Mapped[str] = mapped_column(String(10), default="queued", index=True)   # queued | sending | sent | failed
    provider: Mapped[str | None] = mapped_column(String(20))
    provider_id: Mapped[str | None] = mapped_column(String(60))
    error: Mapped[str | None] = mapped_column(String(300))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    sending_at: Mapped[datetime | None] = mapped_column(DateTime)       # claimed by a sender (status «sending»)
    parts: Mapped[int] = mapped_column(Integer, default=1)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class SmsCampaign(Base, TimestampMixin):
    __tablename__ = "sms_campaigns"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(120))
    text: Mapped[str] = mapped_column(Text)
    segment: Mapped[dict] = mapped_column(JSON, default=dict)
    total: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class SmsOptOut(Base, TimestampMixin):
    """Numbers that asked not to receive marketing messages (service messages like order status still go out)."""
    __tablename__ = "sms_optout"
    id: Mapped[int] = mapped_column(primary_key=True)
    phone: Mapped[str] = mapped_column(String(20), unique=True)
    note: Mapped[str | None] = mapped_column(String(120))
