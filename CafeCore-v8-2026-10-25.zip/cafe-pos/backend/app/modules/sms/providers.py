"""SMS gateways. Each provider: `send(to, text) -> message id` (raises SmsError) and `credit() -> str | None`.

Endpoints follow the providers' official REST docs:
  Kavenegar   POST https://api.kavenegar.com/v1/{API-KEY}/sms/send.json   (receptor, sender, message)
  SMS.ir      POST https://api.sms.ir/v1/send/bulk   header X-API-KEY   {lineNumber, messageText, mobiles}
  MeliPayamak POST https://console.melipayamak.com/api/send/simple/{token}   {from, to, text}
"""
import itertools

import httpx

TIMEOUT = 15


class SmsError(Exception):
    pass


def _json(r: httpx.Response) -> dict:
    try:
        return r.json()
    except ValueError as e:
        raise SmsError(f"پاسخ نامعتبر از سرویس پیامک (HTTP {r.status_code})") from e


class TestProvider:
    """Simulator for setup and demos: nothing leaves the building. Numbers ending in 0000 fail on purpose."""
    key, title = "test", "حالت آزمایشی (بدون ارسال واقعی)"
    fields: list = []
    _seq = itertools.count(1000)

    def __init__(self, cfg: dict):
        self.cfg = cfg

    def send(self, to: str, text: str) -> str:
        if to.endswith("0000"):
            raise SmsError("شماره در حالت آزمایشی مسدود است (برای تست خطا)")
        return f"TEST-{next(self._seq)}"

    def credit(self) -> str | None:
        return "نامحدود (آزمایشی)"


class Kavenegar:
    key, title = "kavenegar", "کاوه‌نگار"
    fields = [("api_key", "کلید API (API Key)", True), ("sender", "شماره خط ارسال", False)]

    def __init__(self, cfg: dict):
        self.api_key, self.sender = (cfg.get("api_key") or "").strip(), (cfg.get("sender") or "").strip()
        if not self.api_key:
            raise SmsError("کلید API کاوه‌نگار وارد نشده است")

    def _call(self, path: str, data: dict | None = None) -> dict:
        r = httpx.post(f"https://api.kavenegar.com/v1/{self.api_key}/{path}", data=data or {}, timeout=TIMEOUT)
        j = _json(r)
        ret = j.get("return") or {}
        if ret.get("status") != 200:
            raise SmsError(f"کاوه‌نگار: {ret.get('message') or r.status_code}")
        return j

    def send(self, to: str, text: str) -> str:
        data = {"receptor": to, "message": text}
        if self.sender:
            data["sender"] = self.sender
        entries = self._call("sms/send.json", data).get("entries") or [{}]
        return str(entries[0].get("messageid", ""))

    def credit(self) -> str | None:
        e = self._call("account/info.json").get("entries") or {}
        return f"{int(e.get('remaincredit', 0)):,} ریال"


class SmsIr:
    key, title = "smsir", "SMS.ir"
    fields = [("api_key", "کلید API (X-API-KEY)", True), ("line", "شماره خط ارسال", True)]

    def __init__(self, cfg: dict):
        self.api_key, self.line = (cfg.get("api_key") or "").strip(), (cfg.get("line") or "").strip()
        if not self.api_key or not self.line:
            raise SmsError("کلید API و شماره خط SMS.ir را وارد کنید")

    def _headers(self) -> dict:
        return {"X-API-KEY": self.api_key, "Accept": "application/json"}

    def send(self, to: str, text: str) -> str:
        r = httpx.post("https://api.sms.ir/v1/send/bulk", headers=self._headers(), timeout=TIMEOUT,
                       json={"lineNumber": int(self.line), "messageText": text, "mobiles": [to], "sendDateTime": None})
        j = _json(r)
        if j.get("status") != 1:
            raise SmsError(f"SMS.ir: {j.get('message') or r.status_code}")
        ids = (j.get("data") or {}).get("messageIds") or [""]
        return str(ids[0])

    def credit(self) -> str | None:
        j = _json(httpx.get("https://api.sms.ir/v1/credit", headers=self._headers(), timeout=TIMEOUT))
        if j.get("status") != 1:
            raise SmsError(f"SMS.ir: {j.get('message')}")
        return f"{j.get('data')} پیامک"


class MeliPayamak:
    key, title = "melipayamak", "ملی‌پیامک"
    fields = [("token", "توکن کنسول (console.melipayamak.com)", True), ("sender", "شماره خط ارسال", True)]

    def __init__(self, cfg: dict):
        self.token, self.sender = (cfg.get("token") or "").strip(), (cfg.get("sender") or "").strip()
        if not self.token or not self.sender:
            raise SmsError("توکن و شماره خط ملی‌پیامک را وارد کنید")

    def send(self, to: str, text: str) -> str:
        r = httpx.post(f"https://console.melipayamak.com/api/send/simple/{self.token}", timeout=TIMEOUT,
                       json={"from": self.sender, "to": to, "text": text})
        j = _json(r)
        rec = j.get("recId")
        if not rec or (isinstance(rec, int) and rec <= 0):
            raise SmsError(f"ملی‌پیامک: {j.get('status') or r.status_code}")
        return str(rec)

    def credit(self) -> str | None:
        j = _json(httpx.get(f"https://console.melipayamak.com/api/receive/credit/{self.token}", timeout=TIMEOUT))
        return f"{j.get('amount')} پیامک" if j.get("amount") is not None else None


PROVIDERS = {p.key: p for p in (TestProvider, Kavenegar, SmsIr, MeliPayamak)}


def parts(text: str) -> int:
    """Persian SMS are UCS-2: 70 chars in one part, 67 per part when concatenated."""
    n = len(text)
    return 1 if n <= 70 else -(-n // 67)
