from app.core import events, settings_store
from app.core.jobs import Job
from app.core.modules import Module
from app.core.permissions import grant_once

from . import service
from .router import router

settings_store.register_defaults(service.DEFAULTS, secrets={"sms.config"}, protected={"sms."})


def setup() -> None:
    events.subscribe("reservation.created", service.on_reservation)
    events.subscribe("online.accepted", service.on_online_accepted)
    events.subscribe("kitchen.ready", service.on_kitchen_ready)
    events.subscribe("delivery.status", service.on_delivery)
    events.subscribe("wallet.topup", service.on_topup)


def seed(db) -> None:
    grant_once(db, "sms", {"manager": ["sms.manage"]})


def demo(db) -> None:
    """A few sent messages + a past campaign so the SMS center is not empty."""
    from datetime import timedelta

    from app.core.utils import now

    from .models import SmsCampaign, SmsMessage
    if db.query(SmsMessage).count():
        return
    t = now()
    c = SmsCampaign(title="تخفیف ۲۰٪ آخر هفته", text="مشتری عزیز، این پنجشنبه و جمعه ۲۰٪ تخفیف روی همه نوشیدنی‌ها 🎉\nلغو۱۱", segment={"type": "all"}, total=3)
    db.add(c)
    db.flush()
    rows = [("09121112233", "سفارش #۵۱ شما توسط پیک (مهدی رنجبر) ارسال شد. مبلغ قابل پرداخت: ۷۷۰٬۰۰۰ تومان", "delivery_out", None, 50),
            ("09123334455", "سارا عزیز، رزرو شما در کافه رستوران من برای ۲ آبان ساعت ۲۰:۰۰ (۴ نفر) ثبت شد.", "reservation_created", None, 120),
            ("09127778899", "سفارش #۴۴ شما آماده تحویل است. کافه رستوران من", "order_ready", None, 200)]
    rows += [(p, c.text, "campaign", c.id, 60 * 26) for p in ("09121112233", "09123334455", "09127778899")]
    for to, text, kind, cid, ago in rows:
        m = SmsMessage(to=to, text=text, kind=kind, campaign_id=cid, status="sent", provider="test", provider_id="TEST-DEMO", parts=1 if len(text) <= 70 else 2,
                       sent_at=t - timedelta(minutes=ago), attempts=1)
        db.add(m)
        db.flush()
        m.created_at = t - timedelta(minutes=ago)


module = Module(
    name="sms",
    title="پیامک",
    description="پیامک خودکار (رزرو، سفارش آنلاین، پیک، آماده بودن سفارش، کیف پول)، کمپین تبلیغاتی برای باشگاه مشتریان؛ کاوه‌نگار، SMS.ir، ملی‌پیامک",
    depends=["customers"],
    routers=[router],
    permissions={"sms.manage": "مدیریت پیامک و کمپین‌ها"},
    seed=seed,
    demo=demo,
    setup=setup,
    jobs=[Job("sms.queue", 5, service.process_queue), Job("sms.reminders", 60, service.reservation_reminders)],
)
