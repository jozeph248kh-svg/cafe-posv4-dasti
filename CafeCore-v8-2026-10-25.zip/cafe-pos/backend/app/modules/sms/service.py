import logging
import re
from datetime import timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.utils import fa_digits, fa_money, jalali_str, normalize_phone, now

from .models import SmsMessage, SmsOptOut
from .providers import PROVIDERS, SmsError, parts

log = logging.getLogger("sms")

# event key -> (title, default template, placeholders)
EVENTS: dict[str, tuple[str, str, list[str]]] = {
    "reservation_created": ("تأیید رزرو میز", "{name} عزیز، رزرو شما در {business} برای {date} ساعت {time} ({guests} نفر) ثبت شد.", ["name", "date", "time", "guests", "business"]),
    "reservation_reminder": ("یادآوری رزرو", "یادآوری: {name} عزیز، امروز ساعت {time} میزبان شما در {business} هستیم.", ["name", "time", "guests", "business"]),
    "online_accepted": ("تأیید سفارش آنلاین", "{name} عزیز، سفارش #{number} شما تأیید شد. زمان تقریبی {eta} دقیقه.\nپیگیری: {link}", ["name", "number", "eta", "link", "business"]),
    "order_ready": ("آماده بودن سفارش بیرون‌بر", "سفارش #{number} شما آماده تحویل است. {business}", ["name", "number", "business"]),
    "delivery_out": ("ارسال سفارش با پیک", "سفارش #{number} شما توسط پیک ({courier}) ارسال شد. {amount_line}", ["name", "number", "courier", "amount_line", "business"]),
    "wallet_topup": ("شارژ کیف پول", "کیف پول شما در {business} به مبلغ {amount} تومان شارژ شد. موجودی: {balance} تومان", ["name", "amount", "balance", "business"]),
}
MARKETING = {"campaign"}

DEFAULTS = {
    "sms.enabled": True,
    "sms.provider": "test",
    "sms.config": {},                     # {provider_key: {field: value}}
    "sms.optout_footer": "لغو۱۱",          # required on marketing messages by the regulator
    "sms.reminder_minutes": 120,
    "sms.quiet_start": 23,                # campaigns are not sent between 23:00 and 08:00
    "sms.quiet_end": 8,
    **{f"sms.ev.{k}": k != "wallet_topup" for k in EVENTS},
    **{f"sms.tpl.{k}": v[1] for k, v in EVENTS.items()},
}


class _Safe(dict):
    def __missing__(self, k):
        return ""


def render(tpl: str, **ctx) -> str:
    return re.sub(r"\n{3,}", "\n\n", tpl.format_map(_Safe(ctx))).strip()


def valid_mobile(p: str | None) -> str | None:
    p = normalize_phone(p)
    return p if p and p.startswith("09") and len(p) == 11 else None


def provider(db: Session):
    s = settings_store.get_all(db)
    key = s.get("sms.provider") or "test"
    cls = PROVIDERS.get(key)
    if not cls:
        raise SmsError(f"سرویس پیامک «{key}» شناخته نشد")
    return cls((s.get("sms.config") or {}).get(key) or {})


def enqueue(db: Session, to: str | None, text: str, kind: str, ref: str | None = None, campaign_id: int | None = None, user_id: int | None = None) -> SmsMessage | None:
    phone = valid_mobile(to)
    if not phone or not text.strip():
        return None
    if ref and db.query(SmsMessage.id).filter(SmsMessage.ref == ref).first():
        return None
    if kind in MARKETING and db.query(SmsOptOut.id).filter(SmsOptOut.phone == phone).first():
        return None
    m = SmsMessage(to=phone, text=text.strip(), kind=kind, ref=ref, campaign_id=campaign_id, parts=parts(text), status="queued", created_by=user_id)
    db.add(m)
    return m


def notify(db: Session, event: str, to: str | None, ref: str | None = None, **ctx) -> SmsMessage | None:
    """Business-event SMS (respecting the on/off switch and the editable template)."""
    s = settings_store.get_all(db)
    if not s.get("sms.enabled") or not s.get(f"sms.ev.{event}"):
        return None
    text = render(s.get(f"sms.tpl.{event}") or EVENTS[event][1], business=s.get("business.name", ""), **ctx)
    return enqueue(db, to, text, event, ref=ref)


STALE_SENDING = timedelta(minutes=10)
INTERRUPTED = "ارسال نیمه‌کاره ماند (قطع برنامه/برق)؛ معلوم نیست پیامک رسیده یا نه — در صورت نیاز دوباره بفرستید"


def claim(db: Session, ids: list[int]) -> list[tuple[int, str, str, int, str]]:
    """Atomically move queued messages to «sending» and COMMIT, so the background job, a manual send and a
    second device can never send the same message twice (conditional UPDATE: only one claimer wins per row).
    Returns (id, to, text, attempts, kind) of the claimed rows; the provider is then called outside any transaction."""
    t, got = now(), []
    for i in ids:
        if db.query(SmsMessage).filter(SmsMessage.id == i, SmsMessage.status == "queued").update(
                {"status": "sending", "sending_at": t, "attempts": SmsMessage.attempts + 1}, synchronize_session=False):
            got.append(i)
    rows = (db.query(SmsMessage.id, SmsMessage.to, SmsMessage.text, SmsMessage.attempts, SmsMessage.kind)
            .filter(SmsMessage.id.in_(got)).order_by(SmsMessage.id).all()) if got else []
    db.commit()
    return [tuple(r) for r in rows]


def deliver(db: Session, jobs: list[tuple[int, str, str, int, str]], prov) -> None:
    """Send claimed messages one by one; each result is committed right away (a crash mid-batch keeps the
    already-sent ones as «sent»). Verification codes are blanked in the log once the message is final."""
    for mid, to, text, attempts, kind in jobs:
        vals: dict
        try:
            pid = prov.send(to, text)
            vals = {"provider": prov.key, "provider_id": pid, "status": "sent", "sent_at": now(), "error": None}
        except SmsError as e:
            vals = {"error": str(e)[:300], "status": "failed" if attempts >= 3 else "queued"}
        except Exception as e:  # noqa: BLE001  network errors etc.
            vals = {"error": f"خطای ارتباط: {e}"[:300], "status": "failed" if attempts >= 3 else "queued"}
        if kind == "otp" and vals["status"] != "queued":
            vals["text"] = re.sub(r"\d{4,}", "•••••", text)
        db.query(SmsMessage).filter(SmsMessage.id == mid, SmsMessage.status == "sending").update(vals, synchronize_session=False)
        db.commit()


def recover_stale(db: Session) -> int:
    n = (db.query(SmsMessage).filter(SmsMessage.status == "sending", SmsMessage.sending_at < now() - STALE_SENDING)
         .update({"status": "failed", "error": INTERRUPTED}, synchronize_session=False))
    if n:
        db.commit()
    return n


def send_one(db: Session, m: SmsMessage, prov=None) -> None:
    """Send one message now (manual/test). Commits."""
    db.flush()
    prov = prov or provider(db)
    deliver(db, claim(db, [m.id]), prov)
    db.refresh(m)


def _quiet(db: Session) -> bool:
    s = settings_store.get_all(db)
    h = now().hour
    a, b = int(s.get("sms.quiet_start", 23)), int(s.get("sms.quiet_end", 8))
    return (h >= a or h < b) if a > b else (a <= h < b)


def process_queue(db: Session, limit: int = 40) -> int:
    """Background job: send queued messages (service messages any time, campaigns outside quiet hours)."""
    if not settings_store.get(db, "sms.enabled", True):
        return 0
    recover_stale(db)
    q = db.query(SmsMessage).filter(SmsMessage.status == "queued")
    if _quiet(db):
        q = q.filter(SmsMessage.kind != "campaign")
    rows = q.order_by(SmsMessage.id).limit(limit).all()
    if not rows:
        return 0
    try:
        prov = provider(db)
    except SmsError as e:
        for m in rows:
            m.error = str(e)
        return 0
    jobs = claim(db, [m.id for m in rows])
    deliver(db, jobs, prov)
    return len(jobs)


def reservation_reminders(db: Session) -> int:
    """Background job: remind guests N minutes before their reservation (once)."""
    try:
        from app.modules.reservations.models import Reservation
    except ImportError:
        return 0
    s = settings_store.get_all(db)
    if not s.get("sms.enabled") or not s.get("sms.ev.reservation_reminder"):
        return 0
    t = now()
    horizon = t + timedelta(minutes=int(s.get("sms.reminder_minutes") or 120))
    rows = db.query(Reservation).filter(Reservation.status.in_(["booked", "confirmed"]), Reservation.start_at > t,
                                        Reservation.start_at <= horizon, Reservation.phone.isnot(None)).all()
    n = 0
    for r in rows:
        if r.created_at and (r.start_at - r.created_at) < timedelta(minutes=45):
            continue            # booked just now — the confirmation SMS is enough
        if notify(db, "reservation_reminder", r.phone, ref=f"resv-remind:{r.id}", name=r.customer_name, time=fa_digits(f"{r.start_at:%H:%M}"), guests=fa_digits(r.guests)):
            n += 1
    return n


def stats(db: Session) -> dict:
    start = now().replace(hour=0, minute=0, second=0, microsecond=0)
    by = dict(db.query(SmsMessage.status, func.count()).filter(SmsMessage.created_at >= start).group_by(SmsMessage.status).all())
    month = now() - timedelta(days=30)
    parts_month = db.query(func.coalesce(func.sum(SmsMessage.parts), 0)).filter(SmsMessage.status == "sent", SmsMessage.created_at >= month).scalar()
    return {"queued": db.query(SmsMessage).filter(SmsMessage.status == "queued").count(), "sent_today": by.get("sent", 0),
            "failed_today": by.get("failed", 0), "parts_30d": int(parts_month or 0),
            "last_error": (db.query(SmsMessage.error).filter(SmsMessage.error.isnot(None)).order_by(SmsMessage.id.desc()).first() or [None])[0]}


# ------------------------------------------------------------------ event handlers (registered in setup)
def _public_base(db: Session) -> str:
    url = (settings_store.get(db, "online.public_url", "") or "").rstrip("/")
    if url:
        return url
    try:
        from app.modules.system.router import lan_addresses
        from app.core.config import get_settings
        ips = lan_addresses()
        return f"http://{ips[0]}:{get_settings().port}" if ips else ""
    except Exception:  # noqa: BLE001
        return ""


def on_reservation(db, reservation, **_):
    r = reservation
    notify(db, "reservation_created", r.phone, ref=f"resv-new:{r.id}", name=r.customer_name, date=jalali_str(r.start_at.date(), long=True),
           time=fa_digits(f"{r.start_at:%H:%M}"), guests=fa_digits(r.guests))


def on_online_accepted(db, request, order, **_):
    if request.mode == "table":
        return
    notify(db, "online_accepted", request.phone, ref=f"online-ok:{request.id}", name=request.customer_name or "", number=fa_digits(order.number),
           eta=fa_digits(request.eta_minutes or "—"), link=f"{_public_base(db)}/order/track/{request.token}")


def on_kitchen_ready(db, order, **_):
    if order.type != "takeaway" or not order.customer_phone:
        return
    lines = [ln for ln in order.active_lines if ln.station_id]
    if lines and all(ln.status in ("ready", "served") for ln in lines):
        notify(db, "order_ready", order.customer_phone, ref=f"ready:{order.id}", name=order.customer_name or "", number=fa_digits(order.number))


def on_delivery(db, order, delivery, status, **_):
    if status != "out" or not order.customer_phone:
        return
    amount = order.remaining if delivery.collect else 0
    notify(db, "delivery_out", order.customer_phone, ref=f"out:{order.id}", name=order.customer_name or "", number=fa_digits(order.number),
           courier=delivery.courier.name if delivery.courier else "", amount_line=f"مبلغ قابل پرداخت: {fa_money(amount)} تومان" if amount else "هزینه سفارش پرداخت شده است.")


def on_topup(db, customer, amount, balance, **_):
    notify(db, "wallet_topup", customer.phone, name=customer.name, amount=fa_money(amount), balance=fa_money(balance))
