from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import normalize_phone, now
from app.modules.customers.models import Customer

from . import service as S
from .models import SmsCampaign, SmsMessage, SmsOptOut
from .providers import PROVIDERS, SmsError, parts

router = APIRouter()
perm = require("sms.manage")


class TestIn(BaseModel):
    to: str
    text: str = Field("پیام آزمایشی از نرم‌افزار کافه ✅", max_length=500)


class ConfigIn(BaseModel):
    enabled: bool
    provider: str
    config: dict[str, dict[str, str]] = {}
    optout_footer: str = ""
    reminder_minutes: int = Field(120, ge=15, le=1440)
    quiet_start: int = Field(23, ge=0, le=23)
    quiet_end: int = Field(8, ge=0, le=23)


class TemplatesIn(BaseModel):
    items: dict[str, dict[str, Any]]           # key -> {enabled, text}


class Segment(BaseModel):
    type: str = Field("all", pattern="^(all|tier|inactive|recent|top|phones)$")
    tier: str | None = None
    days: int = Field(30, ge=1, le=3650)
    top: int = Field(50, ge=1, le=10000)
    phones: list[str] = []


class CampaignIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    text: str = Field(min_length=2, max_length=600)
    segment: Segment


class PreviewIn(BaseModel):
    segment: Segment
    text: str = ""


class SendIn(BaseModel):
    phones: list[str] = Field(min_length=1, max_length=50)
    text: str = Field(min_length=2, max_length=600)


class OptIn(BaseModel):
    phone: str
    note: str | None = None


def mout(m: SmsMessage) -> dict:
    return {"id": m.id, "to": m.to, "text": m.text, "kind": m.kind, "status": m.status, "provider": m.provider, "provider_id": m.provider_id,
            "error": m.error, "attempts": m.attempts, "parts": m.parts, "created_at": m.created_at, "sent_at": m.sent_at, "campaign_id": m.campaign_id}


def recipients(db: Session, seg: Segment) -> list[tuple[str, str]]:
    opted = {p for (p,) in db.query(SmsOptOut.phone).all()}
    if seg.type == "phones":
        return [(p, "") for p in dict.fromkeys(filter(None, (S.valid_mobile(x) for x in seg.phones))) if p not in opted]
    q = db.query(Customer)
    t = now()
    if seg.type == "inactive":
        q = q.filter(or_(Customer.last_visit.is_(None), Customer.last_visit < t - timedelta(days=seg.days)))
    elif seg.type == "recent":
        q = q.filter(Customer.last_visit >= t - timedelta(days=seg.days))
    elif seg.type == "top":
        q = q.order_by(Customer.total_spent.desc()).limit(seg.top)
    rows = q.all()
    if seg.type == "tier":
        try:
            from app.modules.loyalty.service import tier_of, tiers
            tl = tiers(db)
            rows = [c for c in rows if (tier_of(db, c.total_spent, tl) or {}).get("key") == seg.tier]
        except ImportError:
            rows = []
    out, seen = [], set()
    for c in rows:
        p = S.valid_mobile(c.phone)
        if p and p not in seen and p not in opted:
            seen.add(p)
            out.append((p, c.name))
    return out


MASK = "••••••••"
# Fields of `sms.config` that are credentials (never leave the server in clear text).
SECRET_FIELDS = {"api_key", "token", "password", "secret", "key"}


def _mask_config(cfg: dict) -> dict:
    """Return the config with every credential replaced by a mask (keeping only the last 4 chars).

    The generic /api/system/settings already strips `sms.config`; this endpoint used to hand the raw
    API key to the browser, where it lands in devtools/network history and any screen recording.
    """
    out = {}
    for prov, conf in (cfg or {}).items():
        if not isinstance(conf, dict):
            out[prov] = MASK if conf else ""
            continue
        out[prov] = {k: (f"{MASK}{str(v)[-4:]}" if k in SECRET_FIELDS and v else v) for k, v in conf.items()}
    return out


def _merge_config(old: dict, new: dict) -> dict:
    """A masked value coming back from the form means «unchanged» — keep the stored credential."""
    out = {}
    for prov, conf in (new or {}).items():
        prev = (old or {}).get(prov) or {}
        if not isinstance(conf, dict):
            out[prov] = conf
            continue
        merged = dict(conf)
        for k, v in conf.items():
            if k in SECRET_FIELDS and isinstance(v, str) and v.startswith(MASK):
                merged[k] = prev.get(k, "")       # untouched field: keep the real secret
        out[prov] = merged
    return out


def _campaign_text(db: Session, text: str) -> str:
    footer = (settings_store.get(db, "sms.optout_footer", "") or "").strip()
    return f"{text.strip()}\n{footer}" if footer and footer not in text else text.strip()


# ------------------------------------------------------------------ status / config
@router.get("/status")
def status(db: Session = Depends(get_db), _: User = Depends(perm)):
    s = settings_store.get_all(db)
    credit, credit_error = None, None
    try:
        credit = S.provider(db).credit()
    except Exception as e:  # noqa: BLE001
        credit_error = str(e)[:200]
    return {
        "enabled": s.get("sms.enabled"), "provider": s.get("sms.provider"),
        "config": _mask_config(s.get("sms.config") or {}),          # credentials never leave the server
        "optout_footer": s.get("sms.optout_footer"), "reminder_minutes": s.get("sms.reminder_minutes"),
        "quiet_start": s.get("sms.quiet_start"), "quiet_end": s.get("sms.quiet_end"),
        "providers": [{"key": p.key, "title": p.title, "fields": [{"key": f[0], "label": f[1], "required": f[2]} for f in p.fields]} for p in PROVIDERS.values()],
        "credit": credit, "credit_error": credit_error, **S.stats(db),
    }


@router.put("/config")
def save_config(data: ConfigIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    if data.provider not in PROVIDERS:
        raise AppError("سرویس پیامک نامعتبر است")
    old = settings_store.get(db, "sms.config") or {}
    settings_store.set_many(db, {"sms.enabled": data.enabled, "sms.provider": data.provider,
                                 "sms.config": _merge_config(old, data.config), "sms.optout_footer": data.optout_footer,
                                 "sms.reminder_minutes": data.reminder_minutes, "sms.quiet_start": data.quiet_start, "sms.quiet_end": data.quiet_end})
    log_action(db, user, "sms.config", f"تنظیمات پیامک: {PROVIDERS[data.provider].title}")
    db.commit()
    return {"ok": True}


@router.post("/test")
def test(data: TestIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    m = S.enqueue(db, data.to, data.text, "test", user_id=user.id)
    if not m:
        raise AppError("شماره موبایل معتبر نیست", code="phone_invalid")
    db.flush()
    S.send_one(db, m)
    db.commit()
    if m.status != "sent":
        raise AppError(m.error or "ارسال ناموفق بود", code="send_failed")
    return mout(m)


@router.get("/templates")
def templates(db: Session = Depends(get_db), _: User = Depends(perm)):
    s = settings_store.get_all(db)
    return [{"key": k, "title": v[0], "enabled": bool(s.get(f"sms.ev.{k}")), "text": s.get(f"sms.tpl.{k}") or v[1], "default": v[1], "placeholders": v[2]}
            for k, v in S.EVENTS.items()]


@router.put("/templates")
def save_templates(data: TemplatesIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    vals = {}
    for k, v in data.items.items():
        if k not in S.EVENTS:
            continue
        vals[f"sms.ev.{k}"] = bool(v.get("enabled"))
        if (v.get("text") or "").strip():
            vals[f"sms.tpl.{k}"] = v["text"].strip()[:500]
    settings_store.set_many(db, vals)
    log_action(db, user, "sms.templates", "ویرایش متن پیامک‌های خودکار")
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ messages
@router.get("/messages")
def messages(status: str | None = None, kind: str | None = None, q: str | None = None, page: int = 1, size: int = 20,
             db: Session = Depends(get_db), _: User = Depends(perm)):
    qq = db.query(SmsMessage)
    if status:
        qq = qq.filter(SmsMessage.status == status)
    if kind:
        qq = qq.filter(SmsMessage.kind == kind)
    if q:
        qq = qq.filter(or_(SmsMessage.to.contains(normalize_phone(q) or q), SmsMessage.text.contains(q)))
    total = qq.count()
    rows = qq.order_by(SmsMessage.id.desc()).offset((max(page, 1) - 1) * size).limit(min(size, 100)).all()
    return {"total": total, "items": [mout(m) for m in rows]}


@router.post("/messages/{mid}/retry")
def retry(mid: int, db: Session = Depends(get_db), _: User = Depends(perm)):
    m = get_or_404(db, SmsMessage, mid, "پیامک")
    if m.status == "sent":
        raise AppError("این پیامک ارسال شده است")
    m.status, m.attempts, m.error = "queued", 0, None
    db.commit()
    return {"ok": True}


@router.post("/send")
def send(data: SendIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    n = sum(1 for p in data.phones if S.enqueue(db, p, data.text, "manual", user_id=user.id))
    if not n:
        raise AppError("شماره معتبری وارد نشده است", code="phone_invalid")
    log_action(db, user, "sms.send", f"ارسال پیامک دستی به {n} شماره")
    db.commit()
    return {"queued": n}


# ------------------------------------------------------------------ campaigns
@router.post("/campaigns/preview")
def preview(data: PreviewIn, db: Session = Depends(get_db), _: User = Depends(perm)):
    rec = recipients(db, data.segment)
    text = _campaign_text(db, data.text) if data.text.strip() else ""
    p = parts(text) if text else 1
    return {"count": len(rec), "sample": [{"phone": x[0], "name": x[1]} for x in rec[:8]], "parts": p, "total_parts": p * len(rec), "text": text}


@router.get("/campaigns")
def campaigns(db: Session = Depends(get_db), _: User = Depends(perm)):
    rows = db.query(SmsCampaign).order_by(SmsCampaign.id.desc()).limit(50).all()
    out = []
    for c in rows:
        st = dict(db.query(SmsMessage.status, func.count()).filter(SmsMessage.campaign_id == c.id).group_by(SmsMessage.status).all())
        out.append({"id": c.id, "title": c.title, "text": c.text, "segment": c.segment, "total": c.total, "created_at": c.created_at,
                    "sent": st.get("sent", 0), "failed": st.get("failed", 0), "queued": st.get("queued", 0)})
    return out


@router.post("/campaigns", status_code=201)
def create_campaign(data: CampaignIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    rec = recipients(db, data.segment)
    if not rec:
        raise AppError("هیچ گیرنده‌ای با این شرایط پیدا نشد", code="no_recipients")
    text = _campaign_text(db, data.text)
    c = SmsCampaign(title=data.title, text=text, segment=data.segment.model_dump(), total=len(rec), created_by=user.id)
    db.add(c)
    db.flush()
    for phone, name in rec:
        S.enqueue(db, phone, S.render(text, name=name or "مشتری", business=settings_store.get(db, "business.name", "")), "campaign", campaign_id=c.id, user_id=user.id)
    log_action(db, user, "sms.campaign", f"کمپین پیامکی «{c.title}» برای {len(rec)} نفر", entity="sms_campaign", entity_id=c.id)
    db.commit()
    return {"id": c.id, "total": c.total}


# ------------------------------------------------------------------ opt-out
@router.get("/optout")
def optout_list(db: Session = Depends(get_db), _: User = Depends(perm)):
    return [{"id": o.id, "phone": o.phone, "note": o.note, "created_at": o.created_at} for o in db.query(SmsOptOut).order_by(SmsOptOut.id.desc())]


@router.post("/optout", status_code=201)
def optout_add(data: OptIn, db: Session = Depends(get_db), _: User = Depends(perm)):
    p = S.valid_mobile(data.phone)
    if not p:
        raise AppError("شماره موبایل معتبر نیست", code="phone_invalid")
    if not db.query(SmsOptOut).filter(SmsOptOut.phone == p).first():
        db.add(SmsOptOut(phone=p, note=data.note))
        db.query(SmsMessage).filter(SmsMessage.to == p, SmsMessage.status == "queued", SmsMessage.kind == "campaign").delete()
        db.commit()
    return {"ok": True}


@router.delete("/optout/{oid}")
def optout_del(oid: int, db: Session = Depends(get_db), _: User = Depends(perm)):
    db.delete(get_or_404(db, SmsOptOut, oid, "شماره"))
    db.commit()
    return {"ok": True}


_ = SmsError  # re-exported for other modules
