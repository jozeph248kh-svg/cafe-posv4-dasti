from app.core.modules import Module

from .printing import router as printing_router
from .router import router

module = Module(
    name="system",
    title="سیستم و تنظیمات",
    description="تنظیمات کسب‌وکار، گزارش رویدادها، پشتیبان‌گیری و اطلاعات سیستم",
    core=True,
    depends=["staff"],
    routers=[router, printing_router],
    permissions={
        "settings.manage": "تغییر تنظیمات سیستم",
        "audit.view": "مشاهده گزارش رویدادها (لاگ)",
        "dashboard.view": "مشاهده داشبورد مدیریتی",
    },
)
