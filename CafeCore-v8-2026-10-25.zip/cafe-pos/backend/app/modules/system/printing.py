"""Network thermal printers (ESC/POS over TCP 9100): list, test page, print a browser-rendered raster.

Printers are kept in the `print.printers` setting and can only be changed here (validated). Printing endpoints don't
write to the DB and are exempt from the global write lock, so a slow/offline printer never blocks other devices.
"""
import base64
import binascii
import ipaddress
import re

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.orm import Session

from app.core import escpos, settings_store
from app.core.audit import log_action
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User

settings_store.register_defaults({"print.printers": []}, protected={"print.printers"})
router = APIRouter()
HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,62})$")


class PrinterIn(BaseModel):
    id: int = Field(ge=1, le=999)
    name: str = Field(min_length=1, max_length=40)
    host: str = Field(min_length=1, max_length=63)
    port: int = Field(9100, ge=1, le=65535)
    width: int = 576
    receipt: bool = False                         # prints customer bills/receipts
    register_id: int | None = None                # receipt printer of this register only (None = every register)
    drawer: bool = False                          # cash drawer connected to this printer (kick on cash payments)
    station_ids: list[int] = Field(default_factory=list, max_length=50)   # kitchen stations whose tickets go here

    @field_validator("host")
    @classmethod
    def _host(cls, v: str) -> str:
        v = v.strip()
        try:
            ipaddress.ip_address(v)
        except ValueError:
            if not HOST_RE.match(v):
                raise ValueError("آدرس IP یا نام دستگاه معتبر نیست")
        return v

    @field_validator("width")
    @classmethod
    def _width(cls, v: int) -> int:
        if v not in escpos.WIDTHS:
            raise ValueError("عرض چاپ باید ۳۸۴ (۵۸ میلی‌متر)، ۵۱۲ یا ۵۷۶ (۸۰ میلی‌متر) نقطه باشد")
        return v


class PrintersIn(BaseModel):
    printers: list[PrinterIn] = Field(max_length=20)


class RasterIn(BaseModel):
    printer_id: int
    width: int
    height: int = Field(ge=1, le=escpos.MAX_HEIGHT)
    data: str = Field(max_length=800_000)         # base64 of packed 1-bit rows
    cut: bool = True
    drawer: bool = False
    copies: int = Field(1, ge=1, le=5)


def printers(db: Session) -> list[dict]:
    return list(settings_store.get(db, "print.printers", []) or [])


def _printer(db: Session, pid: int) -> dict:
    p = next((x for x in printers(db) if x.get("id") == pid), None)
    if not p:
        raise AppError("چاپگر یافت نشد", 404, "not_found")
    return p


def _send(p: dict, payload: bytes) -> None:
    try:
        escpos.send(p["host"], int(p.get("port") or 9100), payload)
    except escpos.PrinterError:
        raise AppError(f"چاپگر «{p['name']}» ({p['host']}) در دسترس نیست؛ روشن بودن، کاغذ و اتصال شبکه را بررسی کنید",
                       502, "printer_unreachable", printer=p["name"])


@router.get("/printers")
def list_printers(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return printers(db)


@router.put("/printers")
def save_printers(data: PrintersIn, db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    ids = [p.id for p in data.printers]
    if len(ids) != len(set(ids)):
        raise AppError("شناسه چاپگرها تکراری است", code="duplicate")
    if len({p.name for p in data.printers}) != len(ids):
        raise AppError("نام چاپگرها تکراری است", code="duplicate")
    value = [p.model_dump() for p in data.printers]
    settings_store.set_many(db, {"print.printers": value})
    log_action(db, user, "printers.update", f"تنظیم چاپگرها ({len(value)} دستگاه)", details={"printers": value})
    db.commit()
    return value


@router.post("/printers/{pid}/test")
def test_printer(pid: int, db: Session = Depends(get_db), _: User = Depends(require("settings.manage"))):
    p = _printer(db, pid)
    db.rollback()                                  # don't keep a transaction open during the network call
    _send(p, escpos.text_job(["Cafe POS", "printer test OK", f"{p['host']}:{p.get('port') or 9100}", "-" * 24]))
    return {"ok": True}


@router.post("/print")
def print_raster(data: RasterIn, db: Session = Depends(get_db), _: User = Depends(current_user)):
    p = _printer(db, data.printer_id)
    db.rollback()
    if data.width != p.get("width", 576):
        raise AppError("عرض تصویر با عرض چاپگر یکسان نیست", 422, "bad_raster")
    try:
        raw = base64.b64decode(data.data, validate=True)
        payload = escpos.raster_job(data.width, data.height, raw, cut=data.cut, drawer=data.drawer and bool(p.get("drawer")),
                                    copies=data.copies)
    except (ValueError, binascii.Error):
        raise AppError("تصویر چاپ معتبر نیست", 422, "bad_raster")
    _send(p, payload)
    return {"ok": True, "bytes": len(payload)}
