import socket
import re
import uuid
from datetime import datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, File, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.backup import NAME_RE, BackupError, create_backup, drill_and_record, record_run, status as backup_status
from app.core.config import get_settings
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError, not_found
from app.core.models import AuditLog, User
from app.core.modules import registry
from app.core.realtime import publish_after_commit

router = APIRouter()

# ---------------------------------------------------------------- appearance: skins (Round 9)
# Built-in skins live in the frontend (core/skins.js); the server only stores which one is active plus the business's own
# custom skins, and validates them strictly (hex colours, clamped sizes) so a bad import can't break any screen.
BUILTIN_SKINS = ("classic", "latte", "jade", "ocean", "rose", "graphite")
THEME_DEFAULT = {"skin": "classic", "custom": []}
settings_store.register_defaults({"ui.theme": THEME_DEFAULT}, protected={"ui."})
HEX = r"^#[0-9a-fA-F]{6}$"
SKIN_ID = r"^[a-z0-9_-]{2,40}$"
Hex = Annotated[str, Field(pattern=HEX)]


class SkinColors(BaseModel):
    model_config = ConfigDict(extra="forbid")
    primary: Hex
    bg: Hex
    card: Hex
    text: Hex
    muted: Hex
    border: Hex
    sider: Hex
    success: Hex
    warning: Hex
    error: Hex
    info: Hex


class SkinIn(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(pattern=SKIN_ID)
    name: str = Field(min_length=1, max_length=40)
    base: str | None = Field(None, max_length=40)
    note: str | None = Field(None, max_length=120)
    light: SkinColors
    dark: SkinColors
    palette: list[Hex] = Field(min_length=3, max_length=9)
    radius: int = Field(10, ge=0, le=24)
    font_scale: float = Field(1.0, ge=0.85, le=1.25)
    density: Literal["comfortable", "compact"] = "comfortable"
    font: Literal["vazirmatn", "tahoma", "system"] = "vazirmatn"


class ThemeIn(BaseModel):
    skin: str = Field(pattern=SKIN_ID)
    custom: list[SkinIn] = Field(default_factory=list, max_length=20)


def _theme(db: Session) -> dict:
    t = settings_store.get(db, "ui.theme")
    if not isinstance(t, dict) or not isinstance(t.get("skin"), str):
        return dict(THEME_DEFAULT)
    return {"skin": t["skin"], "custom": t.get("custom") if isinstance(t.get("custom"), list) else []}


@router.get("/theme")
def get_theme(db: Session = Depends(get_db)):
    """No authentication: the login screen and the guest pages are themed too. Contains colours only."""
    return _theme(db)


@router.put("/theme")
def put_theme(body: ThemeIn, db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    ids = [c.id for c in body.custom]
    if len(set(ids)) != len(ids):
        raise AppError("شناسهٔ تم‌های سفارشی تکراری است", code="invalid_theme")
    if set(ids) & set(BUILTIN_SKINS):
        raise AppError("شناسهٔ تم سفارشی نباید با تم‌های آماده یکی باشد", code="invalid_theme")
    if body.skin not in BUILTIN_SKINS and body.skin not in ids:
        raise AppError("تم انتخاب‌شده وجود ندارد", code="invalid_theme")
    before = _theme(db)
    value = body.model_dump(exclude_none=True)
    settings_store.set_many(db, {"ui.theme": value})
    log_action(db, user, "theme.update", "تغییر ظاهر و تم برنامه",
               details={"from": before["skin"], "to": body.skin, "custom": [c.name for c in body.custom]})
    publish_after_commit(db, "theme.changed", {"skin": body.skin})
    db.commit()
    return value


PUBLIC_KEYS = ("business.", "currency.", "receipt.", "tax.", "service.", "rounding.", "shift.", "day.")


def lan_addresses() -> list[str]:
    ips: set[str] = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


@router.get("/info")
def info():
    s = get_settings()
    return {
        "app": s.app_name, "version": s.version,
        "modules": [{"name": m.name, "title": m.title, "version": m.version, "core": m.core, "description": m.description,
                     "depends": list(m.depends or [])}
                    for m in registry.modules.values()],
        "lan_urls": [f"{'https' if s.https else 'http'}://{ip}:{s.port}" for ip in lan_addresses()],
        "https": s.https,
    }


@router.get("/settings")
def get_settings_(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return settings_store.public_view(settings_store.get_all(db))


@router.put("/settings")
def update_settings(values: dict[str, Any], db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    current = settings_store.get_all(db)
    clean = {k: settings_store.validate(k, v) for k, v in values.items()
             if k in settings_store.DEFAULTS and not settings_store.is_protected(k)}
    changed = {k: v for k, v in clean.items() if current.get(k) != v}
    settings_store.set_many(db, changed)
    if changed:
        log_action(db, user, "settings.update", "به‌روزرسانی تنظیمات",
                   details={"changes": {k: {"from": current.get(k), "to": v} for k, v in changed.items()}})
    db.commit()
    return settings_store.public_view(settings_store.get_all(db))


@router.get("/audit")
def audit(
    q: str | None = None, action: str | None = None, limit: int = Query(200, le=1000),
    db: Session = Depends(get_db), _: User = Depends(require("audit.view")),
):
    query = db.query(AuditLog).order_by(AuditLog.id.desc())
    if action:
        query = query.filter(AuditLog.action.startswith(action, autoescape=True))
    if q:
        query = query.filter(AuditLog.summary.contains(q) | AuditLog.user_name.contains(q))
    return [
        {"id": a.id, "created_at": a.created_at, "user_name": a.user_name, "approver_name": a.approver_name,
         "action": a.action, "summary": a.summary, "details": a.details}
        for a in query.limit(limit).all()
    ]


# ---------------------------------------------------------------- uploads
ALLOWED = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}


MAGIC = {".jpg": (b"\xff\xd8\xff",), ".png": (b"\x89PNG\r\n\x1a\n",), ".webp": (b"RIFF",)}


@router.post("/upload")
async def upload(file: UploadFile = File(...), user: User = Depends(current_user)):
    if not (user.can("menu.manage") or user.can("settings.manage")):
        raise AppError("شما مجوز بارگذاری تصویر را ندارید", 403, "forbidden")
    ext = ALLOWED.get(file.content_type or "")
    if not ext:
        raise AppError("فقط تصاویر JPG، PNG یا WEBP مجاز است")
    data = await file.read(4 * 1024 * 1024 + 1)
    if len(data) > 4 * 1024 * 1024:
        raise AppError("حجم تصویر حداکثر ۴ مگابایت است")
    if not data.startswith(MAGIC[ext]) or (ext == ".webp" and data[8:12] != b"WEBP"):
        raise AppError("محتوای فایل با نوع تصویر مطابقت ندارد")
    name = f"{uuid.uuid4().hex}{ext}"
    (get_settings().uploads_dir / name).write_bytes(data)
    return {"url": f"/uploads/{name}"}


# ---------------------------------------------------------------- backups
@router.get("/backups")
def list_backups(_: User = Depends(require("settings.manage"))):
    from app.core.backup import parse_name
    s = get_settings()
    out = []
    for f in s.backups_dir.glob("cafe-*.db"):
        info = parse_name(f)
        out.append({"name": f.name, "size": f.stat().st_size, "kind": info[1] if info else "other",
                    "created_at": info[0] if info else datetime.fromtimestamp(f.stat().st_mtime)})
    return sorted(out, key=lambda x: x["created_at"], reverse=True)


@router.get("/backups/policy")
def backup_policy(_: User = Depends(require("settings.manage"))):
    s = get_settings()
    from app.core.db import engine
    return {"interval_minutes": s.backup_interval_minutes, "keep_days": s.backup_keep, "enabled": s.background_jobs,
            "database": engine.dialect.name}


@router.post("/backups")
def make_backup(db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    """Take a backup now (SQLite online copy, or pg_dump on PostgreSQL) and record the outcome."""
    started = datetime.now()
    try:
        path = create_backup("manual")
    except BackupError as e:
        record_run(db, "backup", "failed", detail=str(e))
        raise AppError(str(e), code="backup_failed") from e
    if not path:
        msg = "دیتابیس پیدا نشد؛ پشتیبان‌گیری انجام نشد"
        record_run(db, "backup", "failed", detail=msg)
        raise AppError(msg, code="backup_unsupported")
    took = int((datetime.now() - started).total_seconds() * 1000)
    record_run(db, "backup", "ok", file=path.name, size=path.stat().st_size, duration_ms=took)
    log_action(db, user, "backup.create", f"ایجاد نسخه پشتیبان {path.name}")
    db.commit()
    return {"name": path.name, "size": path.stat().st_size, "duration_ms": took}


@router.get("/backups/status")
def backup_state(db: Session = Depends(get_db), _: User = Depends(require("settings.manage"))):
    """Status card: newest backup + age (stale after 24 h), last restore drill, recent runs and errors."""
    return backup_status(db)


@router.post("/backups/drill")
def run_drill(db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    """Restore the newest backup into an isolated scratch database and compare the key figures with the manifest.

    This never touches the live database — it is a *test* of the backup, which is the only proof that the data
    could really come back after a crash.
    """
    result = drill_and_record(db)
    log_action(db, user, "backup.drill",
               f"آزمون بازیابی {'موفق' if result.get('ok') else 'ناموفق'}: {result.get('backup', '-')}")
    db.commit()
    if not result.get("ok"):
        raise AppError(result.get("error") or "آزمون بازیابی ناموفق بود", code="backup_drill_failed",
                       result=result)
    return result


@router.get("/backups/{name}")
def download_backup(name: str, _: User = Depends(require("settings.manage"))):
    path = get_settings().backups_dir / name
    if not re.match(NAME_RE, name) or not path.is_file():
        raise not_found("فایل پشتیبان")
    return FileResponse(path, filename=name, media_type="application/octet-stream")
