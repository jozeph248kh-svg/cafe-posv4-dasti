import random

from sqlalchemy.orm import Session

from app.core.models import User
from app.core.permissions import grant_once
from app.modules.customers.models import Customer

from . import service as S
from .models import CustomerAccount


def seed(db: Session) -> None:
    grant_once(db, "loyalty", {"manager": ["loyalty.manage", "loyalty.adjust"], "cashier": ["loyalty.manage"]})


EXTRA = ["نیما صالحی", "الهام کاظمی", "پویا رستمی", "شیدا نوروزی", "بهراد جعفری", "هستی مرادی", "آرمان شریفی", "یاسمن قاسمی",
         "سینا امیری", "مهتاب حیدری", "کیان طاهری", "رها فتحی", "امید کرمانی", "نازنین اکبری", "فرزاد بهرامی", "دنیا سلیمانی",
         "حامد یزدانی", "سپیده زمانی", "میلاد عباسی", "پگاه نجفی", "بردیا صادقی", "آیدا منصوری"]


def demo(db: Session) -> None:
    if db.query(CustomerAccount).count():
        return
    from datetime import timedelta

    from app.core.utils import now
    rng = random.Random(11)
    for k, name in enumerate(EXTRA):
        phone = f"0912{3000000 + k * 7919:07d}"
        if not db.query(Customer).filter(Customer.phone == phone).first():
            visits = rng.choice([1, 2, 3, 5, 8, 12, 18, 26, 40])
            db.add(Customer(name=name, phone=phone, visits=visits, total_spent=int(visits * rng.uniform(0.6, 2.4) * 1e6 // 1000 * 1000),
                            last_visit=now() - timedelta(days=rng.randint(0, 45), hours=rng.randint(0, 10))))
    db.flush()
    admin = db.query(User).filter(User.username == "sara").first() or db.query(User).first()
    customers = db.query(Customer).order_by(Customer.total_spent.desc()).all()
    ts = S.tiers(db)
    for i, c in enumerate(customers):
        acc = S.account(db, c)
        t = S.tier_of(db, c.total_spent, ts)
        # historic cashback on past spending
        cb = int(c.total_spent * (t["pct"] if t else 3) / 100 * 0.25 // 1000 * 1000)
        if cb:
            acc.cashback_total = cb
            S.wallet_move(db, acc, "cashback", cb, None, note="کش‌بک خریدهای قبلی")
        if i % 3 == 0:
            S.wallet_move(db, acc, "topup", rng.choice([500_000, 1_000_000, 2_000_000]), admin, method=rng.choice(["card", "cash"]), note="شارژ کیف پول")
        if i % 4 == 1 and acc.wallet > 300_000:
            S.wallet_move(db, acc, "pay", -rng.choice([180_000, 260_000, 300_000]), admin, note="پرداخت سفارش")
        if i % 5 == 2:
            S.credit_move(db, acc, "sale", rng.choice([450_000, 820_000, 1_250_000]), admin, note="خرید نسیه")
            if i % 10 == 2:
                S.credit_move(db, acc, "settle", -300_000, admin, method="card", note="تسویه بخشی از بدهی")
