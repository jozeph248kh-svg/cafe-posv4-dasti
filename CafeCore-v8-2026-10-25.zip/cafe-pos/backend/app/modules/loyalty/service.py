from sqlalchemy.orm import Session

from app.core import events, settings_store
from app.core.errors import AppError
from app.core.realtime import publish_after_commit
from app.core.utils import normalize_phone
from app.modules.customers.models import Customer

from .models import CreditTxn, CustomerAccount, WalletTxn

DEFAULTS = {
    "loyalty.enabled": True,
    "loyalty.cashback_pct": 3,           # base cashback % (used when no tiers)
    "loyalty.tiers": [
        {"key": "bronze", "name": "برنزی", "min": 0, "pct": 3, "color": "#b45309"},
        {"key": "silver", "name": "نقره‌ای", "min": 15_000_000, "pct": 5, "color": "#64748b"},
        {"key": "gold", "name": "طلایی", "min": 50_000_000, "pct": 7, "color": "#ca8a04"},
        {"key": "vip", "name": "VIP", "min": 120_000_000, "pct": 10, "color": "#7c3aed"},
    ],
    "loyalty.cashback_min_order": 200_000,
    "loyalty.topup_bonus_pct": 0,        # e.g. 10 → charging 1,000,000 gives 100,000 extra
    "loyalty.credit_limit": 5_000_000,   # default credit (نسیه) ceiling per customer; 0 = no limit
}
METHOD_LABEL = {"cash": "نقد", "card": "کارتخوان", "transfer": "انتقال بانکی", "online": "آنلاین", "wallet": "کیف پول"}


def tiers(db: Session) -> list[dict]:
    return sorted(settings_store.get(db, "loyalty.tiers") or [], key=lambda t: t.get("min", 0))


def tier_of(db: Session, total_spent: int, _tiers: list[dict] | None = None) -> dict | None:
    cur = None
    for t in _tiers if _tiers is not None else tiers(db):
        if total_spent >= t.get("min", 0):
            cur = t
    return cur


def next_tier(db: Session, total_spent: int) -> dict | None:
    return next((t for t in tiers(db) if t.get("min", 0) > total_spent), None)


def account(db: Session, customer: Customer, create: bool = True) -> CustomerAccount | None:
    acc = db.get(CustomerAccount, customer.id)
    if not acc and create:
        acc = CustomerAccount(customer_id=customer.id, wallet=0, debt=0, cashback_total=0)
        acc.customer = customer
        db.add(acc)
        db.flush()
    return acc


def customer_by_phone(db: Session, phone: str | None) -> Customer | None:
    phone = normalize_phone(phone)
    if not phone:
        return None
    db.flush()   # autoflush is off: see customers created earlier in this transaction
    return db.query(Customer).filter(Customer.phone == phone).first()


def ensure_customer(db: Session, order) -> Customer:
    phone = normalize_phone(order.customer_phone)
    if not phone:
        raise AppError("برای استفاده از کیف پول یا نسیه، شماره موبایل مشتری را روی سفارش ثبت کنید", code="customer_required")
    c = customer_by_phone(db, phone)
    if not c:
        c = Customer(phone=phone, name=order.customer_name or "مشتری", address=order.customer_address, visits=0, total_spent=0)
        db.add(c)
        db.flush()
    return c


def wallet_move(db, acc: CustomerAccount, kind: str, amount: int, user=None, order=None, method=None, note=None) -> WalletTxn:
    if acc.wallet + amount < 0:
        raise AppError(f"موجودی کیف پول کافی نیست (موجودی: {acc.wallet:,} تومان)", code="wallet_insufficient")
    acc.wallet += amount
    t = WalletTxn(customer_id=acc.customer_id, kind=kind, amount=amount, balance=acc.wallet, method=method, note=note,
                  order_id=order.id if order else None, order_number=order.number if order else None, created_by=user.id if user else None)
    db.add(t)
    publish_after_commit(db, "customer.account", {"customer_id": acc.customer_id})
    return t


def credit_move(db, acc: CustomerAccount, kind: str, amount: int, user=None, order=None, method=None, note=None) -> CreditTxn:
    if acc.debt + amount < 0:
        raise AppError(f"مبلغ تسویه بیشتر از بدهی مشتری است (بدهی: {acc.debt:,} تومان)")
    acc.debt += amount
    t = CreditTxn(customer_id=acc.customer_id, kind=kind, amount=amount, balance=acc.debt, method=method, note=note,
                  order_id=order.id if order else None, order_number=order.number if order else None, created_by=user.id if user else None)
    db.add(t)
    publish_after_commit(db, "customer.account", {"customer_id": acc.customer_id})
    return t


def credit_limit(db, acc: CustomerAccount) -> int:
    return acc.credit_limit if acc.credit_limit is not None else int(settings_store.get(db, "loyalty.credit_limit", 0) or 0)


# ------------------------------------------------------------------ event handlers
def on_payment(db: Session, payment, order, user=None, **_):
    if payment.method not in ("wallet", "credit"):
        return
    if payment.method == "credit" and not normalize_phone(order.customer_phone):
        return          # name-only credit sale (legacy behaviour) — not tracked in the ledger
    c = ensure_customer(db, order)
    acc = account(db, c)
    amt = payment.amount
    if payment.method == "wallet":
        wallet_move(db, acc, "refund" if amt < 0 else "pay", -amt, user, order,
                    note=("برگشت به کیف پول — " if amt < 0 else "پرداخت سفارش ") + f"#{order.number}")
    else:
        if amt > 0:
            limit = credit_limit(db, acc)
            if acc.credit_limit == 0:
                raise AppError("فروش نسیه برای این مشتری مجاز نیست", code="credit_blocked")
            if limit and acc.debt + amt > limit:
                raise AppError(f"سقف نسیه مشتری {limit:,} تومان است؛ بدهی فعلی {acc.debt:,} تومان", code="credit_limit")
        credit_move(db, acc, "refund" if amt < 0 else "sale", amt, user, order, note=f"سفارش #{order.number}")
    if amt < 0 and order.status == "closed":
        _reverse_cashback(db, acc, order, -amt, user)


def on_payment_any_refund(db: Session, payment, order, user=None, **_):
    """Refunds through cash/card also claw back the proportional cashback."""
    if payment.amount >= 0 or payment.method in ("wallet", "credit") or order.status != "closed":
        return
    c = customer_by_phone(db, order.customer_phone)
    acc = c and account(db, c, create=False)
    if acc:
        _reverse_cashback(db, acc, order, -payment.amount, user)


def _reverse_cashback(db, acc, order, refund_amount, user):
    given = sum(t.amount for t in db.query(WalletTxn).filter(WalletTxn.order_id == order.id, WalletTxn.kind == "cashback"))
    if given <= 0 or not order.total:
        return
    back = min(round(given * refund_amount / order.total), acc.wallet)
    if back > 0:
        acc.cashback_total -= back
        wallet_move(db, acc, "cashback", -back, user, order, note=f"کسر کش‌بک بابت مرجوعی سفارش #{order.number}")


def on_closed(db: Session, order, user=None, **_):
    if not settings_store.get(db, "loyalty.enabled", True):
        return
    c = customer_by_phone(db, order.customer_phone)
    if not c:
        return
    base = sum(p.amount for p in order.payments if not p.is_refund and p.method not in ("wallet",))
    if base < int(settings_store.get(db, "loyalty.cashback_min_order", 0) or 0):
        return
    t = tier_of(db, c.total_spent - order.total)       # tier before this order (customers handler already added it)
    pct = t["pct"] if t else settings_store.get(db, "loyalty.cashback_pct", 0)
    amount = int(base * float(pct or 0) / 100 // 1000 * 1000)   # round down to 1,000 toman
    if amount <= 0:
        return
    acc = account(db, c)
    acc.cashback_total += amount
    wallet_move(db, acc, "cashback", amount, user, order, note=f"کش‌بک {pct}٪ سفارش #{order.number}" + (f" (سطح {t['name']})" if t else ""))


def topup(db, acc, amount: int, method: str, user, note=None):
    if method == "cash":
        events.emit("cash.movement", db=db, kind="in", amount=amount, reason=f"شارژ کیف پول — {acc.customer.name}", user=user)
    wallet_move(db, acc, "topup", amount, user, method=method, note=note or f"شارژ کیف پول ({METHOD_LABEL.get(method, method)})")
    bonus_pct = float(settings_store.get(db, "loyalty.topup_bonus_pct", 0) or 0)
    bonus = int(amount * bonus_pct / 100 // 1000 * 1000)
    if bonus > 0:
        wallet_move(db, acc, "bonus", bonus, user, note=f"هدیه شارژ {bonus_pct:g}٪")
    return bonus


def settle(db, acc, amount: int, method: str, user, note=None):
    if amount > acc.debt:
        raise AppError(f"مبلغ تسویه بیشتر از بدهی مشتری است (بدهی: {acc.debt:,} تومان)")
    if method == "wallet":
        wallet_move(db, acc, "settle", -amount, user, note="تسویه بدهی نسیه از کیف پول")
    elif method == "cash":
        events.emit("cash.movement", db=db, kind="in", amount=amount, reason=f"تسویه نسیه — {acc.customer.name}", user=user)
    credit_move(db, acc, "settle", -amount, user, method=method, note=note or f"تسویه ({METHOD_LABEL.get(method, method)})")
