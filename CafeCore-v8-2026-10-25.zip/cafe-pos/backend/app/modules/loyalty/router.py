from datetime import date

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.core import events
from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import day_bounds, normalize_phone
from app.modules.customers.models import Customer

from . import service as S
from .models import CreditTxn, CustomerAccount, WalletTxn

router = APIRouter()


class MoneyIn(BaseModel):
    amount: int = Field(gt=0, le=1_000_000_000)
    method: str = Field("cash", pattern="^(cash|card|transfer|wallet)$")
    note: str | None = Field(None, max_length=200)


class AdjustIn(BaseModel):
    target: str = Field(pattern="^(wallet|debt)$")
    amount: int                       # signed
    reason: str = Field(min_length=3, max_length=200)


class LimitIn(BaseModel):
    credit_limit: int | None = Field(None, ge=0)


def acc_out(db, c: Customer, acc: CustomerAccount | None, _tiers=None) -> dict:
    t = S.tier_of(db, c.total_spent, _tiers)
    return {
        "customer_id": c.id, "name": c.name, "phone": c.phone, "visits": c.visits, "total_spent": c.total_spent, "last_visit": c.last_visit,
        "wallet": acc.wallet if acc else 0, "debt": acc.debt if acc else 0, "cashback_total": acc.cashback_total if acc else 0,
        "credit_limit": acc.credit_limit if acc else None,
        "effective_limit": S.credit_limit(db, acc) if acc else int(settings_store.get(db, "loyalty.credit_limit", 0) or 0),
        "tier": t,
    }


def txn_out(t, users) -> dict:
    return {"id": t.id, "kind": t.kind, "amount": t.amount, "balance": t.balance, "method": t.method, "order_id": t.order_id,
            "order_number": t.order_number, "note": t.note, "created_at": t.created_at, "by": users.get(t.created_by)}


@router.get("/summary")
def summary(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), _: User = Depends(require("customers.manage"))):
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    q_w = db.query(WalletTxn)
    if date_from and date_to:
        t1, _a = day_bounds(date_from, cutoff)
        _b, t2 = day_bounds(date_to, cutoff)
        q_w = q_w.filter(WalletTxn.created_at >= t1, WalletTxn.created_at < t2)
    by_kind = dict(q_w.with_entities(WalletTxn.kind, func.sum(WalletTxn.amount)).group_by(WalletTxn.kind).all())
    ts = S.tiers(db)
    counts = {t["key"]: 0 for t in ts}
    for (spent,) in db.query(Customer.total_spent).all():
        t = S.tier_of(db, spent, ts)
        if t:
            counts[t["key"]] = counts.get(t["key"], 0) + 1
    return {
        "members": db.query(Customer).count(),
        "wallet_liability": db.query(func.coalesce(func.sum(CustomerAccount.wallet), 0)).scalar(),
        "receivable": db.query(func.coalesce(func.sum(CustomerAccount.debt), 0)).scalar(),
        "debtors": db.query(CustomerAccount).filter(CustomerAccount.debt > 0).count(),
        "wallet_holders": db.query(CustomerAccount).filter(CustomerAccount.wallet > 0).count(),
        "period": {"topup": by_kind.get("topup", 0), "bonus": by_kind.get("bonus", 0), "cashback": by_kind.get("cashback", 0), "spent": -by_kind.get("pay", 0) - by_kind.get("refund", 0)},
        "tiers": [{**t, "count": counts.get(t["key"], 0)} for t in ts],
    }


@router.get("/customers")
def list_accounts(q: str | None = None, filter: str = Query("all", pattern="^(all|wallet|debt)$"), tier: str | None = None,
                  limit: int = Query(300, le=2000), db: Session = Depends(get_db), _: User = Depends(require("customers.manage"))):
    query = db.query(Customer, CustomerAccount).outerjoin(CustomerAccount, CustomerAccount.customer_id == Customer.id)
    if q:
        qp = normalize_phone(q) or q
        query = query.filter(or_(Customer.name.contains(q), Customer.phone.contains(qp)))
    if filter == "wallet":
        query = query.filter(CustomerAccount.wallet > 0).order_by(CustomerAccount.wallet.desc())
    elif filter == "debt":
        query = query.filter(CustomerAccount.debt > 0).order_by(CustomerAccount.debt.desc())
    else:
        query = query.order_by(Customer.total_spent.desc())
    ts = S.tiers(db)
    rows = [acc_out(db, c, a, ts) for c, a in query.limit(limit * (3 if tier else 1)).all()]
    if tier:
        rows = [r for r in rows if r["tier"] and r["tier"]["key"] == tier][:limit]
    return rows


@router.get("/by-phone/{phone}")
def by_phone(phone: str, db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    c = S.customer_by_phone(db, phone)
    if not c:
        return None
    out = acc_out(db, c, db.get(CustomerAccount, c.id))
    out["next_tier"] = S.next_tier(db, c.total_spent)
    return out


@router.get("/customers/{cid}")
def detail(cid: int, db: Session = Depends(get_db), _: User = Depends(require("customers.manage"))):
    c = get_or_404(db, Customer, cid, "مشتری")
    users = dict(db.query(User.id, User.full_name).all())
    out = acc_out(db, c, db.get(CustomerAccount, cid))
    out["next_tier"] = S.next_tier(db, c.total_spent)
    out["wallet_txns"] = [txn_out(t, users) for t in db.query(WalletTxn).filter(WalletTxn.customer_id == cid).order_by(WalletTxn.id.desc()).limit(200)]
    out["credit_txns"] = [txn_out(t, users) for t in db.query(CreditTxn).filter(CreditTxn.customer_id == cid).order_by(CreditTxn.id.desc()).limit(200)]
    return out


@router.post("/customers/{cid}/topup")
def topup(cid: int, data: MoneyIn, db: Session = Depends(get_db), user: User = Depends(require("loyalty.manage"))):
    if data.method == "wallet":
        raise AppError("روش پرداخت نامعتبر است")
    c = get_or_404(db, Customer, cid, "مشتری")
    acc = S.account(db, c)
    bonus = S.topup(db, acc, data.amount, data.method, user, data.note)
    events.emit("wallet.topup", db=db, customer=c, amount=data.amount + (bonus or 0), balance=acc.wallet)
    log_action(db, user, "wallet.topup", f"شارژ کیف پول «{c.name}» به مبلغ {data.amount:,} ({S.METHOD_LABEL[data.method]})" + (f" + هدیه {bonus:,}" if bonus else ""), entity="customer", entity_id=c.id)
    db.commit()
    return {"wallet": acc.wallet, "bonus": bonus}


@router.post("/customers/{cid}/settle")
def settle(cid: int, data: MoneyIn, db: Session = Depends(get_db), user: User = Depends(require("loyalty.manage"))):
    c = get_or_404(db, Customer, cid, "مشتری")
    acc = S.account(db, c)
    S.settle(db, acc, data.amount, data.method, user, data.note)
    log_action(db, user, "credit.settle", f"تسویه نسیه «{c.name}» به مبلغ {data.amount:,} ({S.METHOD_LABEL[data.method]})", entity="customer", entity_id=c.id)
    db.commit()
    return {"debt": acc.debt, "wallet": acc.wallet}


@router.post("/customers/{cid}/adjust")
def adjust(cid: int, data: AdjustIn, db: Session = Depends(get_db), user: User = Depends(require("loyalty.adjust"))):
    if not data.amount:
        raise AppError("مبلغ اصلاح نمی‌تواند صفر باشد")
    c = get_or_404(db, Customer, cid, "مشتری")
    acc = S.account(db, c)
    if data.target == "wallet":
        S.wallet_move(db, acc, "adjust", data.amount, user, note=data.reason)
    else:
        S.credit_move(db, acc, "adjust", data.amount, user, note=data.reason)
    log_action(db, user, "account.adjust", f"اصلاح دستی {'کیف پول' if data.target == 'wallet' else 'بدهی'} «{c.name}»: {data.amount:+,} — {data.reason}", entity="customer", entity_id=c.id)
    db.commit()
    return {"wallet": acc.wallet, "debt": acc.debt}


@router.put("/customers/{cid}/limit")
def set_limit(cid: int, data: LimitIn, db: Session = Depends(get_db), user: User = Depends(require("loyalty.adjust"))):
    c = get_or_404(db, Customer, cid, "مشتری")
    acc = S.account(db, c)
    acc.credit_limit = data.credit_limit
    log_action(db, user, "credit.limit", f"تعیین سقف نسیه «{c.name}»: " + ("پیش‌فرض" if data.credit_limit is None else f"{data.credit_limit:,}"), entity="customer", entity_id=c.id)
    db.commit()
    return acc_out(db, c, acc)
