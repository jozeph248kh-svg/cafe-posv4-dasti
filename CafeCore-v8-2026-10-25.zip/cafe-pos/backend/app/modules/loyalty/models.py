from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin
from app.modules.customers.models import Customer


class CustomerAccount(Base, TimestampMixin):
    """Wallet balance + credit (نسیه) debt for a customer. One row per customer, created on demand."""
    __tablename__ = "customer_accounts"
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), primary_key=True)
    wallet: Mapped[int] = mapped_column(Integer, default=0)          # money we owe the customer (prepaid / cashback)
    debt: Mapped[int] = mapped_column(Integer, default=0)            # money the customer owes us (credit sales)
    credit_limit: Mapped[int | None] = mapped_column(Integer)        # None = use default setting, 0 = credit not allowed
    cashback_total: Mapped[int] = mapped_column(Integer, default=0)
    customer: Mapped[Customer] = relationship(lazy="joined")


class WalletTxn(Base, TimestampMixin):
    __tablename__ = "wallet_txns"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    kind: Mapped[str] = mapped_column(String(12), index=True)    # topup | bonus | pay | refund | cashback | adjust | settle
    amount: Mapped[int] = mapped_column(Integer)                  # signed change of the wallet
    balance: Mapped[int] = mapped_column(Integer)                 # wallet after
    method: Mapped[str | None] = mapped_column(String(10))       # topup method: cash | card | transfer
    order_id: Mapped[int | None] = mapped_column(Integer, index=True)
    order_number: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class CreditTxn(Base, TimestampMixin):
    __tablename__ = "credit_txns"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    kind: Mapped[str] = mapped_column(String(12), index=True)    # sale | settle | refund | adjust
    amount: Mapped[int] = mapped_column(Integer)                  # signed change of the debt (+ = customer owes more)
    balance: Mapped[int] = mapped_column(Integer)                 # debt after
    method: Mapped[str | None] = mapped_column(String(10))       # settle method
    order_id: Mapped[int | None] = mapped_column(Integer, index=True)
    order_number: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
