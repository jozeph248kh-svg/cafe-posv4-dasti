from app.core import events, settings_store
from app.core.modules import Module

from . import service
from .router import router
from .seed import demo, seed

settings_store.register_defaults(service.DEFAULTS)


def setup() -> None:
    events.subscribe("payment.creating", service.on_payment)
    events.subscribe("payment.creating", service.on_payment_any_refund)
    events.subscribe("order.closed", service.on_closed)


module = Module(
    name="loyalty",
    title="باشگاه مشتریان و کیف پول",
    description="کیف پول اعتباری، کش‌بک پلکانی بر اساس سطح مشتری، حساب نسیه و تسویه بدهی",
    depends=["customers", "orders"],
    routers=[router],
    permissions={"loyalty.manage": "شارژ کیف پول و تسویه نسیه", "loyalty.adjust": "اصلاح دستی حساب مشتری و سقف نسیه"},
    seed=seed,
    demo=demo,
    setup=setup,
)
