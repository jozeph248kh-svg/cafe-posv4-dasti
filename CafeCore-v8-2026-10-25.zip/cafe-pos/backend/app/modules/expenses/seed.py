import random
from datetime import timedelta

from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.permissions import grant_once
from app.core.utils import business_day

from .models import Expense, ExpenseCategory

CATEGORIES = [
    ("اجاره", "🏠", "#6366f1"), ("حقوق و دستمزد", "👥", "#0ea5e9"), ("آب، برق و گاز", "💡", "#f59e0b"),
    ("اینترنت و تلفن", "📶", "#14b8a6"), ("بسته‌بندی و یکبارمصرف", "📦", "#8b5cf6"), ("تعمیرات و نگهداری", "🔧", "#64748b"),
    ("تبلیغات و بازاریابی", "📣", "#ec4899"), ("حمل‌ونقل", "🚚", "#f97316"), ("مواد شوینده و بهداشتی", "🧴", "#10b981"),
    ("مالیات و عوارض", "🏛️", "#ef4444"), ("سایر", "🧾", "#94a3b8"),
]


def seed(db: Session) -> None:
    grant_once(db, "expenses", {"manager": ["expenses.manage", "finance.view"]})
    if not db.query(ExpenseCategory).count():
        for i, (name, icon, color) in enumerate(CATEGORIES):
            db.add(ExpenseCategory(name=name, icon=icon, color=color, sort=i))


def demo(db: Session) -> None:
    if db.query(Expense).count():
        return
    rng = random.Random(77)
    cats = {c.name: c for c in db.query(ExpenseCategory).all()}
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    start = today - timedelta(days=30)

    def add(d, cat, amount, payee=None, note=None, method="transfer"):
        db.add(Expense(category_id=cats[cat].id, expense_date=d, amount=int(round(amount, -4)), method=method, payee=payee, note=note))

    add(start, "اجاره", 180_000_000, "آقای رحیمی (موجر)", "اجاره ماهانه")
    for name, sal in (("سارا احمدی", 32_000_000), ("رضا کریمی", 22_000_000), ("علی محمدی", 18_000_000), ("مریم رضایی", 18_000_000), ("سرآشپز", 38_000_000), ("کمک‌آشپز", 20_000_000)):
        add(start + timedelta(days=1), "حقوق و دستمزد", sal, name, "حقوق ماهانه")
    add(start + timedelta(days=4), "آب، برق و گاز", 9_400_000, "قبض برق")
    add(start + timedelta(days=6), "آب، برق و گاز", 4_100_000, "قبض گاز")
    add(start + timedelta(days=9), "آب، برق و گاز", 1_700_000, "قبض آب")
    add(start + timedelta(days=3), "اینترنت و تلفن", 1_450_000, "مخابرات")
    add(start + timedelta(days=12), "تبلیغات و بازاریابی", 8_000_000, "پیج اینستاگرام", "تبلیغ استوری")
    add(start + timedelta(days=17), "تعمیرات و نگهداری", 6_500_000, "تعمیرکار اسپرسوساز", "سرویس دستگاه اسپرسو")
    add(start + timedelta(days=25), "مالیات و عوارض", 3_200_000, "شهرداری", "عوارض کسب")
    for k in range(0, 31, 3):
        add(start + timedelta(days=k), "بسته‌بندی و یکبارمصرف", rng.uniform(1.2, 2.6) * 1e6, "پخش پلاستیک", method="cash")
    for k in range(1, 31, 5):
        add(start + timedelta(days=k), "مواد شوینده و بهداشتی", rng.uniform(0.6, 1.4) * 1e6, method="cash")
    for k in range(2, 31, 4):
        add(start + timedelta(days=k), "حمل‌ونقل", rng.uniform(0.3, 0.9) * 1e6, "اسنپ بار", method="cash")
