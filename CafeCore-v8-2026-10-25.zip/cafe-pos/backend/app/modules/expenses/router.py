from collections import defaultdict
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import events, settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import business_day

from .models import Expense, ExpenseCategory

router = APIRouter()
manage = require("expenses.manage")
METHODS = {"cash": "نقد", "card": "کارت", "transfer": "حواله / انتقال"}


class CategoryIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    icon: str | None = None
    color: str = "#6366f1"
    sort: int = 0
    is_active: bool = True


class ExpenseIn(BaseModel):
    category_id: int
    expense_date: date
    amount: int = Field(gt=0)
    method: str = Field("cash", pattern="^(cash|card|transfer)$")
    from_register: bool = False
    payee: str | None = Field(None, max_length=80)
    note: str | None = None


def cat_out(c: ExpenseCategory) -> dict:
    return {"id": c.id, "name": c.name, "icon": c.icon, "color": c.color, "sort": c.sort, "is_active": c.is_active}


def exp_out(e: Expense) -> dict:
    return {"id": e.id, "category_id": e.category_id, "category": e.category.name, "icon": e.category.icon, "color": e.category.color,
            "expense_date": e.expense_date, "amount": e.amount, "method": e.method, "from_register": e.from_register,
            "payee": e.payee, "note": e.note, "created_at": e.created_at}


def _range(db: Session, d1: date | None, d2: date | None) -> tuple[date, date]:
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    d2 = d2 or today
    d1 = d1 or d2.replace(day=1)
    if d1 > d2:
        raise AppError("تاریخ شروع بعد از تاریخ پایان است")
    if (d2 - d1).days > 400:
        raise AppError("بازه گزارش حداکثر ۴۰۰ روز است")
    return d1, d2


# ---------------------------------------------------------------- categories
@router.get("/categories")
def list_categories(db: Session = Depends(get_db), _: User = Depends(manage)):
    return [cat_out(c) for c in db.query(ExpenseCategory).order_by(ExpenseCategory.sort, ExpenseCategory.id).all()]


@router.post("/categories", status_code=201)
def create_category(data: CategoryIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = ExpenseCategory(**data.model_dump())
    db.add(c)
    db.commit()
    return cat_out(c)


@router.put("/categories/{cid}")
def update_category(cid: int, data: CategoryIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = get_or_404(db, ExpenseCategory, cid, "دسته هزینه")
    for k, v in data.model_dump().items():
        setattr(c, k, v)
    db.commit()
    return cat_out(c)


@router.delete("/categories/{cid}", status_code=204)
def delete_category(cid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = get_or_404(db, ExpenseCategory, cid, "دسته هزینه")
    if db.query(Expense).filter(Expense.category_id == cid).count():
        c.is_active = False          # keep history intact
    else:
        db.delete(c)
    db.commit()


# ---------------------------------------------------------------- expenses
@router.get("")
def list_expenses(date_from: date | None = None, date_to: date | None = None, category_id: int | None = None,
                  q: str | None = None, db: Session = Depends(get_db), _: User = Depends(manage)):
    d1, d2 = _range(db, date_from, date_to)
    query = db.query(Expense).filter(Expense.expense_date >= d1, Expense.expense_date <= d2)
    if category_id:
        query = query.filter(Expense.category_id == category_id)
    if q:
        query = query.filter(Expense.payee.contains(q) | Expense.note.contains(q))
    rows = query.order_by(Expense.expense_date.desc(), Expense.id.desc()).all()
    by_cat: dict[int, dict] = {}
    for e in rows:
        b = by_cat.setdefault(e.category_id, {"id": e.category_id, "name": e.category.name, "icon": e.category.icon, "color": e.category.color, "amount": 0, "count": 0})
        b["amount"] += e.amount
        b["count"] += 1
    return {"range": {"from": d1, "to": d2}, "total": sum(e.amount for e in rows), "items": [exp_out(e) for e in rows],
            "by_category": sorted(by_cat.values(), key=lambda x: -x["amount"])}


@router.post("", status_code=201)
def create_expense(data: ExpenseIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    cat = get_or_404(db, ExpenseCategory, data.category_id, "دسته هزینه")
    if data.from_register and data.method != "cash":
        raise AppError("پرداخت از صندوق فقط برای هزینه نقدی امکان‌پذیر است")
    e = Expense(**data.model_dump(), created_by=user.id)
    db.add(e)
    if e.from_register:
        events.emit("cash.movement", db=db, kind="out", amount=e.amount, reason=f"هزینه: {cat.name}" + (f" — {e.payee}" if e.payee else ""), user=user)
    log_action(db, user, "expense.create", f"ثبت هزینه {e.amount:,} تومان «{cat.name}»" + (f" — {e.payee}" if e.payee else ""), entity="expense")
    db.commit()
    db.refresh(e)
    return exp_out(e)


@router.put("/{eid}")
def update_expense(eid: int, data: ExpenseIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    e = get_or_404(db, Expense, eid, "هزینه")
    if e.from_register and (data.amount != e.amount or not data.from_register):
        raise AppError("هزینه پرداخت‌شده از صندوق قابل تغییر مبلغ نیست؛ آن را حذف و دوباره ثبت کنید")
    if data.from_register and not e.from_register:
        raise AppError("نمی‌توان هزینه ثبت‌شده را بعداً به صندوق منتقل کرد")
    for k, v in data.model_dump().items():
        setattr(e, k, v)
    log_action(db, user, "expense.update", f"ویرایش هزینه #{e.id} ({e.amount:,} تومان)", entity="expense", entity_id=e.id)
    db.commit()
    db.refresh(e)
    return exp_out(e)


@router.delete("/{eid}", status_code=204)
def delete_expense(eid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    e = get_or_404(db, Expense, eid, "هزینه")
    if e.from_register:
        events.emit("cash.movement", db=db, kind="in", amount=e.amount, reason=f"برگشت هزینه حذف‌شده #{e.id}", user=user, required=False)
    log_action(db, user, "expense.delete", f"حذف هزینه {e.amount:,} تومان «{e.category.name}»", entity="expense", entity_id=e.id)
    db.delete(e)
    db.commit()


# ---------------------------------------------------------------- profit & loss
# One definition per indicator (see docs/FINANCIALS.md) — the single source every screen/Excel number uses:
#   net sales revenue  = Σ closed bills (total − VAT)  −  Σ refunds (the revenue part; the VAT part is reversed too)
#   COGS               = material cost of the goods actually sold, frozen when the bill closed
#                        (item recipe + every chosen modifier recipe), minus the frozen cost of restocked units
#   gross profit       = net sales revenue − COGS − waste            (waste hits the gross result, exactly once)
#   net profit         = gross profit − operating expenses
#   replacement cost   = the same recipes at TODAY's weighted average — a separate indicator, never a COGS rewrite
@router.get("/pnl")
def profit_and_loss(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                    _: User = Depends(require("finance.view"))):
    from app.core.utils import day_bounds
    from app.modules.orders.models import Order, Payment
    from app.modules.reports.service import refund_day

    d1, d2 = _range(db, date_from, date_to)
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    days = defaultdict(lambda: {"revenue": 0, "cogs": 0.0, "expenses": 0, "waste": 0.0})

    # ---- 1) sales: revenue is what the café earned, so the VAT collected from the guest is taken out
    gross = discounts = tax = service = refunds = orders_count = 0
    closed_in_range = (Order.business_date >= d1, Order.business_date <= d2, Order.status == "closed")
    orders = (db.query(Order.id, Order.business_date, Order.subtotal, Order.discount_amount, Order.tax_amount,
                       Order.service_amount, Order.total)
              .filter(*closed_in_range).all())
    for o in orders:
        d = days[o.business_date.isoformat()]
        d["revenue"] += o.total - o.tax_amount
        gross += o.subtotal
        discounts += o.discount_amount
        tax += o.tax_amount
        service += o.service_amount
        orders_count += 1

    # ---- 2) COGS: frozen at sale time, net of what a refund put back on the shelf
    cogs_estimated = cogs_unknown = cogs_unknown_returns = 0
    try:
        from app.modules.inventory.costing import cogs_by_day, cogs_total, replacement_cost
        for day_key, value in cogs_by_day(db, d1, d2).items():      # sold on its sale day, returned on its day
            if d1 <= day_key <= d2:
                days[day_key.isoformat()]["cogs"] += value
        _net, cogs_estimated, cogs_unknown, cogs_unknown_returns = cogs_total(db, d1, d2)
        replacement, no_recipe = replacement_cost(db, d1, d2)
    except Exception:            # inventory module disabled: the café does not track material costs
        replacement, no_recipe = 0.0, 0

    # ---- 3) refunds: money back reverses revenue AND the VAT of that bill, in proportion to its composition,
    #         booked on the day the money went back (so a closed day never changes afterwards)
    s1, _u = day_bounds(d1, cutoff)
    _v, s2 = day_bounds(d2, cutoff)
    # The VAT share of a refund is allocated **cumulatively per bill**: the tax reversed by the k-th refund is
    #   round(cum_amount_after × tax / total) − round(cum_amount_before × tax / total)
    # so the parts always add up to the bill's VAT when the whole bill is refunded. Rounding each refund on its own
    # (round(amount × tax / total)) could lose or gain a toman over several partial refunds (audit finding 3).
    # The cumulative sum is taken over ALL refunds of the bill (not just the ones inside the range), so the parts
    # are the same numbers no matter which period is asked for; only the ones settled in this range are booked here.
    # A refund only reverses revenue that this report actually counted, i.e. refunds of CLOSED bills. A cancelled
    # bill never entered the revenue (step 1 above filters on status), so its refund must not leave the report
    # either; otherwise an old/imported refund row drives the day's revenue negative (audit item 2).
    in_range = (db.query(Payment).join(Order, Order.id == Payment.order_id)
                .filter(Payment.is_refund.is_(True), Payment.created_at >= s1, Payment.created_at < s2,
                        Order.status == "closed").all())
    order_ids = {p.order_id for p in in_range}
    per_order: dict[int, list] = defaultdict(list)
    if order_ids:
        for p in (db.query(Payment).join(Order, Order.id == Payment.order_id)
                  .filter(Payment.order_id.in_(order_ids), Payment.is_refund.is_(True), Order.status == "closed")
                  .order_by(Payment.order_id, Payment.created_at, Payment.id)):
            per_order[p.order_id].append(p)
    booked = {p.id for p in in_range}
    for p in sorted((x for group in per_order.values() for x in group), key=lambda x: (x.created_at, x.id)):
        order = p.order
        amount = -p.amount                                     # positive money handed back
        total = order.total or 0
        before = sum(-x.amount for x in per_order[p.order_id] if (x.created_at, x.id) < (p.created_at, p.id))
        after = before + amount

        def tax_upto(money: int) -> int:
            return round(money * order.tax_amount / total) if total else 0
        tax_part = tax_upto(after) - tax_upto(before)
        if p.id not in booked:                                 # a refund of another day: only feeds the cumulative
            continue
        days[refund_day(p.created_at, cutoff).isoformat()]["revenue"] -= (amount - tax_part)
        tax -= tax_part
        refunds += amount

    # ---- 4) operating expenses (per day) + courier fees
    exps = db.query(Expense).filter(Expense.expense_date >= d1, Expense.expense_date <= d2).all()
    by_cat: dict[int, dict] = {}
    for e in exps:
        days[e.expense_date.isoformat()]["expenses"] += e.amount
        b = by_cat.setdefault(e.category_id, {"id": e.category_id, "name": e.category.name, "icon": e.category.icon,
                                              "color": e.category.color, "amount": 0})
        b["amount"] += e.amount
    try:
        from app.modules.delivery.models import CourierSettlement
        for st in db.query(CourierSettlement).filter(CourierSettlement.created_at >= s1, CourierSettlement.created_at < s2):
            if st.fees:
                b = by_cat.setdefault(-1, {"id": -1, "name": "حق‌الزحمه پیک", "icon": "🛵", "color": "#f97316", "amount": 0})
                b["amount"] += st.fees
                days[refund_day(st.created_at, cutoff).isoformat()]["expenses"] += st.fees
    except ImportError:
        pass

    # ---- 5) waste: its own line, and it lowers the gross result exactly once
    purchases = 0
    try:
        from app.modules.inventory.models import Purchase, StockMovement
        t1, _x = day_bounds(d1, cutoff)
        _y, t2 = day_bounds(d2, cutoff)
        for m in db.query(StockMovement).filter(StockMovement.kind == "waste",
                                               StockMovement.created_at >= t1, StockMovement.created_at < t2):
            days[refund_day(m.created_at, cutoff).isoformat()]["waste"] += -m.qty * m.unit_cost
        purchases = sum(p.total for p in db.query(Purchase).filter(Purchase.purchase_date >= d1, Purchase.purchase_date <= d2))
    except ImportError:
        pass

    # ---- 6) the totals, each derived exactly once from the daily buckets **inside the range**
    # (a refund or a courier settlement can belong to a day outside the range — it creates a bucket of that day,
    #  which must not leak into the totals of this range)
    in_range = [days.get((d1 + timedelta(days=i)).isoformat()) or {"revenue": 0, "cogs": 0, "expenses": 0, "waste": 0}
                for i in range((d2 - d1).days + 1)]
    revenue = sum(d["revenue"] for d in in_range)
    cogs = round(sum(d["cogs"] for d in in_range))
    waste = round(sum(d["waste"] for d in in_range))
    expenses_total = round(sum(d["expenses"] for d in in_range))
    gross_profit = revenue - cogs - waste
    net = gross_profit - expenses_total

    series, cur, running = [], d1, 0
    while cur <= d2:
        d = days.get(cur.isoformat(), {"revenue": 0, "cogs": 0, "expenses": 0, "waste": 0})
        profit = round(d["revenue"] - d["cogs"] - d["waste"] - d["expenses"])
        running += profit
        series.append({"date": cur.isoformat(), "revenue": d["revenue"], "cogs": round(d["cogs"]),
                       "waste": round(d["waste"]), "expenses": d["expenses"], "profit": profit, "cumulative": running})
        cur += timedelta(days=1)

    pct = (lambda v: round(v / revenue * 100, 1) if revenue else 0)
    return {
        "range": {"from": d1, "to": d2, "days": (d2 - d1).days + 1},
        "sales": {"gross": gross, "discounts": discounts, "service": service, "tax": tax, "refunds": refunds,
                  "orders": orders_count},
        "revenue": revenue, "cogs": cogs, "cogs_pct": pct(cogs),
        "cogs_estimated_lines": cogs_estimated, "cogs_unknown_lines": cogs_unknown,
        "cogs_unknown_returns": cogs_unknown_returns,
        "waste": waste,
        "gross_profit": gross_profit, "gross_margin": pct(gross_profit),
        "expenses": expenses_total, "expenses_pct": pct(expenses_total),
        "expenses_by_category": sorted(({**b, "pct": pct(b["amount"])} for b in by_cat.values()), key=lambda x: -x["amount"]),
        "net_profit": net, "net_margin": pct(net), "purchases": purchases,
        "replacement_cost": round(replacement), "replacement_cost_lines_without_recipe": no_recipe,
        "series": series,
    }
