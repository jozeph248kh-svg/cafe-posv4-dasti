from app.core.modules import Module

from .router import router
from .seed import demo, seed

module = Module(
    name="expenses",
    title="هزینه‌ها و سود و زیان",
    description="ثبت هزینه‌های جاری (اجاره، حقوق، قبوض...)، پرداخت از صندوق و صورت سود و زیان",
    depends=["orders", "reports"],
    routers=[router],
    permissions={"expenses.manage": "ثبت و مدیریت هزینه‌ها", "finance.view": "مشاهده سود و زیان"},
    seed=seed,
    demo=demo,
)
