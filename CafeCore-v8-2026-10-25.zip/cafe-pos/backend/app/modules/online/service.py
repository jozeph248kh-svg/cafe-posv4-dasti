import hashlib
import hmac
import secrets
import time
from datetime import timedelta
from collections import defaultdict, deque
from types import SimpleNamespace

from sqlalchemy.orm import Session

from app.core import events
from app.core import settings_store
from app.core.audit import log_action
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import normalize_phone, now

from .models import OnlineOrder, PhoneOtp

DEFAULTS = {
    "online.enabled": True,          # public online-order page (/order)
    "online.accepting": True,        # temporarily pause new orders (busy kitchen)
    "online.pickup": True,
    "online.delivery": True,
    "online.min_order": 250_000,     # minimum basket for delivery/pickup
    "online.qr_ordering": True,      # guests can order from the table QR menu
    "online.qr_auto_accept": False,  # send QR table orders straight to the kitchen
    "online.notice": "",             # message shown on top of the order page
    "online.public_url": "",         # public address (domain / port-forward) used in the shared link + QR
    "online.promo_otp": False,       # promo codes limited per customer need an SMS code to the guest's phone
}
_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(key: str, limit: int = 6, window: int = 600, record: bool = False) -> None:
    """Check (and with record=True, count) placed orders per IP/phone to stop spam from the public page."""
    q = _hits[key]
    t = time.monotonic()
    while q and t - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise AppError("تعداد درخواست‌ها زیاد است؛ چند دقیقه دیگر دوباره تلاش کنید", 429, "rate_limited")
    if record:
        q.append(t)


def price_lines(db: Session, lines) -> tuple[list[dict], int]:
    """Validate guest lines with the same rules as the POS (availability, required modifiers) and price them."""
    from app.modules.orders.service import build_line
    ghost = SimpleNamespace(id=None)
    out, subtotal = [], 0
    for ld in lines:
        line = build_line(db, ld, ghost)
        out.append({"menu_item_id": ld.menu_item_id, "qty": ld.qty, "modifier_option_ids": ld.modifier_option_ids, "note": ld.note,
                    "name": line.name, "unit_price": line.unit_price, "modifiers": [m["name"] for m in line.modifiers]})
        subtotal += line.unit_price * line.qty
    return out, subtotal


MODE_TYPES = {"pickup": "takeaway", "delivery": "delivery", "table": "dine_in"}


def _probe(items: list[dict], subtotal: int, mode: str, phone: str | None):
    """A throw-away (never saved) order with the cart's lines — lets the discount engine price a promo code."""
    from app.modules.orders.models import Order, OrderLine
    o = Order(id=0, type=MODE_TYPES[mode], subtotal=subtotal, customer_phone=phone, status="open")
    o.lines = [OrderLine(menu_item_id=i["menu_item_id"], name=i.get("name") or "", base_price=i["unit_price"],
                         unit_price=i["unit_price"], qty=i["qty"], modifiers=[], status="pending") for i in items]
    return o


# ---------------------------------------------------------------- SMS verification (promo codes)
OTP_TTL = timedelta(minutes=5)
OTP_TOKEN_TTL = timedelta(minutes=30)
OTP_MAX_TRIES = 5
OTP_RESEND = timedelta(seconds=60)
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def _code_hash(code: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(8)
    return f"{salt}${hashlib.sha256(f'{salt}:{code}'.encode()).hexdigest()}"


def _code_ok(code: str, stored: str) -> bool:
    salt = stored.split("$", 1)[0]
    return hmac.compare_digest(_code_hash(code, salt), stored)


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def otp_required(db: Session, preset) -> bool:
    return bool(settings_store.get(db, "online.promo_otp", False) and preset.per_customer_limit)


def otp_send(db: Session, phone: str, ip: str | None) -> dict:
    """Text a 5-digit code to the guest. Fails closed (no code → no limited promo) when SMS is not available."""
    try:
        from app.modules.sms import service as sms
    except ImportError:
        sms = None
    if not sms or not settings_store.get(db, "sms.enabled", False):
        raise AppError("ارسال پیامک فعال نیست؛ این کد تخفیف فعلاً قابل استفاده نیست", 503, "sms_unavailable")
    t = now()
    last = db.query(PhoneOtp).filter(PhoneOtp.phone == phone).order_by(PhoneOtp.id.desc()).first()
    if last and t - last.created_at < OTP_RESEND:
        wait = int((OTP_RESEND - (t - last.created_at)).total_seconds()) + 1
        raise AppError(f"کد قبلاً ارسال شد؛ {wait} ثانیه دیگر دوباره تلاش کنید", 429, "otp_wait", retry_after=wait)
    db.query(PhoneOtp).filter(PhoneOtp.created_at < t - timedelta(days=1)).delete(synchronize_session=False)
    db.query(PhoneOtp).filter(PhoneOtp.phone == phone, PhoneOtp.verified_at.is_(None)).update({"expires_at": t}, synchronize_session=False)
    code = f"{secrets.randbelow(100_000):05d}"
    name = settings_store.get(db, "business.name", "") or ""
    db.add(PhoneOtp(phone=phone, purpose="promo", code_hash=_code_hash(code), expires_at=t + OTP_TTL, ip=ip, created_at=t))
    if not sms.enqueue(db, phone, f"کد تأیید {name}: {code}\nاعتبار: ۵ دقیقه", "otp"):
        raise AppError("شماره موبایل معتبر نیست", code="phone_invalid")
    return {"sent": True, "expires_in": int(OTP_TTL.total_seconds()), "resend_in": int(OTP_RESEND.total_seconds())}


def otp_verify(db: Session, phone: str, code: str) -> dict:
    """Check the code → one-time token (valid 30 min) for promo check + checkout. Wrong tries are counted and kept."""
    t = now()
    o = (db.query(PhoneOtp).filter(PhoneOtp.phone == phone, PhoneOtp.verified_at.is_(None), PhoneOtp.expires_at > t)
         .order_by(PhoneOtp.id.desc()).first())
    if not o:
        raise AppError("کد منقضی شده است؛ دوباره درخواست کد بدهید", 400, "otp_expired")
    o.attempts += 1
    code = code.strip().translate(_DIGITS)
    if not _code_ok(code, o.code_hash):
        left = OTP_MAX_TRIES - o.attempts
        if left <= 0:
            o.expires_at = t
        db.commit()                                   # keep the counted try (the error below rolls back otherwise)
        if left <= 0:
            raise AppError("تعداد تلاش‌ها تمام شد؛ دوباره درخواست کد بدهید", 400, "otp_locked")
        raise AppError(f"کد اشتباه است ({left} تلاش دیگر)", 400, "otp_wrong", left=left)
    token = secrets.token_urlsafe(24)
    o.verified_at, o.token_hash, o.token_expires_at = t, _token_hash(token), t + OTP_TOKEN_TTL
    return {"otp_token": token, "expires_in": int(OTP_TOKEN_TTL.total_seconds())}


def otp_check(db: Session, phone: str | None, token: str | None, consume: bool) -> None:
    o = None
    if phone and token:
        o = (db.query(PhoneOtp).filter(PhoneOtp.token_hash == _token_hash(token), PhoneOtp.phone == phone,
                                       PhoneOtp.used_at.is_(None), PhoneOtp.token_expires_at > now()).first())
    if not o:
        raise AppError("برای استفاده از این کد تخفیف، شماره موبایل خود را با کد پیامکی تأیید کنید", 403, "otp_required")
    if consume:
        o.used_at = now()


def promo_quote(db: Session, code: str, items: list[dict], subtotal: int, mode: str, phone: str | None,
                otp_token: str | None = None, consume_otp: bool = False):
    """→ (preset, discount) for a cart, or AppError explaining why the code can't be used."""
    from app.modules.orders import engine, service as osvc
    from app.modules.orders.discount_presets import preset_unavailable
    from app.modules.orders.discounts import find_code
    p = find_code(db, code)
    if p.scope == "item":
        raise AppError("این کد فقط در صندوق و روی آیتم قابل استفاده است", code="invalid_code")
    probe = _probe(items, subtotal, mode, phone)
    with db.no_autoflush:
        why = preset_unavailable(p, probe, db=db)
        if why:
            raise AppError(f"کد تخفیف قابل استفاده نیست: {why}", code="discount_unavailable")
        rule = engine.rule_of(p)
        amount = engine.rule_amount(db, probe, rule) if rule else osvc.discount_of(p.kind, p.value, None, subtotal)
    if p.max_amount:
        amount = min(amount, p.max_amount)
    amount = min(amount, subtotal)
    if amount <= 0:
        raise AppError(f"شرایط کد «{p.code}» در سبد خرید شما برقرار نیست", code="discount_not_applicable")
    if otp_required(db, p):
        otp_check(db, phone, otp_token, consume_otp)
    return p, amount


def apply_promo(db: Session, oo: OnlineOrder, o, user: User) -> None:
    """Accepting an online order: give the real order the promo code the guest used (as validated at checkout)."""
    from app.modules.orders import engine, service as osvc
    from app.modules.orders.models import DiscountPreset
    if not oo.promo_code or (o.discount_type and not o.discount_auto):
        return
    p = db.query(DiscountPreset).filter(DiscountPreset.code == oo.promo_code).first()
    if not p:
        return
    o.discount_type, o.discount_value, o.discount_cap = p.kind, p.value, p.max_amount
    o.discount_reason, o.discount_preset_id, o.discount_rule, o.discount_auto = f"{p.name} (کد {p.code})", p.id, engine.rule_of(p), False
    o.discount_by, o.discount_approved_by, o.discount_code = user.id, None, p.code
    osvc.recalc(db, o)


def system_user(db: Session) -> User:
    from app.core.models import Role
    return db.query(User).join(Role, Role.id == User.role_id).filter(Role.name == "admin").first() or db.query(User).first()


def accept(db: Session, oo: OnlineOrder, user: User, eta: int | None = None):
    from app.modules.orders import service as osvc
    from app.modules.orders.schemas import LineIn, OrderCreate
    if oo.status != "pending":
        raise AppError("این سفارش قبلاً بررسی شده است")
    lines = [LineIn(menu_item_id=i["menu_item_id"], qty=i["qty"], modifier_option_ids=i.get("modifier_option_ids") or [], note=i.get("note")) for i in oo.items]
    note = " — ".join(x for x in [oo.note, "پرداخت با کارت در محل" if oo.pay_method == "card" else None] if x) or None
    if oo.mode == "table":
        o = osvc.table_open_order(db, oo.table_id)
        if o:
            osvc.add_lines(db, o, lines, user)
            db.flush()
            osvc.send_to_kitchen(db, o, user)
            osvc.recalc(db, o)
            osvc.notify(db, o, "updated")
        else:
            o = osvc.create_order(db, OrderCreate(type="dine_in", table_id=oo.table_id, guests=1, customer_name=oo.customer_name,
                                                  customer_phone=oo.phone, note=note, lines=lines, send=True), user)
            o.source = "qr"
    else:
        o = osvc.create_order(db, OrderCreate(type="delivery" if oo.mode == "delivery" else "takeaway", customer_name=oo.customer_name,
                                              customer_phone=oo.phone, customer_address=oo.address, note=note, lines=lines, send=True), user)
        o.source = "online"
        if oo.mode == "delivery":
            try:
                from app.modules.delivery import service as dsvc
                from app.modules.delivery.models import DeliveryZone
                d = dsvc.ensure(db, o)
                zone = db.get(DeliveryZone, oo.zone_id) if oo.zone_id else None
                if zone:
                    dsvc.set_zone(db, o, d, zone, user)
                d.collect = oo.pay_method == "cash"
                dsvc.changed(db, o.id, "new")
            except ImportError:
                pass
    apply_promo(db, oo, o, user)
    oo.status, oo.order_id, oo.handled_by, oo.handled_at = "accepted", o.id, user.id, now()
    oo.eta_minutes = eta
    events.emit("online.accepted", db=db, request=oo, order=o)
    log_action(db, user, "online.accept", f"تأیید سفارش {'میز' if oo.mode == 'table' else 'آنلاین'} — سفارش #{o.number}", entity="order", entity_id=o.id)
    publish_after_commit(db, "online.changed", {"id": oo.id, "status": "accepted"})
    return o


def tracking(db: Session, oo: OnlineOrder) -> dict:
    from app.modules.orders.models import Order
    s = settings_store.get_all(db)
    stage, order = oo.status, None
    if oo.status == "accepted" and oo.order_id:
        order = db.get(Order, oo.order_id)
        stage = "accepted"
        if order:
            mine = [l for l in order.active_lines if l.station_id]
            if order.status == "cancelled":
                stage = "cancelled"
            elif mine and all(l.status in ("ready", "served") for l in mine):
                stage = "ready"
            elif any(l.status in ("sent", "ready") for l in mine):
                stage = "preparing"
            try:
                from app.modules.delivery.models import Delivery
                d = db.get(Delivery, order.id)
                if d and d.status in ("out", "delivered"):
                    stage = d.status
            except ImportError:
                pass
            if order.status == "closed" and stage not in ("out", "delivered") and oo.mode != "table":
                stage = "completed"
    return {
        "token": oo.token, "mode": oo.mode, "stage": stage, "status": oo.status, "reject_reason": oo.reject_reason,
        "created_at": oo.created_at, "eta_minutes": oo.eta_minutes, "handled_at": oo.handled_at,
        "number": order.number if order else None, "items": oo.items, "subtotal": oo.subtotal, "delivery_fee": oo.delivery_fee,
        "discount": oo.discount or 0, "promo_code": oo.promo_code,
        "tax": oo.tax, "total": order.total if order else oo.total, "customer_name": oo.customer_name, "address": oo.address,
        "business": {"name": s["business.name"], "phone": s["business.phone"], "logo": s["business.logo"]},
    }


def phone_ok(phone: str | None) -> str:
    p = normalize_phone(phone)
    if not p or not p.startswith("09") or len(p) != 11:
        raise AppError("شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷)", code="phone_invalid")
    return p
