from app.core import settings_store
from app.core.modules import Module
from app.core.permissions import grant_once

from . import service
from .router import router

settings_store.register_defaults(service.DEFAULTS)


def seed(db) -> None:
    grant_once(db, "online", {"manager": ["online.manage"], "cashier": ["online.manage"], "waiter": ["online.manage"]})


def demo(db) -> None:
    """Two waiting requests so the POS shows the online-orders inbox."""
    from datetime import timedelta

    from app.core.utils import now
    from app.modules.floor.models import DiningTable
    from app.modules.menu.models import MenuItem
    from app.modules.orders.schemas import LineIn
    from app.modules.orders.service import table_open_order

    from .models import OnlineOrder
    if db.query(OnlineOrder).count():
        return
    simple = [i for i in db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.is_available.is_(True)).all()
              if i.station_id and not any(g.min_select for g in i.modifier_groups)]
    if len(simple) < 4:
        return
    try:
        from app.modules.delivery.models import DeliveryZone
        zone = db.query(DeliveryZone).order_by(DeliveryZone.sort, DeliveryZone.id).first()
    except ImportError:
        zone = None
    table = next((t for t in db.query(DiningTable).filter(DiningTable.is_active.is_(True)).order_by(DiningTable.id.desc()) if not table_open_order(db, t.id)), None)
    reqs = []
    if zone:
        reqs.append(dict(mode="delivery", customer_name="شیرین دلاوری", phone="09127770011", address="سعادت‌آباد، میدان کاج، خیابان سرو، پلاک ۴۲، واحد ۳",
                         zone_id=zone.id, delivery_fee=zone.customer_fee, note="زنگ واحد ۳ خراب است، تماس بگیرید", lines=simple[:2], ago=3))
    if table:
        reqs.append(dict(mode="table", table_id=table.id, customer_name=None, phone=None, lines=simple[2:4], ago=1, note="بدون یخ لطفاً"))
    for r in reqs:
        items, subtotal = service.price_lines(db, [LineIn(menu_item_id=i.id, qty=1) for i in r.pop("lines")])
        ago = r.pop("ago")
        fee = r.get("delivery_fee", 0)
        tax = round((subtotal + fee) * 0.1)
        oo = OnlineOrder(items=items, subtotal=subtotal, tax=tax, total=subtotal + fee + tax, status="pending", pay_method="cash", **r)
        db.add(oo)
        db.flush()
        oo.created_at = now() - timedelta(minutes=ago)


module = Module(
    name="online",
    title="سفارش آنلاین و سفارش از روی میز",
    description="صفحه سفارش آنلاین (بیرون‌بر/پیک) بدون نیاز به اپ، سفارش مهمان از منوی QR میز، تأیید توسط صندوق و پیگیری وضعیت",
    depends=["orders", "menu", "floor"],
    routers=[router],
    permissions={"online.manage": "تأیید/رد سفارش‌های آنلاین و QR"},
    seed=seed,
    demo=demo,
)
