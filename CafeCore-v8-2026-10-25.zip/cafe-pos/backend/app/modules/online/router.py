from datetime import timedelta

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session, selectinload

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import now
from app.modules.floor.models import DiningTable
from app.modules.menu.models import MenuCategory, MenuItem
from app.modules.orders.schemas import LineIn

from . import service as S
from .models import OnlineOrder

router = APIRouter()
perm = require("online.manage")


class GuestOrderIn(BaseModel):
    mode: str = Field(pattern="^(pickup|delivery|table)$")
    table_token: str | None = None
    customer_name: str | None = Field(None, max_length=80)
    phone: str | None = None
    address: str | None = Field(None, max_length=400)
    zone_id: int | None = None
    note: str | None = Field(None, max_length=300)
    pay_method: str = Field("cash", pattern="^(cash|card)$")
    promo_code: str | None = Field(None, max_length=30)
    otp_token: str | None = Field(None, max_length=64)
    lines: list[LineIn] = Field(min_length=1, max_length=40)


class AcceptIn(BaseModel):
    eta_minutes: int | None = Field(None, ge=0, le=240)


class RejectIn(BaseModel):
    reason: str = Field(min_length=2, max_length=200)


def _zones(db: Session) -> list[dict]:
    try:
        from app.modules.delivery.models import DeliveryZone
    except ImportError:
        return []
    return [{"id": z.id, "name": z.name, "fee": z.customer_fee, "eta": z.eta_minutes, "min_order": z.min_order}
            for z in db.query(DeliveryZone).filter(DeliveryZone.is_active.is_(True)).order_by(DeliveryZone.sort, DeliveryZone.id)]


def staff_out(oo: OnlineOrder, tables: dict) -> dict:
    return {"id": oo.id, "token": oo.token, "mode": oo.mode, "table": tables.get(oo.table_id), "customer_name": oo.customer_name, "phone": oo.phone,
            "address": oo.address, "note": oo.note, "items": oo.items, "subtotal": oo.subtotal, "delivery_fee": oo.delivery_fee, "total": oo.total,
            "pay_method": oo.pay_method, "status": oo.status, "reject_reason": oo.reject_reason, "order_id": oo.order_id,
            "created_at": oo.created_at, "handled_at": oo.handled_at, "eta_minutes": oo.eta_minutes,
            "waiting": int((now() - oo.created_at).total_seconds() // 60)}


# ------------------------------------------------------------------ public (no login)
@router.get("/public/info")
def info(table: str | None = None, db: Session = Depends(get_db)):
    s = settings_store.get_all(db)
    tbl = db.query(DiningTable).filter(DiningTable.qr_token == table, DiningTable.is_active.is_(True)).first() if table else None
    return {
        "enabled": bool(s["online.enabled"]), "accepting": bool(s["online.accepting"]), "pickup": bool(s["online.pickup"]),
        "delivery": bool(s["online.delivery"]) and bool(_zones(db)), "min_order": int(s["online.min_order"] or 0),
        "qr_ordering": bool(s["online.qr_ordering"]), "notice": s.get("online.notice") or "", "zones": _zones(db),
        "table": {"name": tbl.name} if tbl else None,
        "tax_percent": s["tax.percent"] if s["tax.enabled"] else 0,
        "business": {"name": s["business.name"], "phone": s["business.phone"], "address": s["business.address"], "logo": s["business.logo"],
                     "currency": s["currency.label"], "instagram": s.get("business.instagram"), "wifi": s.get("business.wifi")},
    }


@router.get("/public/menu")
def menu(db: Session = Depends(get_db)):
    cats = db.query(MenuCategory).filter(MenuCategory.is_active.is_(True)).order_by(MenuCategory.sort, MenuCategory.id).all()
    items = (db.query(MenuItem).options(selectinload(MenuItem.modifier_groups))
             .filter(MenuItem.is_active.is_(True), MenuItem.show_in_qr.is_(True)).order_by(MenuItem.sort, MenuItem.id).all())
    return {
        "categories": [{"id": c.id, "name": c.name, "icon": c.icon, "color": c.color} for c in cats],
        "items": [{"id": i.id, "category_id": i.category_id, "name": i.name, "description": i.description, "price": i.price, "image": i.image,
                   "is_available": i.is_available, "tags": i.tags,
                   "groups": [{"id": g.id, "name": g.name, "min": g.min_select, "max": g.max_select,
                               "options": [{"id": o.id, "name": o.name, "price": o.price_delta, "is_default": o.is_default, "is_available": o.is_available}
                                           for o in g.options]} for g in i.modifier_groups]} for i in items],
    }


@router.post("/public/orders", status_code=201)
def place(data: GuestOrderIn, request: Request, db: Session = Depends(get_db)):
    s = settings_store.get_all(db)
    ip = request.client.host if request.client else "?"
    S.rate_limit(f"ip:{ip}")
    tbl = None
    if data.mode == "table":
        tbl = db.query(DiningTable).filter(DiningTable.qr_token == data.table_token, DiningTable.is_active.is_(True)).first()
        if not tbl:
            raise AppError("کد میز نامعتبر است", 404, "not_found")
        if not s["online.qr_ordering"]:
            raise AppError("سفارش از روی میز فعال نیست؛ لطفاً گارسون را صدا بزنید", 403, "disabled")
    else:
        if not s["online.enabled"]:
            raise AppError("سفارش آنلاین فعال نیست", 403, "disabled")
        if not s["online.accepting"]:
            raise AppError("در حال حاضر سفارش آنلاین پذیرفته نمی‌شود؛ کمی بعد دوباره تلاش کنید", 403, "paused")
        if data.mode == "pickup" and not s["online.pickup"]:
            raise AppError("سفارش بیرون‌بر فعال نیست")
        if data.mode == "delivery" and not s["online.delivery"]:
            raise AppError("ارسال با پیک فعال نیست")
        if not (data.customer_name and len(data.customer_name.strip()) >= 2):
            raise AppError("نام خود را وارد کنید", code="name_required")
    phone = S.phone_ok(data.phone) if data.mode != "table" or data.phone else None
    if phone:
        S.rate_limit(f"phone:{phone}", limit=4, window=600)
    items, subtotal = S.price_lines(db, data.lines)
    fee = 0
    zone = None
    if data.mode == "delivery":
        if not data.address or len(data.address.strip()) < 8:
            raise AppError("آدرس کامل را وارد کنید", code="address_required")
        zone = next((z for z in _zones(db) if z["id"] == data.zone_id), None)
        if not zone:
            raise AppError("منطقه ارسال را انتخاب کنید", code="zone_required")
        fee = zone["fee"]
        if zone["min_order"] and subtotal < zone["min_order"]:
            raise AppError(f"حداقل سفارش برای این منطقه {zone['min_order']:,} تومان است", code="min_order")
    if data.mode != "table" and subtotal < int(s["online.min_order"] or 0):
        raise AppError(f"حداقل مبلغ سفارش آنلاین {int(s['online.min_order']):,} تومان است", code="min_order")
    promo, discount = None, 0
    if data.promo_code and data.promo_code.strip():
        promo, discount = S.promo_quote(db, data.promo_code, items, subtotal, data.mode, phone, data.otp_token, consume_otp=True)
    tax = round((subtotal - discount + fee) * s["tax.percent"] / 100) if s["tax.enabled"] else 0
    oo = OnlineOrder(mode=data.mode, table_id=tbl.id if tbl else None, customer_name=(data.customer_name or "").strip() or None, phone=phone,
                     address=data.address if data.mode == "delivery" else None, zone_id=zone["id"] if zone else None, note=data.note,
                     items=items, subtotal=subtotal, delivery_fee=fee, tax=tax, total=subtotal - discount + fee + tax, pay_method=data.pay_method,
                     promo_code=promo.code if promo else None, discount=discount,
                     status="pending", ip=ip)
    db.add(oo)
    db.flush()
    if data.mode == "table" and s["online.qr_auto_accept"]:
        S.accept(db, oo, S.system_user(db))
    else:
        publish_after_commit(db, "online.new", {"id": oo.id, "mode": oo.mode, "table": tbl.name if tbl else None, "name": oo.customer_name, "total": oo.total})
    db.commit()
    S.rate_limit(f"ip:{ip}", record=True)
    if phone:
        S.rate_limit(f"phone:{phone}", limit=4, window=600, record=True)
    return S.tracking(db, oo)


class PromoIn(BaseModel):
    code: str = Field(min_length=1, max_length=30)
    mode: str = Field("pickup", pattern="^(pickup|delivery|table)$")
    phone: str | None = None
    otp_token: str | None = Field(None, max_length=64)
    lines: list[LineIn] = Field(min_length=1, max_length=40)


class OtpSendIn(BaseModel):
    phone: str = Field(min_length=10, max_length=20)


class OtpVerifyIn(BaseModel):
    phone: str = Field(min_length=10, max_length=20)
    code: str = Field(pattern=r"^\s*\d{5}\s*$")


@router.post("/public/otp/send")
def otp_send(data: OtpSendIn, request: Request, db: Session = Depends(get_db)):
    """Text a verification code to the guest (promo codes limited per customer, when online.promo_otp is on)."""
    ip = request.client.host if request.client else "?"
    phone = S.phone_ok(data.phone)
    S.rate_limit(f"otp-ip:{ip}", limit=10, window=3600)
    S.rate_limit(f"otp-phone:{phone}", limit=3, window=900)
    res = S.otp_send(db, phone, ip)
    db.commit()
    S.rate_limit(f"otp-ip:{ip}", limit=10, window=3600, record=True)
    S.rate_limit(f"otp-phone:{phone}", limit=3, window=900, record=True)
    return res


@router.post("/public/otp/verify")
def otp_verify(data: OtpVerifyIn, request: Request, db: Session = Depends(get_db)):
    ip = request.client.host if request.client else "?"
    S.rate_limit(f"otpv:{ip}", limit=30, window=600)
    S.rate_limit(f"otpv:{ip}", limit=30, window=600, record=True)
    res = S.otp_verify(db, S.phone_ok(data.phone), data.code)
    db.commit()
    return res


@router.post("/public/promo")
def promo(data: PromoIn, request: Request, db: Session = Depends(get_db)):
    """Check a promo code against the guest's cart (online page) → name and discount."""
    ip = request.client.host if request.client else "?"
    S.rate_limit(f"promo:{ip}", limit=20, window=600)
    S.rate_limit(f"promo:{ip}", limit=20, window=600, record=True)      # every try counts (no code guessing)
    items, subtotal = S.price_lines(db, data.lines)
    phone = S.phone_ok(data.phone) if data.phone else None
    p, amount = S.promo_quote(db, data.code, items, subtotal, data.mode, phone, data.otp_token)
    return {"code": p.code, "name": p.name, "discount": amount}


@router.get("/public/orders/{token}")
def track(token: str, db: Session = Depends(get_db)):
    oo = db.query(OnlineOrder).filter(OnlineOrder.token == token).first()
    if not oo:
        raise AppError("سفارش یافت نشد", 404, "not_found")
    return S.tracking(db, oo)


# ------------------------------------------------------------------ staff
@router.get("/requests")
def requests(scope: str = "pending", db: Session = Depends(get_db), _: User = Depends(perm)):
    q = db.query(OnlineOrder)
    if scope == "pending":
        q = q.filter(OnlineOrder.status == "pending").order_by(OnlineOrder.id)
    else:
        q = q.filter(OnlineOrder.created_at >= now() - timedelta(days=1 if scope == "today" else 30)).order_by(OnlineOrder.id.desc())
    tables = {t.id: t.name for t in db.query(DiningTable).all()}
    return [staff_out(o, tables) for o in q.limit(300).all()]


@router.post("/requests/{rid}/accept")
def accept(rid: int, data: AcceptIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    oo = get_or_404(db, OnlineOrder, rid, "سفارش")
    o = S.accept(db, oo, user, data.eta_minutes)
    db.commit()
    return {"order_id": o.id, "number": o.number}


@router.post("/requests/{rid}/reject")
def reject(rid: int, data: RejectIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    oo = get_or_404(db, OnlineOrder, rid, "سفارش")
    if oo.status != "pending":
        raise AppError("این سفارش قبلاً بررسی شده است")
    oo.status, oo.reject_reason, oo.handled_by, oo.handled_at = "rejected", data.reason, user.id, now()
    log_action(db, user, "online.reject", f"رد سفارش آنلاین «{oo.customer_name or ''}» — {data.reason}", entity="online", entity_id=oo.id)
    publish_after_commit(db, "online.changed", {"id": oo.id, "status": "rejected"})
    db.commit()
    return {"ok": True}
