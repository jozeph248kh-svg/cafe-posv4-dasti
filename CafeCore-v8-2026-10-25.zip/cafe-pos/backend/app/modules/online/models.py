import secrets
from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


class OnlineOrder(Base, TimestampMixin):
    """An order request placed by a guest (online order page or table QR). Staff accept it → a real Order is created."""
    __tablename__ = "online_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    token: Mapped[str] = mapped_column(String(24), unique=True, index=True, default=lambda: secrets.token_urlsafe(12))
    mode: Mapped[str] = mapped_column(String(10))                        # pickup | delivery | table
    table_id: Mapped[int | None] = mapped_column(ForeignKey("dining_tables.id"))
    customer_name: Mapped[str | None] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20), index=True)
    address: Mapped[str | None] = mapped_column(Text)
    zone_id: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(String(300))
    items: Mapped[list[dict]] = mapped_column(JSON, default=list)       # [{menu_item_id, qty, modifier_option_ids, note, name, unit_price, modifiers}]
    subtotal: Mapped[int] = mapped_column(Integer, default=0)
    delivery_fee: Mapped[int] = mapped_column(Integer, default=0)
    tax: Mapped[int] = mapped_column(Integer, default=0)
    promo_code: Mapped[str | None] = mapped_column(String(30))
    discount: Mapped[int] = mapped_column(Integer, default=0, server_default="0")   # promo-code discount (estimate)
    total: Mapped[int] = mapped_column(Integer, default=0)              # estimate shown to the guest
    pay_method: Mapped[str] = mapped_column(String(10), default="cash")  # cash | card (paid at the door / counter)
    status: Mapped[str] = mapped_column(String(10), default="pending", index=True)  # pending | accepted | rejected
    reject_reason: Mapped[str | None] = mapped_column(String(200))
    eta_minutes: Mapped[int | None] = mapped_column(Integer)
    order_id: Mapped[int | None] = mapped_column(Integer, index=True)
    handled_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    handled_at: Mapped[datetime | None] = mapped_column(DateTime)
    ip: Mapped[str | None] = mapped_column(String(45))


class PhoneOtp(Base, TimestampMixin):
    """One SMS verification code (online promo codes with a per-customer limit, when online.promo_otp is on).
    Only hashes are stored; a verified code yields a one-time token that the checkout consumes."""
    __tablename__ = "phone_otps"
    id: Mapped[int] = mapped_column(primary_key=True)
    phone: Mapped[str] = mapped_column(String(20), index=True)
    purpose: Mapped[str] = mapped_column(String(20), default="promo")
    code_hash: Mapped[str] = mapped_column(String(120))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime)
    token_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    token_expires_at: Mapped[datetime | None] = mapped_column(DateTime)
    used_at: Mapped[datetime | None] = mapped_column(DateTime)
    ip: Mapped[str | None] = mapped_column(String(45))
