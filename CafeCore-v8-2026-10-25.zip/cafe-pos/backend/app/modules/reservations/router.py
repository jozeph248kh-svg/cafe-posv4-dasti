from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import events
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import LocalDateTime, normalize_phone, now, phone_update
from app.modules.floor.models import Area, DiningTable

from .models import Reservation, WaitlistEntry

router = APIRouter()
perm = require("reservations.manage")
ACTIVE = ("booked", "confirmed", "seated")
DEFAULTS = {"reservation.default_duration": 90, "reservation.hold_minutes": 15, "reservation.warn_minutes": 60}


class ReservationIn(BaseModel):
    customer_name: str = Field(min_length=2, max_length=80)
    phone: str | None = None
    guests: int = Field(2, ge=1, le=200)
    start_at: LocalDateTime
    duration: int = Field(90, ge=15, le=600)
    table_id: int | None = None
    source: str = Field("phone", pattern="^(phone|walk_in|online|instagram)$")
    occasion: str | None = Field(None, max_length=40)
    deposit: int = Field(0, ge=0)
    note: str | None = None


class StatusIn(BaseModel):
    status: str = Field(pattern="^(booked|confirmed|seated|completed|no_show|cancelled)$")
    open_order: bool = True
    table_id: int | None = None


class WaitIn(BaseModel):
    customer_name: str = Field(min_length=2, max_length=80)
    phone: str | None = None
    guests: int = Field(2, ge=1, le=100)
    quoted_minutes: int = Field(15, ge=0, le=240)
    note: str | None = Field(None, max_length=200)


class WaitStatusIn(BaseModel):
    status: str = Field(pattern="^(waiting|notified|seated|left)$")
    table_id: int | None = None
    open_order: bool = True


def out(r: Reservation) -> dict:
    t = now()
    late = r.status in ("booked", "confirmed") and t > r.start_at + timedelta(minutes=15)
    return {"id": r.id, "customer_name": r.customer_name, "phone": r.phone, "guests": r.guests, "start_at": r.start_at,
            "end_at": r.start_at + timedelta(minutes=r.duration), "duration": r.duration, "table_id": r.table_id,
            "table": r.table.name if r.table else None, "status": r.status, "source": r.source, "occasion": r.occasion,
            "deposit": r.deposit, "note": r.note, "order_id": r.order_id, "seated_at": r.seated_at, "late": late}


def wout(w: WaitlistEntry) -> dict:
    return {"id": w.id, "customer_name": w.customer_name, "phone": w.phone, "guests": w.guests, "quoted_minutes": w.quoted_minutes,
            "status": w.status, "note": w.note, "table": w.table.name if w.table else None, "created_at": w.created_at,
            "notified_at": w.notified_at, "waited": int((now() - w.created_at).total_seconds() // 60)}


def conflicts(db: Session, table_id: int, start: datetime, duration: int, exclude: int | None = None) -> list[Reservation]:
    end = start + timedelta(minutes=duration)
    q = db.query(Reservation).filter(Reservation.table_id == table_id, Reservation.status.in_(ACTIVE),
                                     Reservation.start_at < end, Reservation.start_at > start - timedelta(hours=12))
    if exclude:
        q = q.filter(Reservation.id != exclude)
    return [r for r in q.all() if r.start_at + timedelta(minutes=r.duration) > start]


def changed(db: Session) -> None:
    publish_after_commit(db, "reservation.changed", {})


def _open_order(db: Session, table_id: int, guests: int, name: str, phone: str | None, note: str | None, user: User):
    from app.modules.orders import service as osvc
    from app.modules.orders.schemas import OrderCreate
    if osvc.table_open_order(db, table_id):
        raise AppError("میز انتخاب‌شده در حال حاضر اشغال است", code="table_busy")
    return osvc.create_order(db, OrderCreate(type="dine_in", table_id=table_id, guests=guests, customer_name=name, customer_phone=phone, note=note), user)


def _validate(db: Session, data: ReservationIn, exclude: int | None = None) -> None:
    if data.table_id:
        tb = db.get(DiningTable, data.table_id)
        if not tb or not tb.is_active:
            raise AppError("میز انتخاب‌شده معتبر نیست")
        clash = conflicts(db, data.table_id, data.start_at, data.duration, exclude)
        if clash:
            c = clash[0]
            raise AppError(f"میز {tb.name} در این بازه برای «{c.customer_name}» ساعت {c.start_at:%H:%M} رزرو شده است", code="table_reserved")


# ------------------------------------------------------------------ reservations
@router.get("")
def day_list(day: date | None = None, db: Session = Depends(get_db), _: User = Depends(perm)):
    d = day or now().date()
    start = datetime.combine(d, datetime.min.time())
    rows = db.query(Reservation).filter(Reservation.start_at >= start, Reservation.start_at < start + timedelta(days=1)).order_by(Reservation.start_at).all()
    areas = [{"id": a.id, "name": a.name, "tables": [{"id": t.id, "name": t.name, "seats": t.seats} for t in a.tables if t.is_active]}
             for a in db.query(Area).order_by(Area.sort, Area.id).all()]
    active = [r for r in rows if r.status not in ("cancelled", "no_show")]
    return {"day": d, "items": [out(r) for r in rows], "areas": areas,
            "stats": {"count": len(active), "guests": sum(r.guests for r in active), "seated": sum(r.status in ("seated", "completed") for r in rows),
                      "no_show": sum(r.status == "no_show" for r in rows), "upcoming": sum(r.status in ("booked", "confirmed") for r in rows)}}


@router.get("/upcoming")
def upcoming(hours: int = Query(3, le=24), db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    """Next reservation per table (for badges on the POS floor plan)."""
    t = now()
    rows = (db.query(Reservation).filter(Reservation.status.in_(("booked", "confirmed")), Reservation.table_id.isnot(None),
                                         Reservation.start_at >= t - timedelta(minutes=30), Reservation.start_at <= t + timedelta(hours=hours))
            .order_by(Reservation.start_at).all())
    by_table: dict[int, dict] = {}
    for r in rows:
        by_table.setdefault(r.table_id, {"id": r.id, "name": r.customer_name, "guests": r.guests, "start_at": r.start_at,
                                         "minutes": int((r.start_at - t).total_seconds() // 60)})
    return by_table


@router.get("/availability")
def availability(start_at: LocalDateTime, guests: int = 2, duration: int = 90, exclude: int | None = None,
                 db: Session = Depends(get_db), _: User = Depends(perm)):
    res = []
    for tb in db.query(DiningTable).filter(DiningTable.is_active.is_(True)).order_by(DiningTable.area_id, DiningTable.sort).all():
        clash = conflicts(db, tb.id, start_at, duration, exclude)
        res.append({"id": tb.id, "name": tb.name, "area": tb.area.name, "seats": tb.seats, "fits": tb.seats >= guests,
                    "free": not clash, "clash": f"{clash[0].customer_name} {clash[0].start_at:%H:%M}" if clash else None})
    res.sort(key=lambda x: (not x["free"], not x["fits"], abs(x["seats"] - guests)))
    return res


@router.post("", status_code=201)
def create(data: ReservationIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    _validate(db, data)
    r = Reservation(**{**data.model_dump(), "phone": normalize_phone(data.phone) or data.phone}, status="booked", created_by=user.id)
    db.add(r)
    db.flush()
    events.emit("reservation.created", db=db, reservation=r)
    log_action(db, user, "reservation.create", f"رزرو «{r.customer_name}» {r.guests} نفر — {r.start_at:%Y-%m-%d %H:%M}" + (f" میز {r.table.name}" if r.table_id and r.table else ""), entity="reservation", entity_id=r.id)
    changed(db)
    db.commit()
    db.refresh(r)
    return out(r)


@router.put("/{rid}")
def update(rid: int, data: ReservationIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    r = get_or_404(db, Reservation, rid, "رزرو")
    if r.status in ("completed", "cancelled", "no_show"):
        raise AppError("این رزرو بسته شده و قابل ویرایش نیست")
    _validate(db, data, exclude=r.id)
    old_phone = r.phone
    for k, v in data.model_dump().items():
        setattr(r, k, v)
    r.phone = phone_update(data.phone, old_phone) or data.phone
    changed(db)
    db.commit()
    db.refresh(r)
    return out(r)


@router.post("/{rid}/status")
def set_status(rid: int, data: StatusIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    r = get_or_404(db, Reservation, rid, "رزرو")
    if data.status == "seated":
        if data.table_id:
            r.table_id = data.table_id
            db.flush()
        if not r.table_id:
            raise AppError("برای نشاندن مهمان، میز را انتخاب کنید", code="table_required")
        if data.open_order and not r.order_id:
            o = _open_order(db, r.table_id, r.guests, r.customer_name, r.phone, f"رزرو: {r.occasion or ''} {r.note or ''}".strip(), user)
            r.order_id = o.id
        r.seated_at = now()
    r.status = data.status
    log_action(db, user, "reservation.status", f"رزرو «{r.customer_name}» ← {data.status}", entity="reservation", entity_id=r.id)
    changed(db)
    db.commit()
    db.refresh(r)
    return out(r)


# ------------------------------------------------------------------ waitlist
@router.get("/waitlist")
def waitlist(db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    since = now() - timedelta(hours=12)
    rows = db.query(WaitlistEntry).filter(WaitlistEntry.created_at >= since).order_by(WaitlistEntry.id).all()
    return [wout(w) for w in rows if w.status in ("waiting", "notified")] + [wout(w) for w in rows if w.status not in ("waiting", "notified")][-10:]


@router.post("/waitlist", status_code=201)
def add_wait(data: WaitIn, db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    w = WaitlistEntry(**{**data.model_dump(), "phone": normalize_phone(data.phone) or data.phone}, status="waiting")
    db.add(w)
    changed(db)
    db.commit()
    db.refresh(w)
    return wout(w)


@router.post("/waitlist/{wid}/status")
def wait_status(wid: int, data: WaitStatusIn, db: Session = Depends(get_db), user: User = Depends(require("pos.access"))):
    w = get_or_404(db, WaitlistEntry, wid, "نوبت")
    if data.status == "notified":
        w.notified_at = now()
    if data.status == "seated":
        if not data.table_id:
            raise AppError("میز را انتخاب کنید", code="table_required")
        w.table_id = data.table_id
        if data.open_order:
            w.order_id = _open_order(db, data.table_id, w.guests, w.customer_name, w.phone, None, user).id
    if data.status in ("seated", "left"):
        w.done_at = now()
    w.status = data.status
    changed(db)
    db.commit()
    db.refresh(w)
    return wout(w)
