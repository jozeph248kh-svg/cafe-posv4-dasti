from app.core import settings_store
from app.core.modules import Module

from .router import DEFAULTS, router
from .seed import demo, seed

settings_store.register_defaults(DEFAULTS)

module = Module(
    name="reservations",
    title="رزرو میز و لیست انتظار",
    description="رزرو میز با بررسی تداخل زمانی، تقویم روزانه میزها، نشاندن مهمان و باز شدن خودکار سفارش، لیست انتظار",
    depends=["floor", "orders"],
    routers=[router],
    permissions={"reservations.manage": "مدیریت رزرو میز"},
    seed=seed,
    demo=demo,
)
