from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin
from app.modules.floor.models import DiningTable


class Reservation(Base, TimestampMixin):
    __tablename__ = "reservations"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20), index=True)
    guests: Mapped[int] = mapped_column(Integer, default=2)
    start_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    duration: Mapped[int] = mapped_column(Integer, default=90)            # minutes
    table_id: Mapped[int | None] = mapped_column(ForeignKey("dining_tables.id"), index=True)
    status: Mapped[str] = mapped_column(String(10), default="booked", index=True)   # booked|confirmed|seated|completed|no_show|cancelled
    source: Mapped[str] = mapped_column(String(10), default="phone")      # phone | walk_in | online | instagram
    occasion: Mapped[str | None] = mapped_column(String(40))             # تولد، سالگرد، جلسه کاری...
    deposit: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str | None] = mapped_column(Text)
    order_id: Mapped[int | None] = mapped_column(Integer)
    seated_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    table: Mapped[DiningTable | None] = relationship(lazy="joined")


class WaitlistEntry(Base, TimestampMixin):
    __tablename__ = "waitlist"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20))
    guests: Mapped[int] = mapped_column(Integer, default=2)
    quoted_minutes: Mapped[int] = mapped_column(Integer, default=15)
    status: Mapped[str] = mapped_column(String(10), default="waiting", index=True)  # waiting|notified|seated|left
    note: Mapped[str | None] = mapped_column(String(200))
    table_id: Mapped[int | None] = mapped_column(ForeignKey("dining_tables.id"))
    notified_at: Mapped[datetime | None] = mapped_column(DateTime)
    done_at: Mapped[datetime | None] = mapped_column(DateTime)
    order_id: Mapped[int | None] = mapped_column(Integer)
    table: Mapped[DiningTable | None] = relationship(lazy="joined")
