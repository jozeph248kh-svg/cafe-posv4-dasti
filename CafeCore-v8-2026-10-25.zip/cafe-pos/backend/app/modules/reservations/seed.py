import random
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.core.permissions import grant_once
from app.core.utils import now
from app.modules.floor.models import DiningTable

from .models import Reservation, WaitlistEntry

NAMES = ["خانواده رحمانی", "آقای توکلی", "خانم شجاعی", "دکتر معتمدی", "مهندس پارسا", "خانم وکیلی", "آقای زارعی", "خانواده نیک‌نام",
         "خانم سعیدی", "آقای قربانی", "تیم شرکت آریا", "خانم اسدی", "آقای مختاری", "خانم یگانه"]
OCC = [None, None, None, "تولد 🎂", "سالگرد ازدواج 💍", "جلسه کاری 💼", None]


def seed(db: Session) -> None:
    grant_once(db, "reservations", {"manager": ["reservations.manage"], "cashier": ["reservations.manage"], "waiter": ["reservations.manage"]})


def demo(db: Session) -> None:
    if db.query(Reservation).count():
        return
    rng = random.Random(3)
    tables = db.query(DiningTable).filter(DiningTable.is_active.is_(True)).all()
    if not tables:
        return
    t0 = now()
    today = t0.date()
    taken: dict[int, list[tuple[datetime, datetime]]] = {}

    def free(tb, s, dur):
        e = s + timedelta(minutes=dur)
        return all(e <= a or s >= b for a, b in taken.get(tb.id, []))

    for day_off in range(-3, 6):
        d = today + timedelta(days=day_off)
        for _ in range(rng.randint(4, 8) if day_off else 9):
            hour = rng.choice([12, 13, 13, 14, 19, 20, 20, 21, 21, 22])
            s = datetime.combine(d, datetime.min.time()) + timedelta(hours=hour, minutes=rng.choice([0, 15, 30, 45]))
            guests = rng.choice([2, 2, 2, 3, 4, 4, 5, 6, 8])
            dur = 120 if guests >= 5 else 90
            cands = [tb for tb in tables if tb.seats >= guests and free(tb, s, dur)]
            if not cands:
                continue
            tb = min(cands, key=lambda x: (x.seats, rng.random()))
            taken.setdefault(tb.id, []).append((s, s + timedelta(minutes=dur)))
            if s < t0 - timedelta(minutes=dur):
                status = rng.choice(["completed"] * 6 + ["no_show", "cancelled"])
            elif s < t0:
                status = "completed"
            else:
                status = rng.choice(["booked", "confirmed", "confirmed"])
            db.add(Reservation(customer_name=rng.choice(NAMES), phone=f"0912{rng.randint(1000000, 9999999)}", guests=guests, start_at=s,
                               duration=dur, table_id=tb.id, status=status, source=rng.choice(["phone", "phone", "instagram", "walk_in"]),
                               occasion=rng.choice(OCC), deposit=rng.choice([0, 0, 500_000]) if guests >= 5 else 0))
    # a reservation in 40 minutes so the POS floor shows a badge
    tb = next((x for x in tables if free(x, t0 + timedelta(minutes=40), 90)), None)
    if tb:
        db.add(Reservation(customer_name="خانم کیانی", phone="09121231234", guests=min(4, tb.seats), start_at=(t0 + timedelta(minutes=40)).replace(second=0),
                           duration=90, table_id=tb.id, status="confirmed", source="phone", occasion="تولد 🎂", note="کیک را خودشان می‌آورند"))
    for k, (n, g, q) in enumerate([("آقای صفری", 4, 20), ("خانم نوری", 2, 10)]):
        w = WaitlistEntry(customer_name=n, guests=g, quoted_minutes=q, status="waiting", phone=f"0935{k}001122")
        db.add(w)
        db.flush()
        w.created_at = t0 - timedelta(minutes=[12, 4][k])
