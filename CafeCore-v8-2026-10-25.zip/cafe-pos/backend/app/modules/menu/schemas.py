from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class StationIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    kind: str = Field("kitchen", pattern="^(kitchen|bar)$")
    color: str = "#f97316"
    sort: int = 0
    is_active: bool = True


class StationOut(ORM, StationIn):
    id: int


class CategoryIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    icon: str | None = None
    color: str = "#6366f1"
    section: str = Field("restaurant", pattern="^(cafe|restaurant)$")
    image: str | None = None
    sort: int = 0
    is_active: bool = True


class CategoryOut(ORM, CategoryIn):
    id: int
    item_count: int = 0


class OptionIn(BaseModel):
    id: int | None = None
    name: str = Field(min_length=1, max_length=60)
    price_delta: int = 0
    is_default: bool = False
    is_available: bool = True


class OptionOut(ORM):
    id: int
    name: str
    price_delta: int
    is_default: bool
    is_available: bool


class GroupIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    min_select: int = Field(0, ge=0)
    max_select: int = Field(1, ge=1)
    sort: int = 0
    options: list[OptionIn] = Field(min_length=1)


class GroupOut(ORM):
    id: int
    name: str
    min_select: int
    max_select: int
    sort: int
    options: list[OptionOut]


class ItemIn(BaseModel):
    category_id: int
    station_id: int | None = None
    name: str = Field(min_length=2, max_length=100)
    code: str | None = None
    description: str | None = None
    price: int = Field(ge=0)
    image: str | None = None
    prep_minutes: int = Field(10, ge=0)
    is_available: bool = True
    is_active: bool = True
    show_in_qr: bool = True
    tags: str | None = None
    sort: int = 0
    modifier_group_ids: list[int] = []


class ItemOut(ORM):
    id: int
    category_id: int
    station_id: int | None
    name: str
    code: str | None
    description: str | None
    price: int
    image: str | None
    prep_minutes: int
    is_available: bool
    is_active: bool
    show_in_qr: bool
    tags: str | None
    sort: int
    modifier_group_ids: list[int] = []
