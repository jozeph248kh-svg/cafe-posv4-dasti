from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Table, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin

item_modifier_groups = Table(
    "menu_item_modifier_groups",
    Base.metadata,
    Column("item_id", ForeignKey("menu_items.id", ondelete="CASCADE"), primary_key=True),
    Column("group_id", ForeignKey("modifier_groups.id", ondelete="CASCADE"), primary_key=True),
)


class Station(Base):
    """Preparation station: hot kitchen, cold kitchen, coffee bar, dessert..."""
    __tablename__ = "stations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    kind: Mapped[str] = mapped_column(String(20), default="kitchen")     # kitchen | bar
    color: Mapped[str] = mapped_column(String(20), default="#f97316")
    sort: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class MenuCategory(Base):
    __tablename__ = "menu_categories"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    icon: Mapped[str | None] = mapped_column(String(10))          # emoji
    color: Mapped[str] = mapped_column(String(20), default="#6366f1")
    section: Mapped[str] = mapped_column(String(20), default="restaurant")   # cafe | restaurant
    image: Mapped[str | None] = mapped_column(String(200))
    sort: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    items: Mapped[list["MenuItem"]] = relationship(back_populates="category", order_by="[MenuItem.sort, MenuItem.id]")


class ModifierGroup(Base):
    __tablename__ = "modifier_groups"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    min_select: Mapped[int] = mapped_column(Integer, default=0)
    max_select: Mapped[int] = mapped_column(Integer, default=1)
    sort: Mapped[int] = mapped_column(Integer, default=0)
    options: Mapped[list["ModifierOption"]] = relationship(
        back_populates="group", cascade="all, delete-orphan", order_by=lambda: (ModifierOption.sort, ModifierOption.id))


class ModifierOption(Base):
    __tablename__ = "modifier_options"
    id: Mapped[int] = mapped_column(primary_key=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("modifier_groups.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(60))
    price_delta: Mapped[int] = mapped_column(Integer, default=0)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    sort: Mapped[int] = mapped_column(Integer, default=0)
    group: Mapped[ModifierGroup] = relationship(back_populates="options")


class MenuItem(Base, TimestampMixin):
    __tablename__ = "menu_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("menu_categories.id"))
    station_id: Mapped[int | None] = mapped_column(ForeignKey("stations.id"))
    name: Mapped[str] = mapped_column(String(100))
    code: Mapped[str | None] = mapped_column(String(20), index=True)       # quick code for cashiers
    description: Mapped[str | None] = mapped_column(Text)
    price: Mapped[int] = mapped_column(Integer)
    image: Mapped[str | None] = mapped_column(String(200))
    prep_minutes: Mapped[int] = mapped_column(Integer, default=10)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)   # temporarily out of stock
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)      # shown at all
    show_in_qr: Mapped[bool] = mapped_column(Boolean, default=True)
    tags: Mapped[str | None] = mapped_column(String(100))               # e.g. "ویژه,گیاهی"
    sort: Mapped[int] = mapped_column(Integer, default=0)

    category: Mapped[MenuCategory] = relationship(back_populates="items")
    station: Mapped[Station | None] = relationship()
    modifier_groups: Mapped[list[ModifierGroup]] = relationship(secondary=item_modifier_groups, order_by=[ModifierGroup.sort, ModifierGroup.id])
