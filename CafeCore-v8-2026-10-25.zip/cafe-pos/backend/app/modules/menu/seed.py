"""Starter menu for a cafe-restaurant. Edit freely from the admin panel."""
from sqlalchemy.orm import Session

from .models import MenuCategory, MenuItem, ModifierGroup, ModifierOption, Station

GROUPS = {
    "size": ("سایز", 1, 1, [("معمولی", 0, True), ("بزرگ", 40_000, False)]),
    "milk": ("نوع شیر", 1, 1, [("شیر معمولی", 0, True), ("شیر بادام", 50_000, False), ("شیر سویا", 40_000, False), ("بدون لاکتوز", 30_000, False)]),
    "shot": ("شات اضافه", 0, 1, [("یک شات اضافه", 50_000, False)]),
    "syrup": ("سیروپ", 0, 2, [("کارامل", 30_000, False), ("وانیل", 30_000, False), ("فندق", 30_000, False)]),
    "sugar": ("شکر", 0, 1, [("بدون شکر", 0, False), ("کم‌شیرین", 0, False), ("شیرین", 0, False)]),
    "doneness": ("درجه پخت", 1, 1, [("مدیوم رر", 0, False), ("مدیوم", 0, True), ("مدیوم ول", 0, False), ("ول دان", 0, False)]),
    "sauce": ("سس استیک", 0, 1, [("سس قارچ", 0, False), ("سس فلفل", 0, False), ("سس باربیکیو", 0, False)]),
    "side": ("دورچین", 1, 1, [("سیب‌زمینی سرخ‌کرده", 0, True), ("پوره سیب‌زمینی", 0, False), ("سبزیجات گریل", 20_000, False)]),
    "burger": ("افزودنی برگر", 0, 4, [("پنیر چدار اضافه", 60_000, False), ("قارچ", 50_000, False), ("بیکن گوشت", 90_000, False), ("تخم‌مرغ", 40_000, False)]),
    "crust": ("نوع خمیر", 1, 1, [("خمیر نازک ایتالیایی", 0, True), ("خمیر ضخیم آمریکایی", 30_000, False)]),
}

STATIONS = [("بار قهوه", "bar", "#8b5a2b"), ("آشپزخانه گرم", "kitchen", "#ef4444"), ("سرد و دسر", "kitchen", "#0ea5e9")]

# (category, icon, color, section, station_idx, [(name, code, price, minutes, [groups], description)])
MENU = [
    ("قهوه گرم", "☕", "#92400e", "cafe", 0, [
        ("اسپرسو", "101", 140_000, 3, ["shot", "sugar"], "۱۸ گرم قهوه عربیکا، عصاره‌گیری دوبل"),
        ("آمریکانو", "102", 150_000, 3, ["size", "shot", "sugar"], "اسپرسو دوبل با آب داغ"),
        ("کاپوچینو", "103", 180_000, 4, ["size", "milk", "shot", "syrup"], "اسپرسو با فوم ضخیم شیر"),
        ("لاته", "104", 190_000, 4, ["size", "milk", "shot", "syrup"], "اسپرسو و شیر بخارخورده با لایه نازک فوم"),
        ("موکا", "105", 220_000, 5, ["size", "milk", "shot"], "اسپرسو، شکلات تلخ و شیر"),
        ("کارامل ماکیاتو", "106", 230_000, 5, ["size", "milk", "shot"], "وانیل، شیر، اسپرسو و سس کارامل"),
        ("هات چاکلت", "107", 200_000, 4, ["size", "milk"], "شکلات بلژیکی و شیر داغ"),
        ("چای ماسالا", "108", 170_000, 5, ["milk", "sugar"], "چای سیاه با ادویه‌های هندی و شیر"),
    ]),
    ("نوشیدنی سرد", "🧊", "#0891b2", "cafe", 0, [
        ("آیس آمریکانو", "201", 170_000, 3, ["shot", "sugar"], None),
        ("آیس لاته", "202", 210_000, 4, ["milk", "shot", "syrup"], None),
        ("موهیتو", "203", 220_000, 5, ["sugar"], "لیمو، نعناع تازه و سودا"),
        ("لیموناد خانگی", "204", 180_000, 4, ["sugar"], None),
        ("اسموتی توت‌فرنگی و موز", "205", 260_000, 5, [], None),
        ("شیک شکلات", "206", 280_000, 5, [], "بستنی وانیلی، شکلات و شیر"),
    ]),
    ("صبحانه", "🍳", "#f59e0b", "restaurant", 1, [
        ("املت ایرانی", "301", 280_000, 12, [], "گوجه، تخم‌مرغ محلی، نان تازه"),
        ("صبحانه انگلیسی", "302", 460_000, 15, [], "تخم‌مرغ، سوسیس، لوبیا، قارچ، نان تست"),
        ("پنکیک با سیروپ افرا", "303", 320_000, 12, [], None),
        ("شکشوکا", "304", 340_000, 15, [], None),
    ]),
    ("پیش‌غذا", "🍟", "#ea580c", "restaurant", 1, [
        ("سیب‌زمینی سرخ‌کرده", "401", 220_000, 8, [], None),
        ("سیب‌زمینی ویژه با پنیر و قارچ", "402", 320_000, 10, [], None),
        ("نان سیر", "403", 180_000, 7, [], None),
        ("سوپ روز", "404", 200_000, 5, [], None),
        ("بال کبابی تند", "405", 380_000, 15, [], None),
    ]),
    ("سالاد", "🥗", "#16a34a", "restaurant", 2, [
        ("سالاد سزار مرغ", "501", 420_000, 10, [], "کاهو رسمی، مرغ گریل، پارمزان، کروتان"),
        ("سالاد یونانی", "502", 360_000, 8, [], "خیار، گوجه، زیتون، پنیر فتا"),
    ]),
    ("پاستا", "🍝", "#d97706", "restaurant", 1, [
        ("فتوچینی آلفردو", "601", 520_000, 15, [], "سس خامه، قارچ و مرغ"),
        ("اسپاگتی بولونز", "602", 490_000, 15, [], None),
        ("پنه آرابیاتا", "603", 420_000, 14, [], "سس گوجه تند و ریحان"),
    ]),
    ("پیتزا", "🍕", "#dc2626", "restaurant", 1, [
        ("پیتزا مارگاریتا", "701", 480_000, 15, ["crust"], None),
        ("پیتزا پپرونی", "702", 620_000, 15, ["crust"], None),
        ("پیتزا مخصوص", "703", 720_000, 18, ["crust"], "گوشت، مرغ، قارچ و فلفل دلمه"),
    ]),
    ("غذای اصلی", "🥩", "#7c3aed", "restaurant", 1, [
        ("استیک فیله", "801", 1_250_000, 25, ["doneness", "sauce", "side"], "۲۵۰ گرم فیله گوساله"),
        ("برگر کلاسیک", "802", 520_000, 15, ["doneness", "burger", "side"], "۱۸۰ گرم گوشت خالص"),
        ("چیزبرگر دوبل", "803", 690_000, 18, ["doneness", "burger", "side"], None),
        ("مرغ گریل با سس لیمو", "804", 560_000, 20, ["side"], None),
        ("شنیسل مرغ", "805", 590_000, 18, ["side"], None),
    ]),
    ("دسر و کیک", "🍰", "#db2777", "cafe", 2, [
        ("چیزکیک نیویورکی", "901", 240_000, 2, [], None),
        ("کیک شکلات خیس", "902", 220_000, 2, [], None),
        ("تیرامیسو", "903", 260_000, 2, [], None),
        ("بستنی سه اسکوپ", "904", 160_000, 3, [], None),
    ]),
]


def seed(db: Session) -> None:
    if db.query(MenuCategory).count():
        return
    stations = []
    for i, (name, kind, color) in enumerate(STATIONS):
        s = Station(name=name, kind=kind, color=color, sort=i)
        db.add(s)
        stations.append(s)
    groups = {}
    for i, (key, (name, mn, mx, opts)) in enumerate(GROUPS.items()):
        g = ModifierGroup(name=name, min_select=mn, max_select=mx, sort=i)
        g.options = [ModifierOption(name=n, price_delta=p, is_default=d, sort=j) for j, (n, p, d) in enumerate(opts)]
        db.add(g)
        groups[key] = g
    db.flush()
    for ci, (cname, icon, color, section, st, items) in enumerate(MENU):
        cat = MenuCategory(name=cname, icon=icon, color=color, section=section, sort=ci)
        db.add(cat)
        db.flush()
        for ii, (name, code, price, minutes, gkeys, desc) in enumerate(items):
            db.add(MenuItem(
                category_id=cat.id, station_id=stations[st].id, name=name, code=code,
                price=price, prep_minutes=minutes, description=desc, sort=ii,
                modifier_groups=[groups[k] for k in gkeys],
                tags="پرفروش" if code in ("104", "702", "801", "901") else None,
            ))
