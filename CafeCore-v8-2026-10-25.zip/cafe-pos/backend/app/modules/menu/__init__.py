from app.core.modules import Module

from .router import router
from .seed import seed

module = Module(
    name="menu",
    title="منو",
    description="دسته‌بندی‌ها، آیتم‌ها، گزینه‌های سفارشی (مدیفایر) و ایستگاه‌های آماده‌سازی",
    depends=["system"],
    routers=[router],
    permissions={"menu.manage": "مدیریت منو و قیمت‌ها"},
    seed=seed,
)
