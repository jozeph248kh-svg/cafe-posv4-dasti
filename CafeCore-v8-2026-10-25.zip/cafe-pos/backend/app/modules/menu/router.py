from fastapi import APIRouter, Depends
from sqlalchemy import func, or_
from sqlalchemy.orm import Session, selectinload

from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit

from .models import MenuCategory, MenuItem, ModifierGroup, ModifierOption, Station
from .schemas import (
    CategoryIn,
    CategoryOut,
    GroupIn,
    GroupOut,
    ItemIn,
    ItemOut,
    StationIn,
    StationOut,
)

router = APIRouter()
manage = require("menu.manage")


def changed(db: Session) -> None:
    publish_after_commit(db, "menu.changed")


# ---------------------------------------------------------------- full menu (POS)
@router.get("/full")
def full_menu(db: Session = Depends(get_db), _: User = Depends(current_user)):
    """Everything the POS needs in one request."""
    cats = db.query(MenuCategory).filter(MenuCategory.is_active.is_(True)).order_by(MenuCategory.sort, MenuCategory.id).all()
    items = (db.query(MenuItem).options(selectinload(MenuItem.modifier_groups))
             .filter(MenuItem.is_active.is_(True)).order_by(MenuItem.sort, MenuItem.id).all())
    groups = db.query(ModifierGroup).options(selectinload(ModifierGroup.options)).all()
    return {
        "categories": [CategoryOut.model_validate(c) for c in cats],
        "items": [item_out(i) for i in items],
        "modifier_groups": [GroupOut.model_validate(g) for g in groups],
        "stations": [StationOut.model_validate(s) for s in db.query(Station).order_by(Station.sort, Station.id).all()],
    }


# ---------------------------------------------------------------- stations
@router.get("/stations", response_model=list[StationOut])
def list_stations(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return db.query(Station).order_by(Station.sort, Station.id).all()


@router.post("/stations", response_model=StationOut, status_code=201)
def create_station(data: StationIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    st = Station(**data.model_dump())
    db.add(st)
    db.commit()
    return st


@router.put("/stations/{sid}", response_model=StationOut)
def update_station(sid: int, data: StationIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    st = get_or_404(db, Station, sid, "ایستگاه")
    for k, v in data.model_dump().items():
        setattr(st, k, v)
    db.commit()
    return st


@router.delete("/stations/{sid}", status_code=204)
def delete_station(sid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    st = get_or_404(db, Station, sid, "ایستگاه")
    if db.query(MenuItem).filter(MenuItem.station_id == sid).count():
        raise AppError("آیتم‌هایی به این ایستگاه متصل هستند؛ ابتدا آن‌ها را منتقل کنید")
    db.delete(st)
    db.commit()


# ---------------------------------------------------------------- categories
@router.get("/categories", response_model=list[CategoryOut])
def list_categories(db: Session = Depends(get_db), _: User = Depends(current_user)):
    counts = dict(db.query(MenuItem.category_id, func.count()).group_by(MenuItem.category_id).all())
    out = []
    for c in db.query(MenuCategory).filter(MenuCategory.section != "system").order_by(MenuCategory.sort, MenuCategory.id).all():
        o = CategoryOut.model_validate(c)
        o.item_count = counts.get(c.id, 0)
        out.append(o)
    return out


@router.post("/categories", response_model=CategoryOut, status_code=201)
def create_category(data: CategoryIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    c = MenuCategory(**data.model_dump())
    db.add(c)
    log_action(db, user, "menu.category.create", f"ایجاد دسته «{c.name}»", entity="category")
    changed(db)
    db.commit()
    return c


@router.put("/categories/{cid}", response_model=CategoryOut)
def update_category(cid: int, data: CategoryIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = get_or_404(db, MenuCategory, cid, "دسته‌بندی")
    for k, v in data.model_dump().items():
        setattr(c, k, v)
    changed(db)
    db.commit()
    return c


@router.post("/categories/reorder", status_code=204)
def reorder_categories(ids: list[int], db: Session = Depends(get_db), _: User = Depends(manage)):
    for i, cid in enumerate(ids):
        c = db.get(MenuCategory, cid)
        if c:
            c.sort = i
    changed(db)
    db.commit()


@router.delete("/categories/{cid}", status_code=204)
def delete_category(cid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    c = get_or_404(db, MenuCategory, cid, "دسته‌بندی")
    if db.query(MenuItem).filter(MenuItem.category_id == cid).count():
        raise AppError("این دسته دارای آیتم است؛ ابتدا آیتم‌ها را حذف یا منتقل کنید")
    db.delete(c)
    log_action(db, user, "menu.category.delete", f"حذف دسته «{c.name}»", entity="category")
    changed(db)
    db.commit()


# ---------------------------------------------------------------- modifier groups
@router.get("/modifier-groups", response_model=list[GroupOut])
def list_groups(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return db.query(ModifierGroup).options(selectinload(ModifierGroup.options)).order_by(ModifierGroup.sort, ModifierGroup.id).all()


def _apply_group(g: ModifierGroup, data: GroupIn) -> None:
    if data.min_select > data.max_select:
        raise AppError("حداقل انتخاب نمی‌تواند بیشتر از حداکثر باشد")
    g.name, g.min_select, g.max_select, g.sort = data.name, data.min_select, data.max_select, data.sort
    existing = {o.id: o for o in g.options}
    keep = []
    for i, od in enumerate(data.options):
        o = existing.get(od.id) if od.id else None
        if not o:
            o = ModifierOption()
            g.options.append(o)
        o.name, o.price_delta, o.is_default, o.is_available, o.sort = od.name, od.price_delta, od.is_default, od.is_available, i
        keep.append(o)
    for o in list(g.options):
        if o not in keep:
            g.options.remove(o)


@router.post("/modifier-groups", response_model=GroupOut, status_code=201)
def create_group(data: GroupIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    g = ModifierGroup()
    _apply_group(g, data)
    db.add(g)
    changed(db)
    db.commit()
    return g


@router.put("/modifier-groups/{gid}", response_model=GroupOut)
def update_group(gid: int, data: GroupIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    g = get_or_404(db, ModifierGroup, gid, "گروه گزینه")
    _apply_group(g, data)
    changed(db)
    db.commit()
    return g


@router.delete("/modifier-groups/{gid}", status_code=204)
def delete_group(gid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    db.delete(get_or_404(db, ModifierGroup, gid, "گروه گزینه"))
    changed(db)
    db.commit()


# ---------------------------------------------------------------- items
def item_out(i: MenuItem) -> ItemOut:
    o = ItemOut.model_validate(i)
    o.modifier_group_ids = [g.id for g in i.modifier_groups]
    return o


@router.get("/items", response_model=list[ItemOut])
def list_items(db: Session = Depends(get_db), _: User = Depends(current_user)):
    items = (db.query(MenuItem).options(selectinload(MenuItem.modifier_groups))
             .filter(or_(MenuItem.code.is_(None), ~MenuItem.code.startswith("__", autoescape=True)))   # hide system items (e.g. delivery fee); "_" is a LIKE wildcard
             .order_by(MenuItem.category_id, MenuItem.sort, MenuItem.id))
    return [item_out(i) for i in items.all()]


def _apply_item(db: Session, it: MenuItem, data: ItemIn) -> None:
    get_or_404(db, MenuCategory, data.category_id, "دسته‌بندی")
    if data.code:
        dup = db.query(MenuItem).filter(MenuItem.code == data.code, MenuItem.id != (it.id or 0)).first()
        if dup:
            raise AppError(f"کد «{data.code}» قبلاً برای «{dup.name}» استفاده شده است")
    for k, v in data.model_dump(exclude={"modifier_group_ids"}).items():
        setattr(it, k, v)
    it.modifier_groups = db.query(ModifierGroup).filter(ModifierGroup.id.in_(data.modifier_group_ids)).all() if data.modifier_group_ids else []


@router.post("/items", response_model=ItemOut, status_code=201)
def create_item(data: ItemIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    it = MenuItem()
    _apply_item(db, it, data)
    db.add(it)
    log_action(db, user, "menu.item.create", f"ایجاد آیتم «{it.name}» با قیمت {it.price:,}", entity="menu_item")
    changed(db)
    db.commit()
    return item_out(it)


@router.put("/items/{iid}", response_model=ItemOut)
def update_item(iid: int, data: ItemIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    it = get_or_404(db, MenuItem, iid, "آیتم")
    old_price = it.price
    _apply_item(db, it, data)
    if old_price != it.price:
        log_action(db, user, "menu.item.price", f"تغییر قیمت «{it.name}» از {old_price:,} به {it.price:,}",
                   entity="menu_item", entity_id=it.id, details={"old": old_price, "new": it.price})
    changed(db)
    db.commit()
    return item_out(it)


@router.patch("/items/{iid}/availability", response_model=ItemOut)
def toggle_availability(iid: int, available: bool, db: Session = Depends(get_db), user: User = Depends(require("pos.access"))):
    """Quick "86" from POS/kitchen: mark an item as temporarily unavailable."""
    it = get_or_404(db, MenuItem, iid, "آیتم")
    it.is_available = available
    log_action(db, user, "menu.item.availability", f"«{it.name}» {'موجود' if available else 'ناموجود'} شد", entity="menu_item", entity_id=it.id)
    changed(db)
    db.commit()
    return item_out(it)


@router.delete("/items/{iid}", status_code=204)
def delete_item(iid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    it = get_or_404(db, MenuItem, iid, "آیتم")
    # keep history intact: items referenced by orders are deactivated instead of deleted
    it.is_active = False
    log_action(db, user, "menu.item.delete", f"حذف آیتم «{it.name}»", entity="menu_item", entity_id=it.id)
    changed(db)
    db.commit()
