from app.core import settings_store
from app.core.modules import Module

from .router import router
from .seed import demo, seed

# insurance_pct: employer share added to insured staff (Iran: 20% employer + 3% unemployment = 23% of the insured wage)
settings_store.register_defaults({"timeclock.max_hours": 16, "timeclock.insurance_pct": 23},
                                 ranges={"timeclock.max_hours": (4, 24), "timeclock.insurance_pct": (0, 50)})

module = Module(
    name="timeclock",
    title="حضور و غیاب",
    description="ثبت ورود و خروج پرسنل با کد شخصی، اصلاح دستی توسط مدیر، نرخ ساعتی و گزارش هزینه نیرو در برابر فروش",
    depends=["staff", "orders"],
    routers=[router],
    permissions={"timeclock.manage": "مدیریت حضور و غیاب و گزارش هزینه نیرو"},
    seed=seed,
    demo=demo,
)
