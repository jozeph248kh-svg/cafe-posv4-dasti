from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, false, text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


class TimeEntry(Base, TimestampMixin):
    """One attendance interval: clock-in → clock-out (NULL while the person is still on the clock)."""
    __tablename__ = "time_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    clock_in: Mapped[datetime] = mapped_column(DateTime, index=True)
    clock_out: Mapped[datetime | None] = mapped_column(DateTime)
    business_date: Mapped[date] = mapped_column(Date, index=True)
    source: Mapped[str] = mapped_column(String(10), default="pin")        # pin | self | manual
    note: Mapped[str | None] = mapped_column(String(200))
    edited_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class StaffWage(Base, TimestampMixin):
    """Labour cost of a staff member used by the labour-vs-sales report (TOMAN): either an hourly rate (cost follows the
    clocked hours) or a fixed monthly salary (spread evenly: salary ÷ 30 per calendar day, worked or not). If
    `insured`, the employer's insurance share (setting timeclock.insurance_pct) is added on top."""
    __tablename__ = "staff_wages"
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    hourly_wage: Mapped[int] = mapped_column(Integer, default=0)
    pay_type: Mapped[str] = mapped_column(String(10), default="hourly", server_default=text("'hourly'"))   # hourly | monthly
    monthly_salary: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    insured: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())
