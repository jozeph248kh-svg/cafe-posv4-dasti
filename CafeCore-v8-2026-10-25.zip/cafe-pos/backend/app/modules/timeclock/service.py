"""Time clock: punches, worked minutes and the labour-vs-sales report."""
from collections import defaultdict
from datetime import date, datetime, timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import events, settings_store
from app.core.errors import AppError
from app.core.models import Role, User
from app.core.utils import business_day, now

from .models import StaffWage, TimeEntry

DOUBLE_TAP_SEC = 60


def max_hours(db: Session) -> int:
    return int(settings_store.get(db, "timeclock.max_hours", 16) or 16)


def open_entry(db: Session, user_id: int) -> TimeEntry | None:
    return (db.query(TimeEntry).filter(TimeEntry.user_id == user_id, TimeEntry.clock_out.is_(None))
            .order_by(TimeEntry.clock_in.desc()).first())


def end_of(e: TimeEntry, limit_h: int, at: datetime | None = None) -> datetime:
    """Effective end: the clock-out, or (still open) now — capped so a forgotten clock-out can't count for days."""
    if e.clock_out:
        return e.clock_out
    return min(at or now(), e.clock_in + timedelta(hours=limit_h))


def minutes_of(e: TimeEntry, limit_h: int, at: datetime | None = None) -> int:
    return max(0, int((end_of(e, limit_h, at) - e.clock_in).total_seconds() // 60))


def punch(db: Session, user: User, source: str) -> dict:
    """Toggle: clock in when off the clock, otherwise clock out. A second tap within a minute is refused."""
    t = now()
    e = open_entry(db, user.id)
    if e:
        if (t - e.clock_in).total_seconds() < DOUBLE_TAP_SEC:
            raise AppError("ورود شما همین الان ثبت شد", code="punch_too_soon")
        events.emit("timeclock.clocking_out", db=db, user=user, entry=e)   # shifts: report + drawer hand-over first
        e.clock_out = t
        return {"action": "out", "name": user.full_name, "at": t, "minutes": minutes_of(e, max_hours(db), t),
                "over_limit": (t - e.clock_in) > timedelta(hours=max_hours(db))}
    last = db.query(func.max(TimeEntry.clock_out)).filter(TimeEntry.user_id == user.id).scalar()
    if last and (t - last).total_seconds() < DOUBLE_TAP_SEC:
        raise AppError("خروج شما همین الان ثبت شد", code="punch_too_soon")
    db.add(TimeEntry(user_id=user.id, clock_in=t, business_date=business_day(t, settings_store.get(db, "day.cutoff_hour", 5)),
                     source=source))
    return {"action": "in", "name": user.full_name, "at": t, "minutes": 0, "over_limit": False}


def status_of(db: Session, user: User) -> dict:
    e = open_entry(db, user.id)
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    lim = max_hours(db)
    done = sum(minutes_of(x, lim) for x in db.query(TimeEntry).filter(TimeEntry.user_id == user.id, TimeEntry.business_date == today))
    return {"on_clock": bool(e), "since": e.clock_in if e else None, "today_minutes": done}


def entry_out(e: TimeEntry, users: dict, lim: int) -> dict:
    return {"id": e.id, "user_id": e.user_id, "name": users.get(e.user_id, "—"), "clock_in": e.clock_in, "clock_out": e.clock_out,
            "business_date": e.business_date, "source": e.source, "note": e.note, "edited_by": e.edited_by,
            "minutes": minutes_of(e, lim), "forgotten": e.clock_out is None and now() - e.clock_in > timedelta(hours=lim)}


def wages(db: Session) -> dict[int, int]:
    return {w.user_id: w.hourly_wage for w in db.query(StaffWage).all()}


def insurance_pct(db: Session) -> float:
    return float(settings_store.get(db, "timeclock.insurance_pct", 23) or 0)


def has_pay(w: StaffWage | None) -> bool:
    return bool(w and (w.monthly_salary if w.pay_type == "monthly" else w.hourly_wage))


def labor(db: Session, d1: date, d2: date) -> dict:
    """Labour hours and cost against net sales (subtotal − discounts, excl. service and tax) for business days d1..d2."""
    from app.modules.orders.models import Order                               # orders is a dependency of this module

    lim = max_hours(db)
    at = now()
    users = {u.id: (u.full_name, u.role_id) for u in db.query(User.id, User.full_name, User.role_id).all()}
    roles = {r.id: r.title for r in db.query(Role.id, Role.title).all()}
    pay = {w.user_id: w for w in db.query(StaffWage).all()}
    ins = insurance_pct(db) / 100
    factor = {uid: (1 + ins) if w.insured else 1.0 for uid, w in pay.items()}
    rate = {uid: w.hourly_wage * factor[uid] for uid, w in pay.items() if w.pay_type != "monthly"}
    active = {uid for (uid,) in db.query(User.id).filter(User.is_active.is_(True))}
    entries = db.query(TimeEntry).filter(TimeEntry.business_date >= d1, TimeEntry.business_date <= d2).all()
    orders = (db.query(Order.business_date, Order.created_at, Order.waiter_id, Order.subtotal, Order.discount_amount)
              .filter(Order.business_date >= d1, Order.business_date <= d2, Order.status == "closed").all())

    by_day = defaultdict(lambda: {"minutes": 0, "cost": 0.0, "sales": 0, "staff": set()})
    by_hour = defaultdict(lambda: {"minutes": 0.0, "sales": 0})
    by_staff = defaultdict(lambda: {"minutes": 0, "cost": 0.0, "entries": 0, "days": set(), "sales": 0})
    forgotten = 0
    for e in entries:
        m = minutes_of(e, lim, at)
        c = m / 60 * rate.get(e.user_id, 0)
        d = by_day[e.business_date]
        d["minutes"] += m
        d["cost"] += c
        d["staff"].add(e.user_id)
        s = by_staff[e.user_id]
        s["minutes"] += m
        s["cost"] += c
        s["entries"] += 1
        s["days"].add(e.business_date)
        forgotten += e.clock_out is None and at - e.clock_in > timedelta(hours=lim)
        # spread the interval over clock hours (hour-of-day profile)
        t, end = e.clock_in, end_of(e, lim, at)
        while t < end:
            nxt = min(end, t.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))
            by_hour[t.hour]["minutes"] += (nxt - t).total_seconds() / 60
            t = nxt
    # monthly salaries: a fixed cost per calendar day (salary ÷ 30), up to today — whether or not the person clocked in
    last = min(d2, business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5)))
    for uid, w in pay.items():
        if w.pay_type != "monthly" or not w.monthly_salary or uid not in active:
            continue
        per_day = w.monthly_salary / 30 * factor[uid]
        cur = d1
        while cur <= last:
            by_day[cur]["cost"] += per_day
            by_staff[uid]["cost"] += per_day
            cur += timedelta(days=1)
    for o in orders:
        net = (o.subtotal or 0) - (o.discount_amount or 0)
        by_day[o.business_date]["sales"] += net
        by_hour[o.created_at.hour]["sales"] += net
        if o.waiter_id in by_staff:
            by_staff[o.waiter_id]["sales"] += net

    def ratios(minutes: float, cost: float, sales: int) -> dict:
        hours = minutes / 60
        return {"hours": round(hours, 2), "cost": round(cost), "sales": sales,
                "labor_pct": round(cost * 100 / sales, 1) if sales else None,
                "splh": round(sales / hours) if hours else None}

    total_min = sum(d["minutes"] for d in by_day.values())
    total_cost = sum(d["cost"] for d in by_day.values())
    total_sales = sum(d["sales"] for d in by_day.values())
    days = []
    cur = d1
    while cur <= d2:
        d = by_day.get(cur)
        if d:
            days.append({"date": cur, "staff": len(d["staff"]), **ratios(d["minutes"], d["cost"], d["sales"])})
        cur += timedelta(days=1)
    n_days = max(1, (d2 - d1).days + 1)
    hours = [{"hour": h, "avg_staff": round(by_hour[h]["minutes"] / 60 / n_days, 2), **ratios(by_hour[h]["minutes"], 0, by_hour[h]["sales"])}
             for h in range(24) if by_hour[h]["minutes"] or by_hour[h]["sales"]]
    for h in hours:
        h.pop("cost"), h.pop("labor_pct")
    staff = []
    for uid, s in by_staff.items():
        name, role_id = users.get(uid, ("—", None))
        w = pay.get(uid)
        staff.append({"user_id": uid, "name": name, "role": roles.get(role_id, ""), "wage": w.hourly_wage if w else 0,
                      "pay_type": w.pay_type if w else "hourly", "monthly_salary": w.monthly_salary if w else 0,
                      "insured": bool(w and w.insured), "has_pay": has_pay(w), "entries": s["entries"],
                      "days": len(s["days"]), **ratios(s["minutes"], s["cost"], s["sales"])})
    staff.sort(key=lambda r: -r["hours"])
    no_wage = [r["name"] for r in staff if not r["has_pay"]]
    return {"date_from": d1, "date_to": d2, "totals": {**ratios(total_min, total_cost, total_sales), "entries": len(entries),
                                                       "forgotten": forgotten, "no_wage": no_wage, "max_hours": lim,
                                                       "insurance_pct": round(ins * 100, 2)},
            "days": days, "hours": hours, "staff": staff}
