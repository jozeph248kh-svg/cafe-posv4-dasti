import random
from datetime import datetime, time, timedelta

from sqlalchemy.orm import Session

from app.core.models import Role, User
from app.core.permissions import grant_once
from app.core.utils import business_day

from .models import StaffWage, TimeEntry

DEMO_WAGES = {"manager": 180_000, "cashier": 110_000, "waiter": 95_000, "kitchen": 130_000}


def seed(db: Session) -> None:
    grant_once(db, "timeclock", {"manager": ["timeclock.manage"]})


def demo(db: Session) -> None:
    """Two weeks of plausible attendance for the sample staff, with hourly wages."""
    if db.query(TimeEntry).count():
        return
    rng = random.Random(41)
    staff = (db.query(User, Role.name).join(Role, Role.id == User.role_id)
             .filter(User.is_active.is_(True), Role.name.in_(list(DEMO_WAGES))).all())
    today = business_day()
    for u, role in staff:
        if not db.get(StaffWage, u.id):
            db.add(StaffWage(user_id=u.id, hourly_wage=DEMO_WAGES[role]))
        for back in range(14, 0, -1):
            day = today - timedelta(days=back)
            if rng.random() < 0.15:                       # day off
                continue
            start = datetime.combine(day, time(rng.choice([9, 10, 11, 15, 16]), rng.randint(0, 25)))
            end = start + timedelta(hours=rng.choice([6, 7, 8, 8, 9]), minutes=rng.randint(0, 40))
            db.add(TimeEntry(user_id=u.id, clock_in=start, clock_out=end, business_date=day, source="pin"))
