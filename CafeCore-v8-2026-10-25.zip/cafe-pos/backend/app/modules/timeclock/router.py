from datetime import date, datetime, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import ratelimit, settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User
from app.core.security import hash_pin
from app.core.utils import LocalDateTime, business_day, now

from . import service as S
from .models import StaffWage, TimeEntry

router = APIRouter()
manage = require("timeclock.manage")


class PunchIn(BaseModel):
    pin: str = Field(min_length=4, max_length=8, pattern=r"^\d+$")


class EntryIn(BaseModel):
    user_id: int
    clock_in: LocalDateTime
    clock_out: LocalDateTime | None = None
    note: str | None = Field(None, max_length=200)


class WageIn(BaseModel):
    user_id: int
    hourly_wage: int = Field(ge=0, le=100_000_000)
    pay_type: Literal["hourly", "monthly"] | None = None          # None = keep (older clients)
    monthly_salary: int | None = Field(None, ge=0, le=10_000_000_000)
    insured: bool | None = None


class ConfigIn(BaseModel):
    insurance_pct: float = Field(ge=0, le=50)


def _users(db: Session) -> dict[int, str]:
    return {u.id: u.full_name for u in db.query(User.id, User.full_name).all()}


def _range(db: Session, date_from: date | None, date_to: date | None) -> tuple[date, date]:
    d2 = date_to or business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    d1 = date_from or d2
    if d1 > d2:
        raise AppError("تاریخ شروع بعد از تاریخ پایان است")
    if (d2 - d1).days > 366:
        raise AppError("بازه گزارش حداکثر یک سال است")
    return d1, d2


# ---------------------------------------------------------------- punching
@router.post("/punch")
def punch_with_pin(data: PunchIn, request: Request, db: Session = Depends(get_db)):
    """Shared terminal (login screen): staff clock in/out with their personal PIN — no session is opened."""
    keys = (f"pin-ip:{ratelimit.client_ip(request)}",)
    ratelimit.check(*keys)
    user = db.query(User).filter(User.pin_hash == hash_pin(data.pin)).first()
    if not user or not user.is_active:
        ratelimit.fail(*keys)
        raise AppError("کد شخصی اشتباه است", status.HTTP_401_UNAUTHORIZED, "bad_pin")
    ratelimit.success(*keys)
    out = S.punch(db, user, "pin")
    db.commit()
    return out


@router.get("/me")
def my_status(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return S.status_of(db, user)


@router.post("/me/punch")
def my_punch(db: Session = Depends(get_db), user: User = Depends(current_user)):
    out = S.punch(db, user, "self")
    db.commit()
    return {**out, **S.status_of(db, user)}


# ---------------------------------------------------------------- management
@router.get("/now")
def on_clock(db: Session = Depends(get_db), _: User = Depends(manage)):
    users, lim = _users(db), S.max_hours(db)
    rows = db.query(TimeEntry).filter(TimeEntry.clock_out.is_(None)).order_by(TimeEntry.clock_in).all()
    return [S.entry_out(e, users, lim) for e in rows]


@router.get("/entries")
def entries(date_from: date | None = None, date_to: date | None = None, user_id: int | None = None,
            db: Session = Depends(get_db), _: User = Depends(manage)):
    d1, d2 = _range(db, date_from, date_to)
    q = db.query(TimeEntry).filter(TimeEntry.business_date >= d1, TimeEntry.business_date <= d2)
    if user_id:
        q = q.filter(TimeEntry.user_id == user_id)
    users, lim = _users(db), S.max_hours(db)
    return [S.entry_out(e, users, lim) for e in q.order_by(TimeEntry.clock_in.desc()).limit(2000).all()]


def _check(db: Session, data: EntryIn, entry_id: int | None = None) -> None:
    if not db.get(User, data.user_id):
        raise AppError("کاربر انتخاب‌شده وجود ندارد")
    if data.clock_in > now() + timedelta(minutes=5) or (data.clock_out and data.clock_out > now() + timedelta(minutes=5)):
        raise AppError("زمان ورود/خروج نمی‌تواند در آینده باشد")
    if data.clock_out:
        if data.clock_out <= data.clock_in:
            raise AppError("زمان خروج باید بعد از زمان ورود باشد")
        if data.clock_out - data.clock_in > timedelta(hours=24):
            raise AppError("یک بازه کاری نمی‌تواند بیشتر از ۲۴ ساعت باشد")
    end = data.clock_out or datetime.max
    q = db.query(TimeEntry).filter(TimeEntry.user_id == data.user_id, TimeEntry.id != (entry_id or 0),
                                   TimeEntry.clock_in < end, (TimeEntry.clock_out.is_(None)) | (TimeEntry.clock_out > data.clock_in))
    if q.first():
        raise AppError("این بازه با یک ورود/خروج دیگر همین شخص هم‌پوشانی دارد")


def _when(e: TimeEntry) -> str:
    out = e.clock_out.strftime("%H:%M") if e.clock_out else "…"
    return f"{e.clock_in:%Y-%m-%d %H:%M} تا {out}"


@router.post("/entries", status_code=201)
def add_entry(data: EntryIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    _check(db, data)
    e = TimeEntry(**data.model_dump(), source="manual", edited_by=user.id,
                  business_date=business_day(data.clock_in, settings_store.get(db, "day.cutoff_hour", 5)))
    db.add(e)
    db.flush()
    log_action(db, user, "timeclock.add", f"ثبت دستی حضور {_users(db).get(e.user_id)}: {_when(e)}", entity="time_entry", entity_id=e.id)
    db.commit()
    return S.entry_out(e, _users(db), S.max_hours(db))


@router.put("/entries/{eid}")
def edit_entry(eid: int, data: EntryIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    e = get_or_404(db, TimeEntry, eid)
    _check(db, data, eid)
    before = _when(e)
    for k, v in data.model_dump().items():
        setattr(e, k, v)
    e.business_date = business_day(e.clock_in, settings_store.get(db, "day.cutoff_hour", 5))
    e.edited_by = user.id
    log_action(db, user, "timeclock.edit", f"اصلاح حضور {_users(db).get(e.user_id)}: {before} ← {_when(e)}", entity="time_entry", entity_id=e.id)
    db.commit()
    return S.entry_out(e, _users(db), S.max_hours(db))


@router.delete("/entries/{eid}", status_code=204)
def delete_entry(eid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    e = get_or_404(db, TimeEntry, eid)
    log_action(db, user, "timeclock.delete", f"حذف حضور {_users(db).get(e.user_id)}: {_when(e)}", entity="time_entry", entity_id=e.id)
    db.delete(e)
    db.commit()


@router.get("/wages")
def list_wages(db: Session = Depends(get_db), _: User = Depends(manage)):
    pay = {w.user_id: w for w in db.query(StaffWage).all()}

    def row(u: User) -> dict:
        w = pay.get(u.id)
        return {"user_id": u.id, "name": u.full_name, "hourly_wage": w.hourly_wage if w else 0, "pay_type": w.pay_type if w else "hourly",
                "monthly_salary": w.monthly_salary if w else 0, "insured": bool(w and w.insured)}
    return [row(u) for u in db.query(User).filter(User.is_active.is_(True)).order_by(User.full_name).all()]


@router.get("/config")
def get_config(db: Session = Depends(get_db), _: User = Depends(manage)):
    return {"insurance_pct": S.insurance_pct(db), "max_hours": S.max_hours(db)}


@router.put("/config")
def set_config(data: ConfigIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    old = S.insurance_pct(db)
    settings_store.set_many(db, {"timeclock.insurance_pct": data.insurance_pct})
    log_action(db, user, "timeclock.config", f"سهم بیمه کارفرما: {old:g}٪ ← {data.insurance_pct:g}٪")
    db.commit()
    return {"insurance_pct": data.insurance_pct, "max_hours": S.max_hours(db)}


@router.put("/wages")
def set_wage(data: WageIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    target = get_or_404(db, User, data.user_id)
    row = db.get(StaffWage, data.user_id) or StaffWage(user_id=data.user_id)
    def desc() -> str:
        if (row.pay_type or "hourly") == "monthly":
            s = f"حقوق ماهانه {row.monthly_salary or 0:,}"
        else:
            s = f"نرخ ساعتی {row.hourly_wage or 0:,}"
        return s + (" + بیمه" if row.insured else "")
    old = desc()
    row.hourly_wage = data.hourly_wage
    if data.pay_type is not None:
        row.pay_type = data.pay_type
    if data.monthly_salary is not None:
        row.monthly_salary = data.monthly_salary
    if data.insured is not None:
        row.insured = data.insured
    if row.pay_type == "monthly" and not row.monthly_salary:
        raise AppError("مبلغ حقوق ماهانه را وارد کنید", status_code=422, code="salary_required")
    db.add(row)
    log_action(db, user, "timeclock.wage", f"{target.full_name}: {old} ← {desc()}", entity="user", entity_id=target.id)
    db.commit()
    return {"user_id": data.user_id, "hourly_wage": row.hourly_wage, "pay_type": row.pay_type, "monthly_salary": row.monthly_salary,
            "insured": bool(row.insured)}


@router.get("/labor")
def labor_report(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), _: User = Depends(manage)):
    d1, d2 = _range(db, date_from, date_to)
    return S.labor(db, d1, d2)
