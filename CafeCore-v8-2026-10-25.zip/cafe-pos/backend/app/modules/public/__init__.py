from app.core.modules import Module

from .router import router

module = Module(
    name="public",
    title="منوی دیجیتال (QR)",
    description="منوی عمومی برای مشتری با اسکن کیوآر میز، فراخوان گارسون و درخواست صورتحساب",
    depends=["menu", "floor"],
    routers=[router],
)
