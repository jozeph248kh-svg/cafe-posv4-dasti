from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


class ServiceCall(Base, TimestampMixin):
    __tablename__ = "service_calls"
    id: Mapped[int] = mapped_column(primary_key=True)
    table_id: Mapped[int] = mapped_column(ForeignKey("dining_tables.id"), index=True)
    kind: Mapped[str] = mapped_column(String(10))          # waiter | bill
    status: Mapped[str] = mapped_column(String(10), default="open", index=True)
    handled_by: Mapped[int | None] = mapped_column(Integer)
    handled_at: Mapped[datetime | None] = mapped_column(DateTime)
