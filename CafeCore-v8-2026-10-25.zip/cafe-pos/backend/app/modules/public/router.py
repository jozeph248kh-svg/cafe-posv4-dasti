from datetime import timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import now
from app.modules.floor.models import DiningTable
from app.modules.menu.models import MenuCategory, MenuItem

from .models import ServiceCall

router = APIRouter()


class CallIn(BaseModel):
    token: str
    kind: str = Field(pattern="^(waiter|bill)$")


@router.get("/menu")
def public_menu(table: str | None = None, db: Session = Depends(get_db)):
    """No authentication: what guests see after scanning the table QR code."""
    s = settings_store.get_all(db)
    tbl = db.query(DiningTable).filter(DiningTable.qr_token == table, DiningTable.is_active.is_(True)).first() if table else None
    cats = db.query(MenuCategory).filter(MenuCategory.is_active.is_(True)).order_by(MenuCategory.sort, MenuCategory.id).all()
    items = (db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.show_in_qr.is_(True))
             .order_by(MenuItem.sort, MenuItem.id).all())
    return {
        "business": {"name": s["business.name"], "phone": s["business.phone"], "address": s["business.address"],
                     "logo": s["business.logo"], "currency": s["currency.label"], "wifi": s.get("business.wifi"),
                     "instagram": s.get("business.instagram"), "call_enabled": bool(s.get("qr.call_enabled", True)) and tbl is not None,
                     "tax_percent": s["tax.percent"] if s["tax.enabled"] else 0},
        "table": {"name": tbl.name} if tbl else None,
        "categories": [{"id": c.id, "name": c.name, "icon": c.icon, "color": c.color, "section": c.section} for c in cats],
        "items": [{"id": i.id, "category_id": i.category_id, "name": i.name, "description": i.description, "price": i.price,
                   "image": i.image, "is_available": i.is_available, "tags": i.tags,
                   "options": [{"group": g.name, "items": [{"name": o.name, "price": o.price_delta} for o in g.options]}
                               for g in i.modifier_groups]} for i in items],
    }


@router.post("/call")
def call(data: CallIn, db: Session = Depends(get_db)):
    tbl = db.query(DiningTable).filter(DiningTable.qr_token == data.token, DiningTable.is_active.is_(True)).first()
    if not tbl:
        raise AppError("کد میز نامعتبر است", 404, "not_found")
    if not settings_store.get(db, "qr.call_enabled", True):
        raise AppError("فراخوان غیرفعال است", 403, "disabled")
    recent = db.query(ServiceCall).filter(ServiceCall.table_id == tbl.id, ServiceCall.kind == data.kind,
                                          ServiceCall.created_at >= now() - timedelta(seconds=60)).first()
    if recent:
        return {"ok": True, "duplicate": True}
    c = ServiceCall(table_id=tbl.id, kind=data.kind)
    db.add(c)
    db.flush()
    publish_after_commit(db, "service.call", {"id": c.id, "table_id": tbl.id, "table_name": tbl.name, "kind": data.kind})
    db.commit()
    return {"ok": True}


@router.get("/calls")
def open_calls(db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    rows = db.query(ServiceCall).filter(ServiceCall.status == "open").order_by(ServiceCall.id).all()
    names = {t.id: t.name for t in db.query(DiningTable).all()}
    return [{"id": c.id, "table_id": c.table_id, "table_name": names.get(c.table_id), "kind": c.kind, "created_at": c.created_at} for c in rows]


@router.post("/calls/{cid}/ack")
def ack(cid: int, db: Session = Depends(get_db), user: User = Depends(require("pos.access"))):
    c = get_or_404(db, ServiceCall, cid, "درخواست")
    c.status, c.handled_by, c.handled_at = "done", user.id, now()
    publish_after_commit(db, "service.ack", {"id": c.id})
    db.commit()
    return {"ok": True}
