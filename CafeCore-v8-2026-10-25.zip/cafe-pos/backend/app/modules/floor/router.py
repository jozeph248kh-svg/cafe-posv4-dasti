import secrets

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit

from .models import Area, DiningTable

router = APIRouter()
manage = require("floor.manage")


class AreaIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    sort: int = 0


class AreaOut(AreaIn):
    model_config = ConfigDict(from_attributes=True)
    id: int


class TableIn(BaseModel):
    area_id: int
    name: str = Field(min_length=1, max_length=30)
    seats: int = Field(4, ge=1, le=40)
    shape: str = Field("square", pattern="^(square|round|rect)$")
    x: int = 0
    y: int = 0
    sort: int = 0
    is_active: bool = True


class TableOut(TableIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    qr_token: str


class Position(BaseModel):
    id: int
    x: int
    y: int


@router.get("/areas", response_model=list[AreaOut])
def list_areas(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return db.query(Area).order_by(Area.sort, Area.id).all()


@router.post("/areas", response_model=AreaOut, status_code=201)
def create_area(data: AreaIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    a = Area(**data.model_dump())
    db.add(a)
    publish_after_commit(db, "floor.changed")
    db.commit()
    return a


@router.put("/areas/{aid}", response_model=AreaOut)
def update_area(aid: int, data: AreaIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    a = get_or_404(db, Area, aid, "فضا")
    a.name, a.sort = data.name, data.sort
    publish_after_commit(db, "floor.changed")
    db.commit()
    return a


@router.delete("/areas/{aid}", status_code=204)
def delete_area(aid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    a = get_or_404(db, Area, aid, "فضا")
    if a.tables:
        raise AppError("ابتدا میزهای این فضا را حذف یا منتقل کنید")
    db.delete(a)
    publish_after_commit(db, "floor.changed")
    db.commit()


@router.get("/tables", response_model=list[TableOut])
def list_tables(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return db.query(DiningTable).order_by(DiningTable.area_id, DiningTable.sort, DiningTable.id).all()


@router.post("/tables", response_model=TableOut, status_code=201)
def create_table(data: TableIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    get_or_404(db, Area, data.area_id, "فضا")
    t = DiningTable(**data.model_dump())
    db.add(t)
    publish_after_commit(db, "floor.changed")
    db.commit()
    return t


@router.put("/tables/{tid}", response_model=TableOut)
def update_table(tid: int, data: TableIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    t = get_or_404(db, DiningTable, tid, "میز")
    for k, v in data.model_dump().items():
        setattr(t, k, v)
    publish_after_commit(db, "floor.changed")
    db.commit()
    return t


@router.post("/tables/positions", status_code=204)
def save_positions(items: list[Position], db: Session = Depends(get_db), _: User = Depends(manage)):
    for p in items:
        t = db.get(DiningTable, p.id)
        if t:
            t.x, t.y = p.x, p.y
    publish_after_commit(db, "floor.changed")
    db.commit()


@router.post("/tables/{tid}/regenerate-qr", response_model=TableOut)
def regenerate_qr(tid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    t = get_or_404(db, DiningTable, tid, "میز")
    t.qr_token = secrets.token_urlsafe(9)
    db.commit()
    return t


@router.delete("/tables/{tid}", status_code=204)
def delete_table(tid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    t = get_or_404(db, DiningTable, tid, "میز")
    t.is_active = False          # keep order history consistent
    publish_after_commit(db, "floor.changed")
    db.commit()
