import secrets

from sqlalchemy import Boolean, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class Area(Base):
    __tablename__ = "areas"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    sort: Mapped[int] = mapped_column(Integer, default=0)
    tables: Mapped[list["DiningTable"]] = relationship(back_populates="area", order_by="[DiningTable.sort, DiningTable.id]")


class DiningTable(Base):
    __tablename__ = "dining_tables"
    id: Mapped[int] = mapped_column(primary_key=True)
    area_id: Mapped[int] = mapped_column(ForeignKey("areas.id"))
    name: Mapped[str] = mapped_column(String(30))
    seats: Mapped[int] = mapped_column(Integer, default=4)
    shape: Mapped[str] = mapped_column(String(10), default="square")   # square | round | rect
    x: Mapped[int] = mapped_column(Integer, default=0)                  # floor-plan grid position
    y: Mapped[int] = mapped_column(Integer, default=0)
    sort: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    qr_token: Mapped[str] = mapped_column(String(32), unique=True, default=lambda: secrets.token_urlsafe(9))
    area: Mapped[Area] = relationship(back_populates="tables")
