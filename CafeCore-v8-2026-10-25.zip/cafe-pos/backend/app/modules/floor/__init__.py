from app.core.modules import Module

from .router import router
from .seed import seed

module = Module(
    name="floor",
    title="سالن و میزها",
    description="فضاها، میزها، نقشه سالن و کیوآر هر میز",
    depends=["system"],
    routers=[router],
    permissions={"floor.manage": "مدیریت سالن و میزها"},
    seed=seed,
)
