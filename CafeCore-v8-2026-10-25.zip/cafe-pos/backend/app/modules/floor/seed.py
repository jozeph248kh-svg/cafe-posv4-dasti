from sqlalchemy.orm import Session

from .models import Area, DiningTable


def seed(db: Session) -> None:
    if db.query(Area).count():
        return
    main = Area(name="سالن اصلی", sort=0)
    terrace = Area(name="تراس", sort=1)
    db.add_all([main, terrace])
    db.flush()
    for i in range(12):
        db.add(DiningTable(area_id=main.id, name=str(i + 1), seats=[2, 4, 4, 6][i % 4],
                           shape="round" if i % 4 == 0 else "square", x=i % 4, y=i // 4, sort=i))
    for i in range(6):
        db.add(DiningTable(area_id=terrace.id, name=f"T{i + 1}", seats=4, shape="square", x=i % 3, y=i // 3, sort=i))
