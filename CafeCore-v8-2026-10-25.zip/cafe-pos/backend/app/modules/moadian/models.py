from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


class TaxInvoice(Base, TimestampMixin):
    """One electronic invoice sent to the Moadian system (original sale, or a cancellation of one)."""
    __tablename__ = "tax_invoices"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    kind: Mapped[str] = mapped_column(String(10), default="sale")              # sale | cancel
    serial: Mapped[int | None] = mapped_column(Integer, unique=True)
    tax_id: Mapped[str | None] = mapped_column(String(22), unique=True)
    ref_tax_id: Mapped[str | None] = mapped_column(String(22))                 # cancellation → original tax id
    total_rial: Mapped[int] = mapped_column(Integer, default=0)
    vat_rial: Mapped[int] = mapped_column(Integer, default=0)
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(12), default="queued", index=True)   # queued|sending|sent|success|failed|not_sent
    mode: Mapped[str] = mapped_column(String(10), default="mock")
    uid: Mapped[str | None] = mapped_column(String(60))
    reference: Mapped[str | None] = mapped_column(String(80), index=True)
    errors: Mapped[list | None] = mapped_column(JSON)
    warnings: Mapped[list | None] = mapped_column(JSON)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)
    sending_at: Mapped[datetime | None] = mapped_column(DateTime)      # claimed by a sender (status «sending»)
    checked_at: Mapped[datetime | None] = mapped_column(DateTime)


class TaxCounter(Base):
    """Monotonic invoice serial (must never repeat for the same memory id)."""
    __tablename__ = "tax_counter"
    id: Mapped[int] = mapped_column(primary_key=True)
    memory_id: Mapped[str] = mapped_column(String(10), unique=True)
    serial: Mapped[int] = mapped_column(Integer, default=0)


class TaxItem(Base):
    """Per menu item tax data: 13-digit product id (شناسه کالا/خدمت) and unit of measure."""
    __tablename__ = "tax_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    menu_item_id: Mapped[int] = mapped_column(ForeignKey("menu_items.id"), unique=True)
    sstid: Mapped[str] = mapped_column(String(13))
    mu: Mapped[str] = mapped_column(String(8), default="1627")
