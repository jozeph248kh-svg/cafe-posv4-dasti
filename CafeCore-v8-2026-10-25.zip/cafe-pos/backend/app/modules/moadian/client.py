"""Moadian v2 API client (requestsmanager/api/v2) + a local mock with the same behaviour for test mode."""
import hashlib
import time
import uuid

import httpx

from . import crypto

BASE = {"sandbox": "https://sandboxrc.tax.gov.ir/requestsmanager/api/v2/", "production": "https://tp.tax.gov.ir/requestsmanager/api/v2/"}


class MoadianError(Exception):
    def __init__(self, msg: str, errors: list | None = None):
        super().__init__(msg)
        self.errors = errors or []


class Client:
    def __init__(self, mode: str, memory_id: str, key_pem: str, cert_pem: str, timeout: int = 30):
        if mode not in BASE:
            raise MoadianError("حالت اتصال نامعتبر است")
        if not (memory_id and key_pem and cert_pem):
            raise MoadianError("شناسه حافظه، کلید خصوصی و گواهی امضا باید تنظیم شوند")
        self.base, self.memory_id, self.key, self.cert, self.timeout = BASE[mode], memory_id.upper(), key_pem, cert_pem, timeout
        self._server = None

    def _req(self, method: str, path: str, auth: bool = True, **kw):
        headers = kw.pop("headers", {})
        headers.setdefault("Accept", "application/json")
        if auth:
            headers["Authorization"] = f"Bearer {self.token()}"
        try:
            r = httpx.request(method, self.base + path, headers=headers, timeout=self.timeout, **kw)
        except httpx.HTTPError as e:
            raise MoadianError(f"ارتباط با سامانه مودیان برقرار نشد: {e}") from e
        try:
            j = r.json()
        except ValueError as e:
            raise MoadianError(f"پاسخ نامعتبر از سامانه (HTTP {r.status_code})") from e
        if r.status_code >= 400:
            errs = j.get("errors") if isinstance(j, dict) else None
            raise MoadianError("; ".join(f"{e.get('code')}: {e.get('message')}" for e in errs or []) or f"HTTP {r.status_code}", errs)
        return j

    def token(self) -> str:
        nonce = self._req("GET", "nonce", auth=False, params={"timeToLive": 30})["nonce"]
        return crypto.jws({"nonce": nonce, "clientId": self.memory_id}, self.key, self.cert)

    def server_key(self) -> tuple[str, str]:
        if not self._server:
            info = self._req("GET", "server-information", auth=False)
            k = (info.get("publicKeys") or [{}])[0]
            self._server = (k.get("key"), k.get("id"))
        return self._server

    def send(self, invoices: list[dict]) -> list[dict]:
        pub, kid = self.server_key()
        packets = []
        for inv in invoices:
            signed = crypto.jws(inv, self.key, self.cert)
            packets.append({"payload": crypto.jwe(signed, pub, kid), "header": {"requestTraceId": str(uuid.uuid4()), "fiscalId": self.memory_id}})
        res = self._req("POST", "invoice", json=packets)
        return res.get("result") or []

    def inquiry(self, references: list[str]) -> list[dict]:
        return self._req("GET", "inquiry-by-reference-id", params=[("referenceIds", r) for r in references])

    def fiscal_info(self) -> dict:
        return self._req("GET", "fiscal-information", params={"memoryId": self.memory_id})


class MockClient:
    """Behaves like the real system: accepts packets, returns reference numbers, results appear after ~10 s.
    Validation mirrors common real errors so setup mistakes surface during testing."""
    _store: dict[str, dict] = {}

    def __init__(self, memory_id: str, **_):
        self.memory_id = (memory_id or "").upper()

    def server_key(self):
        return ("mock", "mock")

    def fiscal_info(self) -> dict:
        return {"nameTrade": "حالت آزمایشی", "fiscalStatus": "ACTIVE", "economicCode": "—", "mock": True}

    def send(self, invoices: list[dict]) -> list[dict]:
        out = []
        for inv in invoices:
            h = inv["header"]
            ref = hashlib.sha1(f"{h['taxid']}{time.time()}".encode()).hexdigest()[:8] + "-" + uuid.uuid4().hex[:4] + "-" + uuid.uuid4().hex[:12]
            errors = []
            if not crypto.verhoeff_valid(crypto._decimalise(h["taxid"][:6]) + str(int(h["taxid"][6:11], 16)).rjust(6, "0") + str(int(h["taxid"][11:21], 16)).rjust(12, "0") + h["taxid"][-1]):
                errors.append({"code": "0100", "message": "شماره منحصر به فرد مالیاتی نامعتبر است"})
            if abs(h["tbill"] - sum(b["tsstam"] for b in inv["body"])) > 1:
                errors.append({"code": "0510", "message": "مجموع صورتحساب با جمع اقلام برابر نیست"})
            for b in inv["body"]:
                if len(str(b.get("sstid", ""))) != 13:
                    errors.append({"code": "0603", "message": f"شناسه کالا/خدمت «{b['sstt']}» باید ۱۳ رقم باشد"})
            self._store[ref] = {"at": time.time(), "errors": errors, "taxid": h["taxid"]}
            out.append({"uid": str(uuid.uuid4()), "referenceNumber": ref, "errorCode": None, "errorDetail": None, "taxId": h["taxid"]})
        return out

    def inquiry(self, references: list[str]) -> list[dict]:
        res = []
        for ref in references:
            st = self._store.get(ref)
            if not st:      # mock store is in memory: after a restart treat earlier packets as accepted
                res.append({"referenceNumber": ref, "status": "SUCCESS", "data": {"error": [], "warning": [], "success": True}})
            elif time.time() - st["at"] < MockClient.delay:
                res.append({"referenceNumber": ref, "status": "IN_PROGRESS"})
            else:
                res.append({"referenceNumber": ref, "status": "FAILED" if st["errors"] else "SUCCESS",
                            "data": {"error": st["errors"], "warning": [], "success": not st["errors"]}})
        return res

    delay = 10


def make(settings: dict, key_pem: str, cert_pem: str):
    mode = settings.get("moadian.mode") or "mock"
    if mode == "mock":
        return MockClient(settings.get("moadian.memory_id"))
    return Client(mode, settings.get("moadian.memory_id") or "", key_pem, cert_pem)

