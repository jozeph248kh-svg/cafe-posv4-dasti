from app.core import events, settings_store
from app.core.jobs import Job
from app.core.modules import Module
from app.core.permissions import grant_once

from . import service
from .router import router

settings_store.register_defaults(service.DEFAULTS, protected={"moadian."})


def setup() -> None:
    events.subscribe("order.closed", service.on_order_closed)


def seed(db) -> None:
    grant_once(db, "moadian", {"manager": ["moadian.manage"]})


def demo(db) -> None:
    """Mock mode with a few registered invoices so the page can be explored (nothing is sent anywhere)."""
    from datetime import timedelta

    from app.core.utils import now
    from app.modules.orders.models import Order

    from .models import TaxInvoice
    if db.query(TaxInvoice).count():
        return
    settings_store.set_many(db, {"moadian.enabled": True, "moadian.mode": "mock", "moadian.memory_id": "A1B2C3", "moadian.economic_code": "14000000000",
                                 "moadian.default_sstid": "2710000138624"})
    orders = db.query(Order).filter(Order.status == "closed").order_by(Order.id.desc()).limit(12).all()
    t = now()
    for i, o in enumerate(reversed(orders)):
        ti = service.enqueue(db, o)
        db.flush()
        if ti.status == "queued":
            ti.status, ti.reference, ti.sent_at, ti.checked_at = ("success", f"demo-{ti.serial:04d}", t - timedelta(minutes=5 * (12 - i)), t) if i != 3 else ("failed", f"demo-{ti.serial:04d}", t, t)
            if i == 3:
                ti.errors = [{"code": "0603", "message": "شناسه کالا/خدمت نامعتبر است (نمونه خطا)"}]


module = Module(
    name="moadian",
    title="سامانه مودیان",
    description="صدور و ارسال خودکار صورتحساب الکترونیکی (نوع دوم) به سامانه مودیان سازمان امور مالیاتی؛ حالت آزمایشی، sandbox و عملیاتی",
    depends=["orders", "menu"],
    routers=[router],
    permissions={"moadian.manage": "مدیریت سامانه مودیان"},
    seed=seed,
    demo=demo,
    setup=setup,
    jobs=[Job("moadian.send", 30, service.send_queue), Job("moadian.inquiry", 30, service.inquire)],
)
