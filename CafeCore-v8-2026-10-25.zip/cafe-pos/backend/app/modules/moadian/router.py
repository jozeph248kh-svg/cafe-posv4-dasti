from datetime import timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import now

from . import client as C
from . import crypto
from . import service as S
from .models import TaxInvoice, TaxItem

router = APIRouter()
perm = require("moadian.manage")


class ConfigIn(BaseModel):
    enabled: bool
    mode: str = Field(pattern="^(mock|sandbox|production)$")
    auto_send: bool = True
    memory_id: str = Field("", max_length=10)
    economic_code: str = Field("", max_length=14)
    vat_percent: float = Field(10, ge=0, le=30)
    price_includes_vat: bool = True
    default_sstid: str = Field("", pattern=r"^(\d{13})?$")
    default_mu: str = "1627"
    min_amount: int = 0


class GenIn(BaseModel):
    common_name: str = Field(min_length=2)
    national_id: str = Field(pattern=r"^\d{10,11}$")
    organization: str | None = None
    individual: bool = False


class KeysIn(BaseModel):
    private_key: str | None = None
    certificate: str | None = None


class ItemsIn(BaseModel):
    items: dict[int, str]          # menu_item_id -> 13-digit sstid ("" = remove)


def iout(t: TaxInvoice) -> dict:
    return {"id": t.id, "order_id": t.order_id, "kind": t.kind, "serial": t.serial, "tax_id": t.tax_id, "ref_tax_id": t.ref_tax_id, "total": t.total_rial,
            "vat": t.vat_rial, "status": t.status, "mode": t.mode, "reference": t.reference, "errors": t.errors, "warnings": t.warnings, "attempts": t.attempts,
            "created_at": t.created_at, "sent_at": t.sent_at, "checked_at": t.checked_at}


@router.get("/status")
def status(db: Session = Depends(get_db), _: User = Depends(perm)):
    s = settings_store.get_all(db)
    k, c = S.read_keys()
    since = now() - timedelta(days=30)
    counts = dict(db.query(TaxInvoice.status, func.count()).filter(TaxInvoice.created_at >= since).group_by(TaxInvoice.status).all())
    vat = db.query(func.coalesce(func.sum(TaxInvoice.vat_rial), 0)).filter(TaxInvoice.status == "success", TaxInvoice.kind == "sale", TaxInvoice.created_at >= since).scalar()
    return {**{k2.split(".", 1)[1]: v for k2, v in s.items() if k2.startswith("moadian.")}, "has_key": bool(k), "certificate": S.cert_info(c),
            "public_key": crypto.public_b64(k) if k else None, "counts": counts, "vat_30d": int(vat or 0)}


@router.put("/config")
def save_config(data: ConfigIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    if data.enabled and data.mode != "mock" and len(data.memory_id.strip()) != 6:
        raise AppError("شناسه یکتای حافظه مالیاتی باید ۶ کاراکتر باشد")
    settings_store.set_many(db, {f"moadian.{k}": (v.strip().upper() if k == "memory_id" else v) for k, v in data.model_dump().items()})
    log_action(db, user, "moadian.config", f"تنظیمات سامانه مودیان (حالت {data.mode}، {'فعال' if data.enabled else 'غیرفعال'})")
    db.commit()
    return {"ok": True}


@router.post("/keys/generate")
def generate(data: GenIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    key, csr = crypto.generate_key_and_csr(data.common_name, data.national_id, data.organization, data.individual)
    S.write_key("private.pem", key)
    S.write_key("request.csr", csr)
    _k, cert = S.read_keys()
    if not cert:
        S.write_key("certificate.pem", crypto.self_signed(key, data.common_name))     # placeholder for mock/sandbox until the real one is issued
    log_action(db, user, "moadian.keys", "تولید کلید خصوصی و درخواست گواهی (CSR) مودیان")
    db.commit()
    return {"csr": csr, "public_key": crypto.public_b64(key)}


@router.put("/keys")
def upload_keys(data: KeysIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    if data.private_key:
        try:
            crypto.load_private_key(data.private_key.strip())
        except Exception as e:
            raise AppError("کلید خصوصی نامعتبر است (فرمت PEM بدون رمز)") from e
        S.write_key("private.pem", data.private_key)
    if data.certificate:
        try:
            crypto.load_cert(data.certificate.strip())
        except Exception as e:
            raise AppError("گواهی نامعتبر است (فرمت PEM)") from e
        S.write_key("certificate.pem", data.certificate)
    log_action(db, user, "moadian.keys", "بارگذاری کلید/گواهی مودیان")
    db.commit()
    return {"ok": True}


@router.post("/test")
def test(db: Session = Depends(get_db), _: User = Depends(perm)):
    try:
        cl = S.make_client(db)
        info = cl.fiscal_info()
        return {"ok": True, "info": info}
    except C.MoadianError as e:
        raise AppError(str(e), code="moadian_error") from e


@router.get("/invoices")
def invoices(status: str | None = None, days: int = 7, page: int = 1, size: int = 20, db: Session = Depends(get_db), _: User = Depends(perm)):
    q = db.query(TaxInvoice).filter(TaxInvoice.created_at >= now() - timedelta(days=days))
    if status:
        q = q.filter(TaxInvoice.status == status)
    total = q.count()
    rows = q.order_by(TaxInvoice.id.desc()).offset((max(page, 1) - 1) * size).limit(min(size, 100)).all()
    from app.modules.orders.models import Order
    nums = dict(db.query(Order.id, Order.number).filter(Order.id.in_([r.order_id for r in rows])).all()) if rows else {}
    return {"total": total, "items": [{**iout(r), "order_number": nums.get(r.order_id)} for r in rows]}


@router.get("/invoices/{iid}/payload")
def payload(iid: int, db: Session = Depends(get_db), _: User = Depends(perm)):
    return get_or_404(db, TaxInvoice, iid, "صورتحساب").payload


@router.post("/orders/{oid}")
def send_order(oid: int, db: Session = Depends(get_db), user: User = Depends(perm)):
    from app.modules.orders.models import Order
    o = get_or_404(db, Order, oid, "سفارش")
    if o.status != "closed":
        raise AppError("فقط سفارش‌های تسویه‌شده قابل ارسال هستند")
    if db.query(TaxInvoice.id).filter(TaxInvoice.order_id == oid, TaxInvoice.kind == "sale", TaxInvoice.status != "not_sent").first():
        raise AppError("برای این سفارش قبلاً صورتحساب صادر شده است")
    t = S.enqueue(db, o)
    db.commit()
    return iout(t)


@router.post("/invoices/{iid}/retry")
def retry(iid: int, db: Session = Depends(get_db), user: User = Depends(perm)):
    t = get_or_404(db, TaxInvoice, iid, "صورتحساب")
    if t.status not in ("failed", "not_sent"):
        raise AppError("فقط صورتحساب‌های ناموفق دوباره ارسال می‌شوند")
    try:
        S.rebuild(db, t)
    except ValueError as e:
        t.errors = [{"code": "LOCAL", "message": str(e)}]
        db.commit()
        raise AppError(str(e)) from e
    db.commit()
    return iout(t)


@router.post("/invoices/{iid}/cancel")
def cancel(iid: int, db: Session = Depends(get_db), user: User = Depends(perm)):
    """Issue a cancellation invoice (ابطال) for a successfully registered sale."""
    from app.modules.orders.models import Order
    t = get_or_404(db, TaxInvoice, iid, "صورتحساب")
    if t.kind != "sale" or t.status != "success":
        raise AppError("فقط صورتحساب فروشِ ثبت‌شده قابل ابطال است")
    if db.query(TaxInvoice.id).filter(TaxInvoice.ref_tax_id == t.tax_id, TaxInvoice.kind == "cancel").first():
        raise AppError("این صورتحساب قبلاً ابطال شده است")
    c = S.enqueue(db, db.get(Order, t.order_id), "cancel", t)
    log_action(db, user, "moadian.cancel", f"ابطال صورتحساب {t.tax_id}", entity="order", entity_id=t.order_id)
    db.commit()
    return iout(c)


@router.post("/run")
def run_now(db: Session = Depends(get_db), _: User = Depends(perm)):
    sent = S.send_queue(db)
    db.commit()
    checked = S.inquire(db)
    db.commit()
    return {"sent": sent, "checked": checked}


@router.get("/items")
def items(db: Session = Depends(get_db), _: User = Depends(perm)):
    from app.modules.menu.models import MenuCategory, MenuItem
    maps = {t.menu_item_id: t for t in db.query(TaxItem)}
    cats = dict(db.query(MenuCategory.id, MenuCategory.name).all())
    rows = db.query(MenuItem).filter(MenuItem.is_active.is_(True)).order_by(MenuItem.category_id, MenuItem.sort).all()
    return [{"id": m.id, "name": m.name, "category": cats.get(m.category_id), "price": m.price, "sstid": maps[m.id].sstid if m.id in maps else ""}
            for m in rows if not (m.code or "").startswith("__")]


@router.put("/items")
def save_items(data: ItemsIn, db: Session = Depends(get_db), _: User = Depends(perm)):
    maps = {t.menu_item_id: t for t in db.query(TaxItem)}
    for mid, sst in data.items.items():
        sst = (sst or "").strip()
        if sst and (len(sst) != 13 or not sst.isdigit()):
            raise AppError(f"شناسه «{sst}» باید ۱۳ رقم باشد")
        if not sst:
            if mid in maps:
                db.delete(maps[mid])
        elif mid in maps:
            maps[mid].sstid = sst
        else:
            db.add(TaxItem(menu_item_id=mid, sstid=sst))
    db.commit()
    return {"ok": True}
