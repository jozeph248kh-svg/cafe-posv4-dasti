"""Builds the Moadian JSON invoice (type 2 = B2C retail invoice, pattern 1 = sale) from a closed order."""
from sqlalchemy.orm import Session

from app.core import settings_store

from . import crypto

SETM = {"cash": 1, "card": 1, "online": 1, "wallet": 1, "credit": 2}


def _drop_none(d: dict) -> dict:
    return {k: v for k, v in d.items() if v is not None}


def build(db: Session, order, serial: int, kind: str = "sale", ref_tax_id: str | None = None, issued=None) -> tuple[str, dict, int, int]:
    from .models import TaxItem
    s = settings_store.get_all(db)
    memory_id = (s.get("moadian.memory_id") or "").strip().upper()
    if len(memory_id) < 6:
        raise ValueError("شناسه یکتای حافظه مالیاتی تنظیم نشده است")
    issued = issued or order.closed_at or order.created_at
    tid = crypto.tax_id(memory_id, issued, serial)
    vra = float(s.get("moadian.vat_percent") or 10)
    vra = int(vra) if vra.is_integer() else vra
    inclusive = bool(s.get("moadian.price_includes_vat"))
    default_sstid = (s.get("moadian.default_sstid") or "").strip()
    maps = {t.menu_item_id: t for t in db.query(TaxItem).all()}

    lines = [ln for ln in order.active_lines if ln.total > 0]
    gross = sum(ln.total - ln.discount_amount for ln in lines) or 1     # weights: item value after item discounts
    # what the customer actually paid for goods (toman): subtotal − discount + service (+rounding); VAT handled below
    target = order.total - (0 if inclusive else order.tax_amount)
    body, acc = [], 0
    for i, ln in enumerate(lines):
        share = target - acc if i == len(lines) - 1 else round(target * (ln.total - ln.discount_amount) / gross)
        acc += share
        t = maps.get(ln.menu_item_id)
        prdis = ln.total * 10                                   # rial
        net = share * 10
        if inclusive:
            net = round(net / (1 + vra / 100))
        adis = net
        fee = max(round(prdis / ln.qty), -(-adis // ln.qty)) if ln.qty else prdis
        vam = round(adis * vra / 100)
        body.append(_drop_none({
            "sstid": (t.sstid if t else default_sstid) or None, "sstt": ln.name[:400], "am": ln.qty, "mu": (t.mu if t else s.get("moadian.default_mu")) or "1627",
            "fee": fee, "prdis": fee * ln.qty, "dis": fee * ln.qty - adis, "adis": adis, "vra": vra, "vam": vam, "tsstam": adis + vam,
        }))
    tprdis = sum(b["prdis"] for b in body)
    tdis = sum(b["dis"] for b in body)
    tadis = sum(b["adis"] for b in body)
    tvam = sum(b["vam"] for b in body)
    methods = {p.method for p in order.payments if p.amount > 0}
    setm = 3 if len({SETM.get(m, 1) for m in methods}) > 1 else (SETM.get(next(iter(methods)), 1) if methods else 1)
    credit = sum(p.amount for p in order.payments if p.method == "credit") * 10
    header = _drop_none({
        "taxid": tid, "indatim": crypto.epoch_ms(issued), "Indati2m": crypto.epoch_ms(issued), "inty": 2, "inno": crypto.inno(serial),
        "irtaxid": ref_tax_id, "inp": 1, "ins": 3 if kind == "cancel" else 1, "tins": (s.get("moadian.economic_code") or "").strip() or None,
        "tprdis": tprdis, "tdis": tdis, "tadis": tadis, "tvam": tvam, "todam": 0, "tbill": tadis + tvam, "setm": setm,
        "cap": tadis + tvam - credit if setm != 2 else None, "insp": credit if setm == 3 else None,
    })
    if setm == 2:
        header["cap"], header["insp"] = 0, tadis + tvam
    missing = [b["sstt"] for b in body if not b.get("sstid")]
    if missing:
        raise ValueError("شناسه کالا/خدمت (۱۳ رقمی) برای این اقلام تعریف نشده: " + "، ".join(missing[:5]))
    return tid, {"header": header, "body": body, "payments": []}, tadis + tvam, tvam
