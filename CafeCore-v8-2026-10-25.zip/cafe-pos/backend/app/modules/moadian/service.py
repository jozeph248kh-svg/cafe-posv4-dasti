import logging
from datetime import timedelta

from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.config import get_settings
from app.core.utils import now

from . import client as C
from . import crypto, invoice
from .models import TaxCounter, TaxInvoice

log = logging.getLogger("moadian")

DEFAULTS = {
    "moadian.enabled": False,
    "moadian.mode": "mock",               # mock | sandbox | production
    "moadian.auto_send": True,            # send every closed order automatically
    "moadian.memory_id": "",              # شناسه یکتای حافظه مالیاتی (6 chars)
    "moadian.economic_code": "",          # شماره اقتصادی / شناسه ملی فروشنده
    "moadian.vat_percent": 10,
    "moadian.price_includes_vat": True,
    "moadian.default_sstid": "",          # used for items without their own product id
    "moadian.default_mu": "1627",         # unit: عدد
    "moadian.min_amount": 0,              # orders below this total (toman) are skipped
}


def key_dir():
    d = get_settings().data_dir / "moadian"
    d.mkdir(parents=True, exist_ok=True)
    return d


def read_keys() -> tuple[str, str]:
    d = key_dir()
    k, c = d / "private.pem", d / "certificate.pem"
    return (k.read_text() if k.exists() else ""), (c.read_text() if c.exists() else "")


def write_key(name: str, pem: str) -> None:
    p = key_dir() / name
    p.write_text(pem.strip() + "\n")
    try:
        p.chmod(0o600)
    except OSError:
        pass


def make_client(db: Session):
    k, c = read_keys()
    return C.make(settings_store.get_all(db), k, c)


def next_serial(db: Session, memory_id: str) -> int:
    row = db.query(TaxCounter).filter(TaxCounter.memory_id == memory_id).with_for_update().first()
    if not row:
        row = TaxCounter(memory_id=memory_id, serial=0)
        db.add(row)
    row.serial += 1
    db.flush()
    return row.serial


def enqueue(db: Session, order, kind: str = "sale", ref: TaxInvoice | None = None) -> TaxInvoice:
    s = settings_store.get_all(db)
    memory_id = (s.get("moadian.memory_id") or "").strip().upper()
    mode = s.get("moadian.mode") or "mock"
    ti = TaxInvoice(order_id=order.id, kind=kind, ref_tax_id=ref.tax_id if ref else None, mode=mode, payload={}, status="queued")
    try:
        invoice.build(db, order, 1, kind, ti.ref_tax_id)      # validate before consuming a serial number
    except ValueError as e:
        ti.status, ti.errors = "not_sent", [{"code": "LOCAL", "message": str(e)}]
        db.add(ti)
        return ti
    serial = next_serial(db, memory_id)
    ti.serial = serial
    ti.tax_id, ti.payload, ti.total_rial, ti.vat_rial = invoice.build(db, order, serial, kind, ti.ref_tax_id)
    db.add(ti)
    return ti


def rebuild(db: Session, ti: TaxInvoice) -> None:
    """After fixing settings / product ids: rebuild the payload (keeping the serial if one was assigned)."""
    from app.modules.orders.models import Order
    order = db.get(Order, ti.order_id)
    s = settings_store.get_all(db)
    if ti.serial is None:
        invoice.build(db, order, 1, ti.kind, ti.ref_tax_id)
        ti.serial = next_serial(db, (s.get("moadian.memory_id") or "").strip().upper())
    ti.tax_id, ti.payload, ti.total_rial, ti.vat_rial = invoice.build(db, order, ti.serial, ti.kind, ti.ref_tax_id)
    ti.status, ti.errors, ti.attempts, ti.reference, ti.mode = "queued", None, 0, None, s.get("moadian.mode") or "mock"


STALE_SENDING = timedelta(minutes=15)


def _claim(db: Session, ids: list[int]) -> list[int]:
    """queued → sending with a conditional UPDATE, committed before the network call: the background job and
    «ارسال الان» can never submit the same invoice twice."""
    t, got = now(), []
    for i in ids:
        if db.query(TaxInvoice).filter(TaxInvoice.id == i, TaxInvoice.status == "queued").update(
                {"status": "sending", "sending_at": t}, synchronize_session=False):
            got.append(i)
    db.commit()
    return got


def _mine(db: Session, ids: list[int]) -> list[TaxInvoice]:
    return (db.query(TaxInvoice).populate_existing().filter(TaxInvoice.id.in_(ids), TaxInvoice.status == "sending")
            .order_by(TaxInvoice.id).all())


def recover_stale(db: Session) -> int:
    """A send interrupted by a crash: back to the queue (the tax system identifies invoices by taxId; the inquiry
    job also re-queues invoices it can't find)."""
    rows = db.query(TaxInvoice).filter(TaxInvoice.status == "sending", TaxInvoice.sending_at < now() - STALE_SENDING).all()
    for r in rows:
        r.status, r.errors = "queued", [{"code": "INTERRUPTED", "message": "ارسال نیمه‌کاره ماند؛ دوباره ارسال می‌شود"}]
    if rows:
        db.commit()
    return len(rows)


def send_queue(db: Session, limit: int = 10) -> int:
    if not settings_store.get(db, "moadian.enabled", False):
        return 0
    recover_stale(db)
    ids = [i for (i,) in db.query(TaxInvoice.id).filter(TaxInvoice.status == "queued").order_by(TaxInvoice.id).limit(limit)]
    if not ids:
        return 0
    try:
        cl = make_client(db)
    except C.MoadianError as e:
        for r in db.query(TaxInvoice).filter(TaxInvoice.id.in_(ids)).all():
            r.attempts += 1
            r.errors = e.errors or [{"code": "NET", "message": str(e)}]
            if r.attempts >= 5:
                r.status = "failed"
        return 0
    ids = _claim(db, ids)
    rows = _mine(db, ids)
    payloads = [r.payload for r in rows]
    db.commit()                                   # no transaction is held during the network call
    if not rows:
        return 0
    try:
        res = cl.send(payloads)
    except C.MoadianError as e:
        for r in _mine(db, ids):
            r.attempts += 1
            r.errors = e.errors or [{"code": "NET", "message": str(e)}]
            r.status = "failed" if r.attempts >= 5 else "queued"
        db.commit()
        return 0
    by_tax = {x.get("taxId"): x for x in res if x.get("taxId")}
    order = {r.id: i for i, r in enumerate(rows)}
    for r in _mine(db, ids):
        i = order[r.id]
        x = by_tax.get(r.tax_id) or (res[i] if i < len(res) else {})
        r.attempts += 1
        if x.get("referenceNumber"):
            r.status, r.reference, r.uid, r.sent_at, r.errors = "sent", x["referenceNumber"], x.get("uid"), now(), None
        else:
            r.errors = [{"code": x.get("errorCode") or "?", "message": x.get("errorDetail") or "ارسال ناموفق"}]
            r.status = "failed" if r.attempts >= 5 else "queued"
    db.commit()
    return len(rows)


def inquire(db: Session, limit: int = 50) -> int:
    if not settings_store.get(db, "moadian.enabled", False):
        return 0
    rows = (db.query(TaxInvoice).filter(TaxInvoice.status == "sent", TaxInvoice.sent_at <= now() - timedelta(seconds=10))
            .order_by(TaxInvoice.sent_at).limit(limit).all())
    if not rows:
        return 0
    ids, refs = [r.id for r in rows], [r.reference for r in rows]
    try:
        cl = make_client(db)
        db.commit()                               # no transaction is held during the network call
        res = cl.inquiry(refs)
    except C.MoadianError as e:
        log.warning("moadian inquiry failed: %s", e)
        return 0
    by_ref = {x.get("referenceNumber"): x for x in res or []}
    rows = db.query(TaxInvoice).populate_existing().filter(TaxInvoice.id.in_(ids), TaxInvoice.status == "sent").all()
    for r in rows:
        x = by_ref.get(r.reference) or {}
        st = (x.get("status") or "").upper()
        r.checked_at = now()
        data = x.get("data") or {}
        if st == "SUCCESS":
            r.status, r.warnings = "success", data.get("warning") or None
        elif st == "FAILED":
            r.status, r.errors, r.warnings = "failed", data.get("error") or [{"code": "?", "message": "رد شده توسط سامانه"}], data.get("warning") or None
        elif st == "NOT_FOUND" and r.sent_at < now() - timedelta(hours=1):
            r.status, r.errors = "queued", [{"code": "NOT_FOUND", "message": "در سامانه پیدا نشد؛ دوباره ارسال می‌شود"}]
    return len(rows)


def on_order_closed(db, order, **_):
    s = settings_store.get_all(db)
    if not s.get("moadian.enabled") or not s.get("moadian.auto_send"):
        return
    if order.total < int(s.get("moadian.min_amount") or 0):
        return
    if db.query(TaxInvoice.id).filter(TaxInvoice.order_id == order.id, TaxInvoice.kind == "sale").first():
        return
    enqueue(db, order)


def cert_info(cert_pem: str) -> dict | None:
    if not cert_pem:
        return None
    try:
        c = crypto.load_cert(cert_pem)
        return {"subject": c.subject.rfc4514_string(), "issuer": c.issuer.rfc4514_string(), "not_after": c.not_valid_after_utc.isoformat(),
                "self_signed": c.subject == c.issuer}
    except Exception as e:  # noqa: BLE001
        return {"error": str(e)[:200]}
