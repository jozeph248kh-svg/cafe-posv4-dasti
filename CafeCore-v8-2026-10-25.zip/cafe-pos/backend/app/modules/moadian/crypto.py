"""Moadian (سامانه مودیان) cryptography: tax id, Verhoeff, JWS (RS256 + sigT/x5c) and JWE (RSA-OAEP-256 / A256GCM).

Wire format follows the public reverse-engineered v2 spec (requestsmanager/api/v2) used by open-source SDKs.
"""
import base64
import json
import os
import time
from datetime import datetime, timedelta, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.x509.oid import NameOID

TEHRAN = timezone(timedelta(hours=3, minutes=30))     # Iran has no DST since 1401


def b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def b64url_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def compact_json(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode()


# ------------------------------------------------------------------ Verhoeff
_D = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6], [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
      [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1], [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
      [8, 7, 6, 5, 9, 3, 2, 1, 0, 4], [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]]
_P = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2], [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
      [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1], [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]]
_INV = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9]


def verhoeff(num: str) -> int:
    c = 0
    for i, ch in enumerate(reversed(num)):
        c = _D[c][_P[(i + 1) % 8][int(ch)]]
    return _INV[c]


def verhoeff_valid(num: str) -> bool:
    c = 0
    for i, ch in enumerate(reversed(num)):
        c = _D[c][_P[i % 8][int(ch)]]
    return c == 0


# ------------------------------------------------------------------ tax id (شماره منحصربه‌فرد مالیاتی)
def _decimalise(memory_id: str) -> str:
    return "".join(ch if ch.isdigit() else str(ord(ch)) for ch in memory_id.upper())


def day_range(issued: datetime) -> int:
    aware = issued.replace(tzinfo=TEHRAN) if issued.tzinfo is None else issued
    return int(aware.timestamp() // 86400)


def tax_id(memory_id: str, issued: datetime, serial: int) -> str:
    memory_id = memory_id.strip().upper()
    d = day_range(issued)
    control = _decimalise(memory_id) + str(d).rjust(6, "0") + str(serial).rjust(12, "0")
    return (memory_id + f"{d:x}".rjust(5, "0") + f"{serial:x}".rjust(10, "0")).upper() + str(verhoeff(control))


def inno(serial: int) -> str:
    return f"{serial:x}".rjust(10, "0")


def epoch_ms(dt: datetime) -> int:
    aware = dt.replace(tzinfo=TEHRAN) if dt.tzinfo is None else dt
    return int(aware.timestamp() * 1000)


# ------------------------------------------------------------------ keys
def load_private_key(pem: str):
    return serialization.load_pem_private_key(pem.encode(), password=None)


def load_cert(pem: str) -> x509.Certificate:
    return x509.load_pem_x509_certificate(pem.encode())


def generate_key_and_csr(common_name: str, national_id: str, org: str | None = None, individual: bool = False) -> tuple[str, str]:
    """RSA-2048 key + CSR for uploading in the taxpayer portal (my.tax.gov.ir → شناسه یکتای حافظه)."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    attrs = [x509.NameAttribute(NameOID.COUNTRY_NAME, "IR"), x509.NameAttribute(NameOID.SERIAL_NUMBER, national_id),
             x509.NameAttribute(NameOID.COMMON_NAME, common_name)]
    if not individual:
        attrs += [x509.NameAttribute(NameOID.ORGANIZATION_NAME, org or common_name), x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, org or common_name)]
    csr = x509.CertificateSigningRequestBuilder().subject_name(x509.Name(attrs)).sign(key, hashes.SHA256())
    key_pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
    return key_pem, csr.public_bytes(serialization.Encoding.PEM).decode()


def self_signed(key_pem: str, cn: str = "TEST") -> str:
    """Only for mock/sandbox experiments when no real certificate exists yet."""
    key = load_private_key(key_pem)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    now = datetime.now(timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(days=1)).not_valid_after(now + timedelta(days=365)).sign(key, hashes.SHA256()))
    return cert.public_bytes(serialization.Encoding.PEM).decode()


# ------------------------------------------------------------------ JWS / JWE
def jws(payload, key_pem: str, cert_pem: str) -> str:
    key = load_private_key(key_pem)
    der = load_cert(cert_pem).public_bytes(serialization.Encoding.DER)
    header = {"alg": "RS256", "x5c": [base64.b64encode(der).decode()], "sigT": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "typ": "jose", "crit": ["sigT"], "cty": "text/plain"}
    signing_input = f"{b64url(compact_json(header))}.{b64url(payload if isinstance(payload, bytes) else compact_json(payload))}"
    sig = key.sign(signing_input.encode(), padding.PKCS1v15(), hashes.SHA256())
    return f"{signing_input}.{b64url(sig)}"


def jws_verify(token: str, cert_pem: str | None = None) -> dict:
    h, p, s = token.split(".")
    header = json.loads(b64url_dec(h))
    cert = load_cert(cert_pem) if cert_pem else x509.load_der_x509_certificate(base64.b64decode(header["x5c"][0]))
    cert.public_key().verify(b64url_dec(s), f"{h}.{p}".encode(), padding.PKCS1v15(), hashes.SHA256())
    return json.loads(b64url_dec(p))


def _load_pub(key: str):
    key = key.strip()
    if "BEGIN" in key:
        return serialization.load_pem_public_key(key.encode())
    return serialization.load_der_public_key(base64.b64decode(key))


def jwe(plaintext: str, server_pub: str, kid: str) -> str:
    header = {"alg": "RSA-OAEP-256", "enc": "A256GCM", "kid": kid}
    h64 = b64url(compact_json(header))
    cek, iv = os.urandom(32), os.urandom(12)
    ek = _load_pub(server_pub).encrypt(cek, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    ct = AESGCM(cek).encrypt(iv, plaintext.encode(), h64.encode())
    return ".".join([h64, b64url(ek), b64url(iv), b64url(ct[:-16]), b64url(ct[-16:])])


def jwe_decrypt(token: str, private_pem: str) -> str:
    """Used by tests and the mock server to prove the packet is decryptable."""
    h64, ek, iv, ct, tag = token.split(".")
    cek = load_private_key(private_pem).decrypt(b64url_dec(ek), padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    return AESGCM(cek).decrypt(b64url_dec(iv), b64url_dec(ct) + b64url_dec(tag), h64.encode()).decode()


def public_b64(private_pem: str) -> str:
    pub = load_private_key(private_pem).public_key()
    return base64.b64encode(pub.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)).decode()
