from types import SimpleNamespace

from sqlalchemy.orm import Session

from app.core import events

from .costing import snapshot_line_costs
from .models import Ingredient, StockMovement
from .service import move, usage_for_lines


def on_closed(db: Session, order, user, **_):
    # idempotent: an order's ingredients are consumed exactly once even if the event is emitted again
    if db.query(StockMovement.id).filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                                         StockMovement.ref_id == order.id).first():
        return
    snapshot_line_costs(db, order)          # freeze COGS of this sale before the prices can change
    usage = usage_for_lines(db, order.active_lines)
    for ing_id, qty in usage.items():
        ing = db.get(Ingredient, ing_id)
        if ing:
            move(db, ing, -qty, "sale", ref_type="order", ref_id=order.id, note=f"سفارش #{order.number}", user_id=user.id)


def on_refunded(db: Session, order, user, returned, **_):
    """Items handed back on a refund: their recipe ingredients return to stock (kind "return")."""
    usage = usage_for_lines(db, [SimpleNamespace(menu_item_id=l.menu_item_id, modifiers=l.modifiers, qty=q) for l, q in returned])
    names = "، ".join(f"{q}× {l.name}" for l, q in returned)
    for ing_id, qty in usage.items():
        ing = db.get(Ingredient, ing_id)
        if ing and qty:
            move(db, ing, qty, "return", ref_type="order", ref_id=order.id, note=f"برگشت از سفارش #{order.number}: {names}"[:200],
                 user_id=user.id)


def setup() -> None:
    events.subscribe("order.closed", on_closed)
    events.subscribe("order.refunded", on_refunded)
