from datetime import date, datetime

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy.orm import Session

from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.modules.menu.models import MenuCategory, MenuItem, ModifierOption

from .models import (
    STD_PURCHASE_UNITS,
    UNITS,
    Ingredient,
    Purchase,
    PurchaseLine,
    RecipeLine,
    StockAlert,
    StockMovement,
    Supplier,
)
from .service import item_costs, move, receive, resolve_unit, unit_options

router = APIRouter()
view = require("inventory.view")
manage = require("inventory.manage")


# ---------------------------------------------------------------- schemas
class PurchaseUnitIn(BaseModel):
    name: str = Field(min_length=1, max_length=20)
    factor: float = Field(gt=0, le=1_000_000)          # stock units in one purchase unit

    @field_validator("name")
    @classmethod
    def _strip(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("نام واحد خالی است")
        return v


class IngredientIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    unit: str = Field(pattern="^(g|kg|ml|l|pcs)$")
    category: str | None = None
    min_stock: float = Field(0, ge=0)
    cost_per_unit: float = Field(0, ge=0)
    opening_stock: float | None = Field(None, ge=0)   # only on create
    is_active: bool = True
    purchase_units: list[PurchaseUnitIn] | None = Field(None, max_length=10)   # None = keep (older clients)

    @model_validator(mode="after")
    def _units(self):
        if self.purchase_units:
            taken = {UNITS[self.unit]} | {n for n, _ in STD_PURCHASE_UNITS.get(self.unit, [])}
            for u in self.purchase_units:
                if u.name in taken:
                    raise ValueError(f"واحد «{u.name}» تکراری است یا از قبل وجود دارد")
                taken.add(u.name)
        return self


class IngredientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    unit: str
    category: str | None
    stock: float
    min_stock: float
    cost_per_unit: float
    is_active: bool
    stock_value: float = 0
    is_low: bool = False
    purchase_units: list[dict] = []
    unit_options: list[dict] = []


class AdjustIn(BaseModel):
    kind: str = Field(pattern="^(waste|adjust)$")
    qty: float                                        # waste: amount wasted (>0); adjust: signed delta
    note: str | None = None


class CountLine(BaseModel):
    ingredient_id: int
    counted: float = Field(ge=0)


class RecipeLineIn(BaseModel):
    ingredient_id: int
    qty: float = Field(gt=0)


class SupplierIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    phone: str | None = None
    note: str | None = None
    is_active: bool = True


class PurchaseLineIn(BaseModel):
    """qty and price are in `purchase_unit` (e.g. 3 کارتن at 2,400,000) — or in the stock unit when it is omitted.
    Send `unit_cost` (price per unit) or `total` (line amount, exact)."""
    ingredient_id: int
    qty: float = Field(gt=0, le=1_000_000)
    unit_cost: float | None = Field(None, ge=0, le=10_000_000_000)
    total: int | None = Field(None, ge=0, le=100_000_000_000)
    purchase_unit: str | None = Field(None, max_length=20)

    @model_validator(mode="after")
    def _price(self):
        if self.unit_cost is None and self.total is None:
            raise ValueError("قیمت واحد یا مبلغ ردیف لازم است")
        return self


class PurchaseIn(BaseModel):
    supplier_id: int | None = None
    invoice_no: str | None = None
    purchase_date: date
    note: str | None = None
    lines: list[PurchaseLineIn] = Field(min_length=1, max_length=200)


def ing_out(i: Ingredient) -> IngredientOut:
    o = IngredientOut.model_validate(i)
    o.stock_value = round(max(i.stock, 0) * i.cost_per_unit)
    o.is_low = i.stock <= i.min_stock
    o.purchase_units = list(i.purchase_units or [])
    o.unit_options = unit_options(i)
    return o


# ---------------------------------------------------------------- negative-stock alerts
class AlertOut(BaseModel):
    id: int
    ingredient_id: int
    name: str
    unit: str
    stock_before: float
    stock_after: float
    shortage: float
    occurrences: int
    last_note: str | None = None
    created_at: datetime | None = None
    resolved_at: datetime | None = None


def alert_out(a: StockAlert) -> AlertOut:
    return AlertOut(id=a.id, ingredient_id=a.ingredient_id, name=a.ingredient.name if a.ingredient else "",
                    unit=a.ingredient.unit if a.ingredient else "", stock_before=a.stock_before, stock_after=a.stock_after,
                    shortage=a.shortage, occurrences=a.occurrences, last_note=a.last_note,
                    created_at=a.created_at, resolved_at=a.resolved_at)


@router.get("/alerts", response_model=list[AlertOut])
def alerts(open_only: bool = True, limit: int = Query(100, ge=1, le=500), db: Session = Depends(get_db), _: User = Depends(view)):
    """Ingredients the system sold below zero (selling is not blocked — this is the manager's to-do list)."""
    q = db.query(StockAlert)
    if open_only:
        q = q.filter(StockAlert.kind == "negative", StockAlert.resolved_at.is_(None))
    return [alert_out(a) for a in q.order_by(StockAlert.id.desc()).limit(limit).all()]


# ---------------------------------------------------------------- ingredients
@router.get("/units")
def units():
    return UNITS


@router.get("/ingredients", response_model=list[IngredientOut])
def list_ingredients(db: Session = Depends(get_db), _: User = Depends(view)):
    return [ing_out(i) for i in db.query(Ingredient).order_by(Ingredient.category, Ingredient.name).all()]


@router.post("/ingredients", response_model=IngredientOut, status_code=201)
def create_ingredient(data: IngredientIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    i = Ingredient(**data.model_dump(exclude={"opening_stock", "purchase_units"}), stock=0,
                   purchase_units=[u.model_dump() for u in data.purchase_units or []])
    db.add(i)
    db.flush()
    if data.opening_stock:
        move(db, i, data.opening_stock, "opening", note="موجودی اول دوره", user_id=user.id)
    db.commit()
    return ing_out(i)


@router.put("/ingredients/{iid}", response_model=IngredientOut)
def update_ingredient(iid: int, data: IngredientIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    i = get_or_404(db, Ingredient, iid, "ماده اولیه")
    for k, v in data.model_dump(exclude={"opening_stock", "purchase_units"}).items():
        setattr(i, k, v)
    if data.purchase_units is not None:
        i.purchase_units = [u.model_dump() for u in data.purchase_units]
    db.commit()
    return ing_out(i)


@router.post("/ingredients/{iid}/adjust", response_model=IngredientOut)
def adjust(iid: int, data: AdjustIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    i = get_or_404(db, Ingredient, iid, "ماده اولیه")
    if data.kind == "waste":
        if data.qty <= 0:
            raise AppError("مقدار ضایعات باید بیشتر از صفر باشد")
        move(db, i, -data.qty, "waste", note=data.note, user_id=user.id)
        log_action(db, user, "inventory.waste", f"ثبت ضایعات {data.qty:g} {UNITS[i.unit]} «{i.name}»"
                   + (f" — {data.note}" if data.note else ""), entity="ingredient", entity_id=i.id,
                   details={"value": round(data.qty * i.cost_per_unit)})
    else:
        move(db, i, data.qty, "adjust", note=data.note, user_id=user.id)
        log_action(db, user, "inventory.adjust", f"اصلاح موجودی «{i.name}» به میزان {data.qty:+g}", entity="ingredient", entity_id=i.id)
    db.commit()
    return ing_out(i)


@router.post("/stock-count", status_code=204)
def stock_count(lines: list[CountLine], db: Session = Depends(get_db), user: User = Depends(manage)):
    """Physical count: sets stock to counted values and records the variance."""
    variance_value = 0.0
    for c in lines:
        i = db.get(Ingredient, c.ingredient_id)
        if not i:
            continue
        diff = round(c.counted - i.stock, 4)
        if diff:
            variance_value += diff * i.cost_per_unit
            move(db, i, diff, "adjust", note="انبارگردانی", user_id=user.id)
    log_action(db, user, "inventory.count", f"ثبت انبارگردانی ({len(lines)} قلم، مغایرت {round(variance_value):,} تومان)")
    db.commit()


# ---------------------------------------------------------------- recipes & food cost
def _recipe_out(rows: list[RecipeLine]) -> list[dict]:
    return [{"ingredient_id": r.ingredient_id, "name": r.ingredient.name, "unit": r.ingredient.unit, "qty": r.qty,
             "cost": round(r.qty * r.ingredient.cost_per_unit)} for r in rows]


@router.get("/recipes/item/{item_id}")
def get_item_recipe(item_id: int, db: Session = Depends(get_db), _: User = Depends(view)):
    return _recipe_out(db.query(RecipeLine).filter(RecipeLine.menu_item_id == item_id).all())


@router.put("/recipes/item/{item_id}")
def set_item_recipe(item_id: int, lines: list[RecipeLineIn], db: Session = Depends(get_db), user: User = Depends(manage)):
    item = get_or_404(db, MenuItem, item_id, "آیتم منو")
    db.query(RecipeLine).filter(RecipeLine.menu_item_id == item_id).delete()
    for l in lines:
        get_or_404(db, Ingredient, l.ingredient_id, "ماده اولیه")
        db.add(RecipeLine(menu_item_id=item_id, ingredient_id=l.ingredient_id, qty=l.qty))
    log_action(db, user, "inventory.recipe", f"ویرایش دستور پخت «{item.name}»", entity="menu_item", entity_id=item_id)
    db.commit()
    return get_item_recipe(item_id, db, user)


@router.get("/recipes/option/{option_id}")
def get_option_recipe(option_id: int, db: Session = Depends(get_db), _: User = Depends(view)):
    return _recipe_out(db.query(RecipeLine).filter(RecipeLine.modifier_option_id == option_id).all())


@router.put("/recipes/option/{option_id}")
def set_option_recipe(option_id: int, lines: list[RecipeLineIn], db: Session = Depends(get_db), user: User = Depends(manage)):
    get_or_404(db, ModifierOption, option_id, "گزینه")
    db.query(RecipeLine).filter(RecipeLine.modifier_option_id == option_id).delete()
    for l in lines:
        db.add(RecipeLine(modifier_option_id=option_id, ingredient_id=l.ingredient_id, qty=l.qty))
    db.commit()
    return get_option_recipe(option_id, db, user)


@router.get("/food-cost")
def food_cost(db: Session = Depends(get_db), _: User = Depends(view)):
    costs = item_costs(db)
    with_recipe = {r[0] for r in db.query(RecipeLine.menu_item_id).filter(RecipeLine.menu_item_id.isnot(None)).distinct()}
    cats = {c.id: c.name for c in db.query(MenuCategory).all()}
    out = []
    for it in db.query(MenuItem).filter(MenuItem.is_active.is_(True)).order_by(MenuItem.category_id, MenuItem.sort).all():
        cost = round(costs.get(it.id, 0))
        out.append({"id": it.id, "name": it.name, "category": cats.get(it.category_id), "price": it.price, "cost": cost,
                    "profit": it.price - cost, "food_cost_pct": round(cost / it.price * 100, 1) if it.price else 0,
                    "has_recipe": it.id in with_recipe})
    return out


# ---------------------------------------------------------------- suppliers
@router.get("/suppliers")
def list_suppliers(db: Session = Depends(get_db), _: User = Depends(view)):
    return [{"id": s.id, "name": s.name, "phone": s.phone, "note": s.note, "is_active": s.is_active}
            for s in db.query(Supplier).order_by(Supplier.name).all()]


@router.post("/suppliers", status_code=201)
def create_supplier(data: SupplierIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    s = Supplier(**data.model_dump())
    db.add(s)
    db.commit()
    return {"id": s.id, **data.model_dump()}


@router.put("/suppliers/{sid}")
def update_supplier(sid: int, data: SupplierIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    s = get_or_404(db, Supplier, sid, "تأمین‌کننده")
    for k, v in data.model_dump().items():
        setattr(s, k, v)
    db.commit()
    return {"id": s.id, **data.model_dump()}


# ---------------------------------------------------------------- purchases
def purchase_out(p: Purchase) -> dict:
    return {"id": p.id, "supplier_id": p.supplier_id, "supplier_name": p.supplier.name if p.supplier else None,
            "invoice_no": p.invoice_no, "purchase_date": p.purchase_date, "total": p.total, "note": p.note,
            "created_at": p.created_at,
            "lines": [{"ingredient_id": l.ingredient_id, "name": l.ingredient.name, "unit": l.ingredient.unit,
                       "qty": l.qty, "unit_cost": l.unit_cost, "total": round(l.qty * l.unit_cost),
                       "purchase_unit": l.pu_name, "pu_qty": l.pu_qty, "pu_factor": l.pu_factor,
                       "pu_price": round(l.unit_cost * l.pu_factor) if l.pu_factor else None} for l in p.lines]}


@router.get("/purchases")
def list_purchases(limit: int = Query(100, le=500), db: Session = Depends(get_db), _: User = Depends(view)):
    return [purchase_out(p) for p in db.query(Purchase).order_by(Purchase.purchase_date.desc(), Purchase.id.desc()).limit(limit).all()]


@router.post("/purchases", status_code=201)
def create_purchase(data: PurchaseIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    p = Purchase(supplier_id=data.supplier_id, invoice_no=data.invoice_no, purchase_date=data.purchase_date,
                 note=data.note, created_by=user.id)
    db.add(p)
    db.flush()
    total = 0.0
    for l in data.lines:
        ing = get_or_404(db, Ingredient, l.ingredient_id, "ماده اولیه")
        factor = resolve_unit(ing, l.purchase_unit)
        line_total = l.total if l.total is not None else l.qty * (l.unit_cost or 0)
        qty = round(l.qty * factor, 6)                       # into stock units
        unit_cost = line_total / qty
        is_pu = factor != 1 or bool(l.purchase_unit and l.purchase_unit.strip() != UNITS.get(ing.unit))
        p.lines.append(PurchaseLine(ingredient_id=ing.id, qty=qty, unit_cost=unit_cost,
                                    pu_name=l.purchase_unit.strip() if is_pu else None, pu_factor=factor if is_pu else None,
                                    pu_qty=l.qty if is_pu else None))
        receive(db, ing, qty, unit_cost, ref_type="purchase", ref_id=p.id,
                note=(f"خرید {data.invoice_no or ''}".strip() + (f" — {l.qty:g} {l.purchase_unit.strip()}" if is_pu else ""))[:200],
                user_id=user.id)
        total += line_total
    p.total = round(total)
    log_action(db, user, "inventory.purchase", f"ثبت فاکتور خرید به مبلغ {p.total:,}", entity="purchase", entity_id=p.id)
    db.commit()
    db.refresh(p)
    return purchase_out(p)


# ---------------------------------------------------------------- movements
@router.get("/movements")
def movements(ingredient_id: int | None = None, kind: str | None = None, limit: int = Query(200, le=1000),
              db: Session = Depends(get_db), _: User = Depends(view)):
    q = db.query(StockMovement).order_by(StockMovement.id.desc())
    if ingredient_id:
        q = q.filter(StockMovement.ingredient_id == ingredient_id)
    if kind:
        q = q.filter(StockMovement.kind == kind)
    return [{"id": m.id, "ingredient_id": m.ingredient_id, "ingredient": m.ingredient.name, "unit": m.ingredient.unit,
             "kind": m.kind, "qty": m.qty, "balance": m.balance, "unit_cost": m.unit_cost,
             "ref_type": m.ref_type, "ref_id": m.ref_id,
             "value": round(m.qty * m.unit_cost), "note": m.note, "created_at": m.created_at} for m in q.limit(limit).all()]
