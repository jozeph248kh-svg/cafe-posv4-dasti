import math
from collections import defaultdict

from sqlalchemy.orm import Session

from app.core.audit import log_action
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import now

from .models import Ingredient, RecipeLine, StockAlert, StockMovement

EPS = 1e-6


def move(db: Session, ing: Ingredient, qty: float, kind: str, *, unit_cost: float | None = None, ref_type=None,
         ref_id=None, note=None, user_id=None) -> StockMovement:
    if not math.isfinite(qty) or abs(qty) > 1e9 or (unit_cost is not None and (not math.isfinite(unit_cost) or unit_cost < 0)):
        raise AppError("مقدار یا قیمت واردشده معتبر نیست", code="invalid_quantity")
    was_low = ing.stock <= ing.min_stock
    before = ing.stock
    ing.stock = round(ing.stock + qty, 4)
    m = StockMovement(ingredient_id=ing.id, kind=kind, qty=qty, unit_cost=ing.cost_per_unit if unit_cost is None else unit_cost,
                      balance=ing.stock, ref_type=ref_type, ref_id=ref_id, note=note, created_by=user_id)
    db.add(m)
    if not was_low and ing.stock <= ing.min_stock:
        publish_after_commit(db, "inventory.low", {"id": ing.id, "name": ing.name, "stock": ing.stock})
    track_negative(db, ing, before, ing.stock, note=note, user_id=user_id, kind=kind, ref_type=ref_type, ref_id=ref_id)
    return m


def track_negative(db: Session, ing: Ingredient, before: float, after: float, *, note=None, user_id=None,
                   kind=None, ref_type=None, ref_id=None) -> StockAlert | None:
    """Keep one open negative-stock alert per ingredient (sale is allowed; the manager must see the shortage).

    * crossing below zero (or going negative again after it was settled) → new alert, realtime event, audit row
    * the shortage growing while the alert is open → the same row is updated (no duplicate alert), event + audit
    * stock back to >= 0 → the alert is closed, so the next negativity opens a fresh one
    """
    open_alert = (db.query(StockAlert)
                  .filter(StockAlert.ingredient_id == ing.id, StockAlert.kind == "negative", StockAlert.resolved_at.is_(None))
                  .order_by(StockAlert.id.desc()).first())
    if after >= -EPS:
        if open_alert:
            open_alert.resolved_at = now()
            open_alert.stock_after = after
            open_alert.shortage = 0
            publish_after_commit(db, "inventory.negative", {"id": open_alert.id, "ingredient_id": ing.id,
                                                            "name": ing.name, "resolved": True, "stock_after": after})
        return None
    if open_alert and after >= open_alert.stock_after - EPS:
        return open_alert                      # same (or smaller) shortage: don't spam a second alert
    if open_alert:
        open_alert.stock_after, open_alert.shortage = after, round(-after, 4)
        open_alert.occurrences += 1
        open_alert.last_note = (note or "")[:200] or None
    else:
        open_alert = StockAlert(ingredient_id=ing.id, kind="negative", stock_before=round(before, 4),
                                stock_after=after, shortage=round(-after, 4), last_note=(note or "")[:200] or None)
        db.add(open_alert)
    db.flush()                                 # the alert id / payload is needed below (and by the audit row)
    user = db.get(User, user_id) if user_id else None
    log_action(db, user, "inventory.negative",
               f"موجودی «{ing.name}» منفی شد: {open_alert.stock_after:g} {ing.unit} — کسری {open_alert.shortage:g}",
               entity="ingredient", entity_id=ing.id,
               details={"stock_before": round(before, 4), "stock_after": open_alert.stock_after,
                        "shortage": open_alert.shortage, "movement": kind, "ref_type": ref_type, "ref_id": ref_id,
                        "occurrences": open_alert.occurrences})
    publish_after_commit(db, "inventory.negative",
                         {"id": open_alert.id, "ingredient_id": ing.id, "name": ing.name, "unit": ing.unit,
                          "stock_before": round(before, 4), "stock_after": open_alert.stock_after,
                          "shortage": open_alert.shortage, "occurrences": open_alert.occurrences, "resolved": False})
    return open_alert


def open_alerts(db: Session) -> list[StockAlert]:
    return (db.query(StockAlert).filter(StockAlert.kind == "negative", StockAlert.resolved_at.is_(None))
            .order_by(StockAlert.id.desc()).all())


def unit_options(ing: Ingredient) -> list[dict]:
    """Units an ingredient can be bought in: the stock unit, the built-in conversions, then its own (carton, box…)."""
    from .models import STD_PURCHASE_UNITS, UNITS
    out = [{"name": UNITS.get(ing.unit, ing.unit), "factor": 1, "base": True}]
    out += [{"name": n, "factor": f} for n, f in STD_PURCHASE_UNITS.get(ing.unit, [])]
    out += [{"name": u["name"], "factor": u["factor"]} for u in (ing.purchase_units or [])]
    return out


def resolve_unit(ing: Ingredient, name: str | None) -> float:
    """Factor (stock units per purchase unit) for a unit name; the server never trusts a client-sent factor."""
    if not name:
        return 1
    for u in unit_options(ing):
        if u["name"] == name.strip():
            return float(u["factor"])
    from app.core.errors import AppError
    raise AppError(f"واحد «{name}» برای «{ing.name}» تعریف نشده است", status_code=422, code="unit_unknown")


def receive(db: Session, ing: Ingredient, qty: float, unit_cost: float, **kw) -> None:
    """Purchase receipt with weighted-average costing."""
    old_qty = max(ing.stock, 0)
    total_qty = old_qty + qty
    if total_qty > 0:
        ing.cost_per_unit = round((old_qty * ing.cost_per_unit + qty * unit_cost) / total_qty, 4)
    move(db, ing, qty, "purchase", unit_cost=unit_cost, **kw)


def usage_for_lines(db: Session, lines) -> dict[int, float]:
    """Total ingredient usage for order lines (item recipe + chosen modifier recipes) × qty."""
    item_ids = {l.menu_item_id for l in lines}
    opt_ids = {m["id"] for l in lines for m in (l.modifiers or [])}
    rec = db.query(RecipeLine).filter((RecipeLine.menu_item_id.in_(item_ids)) | (RecipeLine.modifier_option_id.in_(opt_ids))).all()
    by_item, by_opt = defaultdict(list), defaultdict(list)
    for r in rec:
        (by_item[r.menu_item_id] if r.menu_item_id else by_opt[r.modifier_option_id]).append(r)
    usage: dict[int, float] = defaultdict(float)
    for l in lines:
        for r in by_item.get(l.menu_item_id, []):
            usage[r.ingredient_id] += r.qty * l.qty
        for m in l.modifiers or []:
            for r in by_opt.get(m["id"], []):
                usage[r.ingredient_id] += r.qty * l.qty
    return usage


def item_costs(db: Session) -> dict[int, float]:
    """Cost of one unit of a menu item from its own recipe (today's weighted-average prices).

    The recipe of a *modifier* cannot be part of a per-item number (a modifier is chosen per line), so the
    line-level COGS in the reports comes from the frozen snapshot instead — see `costing.line_costs()`.
    """
    from .costing import base_item_costs
    return base_item_costs(db)
