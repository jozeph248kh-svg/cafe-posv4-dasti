from datetime import date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin

UNITS = {"g": "گرم", "kg": "کیلوگرم", "ml": "میلی‌لیتر", "l": "لیتر", "pcs": "عدد"}
# Built-in purchase units for each stock unit: (label, how many stock units one purchase unit is)
STD_PURCHASE_UNITS = {"g": [("کیلوگرم", 1000)], "ml": [("لیتر", 1000)], "kg": [("گرم", 0.001)], "l": [("میلی‌لیتر", 0.001)], "pcs": []}


class Ingredient(Base, TimestampMixin):
    __tablename__ = "ingredients"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    unit: Mapped[str] = mapped_column(String(5), default="g")
    category: Mapped[str | None] = mapped_column(String(40))
    stock: Mapped[float] = mapped_column(Float, default=0)
    min_stock: Mapped[float] = mapped_column(Float, default=0)
    cost_per_unit: Mapped[float] = mapped_column(Float, default=0)        # toman per unit (weighted average)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # extra units it is bought in, e.g. [{"name": "کارتن", "factor": 12000}] = one carton is 12000 stock units (g)
    purchase_units: Mapped[list] = mapped_column(JSON, default=list, server_default=text("'[]'"))


class RecipeLine(Base):
    """Ingredient usage for one menu item (or a modifier option, e.g. 'شیر بادام')."""
    __tablename__ = "recipe_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    menu_item_id: Mapped[int | None] = mapped_column(ForeignKey("menu_items.id", ondelete="CASCADE"), index=True)
    modifier_option_id: Mapped[int | None] = mapped_column(ForeignKey("modifier_options.id", ondelete="CASCADE"), index=True)
    ingredient_id: Mapped[int] = mapped_column(ForeignKey("ingredients.id"))
    qty: Mapped[float] = mapped_column(Float)
    ingredient: Mapped[Ingredient] = relationship(lazy="joined")


class Supplier(Base, TimestampMixin):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20))
    note: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Purchase(Base, TimestampMixin):
    __tablename__ = "purchases"
    id: Mapped[int] = mapped_column(primary_key=True)
    supplier_id: Mapped[int | None] = mapped_column(ForeignKey("suppliers.id"))
    invoice_no: Mapped[str | None] = mapped_column(String(40))
    purchase_date: Mapped[date] = mapped_column(Date)
    total: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    supplier: Mapped[Supplier | None] = relationship(lazy="joined")
    lines: Mapped[list["PurchaseLine"]] = relationship(cascade="all, delete-orphan", order_by="PurchaseLine.id")


class PurchaseLine(Base):
    __tablename__ = "purchase_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    purchase_id: Mapped[int] = mapped_column(ForeignKey("purchases.id", ondelete="CASCADE"), index=True)
    ingredient_id: Mapped[int] = mapped_column(ForeignKey("ingredients.id"))
    qty: Mapped[float] = mapped_column(Float)                    # in stock units (what entered the store)
    unit_cost: Mapped[float] = mapped_column(Float)              # per stock unit
    pu_name: Mapped[str | None] = mapped_column(String(20))      # as written on the supplier's invoice, e.g. 3 کارتن
    pu_factor: Mapped[float | None] = mapped_column(Float)
    pu_qty: Mapped[float | None] = mapped_column(Float)
    ingredient: Mapped[Ingredient] = relationship(lazy="joined")


class StockMovement(Base, TimestampMixin):
    __tablename__ = "stock_movements"
    __table_args__ = (Index("ix_stock_movements_ref", "ref_type", "ref_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    ingredient_id: Mapped[int] = mapped_column(ForeignKey("ingredients.id"), index=True)
    kind: Mapped[str] = mapped_column(String(12), index=True)   # purchase|sale|return|waste|adjust|opening
    qty: Mapped[float] = mapped_column(Float)                   # signed change
    unit_cost: Mapped[float] = mapped_column(Float, default=0)
    balance: Mapped[float] = mapped_column(Float, default=0)    # stock after movement
    ref_type: Mapped[str | None] = mapped_column(String(20))
    ref_id: Mapped[int | None] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    ingredient: Mapped[Ingredient] = relationship(lazy="joined")


class StockAlert(Base, TimestampMixin):
    """One open row per ingredient whose stock went below zero.

    Selling is never blocked (the café keeps selling; the shortage is a *counting* problem, not a reason to stop
    the till), but a manager has to see it. Repeating the same condition does not create a second row — an open
    alert is only updated when the shortage actually grows, and a new row is opened after the stock is back to
    zero and goes negative again.
    """
    __tablename__ = "inventory_alerts"
    id: Mapped[int] = mapped_column(primary_key=True)
    ingredient_id: Mapped[int] = mapped_column(ForeignKey("ingredients.id"), index=True)
    kind: Mapped[str] = mapped_column(String(12), default="negative", index=True)
    stock_before: Mapped[float] = mapped_column(Float, default=0)      # stock just before it went negative
    stock_after: Mapped[float] = mapped_column(Float, default=0)       # stock after the last movement
    shortage: Mapped[float] = mapped_column(Float, default=0)          # how much the stock is short (= −stock_after)
    occurrences: Mapped[int] = mapped_column(Integer, default=1)       # times the shortage grew in this episode
    last_note: Mapped[str | None] = mapped_column(String(200))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)     # set when the stock is back to >= 0
    ingredient: Mapped[Ingredient] = relationship(lazy="joined")
