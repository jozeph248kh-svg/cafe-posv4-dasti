from sqlalchemy.orm import Session

from app.modules.menu.models import MenuItem, ModifierOption

from .models import Ingredient, RecipeLine, StockMovement, Supplier

# name, unit, category, stock, min, cost/unit (toman)
INGREDIENTS = {
    "coffee": ("دانه قهوه عربیکا", "g", "بار", 6000, 1500, 2_200),
    "milk": ("شیر پرچرب", "ml", "لبنیات", 40000, 8000, 65),
    "almond": ("شیر بادام", "ml", "لبنیات", 6000, 2000, 320),
    "soy": ("شیر سویا", "ml", "لبنیات", 5000, 2000, 240),
    "lf_milk": ("شیر بدون لاکتوز", "ml", "لبنیات", 4000, 2000, 150),
    "choc": ("پودر شکلات", "g", "بار", 3000, 800, 1_100),
    "caramel": ("سیروپ کارامل", "ml", "بار", 3000, 700, 900),
    "vanilla": ("سیروپ وانیل", "ml", "بار", 2500, 700, 900),
    "hazelnut": ("سیروپ فندق", "ml", "بار", 1200, 700, 950),
    "lemon": ("لیمو ترش تازه", "pcs", "میوه و سبزی", 120, 30, 9_000),
    "mint": ("نعناع تازه", "g", "میوه و سبزی", 800, 200, 600),
    "icecream": ("بستنی وانیلی", "g", "لبنیات", 5000, 1500, 240),
    "egg": ("تخم‌مرغ", "pcs", "لبنیات", 180, 60, 7_500),
    "beef": ("گوشت چرخ‌کرده گوساله", "g", "پروتئین", 12000, 3000, 820),
    "fillet": ("فیله گوساله", "g", "پروتئین", 5000, 1500, 1_900),
    "chicken": ("سینه مرغ", "g", "پروتئین", 10000, 3000, 420),
    "bun": ("نان برگر", "pcs", "نان", 80, 25, 18_000),
    "cheddar": ("پنیر چدار", "g", "لبنیات", 3000, 800, 1_400),
    "mozzarella": ("پنیر موزارلا", "g", "لبنیات", 8000, 2000, 720),
    "dough": ("خمیر پیتزا", "pcs", "نان", 40, 12, 35_000),
    "pasta": ("پاستا خشک", "g", "خشکبار", 9000, 2000, 210),
    "potato": ("سیب‌زمینی خلالی منجمد", "g", "منجمد", 20000, 5000, 190),
    "lettuce": ("کاهو رسمی", "g", "میوه و سبزی", 4000, 1000, 160),
    "cream": ("خامه پخت", "ml", "لبنیات", 5000, 1500, 260),
    "cheesecake": ("چیزکیک (برش)", "pcs", "دسر", 14, 6, 95_000),
}

RECIPES = {  # menu code -> [(ingredient, qty)]
    "101": [("coffee", 18)], "102": [("coffee", 18)],
    "103": [("coffee", 18), ("milk", 150)], "104": [("coffee", 18), ("milk", 220)],
    "105": [("coffee", 18), ("milk", 180), ("choc", 25)], "106": [("coffee", 18), ("milk", 200), ("caramel", 20), ("vanilla", 10)],
    "107": [("milk", 250), ("choc", 35)], "201": [("coffee", 18)], "202": [("coffee", 18), ("milk", 200)],
    "203": [("lemon", 1), ("mint", 10)], "204": [("lemon", 2)], "206": [("icecream", 150), ("milk", 150), ("choc", 20)],
    "301": [("egg", 3)], "302": [("egg", 2)], "401": [("potato", 250)], "402": [("potato", 250), ("cheddar", 40)],
    "501": [("lettuce", 150), ("chicken", 120)], "601": [("pasta", 140), ("cream", 120), ("chicken", 100)],
    "602": [("pasta", 140), ("beef", 120)], "603": [("pasta", 140)],
    "701": [("dough", 1), ("mozzarella", 180)], "702": [("dough", 1), ("mozzarella", 180)],
    "703": [("dough", 1), ("mozzarella", 200), ("beef", 60), ("chicken", 60)],
    "801": [("fillet", 250), ("potato", 150)], "802": [("bun", 1), ("beef", 180), ("potato", 150)],
    "803": [("bun", 1), ("beef", 300), ("cheddar", 40), ("potato", 150)], "804": [("chicken", 250), ("potato", 150)],
    "805": [("chicken", 220), ("egg", 1), ("potato", 150)], "901": [("cheesecake", 1)], "904": [("icecream", 200)],
}

OPTION_RECIPES = {  # modifier option name -> [(ingredient, qty)]
    "شیر بادام": [("almond", 200)], "شیر سویا": [("soy", 200)], "بدون لاکتوز": [("lf_milk", 200)],
    "یک شات اضافه": [("coffee", 9)], "کارامل": [("caramel", 15)], "وانیل": [("vanilla", 15)], "فندق": [("hazelnut", 15)],
    "پنیر چدار اضافه": [("cheddar", 30)], "تخم‌مرغ": [("egg", 1)],
}


def seed(db: Session) -> None:
    if db.query(Ingredient).count():
        return
    ings = {}
    for key, (name, unit, cat, stock, mn, cost) in INGREDIENTS.items():
        i = Ingredient(name=name, unit=unit, category=cat, stock=stock, min_stock=mn, cost_per_unit=cost)
        db.add(i)
        ings[key] = i
    db.flush()
    for i in ings.values():
        db.add(StockMovement(ingredient_id=i.id, kind="opening", qty=i.stock, unit_cost=i.cost_per_unit, balance=i.stock, note="موجودی اول دوره"))
    items = {m.code: m for m in db.query(MenuItem).all() if m.code}
    for code, rows in RECIPES.items():
        if code in items:
            for key, qty in rows:
                db.add(RecipeLine(menu_item_id=items[code].id, ingredient_id=ings[key].id, qty=qty))
    for opt in db.query(ModifierOption).all():
        for key, qty in OPTION_RECIPES.get(opt.name, []):
            db.add(RecipeLine(modifier_option_id=opt.id, ingredient_id=ings[key].id, qty=qty))
    db.add_all([Supplier(name="رست قهوه آریا", phone="02188776655"), Supplier(name="لبنیات پگاه", phone="02144332211"),
                Supplier(name="پروتئین طلایی", phone="02166554433"), Supplier(name="میدان تره‌بار", phone=None)])
