"""Cost of goods sold — frozen at the moment of the sale, and the separate "replacement cost" indicator.

Why this module exists
----------------------
The reports used to value every sold line at the *current* weighted-average cost of its ingredients. Two things
were wrong with that:

* a purchase at a higher price changed the profit of sales that were already made (inflation rewrote history);
* only the **base** recipe was counted — a modifier's recipe left the store (it was deducted from stock) but its
  cost never reached COGS.

So a line's material cost is now computed once, when the bill closes, and stored on the line (`cost_amount`):
  item recipe + every recipe of the modifiers actually chosen, at the weighted-average cost of that moment.
Reports read that frozen number. The valuation method itself stays the approved one (weighted average, computed
at receipt in `service.receive()`); what is frozen is only the historical figure.

`replacement_cost()` answers a different question — "what would the same materials cost at today's prices?" — and
is reported as its own indicator. It never replaces historical COGS.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.modules.orders.models import Order, OrderLine, OrderRefundLine

from .models import Ingredient, RecipeLine, StockMovement
from .service import usage_for_lines

EPS = 1e-9


# ---------------------------------------------------------------- at sale time
def line_cost(db: Session, line) -> float:
    """Material cost of one order line right now (base recipe + the modifiers chosen on that line)."""
    usage = usage_for_lines(db, [line])
    total = 0.0
    for ing_id, qty in usage.items():
        ing = db.get(Ingredient, ing_id)
        if ing:
            total += qty * (ing.cost_per_unit or 0)
    return round(total, 4)


def snapshot_line_costs(db: Session, order) -> None:
    """Freeze the material cost of every line of a bill that is being closed (idempotent)."""
    for ln in order.lines:
        if ln.cost_amount is None:
            ln.cost_amount = line_cost(db, ln)


# ---------------------------------------------------------------- at report time
def _usage_weights(db: Session, lines) -> dict[int, float]:
    """Current-recipe cost of each line — used only as a weight to split legacy orders that have no snapshot."""
    return {ln.id: line_cost(db, ln) for ln in lines}


def _order_movement_costs(db: Session, order_ids: list[int]) -> dict[int, float]:
    """Historical cost of every order's own `sale` movements (the unit cost frozen when the sale happened)."""
    if not order_ids:
        return {}
    rows = (db.query(StockMovement.ref_id, func.sum(-StockMovement.qty * StockMovement.unit_cost))
            .filter(StockMovement.kind == "sale", StockMovement.ref_type == "order",
                    StockMovement.ref_id.in_(order_ids))
            .group_by(StockMovement.ref_id).all())
    return {rid: float(cost or 0) for rid, cost in rows}


def _allocate_legacy(db: Session, legacy: list, snapshot_sum: dict[int, float]) -> tuple[dict[int, float], dict[int, str]]:
    """Cost of the lines that have no frozen snapshot — the residual of their own order's movement.

    The movement of an order covers **all** its lines. What belongs to the legacy lines is therefore only
    `movement − Σ(snapshots of that same order)`; allocating the whole movement over the legacy lines counted the
    frozen lines twice (reported by the audit: a bill whose materials cost 250 was reported as 350).

    Returns (cost per line id, status per line id):
      * "estimated" — reconstructed from a real historical sale movement (auditable)
      * "unknown"   — no usable movement (none recorded, or already fully explained by the snapshots): the cost
                      cannot be reconstructed, so it is reported as unknown instead of a confident 0.
    """
    by_order: dict[int, list] = defaultdict(list)
    for ln in legacy:
        by_order[ln.order_id].append(ln)
    movement = _order_movement_costs(db, list(by_order))
    costs: dict[int, float] = {}
    status: dict[int, str] = {}
    for oid, group in by_order.items():
        total = movement.get(oid)
        residual = None if total is None else total - snapshot_sum.get(oid, 0.0)
        if residual is None or residual <= EPS:
            for ln in group:                     # nothing to attribute: never invent a number
                costs[ln.id], status[ln.id] = 0.0, "unknown"
            continue
        weights = _usage_weights(db, [db.get(OrderLine, ln.id) for ln in group])
        total_w = sum(weights.values())
        for ln in group:
            share = (weights[ln.id] / total_w) if total_w > EPS else 1 / len(group)
            costs[ln.id], status[ln.id] = round(residual * share, 4), "estimated"
    return costs, status


def line_costs(db: Session, d1: date, d2: date) -> list[dict]:
    """The material cost of every sold line of the range — **before** any return.

    * `gross`  — the frozen cost of all units of the line (snapshot at the sale, or reconstructed; see `status`)
    * `status` — "snapshot" · "estimated" (from that order's historical movements) · "unknown" (not reconstructable)
    The cost of a physical return is *not* subtracted here: it is a separate event, booked on the day the goods
    came back (see `refund_facts`). That keeps a closed sale day untouched forever.
    """
    lines = (db.query(OrderLine.id, OrderLine.order_id, OrderLine.menu_item_id, OrderLine.qty, OrderLine.returned_qty,
                      OrderLine.cost_amount, Order.business_date, Order.status)
             .join(Order, Order.id == OrderLine.order_id)
             .filter(Order.business_date >= d1, Order.business_date <= d2,
                     Order.status == "closed", OrderLine.status != "void").all())
    legacy = [ln for ln in lines if ln.cost_amount is None]
    fallback: dict[int, float] = {}
    status_by_line: dict[int, str] = {}
    if legacy:
        snapshot_sum: dict[int, float] = defaultdict(float)
        for ln in lines:
            if ln.cost_amount is not None:
                snapshot_sum[ln.order_id] += float(ln.cost_amount)
        fallback, status_by_line = _allocate_legacy(db, legacy, snapshot_sum)
    out = []
    for ln in lines:
        if ln.cost_amount is not None:
            gross, status = float(ln.cost_amount), "snapshot"
        else:
            gross, status = fallback.get(ln.id, 0.0), status_by_line.get(ln.id, "unknown")
        out.append({"line_id": ln.id, "order_id": ln.order_id, "item_id": ln.menu_item_id,
                    "business_date": ln.business_date, "qty": int(ln.qty or 0),
                    "returned_qty": int(ln.returned_qty or 0), "gross": round(gross, 4),
                    "unit_cost": round(gross / ln.qty, 4) if ln.qty else 0.0,
                    "status": status, "estimated": status == "estimated", "unknown": status == "unknown"})
    return out


def refund_facts(db: Session, d1: date, d2: date) -> list[dict]:
    """Physical returns booked **on the day they happened** (the event table, not the sale).

    Each row: the sold line, how many units came back, the frozen unit cost of that line, and the event's own
    business day. A refund that only moved money has no row here — the goods were never returned, so the material
    cost of the sale stays where it was.
    """
    from app.core import settings_store
    from app.core.utils import business_day, day_bounds
    from app.modules.orders.models import OrderRefundLine

    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    start, end = day_bounds(d1, cutoff)[0], day_bounds(d2, cutoff)[1]
    rows = (db.query(OrderRefundLine, OrderLine.menu_item_id, OrderLine.qty.label("sold_qty"))
            .join(OrderLine, OrderLine.id == OrderRefundLine.line_id)
            .filter(OrderRefundLine.created_at >= start, OrderRefundLine.created_at < end).all())
    out = []
    for ev, item_id, _sold in rows:
        unit = ev.unit_cost
        out.append({"id": ev.id, "order_id": ev.order_id, "line_id": ev.line_id, "item_id": item_id,
                    "qty": float(ev.qty or 0), "unit_cost": None if unit is None else float(unit),
                    "amount": round(-(float(ev.qty or 0) * float(unit)), 4) if unit is not None else 0.0,
                    "unknown_cost": unit is None,
                    "business_date": business_day(ev.created_at, cutoff),
                    "created_at": ev.created_at, "kind": ev.kind, "source": ev.source,
                    "refund_payment_id": ev.refund_payment_id})
    return out


def legacy_return_facts(db: Session, d1: date, d2: date) -> list[dict]:
    """Returns that only exist as `order_lines.returned_qty` (a database from before the event table).

    Their date was never recorded, so they stay on the sale day — exactly as before this change — and are marked
    `source="legacy"`. Nothing is guessed: no date, no quantity and no cost is invented.
    """
    events_by_line: dict[int, float] = defaultdict(float)
    for ev in (db.query(OrderRefundLine.line_id, func.sum(OrderRefundLine.qty))
               .group_by(OrderRefundLine.line_id).all()):
        events_by_line[ev[0]] = float(ev[1] or 0)
    out = []
    for ln in line_costs(db, d1, d2):
        leftover = ln["returned_qty"] - events_by_line.get(ln["line_id"], 0.0)
        if leftover <= EPS:
            continue
        leftover = min(leftover, ln["qty"])
        out.append({"line_id": ln["line_id"], "order_id": ln["order_id"], "item_id": ln["item_id"],
                    "qty": leftover, "unit_cost": ln["unit_cost"],
                    "amount": round(-leftover * ln["unit_cost"], 4), "unknown_cost": ln["unknown"],
                    "business_date": ln["business_date"], "source": "legacy"})
    return out


def _sum_by(rows: list[dict], key) -> dict:
    out: dict = defaultdict(float)
    for r in rows:
        out[key(r)] += r.get("amount", 0.0)
    return out


def cogs_by_day(db: Session, d1: date, d2: date) -> dict[date, float]:
    """The one source every report uses: sold material on its sale day, minus returns on the day they happened."""
    out: dict[date, float] = defaultdict(float)
    for ln in line_costs(db, d1, d2):
        out[ln["business_date"]] += ln["gross"]
    for row in refund_facts(db, d1, d2) + legacy_return_facts(db, d1, d2):
        out[row["business_date"]] += row["amount"]
    return out


def cogs_by_item(db: Session, d1: date, d2: date) -> dict[int, float]:
    out: dict[int, float] = defaultdict(float)
    for ln in line_costs(db, d1, d2):
        out[ln["item_id"]] += ln["gross"]
    for row in refund_facts(db, d1, d2) + legacy_return_facts(db, d1, d2):
        out[row["item_id"]] += row["amount"]
    return out


def cogs_by_order(db: Session, d1: date, d2: date) -> dict[int, float]:
    out: dict[int, float] = defaultdict(float)
    for ln in line_costs(db, d1, d2):
        out[ln["order_id"]] += ln["gross"]
    for row in refund_facts(db, d1, d2) + legacy_return_facts(db, d1, d2):
        out[row["order_id"]] += row["amount"]
    return out


def cogs_total(db: Session, d1: date, d2: date) -> tuple[float, int, int, int]:
    """(net COGS of the range, estimated sale lines, unknown sale lines, returns whose cost is unknown)."""
    lines = line_costs(db, d1, d2)
    refunds = refund_facts(db, d1, d2)
    legacy = legacy_return_facts(db, d1, d2)
    net = sum(ln["gross"] for ln in lines) + sum(r["amount"] for r in refunds) + sum(r["amount"] for r in legacy)
    return (round(net, 4), sum(1 for ln in lines if ln["estimated"]), sum(1 for ln in lines if ln["unknown"]),
            sum(1 for r in refunds if r["unknown_cost"]))


# ---------------------------------------------------------------- replacement cost (today's prices)
def _line_replacement_cost(db: Session, line, costs: dict[int, float]) -> float:
    """What this line's materials would cost at today's weighted average (modifier recipes included)."""
    if not (line.modifiers or []):
        return costs.get(line.menu_item_id, 0.0) * line.qty
    return line_cost(db, line)


def replacement_cost(db: Session, d1: date, d2: date) -> tuple[float, int]:
    """(replacement cost of the materials consumed in the range at TODAY's prices, lines without a recipe).

    "Consumed" is the same set of events COGS uses: the materials of the sold lines **minus the units a return
    gave back to the shelf in this range**. The two indicators then move together, but with different prices
    (historical for COGS, today's for this one) — which is the whole point of having both.
    """
    costs = base_item_costs(db)
    lines = (db.query(OrderLine, Order.status)
             .join(Order, Order.id == OrderLine.order_id)
             .filter(Order.business_date >= d1, Order.business_date <= d2,
                     Order.status == "closed", OrderLine.status != "void").all())
    total, missing = 0.0, 0
    for ln, _status in lines:
        total += _line_replacement_cost(db, ln, costs)
        if not costs.get(ln.menu_item_id) and not (ln.modifiers or []):
            missing += 1
    for ev in refund_facts(db, d1, d2) + legacy_return_facts(db, d1, d2):
        line = db.get(OrderLine, ev["line_id"])
        if line is None or not line.qty:
            continue
        total -= _line_replacement_cost(db, line, costs) * (ev["qty"] / line.qty)   # what came back
    return round(total, 4), missing


def base_item_costs(db: Session) -> dict[int, float]:
    """Cost of one unit of a menu item from its own recipe, at today's weighted-average prices."""
    costs: dict[int, float] = defaultdict(float)
    for r in db.query(RecipeLine).filter(RecipeLine.menu_item_id.isnot(None)).all():
        costs[r.menu_item_id] += r.qty * (r.ingredient.cost_per_unit or 0)
    return costs
