from app.core.modules import Module

from .handlers import setup
from .router import router
from .seed import seed

module = Module(
    name="inventory",
    title="انبار و بهای تمام‌شده",
    description="مواد اولیه، دستور پخت، کسر خودکار از انبار، خرید، ضایعات، انبارگردانی و فودکاست",
    depends=["menu", "orders"],
    routers=[router],
    permissions={"inventory.view": "مشاهده انبار", "inventory.manage": "مدیریت انبار، خرید و دستور پخت"},
    seed=seed,
    setup=setup,
)
