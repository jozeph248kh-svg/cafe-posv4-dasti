from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin


class Courier(Base, TimestampMixin):
    __tablename__ = "couriers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20))
    vehicle: Mapped[str] = mapped_column(String(10), default="motor")    # motor | car | bike
    plate: Mapped[str | None] = mapped_column(String(30))
    default_fee: Mapped[int] = mapped_column(Integer, default=0)        # pay per delivery when the zone has no courier fee
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str | None] = mapped_column(Text)


class DeliveryZone(Base, TimestampMixin):
    __tablename__ = "delivery_zones"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    customer_fee: Mapped[int] = mapped_column(Integer, default=0)       # added to the bill
    courier_fee: Mapped[int] = mapped_column(Integer, default=0)        # paid to the courier
    eta_minutes: Mapped[int] = mapped_column(Integer, default=30)
    min_order: Mapped[int] = mapped_column(Integer, default=0)
    sort: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Delivery(Base, TimestampMixin):
    """Delivery details of an order (1:1). Kept in its own table so the orders module stays untouched."""
    __tablename__ = "deliveries"
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), primary_key=True)
    zone_id: Mapped[int | None] = mapped_column(ForeignKey("delivery_zones.id"))
    courier_id: Mapped[int | None] = mapped_column(ForeignKey("couriers.id"), index=True)
    status: Mapped[str] = mapped_column(String(10), default="waiting", index=True)   # waiting|assigned|out|delivered|failed|cancelled
    customer_fee: Mapped[int] = mapped_column(Integer, default=0)
    courier_fee: Mapped[int] = mapped_column(Integer, default=0)
    collect: Mapped[bool] = mapped_column(Boolean, default=False)       # courier collects the bill in cash at the door
    fee_line_id: Mapped[int | None] = mapped_column(Integer)
    assigned_at: Mapped[datetime | None] = mapped_column(DateTime)
    out_at: Mapped[datetime | None] = mapped_column(DateTime)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime)
    settlement_id: Mapped[int | None] = mapped_column(ForeignKey("courier_settlements.id"), index=True)
    note: Mapped[str | None] = mapped_column(String(200))
    zone: Mapped[DeliveryZone | None] = relationship(lazy="joined")
    courier: Mapped[Courier | None] = relationship(lazy="joined")


class CourierSettlement(Base, TimestampMixin):
    __tablename__ = "courier_settlements"
    id: Mapped[int] = mapped_column(primary_key=True)
    courier_id: Mapped[int] = mapped_column(ForeignKey("couriers.id"), index=True)
    deliveries: Mapped[int] = mapped_column(Integer, default=0)
    fees: Mapped[int] = mapped_column(Integer, default=0)               # owed to the courier
    collected: Mapped[int] = mapped_column(Integer, default=0)          # cash the courier brought back
    net: Mapped[int] = mapped_column(Integer, default=0)                # collected - fees (+ = courier pays us)
    method: Mapped[str] = mapped_column(String(10), default="cash")
    note: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    courier: Mapped[Courier] = relationship(lazy="joined")
