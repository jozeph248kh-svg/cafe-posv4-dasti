import random
from collections import defaultdict
from datetime import timedelta

from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.models import User
from app.core.permissions import grant_once
from app.core.utils import business_day

from . import service as S
from .models import Courier, CourierSettlement, Delivery, DeliveryZone

ZONES = [("محدوده ۱ — تا ۲ کیلومتر", 40_000, 35_000, 20), ("محدوده ۲ — ۲ تا ۴ کیلومتر", 60_000, 50_000, 30),
         ("محدوده ۳ — ۴ تا ۷ کیلومتر", 90_000, 75_000, 40), ("محدوده ۴ — بیش از ۷ کیلومتر", 130_000, 110_000, 55)]


def seed(db: Session) -> None:
    grant_once(db, "delivery", {"manager": ["delivery.dispatch", "delivery.manage"], "cashier": ["delivery.dispatch"]})
    if not db.query(DeliveryZone).count():
        for i, (name, cf, kf, eta) in enumerate(ZONES):
            db.add(DeliveryZone(name=name, customer_fee=cf, courier_fee=kf, eta_minutes=eta, sort=i))
    S.fee_item(db)


def demo(db: Session) -> None:
    from app.modules.orders.models import Order
    if db.query(Courier).count():
        return
    rng = random.Random(5)
    couriers = [Courier(name=n, phone=p, vehicle=v, plate=pl, default_fee=40_000) for n, p, v, pl in (
        ("مهدی رنجبر", "09121112233", "motor", "۲۳۴ ـ ۵۶۷۸۹"), ("جواد کیانی", "09352223344", "motor", "۱۱۸ ـ ۲۴۶۸۰"),
        ("حسین نادری", "09193334455", "car", "۴۴ ج ۵۵۵ ـ ۱۰"), ("امیر سلطانی", "09104445566", "motor", "۷۷۱ ـ ۳۳۲۱۹"))]
    db.add_all(couriers)
    db.flush()
    zones = db.query(DeliveryZone).order_by(DeliveryZone.sort, DeliveryZone.id).all()
    admin = db.query(User).filter(User.username == "reza").first()
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    groups = defaultdict(list)
    for o in db.query(Order).filter(Order.type == "delivery", Order.status != "cancelled").order_by(Order.id).all():
        z = rng.choices(zones, weights=[4, 4, 2, 1])[0]
        c = rng.choice(couriers)
        d = Delivery(order_id=o.id, zone_id=z.id, courier_id=c.id, customer_fee=0, courier_fee=z.courier_fee, collect=False)
        if o.status == "closed":
            d.status = "delivered"
            d.assigned_at = o.created_at + timedelta(minutes=rng.randint(4, 12))
            d.out_at = d.assigned_at + timedelta(minutes=rng.randint(3, 10))
            d.delivered_at = d.out_at + timedelta(minutes=z.eta_minutes + rng.randint(-8, 10))
            if o.business_date < today:
                groups[(c.id, o.business_date)].append(d)
        else:
            d.status = rng.choice(["waiting", "assigned", "out"])
            if d.status == "waiting":
                d.courier_id = None
        db.add(d)
    db.flush()
    _live_orders(db, rng, couriers, zones)
    for (cid, _day), ds in groups.items():
        last = max(x.delivered_at for x in ds)
        fees = sum(x.courier_fee for x in ds)
        st = CourierSettlement(courier_id=cid, deliveries=len(ds), fees=fees, collected=0, net=-fees, method="cash", created_by=admin.id if admin else None)
        db.add(st)
        db.flush()
        st.created_at = last + timedelta(minutes=30)
        for x in ds:
            x.settlement_id = st.id


LIVE = [("نسترن پاکزاد", "09125550101", "سعادت‌آباد، خیابان سرو غربی، پلاک ۱۸، واحد ۴", "waiting", False),
        ("کامران فلاحی", "09125550202", "شهرک غرب، بلوار دریا، کوچه گلها، پلاک ۷", "waiting", True),
        ("لیلا میرزایی", "09125550303", "یوسف‌آباد، خیابان ۳۳، پلاک ۲۱، طبقه دوم", "assigned", True),
        ("سهیل اکبرزاده", "09125550404", "ونک، خیابان ملاصدرا، کوچه شیراز، پلاک ۴", "out", True),
        ("فرناز کریمی", "09125550505", "جردن، خیابان طاهری، برج آفتاب، واحد ۱۲", "out", True)]


def _live_orders(db: Session, rng, couriers, zones) -> None:
    """A few in-flight delivery orders so the dispatch board isn't empty in the demo."""
    from app.modules.kitchen.models import KitchenTicket
    from app.modules.menu.models import MenuItem
    from app.modules.orders import service as osvc
    from app.modules.orders.schemas import LineIn, OrderCreate
    from app.core.utils import now
    user = db.query(User).filter(User.username == "reza").first() or db.query(User).first()
    items = [i for i in db.query(MenuItem).filter(MenuItem.is_active.is_(True)).all()
             if i.station_id and not any(g.min_select for g in i.modifier_groups)]
    if not items:
        return
    for k, (name, phone, addr, status, ready) in enumerate(LIVE):
        picks = rng.sample(items, k=min(len(items), rng.randint(2, 3)))
        o = osvc.create_order(db, OrderCreate(type="delivery", customer_name=name, customer_phone=phone, customer_address=addr,
                                              lines=[LineIn(menu_item_id=i.id, qty=rng.choice([1, 1, 2])) for i in picks], send=True), user)
        o.created_at = now() - timedelta(minutes=[6, 14, 19, 28, 41][k])
        db.flush()
        d = S.ensure(db, o)
        S.set_zone(db, o, d, zones[k % len(zones) if k < 3 else 1], user)
        if ready:
            for l in o.lines:
                if l.station_id:
                    l.status = "ready"
            for t in db.query(KitchenTicket).filter(KitchenTicket.order_id == o.id):
                t.status = "ready"
        if status in ("assigned", "out"):
            d.courier_id = couriers[k % len(couriers)].id
            d.courier_fee = d.zone.courier_fee if d.zone else 40_000
            d.assigned_at = o.created_at + timedelta(minutes=8)
            d.status = status
        if status == "out":
            d.out_at = o.created_at + timedelta(minutes=12)
            d.collect = k == 4          # one courier collects cash at the door
            if not d.collect:   # prepaid online
                from app.modules.orders.schemas import PaymentIn
                try:
                    osvc.add_payments(db, o, [PaymentIn(method="online", amount=o.total)], user)
                except Exception:   # noqa: BLE001 — e.g. no open shift in a custom demo
                    d.collect = True
