from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.core.realtime import publish_after_commit
from app.core.utils import now

from .models import Delivery, DeliveryZone

FEE_CODE = "__delivery__"


def fee_item(db: Session):
    from app.modules.menu.models import MenuCategory, MenuItem
    it = db.query(MenuItem).filter(MenuItem.code == FEE_CODE).first()
    if it:
        return it
    cat = db.query(MenuCategory).filter(MenuCategory.section == "system").first()
    if not cat:
        cat = MenuCategory(name="سیستمی", section="system", is_active=False, sort=999)
        db.add(cat)
        db.flush()
    it = MenuItem(category_id=cat.id, name="هزینه ارسال", code=FEE_CODE, price=0, is_active=False, show_in_qr=False, sort=999)
    db.add(it)
    db.flush()
    return it


def ensure(db: Session, order) -> Delivery:
    d = db.get(Delivery, order.id)
    if not d:
        d = Delivery(order_id=order.id, status="waiting", customer_fee=0, courier_fee=0, collect=False)
        db.add(d)
        db.flush()
    return d


def changed(db: Session, order_id: int | None = None, action: str = "updated") -> None:
    publish_after_commit(db, "delivery.changed", {"order_id": order_id, "action": action})


def set_zone(db: Session, order, d: Delivery, zone: DeliveryZone | None, user, customer_fee: int | None = None) -> None:
    from app.modules.orders import service as osvc
    from app.modules.orders.models import OrderLine
    d.zone_id = zone.id if zone else None
    fee = customer_fee if customer_fee is not None else (zone.customer_fee if zone else 0)
    if d.courier_fee == 0 or zone:
        d.courier_fee = (zone.courier_fee if zone and zone.courier_fee else (d.courier.default_fee if d.courier else 0))
    if order.status != "open":
        if fee != d.customer_fee:
            raise AppError("سفارش بسته شده؛ هزینه ارسال مشتری قابل تغییر نیست")
        return
    line = next((l for l in order.lines if l.id == d.fee_line_id), None) if d.fee_line_id else None
    if fee > 0:
        if line and line.status != "void":
            line.base_price = line.unit_price = fee
            line.name = f"هزینه ارسال{' — ' + zone.name if zone else ''}"
        else:
            it = fee_item(db)
            line = OrderLine(menu_item_id=it.id, station_id=None, name=f"هزینه ارسال{' — ' + zone.name if zone else ''}", base_price=fee,
                             unit_price=fee, qty=1, modifiers=[], status="served", created_by=user.id if user else None)
            order.lines.append(line)
            db.flush()
            d.fee_line_id = line.id
    elif line:
        line.status, line.void_reason = "void", "حذف هزینه ارسال"
    d.customer_fee = fee
    osvc.recalc(db, order)
    osvc.notify(db, order, "updated")


def set_status(d: Delivery, status: str) -> None:
    if d.settlement_id:
        raise AppError("این ارسال با پیک تسویه شده و قابل تغییر نیست")
    if d.status == "cancelled":
        raise AppError("سفارش لغو شده است")
    t = now()
    if status == "assigned" and not d.courier_id:
        raise AppError("ابتدا پیک را انتخاب کنید")
    if status == "out":
        if not d.courier_id:
            raise AppError("برای ارسال، پیک را انتخاب کنید", code="courier_required")
        d.out_at = d.out_at or t
        d.assigned_at = d.assigned_at or t
    elif status == "assigned":
        d.assigned_at = d.assigned_at or t
    elif status == "delivered":
        if not d.courier_id:
            raise AppError("پیک این سفارش مشخص نیست", code="courier_required")
        d.out_at = d.out_at or t
        d.delivered_at = t
    elif status == "waiting":
        d.courier_id, d.assigned_at, d.out_at = None, None, None
    d.status = status


# ------------------------------------------------------------------ events
def on_sent(db: Session, order, **_):
    if order.type == "delivery":
        ensure(db, order)
        changed(db, order.id, "new")


def on_cancelled(db: Session, order, **_):
    d = db.get(Delivery, order.id)
    if d and not d.settlement_id:
        d.status = "cancelled"
        changed(db, order.id, "cancelled")


def on_closed(db: Session, order, **_):
    if order.type == "delivery":
        ensure(db, order)
        changed(db, order.id, "paid")
