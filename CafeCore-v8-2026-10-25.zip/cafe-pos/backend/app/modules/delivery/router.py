from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import or_
from sqlalchemy.orm import Session, selectinload

from app.core import events, settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import business_day, day_bounds, normalize_phone, now, phone_update
from app.modules.orders.models import Order

from . import service as S
from .models import Courier, CourierSettlement, Delivery, DeliveryZone

router = APIRouter()
dispatch = require("delivery.dispatch")
manage = require("delivery.manage")
VEHICLES = {"motor": "موتور", "car": "خودرو", "bike": "دوچرخه"}


class CourierIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    phone: str | None = None
    vehicle: str = Field("motor", pattern="^(motor|car|bike)$")
    plate: str | None = None
    default_fee: int = Field(0, ge=0)
    is_active: bool = True
    note: str | None = None


class ZoneIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    customer_fee: int = Field(0, ge=0)
    courier_fee: int = Field(0, ge=0)
    eta_minutes: int = Field(30, ge=5, le=240)
    min_order: int = Field(0, ge=0)
    sort: int = 0
    is_active: bool = True


class DeliveryUpdate(BaseModel):
    zone_id: int | None = None
    clear_zone: bool = False
    courier_id: int | None = None
    collect: bool | None = None
    customer_fee: int | None = Field(None, ge=0)
    courier_fee: int | None = Field(None, ge=0)
    note: str | None = Field(None, max_length=200)


class StatusIn(BaseModel):
    status: str = Field(pattern="^(waiting|assigned|out|delivered|failed)$")


class SettleIn(BaseModel):
    method: str = Field("cash", pattern="^(cash|card|transfer)$")
    note: str | None = Field(None, max_length=200)


def courier_out(c: Courier) -> dict:
    return {"id": c.id, "name": c.name, "phone": c.phone, "vehicle": c.vehicle, "plate": c.plate, "default_fee": c.default_fee, "is_active": c.is_active, "note": c.note}


def zone_out(z: DeliveryZone) -> dict:
    return {"id": z.id, "name": z.name, "customer_fee": z.customer_fee, "courier_fee": z.courier_fee, "eta_minutes": z.eta_minutes,
            "min_order": z.min_order, "sort": z.sort, "is_active": z.is_active}


def collect_amount(d: Delivery, o: Order) -> int:
    return o.remaining if d.collect and o.status == "open" else 0


def row_out(o: Order, d: Delivery) -> dict:
    lines = [l for l in o.active_lines if l.id != d.fee_line_id]
    kitchen = [l for l in lines if l.station_id]
    return {
        "order_id": o.id, "number": o.number, "order_status": o.status, "source": o.source, "total": o.total, "paid": o.paid_amount,
        "remaining": o.remaining, "customer_name": o.customer_name, "customer_phone": o.customer_phone, "customer_address": o.customer_address,
        "note": o.note, "created_at": o.created_at, "items": [{"name": l.name, "qty": l.qty} for l in lines],
        "kitchen_ready": bool(kitchen) and all(l.status in ("ready", "served") for l in kitchen) or not kitchen,
        "status": d.status, "zone_id": d.zone_id, "zone": d.zone.name if d.zone else None, "eta": d.zone.eta_minutes if d.zone else None,
        "courier_id": d.courier_id, "courier": d.courier.name if d.courier else None, "customer_fee": d.customer_fee, "courier_fee": d.courier_fee,
        "collect": d.collect, "collect_amount": collect_amount(d, o), "assigned_at": d.assigned_at, "out_at": d.out_at,
        "delivered_at": d.delivered_at, "settled": bool(d.settlement_id), "delivery_note": d.note,
    }


def _order(db: Session, oid: int) -> tuple[Order, Delivery]:
    o = db.query(Order).options(selectinload(Order.lines), selectinload(Order.payments)).filter(Order.id == oid).first()
    if not o:
        raise AppError("سفارش یافت نشد", code="not_found")
    if o.type != "delivery":
        raise AppError("این سفارش از نوع پیک نیست")
    return o, S.ensure(db, o)


# ------------------------------------------------------------------ board
@router.get("/board")
def board(db: Session = Depends(get_db), _: User = Depends(dispatch)):
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    orders = (db.query(Order).options(selectinload(Order.lines), selectinload(Order.payments))
              .outerjoin(Delivery, Delivery.order_id == Order.id)
              .filter(Order.type == "delivery", Order.status != "cancelled")
              .filter(or_(Order.business_date == today, Order.status == "open",
                          Delivery.status.in_(["waiting", "assigned", "out"]), (Delivery.status == "delivered") & Delivery.settlement_id.is_(None)))
              .order_by(Order.id).all())
    rows = [row_out(o, S.ensure(db, o)) for o in orders]
    db.commit()
    couriers = []
    for c in db.query(Courier).filter(Courier.is_active.is_(True)).order_by(Courier.name).all():
        mine = [r for r in rows if r["courier_id"] == c.id]
        couriers.append({**courier_out(c), "active": sum(r["status"] in ("assigned", "out") for r in mine),
                         "out": sum(r["status"] == "out" for r in mine),
                         "unsettled": sum(r["status"] == "delivered" and not r["settled"] for r in mine),
                         "today": sum(r["status"] == "delivered" for r in mine)})
    zones = [zone_out(z) for z in db.query(DeliveryZone).filter(DeliveryZone.is_active.is_(True)).order_by(DeliveryZone.sort, DeliveryZone.id)]
    return {"orders": rows, "couriers": couriers, "zones": zones}


@router.get("/orders/{oid}")
def get_delivery(oid: int, db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    o, d = _order(db, oid)
    db.commit()
    return row_out(o, d)


@router.put("/orders/{oid}")
def update_delivery(oid: int, data: DeliveryUpdate, db: Session = Depends(get_db), user: User = Depends(require("pos.access"))):
    o, d = _order(db, oid)
    if d.settlement_id:
        raise AppError("این ارسال تسویه شده و قابل ویرایش نیست")
    if data.courier_id is not None:
        if not user.can("delivery.dispatch"):
            raise AppError("دسترسی تعیین پیک را ندارید", code="forbidden")
        c = get_or_404(db, Courier, data.courier_id, "پیک")
        if not c.is_active:
            raise AppError("این پیک غیرفعال است")
        d.courier_id = c.id
        d.courier = c
        if d.status == "waiting":
            d.status, d.assigned_at = "assigned", now()
        if not (d.zone and d.zone.courier_fee):
            d.courier_fee = c.default_fee
    if data.zone_id is not None or data.clear_zone or data.customer_fee is not None:
        zone = get_or_404(db, DeliveryZone, data.zone_id, "منطقه") if data.zone_id else (None if data.clear_zone else d.zone)
        S.set_zone(db, o, d, zone, user, data.customer_fee)
    if data.collect is not None:
        d.collect = data.collect
    if data.courier_fee is not None:
        d.courier_fee = data.courier_fee
    if data.note is not None:
        d.note = data.note
    S.changed(db, o.id)
    db.commit()
    return row_out(o, d)


@router.post("/orders/{oid}/status")
def change_status(oid: int, data: StatusIn, db: Session = Depends(get_db), user: User = Depends(dispatch)):
    o, d = _order(db, oid)
    prev = d.status
    S.set_status(d, data.status)
    if data.status == "out" and o.status == "open" and o.remaining > 0 and not d.collect:
        d.collect = True        # unpaid order leaving the shop → courier collects at the door
    events.emit("delivery.status", db=db, order=o, delivery=d, status=data.status)
    log_action(db, user, "delivery.status", f"سفارش پیک #{o.number}: {prev} → {data.status}" + (f" ({d.courier.name})" if d.courier else ""), entity="order", entity_id=o.id)
    S.changed(db, o.id, data.status)
    db.commit()
    return row_out(o, d)


# ------------------------------------------------------------------ couriers & settlement
@router.get("/couriers")
def list_couriers(db: Session = Depends(get_db), _: User = Depends(dispatch)):
    return [courier_out(c) for c in db.query(Courier).order_by(Courier.is_active.desc(), Courier.name).all()]


@router.post("/couriers", status_code=201)
def create_courier(data: CourierIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = Courier(**{**data.model_dump(), "phone": normalize_phone(data.phone) or data.phone})
    db.add(c)
    db.commit()
    return courier_out(c)


@router.put("/couriers/{cid}")
def update_courier(cid: int, data: CourierIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    c = get_or_404(db, Courier, cid, "پیک")
    old_phone = c.phone
    for k, v in data.model_dump().items():
        setattr(c, k, v)
    c.phone = phone_update(data.phone, old_phone) or data.phone
    db.commit()
    return courier_out(c)


def _unsettled(db: Session, cid: int):
    ds = db.query(Delivery).filter(Delivery.courier_id == cid, Delivery.status == "delivered", Delivery.settlement_id.is_(None)).all()
    orders = {o.id: o for o in db.query(Order).options(selectinload(Order.lines), selectinload(Order.payments)).filter(Order.id.in_([d.order_id for d in ds]))} if ds else {}
    return [(d, orders[d.order_id]) for d in ds if d.order_id in orders]


@router.get("/couriers/{cid}/unsettled")
def unsettled(cid: int, db: Session = Depends(get_db), _: User = Depends(dispatch)):
    c = get_or_404(db, Courier, cid, "پیک")
    rows = [row_out(o, d) for d, o in _unsettled(db, cid)]
    fees = sum(r["courier_fee"] for r in rows)
    collected = sum(r["collect_amount"] for r in rows)
    return {"courier": courier_out(c), "orders": rows, "fees": fees, "collected": collected, "net": collected - fees,
            "unpaid": [r["number"] for r in rows if r["order_status"] == "open" and not r["collect"]]}


@router.post("/couriers/{cid}/settle")
def settle(cid: int, data: SettleIn, db: Session = Depends(get_db), user: User = Depends(dispatch)):
    from app.modules.orders import service as osvc
    from app.modules.orders.schemas import PaymentIn
    c = get_or_404(db, Courier, cid, "پیک")
    items = _unsettled(db, cid)
    if not items:
        raise AppError("سفارش تسویه‌نشده‌ای برای این پیک وجود ندارد")
    collected = fees = 0
    for d, o in items:
        amount = collect_amount(d, o)
        if amount > 0:
            osvc.add_payments(db, o, [PaymentIn(method="cash", amount=amount, tendered=amount, reference=f"پیک: {c.name}")], user)
            collected += amount
        fees += d.courier_fee
    st = CourierSettlement(courier_id=c.id, deliveries=len(items), fees=fees, collected=collected, net=collected - fees,
                           method=data.method, note=data.note, created_by=user.id)
    db.add(st)
    db.flush()
    for d, _o in items:
        d.settlement_id = st.id
    if fees and data.method == "cash":
        events.emit("cash.movement", db=db, kind="out", amount=fees, reason=f"حق‌الزحمه پیک — {c.name} ({len(items)} سفارش)", user=user)
    log_action(db, user, "delivery.settle", f"تسویه با پیک «{c.name}»: {len(items)} سفارش، وجه دریافتی {collected:,}، حق‌الزحمه {fees:,}", entity="courier", entity_id=c.id)
    S.changed(db, None, "settled")
    db.commit()
    return {"id": st.id, "deliveries": st.deliveries, "fees": fees, "collected": collected, "net": st.net}


@router.get("/settlements")
def settlements(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), _: User = Depends(dispatch)):
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    d2 = date_to or business_day(cutoff_hour=cutoff)
    d1 = date_from or d2
    t1, _a = day_bounds(d1, cutoff)
    _b, t2 = day_bounds(d2, cutoff)
    users = dict(db.query(User.id, User.full_name).all())
    rows = db.query(CourierSettlement).filter(CourierSettlement.created_at >= t1, CourierSettlement.created_at < t2).order_by(CourierSettlement.id.desc()).all()
    return [{"id": s.id, "courier": s.courier.name, "courier_id": s.courier_id, "deliveries": s.deliveries, "fees": s.fees, "collected": s.collected,
             "net": s.net, "method": s.method, "note": s.note, "created_at": s.created_at, "by": users.get(s.created_by)} for s in rows]


@router.get("/report")
def report(date_from: date, date_to: date, db: Session = Depends(get_db), _: User = Depends(dispatch)):
    rows = (db.query(Delivery, Order).join(Order, Order.id == Delivery.order_id)
            .filter(Order.business_date >= date_from, Order.business_date <= date_to, Order.status != "cancelled").all())
    by_c = defaultdict(lambda: {"count": 0, "fees": 0, "minutes": []})
    by_z = defaultdict(lambda: {"count": 0, "revenue": 0})
    for d, o in rows:
        if d.status == "delivered" and d.courier:
            b = by_c[d.courier.name]
            b["count"] += 1
            b["fees"] += d.courier_fee
            if d.delivered_at:
                b["minutes"].append((d.delivered_at - o.created_at).total_seconds() / 60)
        z = by_z[d.zone.name if d.zone else "بدون منطقه"]
        z["count"] += 1
        z["revenue"] += o.total
    delivered = [d for d, _o in rows if d.status == "delivered"]
    return {
        "orders": len(rows), "delivered": len(delivered), "failed": sum(d.status == "failed" for d, _o in rows),
        "customer_fees": sum(d.customer_fee for d, _o in rows), "courier_fees": sum(d.courier_fee for d in delivered),
        "by_courier": sorted([{"name": k, "count": v["count"], "fees": v["fees"], "avg_minutes": round(sum(v["minutes"]) / len(v["minutes"])) if v["minutes"] else None}
                              for k, v in by_c.items()], key=lambda x: -x["count"]),
        "by_zone": sorted([{"name": k, **v} for k, v in by_z.items()], key=lambda x: -x["count"]),
    }


# ------------------------------------------------------------------ zones
@router.get("/zones")
def list_zones(db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    return [zone_out(z) for z in db.query(DeliveryZone).order_by(DeliveryZone.sort, DeliveryZone.id).all()]


@router.post("/zones", status_code=201)
def create_zone(data: ZoneIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    z = DeliveryZone(**data.model_dump())
    db.add(z)
    db.commit()
    return zone_out(z)


@router.put("/zones/{zid}")
def update_zone(zid: int, data: ZoneIn, db: Session = Depends(get_db), _: User = Depends(manage)):
    z = get_or_404(db, DeliveryZone, zid, "منطقه")
    for k, v in data.model_dump().items():
        setattr(z, k, v)
    db.commit()
    return zone_out(z)
