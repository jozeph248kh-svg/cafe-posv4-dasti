from app.core import events
from app.core.modules import Module

from . import service
from .router import router
from .seed import demo, seed


def setup() -> None:
    events.subscribe("order.sent", service.on_sent)
    events.subscribe("order.closed", service.on_closed)
    events.subscribe("order.cancelled", service.on_cancelled)


module = Module(
    name="delivery",
    title="پیک و ارسال",
    description="مناطق ارسال و هزینه پیک، تخصیص سفارش به پیک، پیگیری وضعیت و تسویه حساب پیک‌ها",
    depends=["orders", "menu"],
    routers=[router],
    permissions={"delivery.dispatch": "توزیع سفارش بین پیک‌ها و تسویه", "delivery.manage": "تعریف پیک و مناطق ارسال"},
    seed=seed,
    demo=demo,
    setup=setup,
)
