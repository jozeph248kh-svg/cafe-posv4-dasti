from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text, true
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin
from app.core.models import User


class Register(Base, TimestampMixin):
    """A cash drawer / till (صندوق ۱ سالن، صندوق بیرون‌بر…). Each POS device picks one; it has its own shifts,
    opening cash and cash count. Several cashiers may share a register."""
    __tablename__ = "registers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40), unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())
    sort: Mapped[int] = mapped_column(Integer, default=0)


class Shift(Base):
    __tablename__ = "shifts"
    id: Mapped[int] = mapped_column(primary_key=True)
    register_id: Mapped[int | None] = mapped_column(ForeignKey("registers.id"), index=True)   # NULL (old rows) = main
    status: Mapped[str] = mapped_column(String(10), default="open", index=True)
    opened_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    opened_at: Mapped[datetime] = mapped_column(DateTime)
    opening_cash: Mapped[int] = mapped_column(Integer, default=0)
    closed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)
    counted_cash: Mapped[int | None] = mapped_column(Integer)
    expected_cash: Mapped[int | None] = mapped_column(Integer)
    summary: Mapped[dict | None] = mapped_column(JSON)                 # snapshot at close
    note: Mapped[str | None] = mapped_column(Text)
    opener: Mapped[User] = relationship(foreign_keys=[opened_by], lazy="joined")
    closer: Mapped[User | None] = relationship(foreign_keys=[closed_by], lazy="joined")
    register: Mapped[Register | None] = relationship(lazy="joined")


class CashMovement(Base, TimestampMixin):
    __tablename__ = "cash_movements"
    id: Mapped[int] = mapped_column(primary_key=True)
    shift_id: Mapped[int] = mapped_column(ForeignKey("shifts.id"), index=True)
    kind: Mapped[str] = mapped_column(String(5))          # in | out
    amount: Mapped[int] = mapped_column(Integer)
    reason: Mapped[str] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class StaffShiftReport(Base, TimestampMixin):
    """End-of-shift report an employee submits to the manager (sales, payments taken, discounts/voids, open orders
    handed over, drawer handover). `data` is a snapshot computed at submission time."""
    __tablename__ = "staff_shift_reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    time_entry_id: Mapped[int | None] = mapped_column(Integer, index=True)       # the clock-in this report closes
    period_start: Mapped[datetime] = mapped_column(DateTime)
    period_end: Mapped[datetime] = mapped_column(DateTime, index=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime)
    data: Mapped[dict] = mapped_column(JSON)
    note: Mapped[str | None] = mapped_column(Text)
    acknowledged_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime)
    manager_note: Mapped[str | None] = mapped_column(String(500))
    user: Mapped[User] = relationship(foreign_keys=[user_id], lazy="joined")
    acker: Mapped[User | None] = relationship(foreign_keys=[acknowledged_by], lazy="joined")
