from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core import events, settings_store
from app.core.device import device_register
from app.core.errors import AppError

from .models import Register, Shift

MAIN_NAME = "صندوق اصلی"


def main_register(db: Session) -> Register:
    r = db.query(Register).filter(Register.is_active.is_(True)).order_by(Register.sort, Register.id).first()
    if r:
        return r
    r = db.query(Register).order_by(Register.id).first()        # all deactivated: the oldest one still works
    if r:
        return r
    r = Register(name=MAIN_NAME)
    db.add(r)
    db.flush()
    return r


def resolve_register(db: Session, register_id: int | None = None) -> Register:
    """Explicit id (manager screens) → the device's register (X-Register-Id) → the main register."""
    rid = register_id if register_id is not None else device_register.get()
    if rid is None:
        return main_register(db)
    r = db.get(Register, rid) if rid > 0 else None
    if not r or not r.is_active:
        raise AppError("صندوقِ این دستگاه وجود ندارد یا غیرفعال شده است؛ از صفحه «شیفت و صندوق» صندوق این دستگاه را دوباره انتخاب کنید",
                       409, "register_invalid")
    return r


def current_shift(db: Session, register: Register | None = None) -> Shift | None:
    reg = register or resolve_register(db)
    q = db.query(Shift).filter(Shift.status == "open")
    if reg.id == main_register(db).id:
        q = q.filter(or_(Shift.register_id == reg.id, Shift.register_id.is_(None)))   # rows from before registers
    else:
        q = q.filter(Shift.register_id == reg.id)
    return q.order_by(Shift.id.desc()).first()


def _closed_error(reg: Register) -> AppError:
    return AppError(f"«{reg.name}» باز نیست؛ ابتدا شیفت این صندوق را باز کنید", code="shift_closed", register=reg.name)


def on_payment(db: Session, payment, order, user, **_):
    reg = resolve_register(db)
    shift = current_shift(db, reg)
    if not shift and settings_store.get(db, "shift.required", True):
        raise _closed_error(reg)
    payment.shift_id = shift.id if shift else None


def on_cash_movement(db: Session, kind: str, amount: int, reason: str, user=None, required: bool = True, **_):
    """Generic hook other modules use to move cash in/out of the open register (expenses, wallet top-ups, courier pay...)."""
    from .models import CashMovement
    reg = resolve_register(db)
    shift = current_shift(db, reg)
    if not shift:
        if required and settings_store.get(db, "shift.required", True):
            raise _closed_error(reg)
        return
    db.add(CashMovement(shift_id=shift.id, kind=kind, amount=amount, reason=reason[:200], created_by=user.id if user else None))
    from app.core.realtime import publish_after_commit
    publish_after_commit(db, "shift.changed", {"status": "open", "register_id": reg.id})


def on_clocking_out(db: Session, user, entry, **_):
    """Time clock → before a clock-out: the drawer must be handed over and the end-of-shift report submitted."""
    if not settings_store.get(db, "shift.report_required", True):
        return
    from .staff_report import fresh_report, held_drawer
    drawer = held_drawer(db, user)
    if drawer:
        name = drawer.register.name if drawer.register else "صندوق"
        raise AppError(f"«{name}» به نام شما باز است؛ قبل از ثبت خروج، صندوق را بشمارید و تحویل دهید و گزارش پایان شیفت را ارسال کنید",
                       409, "drawer_open")
    if not fresh_report(db, user, entry):
        raise AppError("قبل از ثبت خروج، گزارش پایان شیفت خود را ارسال کنید (بخش «شیفت من»)", 409, "shift_report_required")


def seed(db: Session) -> None:
    """Make sure a main register exists and attach shifts from before multi-register to it (idempotent)."""
    from app.core.permissions import grant_once
    grant_once(db, "shifts.supervise", {"manager": ["shifts.supervise"]})
    main = main_register(db)
    db.query(Shift).filter(Shift.register_id.is_(None)).update({"register_id": main.id}, synchronize_session=False)


def setup() -> None:
    events.subscribe("payment.creating", on_payment)
    events.subscribe("cash.movement", on_cash_movement)
    events.subscribe("timeclock.clocking_out", on_clocking_out)
