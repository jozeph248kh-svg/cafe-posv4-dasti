from collections import defaultdict

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import now
from app.modules.orders.models import Order, Payment

from .handlers import current_shift, main_register, resolve_register
from .models import CashMovement, Register, Shift
from .staff_report import blind_for

router = APIRouter()
manage = require("shifts.manage")


class OpenIn(BaseModel):
    opening_cash: int = Field(0, ge=0, le=100_000_000_000)
    note: str | None = Field(None, max_length=500)
    register_id: int | None = None          # default: this device's register


class CloseIn(BaseModel):
    counted_cash: int = Field(ge=0, le=100_000_000_000)
    note: str | None = Field(None, max_length=500)
    register_id: int | None = None


class CashIn(BaseModel):
    kind: str = Field(pattern="^(in|out)$")
    amount: int = Field(gt=0, le=100_000_000_000)
    reason: str = Field(min_length=2, max_length=200)
    register_id: int | None = None


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=40)
    is_active: bool = True
    sort: int = Field(0, ge=0, le=1000)


def compute(db: Session, s: Shift) -> dict:
    pays = db.query(Payment).filter(Payment.shift_id == s.id).all()
    by_method = defaultdict(int)
    for p in pays:
        by_method[p.method] += p.amount
    moves = db.query(CashMovement).filter(CashMovement.shift_id == s.id).order_by(CashMovement.id).all()
    cash_in = sum(m.amount for m in moves if m.kind == "in")
    cash_out = sum(m.amount for m in moves if m.kind == "out")
    order_ids = {p.order_id for p in pays if not p.is_refund}
    refunds = -sum(p.amount for p in pays if p.is_refund)
    expected = s.opening_cash + by_method.get("cash", 0) + cash_in - cash_out
    return {
        "payments": dict(by_method), "total_sales": sum(p.amount for p in pays), "orders": len(order_ids),
        "refunds": refunds, "cash_in": cash_in, "cash_out": cash_out, "expected_cash": expected,
        "movements": [{"id": m.id, "kind": m.kind, "amount": m.amount, "reason": m.reason, "created_at": m.created_at.isoformat(timespec="seconds")} for m in moves],
    }


def shift_out(db: Session, s: Shift, viewer: User | None = None) -> dict:
    """`viewer` decides what is shown for an OPEN drawer: without `shifts.manage` only that it is open (by whom,
    since when); a blind viewer (shift.blind_close, no `shifts.supervise`) sees no expected cash and no cash
    sales it could be computed from. Closed shifts are shown in full to everybody who may list them."""
    reg = s.register or main_register(db)
    if s.status == "open" and viewer is not None and not viewer.can("shifts.manage"):
        return {"id": s.id, "status": s.status, "register_id": reg.id, "register_name": reg.name, "opened_at": s.opened_at,
                "opened_by": s.opener.full_name, "restricted": True, "blind": True}
    data = s.summary if s.status == "closed" and s.summary else compute(db, s)
    if s.status == "open" and blind_for(db, viewer):
        data = {**data, "expected_cash": None, "total_sales": None,
                "payments": {k: v for k, v in data["payments"].items() if k != "cash"}}
        return {
            "id": s.id, "status": s.status, "register_id": reg.id, "register_name": reg.name, "opened_at": s.opened_at,
            "opening_cash": s.opening_cash, "opened_by": s.opener.full_name, "opened_by_id": s.opened_by, "closed_at": None,
            "closed_by": None, "counted_cash": None, "difference": None, "note": s.note, "blind": True, **data,
        }
    return {
        "id": s.id, "status": s.status, "register_id": reg.id, "register_name": reg.name, "opened_at": s.opened_at, "opening_cash": s.opening_cash,
        "opened_by": s.opener.full_name, "closed_at": s.closed_at, "closed_by": s.closer.full_name if s.closer else None,
        "counted_cash": s.counted_cash, "expected_cash": data["expected_cash"],
        "difference": (s.counted_cash - data["expected_cash"]) if s.counted_cash is not None else None,
        "note": s.note, "opened_by_id": s.opened_by, "blind": False, **data,
    }


# ---------------------------------------------------------------- registers (cash drawers)
def _registers(db: Session, active_only: bool) -> list[dict]:
    main = main_register(db)
    q = db.query(Register)
    if active_only:
        q = q.filter(Register.is_active.is_(True))
    out = []
    for r in q.order_by(Register.sort, Register.id).all():
        s = current_shift(db, r) if r.is_active else None
        out.append({"id": r.id, "name": r.name, "is_active": r.is_active, "sort": r.sort, "is_main": r.id == main.id,
                    "open_shift": {"id": s.id, "opened_by": s.opener.full_name, "opened_at": s.opened_at} if s else None})
    return out


@router.get("/registers")
def list_registers(all: bool = False, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Registers a device can pick (any signed-in user — it is a device setting). `all=1` (managers) includes inactive."""
    return _registers(db, active_only=not (all and user.can("shifts.manage")))


@router.post("/registers", status_code=201)
def create_register(data: RegisterIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    name = data.name.strip()
    if db.query(Register.id).filter(Register.name == name).first():
        raise AppError("صندوقی با این نام وجود دارد", code="duplicate")
    if db.query(Register).count() >= 20:
        raise AppError("حداکثر ۲۰ صندوق قابل تعریف است")
    main_register(db)                                 # the main one exists before the second is added
    r = Register(name=name, is_active=data.is_active, sort=data.sort)
    db.add(r)
    db.flush()
    log_action(db, user, "shift.register", f"تعریف صندوق «{name}»", entity="register", entity_id=r.id)
    publish_after_commit(db, "shift.changed", {"register_id": r.id})
    db.commit()
    return next(x for x in _registers(db, False) if x["id"] == r.id)


@router.put("/registers/{rid}")
def update_register(rid: int, data: RegisterIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    r = get_or_404(db, Register, rid, "صندوق")
    name = data.name.strip()
    if db.query(Register.id).filter(Register.name == name, Register.id != rid).first():
        raise AppError("صندوقی با این نام وجود دارد", code="duplicate")
    if r.is_active and not data.is_active:
        if current_shift(db, r):
            raise AppError("این صندوق شیفت باز دارد؛ ابتدا آن را ببندید", code="register_busy")
        if db.query(Register).filter(Register.is_active.is_(True), Register.id != rid).count() == 0:
            raise AppError("دست‌کم یک صندوق فعال لازم است", code="register_last")
    old = r.name
    r.name, r.is_active, r.sort = name, data.is_active, data.sort
    log_action(db, user, "shift.register", f"ویرایش صندوق «{old}»" + (f" ← «{name}»" if name != old else "") + ("" if data.is_active else " (غیرفعال)"),
               entity="register", entity_id=r.id)
    publish_after_commit(db, "shift.changed", {"register_id": r.id})
    db.commit()
    return next(x for x in _registers(db, False) if x["id"] == r.id)


# ---------------------------------------------------------------- shifts
@router.get("/current")
def get_current(register_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    s = current_shift(db, resolve_register(db, register_id))
    return shift_out(db, s, user) if s else None


@router.post("/open")
def open_shift(data: OpenIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    reg = resolve_register(db, data.register_id)
    if current_shift(db, reg):
        raise AppError(f"«{reg.name}» شیفت باز دارد", code="shift_open")
    s = Shift(register_id=reg.id, opened_by=user.id, opened_at=now(), opening_cash=data.opening_cash, note=data.note)
    db.add(s)
    log_action(db, user, "shift.open", f"باز کردن «{reg.name}» با موجودی اولیه {data.opening_cash:,}", entity="register", entity_id=reg.id)
    publish_after_commit(db, "shift.changed", {"status": "open", "register_id": reg.id})
    db.commit()
    db.refresh(s)
    return shift_out(db, s, user)


@router.post("/cash")
def cash_movement(data: CashIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    reg = resolve_register(db, data.register_id)
    s = current_shift(db, reg)
    if not s:
        raise AppError(f"«{reg.name}» باز نیست", code="shift_closed")
    db.add(CashMovement(shift_id=s.id, kind=data.kind, amount=data.amount, reason=data.reason, created_by=user.id))
    log_action(db, user, f"shift.cash_{data.kind}", f"{'واریز به' if data.kind == 'in' else 'برداشت از'} «{reg.name}»: {data.amount:,} — {data.reason}")
    publish_after_commit(db, "shift.changed", {"status": "open", "register_id": reg.id})
    db.commit()
    return shift_out(db, s, user)


@router.post("/close")
def close_shift(data: CloseIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    reg = resolve_register(db, data.register_id)
    s = current_shift(db, reg)
    if not s:
        raise AppError(f"«{reg.name}» شیفت باز ندارد", code="shift_closed")
    paid_here = db.query(Payment.order_id).filter(Payment.shift_id == s.id)
    open_orders = db.query(Order).filter(Order.status == "open", Order.paid_amount > 0, Order.id.in_(paid_here)).count()
    if open_orders:
        raise AppError(f"{open_orders} سفارش نیمه‌پرداخت (پرداخت‌شده در این صندوق) باز است؛ ابتدا آن‌ها را تسویه کنید")
    summary = compute(db, s)
    s.status, s.closed_by, s.closed_at = "closed", user.id, now()
    s.counted_cash, s.expected_cash, s.summary = data.counted_cash, summary["expected_cash"], summary
    s.note = "\n".join(filter(None, [s.note, data.note])) or None
    diff = data.counted_cash - summary["expected_cash"]
    log_action(db, user, "shift.close", f"بستن «{reg.name}» — فروش {summary['total_sales']:,}، مغایرت نقدی {diff:+,}",
               details={"difference": diff, "register_id": reg.id}, entity="register", entity_id=reg.id)
    publish_after_commit(db, "shift.changed", {"status": "closed", "register_id": reg.id})
    db.commit()
    db.refresh(s)
    _backup_after_close()
    return shift_out(db, s, user)            # closed: the counter sees the result only now (blind count)


def _backup_after_close() -> None:
    """End of shift: keep one backup for the day (taken now) and drop the day's hourly snapshots — in the background."""
    import threading

    from app.core.config import get_settings
    if not get_settings().background_jobs:
        return

    def run():
        from app.core.backup import shift_closed_backup
        from app.core.db import SessionLocal
        try:
            with SessionLocal() as db:
                shift_closed_backup(db)
        except Exception:  # noqa: BLE001
            import logging
            logging.getLogger("backup").exception("end-of-shift backup failed")
    threading.Thread(target=run, name="shift-backup", daemon=True).start()


@router.get("")
def list_shifts(limit: int = Query(60, le=365), register_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(manage)):
    q = db.query(Shift)
    if register_id:
        q = q.filter(Shift.register_id == register_id)
    return [shift_out(db, s, user) for s in q.order_by(Shift.id.desc()).limit(limit).all()]


@router.get("/{sid}")
def get_shift(sid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    return shift_out(db, get_or_404(db, Shift, sid, "شیفت"), user)
