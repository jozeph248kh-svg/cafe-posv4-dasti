from app.core import settings_store
from app.core.modules import Module

from .handlers import seed, setup
from .report_router import router as report_router
from .router import router

# blind_close: staff without shifts.supervise count the drawer without seeing the expected cash;
# report_required: clocking out needs the end-of-shift report (and the drawer handed over); hours: planned shift length
settings_store.register_defaults({"shift.blind_close": True, "shift.report_required": True, "shift.hours": 8},
                                 ranges={"shift.hours": (1, 16)})

module = Module(
    name="shifts",
    title="شیفت و صندوق",
    description="باز و بسته کردن صندوق، شمارش کور پول، برداشت/واریز، گزارش مغایرت و گزارش پایان شیفت کارکنان",
    depends=["orders"],
    routers=[report_router, router],      # report routes first: /my-report must not hit /{sid}
    permissions={"shifts.manage": "باز/بستن شیفت صندوق و ثبت برداشت",
                 "shifts.supervise": "دیدن نقد مورد انتظار صندوق‌های باز و بررسی گزارش پایان شیفت کارکنان"},
    setup=setup,
    seed=seed,
)
