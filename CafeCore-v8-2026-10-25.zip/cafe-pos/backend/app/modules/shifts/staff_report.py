"""End-of-shift report of one employee («شیفت من») and the blind-count rules for the cash drawer.

Blind count (shift.blind_close, default on): somebody who doesn't have `shifts.supervise` never sees how much cash
an OPEN drawer should hold — not the expected cash, not the cash sales it is computed from — so the count at
hand-over is an honest observation. After the drawer is closed (counted) the result is shown.
"""
from collections import defaultdict
from datetime import datetime, timedelta

from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.models import AuditLog, User
from app.core.modules import registry
from app.core.utils import business_day, day_bounds, now
from app.modules.orders.models import Order, OrderLine, Payment

from .models import CashMovement, Shift, StaffShiftReport

FRESH_MINUTES = 30            # a report older than this doesn't let you clock out (you kept working after it)


# ---------------------------------------------------------------- blind count
def blind_for(db: Session, viewer: User | None) -> bool:
    """True when `viewer` must not see the expected cash of open drawers."""
    if viewer is None or viewer.can("shifts.supervise"):
        return False
    return bool(settings_store.get(db, "shift.blind_close", True))


def held_drawer(db: Session, user: User) -> Shift | None:
    """The open register shift this employee opened (= the drawer they are responsible for)."""
    return db.query(Shift).filter(Shift.status == "open", Shift.opened_by == user.id).order_by(Shift.id.desc()).first()


# ---------------------------------------------------------------- period
def _timeclock_on() -> bool:
    return "timeclock" in registry.modules


def open_time_entry(db: Session, user: User):
    if not _timeclock_on():
        return None
    from app.modules.timeclock.service import open_entry
    return open_entry(db, user.id)


def period(db: Session, user: User, at: datetime | None = None):
    """(start, end, open time entry). Clocked in → since the clock-in; otherwise since the last report or the start
    of the business day, whichever is later."""
    t = at or datetime.now()                 # not now(): that drops microseconds and would miss this second's orders
    entry = open_time_entry(db, user)
    if entry:
        return entry.clock_in, t, entry
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    start = day_bounds(business_day(t, cutoff), cutoff)[0]
    last = db.query(func.max(StaffShiftReport.period_end)).filter(StaffShiftReport.user_id == user.id).scalar()
    if last and start < last <= t:
        start = last
    return start, t, None


def _minutes(db: Session, user: User, start: datetime, end: datetime) -> int | None:
    if not _timeclock_on():
        return None
    from app.modules.timeclock.models import TimeEntry
    from app.modules.timeclock.service import end_of, max_hours
    lim, total = max_hours(db), 0
    rows = db.query(TimeEntry).filter(TimeEntry.user_id == user.id, TimeEntry.clock_in < end,
                                      or_(TimeEntry.clock_out.is_(None), TimeEntry.clock_out > start))
    for e in rows:
        a, b = max(e.clock_in, start), min(end_of(e, lim, end), end)
        total += max(0, int((b - a).total_seconds() // 60))
    return total


# ---------------------------------------------------------------- report
def compute(db: Session, user: User, start: datetime, end: datetime) -> dict:
    mine = func.coalesce(Order.waiter_id, Order.created_by) == user.id
    orders = (db.query(Order).filter(mine, Order.created_at >= start, Order.created_at <= end)
              .order_by(Order.id).all())
    live = [o for o in orders if o.status != "cancelled"]
    closed = [o for o in live if o.status == "closed"]
    by_type = defaultdict(lambda: {"count": 0, "amount": 0})
    for o in closed:
        by_type[o.type]["count"] += 1
        by_type[o.type]["amount"] += o.total
    sales = sum(o.total for o in closed)

    items = defaultdict(lambda: {"qty": 0, "amount": 0})
    for o in live:
        for ln in o.lines:
            if ln.status != "void":
                items[ln.name]["qty"] += ln.qty
                items[ln.name]["amount"] += ln.total
    top = sorted(({"name": k, **v} for k, v in items.items()), key=lambda x: (-x["qty"], x["name"]))[:5]

    pays = (db.query(Payment).filter(Payment.created_by == user.id, Payment.created_at >= start, Payment.created_at <= end)
            .order_by(Payment.id).all())
    collected = defaultdict(int)
    refunds = {"count": 0, "amount": 0}
    for p in pays:
        if p.is_refund:
            refunds["count"] += 1
            refunds["amount"] += -p.amount
        collected[p.method] += p.amount                      # net of refunds per method (what is in the drawer)
    cash_shifts = sorted({p.shift_id for p in pays if p.method == "cash" and p.shift_id})

    bill_disc = [o for o in orders if o.discount_by == user.id and (o.discount_amount - (o.line_discount_amount or 0)) > 0]
    line_disc = (db.query(OrderLine).join(Order, Order.id == OrderLine.order_id)
                 .filter(OrderLine.discount_by == user.id, OrderLine.discount_amount > 0,
                         Order.created_at >= start, Order.created_at <= end).all())
    discounts = {
        "count": len(bill_disc) + len(line_disc),
        "amount": sum(o.discount_amount - (o.line_discount_amount or 0) for o in bill_disc) + sum(ln.discount_amount for ln in line_disc),
    }

    logs = (db.query(AuditLog).filter(AuditLog.user_id == user.id, AuditLog.created_at >= start, AuditLog.created_at <= end,
                                      AuditLog.action.in_(("order.void", "order.cancel"))).order_by(AuditLog.id).all())
    voids = {"count": 0, "amount": 0, "items": []}
    cancels = {"count": 0, "amount": 0}
    for a in logs:
        amount = int((a.details or {}).get("amount") or 0)
        bucket = voids if a.action == "order.void" else cancels
        bucket["count"] += 1
        bucket["amount"] += amount
        if a.action == "order.void" and len(voids["items"]) < 20:
            voids["items"].append({"summary": a.summary, "approver": a.approver_name, "at": a.created_at.isoformat(timespec="seconds")})

    moves = (db.query(CashMovement).filter(CashMovement.created_by == user.id, CashMovement.created_at >= start,
                                           CashMovement.created_at <= end).order_by(CashMovement.id).all())

    open_orders = (db.query(Order).filter(mine, Order.status == "open").order_by(Order.id).limit(50).all())

    drawer = held_drawer(db, user)
    closed_drawers = (db.query(Shift).filter(Shift.closed_by == user.id, Shift.closed_at >= start, Shift.closed_at <= end)
                      .order_by(Shift.id).all())

    return {
        "minutes": _minutes(db, user, start, end),
        "orders": {"count": len(live), "closed": len(closed), "open": len(live) - len(closed), "cancelled": len(orders) - len(live),
                   "sales": sales, "avg": sales // len(closed) if closed else 0, "guests": sum(o.guests or 0 for o in closed),
                   "by_type": dict(by_type)},
        "top_items": top,
        "payments": dict(collected),
        "collected_total": sum(collected.values()),
        "payments_count": sum(1 for p in pays if not p.is_refund),
        "refunds": refunds,
        "discounts": discounts,
        "voids": voids,
        "cancels": cancels,
        "cash_moves": [{"kind": m.kind, "amount": m.amount, "reason": m.reason, "at": m.created_at.isoformat(timespec="seconds")} for m in moves],
        "open_orders": [{"id": o.id, "number": o.number, "type": o.type, "table": o.table.name if o.table else None,
                         "total": o.total, "paid": o.paid_amount, "created_at": o.created_at.isoformat(timespec="seconds")} for o in open_orders],
        "drawer": ({"shift_id": drawer.id, "register_id": drawer.register_id, "register_name": drawer.register.name if drawer.register else None,
                    "opened_at": drawer.opened_at.isoformat(timespec="seconds"), "opening_cash": drawer.opening_cash} if drawer else None),
        "drawers_closed": [{"shift_id": s.id, "register_name": s.register.name if s.register else None,
                            "closed_at": s.closed_at.isoformat(timespec="seconds"), "counted_cash": s.counted_cash,
                            "expected_cash": s.expected_cash,
                            "difference": (s.counted_cash - s.expected_cash) if s.counted_cash is not None and s.expected_cash is not None else None}
                           for s in closed_drawers],
        "cash_shift_ids": cash_shifts,
    }


def mask(db: Session, data: dict, viewer: User) -> dict:
    """Hide the cash collected into a drawer that is still open from a blind viewer (it would reveal the expected
    cash). Everything else stays visible."""
    if not blind_for(db, viewer):
        return {**data, "cash_hidden": False}
    ids = data.get("cash_shift_ids") or []
    still_open = ids and db.query(Shift.id).filter(Shift.id.in_(ids), Shift.status == "open").first()
    if not still_open:
        return {**data, "cash_hidden": False}
    pays = dict(data.get("payments") or {})
    pays["cash"] = None
    return {**data, "payments": pays, "collected_total": None, "cash_hidden": True}


def report_out(db: Session, r: StaffShiftReport, viewer: User) -> dict:
    return {
        "id": r.id, "user_id": r.user_id, "name": r.user.full_name, "role": r.user.role.title if r.user.role else None,
        "period_start": r.period_start, "period_end": r.period_end, "submitted_at": r.submitted_at,
        "note": r.note, "acknowledged_at": r.acknowledged_at, "acknowledged_by": r.acker.full_name if r.acker else None,
        "manager_note": r.manager_note, "data": mask(db, r.data or {}, viewer),
    }


def fresh_report(db: Session, user: User, entry) -> StaffShiftReport | None:
    """A report that lets this employee clock out: for this clock-in and submitted recently."""
    q = db.query(StaffShiftReport).filter(StaffShiftReport.user_id == user.id,
                                          StaffShiftReport.period_end >= now() - timedelta(minutes=FRESH_MINUTES))
    if entry is not None:
        q = q.filter(StaffShiftReport.time_entry_id == entry.id)
    return q.order_by(StaffShiftReport.id.desc()).first()
