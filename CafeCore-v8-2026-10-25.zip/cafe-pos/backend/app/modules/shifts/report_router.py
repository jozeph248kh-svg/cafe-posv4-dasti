"""«شیفت من»: every employee sees and submits their own end-of-shift report; managers review and acknowledge them.

Mounted before the main shifts router so `/my-report` and `/staff-reports` are not taken for `/{sid}`.
"""
from datetime import date

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import day_bounds, now

from . import staff_report as R
from .models import StaffShiftReport

router = APIRouter()
supervise = require("shifts.supervise")


class SubmitIn(BaseModel):
    note: str | None = Field(None, max_length=1000)


class AckIn(BaseModel):
    note: str | None = Field(None, max_length=500)


def _status(db: Session, user: User, entry, start) -> dict:
    hours = int(settings_store.get(db, "shift.hours", 8) or 8)
    worked = int((now() - entry.clock_in).total_seconds() // 60) if entry else None
    last = (db.query(StaffShiftReport).filter(StaffShiftReport.user_id == user.id)
            .order_by(StaffShiftReport.id.desc()).first())
    return {
        "on_clock": bool(entry), "clock_in": entry.clock_in if entry else None, "worked_minutes": worked,
        "shift_hours": hours, "overdue": bool(entry) and worked >= hours * 60,
        "required": bool(settings_store.get(db, "shift.report_required", True)),
        "blind": R.blind_for(db, user), "period_start": start, "timeclock": R._timeclock_on(),
        "last_report": {"id": last.id, "submitted_at": last.submitted_at, "period_end": last.period_end,
                        "acknowledged": last.acknowledged_at is not None} if last else None,
        "can_clock_out": bool(entry) and R.fresh_report(db, user, entry) is not None,
    }


@router.get("/my-report")
def my_report(db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Live report of the signed-in employee for the current shift (since clock-in)."""
    start, end, entry = R.period(db, user)
    data = R.compute(db, user, start, end)
    return {"name": user.full_name, "role": user.role.title if user.role else None, "period_start": start, "period_end": end,
            "status": _status(db, user, entry, start), "data": R.mask(db, data, user)}


@router.post("/my-report", status_code=201)
def submit_report(body: SubmitIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    drawer = R.held_drawer(db, user)
    if drawer:
        name = drawer.register.name if drawer.register else "صندوق"
        raise AppError(f"«{name}» به نام شما باز است؛ ابتدا صندوق را بشمارید و تحویل دهید (بستن صندوق)", 409, "drawer_open",
                       register_id=drawer.register_id)
    start, end, entry = R.period(db, user)
    data = R.compute(db, user, start, end)
    r = None
    if entry is not None:                      # one report per clock-in; re-submitting refreshes it until it is reviewed
        r = (db.query(StaffShiftReport).filter(StaffShiftReport.user_id == user.id, StaffShiftReport.time_entry_id == entry.id,
                                               StaffShiftReport.acknowledged_at.is_(None))
             .order_by(StaffShiftReport.id.desc()).first())
    if r is None:
        r = StaffShiftReport(user_id=user.id, time_entry_id=entry.id if entry else None)
        db.add(r)
    r.period_start, r.period_end, r.submitted_at, r.data = start, end, now(), data
    r.note = (body.note or "").strip() or None
    db.flush()
    o = data["orders"]
    log_action(db, user, "shift.staff_report", f"گزارش پایان شیفت {user.full_name}: {o['closed']} سفارش، فروش {o['sales']:,}",
               entity="staff_report", entity_id=r.id)
    publish_after_commit(db, "staff_report.submitted", {"id": r.id, "user_id": user.id})
    db.commit()
    db.refresh(r)
    return R.report_out(db, r, user)


@router.get("/my-reports")
def my_reports(limit: int = Query(20, ge=1, le=100), db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = (db.query(StaffShiftReport).filter(StaffShiftReport.user_id == user.id)
            .order_by(StaffShiftReport.id.desc()).limit(limit).all())
    return [R.report_out(db, r, user) for r in rows]


@router.get("/staff-reports")
def staff_reports(date_from: date | None = None, date_to: date | None = None, user_id: int | None = None,
                  pending: bool = False, db: Session = Depends(get_db), user: User = Depends(supervise)):
    q = db.query(StaffShiftReport)
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    if date_from:
        q = q.filter(StaffShiftReport.period_end >= day_bounds(date_from, cutoff)[0])
    if date_to:
        q = q.filter(StaffShiftReport.period_end < day_bounds(date_to, cutoff)[1])
    if user_id:
        q = q.filter(StaffShiftReport.user_id == user_id)
    if pending:
        q = q.filter(StaffShiftReport.acknowledged_at.is_(None))
    return [R.report_out(db, r, user) for r in q.order_by(StaffShiftReport.id.desc()).limit(300).all()]


@router.get("/staff-reports/{rid}")
def staff_report(rid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = get_or_404(db, StaffShiftReport, rid, "گزارش")
    if r.user_id != user.id and not user.can("shifts.supervise"):
        raise AppError("به این گزارش دسترسی ندارید", 403, "forbidden")
    return R.report_out(db, r, user)


@router.post("/staff-reports/{rid}/ack")
def acknowledge(rid: int, body: AckIn, db: Session = Depends(get_db), user: User = Depends(supervise)):
    r = get_or_404(db, StaffShiftReport, rid, "گزارش")
    if r.user_id == user.id and "*" not in (user.role.permissions or []):     # the owner (full access) may close their own
        raise AppError("گزارش شیفت خودتان را باید مدیر دیگری تأیید کند", 409, "own_report")
    r.acknowledged_by, r.acknowledged_at = user.id, now()
    r.manager_note = (body.note or "").strip() or None
    log_action(db, user, "shift.staff_report_ack", f"تأیید گزارش پایان شیفت {r.user.full_name}", entity="staff_report", entity_id=r.id)
    publish_after_commit(db, "staff_report.submitted", {"id": r.id, "user_id": r.user_id})
    db.commit()
    db.refresh(r)
    return R.report_out(db, r, user)
