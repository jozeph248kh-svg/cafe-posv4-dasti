"""Multi-branch: every branch runs its own server (works fully offline) and pushes closed sales, expenses and
a live snapshot to the central server whenever the internet is available. The central server only aggregates."""
import hashlib
import logging
import secrets
from datetime import timedelta

import httpx
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.config import get_settings
from app.core.utils import now

from .models import Branch, BranchExpense, BranchSale, SyncMap, SyncOutbox

log = logging.getLogger("branches")

DEFAULTS = {
    "branch.mode": "standalone",        # standalone | branch | central
    "branch.central_url": "",
    "branch.api_key": "",
    "branch.last_push": None,
    "branch.last_error": None,
    "branch.expense_days": 40,
}
TIMEOUT = 20


def hash_key(k: str) -> str:
    return hashlib.sha256(k.encode()).hexdigest()


def new_key() -> str:
    return "br_" + secrets.token_urlsafe(30)


def auth_branch(db: Session, key: str | None) -> Branch | None:
    if not key:
        return None
    b = db.query(Branch).filter(Branch.key_hash == hash_key(key.removeprefix("Bearer ").strip())).first()
    return b if b and b.is_active else None


# ----------------------------------------------------------------- branch side: outbox
def sale_payload(order) -> dict:
    pays: dict[str, int] = {}
    for p in order.payments:
        pays[p.method] = pays.get(p.method, 0) + p.amount
    # `total` stays gross of refunds and `refunds` is reported on its own line — the same rule the local sales
    # report uses, so the central figures can be reconciled with the branch's own report
    return {"id": order.id, "number": order.number, "business_date": order.business_date.isoformat(), "type": order.type, "source": order.source,
            "status": order.status, "subtotal": order.subtotal, "discount": order.discount_amount, "total": order.total if order.status == "closed" else 0,
            # a cancelled bill has no revenue (total above is 0), so its refunds must be 0 too — otherwise the
            # central report would show a branch with negative net sales for a bill that never happened
            "refunds": -sum(p.amount for p in order.payments if p.is_refund) if order.status == "closed" else 0,
            "guests": order.guests, "payments": pays, "closed_at": (order.closed_at or order.cancelled_at or now()).isoformat(timespec="seconds"),
            "lines": [{"name": ln.name, "qty": ln.qty, "total": ln.total} for ln in order.active_lines]}


def on_order(db, order, **_):
    if settings_store.get(db, "branch.mode") != "branch":
        return
    if order.status == "cancelled" and not order.payments:
        return
    db.add(SyncOutbox(kind="sale", ref_id=order.id, payload=sale_payload(order)))


def _expenses(db: Session) -> tuple[str, list[dict]]:
    try:
        from app.modules.expenses.models import Expense
    except ImportError:
        return now().date().isoformat(), []
    start = now().date() - timedelta(days=int(settings_store.get(db, "branch.expense_days", 40) or 40))
    rows = db.query(Expense).filter(Expense.expense_date >= start).all()
    return start.isoformat(), [{"id": e.id, "date": e.expense_date.isoformat(), "category": e.category.name if e.category else "", "amount": e.amount, "note": (e.note or "")[:200]} for e in rows]


def snapshot(db: Session) -> dict:
    from app.core.utils import business_day
    from app.modules.orders.models import Order
    # the branch's "today" must be the same business day the orders were filed under (day.cutoff_hour),
    # otherwise the central dashboard shows yesterday's sales as today's for shops open past midnight
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    snap = {"open_orders": db.query(Order).filter(Order.status == "open").count(),
            "today_sales": int(db.query(func.coalesce(func.sum(Order.total), 0)).filter(Order.status == "closed", Order.business_date == today).scalar() or 0),
            "today_orders": db.query(Order).filter(Order.status == "closed", Order.business_date == today).count(), "at": now().isoformat(timespec="seconds")}
    try:
        from app.modules.inventory.models import Ingredient
        low = db.query(Ingredient).filter(Ingredient.min_stock > 0, Ingredient.stock <= Ingredient.min_stock).limit(15).all()
        snap["low_stock"] = [{"name": i.name, "stock": round(i.stock, 1), "min": i.min_stock} for i in low]
    except ImportError:
        pass
    return snap


def _client_headers(db: Session) -> tuple[str, dict]:
    s = settings_store.get_all(db)
    url, key = (s.get("branch.central_url") or "").rstrip("/"), s.get("branch.api_key") or ""
    if not url or not key:
        raise RuntimeError("آدرس سرور مرکزی و کلید شعبه تنظیم نشده است")
    return url, {"Authorization": f"Bearer {key}", "X-Cafe-Version": get_settings().version}


def push(db: Session, limit: int = 200) -> dict:
    """Background job (branch mode): send pending outbox + expenses + snapshot. Safe to call repeatedly."""
    if settings_store.get(db, "branch.mode") != "branch":
        return {"skipped": True}
    rows = db.query(SyncOutbox).filter(SyncOutbox.status == "pending").order_by(SyncOutbox.id).limit(limit).all()
    try:
        url, headers = _client_headers(db)
        exp_from, exps = _expenses(db)
        body = {"sales": [x.payload for x in rows], "expenses": exps, "expense_from": exp_from, "snapshot": snapshot(db)}
        db.commit()           # no transaction is held during the network call (the central server ignores duplicates)
        r = httpx.post(f"{url}/api/branches/sync/push", headers=headers, timeout=TIMEOUT, json=body)
        j = r.json()
        if r.status_code >= 400:
            raise RuntimeError((j.get("detail") or {}).get("message") if isinstance(j.get("detail"), dict) else j.get("detail") or f"HTTP {r.status_code}")
    except (httpx.HTTPError, RuntimeError, ValueError) as e:
        for x in rows:
            x.attempts += 1
        settings_store.set_many(db, {"branch.last_error": f"{now():%H:%M} — {str(e)[:200]}"})
        return {"ok": False, "error": str(e)}
    t = now()
    for x in rows:
        x.status, x.sent_at = "sent", t
    db.query(SyncOutbox).filter(SyncOutbox.status == "sent", SyncOutbox.sent_at < t - timedelta(days=30)).delete()
    settings_store.set_many(db, {"branch.last_push": t.isoformat(timespec="seconds"), "branch.last_error": None})
    return {"ok": True, "sent": len(rows), "branch": j.get("branch")}


def pull_catalog(db: Session, prices_only: bool = False) -> dict:
    """Apply the central menu: match by remembered id, else by exact name; create missing items/categories."""
    from app.modules.menu.models import MenuCategory, MenuItem
    url, headers = _client_headers(db)
    r = httpx.get(f"{url}/api/branches/sync/catalog", headers=headers, timeout=TIMEOUT)
    if r.status_code >= 400:
        raise RuntimeError(f"دریافت منو ناموفق بود (HTTP {r.status_code})")
    data = r.json()
    maps = {(m.kind, m.remote_id): m.local_id for m in db.query(SyncMap)}
    stats = {"categories": 0, "created": 0, "updated": 0, "unchanged": 0}
    cats = {c.name: c for c in db.query(MenuCategory)}
    cat_local: dict[int, int] = {}
    for c in data.get("categories", []):
        lid = maps.get(("category", c["id"]))
        local = db.get(MenuCategory, lid) if lid else cats.get(c["name"])
        if not local and not prices_only:
            local = MenuCategory(name=c["name"], icon=c.get("icon"), color=c.get("color") or "#6366f1", section=c.get("section") or "restaurant", sort=c.get("sort", 0))
            db.add(local)
            db.flush()
            stats["categories"] += 1
        if local:
            cat_local[c["id"]] = local.id
            if ("category", c["id"]) not in maps:
                db.add(SyncMap(kind="category", remote_id=c["id"], local_id=local.id))
    items = {i.name: i for i in db.query(MenuItem)}
    for it in data.get("items", []):
        lid = maps.get(("item", it["id"]))
        local = db.get(MenuItem, lid) if lid else items.get(it["name"])
        if not local:
            if prices_only or it["category_id"] not in cat_local:
                continue
            local = MenuItem(category_id=cat_local[it["category_id"]], name=it["name"], price=it["price"], code=it.get("code"), description=it.get("description"),
                             is_active=it.get("is_active", True), sort=it.get("sort", 0))
            db.add(local)
            db.flush()
            stats["created"] += 1
        else:
            changed = local.price != it["price"] or (not prices_only and (local.name != it["name"] or local.is_active != it.get("is_active", True)))
            local.price = it["price"]
            if not prices_only:
                local.name, local.is_active = it["name"], it.get("is_active", True)
            stats["updated" if changed else "unchanged"] += 1
        if ("item", it["id"]) not in maps:
            db.add(SyncMap(kind="item", remote_id=it["id"], local_id=local.id))
            maps[("item", it["id"])] = local.id
    return stats


# ----------------------------------------------------------------- central side: ingest
def ingest(db: Session, b: Branch, data: dict, ip: str | None, version: str | None) -> dict:
    from datetime import date, datetime
    t = now()
    n_sales = 0
    for s in data.get("sales", []):
        row = db.query(BranchSale).filter(BranchSale.branch_id == b.id, BranchSale.remote_id == s["id"]).first() or BranchSale(branch_id=b.id, remote_id=s["id"])
        row.number, row.business_date, row.type, row.source, row.status = s.get("number", 0), date.fromisoformat(s["business_date"]), s.get("type", "dine_in"), s.get("source", "pos"), s.get("status", "closed")
        row.subtotal, row.discount, row.total, row.guests = s.get("subtotal", 0), s.get("discount", 0), s.get("total", 0), s.get("guests", 1)
        row.refunds = s.get("refunds", 0) or 0
        row.payments, row.lines = s.get("payments") or {}, s.get("lines") or []
        row.closed_at = datetime.fromisoformat(s["closed_at"]) if s.get("closed_at") else None
        row.received_at = t
        db.add(row)
        n_sales += 1
    if "expenses" in data:
        start = date.fromisoformat(data.get("expense_from") or t.date().isoformat())
        seen = set()
        existing = {e.remote_id: e for e in db.query(BranchExpense).filter(BranchExpense.branch_id == b.id, BranchExpense.date >= start)}
        for e in data["expenses"]:
            seen.add(e["id"])
            row = existing.get(e["id"]) or db.query(BranchExpense).filter(BranchExpense.branch_id == b.id, BranchExpense.remote_id == e["id"]).first() or BranchExpense(branch_id=b.id, remote_id=e["id"])
            row.date, row.category, row.amount, row.note = date.fromisoformat(e["date"]), e.get("category") or "سایر", e["amount"], e.get("note")
            db.add(row)
        for rid, row in existing.items():           # deleted on the branch within the window
            if rid not in seen:
                db.delete(row)
    b.last_seen, b.last_ip, b.version = t, ip, version
    if data.get("snapshot"):
        b.snapshot = data["snapshot"]
    return {"sales": n_sales, "expenses": len(data.get("expenses", []))}
