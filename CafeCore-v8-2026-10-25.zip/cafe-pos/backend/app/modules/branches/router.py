from collections import defaultdict
from datetime import date, timedelta

import httpx
from fastapi import APIRouter, Depends, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.config import get_settings
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import now

from . import service as S
from .models import Branch, BranchExpense, BranchSale, SyncOutbox

router = APIRouter()
perm = require("branches.manage")


class BranchIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    code: str = Field(min_length=1, max_length=20)
    address: str | None = None
    is_active: bool = True


class LocalIn(BaseModel):
    mode: str = Field(pattern="^(standalone|branch|central)$")
    central_url: str = ""
    api_key: str | None = None        # None = keep current


def bout(b: Branch) -> dict:
    online = bool(b.last_seen and (now() - b.last_seen) < timedelta(minutes=3))
    return {"id": b.id, "name": b.name, "code": b.code, "address": b.address, "is_active": b.is_active, "key_prefix": b.key_prefix, "last_seen": b.last_seen,
            "last_ip": b.last_ip, "version": b.version, "online": online, "snapshot": b.snapshot or {}}


def _branch(db: Session, authorization: str | None) -> Branch:
    b = S.auth_branch(db, authorization)
    if not b:
        raise AppError("کلید شعبه نامعتبر است", 401, "bad_branch_key")
    return b


# ----------------------------------------------------------------- machine-to-machine (branch → central)
@router.get("/sync/ping")
def ping(authorization: str | None = Header(None), db: Session = Depends(get_db)):
    b = _branch(db, authorization)
    return {"ok": True, "branch": b.name, "central": settings_store.get(db, "business.name", ""), "version": get_settings().version}


@router.post("/sync/push")
async def push(request: Request, authorization: str | None = Header(None), x_cafe_version: str | None = Header(None), db: Session = Depends(get_db)):
    b = _branch(db, authorization)
    data = await request.json()
    res = S.ingest(db, b, data, request.client.host if request.client else None, x_cafe_version)
    db.commit()
    return {"ok": True, "branch": b.name, **res}


@router.get("/sync/catalog")
def catalog(authorization: str | None = Header(None), db: Session = Depends(get_db)):
    from app.modules.menu.models import MenuCategory, MenuItem
    _branch(db, authorization)
    cats = db.query(MenuCategory).order_by(MenuCategory.sort, MenuCategory.id).all()
    items = [i for i in db.query(MenuItem).order_by(MenuItem.sort, MenuItem.id).all() if not (i.code or "").startswith("__")]
    return {"categories": [{"id": c.id, "name": c.name, "icon": c.icon, "color": c.color, "section": c.section, "sort": c.sort} for c in cats],
            "items": [{"id": i.id, "category_id": i.category_id, "name": i.name, "code": i.code, "price": i.price, "description": i.description,
                       "is_active": i.is_active, "sort": i.sort} for i in items]}


# ----------------------------------------------------------------- central admin
@router.get("")
def branches(db: Session = Depends(get_db), _: User = Depends(perm)):
    return [bout(b) for b in db.query(Branch).order_by(Branch.id)]


@router.post("", status_code=201)
def create(data: BranchIn, db: Session = Depends(get_db), user: User = Depends(perm)):
    if db.query(Branch).filter(Branch.code == data.code).first():
        raise AppError("کد شعبه تکراری است")
    key = S.new_key()
    b = Branch(**data.model_dump(), key_hash=S.hash_key(key), key_prefix=key[:8])
    db.add(b)
    db.flush()
    log_action(db, user, "branch.create", f"شعبه «{b.name}»", entity="branch", entity_id=b.id)
    db.commit()
    return {**bout(b), "api_key": key}


@router.put("/{bid}")
def update(bid: int, data: BranchIn, db: Session = Depends(get_db), _: User = Depends(perm)):
    b = get_or_404(db, Branch, bid, "شعبه")
    for k, v in data.model_dump().items():
        setattr(b, k, v)
    db.commit()
    return bout(b)


@router.post("/{bid}/rotate-key")
def rotate(bid: int, db: Session = Depends(get_db), user: User = Depends(perm)):
    b = get_or_404(db, Branch, bid, "شعبه")
    key = S.new_key()
    b.key_hash, b.key_prefix = S.hash_key(key), key[:8]
    log_action(db, user, "branch.key", f"کلید جدید برای شعبه «{b.name}»", entity="branch", entity_id=b.id)
    db.commit()
    return {"api_key": key}


@router.get("/report")
def report(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), _: User = Depends(require("reports.view"))):
    from app.modules.orders.models import Order
    d1, d2 = date_from or now().date() - timedelta(days=6), date_to or now().date()
    rows: dict = {}
    days = [(d1 + timedelta(days=i)).isoformat() for i in range((d2 - d1).days + 1)]

    def blank(key, name, online=None, snap=None):
        return {"key": key, "name": name, "online": online, "snapshot": snap or {}, "sales": 0, "refunds": 0, "orders": 0, "guests": 0, "discount": 0, "expenses": 0,
                "payments": defaultdict(int), "daily": dict.fromkeys(days, 0), "items": defaultdict(lambda: [0, 0])}
    # this server's own sales (the central shop itself)
    local = blank("local", f"{settings_store.get(db, 'business.name', 'این مجموعه')} (این سرور)")
    for o in db.query(Order).filter(Order.status == "closed", Order.business_date >= d1, Order.business_date <= d2).all():
        local["sales"] += o.total
        local["orders"] += 1
        local["guests"] += o.guests
        local["discount"] += o.discount_amount
        local["daily"][o.business_date.isoformat()] += o.total
        for p in o.payments:
            local["payments"][p.method] += p.amount
            if p.is_refund:
                local["refunds"] += -p.amount
        for ln in o.active_lines:
            local["items"][ln.name][0] += ln.qty
            local["items"][ln.name][1] += ln.total
    try:
        from app.modules.expenses.models import Expense
        local["expenses"] = int(db.query(func.coalesce(func.sum(Expense.amount), 0)).filter(Expense.expense_date >= d1, Expense.expense_date <= d2).scalar() or 0)
    except ImportError:
        pass
    if local["orders"] or local["expenses"]:
        rows["local"] = local
    for b in db.query(Branch).order_by(Branch.id):
        bo = bout(b)
        r = blank(b.id, b.name, bo["online"], b.snapshot)
        r["last_seen"] = b.last_seen
        for s in db.query(BranchSale).filter(BranchSale.branch_id == b.id, BranchSale.status == "closed", BranchSale.business_date >= d1, BranchSale.business_date <= d2):
            r["sales"] += s.total
            r["orders"] += 1
            r["guests"] += s.guests
            r["discount"] += s.discount
            r["refunds"] += s.refunds or 0
            r["daily"][s.business_date.isoformat()] = r["daily"].get(s.business_date.isoformat(), 0) + s.total
            for m, a in (s.payments or {}).items():
                r["payments"][m] += a
            for ln in s.lines or []:
                r["items"][ln["name"]][0] += ln["qty"]
                r["items"][ln["name"]][1] += ln["total"]
        r["expenses"] = int(db.query(func.coalesce(func.sum(BranchExpense.amount), 0)).filter(BranchExpense.branch_id == b.id, BranchExpense.date >= d1, BranchExpense.date <= d2).scalar() or 0)
        rows[b.id] = r
    top: dict = defaultdict(lambda: [0, 0])
    out = []
    for r in rows.values():
        for name, (q, t) in r["items"].items():
            top[name][0] += q
            top[name][1] += t
        out.append({**{k: v for k, v in r.items() if k != "items"}, "payments": dict(r["payments"]),
                    "net": r["sales"] - r["refunds"],                 # sales are gross of refunds; this is what stayed in the till
                    "avg_ticket": round(r["sales"] / r["orders"]) if r["orders"] else 0,
                    "top_items": [{"name": n, "qty": q, "total": t} for n, (q, t) in sorted(r["items"].items(), key=lambda x: -x[1][1])[:5]]})
    return {"from": d1, "to": d2, "days": days, "branches": out,
            "totals": {"sales": sum(r["sales"] for r in out), "refunds": sum(r["refunds"] for r in out),
                       "net": sum(r["sales"] - r["refunds"] for r in out),
                       "orders": sum(r["orders"] for r in out), "expenses": sum(r["expenses"] for r in out)},
            "top_items": [{"name": n, "qty": q, "total": t} for n, (q, t) in sorted(top.items(), key=lambda x: -x[1][1])[:10]]}


# ----------------------------------------------------------------- this server's own branch settings
@router.get("/local/status")
def local_status(db: Session = Depends(get_db), _: User = Depends(require("settings.manage"))):
    s = settings_store.get_all(db)
    key = s.get("branch.api_key") or ""
    return {"mode": s.get("branch.mode"), "central_url": s.get("branch.central_url"), "has_key": bool(key), "key_hint": f"{key[:8]}…" if key else None,
            "pending": db.query(SyncOutbox).filter(SyncOutbox.status == "pending").count(), "last_push": s.get("branch.last_push"), "last_error": s.get("branch.last_error"),
            "branches": db.query(Branch).count()}


@router.put("/local/config")
def local_config(data: LocalIn, db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    vals = {"branch.mode": data.mode, "branch.central_url": data.central_url.strip().rstrip("/")}
    if data.api_key is not None:
        vals["branch.api_key"] = data.api_key.strip()
    if data.mode == "branch" and not (vals["branch.central_url"] and (data.api_key or settings_store.get(db, "branch.api_key"))):
        raise AppError("برای حالت شعبه، آدرس سرور مرکزی و کلید شعبه لازم است")
    settings_store.set_many(db, vals)
    log_action(db, user, "branch.mode", f"حالت چندشعبه‌ای: {data.mode}")
    db.commit()
    return {"ok": True}


@router.post("/local/test")
def local_test(db: Session = Depends(get_db), _: User = Depends(require("settings.manage"))):
    try:
        url, headers = S._client_headers(db)
        r = httpx.get(f"{url}/api/branches/sync/ping", headers=headers, timeout=10)
        j = r.json()
    except (httpx.HTTPError, RuntimeError, ValueError) as e:
        raise AppError(f"اتصال برقرار نشد: {e}", code="sync_failed") from e
    if r.status_code >= 400:
        raise AppError("کلید شعبه توسط سرور مرکزی پذیرفته نشد", code="sync_failed")
    return j


@router.post("/local/push")
def local_push(db: Session = Depends(get_db), _: User = Depends(require("settings.manage"))):
    res = S.push(db)
    db.commit()
    if not res.get("ok") and not res.get("skipped"):
        raise AppError(res.get("error") or "ارسال ناموفق بود", code="sync_failed")
    return res


@router.post("/local/pull-catalog")
def local_pull(prices_only: bool = False, db: Session = Depends(get_db), user: User = Depends(require("settings.manage", "menu.manage"))):
    try:
        res = S.pull_catalog(db, prices_only)
    except (httpx.HTTPError, RuntimeError) as e:
        raise AppError(str(e), code="sync_failed") from e
    log_action(db, user, "branch.catalog", f"دریافت منو از مرکز: {res}")
    from app.core.realtime import publish_after_commit
    publish_after_commit(db, "menu.changed", {})
    db.commit()
    return res


@router.post("/local/resync")
def local_resync(days: int = 30, db: Session = Depends(get_db), user: User = Depends(require("settings.manage"))):
    """Queue all closed orders of the last N days again (e.g. after connecting a branch that already had sales)."""
    from app.modules.orders.models import Order
    start = now().date() - timedelta(days=days)
    n = 0
    for o in db.query(Order).filter(Order.status == "closed", Order.business_date >= start):
        db.add(SyncOutbox(kind="sale", ref_id=o.id, payload=S.sale_payload(o)))
        n += 1
    db.commit()
    return {"queued": n}
