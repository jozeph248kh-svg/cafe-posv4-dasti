from datetime import date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, TimestampMixin


# ----------------------------------------------------------------- central side
class Branch(Base, TimestampMixin):
    __tablename__ = "br_branches"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    code: Mapped[str] = mapped_column(String(20), unique=True)
    address: Mapped[str | None] = mapped_column(String(200))
    key_hash: Mapped[str] = mapped_column(String(64), index=True)
    key_prefix: Mapped[str] = mapped_column(String(8))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime)
    last_ip: Mapped[str | None] = mapped_column(String(60))
    version: Mapped[str | None] = mapped_column(String(20))
    snapshot: Mapped[dict | None] = mapped_column(JSON)          # live status pushed by the branch (open orders, low stock…)


class BranchSale(Base):
    __tablename__ = "br_sales"
    __table_args__ = (UniqueConstraint("branch_id", "remote_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    branch_id: Mapped[int] = mapped_column(ForeignKey("br_branches.id"), index=True)
    remote_id: Mapped[int] = mapped_column(Integer)
    number: Mapped[int] = mapped_column(Integer, default=0)
    business_date: Mapped[date] = mapped_column(Date, index=True)
    type: Mapped[str] = mapped_column(String(12))
    source: Mapped[str] = mapped_column(String(12), default="pos")
    status: Mapped[str] = mapped_column(String(12))
    subtotal: Mapped[int] = mapped_column(Integer, default=0)
    discount: Mapped[int] = mapped_column(Integer, default=0)
    total: Mapped[int] = mapped_column(Integer, default=0)          # gross of refunds (same rule as the local report)
    refunds: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    guests: Mapped[int] = mapped_column(Integer, default=1)
    payments: Mapped[dict] = mapped_column(JSON, default=dict)     # {method: amount}
    lines: Mapped[list] = mapped_column(JSON, default=list)        # [{name, qty, total}]
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)
    received_at: Mapped[datetime] = mapped_column(DateTime)


class BranchExpense(Base):
    __tablename__ = "br_expenses"
    __table_args__ = (UniqueConstraint("branch_id", "remote_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    branch_id: Mapped[int] = mapped_column(ForeignKey("br_branches.id"), index=True)
    remote_id: Mapped[int] = mapped_column(Integer)
    date: Mapped[date] = mapped_column(Date, index=True)
    category: Mapped[str] = mapped_column(String(60))
    amount: Mapped[int] = mapped_column(Integer)
    note: Mapped[str | None] = mapped_column(String(200))


# ----------------------------------------------------------------- branch side
class SyncOutbox(Base, TimestampMixin):
    """Closed sales waiting to be pushed to the central server (survives restarts and internet outages)."""
    __tablename__ = "br_outbox"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(12), default="sale")
    ref_id: Mapped[int] = mapped_column(Integer, index=True)
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(10), default="pending", index=True)   # pending | sent
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)


class SyncMap(Base):
    """Central catalog id ↔ local id (menu pulled from the central server)."""
    __tablename__ = "br_syncmap"
    __table_args__ = (UniqueConstraint("kind", "remote_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(12))                  # category | item
    remote_id: Mapped[int] = mapped_column(Integer)
    local_id: Mapped[int] = mapped_column(Integer)
