from app.core import events, settings_store
from app.core.jobs import Job
from app.core.modules import Module
from app.core.permissions import grant_once

from . import service
from .router import router

settings_store.register_defaults(service.DEFAULTS, secrets={"branch.api_key"}, protected={"branch."})


def setup() -> None:
    events.subscribe("order.closed", service.on_order)
    events.subscribe("order.cancelled", service.on_order)
    events.subscribe("order.refunded", service.on_order)       # a refund must reach the central server too


def seed(db) -> None:
    grant_once(db, "branches", {"manager": ["branches.manage"]})


def demo(db) -> None:
    """Two remote branches with a week of synced sales so the consolidated report can be explored."""
    import random
    from datetime import timedelta

    from app.core.utils import business_day, now
    from app.modules.menu.models import MenuItem

    from .models import Branch, BranchExpense, BranchSale
    if db.query(Branch).count():
        return
    rnd = random.Random(11)
    items = [m for m in db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.price > 0).all() if not (m.code or "").startswith("__")]
    today, t = business_day(), now()
    for name, code, scale, rid0 in (("شعبه ونک", "VNK", 1.0, 1000), ("شعبه سعادت‌آباد", "SAD", 0.7, 5000)):
        key = service.new_key()
        b = Branch(name=name, code=code, key_hash=service.hash_key(key), key_prefix=key[:8], last_seen=t - timedelta(seconds=40 if code == "VNK" else 3600 * 5),
                   last_ip="10.8.0." + str(rnd.randint(2, 50)), version="1.0.0",
                   snapshot={"open_orders": rnd.randint(2, 7), "today_sales": 0, "today_orders": 0, "at": t.isoformat(timespec="seconds"),
                             "low_stock": [{"name": "شیر", "stock": 3, "min": 10}] if code == "SAD" else []})
        db.add(b)
        db.flush()
        rid = rid0
        for d in range(7):
            day = today - timedelta(days=d)
            for _ in range(int(rnd.randint(18, 32) * scale)):
                lines = [(m, rnd.randint(1, 3)) for m in rnd.sample(items, k=rnd.randint(1, 4))]
                total = sum(m.price * q for m, q in lines)
                method = rnd.choice(["card", "card", "card", "cash", "online"])
                rid += 1
                db.add(BranchSale(branch_id=b.id, remote_id=rid, number=rid - rid0, business_date=day, type=rnd.choice(["dine_in", "dine_in", "takeaway"]), source="pos",
                                  status="closed", subtotal=total, discount=0, total=total, guests=rnd.randint(1, 4), payments={method: total},
                                  lines=[{"name": m.name, "qty": q, "total": m.price * q} for m, q in lines], closed_at=t - timedelta(days=d), received_at=t))
                if d == 0:
                    b.snapshot = {**b.snapshot, "today_sales": b.snapshot["today_sales"] + total, "today_orders": b.snapshot["today_orders"] + 1}
        for i, (cat, amt) in enumerate((("اجاره", 45_000_000), ("حقوق", 38_000_000), ("خرید مواد", 12_500_000))):
            db.add(BranchExpense(branch_id=b.id, remote_id=i + 1, date=today - timedelta(days=i + 1), category=cat, amount=int(amt * scale)))


module = Module(
    name="branches",
    title="چندشعبه‌ای",
    description="سرور محلی در هر شعبه (کار بدون اینترنت) + همگام‌سازی فروش، هزینه و وضعیت با سرور مرکزی؛ گزارش تجمیعی و ارسال منو از مرکز",
    depends=["orders", "menu"],
    routers=[router],
    permissions={"branches.manage": "مدیریت شعبه‌ها"},
    seed=seed,
    demo=demo,
    setup=setup,
    jobs=[Job("branches.push", 30, service.push)],
)
