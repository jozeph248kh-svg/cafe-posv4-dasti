from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.modules.orders.models import Order

from .handlers import normalize_phone
from app.core.utils import phone_update
from .models import Customer

router = APIRouter()


class CustomerIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    phone: str = Field(min_length=8, max_length=20)
    address: str | None = None
    note: str | None = None


def out(c: Customer) -> dict:
    return {k: getattr(c, k) for k in ("id", "name", "phone", "address", "note", "visits", "total_spent", "last_visit", "created_at")}


@router.get("")
def search(q: str | None = None, limit: int = Query(50, le=500), db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    query = db.query(Customer)
    if q:
        nq = normalize_phone(q) or q
        query = query.filter(or_(Customer.phone.contains(nq), Customer.name.contains(q)))
    return [out(c) for c in query.order_by(Customer.last_visit.desc().nullslast()).limit(limit).all()]


@router.get("/by-phone/{phone}")
def by_phone(phone: str, db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    c = db.query(Customer).filter(Customer.phone == normalize_phone(phone)).first()
    return out(c) if c else None


@router.post("", status_code=201)
def create(data: CustomerIn, db: Session = Depends(get_db), _: User = Depends(require("customers.manage"))):
    phone = normalize_phone(data.phone)
    if db.query(Customer).filter(Customer.phone == phone).first():
        raise AppError("مشتری با این شماره وجود دارد")
    c = Customer(name=data.name, phone=phone, address=data.address, note=data.note)
    db.add(c)
    db.commit()
    return out(c)


@router.put("/{cid}")
def update(cid: int, data: CustomerIn, db: Session = Depends(get_db), _: User = Depends(require("customers.manage"))):
    c = get_or_404(db, Customer, cid, "مشتری")
    phone = phone_update(data.phone, c.phone)
    if db.query(Customer).filter(Customer.phone == phone, Customer.id != cid).first():
        raise AppError("شماره متعلق به مشتری دیگری است")
    c.name, c.phone, c.address, c.note = data.name, phone, data.address, data.note
    db.commit()
    return out(c)


@router.get("/{cid}/orders")
def orders(cid: int, db: Session = Depends(get_db), _: User = Depends(require("pos.access"))):
    c = get_or_404(db, Customer, cid, "مشتری")
    rows = db.query(Order).filter(Order.customer_phone == c.phone).order_by(Order.created_at.desc()).limit(50).all()
    return [{"id": o.id, "number": o.number, "type": o.type, "status": o.status, "total": o.total, "created_at": o.created_at} for o in rows]
