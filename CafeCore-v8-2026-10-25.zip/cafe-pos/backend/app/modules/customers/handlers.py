from sqlalchemy.orm import Session

from app.core import events
from app.core.utils import normalize_phone

from .models import Customer


def on_closed(db: Session, order, **_):
    phone = normalize_phone(order.customer_phone)
    if not phone:
        return
    c = db.query(Customer).filter(Customer.phone == phone).first()
    if not c:
        c = Customer(phone=phone, name=order.customer_name or "مشتری", address=order.customer_address, visits=0, total_spent=0)
        db.add(c)
    elif order.customer_address and not c.address:
        c.address = order.customer_address
    c.visits += 1
    c.total_spent += order.total
    c.last_visit = order.closed_at


def on_refunded(db: Session, order, amount: int = 0, **_):
    """A refund lowers what the customer actually spent — otherwise the loyalty tier keeps counting money
    that was handed back (the cashback itself is already reversed by the loyalty module)."""
    phone = normalize_phone(order.customer_phone)
    if not phone or not amount:
        return
    c = db.query(Customer).filter(Customer.phone == phone).first()
    if not c:
        return
    c.total_spent = max(c.total_spent - int(amount), 0)


def setup() -> None:
    events.subscribe("order.closed", on_closed)
    events.subscribe("order.refunded", on_refunded)
