from app.core.modules import Module

from app.core.permissions import grant_once

from .handlers import setup
from .router import router

def seed(db) -> None:
    # existing installs: managers and cashiers keep seeing full numbers (delivery, club); waiters/kitchen see them masked
    grant_once(db, "customers.phone", {"manager": ["customers.phone"], "cashier": ["customers.phone"]})


module = Module(
    name="customers",
    title="مشتریان",
    description="پرونده مشتری، جستجو با شماره تلفن هنگام سفارش و سابقه خرید",
    depends=["orders"],
    routers=[router],
    permissions={"customers.manage": "مدیریت مشتریان", "customers.phone": "مشاهده کامل شماره تلفن مشتریان (بقیه: 0912***4567)"},
    seed=seed,
    setup=setup,
)
