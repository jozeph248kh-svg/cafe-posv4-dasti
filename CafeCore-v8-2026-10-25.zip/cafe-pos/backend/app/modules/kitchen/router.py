from datetime import timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session, selectinload

from app.core import events
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import publish_after_commit
from app.core.utils import now
from app.modules.orders.models import Order, OrderLine

from .models import KitchenTicket, KitchenTicketItem

router = APIRouter()
kds = require("kitchen.access")
FLOW = {"new": "preparing", "preparing": "ready", "ready": "done"}


class StatusIn(BaseModel):
    status: str = Field(pattern="^(new|preparing|ready|done)$")


def ticket_out(t: KitchenTicket) -> dict:
    return {
        "id": t.id, "order_id": t.order_id, "order_number": t.order_number, "order_type": t.order_type,
        "station_id": t.station_id, "table_name": t.table_name, "waiter_name": t.waiter_name, "note": t.note,
        "status": t.status, "created_at": t.created_at, "started_at": t.started_at, "ready_at": t.ready_at,
        "items": [{"id": i.id, "name": i.name, "qty": i.qty, "modifiers": i.modifiers, "note": i.note,
                   "is_void": i.is_void, "is_done": i.is_done} for i in t.items],
    }


@router.get("/tickets")
def tickets(station_id: int | None = None, include_done: bool = False, db: Session = Depends(get_db), _: User = Depends(kds)):
    q = db.query(KitchenTicket).options(selectinload(KitchenTicket.items))
    statuses = ["new", "preparing", "ready"]
    if include_done:
        q = q.filter((KitchenTicket.status.in_(statuses)) | (KitchenTicket.done_at >= now() - timedelta(minutes=30)))
    else:
        q = q.filter(KitchenTicket.status.in_(statuses))
    if station_id:
        q = q.filter(KitchenTicket.station_id == station_id)
    return [ticket_out(t) for t in q.order_by(KitchenTicket.created_at).all()]


def _sync_lines(db: Session, t: KitchenTicket, status: str) -> None:
    """Mirror ticket progress onto order lines so the POS/waiters see 'ready'."""
    line_ids = [i.order_line_id for i in t.items if not i.is_void and i.order_line_id]
    if not line_ids:
        return
    for line in db.query(OrderLine).filter(OrderLine.id.in_(line_ids)).all():
        if line.status in ("void", "served"):
            continue
        if status == "ready":
            line.status, line.ready_at = "ready", now()
        elif status in ("new", "preparing") and line.status == "ready":
            line.status, line.ready_at = "sent", None


@router.post("/tickets/{tid}/status")
def set_status(tid: int, data: StatusIn, db: Session = Depends(get_db), user: User = Depends(kds)):
    t = get_or_404(db, KitchenTicket, tid, "تیکت")
    if t.status == "void":
        raise AppError("این تیکت لغو شده است")
    t.status = data.status
    ts = now()
    if data.status == "preparing" and not t.started_at:
        t.started_at = ts
    if data.status == "ready":
        t.ready_at = ts
    if data.status == "done":
        t.done_at = ts
    if data.status in ("new", "preparing"):
        t.ready_at = t.done_at = None
    _sync_lines(db, t, data.status)
    publish_after_commit(db, "kitchen.ticket", {"station_id": t.station_id, "action": data.status})
    if data.status == "ready":
        order = db.get(Order, t.order_id)
        publish_after_commit(db, "kitchen.ready", {
            "order_id": t.order_id, "order_number": t.order_number, "table_name": t.table_name,
            "waiter_id": order.waiter_id if order else None,
            "items": [f"{i.qty}× {i.name}" for i in t.items if not i.is_void]})
        publish_after_commit(db, "order.changed", {"id": t.order_id, "action": "ready"})
        if order:
            db.flush()
            events.emit("kitchen.ready", db=db, order=order)
    db.commit()
    return ticket_out(t)


@router.post("/tickets/{tid}/bump")
def bump(tid: int, db: Session = Depends(get_db), user: User = Depends(kds)):
    """Advance to the next status (single tap on the KDS)."""
    t = get_or_404(db, KitchenTicket, tid, "تیکت")
    nxt = FLOW.get(t.status)
    if not nxt:
        raise AppError("تیکت در وضعیت نهایی است")
    return set_status(tid, StatusIn(status=nxt), db, user)


@router.post("/tickets/{tid}/items/{iid}/toggle")
def toggle_item(tid: int, iid: int, db: Session = Depends(get_db), _: User = Depends(kds)):
    it = get_or_404(db, KitchenTicketItem, iid, "آیتم")
    if it.ticket_id != tid:
        raise AppError("آیتم متعلق به این تیکت نیست")
    it.is_done = not it.is_done
    if it.ticket.status == "new":
        it.ticket.status, it.ticket.started_at = "preparing", now()
    publish_after_commit(db, "kitchen.ticket", {"station_id": it.ticket.station_id, "action": "item"})
    db.commit()
    return ticket_out(it.ticket)


@router.get("/stats")
def stats(db: Session = Depends(get_db), _: User = Depends(kds)):
    since = now() - timedelta(hours=12)
    done = db.query(KitchenTicket).filter(KitchenTicket.ready_at.isnot(None), KitchenTicket.created_at >= since).all()
    avg = round(sum((t.ready_at - t.created_at).total_seconds() for t in done) / len(done) / 60, 1) if done else 0
    return {"avg_minutes": avg, "completed": len(done)}
