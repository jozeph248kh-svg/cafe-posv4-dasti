from app.core.modules import Module

from .handlers import setup
from .router import router

module = Module(
    name="kitchen",
    title="آشپزخانه و بار (KDS)",
    description="نمایشگر آشپزخانه: تیکت هر ایستگاه، تایمر، اعلام آماده بودن به گارسون",
    depends=["orders"],
    routers=[router],
    permissions={"kitchen.access": "دسترسی به نمایشگر آشپزخانه و بار"},
    setup=setup,
)
