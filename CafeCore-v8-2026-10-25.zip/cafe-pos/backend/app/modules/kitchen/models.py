from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin


class KitchenTicket(Base, TimestampMixin):
    __tablename__ = "kitchen_tickets"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    station_id: Mapped[int | None] = mapped_column(Integer, index=True)
    order_number: Mapped[int] = mapped_column(Integer)
    order_type: Mapped[str] = mapped_column(String(12))
    table_name: Mapped[str | None] = mapped_column(String(30))
    waiter_name: Mapped[str | None] = mapped_column(String(80))
    note: Mapped[str | None] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(10), default="new", index=True)  # new|preparing|ready|done|void
    started_at: Mapped[datetime | None] = mapped_column(DateTime)
    ready_at: Mapped[datetime | None] = mapped_column(DateTime)
    done_at: Mapped[datetime | None] = mapped_column(DateTime)
    items: Mapped[list["KitchenTicketItem"]] = relationship(back_populates="ticket", cascade="all, delete-orphan", order_by="KitchenTicketItem.id")


class KitchenTicketItem(Base):
    __tablename__ = "kitchen_ticket_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("kitchen_tickets.id", ondelete="CASCADE"), index=True)
    order_line_id: Mapped[int | None] = mapped_column(Integer, index=True)
    name: Mapped[str] = mapped_column(String(100))
    qty: Mapped[int] = mapped_column(Integer)
    modifiers: Mapped[str | None] = mapped_column(String(300))
    note: Mapped[str | None] = mapped_column(String(200))
    is_void: Mapped[bool] = mapped_column(Boolean, default=False)
    is_done: Mapped[bool] = mapped_column(Boolean, default=False)
    ticket: Mapped[KitchenTicket] = relationship(back_populates="items")
