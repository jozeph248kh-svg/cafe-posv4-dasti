"""Reacts to order events — the orders module knows nothing about kitchen tickets."""
from collections import defaultdict

from sqlalchemy.orm import Session

from app.core import events
from app.core.realtime import publish_after_commit

from .models import KitchenTicket, KitchenTicketItem

TYPE_LABEL = {"dine_in": "سالن", "takeaway": "بیرون‌بر", "delivery": "پیک"}


def on_sent(db: Session, order, lines, user, **_):
    by_station = defaultdict(list)
    for l in lines:
        by_station[l.station_id].append(l)
    for station_id, items in by_station.items():
        t = KitchenTicket(
            order_id=order.id, station_id=station_id, order_number=order.number, order_type=order.type,
            table_name=order.table.name if order.table else None,
            waiter_name=order.waiter.full_name if order.waiter else user.full_name, note=order.note,
        )
        t.items = [KitchenTicketItem(order_line_id=l.id, name=l.name, qty=l.qty, note=l.note,
                                     modifiers="، ".join(m["name"] for m in l.modifiers) or None) for l in items]
        db.add(t)
        publish_after_commit(db, "kitchen.ticket", {"station_id": station_id, "order_number": order.number, "action": "new"})


def on_line_voided(db: Session, order, line, **_):
    items = db.query(KitchenTicketItem).filter(KitchenTicketItem.order_line_id == line.id).all()
    for it in items:
        it.is_void = True
        t = it.ticket
        if all(i.is_void for i in t.items):
            t.status = "void"
        publish_after_commit(db, "kitchen.ticket", {"station_id": t.station_id, "order_number": order.number, "action": "void"})


def on_cancelled(db: Session, order, **_):
    for t in db.query(KitchenTicket).filter(KitchenTicket.order_id == order.id, KitchenTicket.status.in_(("new", "preparing"))).all():
        t.status = "void"
        for it in t.items:
            it.is_void = True
        publish_after_commit(db, "kitchen.ticket", {"station_id": t.station_id, "order_number": order.number, "action": "void"})


def on_table_changed(db: Session, order, **_):
    for t in db.query(KitchenTicket).filter(KitchenTicket.order_id == order.id).all():
        t.table_name = order.table.name if order.table else None
    publish_after_commit(db, "kitchen.ticket", {"action": "update"})


def on_merged(db: Session, source, target, **_):
    for t in db.query(KitchenTicket).filter(KitchenTicket.order_id == source.id).all():
        t.order_id, t.order_number = target.id, target.number
        t.table_name = target.table.name if target.table else t.table_name
    publish_after_commit(db, "kitchen.ticket", {"action": "update"})


def setup() -> None:
    events.subscribe("order.sent", on_sent)
    events.subscribe("order.line_voided", on_line_voided)
    events.subscribe("order.cancelled", on_cancelled)
    events.subscribe("order.table_changed", on_table_changed)
    events.subscribe("order.merged", on_merged)
