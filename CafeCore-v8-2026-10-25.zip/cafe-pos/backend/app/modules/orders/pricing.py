"""Order pricing: the single place where an order's money is computed.

`recalc()` is called after every change to an order (a line, a discount, a payment) and derives
subtotal → discounts → service → tax → rounding → total from scratch, so the numbers can never drift
apart. Split out of `service.py` (411 lines); `service.recalc` is re-exported for existing callers.

Money is integer toman throughout. The rounding step (`rounding.step`) uses Python's round()
— banker's rounding — deliberately, so a 2 toman half-step never accumulates one way.
"""
from __future__ import annotations

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store

from .models import Order

def discount_of(typ: str | None, value: int, cap: int | None, base: int) -> int:
    if base <= 0 or not typ:
        return 0
    amount = round(base * min(value, 100) / 100) if typ == "percent" else min(value, base)
    return min(amount, cap) if cap else amount


def recalc(db: Session, o: Order) -> None:
    from . import engine
    s = settings_store.get_all(db)
    engine.apply_auto(db, o)                                  # automatic presets (open orders only)
    o.subtotal = sum(l.total for l in o.active_lines)
    for l in o.lines:
        l.discount_amount = discount_of(l.discount_type, l.discount_value, l.discount_cap, l.total) if l.status != "void" else 0
    o.line_discount_amount = sum(l.discount_amount for l in o.active_lines)
    # bill discount applies to what is left after item discounts; discount_amount = items + bill (used by all reports)
    remainder = o.subtotal - o.line_discount_amount
    if o.discount_type in engine.RULE_KINDS:                  # buy-X-get-Y / combo: computed from the lines
        bill = engine.rule_amount(db, o, o.discount_rule)
        bill = min(bill, o.discount_cap) if o.discount_cap else bill
        bill = max(min(bill, remainder), 0)
    else:
        bill = discount_of(o.discount_type, o.discount_value, o.discount_cap, remainder)
    o.discount_amount = o.line_discount_amount + bill
    base = o.subtotal - o.discount_amount
    o.service_amount = round(base * s["service.percent"] / 100) if s["service.enabled"] and o.type == "dine_in" else 0
    o.tax_amount = round((base + o.service_amount) * s["tax.percent"] / 100) if s["tax.enabled"] else 0
    raw = base + o.service_amount + o.tax_amount
    step = int(s.get("rounding.step") or 0)
    rounded = round(raw / step) * step if step > 0 else raw
    o.rounding = rounded - raw
    o.total = max(rounded, 0)
    o.paid_amount = sum(p.amount for p in o.payments)


def next_number(db: Session, bdate) -> int:
    return (db.query(func.max(Order.number)).filter(Order.business_date == bdate).scalar() or 0) + 1
