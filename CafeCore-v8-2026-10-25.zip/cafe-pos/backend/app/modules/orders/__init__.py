from app.core import settings_store
from app.core.modules import Module

from .discounts import router as discounts_router
from .router import router

settings_store.register_defaults(
    {"discount.reason_required": True,             # custom (non-preset) discounts need a reason
     # POS floor — how long a table may stay seated (the tile shows the minutes in that colour):
     "pos.table_warn_minutes": 60,                 #   from here the tile turns amber
     "pos.table_limit_minutes": 90,                #   from here it turns red (the sitting limit)
     "pos.table_target_minutes": 90},              #   legacy single-value key (kept readable, not shown in the UI)
    ranges={"pos.table_warn_minutes": (1, 600), "pos.table_limit_minutes": (5, 600), "pos.table_target_minutes": (5, 480)},
)

module = Module(
    name="orders",
    title="سفارش‌ها و صندوق فروش",
    description="ثبت سفارش سالن/بیرون‌بر/پیک، ارسال به آشپزخانه، تخفیف، پرداخت چندگانه، تقسیم و انتقال صورتحساب",
    depends=["menu", "floor"],
    routers=[discounts_router, router],   # discounts first: its /discounts/... paths must win over /{oid}
    permissions={
        "pos.access": "دسترسی به صندوق و ثبت سفارش",
        "orders.discount": "اعمال تخفیف (تا سقف تعیین‌شده)",
        "discounts.manage": "تعریف تخفیف‌های آماده و سقف تخفیف کارکنان",
        "orders.void": "حذف آیتم ارسال‌شده به آشپزخانه",
        "orders.cancel": "لغو کامل سفارش",
        "orders.transfer": "انتقال، ادغام و تقسیم سفارش",
        "payments.take": "دریافت پرداخت و بستن سفارش",
        "payments.refund": "بازپرداخت وجه",
    },
)
