"""Order domain logic: the order lifecycle (create, pay, close, cancel, transfer, merge, split, refund).

The pricing maths lives in `pricing.py` and the line operations in `order_lines.py`; both are
re-exported from here, so `service.recalc` / `service.add_lines` … keep working for every caller.
Routers stay thin; everything that changes an order goes through this package.
"""
from __future__ import annotations

import logging
from datetime import timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import events, settings_store
from app.core.audit import log_action
from app.core.errors import AppError
from app.core.models import User
from app.core.privacy import is_masked
from app.core.realtime import publish_after_commit
from app.core.utils import business_day, normalize_phone, now
from app.modules.floor.models import DiningTable
from app.modules.menu.models import MenuItem

from . import engine
from .models import ClientRequest, Order, OrderLine, OrderRefundLine, Payment
from .order_lines import add_lines, build_line, ensure_open, send_to_kitchen, void_line  # noqa: F401  (public API)
from .pricing import discount_of, next_number, recalc                       # noqa: F401  (public API)
from .schemas import LineIn, LineOut, OrderOut, PaymentOut

log = logging.getLogger("orders")

PAYMENT_LABEL = {"cash": "نقد", "card": "کارتخوان", "online": "آنلاین", "credit": "نسیه", "wallet": "کیف پول"}

# ---------------------------------------------------------------- helpers
def to_out(o: Order) -> OrderOut:
    return OrderOut(
        **{k: getattr(o, k) for k in OrderOut.model_fields if k not in
           ("business_date", "table_name", "waiter_name", "remaining", "lines", "payments")},
        business_date=o.business_date.isoformat(),
        table_name=o.table.name if o.table else None,
        waiter_name=o.waiter.full_name if o.waiter else None,
        remaining=o.remaining,
        lines=[{**{k: getattr(l, k) for k in (
            "id", "menu_item_id", "station_id", "name", "base_price", "unit_price", "qty", "modifiers",
            "note", "status", "void_reason", "sent_at", "ready_at", "created_at", "discount_type", "discount_value",
            "discount_amount", "discount_reason", "discount_auto", "returned_qty")}, "total": l.total} for l in o.lines],
        payments=[{k: getattr(p, k) for k in (
            "id", "method", "amount", "tendered", "change", "reference", "is_refund", "note", "created_at")} for p in o.payments],
    )


ORDER_COLS = (Order.id, Order.number, Order.business_date, Order.type, Order.status, Order.source, Order.table_id,
              Order.guests, Order.customer_name, Order.customer_phone, Order.customer_address, Order.note,
              Order.waiter_id, Order.discount_type, Order.discount_value, Order.discount_reason, Order.subtotal,
              Order.discount_amount, Order.line_discount_amount, Order.discount_preset_id, Order.discount_auto,
              Order.discount_code, Order.service_amount, Order.tax_amount, Order.rounding, Order.total,
              Order.paid_amount, Order.bill_printed_at, Order.created_at, Order.closed_at, Order.cancelled_at,
              Order.cancel_reason)
LINE_COLS = (OrderLine.id, OrderLine.order_id, OrderLine.menu_item_id, OrderLine.station_id, OrderLine.name,
             OrderLine.base_price, OrderLine.unit_price, OrderLine.qty, OrderLine.modifiers, OrderLine.note,
             OrderLine.status, OrderLine.void_reason, OrderLine.sent_at, OrderLine.ready_at, OrderLine.created_at,
             OrderLine.discount_type, OrderLine.discount_value, OrderLine.discount_amount, OrderLine.discount_reason,
             OrderLine.discount_auto, OrderLine.returned_qty)
PAY_COLS = (Payment.id, Payment.order_id, Payment.method, Payment.amount, Payment.tendered, Payment.change,
            Payment.reference, Payment.is_refund, Payment.note, Payment.created_at)


def orders_out(db: Session, status: str = "open", type: str | None = None) -> list[OrderOut]:
    """The same payload as `[to_out(o) for o in ...]`, built from column queries.

    Why: the ORM version materialised every order, line and payment as an instrumented object (plus two eagerly
    joined relations) and then copied them into dicts, twice. On a busy board (thousands of open orders, used by
    the POS and the floor screen on every change) that was the second slowest endpoint in the load test.
    Three plain queries return only the columns the payload needs; nothing is dropped and the JSON is identical
    (tests/test_active_orders.py compares it field by field with the ORM version).
    """
    q = (db.query(*ORDER_COLS, DiningTable.name, User.full_name)
         .select_from(Order)
         .outerjoin(DiningTable, Order.table_id == DiningTable.id)
         .outerjoin(User, Order.waiter_id == User.id)
         .filter(Order.status == status))
    if type:
        q = q.filter(Order.type == type)
    rows = q.order_by(Order.created_at).all()
    if not rows:
        return []
    ids = [r[0] for r in rows]
    lines_by: dict[int, list] = {}
    for r in (db.query(*LINE_COLS).filter(OrderLine.order_id.in_(ids))
                 .execution_options(yield_per=5000).order_by(OrderLine.order_id, OrderLine.id)):
        lines_by.setdefault(r[1], []).append(LineOut.model_construct(
            id=r[0], menu_item_id=r[2], station_id=r[3], name=r[4], base_price=r[5], unit_price=r[6], qty=r[7],
            modifiers=r[8] or [], note=r[9], status=r[10], void_reason=r[11], sent_at=r[12], ready_at=r[13],
            created_at=r[14], discount_type=r[15], discount_value=r[16] or 0, discount_amount=r[17] or 0,
            discount_reason=r[18], discount_auto=bool(r[19]), returned_qty=r[20] or 0, total=(r[6] or 0) * (r[7] or 0)))
    pays_by: dict[int, list] = {}
    for r in db.query(*PAY_COLS).filter(Payment.order_id.in_(ids)).order_by(Payment.order_id, Payment.id):
        pays_by.setdefault(r[1], []).append(PaymentOut.model_construct(
            id=r[0], method=r[2], amount=r[3], tendered=r[4], change=r[5], reference=r[6],
            is_refund=bool(r[7]), note=r[8], created_at=r[9]))
    out = []
    for r in rows:
        oid, total, paid = r[0], r[25], r[26]
        out.append(OrderOut.model_construct(
            id=oid, number=r[1], business_date=r[2].isoformat(), type=r[3], status=r[4], source=r[5],
            table_id=r[6], table_name=r[32], guests=r[7], customer_name=r[8], customer_phone=r[9],
            customer_address=r[10], note=r[11], waiter_id=r[12], waiter_name=r[33], discount_type=r[13],
            discount_value=r[14], discount_reason=r[15], subtotal=r[16], discount_amount=r[17],
            line_discount_amount=r[18] or 0, discount_preset_id=r[19], discount_auto=bool(r[20]),
            discount_code=r[21], service_amount=r[22], tax_amount=r[23], rounding=r[24], total=total,
            paid_amount=paid, remaining=max(total - paid, 0), bill_printed_at=r[27], created_at=r[28],
            closed_at=r[29], cancelled_at=r[30], cancel_reason=r[31],
            lines=lines_by.get(oid, []), payments=pays_by.get(oid, [])))
    return out


def notify(db: Session, o: Order, action: str = "updated") -> None:
    publish_after_commit(db, "order.changed", {"id": o.id, "table_id": o.table_id, "status": o.status, "action": action})


def table_open_order(db: Session, table_id: int) -> Order | None:
    return db.query(Order).filter(Order.table_id == table_id, Order.status == "open").first()


def next_number(db: Session, bdate) -> int:
    return (db.query(func.max(Order.number)).filter(Order.business_date == bdate).scalar() or 0) + 1


def discount_of(typ: str | None, value: int, cap: int | None, base: int) -> int:
    if base <= 0 or not typ:
        return 0
    amount = round(base * min(value, 100) / 100) if typ == "percent" else min(value, base)
    return min(amount, cap) if cap else amount


def recalc(db: Session, o: Order) -> None:
    from . import engine
    s = settings_store.get_all(db)
    engine.apply_auto(db, o)                                  # automatic presets (open orders only)
    o.subtotal = sum(l.total for l in o.active_lines)
    for l in o.lines:
        l.discount_amount = discount_of(l.discount_type, l.discount_value, l.discount_cap, l.total) if l.status != "void" else 0
    o.line_discount_amount = sum(l.discount_amount for l in o.active_lines)
    # bill discount applies to what is left after item discounts; discount_amount = items + bill (used by all reports)
    remainder = o.subtotal - o.line_discount_amount
    if o.discount_type in engine.RULE_KINDS:                  # buy-X-get-Y / combo: computed from the lines
        bill = engine.rule_amount(db, o, o.discount_rule)
        bill = min(bill, o.discount_cap) if o.discount_cap else bill
        bill = max(min(bill, remainder), 0)
    else:
        bill = discount_of(o.discount_type, o.discount_value, o.discount_cap, remainder)
    o.discount_amount = o.line_discount_amount + bill
    base = o.subtotal - o.discount_amount
    o.service_amount = round(base * s["service.percent"] / 100) if s["service.enabled"] and o.type == "dine_in" else 0
    o.tax_amount = round((base + o.service_amount) * s["tax.percent"] / 100) if s["tax.enabled"] else 0
    raw = base + o.service_amount + o.tax_amount
    step = int(s.get("rounding.step") or 0)
    rounded = round(raw / step) * step if step > 0 else raw
    o.rounding = rounded - raw
    o.total = max(rounded, 0)
    o.paid_amount = sum(p.amount for p in o.payments)


# ---------------------------------------------------------------- lifecycle
def customer_phone_for(db: Session, customer_id: int | None, phone: str | None) -> str | None:
    """A customer picked from the search: users without `customers.phone` only saw a masked number, so the
    server takes the real one from the customer file (when no full number was typed)."""
    if not customer_id or (phone and not is_masked(phone)):
        return phone
    try:
        from app.modules.customers.models import Customer     # optional module (customers depends on orders)
    except ImportError:
        return None if is_masked(phone) else phone
    c = db.get(Customer, customer_id)
    if c:
        return c.phone
    return None if is_masked(phone) else phone


def create_order(db: Session, data, user: User) -> Order:
    table = None
    if data.type == "dine_in":
        if not data.table_id:
            raise AppError("برای سفارش سالن، میز را انتخاب کنید")
        table = db.get(DiningTable, data.table_id)
        if not table or not table.is_active:
            raise AppError("میز انتخاب‌شده معتبر نیست")
        if table_open_order(db, table.id):
            raise AppError(f"میز {table.name} سفارش باز دارد", code="table_busy")
    if getattr(data, "customer_id", None):
        data.customer_phone = customer_phone_for(db, data.customer_id, data.customer_phone)
    if data.type == "delivery" and not (data.customer_phone and data.customer_address):
        raise AppError("برای سفارش پیک، شماره تماس و آدرس مشتری الزامی است")

    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    bdate = business_day(cutoff_hour=cutoff)
    o = Order(
        number=next_number(db, bdate), business_date=bdate, type=data.type, status="open",
        table_id=table.id if table else None, guests=data.guests, customer_name=data.customer_name,
        customer_phone=normalize_phone(data.customer_phone), customer_address=data.customer_address, note=data.note,
        waiter_id=data.waiter_id or user.id, created_by=user.id,
    )
    db.add(o)
    if data.lines:
        add_lines(db, o, data.lines, user)
    db.flush()
    if data.send:
        send_to_kitchen(db, o, user)
    recalc(db, o)
    notify(db, o, "created")
    return o


def client_request(db: Session, request_id: str | None, kind: str) -> int | None:
    """Order id an earlier submission with this id produced (retry / offline replay), else None."""
    if not request_id:
        return None
    hit = db.query(ClientRequest).filter(ClientRequest.request_id == request_id).first()
    if hit and hit.kind != kind:
        raise AppError("شناسه درخواست تکراری است", 409, "duplicate_request")
    return hit.order_id if hit else None


def remember_request(db: Session, request_id: str | None, kind: str, o: Order, user: User) -> None:
    if not request_id:
        return
    db.flush()
    db.query(ClientRequest).filter(ClientRequest.created_at < now() - timedelta(days=14)).delete(synchronize_session=False)
    db.add(ClientRequest(request_id=request_id, kind=kind, order_id=o.id, user_id=user.id))


def replayed(db: Session, o: Order, request_id: str | None) -> bool:
    """True if this submission was already applied (network retry / double click) → caller returns current state."""
    if not request_id:
        return False
    hit = db.query(Payment).filter(Payment.request_id.startswith(f"{request_id}:", autoescape=True)).first()
    if hit and hit.order_id != o.id:
        raise AppError("شناسه درخواست تکراری است", 409, "duplicate_request")
    return hit is not None


def audit_rejected_payment(db: Session, o: Order, p, user: User | None, err: AppError,
                           request_id: str | None = None, remaining: int | None = None) -> None:
    """Record a refused tender in the audit trail — separately from the transaction that is about to be rolled back.

    The rejection itself is the interesting event for a cash business (a cashier trying to take more than the bill,
    a wrong change, a retried double click). It must survive the rollback of the request, so the failed transaction
    is rolled back FIRST (that also releases SQLite's write lock) and the audit row is committed on its own after it.
    A failure while writing the audit row is logged and swallowed: it must never turn a refused payment into a
    recorded one, and it must never replace the original error with a 500.
    """
    detail = getattr(err, "detail", None) if isinstance(getattr(err, "detail", None), dict) else {}
    reason_code = detail.get("code") or "rejected"
    reason = detail.get("message") or str(err)
    try:
        db.rollback()                      # the refused request leaves nothing behind (no payment, no partial state)
        log_action(db, user, "payment.rejected",
                   f"تلاش ناموفق دریافت {getattr(p, 'amount', 0):,} تومان "
                   f"({PAYMENT_LABEL.get(getattr(p, 'method', ''), getattr(p, 'method', ''))}) — "
                   f"سفارش #{getattr(o, 'number', '?')} — علت: {reason}"[:250],
                   entity="order", entity_id=getattr(o, "id", None),
                   details={"amount": getattr(p, "amount", None), "method": getattr(p, "method", None),
                            "tendered": getattr(p, "tendered", None), "reference": getattr(p, "reference", None),
                            "reason_code": reason_code, "reason": reason, "remaining": remaining,
                            "request_id": request_id})
        db.commit()
    except Exception:                      # noqa: BLE001 — never hide the original refusal behind a logging error
        log.exception("could not write the rejected-payment audit row")
        try:
            db.rollback()
        except Exception:                  # noqa: BLE001
            pass


def add_payments(db: Session, o: Order, payments, user: User, request_id: str | None = None) -> list[Payment]:
    if replayed(db, o, request_id):
        return []
    # A bill whose total is 0 (100 % discount / «مهمان مدیر») has nothing to pay: it is settled by closing it.
    # Repeating that (double click, retried request) is a no-op — it must not fail and must not log twice.
    if not payments and o.status == "closed" and o.total == 0:
        return []
    order_id, current, remaining = o.id, None, None
    try:
        ensure_open(o)
        recalc(db, o)
        if not o.active_lines:
            raise AppError("سفارش خالی است", code="empty_order")
        if o.total == 0:
            # nothing is due: close the bill — never with a 0-toman payment row (that would pollute the money
            # history) and never by cancelling it (that would erase a sale from the books)
            if payments:
                raise AppError("مبلغ این سفارش صفر است؛ پرداختی لازم نیست — سفارش را ببندید", code="nothing_to_pay")
            if any(l.status == "pending" for l in o.lines):
                send_to_kitchen(db, o, user)          # the kitchen still has to make it
            close_order(db, o, user)
            log_action(db, user, "order.close",
                       f"بستن سفارش #{o.number} با مبلغ صفر — تخفیف کامل {o.discount_amount:,} تومان",
                       entity="order", entity_id=o.id,
                       details={"total": 0, "subtotal": o.subtotal, "discount_amount": o.discount_amount,
                                "discount_reason": o.discount_reason, "lines": len(o.active_lines)})
            notify(db, o, "paid")
            return []
        if not payments:
            raise AppError("مبلغ پرداخت را وارد کنید", code="payment_required")
        if any(l.status == "pending" for l in o.lines):
            # auto-send anything not yet sent so the kitchen never misses a paid item
            send_to_kitchen(db, o, user)
        created = []
        remaining = o.remaining
        for p in payments:
            current = p
            if remaining <= 0:
                raise AppError("مبلغ سفارش قبلاً کامل پرداخت شده است", code="already_paid")
            amount = min(p.amount, remaining)
            change = 0
            if p.method == "cash":
                if p.tendered is not None and p.tendered < amount:
                    raise AppError("مبلغ دریافتی نقدی کمتر از مبلغ پرداخت است", code="tendered_too_low")
                tendered = p.tendered or p.amount
                change = max(tendered - amount, 0)
            elif p.amount > remaining:
                raise AppError(f"مبلغ پرداخت {PAYMENT_LABEL[p.method]} بیشتر از مانده حساب است", code="overpayment")
            if p.method == "credit" and not (o.customer_name or o.customer_phone):
                raise AppError("برای فروش نسیه، نام یا شماره مشتری را ثبت کنید", code="customer_required")
            pay = Payment(method=p.method, amount=amount, tendered=p.tendered if p.method == "cash" else None,
                          change=change, reference=p.reference, created_by=user.id,
                          request_id=f"{request_id}:{len(created)}" if request_id else None)
            events.emit("payment.creating", db=db, payment=pay, order=o, user=user)   # shifts module validates & tags
            # Every tender goes into the audit trail: for a cash business the question "who took this
            # money, when, on which shift" must be answerable from the log alone (tax forensics / zapper
            # checks look for exactly this). Refunds were logged, payments were not.
            log_action(db, user, "payment.refund" if pay.is_refund else "payment.take",
                       f"{'بازپرداخت' if pay.is_refund else 'دریافت'} {amount:,} تومان ({PAYMENT_LABEL.get(p.method, p.method)}) — سفارش #{o.number}",
                       entity="order", entity_id=o.id, details={"method": p.method, "amount": amount})
            o.payments.append(pay)
            created.append(pay)
            remaining -= amount
        recalc(db, o)
        if o.remaining == 0:
            close_order(db, o, user)
        notify(db, o, "paid")
        return created
    except AppError as err:
        # a refused tender is part of the money history: log it AFTER rolling the request back (see the helper)
        rejected = current if current is not None else (payments[0] if payments else None)
        db.rollback()
        audit_rejected_payment(db, db.get(Order, order_id) or o, rejected, user, err, request_id, remaining)
        raise


def close_order(db: Session, o: Order, user: User) -> None:
    o.status, o.closed_at = "closed", now()
    for l in o.lines:
        if l.status in ("sent", "ready"):
            l.status = "served"
    db.flush()
    events.emit("order.closed", db=db, order=o, user=user)


def cancel_order(db: Session, o: Order, reason: str, user: User, approver: User) -> None:
    ensure_open(o)
    if o.paid_amount > 0:
        raise AppError("برای سفارش دارای پرداخت، ابتدا وجه را بازپرداخت کنید")
    was_sent = any(l.status in ("sent", "ready", "served") for l in o.lines)
    o.status, o.cancelled_at, o.cancel_reason = "cancelled", now(), reason
    if was_sent or o.lines:
        log_action(db, user, "order.cancel", f"لغو سفارش #{o.number} به مبلغ {o.total:,} — دلیل: {reason}",
                   entity="order", entity_id=o.id, approver=approver, details={"amount": o.total})
    events.emit("order.cancelled", db=db, order=o)
    notify(db, o, "cancelled")


def transfer(db: Session, o: Order, table_id: int, user: User) -> None:
    ensure_open(o)
    table = db.get(DiningTable, table_id)
    if not table or not table.is_active:
        raise AppError("میز مقصد معتبر نیست")
    if table_open_order(db, table_id):
        raise AppError(f"میز {table.name} سفارش باز دارد؛ از «ادغام» استفاده کنید", code="table_busy")
    old = o.table.name if o.table else "-"
    o.table_id, o.type = table.id, "dine_in"
    db.flush()
    db.refresh(o)
    log_action(db, user, "order.transfer", f"انتقال سفارش #{o.number} از میز {old} به میز {table.name}", entity="order", entity_id=o.id)
    events.emit("order.table_changed", db=db, order=o)
    recalc(db, o)
    publish_after_commit(db, "order.changed", {"id": o.id, "table_id": table_id, "action": "transfer"})


def merge(db: Session, src: Order, dst: Order, user: User) -> None:
    ensure_open(src)
    ensure_open(dst)
    if src.id == dst.id:
        raise AppError("سفارش مبدأ و مقصد یکی است")
    if src.paid_amount:
        raise AppError("سفارش دارای پرداخت قابل ادغام نیست")
    for l in list(src.lines):
        src.lines.remove(l)
        dst.lines.append(l)
    dst.guests += src.guests
    src.status, src.cancelled_at, src.cancel_reason = "cancelled", now(), f"ادغام در سفارش #{dst.number}"
    db.flush()
    events.emit("order.merged", db=db, source=src, target=dst)
    recalc(db, src)
    recalc(db, dst)
    log_action(db, user, "order.merge", f"ادغام سفارش #{src.number} در #{dst.number}", entity="order", entity_id=dst.id)
    notify(db, src, "merged")
    notify(db, dst)


BILL_DISCOUNT_FIELDS = ("discount_type", "discount_value", "discount_cap", "discount_reason", "discount_code",
                        "discount_rule", "discount_preset_id", "discount_auto", "discount_by", "discount_approved_by")


def _bill_discount_state(o: Order) -> dict:
    return {k: getattr(o, k) for k in BILL_DISCOUNT_FIELDS}


def _share_bill_discount(o: Order, new: Order, bill_before: int, base_before: int, base_moved: int) -> None:
    """Keep a bill-level discount whole when a bill is split into two.

    The discount was granted on the *whole* bill, so the part of it that belongs to the lines that moved
    has to travel with them — otherwise the customer loses it (percent) or the two bills together discount
    more than was approved (a fixed amount larger than what stays on the source bill).
    A fixed amount is shared in exact proportion; a percentage stays a percentage on both bills (a
    per-bill rounding of at most one toman, exactly like any other percent discount) and a capped
    percentage gets its cap shared so the cap can never be granted twice.
    """
    if bill_before <= 0 or base_before <= 0 or base_moved <= 0:
        return
    share = max(min(round(bill_before * base_moved / base_before), bill_before), 0)
    share = min(share, base_moved)                                  # never more than what the moved lines cost
    if o.discount_auto:
        # an automatic promotion applies to every bill on its own (a customer who really has two bills
        # gets the promotion twice) — never silently rewrite the source bill's auto state
        for k in BILL_DISCOUNT_FIELDS:
            setattr(new, k, getattr(o, k))
        return
    new.discount_reason, new.discount_code = o.discount_reason, o.discount_code
    new.discount_by, new.discount_approved_by = o.discount_by, o.discount_approved_by
    if o.discount_type in engine.RULE_KINDS:                        # buy-X-get-Y / combo: recomputed from each bill's lines
        new.discount_type, new.discount_rule, new.discount_value = o.discount_type, o.discount_rule, o.discount_value
        new.discount_cap = share or None
    elif o.discount_type == "percent":
        new.discount_type, new.discount_value = "percent", o.discount_value
        if o.discount_cap:
            new.discount_cap = share
            o.discount_cap = (o.discount_cap - share) or None
    else:                                                          # fixed amount: exact proportional split
        new.discount_type, new.discount_value = "amount", share
        o.discount_value = bill_before - share


def split(db: Session, o: Order, parts, user: User) -> Order:
    """Move selected lines (or part of their quantity) to a new order on the same table."""
    ensure_open(o)
    recalc(db, o)                                   # the bill discount is snapshotted below — it has to be current
    bill_before = o.discount_amount - o.line_discount_amount        # bill-level discount, item discounts excluded
    base_before = o.subtotal - o.line_discount_amount               # the base that discount was computed on
    lines = {l.id: l for l in o.lines if l.status != "void"}
    seen: set[int] = set()
    for p in parts:
        if p.line_id in seen:                                       # the same line twice would move it twice
            raise AppError("یک قلم دو بار در درخواست تقسیم آمده است", code="duplicate_line")
        seen.add(p.line_id)
    new = Order(number=next_number(db, o.business_date), business_date=o.business_date, type=o.type,
                status="open", table_id=o.table_id, guests=1, waiter_id=o.waiter_id, created_by=user.id,
                customer_name=o.customer_name, customer_phone=o.customer_phone,
                customer_address=o.customer_address, note=o.note)
    db.add(new)
    moved = 0
    for p in parts:
        l = lines.get(p.line_id)
        if not l:
            raise AppError("آیتم انتخاب‌شده در این سفارش نیست")
        if p.qty > l.qty:
            raise AppError(f"تعداد انتخابی «{l.name}» بیشتر از سفارش است")
        if p.qty == l.qty:
            o.lines.remove(l)
            new.lines.append(l)
        else:
            moved_value = l.discount_value
            if l.discount_type == "amount":           # a fixed item discount is shared in proportion to the quantity
                moved_value = round(l.discount_value * p.qty / l.qty)
                l.discount_value -= moved_value
            l.qty -= p.qty
            new.lines.append(OrderLine(**{k: getattr(l, k) for k in (
                "menu_item_id", "station_id", "name", "base_price", "unit_price", "modifiers", "note",
                "status", "sent_at", "ready_at", "created_by", "discount_type", "discount_cap", "discount_reason",
                "discount_preset_id", "discount_by", "discount_approved_by", "discount_auto")}, qty=p.qty, discount_value=moved_value))
        moved += 1
    if not o.active_lines:
        raise AppError("حداقل یک آیتم باید در سفارش اصلی باقی بماند")
    db.flush()
    base_moved = sum(l.total - discount_of(l.discount_type, l.discount_value, l.discount_cap, l.total) for l in new.lines)
    _share_bill_discount(o, new, bill_before, base_before, base_moved)
    recalc(db, o)
    recalc(db, new)
    if o.paid_amount > o.total:
        raise AppError("مبلغ پرداخت‌شده سفارش اصلی بیشتر از مبلغ جدید می‌شود")
    log_action(db, user, "order.split", f"تقسیم سفارش #{o.number} → #{new.number}", entity="order", entity_id=o.id)
    events.emit("order.split", db=db, source=o, target=new)
    notify(db, o)
    notify(db, new, "created")
    return new


def refund(db: Session, o: Order, data, user: User, approver: User) -> None:
    """Money back and/or goods back — two events that are recorded independently.

    * `amount > 0`  → a refund payment is written (money leaves the till).
    * `restock`     → one `order_refund_lines` row per returned line, stamped with the moment of the event and the
      historical unit cost frozen when the bill closed. The COGS of the sale day is never touched again; the
      material cost is given back on the day of the return (owner's accounting policy).
    * `amount == 0` → goods-only return (no money moves, no payment row at all — never a fake 0 payment).
    """
    request_id = getattr(data, "request_id", None)
    if request_id and db.query(OrderRefundLine.id).filter(OrderRefundLine.request_id == request_id,
                                                          OrderRefundLine.order_id == o.id).first():
        return                                   # the same submission replayed: nothing new to book
    if replayed(db, o, request_id):
        return
    if o.status != "closed":
        raise AppError("بازپرداخت فقط برای سفارش‌های بسته‌شده امکان‌پذیر است")
    refunded = -sum(p.amount for p in o.payments if p.is_refund)
    if data.amount > o.paid_amount:
        raise AppError("مبلغ بازپرداخت بیشتر از مبلغ پرداخت‌شده است")
    if data.amount == 0 and not (getattr(data, "restock", None) or []):
        raise AppError("درخواست خالی است: نه مبلغی برمی‌گردد و نه کالایی", code="empty_refund")
    returned = []
    lines = {l.id: l for l in o.lines}
    seen: set[int] = set()
    for r in getattr(data, "restock", None) or []:
        if r.line_id in seen:                     # the same line twice in one request would double-count the return
            raise AppError("یک قلم دو بار در درخواست برگشت آمده است", code="duplicate_line")
        seen.add(r.line_id)
        line = lines.get(r.line_id)
        if not line or line.status == "void":
            raise AppError("قلم انتخاب‌شده برای برگشت در این سفارش نیست")
        if r.qty > line.qty - (line.returned_qty or 0):
            raise AppError(f"تعداد برگشتی «{line.name}» بیشتر از تعداد فروخته‌شده است")
        line.returned_qty = (line.returned_qty or 0) + r.qty
        returned.append((line, r.qty))
    pay = None
    if data.amount > 0:
        pay = Payment(method=data.method, amount=-data.amount, is_refund=True, note=data.reason, created_by=user.id,
                      request_id=f"{request_id}:0" if request_id else None)
        events.emit("payment.creating", db=db, payment=pay, order=o, user=user)
        o.payments.append(pay)
        db.flush()                                # the events below point at this payment
        o.paid_amount = sum(p.amount for p in o.payments)
    for line, qty in returned:
        unit_cost = (float(line.cost_amount) / line.qty) if (line.cost_amount is not None and line.qty) else None
        db.add(OrderRefundLine(order_id=o.id, line_id=line.id, qty=qty, unit_cost=unit_cost,
                               refund_payment_id=pay.id if pay else None, request_id=request_id,
                               kind="money" if pay else "stock", source="event",
                               note=(data.reason or "")[:200], created_by=user.id))
    log_action(db, user, "payment.refund" if pay else "order.stock_return",
               (f"بازپرداخت {data.amount:,} برای سفارش #{o.number}" if pay else f"برگشت کالا بدون بازپرداخت برای سفارش #{o.number}")
               + (f" — {data.reason}" if data.reason else ""),
               entity="order", entity_id=o.id, approver=approver,
               details={"amount": data.amount, "method": data.method, "previous_refunds": refunded,
                        "returned": [{"line_id": l.id, "name": l.name, "qty": q,
                                      "unit_cost": (float(l.cost_amount) / l.qty) if (l.cost_amount is not None and l.qty) else None}
                                     for l, q in returned]})
    # every refund is announced, with or without returned items: the customer file, the branch sync and the
    # stock return all hang off this event (a money-only refund used to be invisible to them)
    events.emit("order.refunded", db=db, order=o, user=user, returned=returned, amount=data.amount)
    notify(db, o, "refund")
