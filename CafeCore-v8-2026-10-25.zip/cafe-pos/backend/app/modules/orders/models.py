from datetime import date, datetime

from sqlalchemy import (Boolean, Date, DateTime, false, Float, ForeignKey, Index, Integer, JSON, String,
                        Text, UniqueConstraint, text)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin
from app.core.models import User
from app.modules.floor.models import DiningTable

ORDER_TYPES = ("dine_in", "takeaway", "delivery")
PAYMENT_METHODS = ("cash", "card", "online", "credit", "wallet")


class Order(Base, TimestampMixin):
    __tablename__ = "orders"
    # one number per business day; numbering is serialised (SQLite write lock / PG advisory lock) — this is the backstop
    __table_args__ = (Index("ux_orders_day_number", "business_date", "number", unique=True),)
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[int] = mapped_column(Integer)                         # daily sequence shown to staff/customers
    business_date: Mapped[date] = mapped_column(Date, index=True)
    type: Mapped[str] = mapped_column(String(12), default="dine_in")
    status: Mapped[str] = mapped_column(String(12), default="open", index=True)   # open | closed | cancelled
    source: Mapped[str] = mapped_column(String(10), default="pos")       # pos | qr | phone | online
    table_id: Mapped[int | None] = mapped_column(ForeignKey("dining_tables.id"), index=True)
    guests: Mapped[int] = mapped_column(Integer, default=1)
    customer_name: Mapped[str | None] = mapped_column(String(80))
    customer_phone: Mapped[str | None] = mapped_column(String(20), index=True)
    customer_address: Mapped[str | None] = mapped_column(Text)
    note: Mapped[str | None] = mapped_column(Text)
    waiter_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))

    discount_type: Mapped[str | None] = mapped_column(String(10))        # percent | amount
    discount_value: Mapped[int] = mapped_column(Integer, default=0)
    discount_reason: Mapped[str | None] = mapped_column(String(120))

    subtotal: Mapped[int] = mapped_column(Integer, default=0)
    discount_amount: Mapped[int] = mapped_column(Integer, default=0)    # TOTAL discount = item discounts + bill discount
    line_discount_amount: Mapped[int] = mapped_column(Integer, default=0, server_default="0")  # part of discount_amount given on items
    discount_cap: Mapped[int | None] = mapped_column(Integer)            # max toman for a percent bill discount (preset)
    discount_preset_id: Mapped[int | None] = mapped_column(Integer)
    discount_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    discount_approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    discount_code: Mapped[str | None] = mapped_column(String(30))         # promo code used (business-approved, no ceiling)
    discount_rule: Mapped[dict | None] = mapped_column(JSON)              # bogo/combo parameters (snapshot of the preset)
    discount_auto: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())  # applied by an auto preset
    service_amount: Mapped[int] = mapped_column(Integer, default=0)
    tax_amount: Mapped[int] = mapped_column(Integer, default=0)
    rounding: Mapped[int] = mapped_column(Integer, default=0)
    total: Mapped[int] = mapped_column(Integer, default=0)
    paid_amount: Mapped[int] = mapped_column(Integer, default=0)

    bill_printed_at: Mapped[datetime | None] = mapped_column(DateTime)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime)
    cancel_reason: Mapped[str | None] = mapped_column(String(200))

    table: Mapped[DiningTable | None] = relationship(lazy="joined")
    waiter: Mapped[User | None] = relationship(foreign_keys=[waiter_id], lazy="joined")
    lines: Mapped[list["OrderLine"]] = relationship(back_populates="order", cascade="all, delete-orphan", order_by="OrderLine.id")
    payments: Mapped[list["Payment"]] = relationship(back_populates="order", cascade="all, delete-orphan", order_by="Payment.id")

    @property
    def active_lines(self) -> list["OrderLine"]:
        return [l for l in self.lines if l.status != "void"]

    @property
    def remaining(self) -> int:
        return max(self.total - self.paid_amount, 0)


class OrderLine(Base, TimestampMixin):
    __tablename__ = "order_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    menu_item_id: Mapped[int] = mapped_column(ForeignKey("menu_items.id"), index=True)
    station_id: Mapped[int | None] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(100))                       # snapshot (menu may change later)
    base_price: Mapped[int] = mapped_column(Integer)
    unit_price: Mapped[int] = mapped_column(Integer)                     # base + modifiers
    qty: Mapped[int] = mapped_column(Integer, default=1)
    modifiers: Mapped[list[dict]] = mapped_column(JSON, default=list)    # [{id, name, price}]
    note: Mapped[str | None] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(10), default="pending")   # pending|sent|ready|served|void
    void_reason: Mapped[str | None] = mapped_column(String(200))
    voided_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    discount_type: Mapped[str | None] = mapped_column(String(10))        # percent | amount (item discount)
    discount_value: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    discount_amount: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    discount_cap: Mapped[int | None] = mapped_column(Integer)
    discount_reason: Mapped[str | None] = mapped_column(String(120))
    discount_preset_id: Mapped[int | None] = mapped_column(Integer)
    discount_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    discount_approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    discount_auto: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())
    returned_qty: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))  # refunded units put back in stock
    # Material cost of this line frozen when the bill was closed (item recipe + every chosen modifier recipe, at the
    # weighted-average cost of that moment). Reports read this column, so a later purchase can never rewrite the
    # profit of a past sale. NULL = a row written before this column existed (additive migration, nothing rewritten);
    # the reports then fall back to the historical sale movements of that order and mark the figure as estimated.
    cost_amount: Mapped[float | None] = mapped_column(Float)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)
    ready_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    order: Mapped[Order] = relationship(back_populates="lines")

    @property
    def total(self) -> int:
        return self.unit_price * self.qty


class Payment(Base, TimestampMixin):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    method: Mapped[str] = mapped_column(String(10))
    amount: Mapped[int] = mapped_column(Integer)                         # negative for refunds
    tendered: Mapped[int | None] = mapped_column(Integer)
    change: Mapped[int] = mapped_column(Integer, default=0)
    reference: Mapped[str | None] = mapped_column(String(60))
    is_refund: Mapped[bool] = mapped_column(Boolean, default=False)
    note: Mapped[str | None] = mapped_column(String(200))
    shift_id: Mapped[int | None] = mapped_column(Integer, index=True)    # set by the shifts module
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    # client-generated id of the submission ("<uuid>:<n>") — makes retried/double-submitted payments idempotent
    request_id: Mapped[str | None] = mapped_column(String(64), unique=True, index=True)
    order: Mapped[Order] = relationship(back_populates="payments")


class OrderRefundLine(Base, TimestampMixin):
    """One physical return of goods, booked on the day it really happened.

    A money refund and a physical return are two different events: a refund without a restock leaves the goods
    consumed (no COGS change), and this table only records what actually went back on the shelf. Each row keeps
    the sold line it belongs to, how many units came back, the historical cost per unit that was frozen when the
    bill closed, the moment of the event and who recorded it — so a return can never rewrite the profit of the
    day the sale happened (the owner's accounting policy).

    `source` separates real events ("event") from rows that only exist because an old database already had
    `order_lines.returned_qty > 0` without any details ("legacy") — those are never invented, just marked.
    """
    __tablename__ = "order_refund_lines"
    __table_args__ = (UniqueConstraint("refund_payment_id", "line_id", name="ux_order_refund_lines_pay_line"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    line_id: Mapped[int] = mapped_column(ForeignKey("order_lines.id", ondelete="CASCADE"), index=True)
    qty: Mapped[float] = mapped_column(Float, default=0)                 # units of this event (not cumulative)
    unit_cost: Mapped[float | None] = mapped_column(Float)               # frozen historical cost per unit (None = unknown)
    refund_payment_id: Mapped[int | None] = mapped_column(ForeignKey("payments.id"), index=True)  # money moved, if any
    request_id: Mapped[str | None] = mapped_column(String(48), index=True)   # client request id (idempotency)
    kind: Mapped[str] = mapped_column(String(8), default="money", server_default="money")  # money | stock
    source: Mapped[str] = mapped_column(String(8), default="event", server_default="event")  # event | legacy
    note: Mapped[str | None] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class DiscountPreset(Base, TimestampMixin):
    """A named discount the cashier can pick (e.g. «کارمندی ۲۰٪», «هپی‌آور», «مهمان مدیر»)."""
    __tablename__ = "discount_presets"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60))
    kind: Mapped[str] = mapped_column(String(10), default="percent")    # percent | amount | bogo | combo
    value: Mapped[int] = mapped_column(Integer, default=0)              # 0 = open; bogo: % off the free units; combo: bundle price
    scope: Mapped[str] = mapped_column(String(10), default="order")     # order | item | both
    max_amount: Mapped[int | None] = mapped_column(Integer)             # ceiling (toman) for percent discounts
    min_subtotal: Mapped[int] = mapped_column(Integer, default=0)
    order_types: Mapped[list[str]] = mapped_column(JSON, default=list)  # empty = all
    weekdays: Mapped[list[int]] = mapped_column(JSON, default=list)     # 0 = Saturday … 6 = Friday; empty = every day
    start_time: Mapped[str | None] = mapped_column(String(5))           # "16:00"
    end_time: Mapped[str | None] = mapped_column(String(5))             # "19:00" (may wrap past midnight)
    requires_manager: Mapped[bool] = mapped_column(Boolean, default=False)
    reason_required: Mapped[bool] = mapped_column(Boolean, default=False)
    color: Mapped[str | None] = mapped_column(String(9))
    sort: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # --- automatic / promo-code / rule-based discounts
    auto_apply: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())
    code: Mapped[str | None] = mapped_column(String(30), unique=True)    # promo code (stored upper-case)
    valid_from: Mapped[date | None] = mapped_column(Date)
    valid_to: Mapped[date | None] = mapped_column(Date)
    max_uses: Mapped[int | None] = mapped_column(Integer)                # total uses (non-cancelled orders)
    per_customer_limit: Mapped[int | None] = mapped_column(Integer)      # uses per customer phone
    target_category_ids: Mapped[list[int]] = mapped_column(JSON, default=list, server_default=text("'[]'"))
    target_item_ids: Mapped[list[int]] = mapped_column(JSON, default=list, server_default=text("'[]'"))
    buy_qty: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))       # bogo: buy N …
    get_qty: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))       # … get M at `value`% off
    combo_parts: Mapped[list[dict]] = mapped_column(JSON, default=list, server_default=text("'[]'"))  # [{category_ids, item_ids, qty}]


class ClientRequest(Base, TimestampMixin):
    """Idempotency for order writes from devices (retries, offline queue replay): request id → the order it produced.
    A replay with the same id returns the order instead of creating/adding again. Rows older than 14 days are pruned."""
    __tablename__ = "client_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    request_id: Mapped[str] = mapped_column(String(48), unique=True, index=True)
    kind: Mapped[str] = mapped_column(String(16))
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
