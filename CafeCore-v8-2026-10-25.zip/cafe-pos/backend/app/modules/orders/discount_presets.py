"""Discount preset rules: when a preset may be used and how often it has already been used.

Pure rules and validation models, split out of `discounts.py` (which had grown to ~560 lines mixing
ceilings, preset rules and HTTP endpoints). The endpoints stay in `discounts.py`; the automatic
discount engine and the online ordering service import the rules from here.
"""
from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.errors import AppError
from app.core.utils import now, normalize_phone

from . import engine
from .models import DiscountPreset, Order, OrderLine
from .schemas import MAX_AMOUNT

WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]
KIND_TITLES = {"percent": "درصدی", "amount": "مبلغی", "bogo": "یکی بخر، یکی ببر", "combo": "منوی ترکیبی"}

# ---------------------------------------------------------------- presets
def _weekday(dt) -> int:
    return (dt.weekday() + 2) % 7          # Python Monday=0 → Persian week (Saturday=0)


def preset_uses(db: Session, p: DiscountPreset, phone: str | None = None, exclude_order: int | None = None) -> int:
    """Non-cancelled orders that used the preset (bill or item), optionally for one customer."""
    q = db.query(func.count(func.distinct(Order.id))).outerjoin(OrderLine, OrderLine.order_id == Order.id).filter(
        Order.status != "cancelled", (Order.discount_preset_id == p.id) | (OrderLine.discount_preset_id == p.id))
    if phone:
        q = q.filter(Order.customer_phone == phone)
    if exclude_order:
        q = q.filter(Order.id != exclude_order)
    return int(q.scalar() or 0)


def preset_unavailable(p: DiscountPreset, o: Order | None = None, at=None, *, check_usage: bool = True,
                       db: Session | None = None) -> str | None:
    """Why the preset can't be used right now (None = usable)."""
    at = at or now()
    if not p.is_active:
        return "غیرفعال است"
    if p.valid_from and at.date() < p.valid_from:
        return "هنوز شروع نشده است"
    if p.valid_to and at.date() > p.valid_to:
        return "مهلت استفاده تمام شده است"
    if p.weekdays and _weekday(at) not in p.weekdays:
        return "فقط " + "، ".join(WEEKDAYS[d] for d in sorted(p.weekdays))
    if p.start_time and p.end_time:
        t = at.strftime("%H:%M")
        inside = p.start_time <= t < p.end_time if p.start_time <= p.end_time else (t >= p.start_time or t < p.end_time)
        if not inside:
            return f"فقط از {p.start_time} تا {p.end_time}"
    if o is not None:
        if p.order_types and o.type not in p.order_types:
            return "برای این نوع سفارش نیست"
        if p.min_subtotal and o.subtotal < p.min_subtotal:
            return f"حداقل مبلغ سفارش {p.min_subtotal:,} تومان"
        if check_usage and db is not None:
            if p.max_uses and preset_uses(db, p, exclude_order=o.id) >= p.max_uses:
                return "ظرفیت استفاده از این تخفیف تمام شده است"
            if p.per_customer_limit:
                phone = normalize_phone(o.customer_phone)
                if not phone:
                    return "برای این تخفیف، شماره موبایل مشتری را در سفارش وارد کنید"
                if preset_uses(db, p, phone=phone, exclude_order=o.id) >= p.per_customer_limit:
                    return "این مشتری قبلاً از این تخفیف استفاده کرده است"
    return None


class ComboPart(BaseModel):
    category_ids: list[int] = []
    item_ids: list[int] = []
    qty: int = Field(1, ge=1, le=20)


class PresetIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    kind: str = Field("percent", pattern="^(percent|amount|bogo|combo)$")
    value: int = Field(0, ge=0, le=MAX_AMOUNT)
    scope: str = Field("order", pattern="^(order|item|both)$")
    max_amount: int | None = Field(None, ge=0, le=MAX_AMOUNT)
    min_subtotal: int = Field(0, ge=0, le=MAX_AMOUNT)
    order_types: list[str] = []
    weekdays: list[int] = []
    start_time: str | None = Field(None, pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    end_time: str | None = Field(None, pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    requires_manager: bool = False
    reason_required: bool = False
    color: str | None = Field(None, max_length=9)
    sort: int = 0
    is_active: bool = True
    auto_apply: bool = False
    code: str | None = Field(None, max_length=30)
    valid_from: date | None = None
    valid_to: date | None = None
    max_uses: int | None = Field(None, ge=1, le=1_000_000)
    per_customer_limit: int | None = Field(None, ge=1, le=1000)
    target_category_ids: list[int] = []
    target_item_ids: list[int] = []
    buy_qty: int = Field(0, ge=0, le=50)
    get_qty: int = Field(0, ge=0, le=50)
    combo_parts: list[ComboPart] = []


def preset_out(p: DiscountPreset, o: Order | None = None, db: Session | None = None, *, uses: bool = False) -> dict:
    d = {k: getattr(p, k) for k in PresetIn.model_fields}
    d["id"] = p.id
    d["unavailable"] = preset_unavailable(p, o, db=db)
    if uses and db is not None:
        d["uses"] = preset_uses(db, p)
    return d


def _norm_code(code: str | None) -> str | None:
    code = (code or "").strip().upper().replace(" ", "")
    return code or None


def _check_preset(db: Session, data: PresetIn, pid: int | None = None) -> dict:
    """Validate and normalise; → column values."""
    v = data.model_dump()
    v["code"] = _norm_code(data.code)
    if data.kind == "percent" and data.value > 100:
        raise AppError("درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد")
    if bool(data.start_time) != bool(data.end_time):
        raise AppError("برای بازه زمانی، ساعت شروع و پایان را با هم وارد کنید")
    if any(d not in range(7) for d in data.weekdays) or any(t not in ("dine_in", "takeaway", "delivery") for t in data.order_types):
        raise AppError("روز هفته یا نوع سفارش نامعتبر است")
    if data.valid_from and data.valid_to and data.valid_from > data.valid_to:
        raise AppError("تاریخ شروع اعتبار بعد از تاریخ پایان است")
    if data.kind in engine.RULE_KINDS:
        v["scope"] = "order"                                 # computed from the whole order
        if data.kind == "bogo":
            if data.buy_qty < 1 or data.get_qty < 1:
                raise AppError("برای «یکی بخر، یکی ببر» تعداد خرید و تعداد هدیه را وارد کنید (مثلاً ۱ و ۱)")
            if data.value > 100:
                raise AppError("درصد تخفیف آیتم هدیه حداکثر ۱۰۰ است (۱۰۰ = رایگان)")
            v["value"] = data.value or 100
        else:
            if not data.combo_parts or any(not (p.category_ids or p.item_ids) for p in data.combo_parts):
                raise AppError("اجزای منوی ترکیبی را مشخص کنید (برای هر جزء یک دسته یا آیتم)")
            if not data.value:
                raise AppError("قیمت منوی ترکیبی را وارد کنید")
    if data.auto_apply:
        if v["code"]:
            raise AppError("تخفیف خودکار نمی‌تواند کد تخفیف داشته باشد")
        if data.kind in ("percent", "amount") and not data.value:
            raise AppError("تخفیف خودکار باید مقدار مشخص داشته باشد")
        if data.requires_manager or data.reason_required:
            raise AppError("تخفیف خودکار نمی‌تواند «نیاز به تأیید مدیر» یا «توضیح اجباری» داشته باشد")
        if data.kind in ("percent", "amount") and data.scope == "both":
            raise AppError("برای تخفیف خودکار مشخص کنید روی کل فاکتور اعمال شود یا روی آیتم")
    if v["code"]:
        clash = db.query(DiscountPreset.id).filter(DiscountPreset.code == v["code"], DiscountPreset.id != (pid or 0)).first()
        if clash:
            raise AppError(f"کد «{v['code']}» قبلاً برای تخفیف دیگری استفاده شده است")
    return v
