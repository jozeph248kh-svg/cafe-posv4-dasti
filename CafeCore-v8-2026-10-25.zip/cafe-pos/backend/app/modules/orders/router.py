from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session, selectinload

from app.core.db import get_db
from app.core.deps import Actor, require, require_or_override
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import now, phone_update
from app.modules.floor.models import Area

from . import service as svc
from .models import Order, OrderLine
from .schemas import (
    AddLines,
    LineUpdate,
    MergeIn,
    OrderCreate,
    OrderOut,
    OrderUpdate,
    PaymentsIn,
    Reason,
    RefundIn,
    SplitIn,
    TransferIn,
)

router = APIRouter()
pos = require("pos.access")


def load(db: Session, oid: int) -> Order:
    o = (db.query(Order).options(selectinload(Order.lines), selectinload(Order.payments))
         .filter(Order.id == oid).first())
    if not o:
        raise AppError("سفارش یافت نشد", 404, "not_found")
    return o


def done(db: Session, o: Order) -> OrderOut:
    db.commit()
    return svc.to_out(load(db, o.id))


# ---------------------------------------------------------------- floor & lists
@router.get("/floor")
def floor(db: Session = Depends(get_db), _: User = Depends(pos)):
    """Tables with live status for the POS floor plan."""
    open_orders = (db.query(Order).options(selectinload(Order.lines))
                   .filter(Order.status == "open", Order.table_id.isnot(None)).all())
    by_table = {o.table_id: o for o in open_orders}
    t = now()
    areas = []
    for a in db.query(Area).order_by(Area.sort, Area.id).all():
        tables = []
        for tb in a.tables:
            if not tb.is_active:
                continue
            o = by_table.get(tb.id)
            info = {"id": tb.id, "name": tb.name, "seats": tb.seats, "shape": tb.shape, "x": tb.x, "y": tb.y, "status": "free"}
            if o:
                active = o.active_lines
                last = max((l.created_at for l in o.lines), default=o.created_at)
                info.update({
                    "order_id": o.id, "order_number": o.number, "guests": o.guests, "total": o.total,
                    "waiter": o.waiter.full_name if o.waiter else None,
                    "minutes": int((t - o.created_at).total_seconds() // 60),
                    "idle_minutes": int((t - last).total_seconds() // 60),
                    "pending": sum(1 for l in active if l.status == "pending"),
                    "ready": sum(1 for l in active if l.status == "ready"),
                    "status": "billing" if o.bill_printed_at else ("ready" if any(l.status == "ready" for l in active) else "occupied"),
                })
            tables.append(info)
        areas.append({"id": a.id, "name": a.name, "tables": tables})
    return areas


@router.get("/active", response_model=list[OrderOut])
def active_orders(type: str | None = None, db: Session = Depends(get_db), _: User = Depends(pos)):
    # column queries instead of ORM objects — same payload, a fraction of the cost (see orders.service.orders_out)
    return svc.orders_out(db, "open", type)


@router.get("")
def history(
    date_from: date | None = None, date_to: date | None = None, status: str | None = None,
    type: str | None = None, q: str | None = None, page: int = Query(1, ge=1), size: int = Query(30, le=200),
    db: Session = Depends(get_db), _: User = Depends(pos),
):
    query = db.query(Order)
    if date_from:
        query = query.filter(Order.business_date >= date_from)
    if date_to:
        query = query.filter(Order.business_date <= date_to)
    if status:
        query = query.filter(Order.status == status)
    if type:
        query = query.filter(Order.type == type)
    if q:
        like = f"%{q}%"
        conds = [Order.customer_name.like(like), Order.customer_phone.like(like)]
        # only a *plausible order number* is compared with `Order.number`. A phone number is digits too, and on
        # PostgreSQL an 11-digit value overflows the 32-bit column and used to turn the whole search into a 422
        # ("number too large") — searching orders by phone was broken there while it looked fine on SQLite.
        if q.isdigit() and len(q) <= 9:
            conds.append(Order.number == int(q))
        query = query.filter(or_(*conds))
    total = query.count()
    rows = query.order_by(Order.created_at.desc()).offset((page - 1) * size).limit(size).all()
    return {"total": total, "items": [
        {"id": o.id, "number": o.number, "business_date": o.business_date, "type": o.type, "status": o.status,
         "table_name": o.table.name if o.table else None, "customer_name": o.customer_name, "guests": o.guests,
         "waiter_name": o.waiter.full_name if o.waiter else None, "total": o.total, "paid_amount": o.paid_amount,
         "created_at": o.created_at, "closed_at": o.closed_at}
        for o in rows]}


@router.get("/{oid}", response_model=OrderOut)
def get_order(oid: int, db: Session = Depends(get_db), _: User = Depends(pos)):
    return svc.to_out(load(db, oid))


# ---------------------------------------------------------------- mutations
@router.post("", response_model=OrderOut, status_code=201)
def create(data: OrderCreate, db: Session = Depends(get_db), user: User = Depends(pos)):
    prev = svc.client_request(db, data.request_id, "create")
    if prev:
        return done(db, load(db, prev))
    busy = svc.table_open_order(db, data.table_id) if data.merge_if_busy and data.type == "dine_in" and data.table_id else None
    if busy:
        o = load(db, busy.id)
        svc.add_lines(db, o, data.lines, user)
        db.flush()
        if data.send:
            svc.send_to_kitchen(db, o, user)
        svc.recalc(db, o)
        svc.notify(db, o)
    else:
        o = svc.create_order(db, data, user)
        db.flush()
    svc.remember_request(db, data.request_id, "create", o, user)
    return done(db, o)


@router.patch("/{oid}", response_model=OrderOut)
def update(oid: int, data: OrderUpdate, db: Session = Depends(get_db), user: User = Depends(pos)):
    o = load(db, oid)
    svc.ensure_open(o)
    changes = data.model_dump(exclude_unset=True)
    cid = changes.pop("customer_id", None)
    if cid:
        changes["customer_phone"] = svc.customer_phone_for(db, cid, changes.get("customer_phone"))
    for k, v in changes.items():
        setattr(o, k, phone_update(v, o.customer_phone) if k == "customer_phone" else v)
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/lines", response_model=OrderOut)
def add_lines(oid: int, data: AddLines, db: Session = Depends(get_db), user: User = Depends(pos)):
    prev = svc.client_request(db, data.request_id, "lines")
    if prev:
        if prev != oid:
            raise AppError("شناسه درخواست تکراری است", 409, "duplicate_request")
        return done(db, load(db, oid))
    o = load(db, oid)
    svc.add_lines(db, o, data.lines, user)
    svc.remember_request(db, data.request_id, "lines", o, user)
    db.flush()
    if data.send:
        svc.send_to_kitchen(db, o, user)
    svc.recalc(db, o)
    svc.notify(db, o)
    return done(db, o)


def _line(o: Order, line_id: int) -> OrderLine:
    line = next((l for l in o.lines if l.id == line_id), None)
    if not line:
        raise AppError("آیتم در این سفارش یافت نشد", 404, "not_found")
    return line


@router.patch("/{oid}/lines/{line_id}", response_model=OrderOut)
def update_line(oid: int, line_id: int, data: LineUpdate, db: Session = Depends(get_db), user: User = Depends(pos)):
    o = load(db, oid)
    svc.ensure_open(o)
    line = _line(o, line_id)
    if line.status != "pending":
        raise AppError("آیتم ارسال‌شده به آشپزخانه قابل ویرایش نیست؛ آن را حذف و دوباره ثبت کنید")
    if data.qty is not None:
        line.qty = data.qty
    if data.note is not None:
        line.note = data.note.strip() or None
    svc.recalc(db, o)
    svc.notify(db, o)
    return done(db, o)


@router.delete("/{oid}/lines/{line_id}", response_model=OrderOut)
def remove_pending_line(oid: int, line_id: int, db: Session = Depends(get_db), user: User = Depends(pos)):
    o = load(db, oid)
    svc.ensure_open(o)
    line = _line(o, line_id)
    if line.status != "pending":
        raise AppError("این آیتم به آشپزخانه ارسال شده؛ برای حذف، دلیل ثبت کنید", code="line_sent")
    o.lines.remove(line)
    svc.recalc(db, o)
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/lines/{line_id}/void", response_model=OrderOut)
def void_line(oid: int, line_id: int, data: Reason, db: Session = Depends(get_db),
              actor: Actor = Depends(require_or_override("orders.void"))):
    o = load(db, oid)
    svc.void_line(db, o, _line(o, line_id), data.reason, actor.user, actor.approver)
    svc.recalc(db, o)
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/send", response_model=OrderOut)
def send(oid: int, db: Session = Depends(get_db), user: User = Depends(pos)):
    o = load(db, oid)
    if not svc.send_to_kitchen(db, o, user):
        raise AppError("آیتم جدیدی برای ارسال وجود ندارد")
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/served", response_model=OrderOut)
def mark_served(oid: int, db: Session = Depends(get_db), user: User = Depends(pos)):
    o = load(db, oid)
    for l in o.lines:
        if l.status == "ready":
            l.status = "served"
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/bill", response_model=OrderOut)
def print_bill(oid: int, db: Session = Depends(get_db), user: User = Depends(pos)):
    """Mark the pre-bill as printed (table turns 'awaiting payment')."""
    o = load(db, oid)
    svc.ensure_open(o)
    o.bill_printed_at = now()
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/payments", response_model=OrderOut)
def pay(oid: int, data: PaymentsIn, db: Session = Depends(get_db), user: User = Depends(require("payments.take"))):
    o = load(db, oid)
    svc.add_payments(db, o, data.payments, user, data.request_id)
    return done(db, o)


@router.post("/{oid}/refund", response_model=OrderOut)
def refund(oid: int, data: RefundIn, db: Session = Depends(get_db),
           actor: Actor = Depends(require_or_override("payments.refund"))):
    o = load(db, oid)
    svc.refund(db, o, data, actor.user, actor.approver)
    return done(db, o)


@router.post("/{oid}/cancel", response_model=OrderOut)
def cancel(oid: int, data: Reason, db: Session = Depends(get_db),
           actor: Actor = Depends(require_or_override("orders.cancel"))):
    o = load(db, oid)
    svc.cancel_order(db, o, data.reason, actor.user, actor.approver)
    return done(db, o)


@router.post("/{oid}/transfer", response_model=OrderOut)
def transfer(oid: int, data: TransferIn, db: Session = Depends(get_db), user: User = Depends(require("orders.transfer"))):
    o = load(db, oid)
    svc.transfer(db, o, data.table_id, user)
    return done(db, o)


@router.post("/{oid}/merge", response_model=OrderOut)
def merge(oid: int, data: MergeIn, db: Session = Depends(get_db), user: User = Depends(require("orders.transfer"))):
    src, dst = load(db, oid), load(db, data.target_order_id)
    svc.merge(db, src, dst, user)
    return done(db, dst)


@router.post("/{oid}/split", response_model=OrderOut)
def split(oid: int, data: SplitIn, db: Session = Depends(get_db), user: User = Depends(require("orders.transfer"))):
    o = load(db, oid)
    new = svc.split(db, o, data.lines, user)
    return done(db, new)
