"""Order lines: adding items (with modifier validation), sending them to the kitchen and voiding them.

Split out of `service.py`, which had grown to 411 lines mixing pricing, lines and the order
lifecycle. `service.build_line` / `add_lines` / `send_to_kitchen` / `void_line` are re-exported so
the routers and other modules keep calling `service.<name>` as before.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.core import events
from app.core.audit import log_action
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import now
from app.modules.menu.models import MenuItem, ModifierOption

from .models import Order, OrderLine
from .schemas import LineIn


def ensure_open(o: Order) -> None:
    """Guard for every mutation: a closed or cancelled order must never change."""
    if o.status != "open":
        raise AppError("این سفارش بسته یا لغو شده است و قابل تغییر نیست", code="order_not_open")

# ---------------------------------------------------------------- lines
def build_line(db: Session, data: LineIn, user: User) -> OrderLine:
    item = db.get(MenuItem, data.menu_item_id)
    if not item or not item.is_active:
        raise AppError("آیتم انتخاب‌شده در منو وجود ندارد")
    if not item.is_available:
        raise AppError(f"«{item.name}» در حال حاضر موجود نیست", code="item_unavailable")

    opts = db.query(ModifierOption).filter(ModifierOption.id.in_(data.modifier_option_ids)).all() if data.modifier_option_ids else []
    allowed_groups = {g.id: g for g in item.modifier_groups}
    chosen: dict[int, list[ModifierOption]] = {}
    for o in opts:
        if o.group_id not in allowed_groups:
            raise AppError(f"گزینه «{o.name}» برای «{item.name}» مجاز نیست")
        if not o.is_available:
            raise AppError(f"گزینه «{o.name}» موجود نیست")
        chosen.setdefault(o.group_id, []).append(o)
    for g in allowed_groups.values():
        n = len(chosen.get(g.id, []))
        if n < g.min_select:
            raise AppError(f"برای «{item.name}» انتخاب «{g.name}» الزامی است", code="modifier_required")
        if n > g.max_select:
            raise AppError(f"حداکثر {g.max_select} گزینه از «{g.name}» قابل انتخاب است")

    mods = [{"id": o.id, "name": o.name, "price": o.price_delta, "group": allowed_groups[o.group_id].name} for o in opts]
    return OrderLine(
        menu_item_id=item.id, station_id=item.station_id, name=item.name, base_price=item.price,
        unit_price=item.price + sum(m["price"] for m in mods), qty=data.qty, modifiers=mods,
        note=(data.note or "").strip() or None, created_by=user.id,
    )


def add_lines(db: Session, o: Order, lines: list[LineIn], user: User) -> None:
    ensure_open(o)
    for ld in lines:
        new = build_line(db, ld, user)
        # merge with an identical pending line instead of duplicating it
        same = next((l for l in o.lines if l.status == "pending" and l.menu_item_id == new.menu_item_id
                     and l.modifiers == new.modifiers and l.note == new.note), None)
        if same:
            same.qty += new.qty
        else:
            o.lines.append(new)
    o.bill_printed_at = None


def send_to_kitchen(db: Session, o: Order, user: User) -> list[OrderLine]:
    ensure_open(o)
    pending = [l for l in o.lines if l.status == "pending"]
    if not pending:
        return []
    t = now()
    for l in pending:
        l.status, l.sent_at = "sent", t
    db.flush()
    events.emit("order.sent", db=db, order=o, lines=pending, user=user)
    return pending


def void_line(db: Session, o: Order, line: OrderLine, reason: str, user: User, approver: User) -> None:
    ensure_open(o)
    if line.status == "void":
        return
    line.status, line.void_reason, line.voided_by = "void", reason, approver.id
    log_action(db, user, "order.void", f"حذف «{line.name}» ×{line.qty} از سفارش #{o.number} — دلیل: {reason}",
               entity="order", entity_id=o.id, approver=approver, details={"line_id": line.id, "amount": line.total})
    events.emit("order.line_voided", db=db, order=o, line=line)
