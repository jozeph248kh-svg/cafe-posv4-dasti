"""Discount ceilings: how much discount a user may give on their own, and who may approve more.

Split out of `discounts.py`, which had grown to ~560 lines mixing three concerns (ceilings,
preset rules and the HTTP endpoints). Nothing here talks to FastAPI except `Approval`, which is
a dependency object.
"""
from __future__ import annotations

from datetime import date, timedelta

from fastapi import Depends, Header, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import ratelimit, settings_store
from app.core.db import get_db
from app.core.deps import current_user
from app.core.errors import AppError
from app.core.models import User
from app.core.security import hash_pin
from app.core.utils import business_day, now, normalize_phone, to_jalali

from .models import DiscountPreset, Order, OrderLine

# ---------------------------------------------------------------- ceilings
def ceiling(u: User) -> tuple[int | None, int | None]:
    """(max percent, max toman) per order the user may give on their own; None = unlimited, 0 = nothing."""
    if "*" in (u.role.permissions or []):
        return None, None
    if not u.can("orders.discount"):
        return 0, 0
    pct = u.max_discount_pct if u.max_discount_pct is not None else u.role.max_discount_pct
    amount = u.max_discount_amount if u.max_discount_amount is not None else u.role.max_discount_amount
    return pct, amount


def period_ceiling(u: User) -> tuple[int | None, int | None]:
    """(toman per business day, toman per Jalali month); None = unlimited."""
    if "*" in (u.role.permissions or []):
        return None, None
    daily = u.max_discount_daily if u.max_discount_daily is not None else u.role.max_discount_daily
    monthly = u.max_discount_monthly if u.max_discount_monthly is not None else u.role.max_discount_monthly
    return daily, monthly


def _fits(u: User, pct: float, amount: int) -> bool:
    cp, ca = ceiling(u)
    return (cp is None or pct <= cp + 0.0001) and (ca is None or amount <= ca)


def _ceiling_text(u: User) -> str:
    cp, ca = ceiling(u)
    if cp == 0 or ca == 0:
        return "شما مجوز تخفیف ندارید"
    parts = [f"{cp}٪" if cp is not None else None, f"{ca:,} تومان" if ca is not None else None]
    return "سقف تخفیف شما " + " و ".join(p for p in parts if p)


def month_start(d: date) -> date:
    """First Gregorian date of the Jalali month that contains `d`."""
    while to_jalali(d)[2] != 1:
        d -= timedelta(days=1)
    return d


def given_by(db: Session, user_id: int, since: date, until: date, exclude_order: int | None = None) -> int:
    """Manual discounts the user approved THEMSELVES on non-cancelled orders between two business dates."""
    base = [Order.status != "cancelled", Order.business_date >= since, Order.business_date <= until]
    if exclude_order:
        base.append(Order.id != exclude_order)
    bill = db.query(func.coalesce(func.sum(Order.discount_amount - Order.line_discount_amount), 0)).filter(
        *base, Order.discount_by == user_id, Order.discount_approved_by.is_(None), Order.discount_auto.is_(False),
        Order.discount_code.is_(None)).scalar()
    lines = db.query(func.coalesce(func.sum(OrderLine.discount_amount), 0)).join(Order, OrderLine.order_id == Order.id).filter(
        *base, OrderLine.discount_by == user_id, OrderLine.discount_approved_by.is_(None), OrderLine.discount_auto.is_(False),
        OrderLine.status != "void").scalar()
    return int(bill or 0) + int(lines or 0)


def usage_today(db: Session, u: User, exclude_order: int | None = None) -> tuple[int, int]:
    cutoff = int(settings_store.get(db, "day.cutoff_hour") or 5)
    today = business_day(now(), cutoff)
    return given_by(db, u.id, today, today, exclude_order), given_by(db, u.id, month_start(today), today, exclude_order)


class Approval:
    """Resolves who authorises a discount: the user, or a manager identified by `X-Manager-Pin`."""

    def __init__(self, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db),
                 x_manager_pin: str | None = Header(default=None)):
        self.request, self.user, self.db, self.pin = request, user, db, x_manager_pin
        self.approver: User | None = None

    def _manager(self, ok) -> User:
        keys = (f"override:{self.user.id}", f"pin-ip:{ratelimit.client_ip(self.request)}")
        ratelimit.check(*keys)
        u = self.db.query(User).filter(User.pin_hash == hash_pin(self.pin)).first()
        if u and u.is_active and ok(u):
            ratelimit.success(*keys)
            return u
        ratelimit.fail(*keys)
        raise AppError("رمز مدیر نامعتبر است یا سقف/مجوز تخفیف کافی ندارد", status.HTTP_403_FORBIDDEN, "override_invalid",
                       permission="orders.discount")

    def precheck(self) -> None:
        """Before touching the order: without the permission (and no PIN) answer 403 right away."""
        if not self.user.can("orders.discount") and not self.pin:
            raise AppError("اعمال تخفیف نیاز به تأیید مدیر دارد", status.HTTP_403_FORBIDDEN, "override_required",
                           permission="orders.discount")

    def authorise(self, pct: float, amount: int, *, increased: bool, needs_manager: bool, what: str,
                  order: Order | None = None) -> None:
        """Raise `override_required` unless the user (or the PIN's owner) may give this discount.
        `amount` = the order's manual discount after the change."""
        period_msg: list[str] = []

        def period_ok(u: User) -> bool:
            daily, monthly = period_ceiling(u)
            if order is None or (daily is None and monthly is None):
                return True
            day_used, month_used = usage_today(self.db, u, exclude_order=order.id)
            if daily is not None and day_used + amount > daily:
                period_msg.append(f"سقف تخفیف روزانه شما {daily:,} تومان است و امروز {day_used:,} تومان تخفیف داده‌اید")
                return False
            if monthly is not None and month_used + amount > monthly:
                period_msg.append(f"سقف تخفیف ماهانه شما {monthly:,} تومان است و این ماه {month_used:,} تومان تخفیف داده‌اید")
                return False
            return True

        def ok(u: User, own: bool = False) -> bool:
            if needs_manager and not u.can("discounts.manage"):
                return False
            if not increased:
                return u.can("orders.discount")
            return _fits(u, pct, amount) and (not own or period_ok(u))
        if ok(self.user, own=True):
            return
        if self.pin:
            self.approver = self._manager(ok)
            return
        if needs_manager and not self.user.can("discounts.manage"):
            msg = f"«{what}» فقط با تأیید مدیر قابل اعمال است"
        elif not self.user.can("orders.discount"):
            msg = "اعمال تخفیف نیاز به تأیید مدیر دارد"
        elif period_msg:
            msg = period_msg[0] + "؛ تأیید مدیر لازم است"
        else:
            msg = f"تخفیف {pct:.0f}٪ ({amount:,} تومان) از {_ceiling_text(self.user)} بیشتر است؛ تأیید مدیر لازم است"
        raise AppError(msg, status.HTTP_403_FORBIDDEN, "override_required", permission="orders.discount")
