"""Discounts — bill and item discounts, presets (manual / automatic / promo code / buy-X-get-Y / combo) and
per-role/per-user discount ceilings.

How approval works (the same pattern as Toast/Lightspeed "requires manager"):
* `orders.discount` lets a user give discounts up to their ceiling: `max_discount_pct` / `max_discount_amount` per
  order, and optionally `max_discount_daily` (per business day) / `max_discount_monthly` (per Jalali month) — of the
  user, else of their role (NULL = no ceiling). The super-admin role has no ceiling.
* The ceiling is checked against the MANUAL discounts (automatic presets and promo codes are given by the business,
  not by the cashier): the discount being given and the order's total manual discount after the change, so several
  small discounts can't be stacked past the limit. Daily/monthly ceilings count only discounts the user approved
  themselves (not ones a manager approved with a PIN).
* Above the ceiling (or without the permission) the API answers `override_required`; the POS asks for a manager PIN
  and retries with `X-Manager-Pin`. The approver must have `orders.discount` and a high-enough ceiling.
* Presets flagged `requires_manager` always need someone with `discounts.manage`.
* A promo code (`code`) needs no approval unless its preset `requires_manager`.
Removing or lowering a discount never needs approval (only `orders.discount`, or a PIN).
"""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import Role, User
from app.core.utils import now

from . import engine
from . import service as svc
from .discount_limits import Approval, _ceiling_text, ceiling, month_start, period_ceiling  # noqa: F401  (public API)
from .discount_limits import given_by, usage_today                                          # noqa: F401
from .discount_presets import KIND_TITLES, WEEKDAYS, ComboPart, PresetIn, _check_preset      # noqa: F401
from .discount_presets import _norm_code, preset_out, preset_unavailable, preset_uses         # noqa: F401
from .models import DiscountPreset, Order, OrderLine
from .schemas import MAX_AMOUNT, OrderOut

router = APIRouter()
manage = require("discounts.manage")

# Kept importable from here: `engine`, `online.service` and older callers use `discounts.<name>`.
__all__ = ["router", "Approval", "WEEKDAYS", "KIND_TITLES", "find_code", "preset_out", "preset_unavailable",
           "preset_uses", "ceiling", "given_by", "usage_today", "month_start"]

# ---------------------------------------------------------------- presets
@router.get("/discounts/presets")
def list_presets(order_id: int | None = None, all: bool = False, db: Session = Depends(get_db),
                 user: User = Depends(require("pos.access"))):
    o = db.get(Order, order_id) if order_id else None
    q = db.query(DiscountPreset)
    manage_view = all and user.can("discounts.manage")
    if not manage_view:
        # the register shows presets the cashier can pick: automatic ones apply by themselves, codes must be typed
        q = q.filter(DiscountPreset.is_active.is_(True), DiscountPreset.auto_apply.is_(False), DiscountPreset.code.is_(None))
    return [preset_out(p, o, db, uses=manage_view) for p in q.order_by(DiscountPreset.sort, DiscountPreset.id).all()]


@router.post("/discounts/presets", status_code=201)
def create_preset(data: PresetIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    p = DiscountPreset(**_check_preset(db, data))
    db.add(p)
    db.flush()
    log_action(db, user, "discount.preset", f"تعریف تخفیف «{p.name}»", entity="discount_preset", entity_id=p.id)
    db.commit()
    return preset_out(p)


@router.put("/discounts/presets/{pid}")
def update_preset(pid: int, data: PresetIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    p = get_or_404(db, DiscountPreset, pid, "تخفیف")
    for k, v in _check_preset(db, data, pid).items():
        setattr(p, k, v)
    log_action(db, user, "discount.preset", f"ویرایش تخفیف «{p.name}»", entity="discount_preset", entity_id=p.id)
    db.commit()
    return preset_out(p)


@router.delete("/discounts/presets/{pid}", status_code=204)
def delete_preset(pid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    p = get_or_404(db, DiscountPreset, pid, "تخفیف")
    log_action(db, user, "discount.preset", f"حذف تخفیف «{p.name}»", entity="discount_preset", entity_id=p.id)
    db.delete(p)                            # orders keep their own copy of type/value/reason/rule
    db.commit()


# ---------------------------------------------------------------- ceilings management
@router.get("/discounts/my-limit")
def my_limit(user: User = Depends(current_user), db: Session = Depends(get_db)):
    pct, amount = ceiling(user)
    daily, monthly = period_ceiling(user)
    used_day, used_month = usage_today(db, user) if (daily is not None or monthly is not None) else (None, None)
    return {"can_discount": user.can("orders.discount"), "max_pct": pct, "max_amount": amount,
            "can_manage": user.can("discounts.manage"), "reason_required": bool(settings_store.get(db, "discount.reason_required")),
            "max_daily": daily, "max_monthly": monthly, "used_today": used_day, "used_month": used_month}


class LimitIn(BaseModel):
    kind: str = Field(pattern="^(role|user)$")
    id: int
    max_discount_pct: int | None = Field(None, ge=0, le=100)
    max_discount_amount: int | None = Field(None, ge=0, le=MAX_AMOUNT)
    max_discount_daily: int | None = Field(None, ge=0, le=MAX_AMOUNT)
    max_discount_monthly: int | None = Field(None, ge=0, le=MAX_AMOUNT)


LIMIT_FIELDS = ("max_discount_pct", "max_discount_amount", "max_discount_daily", "max_discount_monthly")


@router.get("/discounts/limits")
def list_limits(db: Session = Depends(get_db), _: User = Depends(manage)):
    roles = db.query(Role).order_by(Role.id).all()
    users = db.query(User).filter(User.is_active.is_(True)).order_by(User.id).all()
    return {
        "roles": [{"id": r.id, "title": r.title, "unlimited": "*" in r.permissions, "can_discount": r.allows("orders.discount"),
                   **{f: getattr(r, f) for f in LIMIT_FIELDS}} for r in roles],
        "users": [{"id": u.id, "full_name": u.full_name, "role_id": u.role_id, "role_title": u.role.title,
                   **{f: getattr(u, f) for f in LIMIT_FIELDS},
                   "effective_pct": ceiling(u)[0], "effective_amount": ceiling(u)[1],
                   "effective_daily": period_ceiling(u)[0], "effective_monthly": period_ceiling(u)[1],
                   "can_discount": u.can("orders.discount")}
                  for u in users],
    }


@router.put("/discounts/limits")
def set_limit(data: LimitIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    target = get_or_404(db, Role if data.kind == "role" else User, data.id, "نقش" if data.kind == "role" else "کاربر")
    role = target if data.kind == "role" else target.role
    if "*" in role.permissions:
        raise AppError("سقف تخفیف برای نقش مدیر کل قابل تعیین نیست")
    if data.kind == "user" and target.id == user.id and "*" not in user.role.permissions:
        raise AppError("نمی‌توانید سقف تخفیف خودتان را تغییر دهید", status.HTTP_403_FORBIDDEN, "forbidden")
    # nobody can hand out a ceiling higher than their own
    mine = dict(zip(LIMIT_FIELDS, (*ceiling(user), *period_ceiling(user))))
    for f in LIMIT_FIELDS:
        new = getattr(data, f)
        if mine[f] is not None and (new is None or new > mine[f]):
            raise AppError(f"نمی‌توانید سقفی بالاتر از سقف خودتان تعیین کنید ({_ceiling_text(user).replace('سقف تخفیف شما ', '')})",
                           status.HTTP_403_FORBIDDEN, "forbidden")
    before = tuple(getattr(target, f) for f in LIMIT_FIELDS)
    for f in LIMIT_FIELDS:
        setattr(target, f, getattr(data, f))
    name = target.title if data.kind == "role" else target.full_name

    def fmt(p, a, d, m):
        parts = [f"{p}٪" if p is not None else "", f"{a:,} تومان" if a is not None else "",
                 f"روزانه {d:,}" if d is not None else "", f"ماهانه {m:,}" if m is not None else ""]
        return " / ".join(x for x in parts if x) or "بدون سقف"
    log_action(db, user, "discount.limit", f"سقف تخفیف «{name}»: {fmt(*before)} ← {fmt(*(getattr(data, f) for f in LIMIT_FIELDS))}",
               entity=data.kind, entity_id=target.id)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- applying discounts
class DiscountIn(BaseModel):
    type: str | None = Field(None, pattern="^(percent|amount)$")     # None (and no preset/code) = remove the discount
    value: int = Field(0, ge=0, le=MAX_AMOUNT)
    reason: str | None = Field(None, max_length=120)
    preset_id: int | None = None
    code: str | None = Field(None, max_length=30)                     # promo code


def find_code(db: Session, code: str | None) -> DiscountPreset:
    c = _norm_code(code)
    p = db.query(DiscountPreset).filter(DiscountPreset.code == c).first() if c else None
    if not p or not p.is_active:
        raise AppError("کد تخفیف نامعتبر است", code="invalid_code")
    return p


def _resolve(db: Session, data: DiscountIn, o: Order, scope: str):
    """→ (type, value, cap, reason, preset, rule) after applying the preset rules."""
    preset, rule = None, None
    typ, value, cap, reason = data.type, data.value, None, (data.reason or "").strip() or None
    if data.code or data.preset_id:
        preset = find_code(db, data.code) if data.code else db.get(DiscountPreset, data.preset_id)
        if not preset:
            raise AppError("تخفیف انتخاب‌شده یافت نشد")
        if preset.code and not data.code:
            raise AppError("این تخفیف فقط با وارد کردن کد آن قابل استفاده است")
        why = preset_unavailable(preset, o, db=db)
        if why:
            raise AppError(f"تخفیف «{preset.name}» الان قابل استفاده نیست: {why}", code="discount_unavailable")
        if preset.scope not in (scope, "both"):
            raise AppError(f"تخفیف «{preset.name}» برای {'کل فاکتور' if scope == 'order' else 'تک آیتم'} است")
        typ, cap = preset.kind, preset.max_amount
        value = preset.value or data.value        # open preset: value entered at the register
        rule = engine.rule_of(preset)
        if not value:
            raise AppError("مقدار تخفیف را وارد کنید")
        if preset.reason_required and not reason:
            raise AppError("برای این تخفیف، توضیح (مثلاً نام مهمان یا شماره کارت) لازم است")
        reason = preset.name + (f" — {reason}" if reason else "")
    elif typ and not reason and settings_store.get(db, "discount.reason_required"):
        raise AppError("دلیل تخفیف را بنویسید (در تنظیمات ← صندوق و عملیات می‌توانید اجباری بودن آن را خاموش کنید)",
                       code="reason_required")
    if typ == "percent" and value > 100:
        raise AppError("درصد تخفیف نمی‌تواند بیشتر از ۱۰۰ باشد")
    if typ and not value:
        raise AppError("مقدار تخفیف را وارد کنید")
    return typ, (value if typ else 0), cap, reason, preset, rule


def _pct(amount: int, base: int) -> float:
    return amount * 100 / base if base > 0 else (100.0 if amount else 0.0)


def _label(typ, value, amount) -> str:
    if not typ:
        return "حذف تخفیف"
    if typ in engine.RULE_KINDS:
        return f"{KIND_TITLES[typ]} ({amount:,})"
    return (f"{value}٪" if typ == "percent" else f"{value:,} تومان") + f" ({amount:,})"


def _manual(o: Order) -> int:
    return o.discount_amount - engine.auto_amount(o)


def _authorise(approval: Approval, o: Order, preset, pct: float, manual_before: int, data: DiscountIn) -> None:
    manual_after = _manual(o)
    needs_manager = bool(preset and preset.requires_manager)
    what = preset.name if preset else "تخفیف"
    if data.code:                                   # promo codes are pre-approved by the business
        if needs_manager:
            approval.authorise(pct, manual_after, increased=False, needs_manager=True, what=what)
        return
    approval.authorise(pct, manual_after, increased=manual_after > manual_before, needs_manager=needs_manager,
                       what=what, order=o)


def _precheck(approval: Approval, data: DiscountIn) -> None:
    if data.code:                                   # anyone at the register may redeem a promo code
        if not approval.user.can("pos.access"):
            raise AppError("دسترسی ندارید", status.HTTP_403_FORBIDDEN, "forbidden")
        return
    approval.precheck()


@router.post("/{oid}/discount", response_model=OrderOut)
def discount_order(oid: int, data: DiscountIn, approval: Approval = Depends()):
    from .router import done, load
    db, user = approval.db, approval.user
    _precheck(approval, data)
    o = load(db, oid)
    svc.ensure_open(o)
    svc.recalc(db, o)
    manual_before = _manual(o)
    typ, value, cap, reason, preset, rule = _resolve(db, data, o, "order")
    o.discount_type, o.discount_value, o.discount_cap, o.discount_reason = typ, value, cap, reason
    o.discount_preset_id, o.discount_rule, o.discount_auto = (preset.id if preset else None), rule, False
    o.discount_code = preset.code if (preset and data.code) else None
    svc.recalc(db, o)
    own = o.discount_amount - o.line_discount_amount
    if typ in engine.RULE_KINDS and own <= 0:
        raise AppError(f"شرایط «{preset.name}» در این سفارش برقرار نیست", code="discount_not_applicable")
    pct = max(_pct(own, o.subtotal - o.line_discount_amount), _pct(_manual(o), o.subtotal))
    _authorise(approval, o, preset, pct, manual_before, data)
    o.discount_by = user.id if typ else None
    o.discount_approved_by = approval.approver.id if (typ and approval.approver) else None
    log_action(db, user, "order.discount", f"تخفیف فاکتور #{o.number}: {_label(typ, value, own)}"
               + (f" — {reason}" if reason else "") + (f" (کد {preset.code})" if data.code and preset else ""),
               entity="order", entity_id=o.id, approver=approval.approver,
               details={"scope": "order", "amount": own, "preset_id": o.discount_preset_id, "code": bool(data.code)})
    svc.notify(db, o)
    return done(db, o)


@router.post("/{oid}/lines/{lid}/discount", response_model=OrderOut)
def discount_line(oid: int, lid: int, data: DiscountIn, approval: Approval = Depends()):
    from .router import done, load
    db, user = approval.db, approval.user
    _precheck(approval, data)
    o = load(db, oid)
    svc.ensure_open(o)
    line = next((x for x in o.lines if x.id == lid), None)
    if not line or line.status == "void":
        raise AppError("آیتم انتخاب‌شده در این سفارش نیست")
    svc.recalc(db, o)
    manual_before = _manual(o)
    typ, value, cap, reason, preset, _rule = _resolve(db, data, o, "item")
    line.discount_type, line.discount_value, line.discount_cap, line.discount_reason = typ, value, cap, reason
    line.discount_preset_id, line.discount_auto = (preset.id if preset else None), False
    svc.recalc(db, o)
    pct = max(_pct(line.discount_amount if not line.discount_auto else 0, line.total), _pct(_manual(o), o.subtotal))
    _authorise(approval, o, preset, pct, manual_before, data)
    line.discount_by = user.id if (typ and not line.discount_auto) else None
    line.discount_approved_by = approval.approver.id if (typ and approval.approver) else None
    log_action(db, user, "order.discount", f"تخفیف آیتم «{line.name}» در سفارش #{o.number}: {_label(typ, value, line.discount_amount)}"
               + (f" — {reason}" if reason else ""), entity="order", entity_id=o.id, approver=approval.approver,
               details={"scope": "item", "line_id": line.id, "amount": line.discount_amount, "preset_id": line.discount_preset_id})
    svc.notify(db, o)
    return done(db, o)
