from datetime import datetime

from pydantic import BaseModel, Field


MAX_AMOUNT = 10**12          # toman; guards against overflow/garbage input


class LineIn(BaseModel):
    menu_item_id: int
    qty: int = Field(1, ge=1, le=999)
    modifier_option_ids: list[int] = []
    note: str | None = Field(None, max_length=200)


class OrderCreate(BaseModel):
    type: str = Field("dine_in", pattern="^(dine_in|takeaway|delivery)$")
    table_id: int | None = None
    guests: int = Field(1, ge=1, le=100)
    customer_name: str | None = None
    customer_phone: str | None = None
    customer_address: str | None = None
    customer_id: int | None = None      # picked from the customer search: the server fills the (maybe masked) phone
    note: str | None = None
    waiter_id: int | None = None
    lines: list[LineIn] = []
    send: bool = False
    request_id: str | None = Field(None, min_length=8, max_length=48, pattern=r"^[A-Za-z0-9_-]+$")   # idempotency (retries / offline queue)
    merge_if_busy: bool = False   # offline replay: the table got an order meanwhile → add the lines to it


class OrderUpdate(BaseModel):
    guests: int | None = Field(None, ge=1, le=100)
    customer_name: str | None = None
    customer_phone: str | None = None
    customer_address: str | None = None
    customer_id: int | None = None
    note: str | None = None
    waiter_id: int | None = None


class AddLines(BaseModel):
    lines: list[LineIn] = Field(min_length=1)
    send: bool = False
    request_id: str | None = Field(None, min_length=8, max_length=48, pattern=r"^[A-Za-z0-9_-]+$")   # idempotency (retries / offline queue)


class LineUpdate(BaseModel):
    qty: int | None = Field(None, ge=1, le=999)
    note: str | None = None


class Reason(BaseModel):
    reason: str = Field(min_length=2, max_length=200)


class DiscountIn(BaseModel):
    type: str | None = Field(None, pattern="^(percent|amount)$")     # None = remove discount
    value: int = Field(0, ge=0, le=MAX_AMOUNT)
    reason: str | None = None


class PaymentIn(BaseModel):
    method: str = Field(pattern="^(cash|card|online|credit|wallet)$")
    amount: int = Field(gt=0, le=MAX_AMOUNT)
    tendered: int | None = Field(None, ge=0, le=MAX_AMOUNT)
    reference: str | None = None


class PaymentsIn(BaseModel):
    # an empty list is the "settle" call: only meaningful for a bill whose total is 0 (100 % discount / comp),
    # where there is nothing to pay and the bill just has to be closed (the service rejects it otherwise)
    payments: list[PaymentIn] = Field(default_factory=list, max_length=10)
    request_id: str | None = Field(None, min_length=8, max_length=48, pattern=r"^[A-Za-z0-9_-]+$")


class RestockIn(BaseModel):
    line_id: int
    qty: int = Field(ge=1, le=1000)


class RefundIn(BaseModel):
    method: str = Field(pattern="^(cash|card|online|credit|wallet)$")
    # 0 is allowed: goods back with no money moving (no payment row is written in that case).
    # An empty request (no money AND no returned items) is refused by the service.
    amount: int = Field(ge=0, le=MAX_AMOUNT)
    reason: str = Field(min_length=2, max_length=200)
    request_id: str | None = Field(None, min_length=8, max_length=48, pattern=r"^[A-Za-z0-9_-]+$")
    # returned items: their recipe ingredients go back into stock (unopened drinks, untouched packaged food …)
    restock: list[RestockIn] = Field(default_factory=list, max_length=200)


class TransferIn(BaseModel):
    table_id: int


class MergeIn(BaseModel):
    target_order_id: int


class SplitLine(BaseModel):
    line_id: int
    qty: int = Field(ge=1)


class SplitIn(BaseModel):
    lines: list[SplitLine] = Field(min_length=1)


class LineOut(BaseModel):
    id: int
    menu_item_id: int
    station_id: int | None
    name: str
    base_price: int
    unit_price: int
    qty: int
    total: int
    modifiers: list[dict]
    note: str | None
    status: str
    void_reason: str | None
    discount_type: str | None = None
    discount_value: int = 0
    discount_amount: int = 0
    discount_reason: str | None = None
    discount_auto: bool = False
    returned_qty: int = 0
    sent_at: datetime | None
    ready_at: datetime | None
    created_at: datetime


class PaymentOut(BaseModel):
    id: int
    method: str
    amount: int
    tendered: int | None
    change: int
    reference: str | None
    is_refund: bool
    note: str | None
    created_at: datetime


class OrderOut(BaseModel):
    id: int
    number: int
    business_date: str
    type: str
    status: str
    source: str
    table_id: int | None
    table_name: str | None
    guests: int
    customer_name: str | None
    customer_phone: str | None
    customer_address: str | None
    note: str | None
    waiter_id: int | None
    waiter_name: str | None
    discount_type: str | None
    discount_value: int
    discount_reason: str | None
    subtotal: int
    discount_amount: int                 # total: item discounts + bill discount
    line_discount_amount: int = 0
    discount_preset_id: int | None = None
    discount_auto: bool = False
    discount_code: str | None = None
    service_amount: int
    tax_amount: int
    rounding: int
    total: int
    paid_amount: int
    remaining: int
    bill_printed_at: datetime | None
    created_at: datetime
    closed_at: datetime | None
    cancelled_at: datetime | None
    cancel_reason: str | None
    lines: list[LineOut] = []
    payments: list[PaymentOut] = []
