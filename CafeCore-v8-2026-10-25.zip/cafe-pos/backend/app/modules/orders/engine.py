"""Rule-based and automatic discounts.

* **Automatic presets** (`auto_apply`) are applied by the system during `recalc()` of an OPEN order:
  - item presets (percent/amount) → every matching line that has no manual item discount. The time window is checked
    at the moment the line was added, so a happy-hour drink keeps its price after the happy hour ends;
  - bill presets (percent/amount/bogo/combo) → the best one, when the order has no manual bill discount. The window
    is checked at the moment the order was opened.
  A manual discount always wins over an automatic one; removing the manual discount brings the automatic one back.
* **Buy X get Y (bogo)** — among the matching units (most expensive first) every group of `buy_qty + get_qty` gives
  its `get_qty` cheapest units `value`% off (100 = free).
* **Combo** — each complete set of `combo_parts` (e.g. 1 burger + 1 fries + 1 drink) costs `value` toman; the
  discount is (sum of the set's prices − combo price). Sets are built from the most expensive matching units.
  Units that already carry an item discount are never used by bogo/combo (no double discounts).
Automatic discounts are given by the system: they don't count against the cashier's ceiling.
"""
from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.utils import now
from app.modules.menu.models import MenuItem

from .models import DiscountPreset, Order, OrderLine

RULE_KINDS = ("bogo", "combo")


def rule_of(p: DiscountPreset) -> dict | None:
    """Snapshot of the parameters a bogo/combo needs (kept on the order, so editing/deleting the preset is safe)."""
    if p.kind == "bogo":
        return {"kind": "bogo", "buy": p.buy_qty, "get": p.get_qty, "pct": p.value or 100,
                "category_ids": list(p.target_category_ids or []), "item_ids": list(p.target_item_ids or [])}
    if p.kind == "combo":
        return {"kind": "combo", "price": p.value, "parts": [dict(x) for x in (p.combo_parts or [])]}
    return None


def _categories(db: Session, lines) -> dict[int, int]:
    ids = {l.menu_item_id for l in lines}
    if not ids:
        return {}
    return dict(db.query(MenuItem.id, MenuItem.category_id).filter(MenuItem.id.in_(ids)).all())


def _matches(line: OrderLine, cats: dict[int, int], category_ids, item_ids) -> bool:
    if not category_ids and not item_ids:
        return True
    return line.menu_item_id in (item_ids or []) or cats.get(line.menu_item_id) in (category_ids or [])


def _units(o: Order, cats, category_ids=None, item_ids=None) -> list[int]:
    """Unit prices (most expensive first) of matching lines that carry no item discount."""
    out = []
    for l in o.active_lines:
        if l.discount_type or not _matches(l, cats, category_ids, item_ids):
            continue
        out += [l.unit_price] * l.qty
    return sorted(out, reverse=True)


def rule_amount(db: Session, o: Order, rule: dict | None, cats: dict[int, int] | None = None) -> int:
    if not rule:
        return 0
    cats = cats if cats is not None else _categories(db, o.active_lines)
    if rule["kind"] == "bogo":
        buy, get, pct = int(rule.get("buy") or 0), int(rule.get("get") or 0), min(int(rule.get("pct") or 100), 100)
        if buy < 1 or get < 1:
            return 0
        units = _units(o, cats, rule.get("category_ids"), rule.get("item_ids"))
        n = buy + get
        total = 0
        for i in range(0, len(units) - n + 1, n):
            group = units[i:i + n]
            total += sum(round(u * pct / 100) for u in group[-get:])
        return total
    if rule["kind"] == "combo":
        parts, price = rule.get("parts") or [], int(rule.get("price") or 0)
        if not parts:
            return 0
        # pool of units per line, most expensive first; a unit can fill only one part
        pool = []
        for l in o.active_lines:
            if not l.discount_type:
                pool += [(l.unit_price, l)] * l.qty
        pool.sort(key=lambda x: -x[0])
        total = 0
        while True:
            used, set_sum = [], 0
            for part in parts:
                need = max(int(part.get("qty") or 1), 1)
                for idx, (price_u, l) in enumerate(pool):
                    if need == 0:
                        break
                    if idx in used or not _matches(l, cats, part.get("category_ids"), part.get("item_ids")):
                        continue
                    used.append(idx)
                    set_sum += price_u
                    need -= 1
                if need:
                    return total                    # no more complete sets
            total += max(set_sum - price, 0)
            pool = [u for i, u in enumerate(pool) if i not in used]
    return 0


def _usable(p: DiscountPreset, o: Order, at) -> bool:
    from .discount_presets import preset_unavailable
    return preset_unavailable(p, o, at=at, check_usage=False) is None


def apply_auto(db: Session, o: Order) -> None:
    """Set/refresh the automatic discounts of an open order (called by recalc)."""
    if o.status != "open":
        return
    presets = db.query(DiscountPreset).filter(DiscountPreset.is_active.is_(True), DiscountPreset.auto_apply.is_(True),
                                              DiscountPreset.code.is_(None)).order_by(DiscountPreset.id).all()
    has_auto_state = any(l.discount_auto for l in o.lines) or o.discount_auto
    if not presets and not has_auto_state:
        return
    from .pricing import discount_of
    o.subtotal = sum(l.total for l in o.active_lines)
    cats = _categories(db, o.active_lines)

    # ---- item-level
    item_presets = [p for p in presets if p.scope in ("item", "both") and p.kind in ("percent", "amount")]
    for l in o.lines:
        if l.discount_type and not l.discount_auto:
            continue                                         # manual item discount wins
        best, best_amount = None, 0
        if l.status != "void":
            for p in item_presets:
                if not _matches(l, cats, p.target_category_ids, p.target_item_ids) or not _usable(p, o, l.created_at or now()):
                    continue
                amount = discount_of(p.kind, p.value, p.max_amount, l.total)
                if amount > best_amount:
                    best, best_amount = p, amount
        if best:
            l.discount_type, l.discount_value, l.discount_cap = best.kind, best.value, best.max_amount
            l.discount_reason, l.discount_preset_id, l.discount_auto = best.name, best.id, True
            l.discount_by = l.discount_approved_by = None
        elif l.discount_auto:
            l.discount_type, l.discount_value, l.discount_cap, l.discount_reason, l.discount_preset_id = None, 0, None, None, None
            l.discount_auto = False

    # ---- bill-level
    if o.discount_type and not o.discount_auto:
        return                                               # manual bill discount wins
    remainder = o.subtotal - sum(discount_of(l.discount_type, l.discount_value, l.discount_cap, l.total)
                                 for l in o.active_lines)
    at = o.created_at or now()
    best, best_amount, best_rule = None, 0, None
    for p in presets:
        if p.scope not in ("order", "both") or not _usable(p, o, at):
            continue
        rule = rule_of(p)
        amount = rule_amount(db, o, rule, cats) if rule else discount_of(p.kind, p.value, None, remainder)
        amount = min(amount, p.max_amount) if p.max_amount else amount
        amount = min(amount, remainder)
        if amount > best_amount:
            best, best_amount, best_rule = p, amount, rule
    if best:
        o.discount_type, o.discount_value, o.discount_cap = best.kind, best.value, best.max_amount
        o.discount_reason, o.discount_preset_id, o.discount_rule, o.discount_auto = best.name, best.id, best_rule, True
        o.discount_code = None
        o.discount_by = o.discount_approved_by = None
    elif o.discount_auto:
        o.discount_type, o.discount_value, o.discount_cap, o.discount_reason = None, 0, None, None
        o.discount_preset_id, o.discount_rule, o.discount_auto = None, None, False


def auto_amount(o: Order) -> int:
    """Part of the order's discount given by the business (automatic presets, promo codes) — not by a person."""
    bill = o.discount_amount - o.line_discount_amount
    return sum(l.discount_amount for l in o.active_lines if l.discount_auto) + (bill if (o.discount_auto or o.discount_code) else 0)
