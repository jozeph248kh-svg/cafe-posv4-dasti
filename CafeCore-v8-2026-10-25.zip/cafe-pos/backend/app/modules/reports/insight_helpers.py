"""Shared helpers and the section list for the insight reports.

Split out of `insights.py` (436 lines) so the individual reports can live in their own module
without a circular import: `insights` and `insight_sections` both import from here, and `insights`
re-exports the report functions so `router.py` and older callers keep working unchanged.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy.orm import Session

from app.core.models import User
from app.modules.menu.models import MenuItem
from app.modules.orders.models import Order

SECTIONS = ("discounts", "staff", "shifts", "menu", "modifiers", "tables", "kitchen", "tax", "customers")


def _closed(d1: date, d2: date):
    return (Order.business_date >= d1, Order.business_date <= d2, Order.status == "closed")


def _users(db: Session) -> dict[int, str]:
    return {u.id: u.full_name for u in db.query(User.id, User.full_name).all()}


def _system_items(db: Session) -> set[int]:
    return {i.id for i in db.query(MenuItem.id, MenuItem.code).all() if (i.code or "").startswith("__")}


def _pct(a: float, b: float, nd: int = 1) -> float:
    return round(a * 100 / b, nd) if b else 0


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return 0
    v = sorted(values)
    k = (len(v) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(v) - 1)
    return round(v[lo] + (v[hi] - v[lo]) * (k - lo), 1)


def _closed(d1: date, d2: date):
    return (Order.business_date >= d1, Order.business_date <= d2, Order.status == "closed")


def _users(db: Session) -> dict[int, str]:
    return {u.id: u.full_name for u in db.query(User.id, User.full_name).all()}


def _system_items(db: Session) -> set[int]:
    return {i.id for i in db.query(MenuItem.id, MenuItem.code).all() if (i.code or "").startswith("__")}


def _pct(a: float, b: float, nd: int = 1) -> float:
    return round(a * 100 / b, nd) if b else 0


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return 0
    v = sorted(values)
    k = (len(v) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(v) - 1)
    return round(v[lo] + (v[hi] - v[lo]) * (k - lo), 1)
