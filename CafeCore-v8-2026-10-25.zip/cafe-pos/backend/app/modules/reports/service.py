from collections import defaultdict
from datetime import date, timedelta

from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.models import User
from app.core.utils import business_day, day_bounds, now
from app.modules.menu.models import MenuCategory, MenuItem
from app.modules.orders.models import Order, OrderLine, Payment

TYPE_LABEL = {"dine_in": "سالن", "takeaway": "بیرون‌بر", "delivery": "پیک"}
PAY_LABEL = {"cash": "نقد", "card": "کارتخوان", "online": "آنلاین", "credit": "نسیه", "wallet": "کیف پول"}


def refunds_in_range(db: Session, d1: date, d2: date) -> list[tuple[date, str, int]]:
    """Refunds are reported on the business day they were PAID OUT (not the day of the original order), so a closed
    day's figures never change afterwards and they match the cash shift. Returns (business_day, method, amount>0)."""
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    start, end = day_bounds(d1, cutoff)[0], day_bounds(d2, cutoff)[1]
    # Only refunds of bills that actually produced revenue. A cancelled bill was never revenue, so handing money back
    # for it must not subtract anything (audit item 2) — otherwise a legacy/imported row turns the day negative.
    rows = (db.query(Payment).join(Order, Order.id == Payment.order_id)
            .filter(Payment.is_refund.is_(True), Payment.created_at >= start, Payment.created_at < end,
                    Order.status == "closed").all())
    return [(business_day(p.created_at, cutoff), p.method, -p.amount) for p in rows]


def refund_day(when, cutoff: int):
    """The business day a payment/refund/movement belongs to (day.cutoff_hour rules)."""
    return business_day(when, cutoff)


def _item_costs(db: Session) -> dict[int, float]:
    """Unit recipe cost at TODAY's prices — only for 'what would it cost now' views, never for historical COGS."""
    try:
        from app.modules.inventory.service import item_costs  # optional module
        return item_costs(db)
    except Exception:
        return {}


def _cogs_by_item(db: Session, d1: date, d2: date) -> dict[int, float]:
    try:
        from app.modules.inventory.costing import cogs_by_item
        return cogs_by_item(db, d1, d2)
    except Exception:                     # inventory module disabled: no material costing at all
        return {}


def _cogs_total(db: Session, d1: date, d2: date) -> tuple[float, int, int, int]:
    try:
        from app.modules.inventory.costing import cogs_total
        return cogs_total(db, d1, d2)
    except Exception:
        return 0.0, 0, 0, 0


def line_net_expr():
    """What one sold line is worth after its OWN discount (modifiers included)."""
    return OrderLine.unit_price * OrderLine.qty - func.coalesce(OrderLine.discount_amount, 0)


def item_net_facts(db: Session, d1: date, d2: date) -> list[dict]:
    """Per menu item: quantity, list-price revenue and the revenue actually charged — for closed orders.

    The whole-bill discount (a 100 % «مهمان مدیر» comp included) belongs to the *lines of that bill*, so it is
    allocated over them in proportion to their net amount — the same proportional rule the split feature uses.
    Without this, every per-item report counted list prices and showed a profit on items that were given away
    (reported from the shop, see tests/test_profit_by_item.py).

    One GROUP BY does the work for both SQLite and PostgreSQL (SQLAlchemy window functions); no per-line objects
    are built, so this stays as cheap as the dashboard aggregates that use it.
    """
    net = line_net_expr()
    listed = OrderLine.unit_price * OrderLine.qty                                  # true list price of the line
    order_net = func.sum(net).over(partition_by=OrderLine.order_id)
    order_line_disc = func.sum(func.coalesce(OrderLine.discount_amount, 0)).over(partition_by=OrderLine.order_id)
    bill_disc = func.coalesce(Order.discount_amount, 0) - order_line_disc          # bill-level part only
    share = case((order_net > 0, bill_disc * net * 1.0 / func.nullif(order_net, 0)), else_=0)
    charged = net - share
    sub = (db.query(OrderLine.menu_item_id.label("mid"), OrderLine.qty.label("qty"), listed.label("listed"),
                    charged.label("charged"))
           .join(Order, Order.id == OrderLine.order_id)
           .filter(Order.business_date >= d1, Order.business_date <= d2,
                   Order.status == "closed", OrderLine.status != "void")
           .subquery())
    rows = (db.query(sub.c.mid, func.sum(sub.c.qty), func.sum(sub.c.listed), func.sum(sub.c.charged))
            .group_by(sub.c.mid).all())
    # `gross` = list price (before the line's OWN discount too), `revenue` = what was really charged.
    # The difference is the whole discount of those units — item discount and bill share alike — so the report can
    # never show a «discount» column that is smaller than the discount actually given (audit item 1).
    return [{"id": mid, "qty": int(qty or 0), "gross": int(round(listed or 0)), "revenue": int(round(charged or 0))}
            for mid, qty, listed, charged in rows]


def sales_report(db: Session, d1: date, d2: date) -> dict:
    # Plain column queries instead of ORM objects: a year of a busy café (~50k orders / 150k lines) is aggregated
    # in about a second instead of building hundreds of thousands of Python objects.
    in_range = (Order.business_date >= d1, Order.business_date <= d2)
    orders = (db.query(Order.id, Order.number, Order.business_date, Order.type, Order.status, Order.cancel_reason, Order.guests,
                       Order.waiter_id, Order.subtotal, Order.discount_amount, Order.service_amount, Order.tax_amount, Order.total,
                       Order.created_at)
              .filter(*in_range).order_by(Order.business_date, Order.id).all())
    closed = [o for o in orders if o.status == "closed"]
    closed_ids = {o.id for o in closed}
    cancelled = [o for o in orders if o.status == "cancelled" and not (o.cancel_reason or "").startswith("ادغام")]
    lines = (db.query(OrderLine.order_id, OrderLine.menu_item_id, OrderLine.name, OrderLine.unit_price, OrderLine.qty,
                      OrderLine.status, OrderLine.void_reason, OrderLine.voided_by)
             .join(Order, Order.id == OrderLine.order_id).filter(*in_range)
             .order_by(Order.business_date, Order.id, OrderLine.id).all())
    pays = (db.query(Payment.order_id, Payment.method, Payment.amount)
            .join(Order, Order.id == Payment.order_id)
            .filter(*in_range, Order.status == "closed", Payment.is_refund.is_(False)).all())
    items = {i.id: i for i in db.query(MenuItem).all()}
    cats = {c.id: c for c in db.query(MenuCategory).all()}
    users = {u.id: u.full_name for u in db.query(User).all()}

    gross = sum(o.subtotal for o in closed)
    discounts = sum(o.discount_amount for o in closed)
    service = sum(o.service_amount for o in closed)
    tax = sum(o.tax_amount for o in closed)
    net = sum(o.total for o in closed)
    refund_rows = refunds_in_range(db, d1, d2)
    refunds = sum(r[2] for r in refund_rows)
    guests = sum(o.guests for o in closed if o.type == "dine_in")

    by_day, by_hour, by_type, by_waiter = defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0])
    by_item = defaultdict(lambda: {"qty": 0, "revenue": 0, "gross": 0, "cost": 0.0})
    by_cat = defaultdict(lambda: {"qty": 0, "revenue": 0, "gross": 0})
    by_pay = defaultdict(int)
    weekday_hour = defaultdict(int)
    cost_total = 0.0
    for o in closed:
        for agg, key in ((by_day, o.business_date.isoformat()), (by_hour, o.created_at.hour), (by_type, o.type),
                         (by_waiter, o.waiter_id)):
            agg[key][0] += o.total
            agg[key][1] += 1
        weekday_hour[(o.created_at.weekday(), o.created_at.hour)] += o.total
    for p in pays:
        by_pay[p.method] += p.amount
    system_items = {i.id for i in items.values() if (i.code or "").startswith("__")}   # delivery fee etc. aren't menu sales
    numbers = {o.id: (o.number, o.business_date) for o in orders}
    voids = []
    for l in lines:
        if l.status == "void":
            num, bday = numbers[l.order_id]
            voids.append({"order_number": num, "date": bday, "name": l.name, "qty": l.qty, "amount": l.unit_price * l.qty,
                          "reason": l.void_reason, "by": users.get(l.voided_by)})

    # per-item money view: list price, the revenue actually charged (item + bill discounts taken off, the bill
    # discount shared over its lines) and the material cost frozen at sale time (see inventory/costing.py).
    item_cogs = _cogs_by_item(db, d1, d2)
    cogs_total_value, cogs_estimated_lines, cogs_unknown_lines, cogs_unknown_returns = _cogs_total(db, d1, d2)
    for f in item_net_facts(db, d1, d2):
        if f["id"] in system_items:
            continue
        bi = by_item[f["id"]]
        bi["qty"] += f["qty"]
        bi["gross"] += f["gross"]
        bi["revenue"] += f["revenue"]
        c = item_cogs.get(f["id"], 0)
        bi["cost"] += c
        cost_total += c
        it = items.get(f["id"])
        if it:
            by_cat[it.category_id]["qty"] += f["qty"]
            by_cat[it.category_id]["revenue"] += f["revenue"]
            by_cat[it.category_id]["gross"] += f["gross"]

    # an item may have no sale in the range but a RETURN in it (the cost of that return belongs to this range).
    # Without this row the money would exist in the P&L and vanish from this table — the two reports must reconcile.
    for mid, cost in item_cogs.items():
        if mid in by_item or mid in system_items or abs(cost) < 0.5:
            continue
        bi = by_item[mid]
        bi["qty"] += 0
        bi["cost"] += cost
        cost_total += cost
        it = items.get(mid)
        if it:
            by_cat[it.category_id]["cost"] = by_cat[it.category_id].get("cost", 0) + cost

    for _d, method, amount in refund_rows:          # net per method = takings − refunds paid out in the range
        by_pay[method] -= amount

    days = []
    d = d1
    while d <= d2:
        v = by_day.get(d.isoformat(), [0, 0])
        days.append({"date": d.isoformat(), "revenue": v[0], "orders": v[1]})
        d += timedelta(days=1)

    return {
        "range": {"from": d1, "to": d2},
        "summary": {
            # `net` is what the guests were charged (VAT included) — the till/tax view, kept unchanged for
            # compatibility. `net_revenue` is the same money minus VAT: the "net sales revenue" of the P&L.
            "orders": len(closed), "gross": gross, "discounts": discounts, "service": service, "tax": tax, "net": net,
            "net_revenue": net - tax,
            "refunds": refunds, "avg_ticket": round(net / len(closed)) if closed else 0, "guests": guests,
            "cancelled": len(cancelled), "cancelled_amount": sum(o.total for o in cancelled),
            "voids": len(voids), "voids_amount": sum(v["amount"] for v in voids),
            "food_cost": round(sum(v["cost"] for v in by_item.values())),   # == the total of the table below
            "food_cost_pct": round(cost_total / (gross - discounts) * 100, 1) if gross - discounts > 0 else 0,
            # legacy rows without a frozen cost: "estimated" comes from a real historical movement,
            # "unknown" could not be reconstructed at all — a 0 there is NOT a certain cost
            "food_cost_estimated_lines": cogs_estimated_lines, "food_cost_unknown_lines": cogs_unknown_lines,
            "food_cost_unknown_returns": cogs_unknown_returns,
        },
        "by_day": days,
        "by_hour": [{"hour": h, "revenue": by_hour[h][0], "orders": by_hour[h][1]} for h in range(24)],
        "heatmap": [{"weekday": wd, "hour": h, "revenue": v} for (wd, h), v in weekday_hour.items()],
        "by_type": [{"type": k, "label": TYPE_LABEL.get(k, k), "revenue": v[0], "orders": v[1]} for k, v in by_type.items()],
        "by_payment": [{"method": k, "label": PAY_LABEL.get(k, k), "amount": v} for k, v in by_pay.items()],
        "by_waiter": sorted([{"id": k, "name": users.get(k, "-"), "revenue": v[0], "orders": v[1]} for k, v in by_waiter.items()],
                            key=lambda x: -x["revenue"]),
        "by_category": sorted([{"id": k, "name": cats[k].name if k in cats else "-", "color": cats[k].color if k in cats else "#999",
                                **v} for k, v in by_cat.items()], key=lambda x: -x["revenue"]),
        # `revenue` is the money actually charged for the item (list price − item discount − its share of the
        # bill discount); `gross` keeps the list price next to it. `profit` = revenue − recipe cost.
        "by_item": sorted([{"id": k, "name": items[k].name if k in items else "-",
                            "category": cats[items[k].category_id].name if k in items and items[k].category_id in cats else "-",
                            "qty": v["qty"], "revenue": v["revenue"], "gross": v["gross"], "discount": v["gross"] - v["revenue"],
                            "cost": round(v["cost"]), "profit": v["revenue"] - round(v["cost"])}
                           for k, v in by_item.items()], key=lambda x: -x["revenue"]),
        "voids": voids,
    }


# ---------------------------------------------------------------- dashboard (SQL aggregates)
def _day_facts(db: Session, d1: date, d2: date) -> dict:
    """Per business day: closed sales, cancellations. One GROUP BY instead of loading every order."""
    merged = func.coalesce(Order.cancel_reason, "").like("ادغام%")
    closed = Order.status == "closed"
    cancelled = (Order.status == "cancelled") & (~merged)
    rows = (db.query(
        Order.business_date,
        func.coalesce(func.sum(case((closed, 1), else_=0)), 0),
        func.coalesce(func.sum(case((closed, Order.subtotal), else_=0)), 0),
        func.coalesce(func.sum(case((closed, Order.total), else_=0)), 0),
        func.coalesce(func.sum(case((closed, Order.discount_amount), else_=0)), 0),
        func.coalesce(func.sum(case((closed, Order.service_amount), else_=0)), 0),
        func.coalesce(func.sum(case((closed, Order.tax_amount), else_=0)), 0),
        func.coalesce(func.sum(case((closed & (Order.type == "dine_in"), Order.guests), else_=0)), 0),
        func.coalesce(func.sum(case((cancelled, 1), else_=0)), 0),
        func.coalesce(func.sum(case((cancelled, Order.total), else_=0)), 0),
    ).filter(Order.business_date >= d1, Order.business_date <= d2)
        .group_by(Order.business_date).all())
    return {r[0]: tuple(int(x or 0) for x in r[1:]) for r in rows}


def _void_facts(db: Session, d1: date, d2: date) -> dict:
    """Voided lines per business day (count and amount) — the same rows `sales_report` lists one by one."""
    rows = (db.query(Order.business_date, func.count(OrderLine.id),
                     func.coalesce(func.sum(OrderLine.unit_price * OrderLine.qty), 0))
            .join(Order, Order.id == OrderLine.order_id)
            .filter(Order.business_date >= d1, Order.business_date <= d2, OrderLine.status == "void")
            .group_by(Order.business_date).all())
    return {r[0]: (int(r[1] or 0), int(r[2] or 0)) for r in rows}


def _item_facts(db: Session, d1: date, d2: date) -> list[dict]:
    """Per item: qty, charged revenue and list price — the same numbers as `sales_report()['by_item']`."""
    return item_net_facts(db, d1, d2)


def _catalog(db: Session):
    items = {i.id: i for i in db.query(MenuItem).all()}
    cats = {c.id: c for c in db.query(MenuCategory).all()}
    system = {i.id for i in items.values() if (i.code or "").startswith("__")}   # delivery fee etc. aren't menu sales
    return items, cats, system


def _summary(facts: tuple, voids: tuple, refunds: int, cost_total: float, est: int = 0, unknown: int = 0,
             unknown_returns: int = 0) -> dict:
    """The exact `sales_report()['summary']` shape, from the aggregates above."""
    n, gross, net, discounts, service, tax, guests, cancelled, cancelled_amount = facts
    return {
        "orders": n, "gross": gross, "discounts": discounts, "service": service, "tax": tax, "net": net,
        "net_revenue": net - tax,
        "refunds": refunds, "avg_ticket": round(net / n) if n else 0, "guests": guests,
        "cancelled": cancelled, "cancelled_amount": cancelled_amount,
        "voids": voids[0], "voids_amount": voids[1],
        "food_cost": round(cost_total), "food_cost_pct": round(cost_total / (gross - discounts) * 100, 1) if gross - discounts > 0 else 0,
        "food_cost_estimated_lines": est, "food_cost_unknown_lines": unknown,
        "food_cost_unknown_returns": unknown_returns,
    }


ZERO_FACTS = (0,) * 9
ZERO_VOIDS = (0, 0)


def dashboard_report(db: Session, today: date) -> dict:
    """Everything the dashboard shows, from a handful of SQL aggregates.

    It used to call `sales_report()` three times (today / yesterday / last 14 days); each call pulled every order,
    line and payment of its range into Python and looped over them — with a year of history that is ~100k lines,
    three times, on every dashboard refresh (the slowest endpoint in the load test). The same figures are now
    produced by GROUP BY queries that return a few dozen rows, so the cost no longer grows with the history.
    """
    yesterday = today - timedelta(days=1)
    d14 = today - timedelta(days=13)
    days = [d14 + timedelta(days=i) for i in range(14)]
    facts = _day_facts(db, d14, today)
    voids = _void_facts(db, d14, today)
    items, cats, system = _catalog(db)
    # material cost frozen at sale time (see inventory/costing.py) — never today's prices
    cogs_today = _cogs_by_item(db, today, today)
    cogs_yesterday = _cogs_by_item(db, yesterday, yesterday)
    item_cogs = _cogs_by_item(db, d14, today)

    # ---- today: summary, by_hour, by_type, by_payment
    ref_today = refunds_in_range(db, today, today)
    cost_today_total, est_today, unknown_today, unknown_returns_today = _cogs_total(db, today, today)
    cost_today = cost_today_total          # the same number the P&L reports for today (returns included)
    today_summary = _summary(facts.get(today, ZERO_FACTS), voids.get(today, ZERO_VOIDS),
                             sum(r[2] for r in ref_today), cost_today, est_today, unknown_today, unknown_returns_today)

    hour_rows = (db.query(func.extract("hour", Order.created_at), func.sum(Order.total), func.count(Order.id))
                 .filter(Order.business_date >= today, Order.business_date <= today, Order.status == "closed")
                 .group_by(func.extract("hour", Order.created_at)).all())
    by_hour = {int(h): [int(rev or 0), int(n or 0)] for h, rev, n in hour_rows if h is not None}

    type_rows = (db.query(Order.type, func.sum(Order.total), func.count(Order.id))
                 .filter(Order.business_date >= today, Order.business_date <= today, Order.status == "closed")
                 .group_by(Order.type).order_by(func.min(Order.id)).all())
    by_type = [{"type": t, "label": TYPE_LABEL.get(t, t), "revenue": int(rev or 0), "orders": int(n or 0)}
               for t, rev, n in type_rows]

    pay_rows = (db.query(Payment.method, func.sum(Payment.amount))
                .join(Order, Order.id == Payment.order_id)
                .filter(Order.business_date >= today, Order.business_date <= today,
                        Order.status == "closed", Payment.is_refund.is_(False))
                .group_by(Payment.method).order_by(func.min(Payment.id)).all())
    by_pay = {m: int(a or 0) for m, a in pay_rows}
    for _d, method, amount in ref_today:          # net per method = takings − refunds paid out that day
        by_pay[method] = by_pay.get(method, 0) - amount

    # ---- yesterday: summary only
    ref_y = refunds_in_range(db, yesterday, yesterday)
    cost_y, est_y, unknown_y, unknown_returns_y = _cogs_total(db, yesterday, yesterday)
    yesterday_summary = _summary(facts.get(yesterday, ZERO_FACTS), voids.get(yesterday, ZERO_VOIDS),
                                 sum(r[2] for r in ref_y), cost_y, est_y, unknown_y, unknown_returns_y)

    # ---- last 14 days: the daily strip, the item table and the categories
    item_rows = [r for r in _item_facts(db, d14, today) if r["id"] not in system]
    by_item, by_cat = [], {}
    for f in item_rows:
        mid, qty, revenue = f["id"], f["qty"], f["revenue"]
        it = items.get(mid)
        cost = item_cogs.get(mid, 0)
        cat = cats.get(it.category_id) if it and it.category_id in cats else None
        by_item.append({"id": mid, "name": it.name if it else "-", "category": cat.name if cat else "-",
                        "qty": qty, "revenue": revenue, "gross": f["gross"], "discount": f["gross"] - revenue,
                        "cost": round(cost), "profit": revenue - round(cost)})
        agg = by_cat.setdefault(it.category_id if it else None, {"id": it.category_id if it else None,
                                                                 "name": cat.name if cat else "-",
                                                                 "color": cat.color if cat else "#999", "qty": 0, "revenue": 0})
        agg["qty"] += qty
        agg["revenue"] += revenue
    by_item.sort(key=lambda x: (-x["revenue"], x["id"]))          # stable and deterministic (ties by id)
    by_category = sorted(by_cat.values(), key=lambda x: (-x["revenue"], x["id"] if x["id"] is not None else 0))
    last14 = []
    for d in days:
        f = facts.get(d, ZERO_FACTS)
        last14.append({"date": d.isoformat(), "revenue": f[2], "orders": f[0]})

    return {
        "today": today_summary, "yesterday": yesterday_summary,
        "by_hour": [{"hour": h, "revenue": by_hour.get(h, [0, 0])[0], "orders": by_hour.get(h, [0, 0])[1]} for h in range(24)],
        "by_payment": [{"method": m, "label": PAY_LABEL.get(m, m), "amount": a} for m, a in by_pay.items()],
        "by_type": by_type,
        "top_items": by_item[:8], "by_category": by_category, "last14": last14,
        "live": _live(db),
        "low_stock": _low_stock(db),
    }


def _live(db: Session) -> dict:
    """Open orders and kitchen load — two aggregates instead of loading every open order and ticket."""
    n, amount, tables, guests = (db.query(func.count(Order.id), func.coalesce(func.sum(Order.total), 0),
                                          func.count(func.distinct(Order.table_id)),
                                          func.coalesce(func.sum(case((Order.type == "dine_in", Order.guests), else_=0)), 0))
                                 .filter(Order.status == "open").one())
    live = {"open_orders": int(n or 0), "open_amount": int(amount or 0), "occupied_tables": int(tables or 0),
            "guests": int(guests or 0)}
    try:
        from app.modules.kitchen.models import KitchenTicket
        late_min = settings_store.get(db, "kitchen.late_minutes", 15)
        cutoff = now() - timedelta(minutes=late_min)
        active, late = (db.query(func.count(KitchenTicket.id),
                                 func.coalesce(func.sum(case((KitchenTicket.created_at < cutoff, 1), else_=0)), 0))
                        .filter(KitchenTicket.status.in_(("new", "preparing"))).one())
        live.update({"active_tickets": int(active or 0), "late": int(late or 0)})
    except Exception:  # noqa: BLE001 — the kitchen module is optional, exactly as before
        pass
    return live


def _low_stock(db: Session) -> list:
    try:
        from app.modules.inventory.models import Ingredient
        return [{"id": i.id, "name": i.name, "stock": i.stock, "unit": i.unit, "min_stock": i.min_stock}
                for i in db.query(Ingredient).filter(Ingredient.is_active.is_(True),
                                                     Ingredient.stock <= Ingredient.min_stock).all()]
    except Exception:  # noqa: BLE001
        return []
