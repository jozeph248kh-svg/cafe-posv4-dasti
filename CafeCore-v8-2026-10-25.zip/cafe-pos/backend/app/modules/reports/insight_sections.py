"""The individual insight reports (discounts, staff, shifts, menu, modifiers, tables, kitchen, tax, customers).

Split out of `insights.py`, one function per report, exactly as before. `insights.py` re-exports
them so the endpoints and any existing import path keep working.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.utils import day_bounds
from app.modules.menu.models import MenuCategory, MenuItem
from app.modules.orders.models import DiscountPreset, Order, OrderLine

from .insight_helpers import _closed, _pct, _percentile, _system_items, _users
from .service import item_net_facts, _item_costs, refunds_in_range

# ---------------------------------------------------------------- discounts
def discounts(db: Session, d1: date, d2: date) -> dict:
    users = _users(db)
    presets = {p.id: p.name for p in db.query(DiscountPreset.id, DiscountPreset.name).all()}
    orders = (db.query(Order.id, Order.number, Order.business_date, Order.subtotal, Order.discount_amount, Order.line_discount_amount,
                       Order.discount_type, Order.discount_value, Order.discount_reason, Order.discount_preset_id, Order.discount_by,
                       Order.discount_approved_by, Order.total)
              .filter(*_closed(d1, d2)).all())
    gross = sum(o.subtotal for o in orders)
    total = sum(o.discount_amount for o in orders)
    disc_orders = [o for o in orders if o.discount_amount > 0]
    lines = (db.query(OrderLine.order_id, OrderLine.menu_item_id, OrderLine.name, OrderLine.qty, OrderLine.unit_price,
                      OrderLine.discount_amount, OrderLine.discount_type, OrderLine.discount_value, OrderLine.discount_reason,
                      OrderLine.discount_preset_id, OrderLine.discount_by, OrderLine.discount_approved_by)
             .join(Order, Order.id == OrderLine.order_id)
             .filter(*_closed(d1, d2), OrderLine.status != "void", OrderLine.discount_amount > 0).all())

    by_reason = defaultdict(lambda: {"count": 0, "amount": 0})
    by_user = defaultdict(lambda: {"count": 0, "amount": 0, "approved": 0})
    by_approver = defaultdict(lambda: {"count": 0, "amount": 0})
    by_item = defaultdict(lambda: {"name": "", "count": 0, "qty": 0, "amount": 0})
    comps = 0

    def reason_key(preset_id, reason):
        if preset_id and preset_id in presets:
            return "🏷 " + presets[preset_id]
        if reason and " — " in reason and preset_id:
            return "🏷 " + reason.split(" — ")[0]
        return reason or "بدون دلیل"

    def add(amount, preset_id, reason, by, approver, full):
        nonlocal comps
        r = by_reason[reason_key(preset_id, reason)]
        r["count"] += 1
        r["amount"] += amount
        u = by_user[by]
        u["count"] += 1
        u["amount"] += amount
        if approver and approver != by:
            u["approved"] += 1
            a = by_approver[approver]
            a["count"] += 1
            a["amount"] += amount
        if full:
            comps += amount

    for ln in lines:
        add(ln.discount_amount, ln.discount_preset_id, ln.discount_reason, ln.discount_by, ln.discount_approved_by,
            ln.discount_amount >= ln.unit_price * ln.qty)
        it = by_item[ln.menu_item_id]
        it["name"] = ln.name
        it["count"] += 1
        it["qty"] += ln.qty
        it["amount"] += ln.discount_amount
    listing = []
    for o in disc_orders:
        bill = o.discount_amount - (o.line_discount_amount or 0)
        if bill > 0:
            add(bill, o.discount_preset_id, o.discount_reason, o.discount_by, o.discount_approved_by,
                o.discount_type == "percent" and o.discount_value >= 100)
        listing.append({"id": o.id, "number": o.number, "date": o.business_date, "subtotal": o.subtotal, "discount": o.discount_amount,
                        "items_discount": o.line_discount_amount or 0, "bill_discount": bill, "pct": _pct(o.discount_amount, o.subtotal),
                        "reason": o.discount_reason, "by": users.get(o.discount_by), "approver": users.get(o.discount_approved_by)})
    pct = _pct(total, gross, 2)
    health = "ok" if pct <= 3 else "warn" if pct <= 5 else "high"
    return {
        "summary": {"total": total, "gross": gross, "pct_of_gross": pct, "health": health, "orders": len(disc_orders),
                    "orders_pct": _pct(len(disc_orders), len(orders)), "avg_discount": round(total / len(disc_orders)) if disc_orders else 0,
                    "items_discount": sum(o.line_discount_amount or 0 for o in orders), "comps": comps,
                    "approved_count": sum(v["count"] for v in by_approver.values())},
        "by_reason": sorted([{"reason": k, **v, "share": _pct(v["amount"], total)} for k, v in by_reason.items()], key=lambda x: -x["amount"]),
        "by_user": sorted([{"user": users.get(k, "ثبت‌نشده (سفارش‌های قدیمی)") if k else "ثبت‌نشده (سفارش‌های قدیمی)", **v}
                           for k, v in by_user.items()], key=lambda x: -x["amount"]),
        "by_approver": sorted([{"user": users.get(k, "-"), **v} for k, v in by_approver.items()], key=lambda x: -x["amount"]),
        "by_item": sorted(by_item.values(), key=lambda x: -x["amount"])[:50],
        "orders": sorted(listing, key=lambda x: -x["discount"])[:300],
    }


# ---------------------------------------------------------------- staff performance
def staff(db: Session, d1: date, d2: date) -> dict:
    users = _users(db)
    system = _system_items(db)
    orders = db.query(Order.id, Order.waiter_id, Order.total, Order.guests, Order.type, Order.discount_amount, Order.discount_by).filter(*_closed(d1, d2)).all()
    per = defaultdict(lambda: {"orders": 0, "revenue": 0, "guests": 0, "items": 0, "discounts": 0, "discount_count": 0, "voids": 0, "void_amount": 0})
    owner = {}
    for o in orders:
        p = per[o.waiter_id]
        p["orders"] += 1
        p["revenue"] += o.total
        p["guests"] += o.guests if o.type == "dine_in" else 0
        owner[o.id] = o.waiter_id
    for oid, qty, mid in (db.query(OrderLine.order_id, OrderLine.qty, OrderLine.menu_item_id).join(Order, Order.id == OrderLine.order_id)
                          .filter(*_closed(d1, d2), OrderLine.status != "void").all()):
        if mid not in system:
            per[owner.get(oid)]["items"] += qty
    # discounts given (item + bill part) by the user who applied them
    for o in db.query(Order.discount_amount, Order.line_discount_amount, Order.discount_by).filter(*_closed(d1, d2), Order.discount_amount > 0).all():
        bill = o.discount_amount - (o.line_discount_amount or 0)
        if bill > 0:
            per[o.discount_by]["discounts"] += bill
            per[o.discount_by]["discount_count"] += 1
    for by, amount in (db.query(OrderLine.discount_by, OrderLine.discount_amount).join(Order, Order.id == OrderLine.order_id)
                       .filter(*_closed(d1, d2), OrderLine.status != "void", OrderLine.discount_amount > 0).all()):
        per[by]["discounts"] += amount
        per[by]["discount_count"] += 1
    in_range = (Order.business_date >= d1, Order.business_date <= d2)
    for by, qty, price in (db.query(OrderLine.voided_by, OrderLine.qty, OrderLine.unit_price).join(Order, Order.id == OrderLine.order_id)
                           .filter(*in_range, OrderLine.status == "void").all()):
        per[by]["voids"] += 1
        per[by]["void_amount"] += qty * price
    rows = []
    for uid, p in per.items():
        if not any(p.values()):
            continue
        rows.append({"id": uid, "name": users.get(uid, "بدون نام (آنلاین/سیستم)") if uid else "بدون گارسون (آنلاین/سیستم)", **p,
                     "avg_check": round(p["revenue"] / p["orders"]) if p["orders"] else 0,
                     "items_per_order": round(p["items"] / p["orders"], 1) if p["orders"] else 0,
                     "discount_pct": _pct(p["discounts"], p["revenue"] + p["discounts"])})
    return {"rows": sorted(rows, key=lambda x: -x["revenue"])}


# ---------------------------------------------------------------- cash reconciliation
def shifts(db: Session, d1: date, d2: date) -> dict:
    try:
        from app.modules.shifts.models import Shift
    except ImportError:
        return {"available": False, "rows": [], "by_cashier": []}
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    start, end = day_bounds(d1, cutoff)[0], day_bounds(d2, cutoff)[1]
    users = _users(db)
    rows, per = [], defaultdict(lambda: {"shifts": 0, "over": 0, "short": 0, "net": 0, "sales": 0})
    for s in (db.query(Shift).filter(Shift.status == "closed", Shift.closed_at >= start, Shift.closed_at < end)
              .order_by(Shift.closed_at.desc()).all()):
        diff = (s.counted_cash or 0) - (s.expected_cash or 0)
        sales = (s.summary or {}).get("total_sales", 0)
        rows.append({"id": s.id, "register": s.register.name if s.register else None, "opened_at": s.opened_at, "closed_at": s.closed_at, "opened_by": users.get(s.opened_by),
                     "closed_by": users.get(s.closed_by), "opening_cash": s.opening_cash, "expected": s.expected_cash or 0,
                     "counted": s.counted_cash or 0, "difference": diff, "sales": sales, "orders": (s.summary or {}).get("orders", 0),
                     "note": s.note})
        c = per[s.closed_by]
        c["shifts"] += 1
        c["sales"] += sales
        c["net"] += diff
        c["over" if diff > 0 else "short"] += abs(diff) if diff else 0
    return {"available": True, "rows": rows,
            "summary": {"shifts": len(rows), "net": sum(r["difference"] for r in rows), "with_difference": sum(1 for r in rows if r["difference"]),
                        "short": sum(-r["difference"] for r in rows if r["difference"] < 0), "over": sum(r["difference"] for r in rows if r["difference"] > 0)},
            "by_cashier": sorted([{"name": users.get(k, "-"), **v} for k, v in per.items()], key=lambda x: x["net"])}


# ---------------------------------------------------------------- menu engineering
CLASS_LABEL = {"star": "ستاره", "plowhorse": "اسب کاری", "puzzle": "معما", "dog": "کم‌بازده"}
CLASS_HINT = {
    "star": "پرفروش و پرسود — حفظ کیفیت و جایگاه ویژه در منو",
    "plowhorse": "پرفروش ولی کم‌سود — بازنگری قیمت یا کاهش بهای تمام‌شده",
    "puzzle": "پرسود ولی کم‌فروش — معرفی بهتر، جای بهتر در منو، پیشنهاد گارسون",
    "dog": "کم‌فروش و کم‌سود — حذف یا بازطراحی",
}


def menu(db: Session, d1: date, d2: date) -> dict:
    # unit cost = the frozen material cost of what was actually sold (base recipe + the modifiers chosen),
    # never today's prices — buying flour dearer tomorrow must not "fix" yesterday's margin
    system = _system_items(db)
    frozen_cost: dict[int, float] = defaultdict(float)
    frozen_qty: dict[int, int] = defaultdict(int)
    try:
        from app.modules.inventory.costing import cogs_by_item, line_costs
        frozen_cost.update(cogs_by_item(db, d1, d2))     # sold cost − returns booked in the same range
        for f in line_costs(db, d1, d2):
            frozen_qty[f["item_id"]] += f["qty"]
    except Exception:      # no inventory module: no material cost at all
        pass
    costs = {mid: (frozen_cost[mid] / frozen_qty[mid] if frozen_qty[mid] else 0.0) for mid in frozen_cost}
    cats = {c.id: c.name for c in db.query(MenuCategory.id, MenuCategory.name).all()}
    agg = defaultdict(lambda: {"qty": 0, "revenue": 0, "discount": 0})
    # revenue = what was really charged for the item (item discount and its share of the bill discount taken off)
    for f in item_net_facts(db, d1, d2):
        if f["id"] in system:
            continue
        a = agg[f["id"]]
        a["qty"] += f["qty"]
        a["revenue"] += f["revenue"]
        a["discount"] += f["gross"] - f["revenue"]
    items = {i.id: i for i in db.query(MenuItem).filter(MenuItem.is_active.is_(True)).all() if i.id not in system}
    n = len(agg) or 1
    total_qty = sum(a["qty"] for a in agg.values()) or 1
    rows = []
    for mid, a in agg.items():
        it = items.get(mid)
        unit_cost = costs.get(mid, 0)
        avg_price = a["revenue"] / a["qty"] if a["qty"] else 0
        cm = avg_price - unit_cost                                    # contribution margin per unit
        rows.append({"id": mid, "name": it.name if it else "(حذف‌شده از منو)", "category": cats.get(it.category_id, "-") if it else "-",
                     "qty": a["qty"], "revenue": a["revenue"], "discount": a["discount"], "mix_pct": _pct(a["qty"], total_qty),
                     "unit_cost": round(unit_cost), "cost": round(frozen_cost.get(mid, 0.0)),
                     "cm": round(cm), "total_cm": round(cm * a["qty"]),
                     "cost_pct": _pct(unit_cost, avg_price) if avg_price else 0})
    avg_cm = sum(r["total_cm"] for r in rows) / total_qty if rows else 0
    threshold = 0.7 / n * 100                                         # popularity: ≥ 70% of an equal share
    for r in rows:
        popular = r["mix_pct"] >= threshold
        profitable = r["cm"] >= avg_cm
        r["class"] = "star" if popular and profitable else "plowhorse" if popular else "puzzle" if profitable else "dog"
        r["class_label"] = CLASS_LABEL[r["class"]]
    unsold = [{"id": i.id, "name": i.name, "category": cats.get(i.category_id, "-"), "price": i.price}
              for i in items.values() if i.id not in agg]
    counts = {k: sum(1 for r in rows if r["class"] == k) for k in CLASS_LABEL}
    return {"rows": sorted(rows, key=lambda x: -x["total_cm"]), "unsold": sorted(unsold, key=lambda x: x["category"]),
            "avg_cm": round(avg_cm), "popularity_threshold": round(threshold, 2), "has_costs": any(costs.get(r["id"]) for r in rows),
            "classes": [{"key": k, "label": v, "hint": CLASS_HINT[k], "count": counts[k]} for k, v in CLASS_LABEL.items()]}


# ---------------------------------------------------------------- modifiers
def modifiers(db: Session, d1: date, d2: date) -> dict:
    agg = defaultdict(lambda: {"count": 0, "revenue": 0, "items": defaultdict(int)})
    for name, qty, mods in (db.query(OrderLine.name, OrderLine.qty, OrderLine.modifiers).join(Order, Order.id == OrderLine.order_id)
                            .filter(*_closed(d1, d2), OrderLine.status != "void").all()):
        for m in mods or []:
            a = agg[m.get("name") or "-"]
            a["count"] += qty
            a["revenue"] += (m.get("price") or 0) * qty
            a["items"][name] += qty
    rows = [{"name": k, "count": v["count"], "revenue": v["revenue"],
             "top_items": "، ".join(n for n, _ in sorted(v["items"].items(), key=lambda x: -x[1])[:3])} for k, v in agg.items()]
    return {"rows": sorted(rows, key=lambda x: (-x["revenue"], -x["count"])), "revenue": sum(r["revenue"] for r in rows)}


# ---------------------------------------------------------------- tables
def tables(db: Session, d1: date, d2: date) -> dict:
    try:
        from app.modules.floor.models import Area, DiningTable
    except ImportError:
        return {"available": False}
    tbl = {t.id: t for t in db.query(DiningTable).all()}
    areas = {a.id: a.name for a in db.query(Area).all()}
    per = defaultdict(lambda: {"orders": 0, "guests": 0, "revenue": 0, "minutes": []})
    for tid, guests, total, created, closed in (db.query(Order.table_id, Order.guests, Order.total, Order.created_at, Order.closed_at)
                                                .filter(*_closed(d1, d2), Order.type == "dine_in", Order.table_id.isnot(None)).all()):
        p = per[tid]
        p["orders"] += 1
        p["guests"] += guests or 1
        p["revenue"] += total
        if closed and created and closed > created:
            p["minutes"].append((closed - created).total_seconds() / 60)
    days = (d2 - d1).days + 1
    rows, by_area = [], defaultdict(lambda: {"orders": 0, "guests": 0, "revenue": 0, "tables": 0})
    for tid, t in tbl.items():
        p = per.get(tid, {"orders": 0, "guests": 0, "revenue": 0, "minutes": []})
        mins = p["minutes"]
        area = areas.get(t.area_id, "-")
        rows.append({"id": tid, "name": t.name, "area": area, "seats": t.seats, "orders": p["orders"], "guests": p["guests"], "revenue": p["revenue"],
                     "avg_minutes": round(sum(mins) / len(mins)) if mins else 0, "per_guest": round(p["revenue"] / p["guests"]) if p["guests"] else 0,
                     "turns_per_day": round(p["orders"] / days, 2), "per_seat_day": round(p["revenue"] / (t.seats or 1) / days)})
        a = by_area[area]
        a["tables"] += 1
        for k in ("orders", "guests", "revenue"):
            a[k] += p[k]
    all_mins = [m for p in per.values() for m in p["minutes"]]
    guests = sum(r["guests"] for r in rows)
    revenue = sum(r["revenue"] for r in rows)
    return {"available": True, "rows": sorted(rows, key=lambda x: -x["revenue"]),
            "by_area": [{"area": k, **v, "per_guest": round(v["revenue"] / v["guests"]) if v["guests"] else 0} for k, v in by_area.items()],
            "summary": {"orders": sum(r["orders"] for r in rows), "guests": guests, "revenue": revenue,
                        "per_guest": round(revenue / guests) if guests else 0, "avg_minutes": round(sum(all_mins) / len(all_mins)) if all_mins else 0,
                        "turns_per_table_day": round(sum(r["orders"] for r in rows) / (len(rows) or 1) / days, 2)}}


# ---------------------------------------------------------------- kitchen speed
def kitchen(db: Session, d1: date, d2: date) -> dict:
    try:
        from app.modules.kitchen.models import KitchenTicket, KitchenTicketItem
        from app.modules.menu.models import Station
    except ImportError:
        return {"available": False}
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)
    late = settings_store.get(db, "kitchen.late_minutes", 15)
    start, end = day_bounds(d1, cutoff)[0], day_bounds(d2, cutoff)[1]
    stations = {s.id: s.name for s in db.query(Station.id, Station.name).all()}
    tickets = (db.query(KitchenTicket.id, KitchenTicket.station_id, KitchenTicket.created_at, KitchenTicket.started_at, KitchenTicket.ready_at)
               .filter(KitchenTicket.created_at >= start, KitchenTicket.created_at < end, KitchenTicket.status != "void",
                       KitchenTicket.ready_at.isnot(None)).all())
    # created_at keeps microseconds while status times are whole seconds → clamp tiny negatives to 0
    prep = {t.id: max(0.0, (t.ready_at - t.created_at).total_seconds() / 60) for t in tickets}
    wait = [max(0.0, (t.started_at - t.created_at).total_seconds() / 60) for t in tickets if t.started_at]
    per_station = defaultdict(list)
    for t in tickets:
        if t.id in prep:
            per_station[t.station_id].append(prep[t.id])
    per_item = defaultdict(lambda: {"qty": 0, "times": []})
    if prep:
        for tid, name, qty in (db.query(KitchenTicketItem.ticket_id, KitchenTicketItem.name, KitchenTicketItem.qty)
                               .filter(KitchenTicketItem.ticket_id.in_(list(prep)), KitchenTicketItem.is_void.is_(False)).all()):
            per_item[name]["qty"] += qty
            per_item[name]["times"].append(prep[tid])

    def stats(v):
        return {"count": len(v), "avg": round(sum(v) / len(v), 1) if v else 0, "p90": _percentile(v, 0.9),
                "late_pct": _pct(sum(1 for x in v if x > late), len(v))}
    allv = list(prep.values())
    return {"available": True, "late_minutes": late,
            "summary": {**stats(allv), "avg_wait_to_start": round(sum(wait) / len(wait), 1) if wait else 0},
            "by_station": sorted([{"station": stations.get(k, "بدون ایستگاه"), **stats(v)} for k, v in per_station.items()], key=lambda x: -x["avg"]),
            "by_item": sorted([{"name": k, "qty": v["qty"], **stats(v["times"])} for k, v in per_item.items() if v["times"]],
                              key=lambda x: -x["avg"])[:60]}


# ---------------------------------------------------------------- tax ledger
def tax(db: Session, d1: date, d2: date) -> dict:
    rows = (db.query(Order.business_date, func.count(Order.id), func.sum(Order.subtotal), func.sum(Order.discount_amount),
                     func.sum(Order.service_amount), func.sum(Order.tax_amount), func.sum(Order.rounding), func.sum(Order.total))
            .filter(*_closed(d1, d2)).group_by(Order.business_date).order_by(Order.business_date).all())
    refunds = defaultdict(int)
    for d, _m, amount in refunds_in_range(db, d1, d2):
        refunds[d] += amount
    # A refund can happen on a day that has no bill of its own (the sale was another day, or the shop only handed
    # money back that day). Building the ledger from the bills alone silently DROPPED those refund days, so the
    # «بازپرداخت» column and the range total disagreed with the sales report and the P&L (found in the D3 audit).
    by_day = {d: (c, g, dc, sv, t, r, tt) for d, c, g, dc, sv, t, r, tt in rows}
    for d in refunds:
        by_day.setdefault(d, (0, 0, 0, 0, 0, 0, 0))
    out = [{"date": d, "orders": c, "gross": int(g or 0), "discounts": int(dc or 0), "net_sales": int((g or 0) - (dc or 0)), "service": int(sv or 0),
            "tax": int(t or 0), "rounding": int(r or 0), "total": int(tt or 0), "refunds": refunds.get(d, 0)}
           for d, (c, g, dc, sv, t, r, tt) in sorted(by_day.items())]
    keys = ("orders", "gross", "discounts", "net_sales", "service", "tax", "rounding", "total", "refunds")
    return {"rows": out, "totals": {k: sum(r[k] for r in out) for k in keys},
            "tax_enabled": bool(settings_store.get(db, "tax.enabled", False)), "tax_percent": settings_store.get(db, "tax.percent", 0)}


# ---------------------------------------------------------------- customers
def customers(db: Session, d1: date, d2: date) -> dict:
    rows = (db.query(Order.customer_phone, Order.customer_name, Order.total, Order.business_date)
            .filter(*_closed(d1, d2), Order.customer_phone.isnot(None), Order.customer_phone != "").all())
    all_closed = db.query(func.count(Order.id)).filter(*_closed(d1, d2)).scalar() or 0
    per = defaultdict(lambda: {"name": None, "orders": 0, "spent": 0, "last": None})
    for phone, name, total, d in rows:
        p = per[phone]
        p["name"] = p["name"] or name
        p["orders"] += 1
        p["spent"] += total
        p["last"] = max(p["last"], d) if p["last"] else d
    phones = list(per)
    seen_before = set()
    for i in range(0, len(phones), 500):        # chunks keep the IN() list small
        chunk = phones[i:i + 500]
        seen_before |= {p for (p,) in db.query(Order.customer_phone).filter(Order.customer_phone.in_(chunk), Order.status == "closed",
                                                                          Order.business_date < d1).distinct().all()}
    new = [p for p in phones if p not in seen_before]
    spent = sum(v["spent"] for v in per.values())
    top = sorted([{"phone": k, **v} for k, v in per.items()], key=lambda x: -x["spent"])[:30]
    return {"summary": {"customers": len(per), "new": len(new), "returning": len(per) - len(new), "identified_orders": len(rows),
                        "identified_pct": _pct(len(rows), all_closed), "spent": spent,
                        "avg_per_customer": round(spent / len(per)) if per else 0,
                        "repeat_customers": sum(1 for v in per.values() if v["orders"] > 1)},
            "top": top}
