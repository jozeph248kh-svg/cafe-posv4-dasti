from app.core.modules import Module

from .router import router

module = Module(
    name="reports",
    title="گزارش‌ها",
    description="داشبورد لحظه‌ای، گزارش فروش، آیتم‌ها، ساعات اوج، پرسنل و خروجی اکسل",
    depends=["orders"],
    routers=[router],
    permissions={"reports.view": "مشاهده گزارش‌های فروش و مالی", "dashboard.view": "مشاهده داشبورد مدیریتی"},
)
