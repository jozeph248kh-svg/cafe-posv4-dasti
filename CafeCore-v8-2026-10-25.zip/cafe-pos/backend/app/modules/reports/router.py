import io
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.db import get_db
from app.core.deps import require
from app.core.privacy import PERM as PHONE_PERM
from app.core.privacy import mask_phone
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import business_day, jalali_str

from . import insights
from .service import dashboard_report, sales_report

router = APIRouter()
HEAD_FONT, HEAD_FILL = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="4F46E5")


def sheet(ws, title, headers, rows, widths):
    ws.title = title
    ws.sheet_view.rightToLeft = True
    ws.append(headers)
    for c in ws[1]:
        c.font, c.fill, c.alignment = HEAD_FONT, HEAD_FILL, Alignment(horizontal="center")
    for row in rows:
        ws.append(["" if v is None else v for v in row])
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            if isinstance(c.value, (int, float)):
                c.number_format = "#,##0.##" if isinstance(c.value, float) else "#,##0"
            elif c.data_type == "f":
                c.data_type = "s"          # user text like "=HYPERLINK(..)" must stay text, never a formula


def _xlsx(wb: Workbook, filename: str) -> StreamingResponse:
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{filename}"'})


def _dt(v) -> str:
    return jalali_str(v) + (f" {v:%H:%M}" if hasattr(v, "hour") else "") if v else ""


def _insights_xlsx(db: Session, d1: date, d2: date, mask_phones: bool = False) -> StreamingResponse:
    wb = Workbook()
    ds = insights.discounts(db, d1, d2)
    s = ds["summary"]
    sheet(wb.active, "تخفیف‌ها", ["شاخص", "مقدار"], [
        ["از تاریخ", jalali_str(d1)], ["تا تاریخ", jalali_str(d2)], ["جمع تخفیف (تومان)", s["total"]], ["درصد از فروش ناخالص", s["pct_of_gross"]],
        ["تعداد فاکتور با تخفیف", s["orders"]], ["درصد فاکتورها", s["orders_pct"]], ["میانگین تخفیف (تومان)", s["avg_discount"]],
        ["تخفیف اقلام (تومان)", s["items_discount"]], ["رایگان/کامل (تومان)", s["comps"]], ["با تأیید مدیر (مورد)", s["approved_count"]],
    ], [26, 20])
    sheet(wb.create_sheet(), "تخفیف بر اساس دلیل", ["دلیل / تخفیف آماده", "تعداد", "مبلغ (تومان)", "سهم ٪"],
          [[r["reason"], r["count"], r["amount"], r["share"]] for r in ds["by_reason"]], [30, 10, 16, 10])
    sheet(wb.create_sheet(), "تخفیف بر اساس کاربر", ["کاربر", "تعداد", "مبلغ (تومان)", "با تأیید مدیر"],
          [[r["user"], r["count"], r["amount"], r["approved"]] for r in ds["by_user"]], [26, 10, 16, 14])
    sheet(wb.create_sheet(), "فاکتورهای با تخفیف", ["سفارش", "تاریخ", "جمع اقلام", "تخفیف", "٪", "دلیل", "اعمال‌کننده", "تأییدکننده"],
          [[o["number"], jalali_str(o["date"]), o["subtotal"], o["discount"], o["pct"], o["reason"], o["by"], o["approver"]] for o in ds["orders"]],
          [10, 12, 14, 14, 8, 30, 18, 18])
    st = insights.staff(db, d1, d2)
    sheet(wb.create_sheet(), "عملکرد پرسنل", ["نام", "سفارش", "فروش (تومان)", "میانگین فاکتور", "آیتم در هر سفارش", "مهمان", "تخفیف داده‌شده", "٪ تخفیف", "حذف آیتم", "مبلغ حذف"],
          [[r["name"], r["orders"], r["revenue"], r["avg_check"], r["items_per_order"], r["guests"], r["discounts"], r["discount_pct"], r["voids"], r["void_amount"]]
           for r in st["rows"]], [22, 10, 16, 14, 14, 10, 16, 10, 10, 14])
    sh = insights.shifts(db, d1, d2)
    if sh.get("available"):
        sheet(wb.create_sheet(), "مغایرت صندوق", ["باز شده", "بسته شده", "بازکننده", "بستن توسط", "موجودی اول", "مورد انتظار", "شمارش‌شده", "مغایرت", "فروش", "توضیح"],
              [[_dt(r["opened_at"]), _dt(r["closed_at"]), r["opened_by"], r["closed_by"], r["opening_cash"], r["expected"], r["counted"], r["difference"], r["sales"], r["note"]]
               for r in sh["rows"]], [18, 18, 16, 16, 14, 14, 14, 12, 14, 30])
    mn = insights.menu(db, d1, d2)
    sheet(wb.create_sheet(), "مهندسی منو", ["آیتم", "دسته", "تعداد", "سهم فروش ٪", "فروش (تومان)", "بهای واحد", "حاشیه سود واحد", "حاشیه کل", "گروه"],
          [[r["name"], r["category"], r["qty"], r["mix_pct"], r["revenue"], r["unit_cost"], r["cm"], r["total_cm"], r["class_label"]] for r in mn["rows"]],
          [28, 16, 10, 12, 16, 14, 14, 16, 12])
    sheet(wb.create_sheet(), "آیتم‌های بدون فروش", ["آیتم", "دسته", "قیمت"], [[r["name"], r["category"], r["price"]] for r in mn["unsold"]], [28, 18, 14])
    md = insights.modifiers(db, d1, d2)
    sheet(wb.create_sheet(), "افزودنی‌ها", ["افزودنی", "تعداد", "فروش (تومان)", "بیشتر روی"], [[r["name"], r["count"], r["revenue"], r["top_items"]] for r in md["rows"]], [24, 10, 16, 40])
    tb = insights.tables(db, d1, d2)
    if tb.get("available"):
        sheet(wb.create_sheet(), "میزها", ["میز", "سالن", "ظرفیت", "سفارش", "مهمان", "فروش (تومان)", "میانگین مدت (دقیقه)", "سرانه مهمان", "گردش روزانه"],
              [[r["name"], r["area"], r["seats"], r["orders"], r["guests"], r["revenue"], r["avg_minutes"], r["per_guest"], r["turns_per_day"]] for r in tb["rows"]],
              [10, 16, 8, 10, 10, 16, 16, 14, 12])
    kt = insights.kitchen(db, d1, d2)
    if kt.get("available"):
        sheet(wb.create_sheet(), "سرعت آشپزخانه", ["ایستگاه / آیتم", "تعداد", "میانگین (دقیقه)", "۹۰٪ زیر (دقیقه)", f"٪ دیرتر از {kt['late_minutes']} دقیقه"],
              [[r["station"], r["count"], r["avg"], r["p90"], r["late_pct"]] for r in kt["by_station"]] + [[""] * 5]
              + [[r["name"], r["count"], r["avg"], r["p90"], r["late_pct"]] for r in kt["by_item"]], [26, 10, 14, 14, 16])
    tx = insights.tax(db, d1, d2)
    sheet(wb.create_sheet(), "دفتر مالیات", ["تاریخ", "سفارش", "فروش ناخالص", "تخفیف", "فروش خالص", "سرویس", "مالیات", "رُند", "جمع دریافتی", "بازپرداخت"],
          [[jalali_str(r["date"]), r["orders"], r["gross"], r["discounts"], r["net_sales"], r["service"], r["tax"], r["rounding"], r["total"], r["refunds"]] for r in tx["rows"]]
          + [["جمع", *[tx["totals"][k] for k in ("orders", "gross", "discounts", "net_sales", "service", "tax", "rounding", "total", "refunds")]]],
          [12, 10, 16, 14, 16, 14, 14, 10, 16, 14])
    cu = insights.customers(db, d1, d2)
    sheet(wb.create_sheet(), "مشتریان برتر", ["نام", "موبایل", "سفارش", "خرید (تومان)", "آخرین خرید"],
          [[r["name"], mask_phone(r["phone"]) if mask_phones else r["phone"], r["orders"], r["spent"], jalali_str(r["last"])] for r in cu["top"]], [22, 16, 10, 16, 14])
    return _xlsx(wb, f"reports-{d1}-{d2}.xlsx")


def _range(date_from: date | None, date_to: date | None, db: Session) -> tuple[date, date]:
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    d2 = date_to or today
    d1 = date_from or d2
    if d1 > d2:
        raise AppError("تاریخ شروع بعد از تاریخ پایان است")
    if (d2 - d1).days > 366:
        raise AppError("بازه گزارش حداکثر یک سال است")
    return d1, d2


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _: User = Depends(require("dashboard.view"))):
    # one pass of SQL aggregates instead of computing the whole sales report three times (see dashboard_report)
    today = business_day(cutoff_hour=settings_store.get(db, "day.cutoff_hour", 5))
    return dashboard_report(db, today)


@router.get("/sales")
def sales(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
          _: User = Depends(require("reports.view"))):
    d1, d2 = _range(date_from, date_to, db)
    return sales_report(db, d1, d2)


@router.get("/insights/compare")
def insights_compare(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                     _: User = Depends(require("reports.view"))):
    d1, d2 = _range(date_from, date_to, db)
    return insights.compare(db, d1, d2)


@router.get("/insights/z")
def insights_z(day: date | None = None, db: Session = Depends(get_db), _: User = Depends(require("reports.view"))):
    d1, _d2 = _range(day, day, db)
    return insights.z_report(db, d1)


@router.get("/insights/export")
def insights_export(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                    user: User = Depends(require("reports.view"))):
    d1, d2 = _range(date_from, date_to, db)
    return _insights_xlsx(db, d1, d2, mask_phones=not user.can(PHONE_PERM))     # files bypass the JSON masking


@router.get("/insights/{section}")
def insights_section(section: str, date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
                     _: User = Depends(require("reports.view"))):
    if section not in insights.SECTIONS:
        raise AppError("گزارش یافت نشد", 404, "not_found")
    d1, d2 = _range(date_from, date_to, db)
    return {"range": {"from": d1, "to": d2}, **getattr(insights, section)(db, d1, d2)}


@router.get("/sales/export")
def export(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db),
           _: User = Depends(require("reports.view"))):
    d1, d2 = _range(date_from, date_to, db)
    r = sales_report(db, d1, d2)
    wb = Workbook()

    s = r["summary"]
    sheet(wb.active, "خلاصه", ["شاخص", "مقدار"], [
        ["از تاریخ", jalali_str(d1)], ["تا تاریخ", jalali_str(d2)], ["واحد مبالغ", "تومان"], ["تعداد سفارش", s["orders"]], ["فروش ناخالص", s["gross"]],
        ["تخفیف", s["discounts"]], ["سرویس", s["service"]], ["مالیات", s["tax"]],
        # one definition per indicator (docs/FINANCIALS.md): revenue is net of VAT, the takings include it
        ["درآمد خالص فروش (بدون مالیات)", s.get("net_revenue", s["net"] - s.get("tax", 0))],
        ["جمع دریافتی از مشتری (با مالیات)", s["net"]],
        ["بازپرداخت", s["refunds"]], ["میانگین فاکتور", s["avg_ticket"]], ["بهای تمام‌شده مواد (COGS تاریخی)", s["food_cost"]],
        ["درصد فودکاست", s["food_cost_pct"]], ["سفارش لغوشده", s["cancelled"]], ["آیتم حذف‌شده", s["voids"]],
    ], [24, 20])
    sheet(wb.create_sheet(), "فروش روزانه", ["تاریخ", "تاریخ میلادی", "سفارش", "فروش (تومان)"],
          [[jalali_str(date.fromisoformat(d["date"])), d["date"], d["orders"], d["revenue"]] for d in r["by_day"]], [14, 14, 10, 18])
    # "فروش" = what was charged after the item discount and the item's share of the bill discount
    sheet(wb.create_sheet(), "آیتم‌ها", ["آیتم", "دسته", "تعداد", "فروش (تومان)", "بهای تمام‌شده (تومان)", "سود (تومان)", "قیمت لیست", "تخفیف"],
          [[i["name"], i["category"], i["qty"], i["revenue"], i["cost"], i["profit"], i.get("gross", i["revenue"]),
            i.get("discount", 0)] for i in r["by_item"]], [30, 16, 10, 16, 16, 16, 16, 14])
    sheet(wb.create_sheet(), "دسته‌بندی", ["دسته", "تعداد", "فروش (تومان)"], [[c["name"], c["qty"], c["revenue"]] for c in r["by_category"]], [24, 10, 18])
    sheet(wb.create_sheet(), "پرداخت", ["روش", "مبلغ خالص پس از بازپرداخت (تومان)"], [[p["label"], p["amount"]] for p in r["by_payment"]], [18, 18])
    sheet(wb.create_sheet(), "پرسنل", ["نام", "سفارش", "فروش (تومان)"], [[w["name"], w["orders"], w["revenue"]] for w in r["by_waiter"]], [22, 10, 18])
    sheet(wb.create_sheet(), "حذفیات", ["سفارش", "تاریخ", "آیتم", "تعداد", "مبلغ (تومان)", "دلیل", "تأییدکننده"],
          [[v["order_number"], jalali_str(v["date"]), v["name"], v["qty"], v["amount"], v["reason"], v["by"]] for v in r["voids"]], [10, 12, 26, 8, 14, 30, 18])
    return _xlsx(wb, f"sales-{d1}-{d2}.xlsx")
