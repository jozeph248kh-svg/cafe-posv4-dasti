"""Management reports beyond the sales summary (the reports professional POS systems ship with).

The report sections themselves live in `insight_sections.py` and their shared helpers in
`insight_helpers.py`; this module keeps the cross-section reports (period comparison and the
end-of-day Z report) and re-exports everything, so `insights.<section>(db, d1, d2)` still works.

Each section is a separate function/endpoint so the UI only computes what the user opens:
* discounts      — by reason/preset, by employee and approver, by item; health vs gross (1–3% normal, >5% investigate)
* staff          — employee performance: orders, average check, items per check, discounts given, voids
* shifts         — cash reconciliation: expected vs counted (over/short) per shift and per cashier
* menu           — menu engineering (Kasavana–Smith): stars / plowhorses / puzzles / dogs + items that didn't sell
* modifiers      — add-ons sold and their revenue
* tables         — dine-in: revenue per table/area, average seated time, revenue per guest, turnover
* kitchen        — preparation speed per station and per item (average, 90th percentile, % late)
* tax            — daily VAT / service / discounts ledger
* customers      — new vs returning, top spenders (orders with a phone number)
* compare        — headline KPIs vs the previous period of the same length
* z              — end-of-day (Z) report for one business day
All amounts are integer toman; only CLOSED orders count as sales.
"""
from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.modules.orders.models import Order, OrderLine

from .insight_helpers import SECTIONS, _closed, _pct  # noqa: F401  (re-exported)
from .insight_sections import customers, discounts, kitchen, menu, modifiers, shifts, staff, tables, tax  # noqa: F401
from .service import PAY_LABEL, TYPE_LABEL, sales_report

# ---------------------------------------------------------------- previous-period comparison
def _kpis(db: Session, d1: date, d2: date) -> dict:
    c, g, dc, t, gu = (db.query(func.count(Order.id), func.sum(Order.subtotal), func.sum(Order.discount_amount), func.sum(Order.total),
                                func.sum(Order.guests)).filter(*_closed(d1, d2)).first())
    voids = (db.query(func.sum(OrderLine.qty * OrderLine.unit_price)).join(Order, Order.id == OrderLine.order_id)
             .filter(Order.business_date >= d1, Order.business_date <= d2, OrderLine.status == "void").scalar())
    c, g, dc, t = c or 0, int(g or 0), int(dc or 0), int(t or 0)
    return {"orders": c, "gross": g, "discounts": dc, "net": t, "avg_ticket": round(t / c) if c else 0, "guests": int(gu or 0),
            "discount_pct": _pct(dc, g, 2), "voids_amount": int(voids or 0)}


def compare(db: Session, d1: date, d2: date) -> dict:
    span = (d2 - d1).days + 1
    p2 = d1 - timedelta(days=1)
    p1 = p2 - timedelta(days=span - 1)
    cur, prev = _kpis(db, d1, d2), _kpis(db, p1, p2)
    change = {k: (round((cur[k] - prev[k]) * 100 / prev[k], 1) if prev[k] else None) for k in cur}
    return {"current": cur, "previous": prev, "change": change, "previous_range": {"from": p1, "to": p2}}


# ---------------------------------------------------------------- Z report
def z_report(db: Session, day: date) -> dict:
    r = sales_report(db, day, day)
    s = r["summary"]
    disc = discounts(db, day, day)
    sh = shifts(db, day, day)
    open_orders = db.query(func.count(Order.id)).filter(Order.business_date == day, Order.status == "open").scalar() or 0
    return {
        "day": day, "summary": s, "by_payment": [{**p, "label": PAY_LABEL.get(p["method"], p["method"])} for p in r["by_payment"]],
        "by_type": [{**t, "label": TYPE_LABEL.get(t["type"], t["type"])} for t in r["by_type"]],
        "top_items": r["by_item"][:5], "by_category": r["by_category"],
        "discounts": {"total": disc["summary"]["total"], "pct": disc["summary"]["pct_of_gross"], "orders": disc["summary"]["orders"],
                      "by_reason": disc["by_reason"][:5]},
        "voids": {"count": s["voids"], "amount": s["voids_amount"]},
        "shifts": sh.get("rows", []), "cash_difference": sh.get("summary", {}).get("net", 0),
        "open_orders": open_orders, "by_waiter": r["by_waiter"][:10],
    }


__all__ = ["SECTIONS", "discounts", "staff", "shifts", "menu", "modifiers", "tables", "kitchen", "tax",
           "customers", "compare", "z_report"]
