from datetime import date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin


class Channel(Base, TimestampMixin):
    """A third-party sales channel (SnappFood, Tapsi Food, …) with its commission and integration settings."""
    __tablename__ = "mk_channels"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(20), unique=True)            # snappfood | tapsifood | custom-…
    name: Mapped[str] = mapped_column(String(60))
    color: Mapped[str] = mapped_column(String(10), default="#ff3e6c")
    commission_pct: Mapped[float] = mapped_column(Float, default=0)
    settlement_days: Mapped[int] = mapped_column(Integer, default=7)
    auto_accept: Mapped[bool] = mapped_column(Boolean, default=False)
    prep_minutes: Mapped[int] = mapped_column(Integer, default=20)
    mode: Mapped[str] = mapped_column(String(10), default="test")          # test | live | manual
    config: Mapped[dict] = mapped_column(JSON, default=dict)               # vendor_code, api_base, api_key, status_url, webhook_secret
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class MarketOrder(Base, TimestampMixin):
    __tablename__ = "mk_orders"
    __table_args__ = (UniqueConstraint("channel_id", "external_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    channel_id: Mapped[int] = mapped_column(ForeignKey("mk_channels.id"), index=True)
    external_id: Mapped[str] = mapped_column(String(40))
    order_id: Mapped[int | None] = mapped_column(ForeignKey("orders.id"), index=True)
    status: Mapped[str] = mapped_column(String(12), default="new", index=True)   # new|accepted|picked|rejected|cancelled
    customer_name: Mapped[str | None] = mapped_column(String(80))
    phone: Mapped[str | None] = mapped_column(String(20))
    address: Mapped[str | None] = mapped_column(Text)
    note: Mapped[str | None] = mapped_column(Text)
    items: Mapped[list] = mapped_column(JSON, default=list)               # [{ext_id, name, qty, price, note, menu_item_id}]
    subtotal: Mapped[int] = mapped_column(Integer, default=0)             # food total at channel prices (toman)
    vendor_discount: Mapped[int] = mapped_column(Integer, default=0)      # discount paid by the restaurant
    channel_discount: Mapped[int] = mapped_column(Integer, default=0)     # discount paid by the marketplace (info)
    delivery_fee: Mapped[int] = mapped_column(Integer, default=0)
    commission: Mapped[int] = mapped_column(Integer, default=0)
    net: Mapped[int] = mapped_column(Integer, default=0)                  # receivable from the channel
    paid_online: Mapped[bool] = mapped_column(Boolean, default=True)
    settlement_id: Mapped[int | None] = mapped_column(ForeignKey("mk_settlements.id"), index=True)
    reject_reason: Mapped[str | None] = mapped_column(String(200))
    raw: Mapped[dict | None] = mapped_column(JSON)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime)
    picked_at: Mapped[datetime | None] = mapped_column(DateTime)
    handled_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    channel: Mapped[Channel] = relationship(lazy="joined")


class ItemMap(Base):
    """Remembers which menu item a marketplace product corresponds to."""
    __tablename__ = "mk_item_map"
    __table_args__ = (UniqueConstraint("channel_id", "ext_key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    channel_id: Mapped[int] = mapped_column(ForeignKey("mk_channels.id"), index=True)
    ext_key: Mapped[str] = mapped_column(String(120))
    ext_name: Mapped[str] = mapped_column(String(120))
    menu_item_id: Mapped[int] = mapped_column(ForeignKey("menu_items.id"))


class Settlement(Base, TimestampMixin):
    """Money received from the channel (bank transfer), reconciled against picked orders."""
    __tablename__ = "mk_settlements"
    id: Mapped[int] = mapped_column(primary_key=True)
    channel_id: Mapped[int] = mapped_column(ForeignKey("mk_channels.id"), index=True)
    amount: Mapped[int] = mapped_column(Integer)
    date: Mapped[date] = mapped_column(Date)
    reference: Mapped[str | None] = mapped_column(String(60))
    note: Mapped[str | None] = mapped_column(String(200))
    orders_count: Mapped[int] = mapped_column(Integer, default=0)
    expected: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
