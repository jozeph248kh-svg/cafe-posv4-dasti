from app.core.modules import Module
from app.core.permissions import grant_once

from .router import router


def seed(db) -> None:
    from .models import Channel
    grant_once(db, "marketplace", {"manager": ["market.orders", "market.manage"], "cashier": ["market.orders"]})
    if not db.query(Channel).count():
        import secrets
        db.add(Channel(key="snappfood", name="اسنپ‌فود", color="#ff3e6c", commission_pct=22, settlement_days=7, mode="test", prep_minutes=20,
                       config={"webhook_secret": secrets.token_urlsafe(24), "vendor_code": ""}))
        db.add(Channel(key="tapsifood", name="تپسی‌فود", color="#ff8a00", commission_pct=18, settlement_days=10, mode="manual", prep_minutes=20,
                       config={"webhook_secret": secrets.token_urlsafe(24)}))


def demo(db) -> None:
    """A few past marketplace orders so the channel reports are meaningful."""
    import random
    from datetime import timedelta

    from app.core.utils import now
    from app.modules.menu.models import MenuItem

    from . import service as S
    from .models import Channel, MarketOrder
    if db.query(MarketOrder).count():
        return
    rnd = random.Random(7)
    items = [m for m in db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.price > 0).all() if not (m.code or "").startswith("__")]
    t = now()
    for ch in db.query(Channel).all():
        for k in range(14 if ch.key == "snappfood" else 6):
            pick = rnd.sample(items, k=rnd.randint(1, 3))
            its = [{"ext_id": f"SF-{m.id}", "name": m.name, "qty": rnd.randint(1, 2), "price": m.price, "menu_item_id": m.id} for m in pick]
            sub = sum(i["price"] * i["qty"] for i in its)
            when = t - timedelta(days=rnd.randint(1, 20), hours=rnd.randint(0, 8))
            mo = MarketOrder(channel_id=ch.id, external_id=f"{rnd.randint(10**7, 10**8 - 1)}", status="picked" if k % 7 else "rejected", items=its, subtotal=sub,
                             vendor_discount=0 if k % 3 else round(sub * 0.1 / 1000) * 1000, customer_name=rnd.choice(["آرش", "نگار", "مهدی", "سمیرا"]),
                             accepted_at=when, picked_at=when + timedelta(minutes=25), reject_reason=None if k % 7 else "اتمام موجودی")
            mo.channel = ch
            S.calc(ch, mo)
            db.add(mo)
            db.flush()
            mo.created_at = when


module = Module(
    name="marketplace",
    title="کانال‌های فروش (اسنپ‌فود)",
    description="دریافت سفارش اسنپ‌فود و سایر کانال‌ها (وب‌هوک امن یا ثبت سریع)، کمیسیون، مطالبات و تسویه",
    depends=["orders", "menu"],
    routers=[router],
    permissions={"market.orders": "پذیرش سفارش کانال‌های فروش", "market.manage": "تنظیم کانال‌های فروش و تسویه"},
    seed=seed,
    demo=demo,
)
