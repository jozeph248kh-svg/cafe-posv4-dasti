"""Marketplace orders: ingest → (map items) → accept → kitchen → picked by courier (paid, closed) → settled.

SnappFood's vendor API is private (available after signing a contract), so the integration is split in two:
  * inbound: a signed webhook that accepts our normalized JSON (see normalize()). An adapter on the vendor
    side, or SnappFood's own push once enabled, posts orders here;
  * outbound: status updates (accept / reject / ready) go through push_status(), which logs them in test mode and
    POSTs them to the configured endpoint in live mode.
Only the keys and endpoint addresses need filling in once the contract is signed.
"""
import hashlib
import hmac
import json
import logging
import random
from datetime import date

import httpx
from sqlalchemy.orm import Session

from app.core.audit import log_action
from app.core.errors import AppError
from app.core.models import User
from app.core.realtime import call_after_commit, publish_after_commit
from app.core.utils import normalize_phone, now

from .models import Channel, ItemMap, MarketOrder, Settlement

log = logging.getLogger("marketplace")


def system_user(db: Session) -> User:
    from app.core.models import Role
    return db.query(User).join(Role, Role.id == User.role_id).filter(Role.name == "admin").first() or db.query(User).first()


def sign(secret: str, body: bytes) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def verify(secret: str, body: bytes, signature: str | None) -> bool:
    return bool(signature) and hmac.compare_digest(sign(secret, body), signature.lower().removeprefix("sha256="))


def _int(v) -> int:
    try:
        return int(float(v or 0))
    except (TypeError, ValueError):
        return 0


def normalize(payload: dict, rial: bool = False) -> dict:
    """Accepts our documented schema and tolerates common alternative key names."""
    g = lambda *ks, d=None: next((payload[k] for k in ks if payload.get(k) not in (None, "")), d)  # noqa: E731
    f = 0.1 if rial else 1
    items = []
    for it in g("items", "products", "orderItems", d=[]) or []:
        items.append({"ext_id": str(it.get("id") or it.get("productId") or it.get("code") or ""), "name": str(it.get("name") or it.get("title") or "").strip(),
                      "qty": max(1, _int(it.get("qty") or it.get("quantity") or it.get("count") or 1)), "price": round(_int(it.get("price") or it.get("unitPrice")) * f),
                      "note": it.get("note") or it.get("description") or None})
    if not items:
        raise AppError("سفارش بدون قلم است", code="no_items")
    sub = sum(i["price"] * i["qty"] for i in items)
    cust = g("customer", d={}) or {}
    return {
        "external_id": str(g("id", "orderId", "orderCode", "code") or "").strip() or None,
        "customer_name": g("customer_name", "customerName") or cust.get("name"), "phone": normalize_phone(g("phone", "customerPhone") or cust.get("phone")),
        "address": g("address") or cust.get("address"), "note": g("note", "description", "comment"), "items": items,
        "subtotal": round(_int(g("subtotal", "itemsPrice")) * f) or sub, "vendor_discount": round(_int(g("vendor_discount", "vendorDiscount")) * f),
        "channel_discount": round(_int(g("channel_discount", "marketplaceDiscount", "snappDiscount")) * f), "delivery_fee": round(_int(g("delivery_fee", "deliveryFee")) * f),
        "paid_online": str(g("payment", "paymentType", d="online")).lower() not in ("cash", "cod"),
    }


def match_items(db: Session, ch: Channel, items: list[dict]) -> list[dict]:
    from app.modules.menu.models import MenuItem
    maps = {m.ext_key: m.menu_item_id for m in db.query(ItemMap).filter(ItemMap.channel_id == ch.id)}
    by_name = {m.name.strip(): m.id for m in db.query(MenuItem).filter(MenuItem.is_active.is_(True))}
    for it in items:
        it["menu_item_id"] = it.get("menu_item_id") or maps.get(it["ext_id"] or it["name"]) or maps.get(it["name"]) or by_name.get(it["name"])
    return items


def calc(ch: Channel, mo: MarketOrder) -> None:
    base = max(mo.subtotal - mo.vendor_discount, 0)
    mo.commission = round(base * (ch.commission_pct or 0) / 100)
    mo.net = base - mo.commission


def ingest(db: Session, ch: Channel, data: dict, user: User | None = None) -> MarketOrder:
    if not ch.is_active:
        raise AppError("این کانال غیرفعال است", 409)
    ext = data.get("external_id") or f"M{now():%H%M%S}{random.randint(10, 99)}"
    old = db.query(MarketOrder).filter(MarketOrder.channel_id == ch.id, MarketOrder.external_id == ext).first()
    if old:
        return old                          # idempotent: marketplaces retry webhooks
    mo = MarketOrder(channel_id=ch.id, external_id=ext, status="new", items=match_items(db, ch, data["items"]),
                     **{k: data.get(k) for k in ("customer_name", "phone", "address", "note", "subtotal", "vendor_discount", "channel_discount", "delivery_fee", "paid_online")},
                     raw=data.get("raw"))
    mo.channel = ch
    calc(ch, mo)
    db.add(mo)
    db.flush()
    publish_after_commit(db, "market.new", {"id": mo.id, "channel": ch.name, "number": ext})
    if ch.auto_accept and all(i.get("menu_item_id") for i in mo.items):
        accept(db, mo, user or system_user(db))
    return mo


def _post_status(url: str, body: bytes, headers: dict) -> None:
    try:
        httpx.post(url, content=body, timeout=10, headers=headers).raise_for_status()
    except httpx.HTTPError as e:
        log.warning("marketplace status push failed: %s", e)


def push_status(db: Session, mo: MarketOrder, status: str, **extra) -> None:
    ch = mo.channel
    out = {"external_id": mo.external_id, "status": status, "at": now().isoformat(timespec="seconds"), **extra}
    if ch.mode == "live" and (ch.config or {}).get("status_url"):
        body = json.dumps(out, ensure_ascii=False).encode()
        headers = {"Content-Type": "application/json", "X-Signature": sign(ch.config.get("webhook_secret") or "", body),
                   "Authorization": f"Bearer {ch.config.get('api_key', '')}"}
        call_after_commit(db, _post_status, ch.config["status_url"], body, headers)   # never inside the DB transaction
        out["queued"] = True
    raw = dict(mo.raw or {})
    raw["_outbound"] = [*(raw.get("_outbound") or []), out][-10:]
    mo.raw = raw


def _menu_name(db: Session, mid: int) -> str | None:
    from app.modules.menu.models import MenuItem
    m = db.get(MenuItem, mid)
    return m.name if m else None


def _default_mods(db: Session, mid: int) -> list[int]:
    """Marketplaces don't send our modifier choices: pick the default option(s) for required groups."""
    from app.modules.menu.models import MenuItem
    item = db.get(MenuItem, mid)
    ids: list[int] = []
    for g in (item.modifier_groups if item else []):
        if g.min_select > 0:
            opts = sorted([o for o in g.options if o.is_available], key=lambda o: (not o.is_default, o.sort, o.id))
            ids += [o.id for o in opts[:g.min_select]]
    return ids


def accept(db: Session, mo: MarketOrder, user: User, prep: int | None = None) -> None:
    from app.modules.orders import service as osvc
    from app.modules.orders.schemas import LineIn, OrderCreate
    if mo.status != "new":
        raise AppError("این سفارش قبلاً بررسی شده است")
    missing = [i["name"] for i in mo.items if not i.get("menu_item_id")]
    if missing:
        raise AppError(f"این اقلام هنوز به منو وصل نشده‌اند: {'، '.join(missing)}", code="unmapped")
    ch = mo.channel
    lines = [LineIn(menu_item_id=i["menu_item_id"], qty=i["qty"], modifier_option_ids=_default_mods(db, i["menu_item_id"]),
                    note=" — ".join(x for x in [i["name"] if _menu_name(db, i["menu_item_id"]) != i["name"] else None, i.get("note")] if x) or None)
             for i in mo.items]
    o = osvc.create_order(db, OrderCreate(type="takeaway", customer_name=mo.customer_name or ch.name, customer_phone=mo.phone,
                                          note=f"{ch.name} — کد {mo.external_id}" + (f" — {mo.note}" if mo.note else ""), lines=lines, send=True), user)
    o.source = ch.key[:10]
    if mo.vendor_discount:
        o.discount_type, o.discount_value, o.discount_reason = "amount", mo.vendor_discount, f"تخفیف {ch.name}"
        osvc.recalc(db, o)
    mo.status, mo.order_id, mo.accepted_at, mo.handled_by = "accepted", o.id, now(), user.id
    push_status(db, mo, "accepted", prep_minutes=prep or ch.prep_minutes)
    log_action(db, user, "market.accept", f"تأیید سفارش {ch.name} {mo.external_id} — سفارش #{o.number}", entity="order", entity_id=o.id)
    publish_after_commit(db, "market.changed", {"id": mo.id, "status": "accepted"})


def reject(db: Session, mo: MarketOrder, reason: str, user: User) -> None:
    if mo.status != "new":
        raise AppError("فقط سفارش‌های جدید قابل رد هستند")
    mo.status, mo.reject_reason, mo.handled_by = "rejected", reason, user.id
    push_status(db, mo, "rejected", reason=reason)
    log_action(db, user, "market.reject", f"رد سفارش {mo.channel.name} {mo.external_id}: {reason}")
    publish_after_commit(db, "market.changed", {"id": mo.id, "status": "rejected"})


def picked(db: Session, mo: MarketOrder, user: User) -> None:
    """Courier took the order: the channel owes us → record an 'online' payment and close the order."""
    from app.modules.orders import service as osvc
    from app.modules.orders.models import Order
    from app.modules.orders.schemas import PaymentIn
    if mo.status != "accepted":
        raise AppError("سفارش در وضعیت تحویل به پیک نیست")
    o = db.get(Order, mo.order_id)
    if o and o.status == "open":
        osvc.recalc(db, o)
        if o.remaining > 0:
            osvc.add_payments(db, o, [PaymentIn(method="online", amount=o.remaining, reference=f"{mo.channel.key}:{mo.external_id}")], user)
    mo.status, mo.picked_at = "picked", now()
    push_status(db, mo, "picked")
    publish_after_commit(db, "market.changed", {"id": mo.id, "status": "picked"})


def cancel_by_channel(db: Session, mo: MarketOrder, reason: str) -> None:
    from app.modules.orders import service as osvc
    from app.modules.orders.models import Order
    if mo.status in ("cancelled", "rejected"):
        return
    u = system_user(db)
    o = db.get(Order, mo.order_id) if mo.order_id else None
    if o and o.status == "open":
        osvc.cancel_order(db, o, f"لغو توسط {mo.channel.name}: {reason}", u, u)
    mo.status, mo.reject_reason = "cancelled", reason
    publish_after_commit(db, "market.changed", {"id": mo.id, "status": "cancelled"})


def settle(db: Session, ch: Channel, amount: int, day: date, reference: str | None, note: str | None, user: User) -> Settlement:
    """Apply a payment from the channel to its oldest unsettled picked orders; book the commission as an expense."""
    rows = (db.query(MarketOrder).filter(MarketOrder.channel_id == ch.id, MarketOrder.status == "picked", MarketOrder.settlement_id.is_(None))
            .order_by(MarketOrder.picked_at).all())
    s = Settlement(channel_id=ch.id, amount=amount, date=day, reference=reference, note=note, created_by=user.id)
    db.add(s)
    db.flush()
    covered, expected, commission = 0, 0, 0
    for mo in rows:
        if expected + mo.net > amount * 1.02 + 1000:      # stop when the transfer is used up (2% tolerance)
            break
        mo.settlement_id = s.id
        expected += mo.net
        commission += mo.commission
        covered += 1
    s.orders_count, s.expected = covered, expected
    if commission:
        try:
            from app.modules.expenses.models import Expense, ExpenseCategory
            cat = db.query(ExpenseCategory).filter(ExpenseCategory.name == "کمیسیون کانال‌های فروش").first()
            if not cat:
                cat = ExpenseCategory(name="کمیسیون کانال‌های فروش", icon="🛵", color="#ff3e6c", sort=90)
                db.add(cat)
                db.flush()
            db.add(Expense(category_id=cat.id, expense_date=day, amount=commission, method="transfer", payee=ch.name,
                           note=f"کمیسیون {covered} سفارش — تسویه {reference or s.id}", created_by=user.id))
        except ImportError:
            pass
    log_action(db, user, "market.settle", f"تسویه {ch.name}: {amount:,} تومان ({covered} سفارش)", entity="mk_settlement", entity_id=s.id)
    return s


def simulate_payload(db: Session, ch: Channel) -> dict:
    from app.modules.menu.models import MenuItem
    items = [m for m in db.query(MenuItem).filter(MenuItem.is_active.is_(True), MenuItem.price > 0).all() if not (m.code or "").startswith("__")]
    pick = random.sample(items, k=min(len(items), random.randint(1, 3)))
    names = ["آرش محمدی", "نگار رضایی", "مهدی کریمی", "سمیرا احمدی", "پویا نوری"]
    lines = [{"id": f"SF-{m.id}", "name": m.name, "qty": random.randint(1, 2), "price": m.price} for m in pick]
    if random.random() < 0.25:
        lines.append({"id": "SF-X99", "name": "پک ویژه اسنپ (نیاز به نگاشت)", "qty": 1, "price": 180000})
    sub = sum(x["price"] * x["qty"] for x in lines)
    return {"id": f"{random.randint(10**7, 10**8 - 1)}", "customer": {"name": random.choice(names), "phone": f"0912{random.randint(1000000, 9999999)}",
            "address": "تهران، " + random.choice(["سعادت‌آباد", "پونک", "ونک", "نارمک", "تجریش"])},
            "items": lines, "subtotal": sub, "vendor_discount": random.choice([0, 0, round(sub * 0.1 / 1000) * 1000]),
            "channel_discount": random.choice([0, 30000]), "delivery_fee": random.choice([25000, 35000]), "payment": "online"}
