import json
import secrets
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import business_day, day_bounds, now

from . import service as S
from .models import Channel, ItemMap, MarketOrder, Settlement

router = APIRouter()
staff = require("market.orders")
manage = require("market.manage")


class ChannelIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    key: str | None = Field(None, pattern="^[a-z0-9_-]{2,20}$")
    color: str = "#ff3e6c"
    commission_pct: float = Field(0, ge=0, le=60)
    settlement_days: int = Field(7, ge=0, le=90)
    auto_accept: bool = False
    prep_minutes: int = Field(20, ge=5, le=180)
    mode: str = Field("test", pattern="^(test|live|manual)$")
    config: dict = {}
    is_active: bool = True


class ManualItem(BaseModel):
    menu_item_id: int
    qty: int = Field(1, ge=1, le=99)
    price: int | None = None


class ManualIn(BaseModel):
    channel_id: int
    external_id: str | None = Field(None, max_length=40)
    customer_name: str | None = None
    phone: str | None = None
    note: str | None = None
    items: list[ManualItem] = Field(min_length=1)
    subtotal: int | None = None
    vendor_discount: int = 0
    accept: bool = True


class RejectIn(BaseModel):
    reason: str = Field(min_length=2, max_length=200)


class MapIn(BaseModel):
    maps: dict[int, int]           # item index → menu_item_id


class SettleIn(BaseModel):
    channel_id: int
    amount: int = Field(gt=0)
    date: date
    reference: str | None = None
    note: str | None = None


def cout(c: Channel, full: bool = False) -> dict:
    cfg = dict(c.config or {})
    if not full:
        cfg = {k: v for k, v in cfg.items() if k not in ("api_key", "webhook_secret")}
    return {"id": c.id, "key": c.key, "name": c.name, "color": c.color, "commission_pct": c.commission_pct, "settlement_days": c.settlement_days,
            "auto_accept": c.auto_accept, "prep_minutes": c.prep_minutes, "mode": c.mode, "config": cfg, "is_active": c.is_active,
            "webhook_path": f"/api/marketplace/webhook/{c.key}"}


def mout(m: MarketOrder) -> dict:
    return {"id": m.id, "channel_id": m.channel_id, "channel": m.channel.name, "color": m.channel.color, "external_id": m.external_id, "order_id": m.order_id,
            "status": m.status, "customer_name": m.customer_name, "phone": m.phone, "address": m.address, "note": m.note, "items": m.items,
            "subtotal": m.subtotal, "vendor_discount": m.vendor_discount, "channel_discount": m.channel_discount, "delivery_fee": m.delivery_fee,
            "commission": m.commission, "net": m.net, "paid_online": m.paid_online, "settled": bool(m.settlement_id), "reject_reason": m.reject_reason,
            "created_at": m.created_at, "accepted_at": m.accepted_at, "picked_at": m.picked_at,
            "unmapped": sum(1 for i in m.items if not i.get("menu_item_id")), "outbound": (m.raw or {}).get("_outbound", [])[-3:]}


# ------------------------------------------------------------------ channels
@router.get("/channels")
def channels(db: Session = Depends(get_db), user: User = Depends(staff)):
    return [cout(c, user.can("market.manage")) for c in db.query(Channel).order_by(Channel.id)]


@router.post("/channels", status_code=201)
def create_channel(data: ChannelIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    key = data.key or f"ch{secrets.token_hex(3)}"
    if db.query(Channel).filter(Channel.key == key).first():
        raise AppError("این شناسه کانال تکراری است")
    c = Channel(**{**data.model_dump(), "key": key})
    c.config = {**(c.config or {}), "webhook_secret": (c.config or {}).get("webhook_secret") or secrets.token_urlsafe(24)}
    db.add(c)
    db.commit()
    return cout(c, True)


@router.put("/channels/{cid}")
def update_channel(cid: int, data: ChannelIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    c = get_or_404(db, Channel, cid, "کانال")
    for k, v in data.model_dump(exclude={"key"}).items():
        setattr(c, k, v)
    if not (c.config or {}).get("webhook_secret"):
        c.config = {**(c.config or {}), "webhook_secret": secrets.token_urlsafe(24)}
    log_action(db, user, "market.channel", f"تنظیمات کانال {c.name} (کمیسیون {c.commission_pct}٪، حالت {c.mode})")
    db.commit()
    return cout(c, True)


@router.post("/channels/{cid}/simulate")
def simulate(cid: int, db: Session = Depends(get_db), user: User = Depends(staff)):
    """Generate a realistic test order and push it through the real (signed) webhook pipeline."""
    c = get_or_404(db, Channel, cid, "کانال")
    if c.mode == "live":
        raise AppError("شبیه‌سازی فقط در حالت آزمایشی ممکن است")
    payload = S.simulate_payload(db, c)
    data = S.normalize(payload)
    data["raw"] = {"simulated": True}
    mo = S.ingest(db, c, data, user)
    db.commit()
    return mout(mo)


# ------------------------------------------------------------------ webhook (called by the marketplace / adapter)
@router.post("/webhook/{key}")
async def webhook(key: str, request: Request, x_signature: str | None = Header(None), db: Session = Depends(get_db)):
    c = db.query(Channel).filter(Channel.key == key).first()
    if not c or not c.is_active:
        raise AppError("کانال پیدا نشد", 404)
    body = await request.body()
    secret = (c.config or {}).get("webhook_secret") or ""
    if not S.verify(secret, body, x_signature):
        raise AppError("امضای درخواست نامعتبر است", 401, "bad_signature")
    try:
        payload = json.loads(body or b"{}")
    except ValueError as e:
        raise AppError("JSON نامعتبر") from e
    event = payload.get("event", "order.new")
    if event in ("order.cancelled", "order.cancel"):
        mo = db.query(MarketOrder).filter(MarketOrder.channel_id == c.id, MarketOrder.external_id == str(payload.get("id"))).first()
        if not mo:
            raise AppError("سفارش پیدا نشد", 404)
        S.cancel_by_channel(db, mo, payload.get("reason") or "لغو مشتری")
        db.commit()
        return {"ok": True, "status": mo.status}
    data = S.normalize(payload.get("order", payload), rial=bool((c.config or {}).get("amounts_in_rial")))
    data["raw"] = {"payload": payload}
    mo = S.ingest(db, c, data, None)
    db.commit()
    return {"ok": True, "id": mo.id, "status": mo.status}


# ------------------------------------------------------------------ orders
@router.get("/orders")
def orders(status: str | None = None, channel_id: int | None = None, active: bool = False, days: int = 1, db: Session = Depends(get_db), _: User = Depends(staff)):
    q = db.query(MarketOrder)
    if active:
        q = q.filter(MarketOrder.status.in_(["new", "accepted"]))
    else:
        q = q.filter(MarketOrder.created_at >= now() - timedelta(days=days))
    if status:
        q = q.filter(MarketOrder.status == status)
    if channel_id:
        q = q.filter(MarketOrder.channel_id == channel_id)
    return [mout(m) for m in q.order_by(MarketOrder.id.desc()).limit(300)]


@router.post("/orders/manual", status_code=201)
def manual(data: ManualIn, db: Session = Depends(get_db), user: User = Depends(staff)):
    """Quick entry for channels without API: cashier copies the order from the marketplace tablet."""
    from app.modules.menu.models import MenuItem
    c = get_or_404(db, Channel, data.channel_id, "کانال")
    items = []
    for it in data.items:
        m = get_or_404(db, MenuItem, it.menu_item_id, "کالا")
        items.append({"ext_id": f"m{m.id}", "name": m.name, "qty": it.qty, "price": it.price if it.price is not None else m.price, "menu_item_id": m.id})
    sub = data.subtotal or sum(i["price"] * i["qty"] for i in items)
    mo = S.ingest(db, c, {"external_id": data.external_id, "customer_name": data.customer_name, "phone": data.phone, "note": data.note, "items": items,
                          "subtotal": sub, "vendor_discount": data.vendor_discount, "channel_discount": 0, "delivery_fee": 0, "paid_online": True}, user)
    if data.accept and mo.status == "new":
        S.accept(db, mo, user)
    db.commit()
    return mout(mo)


@router.post("/orders/{mid}/map")
def map_items(mid: int, data: MapIn, db: Session = Depends(get_db), user: User = Depends(staff)):
    mo = get_or_404(db, MarketOrder, mid, "سفارش")
    items = [dict(i) for i in mo.items]
    for idx, menu_id in data.maps.items():
        if 0 <= idx < len(items):
            it = items[idx]
            it["menu_item_id"] = menu_id
            key = it["ext_id"] or it["name"]
            m = db.query(ItemMap).filter(ItemMap.channel_id == mo.channel_id, ItemMap.ext_key == key).first()
            if m:
                m.menu_item_id = menu_id
            else:
                db.add(ItemMap(channel_id=mo.channel_id, ext_key=key, ext_name=it["name"], menu_item_id=menu_id))
    mo.items = items
    db.commit()
    return mout(mo)


@router.post("/orders/{mid}/accept")
def accept(mid: int, prep: int | None = None, db: Session = Depends(get_db), user: User = Depends(staff)):
    mo = get_or_404(db, MarketOrder, mid, "سفارش")
    S.accept(db, mo, user, prep)
    db.commit()
    return mout(mo)


@router.post("/orders/{mid}/reject")
def reject(mid: int, data: RejectIn, db: Session = Depends(get_db), user: User = Depends(staff)):
    mo = get_or_404(db, MarketOrder, mid, "سفارش")
    S.reject(db, mo, data.reason, user)
    db.commit()
    return mout(mo)


@router.post("/orders/{mid}/picked")
def picked(mid: int, db: Session = Depends(get_db), user: User = Depends(require("market.orders", "payments.take"))):
    mo = get_or_404(db, MarketOrder, mid, "سفارش")
    S.picked(db, mo, user)
    db.commit()
    return mout(mo)


@router.get("/maps")
def maps(db: Session = Depends(get_db), _: User = Depends(manage)):
    from app.modules.menu.models import MenuItem
    names = dict(db.query(MenuItem.id, MenuItem.name).all())
    return [{"id": m.id, "channel_id": m.channel_id, "ext_key": m.ext_key, "ext_name": m.ext_name, "menu_item_id": m.menu_item_id, "menu_name": names.get(m.menu_item_id)}
            for m in db.query(ItemMap).order_by(ItemMap.id.desc())]


@router.delete("/maps/{mid}")
def del_map(mid: int, db: Session = Depends(get_db), _: User = Depends(manage)):
    db.delete(get_or_404(db, ItemMap, mid, "نگاشت"))
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ finance
@router.get("/report")
def report(date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), _: User = Depends(require("finance.view"))):
    cutoff = settings_store.get(db, "day.cutoff_hour", 5)      # same business day as the sales reports
    today = business_day(cutoff_hour=cutoff)
    d1, d2 = date_from or (today - timedelta(days=29)), date_to or today
    start, _e = day_bounds(d1, cutoff)
    _s, end = day_bounds(d2, cutoff)
    out = []
    for c in db.query(Channel).order_by(Channel.id):
        base = db.query(MarketOrder).filter(MarketOrder.channel_id == c.id)
        period = base.filter(MarketOrder.created_at >= start, MarketOrder.created_at < end)
        done = period.filter(MarketOrder.status == "picked")
        agg = done.with_entities(func.count(), func.coalesce(func.sum(MarketOrder.subtotal), 0), func.coalesce(func.sum(MarketOrder.vendor_discount), 0),
                                 func.coalesce(func.sum(MarketOrder.commission), 0), func.coalesce(func.sum(MarketOrder.net), 0)).one()
        outstanding = base.filter(MarketOrder.status == "picked", MarketOrder.settlement_id.is_(None))
        oagg = outstanding.with_entities(func.count(), func.coalesce(func.sum(MarketOrder.net), 0), func.min(MarketOrder.picked_at)).one()
        overdue = bool(oagg[2] and (now() - oagg[2]).days > c.settlement_days)
        out.append({"channel": cout(c), "orders": agg[0], "gross": int(agg[1]), "vendor_discount": int(agg[2]), "commission": int(agg[3]), "net": int(agg[4]),
                    "rejected": period.filter(MarketOrder.status.in_(["rejected", "cancelled"])).count(),
                    "outstanding_count": oagg[0], "outstanding": int(oagg[1]), "oldest_unsettled": oagg[2], "overdue": overdue,
                    "settled": int(db.query(func.coalesce(func.sum(Settlement.amount), 0)).filter(Settlement.channel_id == c.id, Settlement.date >= d1, Settlement.date <= d2).scalar())})
    sets = db.query(Settlement).order_by(Settlement.date.desc(), Settlement.id.desc()).limit(30).all()
    return {"from": d1, "to": d2, "channels": out,
            "settlements": [{"id": s.id, "channel_id": s.channel_id, "amount": s.amount, "date": s.date, "reference": s.reference, "note": s.note,
                             "orders_count": s.orders_count, "expected": s.expected} for s in sets]}


@router.post("/settlements", status_code=201)
def settle(data: SettleIn, db: Session = Depends(get_db), user: User = Depends(require("finance.view", "market.manage"))):
    c = get_or_404(db, Channel, data.channel_id, "کانال")
    s = S.settle(db, c, data.amount, data.date, data.reference, data.note, user)
    db.commit()
    return {"id": s.id, "orders_count": s.orders_count, "expected": s.expected, "diff": s.amount - s.expected}
