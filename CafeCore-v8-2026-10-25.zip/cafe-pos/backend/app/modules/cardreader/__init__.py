from app.core import events, settings_store
from app.core.modules import Module

from .router import router

settings_store.register_defaults({"cardreader.rial_factor": 10})


def _link(db, payment, order, **_):
    """When a card payment carries the reader's RRN, attach the card transaction to it (reconciliation)."""
    if payment.method != "card" or not payment.reference:
        return
    from .models import CardTxn
    x = (db.query(CardTxn).filter(CardTxn.rrn == payment.reference.strip(), CardTxn.status == "approved", CardTxn.payment_id.is_(None))
         .order_by(CardTxn.id.desc()).first())
    if x:
        x.payment, x.order_id = payment, order.id


def setup() -> None:
    events.subscribe("payment.creating", _link)


def demo(db) -> None:
    from .models import PosTerminal
    if not db.query(PosTerminal).count():
        db.add(PosTerminal(name="کارتخوان صندوق ۱", psp="sadad", driver="simulator", terminal_code="21045678"))
        db.add(PosTerminal(name="کارتخوان سیار (دستی)", psp="behpardakht", driver="manual"))


module = Module(
    name="cardreader",
    title="کارتخوان (PC-POS)",
    description="ارسال مبلغ به کارتخوان بانکی از صندوق، ثبت خودکار شماره پیگیری و تطبیق تراکنش‌ها",
    depends=["orders"],
    routers=[router],
    demo=demo,
    setup=setup,
)
