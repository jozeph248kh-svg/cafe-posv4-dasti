import logging
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core import settings_store
from app.core.audit import log_action
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import require
from app.core.errors import AppError
from app.core.models import User
from app.core.utils import now

from . import drivers as D
from .models import CardTxn, PosTerminal

log = logging.getLogger("cardreader")

router = APIRouter()
manage = require("settings.manage")
take = require("payments.take")


class TerminalIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    psp: str = "other"
    driver: str = Field("simulator", pattern="^(simulator|bridge|manual)$")
    url: str | None = None
    token: str | None = None
    device_ip: str | None = None
    terminal_code: str | None = None
    timeout_sec: int = Field(90, ge=20, le=300)
    is_active: bool = True


class ChargeIn(BaseModel):
    terminal_id: int
    amount: int = Field(gt=0)
    order_id: int | None = None
    uid: str | None = Field(None, max_length=40)


class ManualIn(BaseModel):
    terminal_id: int
    amount: int = Field(gt=0)
    order_id: int | None = None
    rrn: str = Field(min_length=4, max_length=40)
    card: str | None = Field(None, max_length=25)


def tout(t: PosTerminal) -> dict:
    return {"id": t.id, "name": t.name, "psp": t.psp, "psp_title": D.PSPS.get(t.psp, t.psp), "driver": t.driver, "driver_title": D.DRIVERS[t.driver],
            "url": t.url, "token": t.token, "device_ip": t.device_ip, "terminal_code": t.terminal_code, "timeout_sec": t.timeout_sec, "is_active": t.is_active}


def xout(x: CardTxn) -> dict:
    return {"id": x.id, "uid": x.uid, "terminal_id": x.terminal_id, "order_id": x.order_id, "payment_id": x.payment_id, "amount": x.amount, "status": x.status,
            "rrn": x.rrn, "trace": x.trace, "card": x.card, "code": x.code, "message": x.message, "created_at": x.created_at, "finished_at": x.finished_at}


@router.get("/meta")
def meta(_: User = Depends(take)):
    return {"psps": D.PSPS, "drivers": D.DRIVERS}


@router.get("/terminals")
def terminals(db: Session = Depends(get_db), user: User = Depends(take)):
    rows = db.query(PosTerminal).order_by(PosTerminal.id).all()
    out = [tout(t) for t in rows]
    if not user.can("settings.manage"):
        for o in out:
            o["token"] = None
    return out


@router.post("/terminals", status_code=201)
def create_terminal(data: TerminalIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    t = PosTerminal(**data.model_dump())
    db.add(t)
    db.flush()
    log_action(db, user, "cardreader.create", f"کارتخوان «{t.name}»", entity="pos_terminal", entity_id=t.id)
    db.commit()
    return tout(t)


@router.put("/terminals/{tid}")
def update_terminal(tid: int, data: TerminalIn, db: Session = Depends(get_db), user: User = Depends(manage)):
    t = get_or_404(db, PosTerminal, tid, "کارتخوان")
    for k, v in data.model_dump().items():
        setattr(t, k, v)
    db.commit()
    return tout(t)


@router.delete("/terminals/{tid}")
def delete_terminal(tid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    t = get_or_404(db, PosTerminal, tid, "کارتخوان")
    if db.query(CardTxn.id).filter(CardTxn.terminal_id == tid).first():
        t.is_active = False          # keep history
    else:
        db.delete(t)
    db.commit()
    return {"ok": True}


@router.post("/terminals/{tid}/ping")
def ping(tid: int, db: Session = Depends(get_db), _: User = Depends(take)):
    return D.ping(get_or_404(db, PosTerminal, tid, "کارتخوان"))


def _txn(db: Session, data, user: User) -> tuple[PosTerminal, CardTxn]:
    t = get_or_404(db, PosTerminal, data.terminal_id, "کارتخوان")
    if not t.is_active:
        raise AppError("این کارتخوان غیرفعال است")
    x = CardTxn(uid=getattr(data, "uid", None) or uuid.uuid4().hex[:20], terminal_id=t.id, order_id=data.order_id, amount=data.amount, created_by=user.id)
    db.add(x)
    db.commit()
    return t, x


@router.post("/charge")
def charge(data: ChargeIn, db: Session = Depends(get_db), user: User = Depends(take)):
    """Send the amount to the card reader and wait for the customer (runs in FastAPI's threadpool)."""
    if db.query(CardTxn.id).filter(CardTxn.uid == data.uid).first():
        raise AppError("این تراکنش قبلاً ارسال شده است", code="duplicate")
    t, x = _txn(db, data, user)
    if t.driver == "manual":
        raise AppError("این کارتخوان در حالت دستی است؛ شماره پیگیری را وارد کنید", code="manual")
    factor = int(settings_store.get(db, "cardreader.rial_factor", 10) or 10)
    try:
        res = D.RUN[t.driver](t, data.amount * factor, x.uid, data.order_id)
    except Exception:                       # noqa: BLE001 — a broken driver must not leave the record «pending»
        # The POS shows «در حال انتظار» for `pending`; an unexpected error (a driver bug, a bad bridge response
        # shape, a decode error) used to escape and freeze that row forever. Close it as `error` and keep the
        # technical detail in the server log, not in the API answer.
        log.exception("card reader driver failed: terminal=%s uid=%s", t.id, x.uid)
        db.rollback()                        # the transaction row was already committed by _txn(); re-read it
        x = db.query(CardTxn).filter(CardTxn.uid == x.uid).first()
        if x is not None:
            x.status, x.message, x.finished_at = "error", "خطای داخلی کارتخوان؛ تراکنش ثبت نشد", now()
            log_action(db, user, "cardreader.error",
                       f"کارتخوان {t.name}: خطای غیرمنتظره در {data.amount:,} تومان", entity="card_txn", entity_id=x.id)
            db.commit()
        raise AppError("خطای داخلی کارتخوان؛ مبلغی ثبت نشد. تراکنش را در دستگاه بررسی کنید", 502,
                       "card_reader_error") from None
    finally:
        D._cancel.pop(x.uid, None)
    db.refresh(x)
    if x.status == "cancelled" and res.status == "approved":
        res.message = "⚠️ پس از لغو، تراکنش در دستگاه موفق شد — مبلغ را بررسی و در صورت نیاز برگشت بزنید"
    x.status, x.rrn, x.trace, x.card, x.code, x.message, x.raw, x.finished_at = res.status, res.rrn, res.trace, res.card, res.code, res.message, res.raw, now()
    log_action(db, user, f"cardreader.{res.status}", f"کارتخوان {t.name}: {data.amount:,} تومان — {res.message or res.status}", entity="card_txn", entity_id=x.id)
    db.commit()
    return xout(x)


@router.post("/charge/{uid}/cancel")
def cancel(uid: str, db: Session = Depends(get_db), _: User = Depends(take)):
    x = db.query(CardTxn).filter(CardTxn.uid == uid).first()
    D.cancel(uid)
    if x and x.status == "pending":
        x.status, x.message = "cancelled", "لغو توسط صندوقدار"
        t = db.get(PosTerminal, x.terminal_id)
        if t and t.driver == "bridge":
            D.bridge_cancel(t, uid)
        db.commit()
    return {"ok": True}


@router.post("/manual")
def manual(data: ManualIn, db: Session = Depends(get_db), user: User = Depends(take)):
    """Stand-alone card reader: cashier types the amount on the device and records the RRN here."""
    t, x = _txn(db, data, user)
    x.status, x.rrn, x.card, x.message, x.finished_at = "approved", data.rrn.strip(), data.card, "ثبت دستی", now()
    log_action(db, user, "cardreader.manual", f"ثبت دستی کارتخوان {t.name}: {data.amount:,} تومان (پیگیری {data.rrn})", entity="card_txn", entity_id=x.id)
    db.commit()
    return xout(x)


@router.get("/txns")
def txns(status: str | None = None, unlinked: bool = False, days: int = 7, db: Session = Depends(get_db), _: User = Depends(require("reports.view"))):
    q = db.query(CardTxn).filter(CardTxn.created_at >= now() - timedelta(days=days))
    if status:
        q = q.filter(CardTxn.status == status)
    if unlinked:
        q = q.filter(CardTxn.status == "approved", CardTxn.payment_id.is_(None))
    rows = q.order_by(CardTxn.id.desc()).limit(300).all()
    approved = [x for x in rows if x.status == "approved"]
    return {"items": [xout(x) for x in rows], "approved_total": sum(x.amount for x in approved), "approved_count": len(approved),
            "unlinked": sum(1 for x in approved if not x.payment_id)}


@router.post("/txns/{xid}/dismiss")
def dismiss(xid: int, db: Session = Depends(get_db), user: User = Depends(manage)):
    """Mark an approved-but-unlinked transaction as reconciled (e.g. refunded on the device)."""
    x = get_or_404(db, CardTxn, xid, "تراکنش")
    x.status, x.message = "cancelled", f"تطبیق دستی توسط {user.full_name}"
    log_action(db, user, "cardreader.dismiss", f"تطبیق تراکنش کارتخوان {x.rrn} ({x.amount:,})", entity="card_txn", entity_id=x.id)
    db.commit()
    return {"ok": True}
