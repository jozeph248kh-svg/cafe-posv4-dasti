"""Card reader (PC-POS) drivers.

Iranian PSPs do not publish an open network protocol for their PC-POS devices; each ships a proprietary
Windows SDK (DLL / service). So the app talks to the device through a tiny **bridge** that runs on the
Windows PC next to the reader and wraps the PSP's SDK behind one simple HTTP/JSON contract:

    POST {url}/sale     {"uid", "amount" (rial), "terminal", "device", "orderId", "timeout"}
       -> {"status": "approved"|"declined"|"error"|"cancelled", "rrn", "trace", "card", "code", "message"}
    POST {url}/cancel   {"uid"}
    GET  {url}/status   -> {"ok": true, "psp": "...", "version": "..."}

A reference bridge with a built-in simulator lives in tools/pcpos_bridge.py.
"""
import random
import threading
import time
from dataclasses import dataclass, field

import httpx

PSPS = {
    "sadad": "سداد (بانک ملی)", "behpardakht": "به‌پرداخت ملت", "pec": "تجارت الکترونیک پارسیان", "pna": "پرداخت نوین آرین",
    "sep": "سامان کیش (سپ)", "irankish": "ایران کیش", "asanpardakht": "آسان پرداخت", "pep": "پرداخت الکترونیک پاسارگاد",
    "fanava": "فن‌آوا کارت", "sayan": "سایان کارت", "other": "سایر",
}
DRIVERS = {"simulator": "شبیه‌ساز (تست)", "bridge": "اتصال شبکه از طریق پل (PC-POS)", "manual": "دستی (ثبت شماره پیگیری)"}

_cancel: dict[str, threading.Event] = {}


@dataclass
class Result:
    status: str                      # approved | declined | error | cancelled
    rrn: str | None = None
    trace: str | None = None
    card: str | None = None
    code: str | None = None
    message: str | None = None
    raw: dict = field(default_factory=dict)


def cancel(uid: str) -> None:
    ev = _cancel.get(uid)
    if ev:
        ev.set()


def simulator(t, amount_rial: int, uid: str, order_id: int | None) -> Result:
    """Approves after ~3s. Amounts ending in 13,000 toman are declined (for testing the failure path)."""
    ev = _cancel.setdefault(uid, threading.Event())
    for _ in range(30):
        if ev.wait(0.1):
            return Result("cancelled", message="لغو توسط صندوقدار")
    if (amount_rial // 10_000) % 100 == 13:
        return Result("declined", code="51", message="موجودی کافی نیست", raw={"sim": True})
    rnd = random.Random(uid)
    return Result("approved", rrn=str(rnd.randint(10**11, 10**12 - 1)), trace=str(rnd.randint(100000, 999999)),
                  card=f"603799******{rnd.randint(1000, 9999)}", code="00", message="تراکنش موفق", raw={"sim": True})


def bridge(t, amount_rial: int, uid: str, order_id: int | None) -> Result:
    if not t.url:
        return Result("error", message="آدرس پل کارتخوان تنظیم نشده است")
    headers = {"Authorization": f"Bearer {t.token}"} if t.token else {}
    body = {"uid": uid, "amount": amount_rial, "terminal": t.terminal_code, "device": t.device_ip, "orderId": order_id, "timeout": t.timeout_sec, "psp": t.psp}
    try:
        r = httpx.post(f"{t.url.rstrip('/')}/sale", json=body, headers=headers, timeout=t.timeout_sec + 10)
        j = r.json()
    except httpx.TimeoutException:
        return Result("error", message="کارتخوان پاسخ نداد (پایان زمان)")
    except (httpx.HTTPError, ValueError) as e:
        return Result("error", message=f"ارتباط با پل کارتخوان برقرار نشد: {e}"[:240])
    st = str(j.get("status", "error")).lower()
    if st not in ("approved", "declined", "error", "cancelled"):
        st = "error"
    return Result(st, rrn=j.get("rrn"), trace=j.get("trace"), card=j.get("card"), code=str(j.get("code") or "") or None, message=j.get("message"), raw=j)


def bridge_cancel(t, uid: str) -> None:
    try:
        httpx.post(f"{t.url.rstrip('/')}/cancel", json={"uid": uid}, headers={"Authorization": f"Bearer {t.token}"} if t.token else {}, timeout=5)
    except httpx.HTTPError:
        pass


def ping(t) -> dict:
    if t.driver == "simulator":
        return {"ok": True, "message": "شبیه‌ساز آماده است"}
    if t.driver == "manual":
        return {"ok": True, "message": "حالت دستی نیاز به اتصال ندارد"}
    try:
        started = time.monotonic()
        r = httpx.get(f"{(t.url or '').rstrip('/')}/status", headers={"Authorization": f"Bearer {t.token}"} if t.token else {}, timeout=5)
        j = r.json()
        return {"ok": bool(j.get("ok")), "message": f"متصل · {j.get('psp', '')} {j.get('version', '')} · {int((time.monotonic() - started) * 1000)}ms", "raw": j}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "message": f"اتصال برقرار نشد: {e}"[:200]}


RUN = {"simulator": simulator, "bridge": bridge}
