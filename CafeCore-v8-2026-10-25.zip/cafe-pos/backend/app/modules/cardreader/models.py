from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base, TimestampMixin


class PosTerminal(Base, TimestampMixin):
    """A bank card reader (PC-POS) next to a cash desk."""
    __tablename__ = "pos_terminals"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    psp: Mapped[str] = mapped_column(String(30), default="other")          # sadad | behpardakht | ... (label + defaults)
    driver: Mapped[str] = mapped_column(String(20), default="simulator")   # simulator | manual | bridge
    url: Mapped[str | None] = mapped_column(String(200))                   # bridge base URL, e.g. http://192.168.1.20:8090
    token: Mapped[str | None] = mapped_column(String(120))
    device_ip: Mapped[str | None] = mapped_column(String(60))              # card reader's own IP:port (passed to the bridge)
    terminal_code: Mapped[str | None] = mapped_column(String(40))          # terminal / merchant id printed on the device
    timeout_sec: Mapped[int] = mapped_column(Integer, default=90)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class CardTxn(Base, TimestampMixin):
    __tablename__ = "card_txns"
    id: Mapped[int] = mapped_column(primary_key=True)
    uid: Mapped[str] = mapped_column(String(40), unique=True)
    terminal_id: Mapped[int] = mapped_column(ForeignKey("pos_terminals.id"), index=True)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("orders.id"), index=True)
    payment_id: Mapped[int | None] = mapped_column(ForeignKey("payments.id"), index=True)
    amount: Mapped[int] = mapped_column(Integer)                            # toman
    status: Mapped[str] = mapped_column(String(12), default="pending", index=True)  # pending|approved|declined|error|cancelled
    rrn: Mapped[str | None] = mapped_column(String(40), index=True)
    trace: Mapped[str | None] = mapped_column(String(40))
    card: Mapped[str | None] = mapped_column(String(25))
    code: Mapped[str | None] = mapped_column(String(10))
    message: Mapped[str | None] = mapped_column(String(250))
    raw: Mapped[dict | None] = mapped_column(JSON)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    payment = relationship("Payment")
