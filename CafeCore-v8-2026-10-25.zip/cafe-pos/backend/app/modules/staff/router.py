from fastapi import APIRouter, Depends, Request, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core import ratelimit
from app.core.audit import log_action
from app.core.config import get_settings
from app.core.crud import get_or_404
from app.core.db import get_db
from app.core.deps import current_user, require
from app.core.errors import AppError
from app.core.models import Role, User
from app.core.modules import registry
from app.core.realtime import call_after_commit, hub
from app.core.security import create_token, hash_password, hash_pin, verify_password
from app.core.utils import now

from .seed import DEFAULT_PASSWORDS
from .schemas import (
    LoginIn,
    MeOut,
    PasswordChange,
    PinIn,
    RoleIn,
    RoleOut,
    UserIn,
    UserOut,
)

router = APIRouter()


def me_payload(user: User) -> MeOut:
    perms = sorted(registry.all_permission_codes()) if "*" in user.role.permissions else user.role.permissions
    return MeOut(id=user.id, username=user.username, full_name=user.full_name,
                 role=user.role.name, role_title=user.role.title, permissions=perms)


def _login_response(db: Session, user: User, must_change: bool = False) -> dict:
    user.last_login = now()
    db.commit()
    return {"token": create_token(user.id, user.token_version, must_change), "user": me_payload(user),
            "must_change_password": must_change}


def _is_factory_password(password: str) -> bool:
    return get_settings().force_password_change and password in DEFAULT_PASSWORDS


# ---------------------------------------------------------------- auth
@router.post("/auth/login")
def login(data: LoginIn, request: Request, db: Session = Depends(get_db)):
    uname = data.username.lower().strip()
    ip = ratelimit.client_ip(request)
    keys = (f"login:{ip}:{uname}", f"login-ip:{ip}")
    ratelimit.check(*keys)
    user = db.query(User).filter(func.lower(User.username) == uname).first()
    if not user or not verify_password(data.password, user.password_hash):
        ratelimit.fail(*keys)
        raise AppError("نام کاربری یا رمز عبور اشتباه است", status.HTTP_401_UNAUTHORIZED, "bad_credentials")
    if not user.is_active:
        raise AppError("حساب کاربری غیرفعال است", status.HTTP_403_FORBIDDEN, "inactive")
    ratelimit.success(f"login:{ip}:{uname}")
    return _login_response(db, user, _is_factory_password(data.password))


@router.get("/auth/options")
def login_options(db: Session = Depends(get_db)):
    """Public hints for the login screen: is PIN login set up at all, and is this a sample-users install?"""
    has_pin = db.query(User.id).filter(User.pin_hash.isnot(None), User.is_active.is_(True)).first() is not None
    return {"pin_enabled": has_pin, "sample_users": bool(get_settings().seed_sample_users),
            "timeclock": "timeclock" in registry.modules}


@router.post("/auth/pin")
def pin_login(data: PinIn, request: Request, db: Session = Depends(get_db)):
    keys = (f"pin-ip:{ratelimit.client_ip(request)}",)
    ratelimit.check(*keys)
    user = db.query(User).filter(User.pin_hash == hash_pin(data.pin)).first()
    if not user or not user.is_active:
        ratelimit.fail(*keys)
        raise AppError("کد ورود اشتباه است", status.HTTP_401_UNAUTHORIZED, "bad_pin")
    ratelimit.success(*keys)
    # PIN logins can't prove the password was changed; a factory password account must log in with the password first
    if _is_factory_password_hash(user):
        raise AppError("برای اولین ورود با نام کاربری و رمز عبور وارد شوید و رمز را تغییر دهید", status.HTTP_403_FORBIDDEN,
                       "password_change_required")
    return _login_response(db, user)


def _is_factory_password_hash(user: User) -> bool:
    if not get_settings().force_password_change:
        return False
    return any(verify_password(p, user.password_hash) for p in DEFAULT_PASSWORDS)


@router.get("/auth/me", response_model=MeOut)
def me(request: Request, user: User = Depends(current_user)):
    out = me_payload(user)
    out.must_change_password = getattr(request.state, "must_change_password", False)
    return out


@router.post("/auth/password")
def change_password(data: PasswordChange, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    keys = (f"pwd:{user.id}",)
    ratelimit.check(*keys)
    if not verify_password(data.current_password, user.password_hash):
        ratelimit.fail(*keys)
        raise AppError("رمز فعلی اشتباه است", code="bad_password")
    if data.new_password in DEFAULT_PASSWORDS or data.new_password == data.current_password:
        raise AppError("رمز جدید باید با رمز فعلی و رمزهای پیش‌فرض متفاوت باشد", code="weak_password")
    if data.new_password.lower() == user.username.lower():
        raise AppError("رمز عبور نباید با نام کاربری یکسان باشد", code="weak_password")
    ratelimit.success(*keys)
    user.password_hash = hash_password(data.new_password)
    user.token_version += 1          # signs out every other device using the old password
    log_action(db, user, "user.password", "تغییر رمز عبور", entity="user", entity_id=user.id)
    call_after_commit(db, hub.kick, [user.id])
    db.commit()
    return {"token": create_token(user.id, user.token_version), "user": me_payload(user), "must_change_password": False}


# ---------------------------------------------------------------- permissions & roles
@router.get("/permissions")
def permissions(_: User = Depends(require("staff.manage"))):
    return registry.permissions


@router.get("/roles", response_model=list[RoleOut])
def list_roles(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return db.query(Role).order_by(Role.id).all()


def _clean_perms(perms: list[str]) -> list[str]:
    valid = registry.all_permission_codes()
    return sorted({p for p in perms if p in valid})


def _ensure_within(actor: User, perms: list[str], what: str) -> None:
    """A staff manager may only hand out permissions they hold themselves (no privilege escalation)."""
    if "*" in actor.role.permissions:
        return
    if "*" in perms:
        raise AppError(f"فقط مدیر کل می‌تواند {what} با دسترسی کامل را مدیریت کند", status.HTTP_403_FORBIDDEN, "forbidden")
    extra = sorted(set(perms) - set(actor.role.permissions))
    if extra:
        raise AppError(f"نمی‌توانید مجوزی بالاتر از مجوزهای خودتان بدهید ({', '.join(extra[:5])})", status.HTTP_403_FORBIDDEN,
                       "forbidden", permissions=extra)


@router.post("/roles", response_model=RoleOut, status_code=201)
def create_role(data: RoleIn, db: Session = Depends(get_db), user: User = Depends(require("staff.manage"))):
    _ensure_within(user, _clean_perms(data.permissions), "نقش")
    if db.query(Role).filter(Role.name == data.name).first():
        raise AppError("نقشی با این شناسه وجود دارد")
    role = Role(name=data.name, title=data.title, permissions=_clean_perms(data.permissions))
    db.add(role)
    log_action(db, user, "role.create", f"ایجاد نقش «{role.title}»", entity="role")
    db.commit()
    return role


@router.put("/roles/{role_id}", response_model=RoleOut)
def update_role(role_id: int, data: RoleIn, db: Session = Depends(get_db), user: User = Depends(require("staff.manage"))):
    role = get_or_404(db, Role, role_id, "نقش")
    _ensure_within(user, role.permissions, "نقش")
    _ensure_within(user, _clean_perms(data.permissions), "نقش")
    if role.id == user.role_id and "*" not in user.role.permissions:
        raise AppError("نمی‌توانید مجوزهای نقش خودتان را تغییر دهید", status.HTTP_403_FORBIDDEN, "forbidden")
    before = list(role.permissions)
    role.title = data.title
    if "*" not in role.permissions:  # the super-admin role always keeps full access
        role.permissions = _clean_perms(data.permissions)
    log_action(db, user, "role.update", f"ویرایش مجوزهای نقش «{role.title}»", entity="role", entity_id=role.id,
               details={"before": before, "after": role.permissions})
    if set(before) != set(role.permissions):
        call_after_commit(db, hub.kick, [uid for (uid,) in db.query(User.id).filter(User.role_id == role.id)])
    db.commit()
    return role


@router.delete("/roles/{role_id}", status_code=204)
def delete_role(role_id: int, db: Session = Depends(get_db), user: User = Depends(require("staff.manage"))):
    role = get_or_404(db, Role, role_id, "نقش")
    if role.is_system:
        raise AppError("نقش‌های پیش‌فرض سیستم قابل حذف نیستند")
    if db.query(User).filter(User.role_id == role_id).count():
        raise AppError("این نقش به کاربرانی اختصاص داده شده است")
    db.delete(role)
    log_action(db, user, "role.delete", f"حذف نقش «{role.title}»", entity="role")
    db.commit()


# ---------------------------------------------------------------- users
def user_out(u: User) -> UserOut:
    out = UserOut.model_validate(u)
    out.has_pin = bool(u.pin_hash)
    return out


@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), _: User = Depends(require("staff.manage"))):
    return [user_out(u) for u in db.query(User).order_by(User.id).all()]


@router.get("/users/basic")
def users_basic(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return [{"id": u.id, "full_name": u.full_name, "role": u.role.name}
            for u in db.query(User).filter(User.is_active.is_(True)).order_by(User.full_name).all()]


def _apply_user(db: Session, u: User, data: UserIn, actor: User) -> None:
    if u.id and u.role:
        _ensure_within(actor, u.role.permissions, "کاربر")          # can't edit someone more privileged
    role = db.get(Role, data.role_id)
    if role:
        _ensure_within(actor, role.permissions, "کاربر")            # can't grant a more privileged role
    if u.id == actor.id and data.role_id != actor.role_id:
        raise AppError("نمی‌توانید نقش خودتان را تغییر دهید", status.HTTP_403_FORBIDDEN, "forbidden")
    dup = db.query(User).filter(func.lower(User.username) == data.username.lower(), User.id != (u.id or 0)).first()
    if dup:
        raise AppError("این نام کاربری قبلاً ثبت شده است")
    if not db.get(Role, data.role_id):
        raise AppError("نقش انتخاب‌شده معتبر نیست")
    if u.id and (u.role_id != data.role_id or u.is_active != data.is_active or data.password):
        call_after_commit(db, hub.kick, [u.id])
    u.username, u.full_name, u.phone, u.role_id = data.username, data.full_name, data.phone, data.role_id
    if u.is_active != data.is_active:
        u.token_version = (u.token_version or 1) + 1
    u.is_active = data.is_active
    if data.password:
        u.password_hash = hash_password(data.password)
        u.token_version = (u.token_version or 1) + 1
    if data.clear_pin:
        u.pin_hash = None
    elif data.pin:
        ph = hash_pin(data.pin)
        if db.query(User).filter(User.pin_hash == ph, User.id != (u.id or 0)).first():
            raise AppError("این کد ورود (PIN) برای کاربر دیگری استفاده شده است")
        u.pin_hash = ph


@router.post("/users", response_model=UserOut, status_code=201)
def create_user(data: UserIn, db: Session = Depends(get_db), user: User = Depends(require("staff.manage"))):
    if not data.password:
        raise AppError("رمز عبور برای کاربر جدید الزامی است")
    u = User(token_version=1)
    _apply_user(db, u, data, user)
    db.add(u)
    log_action(db, user, "user.create", f"ایجاد کاربر «{u.full_name}»", entity="user")
    db.commit()
    db.refresh(u)
    return user_out(u)


@router.put("/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, data: UserIn, db: Session = Depends(get_db), user: User = Depends(require("staff.manage"))):
    u = get_or_404(db, User, user_id, "کاربر")
    if u.id == user.id and not data.is_active:
        raise AppError("نمی‌توانید حساب خودتان را غیرفعال کنید")
    _apply_user(db, u, data, user)
    log_action(db, user, "user.update", f"ویرایش کاربر «{u.full_name}»", entity="user", entity_id=u.id)
    db.commit()
    db.refresh(u)
    return user_out(u)
