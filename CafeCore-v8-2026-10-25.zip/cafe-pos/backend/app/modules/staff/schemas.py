from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class LoginIn(BaseModel):
    username: str
    password: str


class PinIn(BaseModel):
    pin: str = Field(min_length=4, max_length=8)


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    title: str
    permissions: list[str]
    is_system: bool


class RoleIn(BaseModel):
    name: str = Field(min_length=2, max_length=40, pattern=r"^[a-z0-9_]+$")
    title: str = Field(min_length=2, max_length=80)
    permissions: list[str] = []


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: str
    phone: str | None
    role_id: int
    is_active: bool
    has_pin: bool = False
    last_login: datetime | None
    created_at: datetime


class UserIn(BaseModel):
    username: str = Field(min_length=3, max_length=40, pattern=r"^[A-Za-z0-9_.]+$")
    full_name: str = Field(min_length=2, max_length=80)
    phone: str | None = None
    role_id: int
    is_active: bool = True
    password: str | None = Field(default=None, min_length=6)
    pin: str | None = Field(default=None, pattern=r"^\d{4,8}$")
    clear_pin: bool = False


class MeOut(BaseModel):
    id: int
    username: str
    full_name: str
    role: str
    role_title: str
    permissions: list[str]
    must_change_password: bool = False
