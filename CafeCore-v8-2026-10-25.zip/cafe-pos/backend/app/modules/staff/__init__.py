from app.core.modules import Module

from .router import router
from .seed import seed

module = Module(
    name="staff",
    title="پرسنل و دسترسی‌ها",
    description="ورود، کاربران، نقش‌ها و مجوزها",
    core=True,
    routers=[router],
    permissions={"staff.manage": "مدیریت پرسنل و نقش‌ها"},
    seed=seed,
)
