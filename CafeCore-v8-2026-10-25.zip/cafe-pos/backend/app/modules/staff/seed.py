from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.models import Role, User
from app.core.security import hash_password, hash_pin

ROLES = [
    ("admin", "مدیر کل", ["*"]),
    ("manager", "مدیر داخلی", [
        "dashboard.view", "pos.access", "orders.discount", "orders.void", "orders.cancel", "orders.transfer",
        "payments.take", "payments.refund", "kitchen.access", "menu.manage", "floor.manage", "inventory.view",
        "inventory.manage", "shifts.manage", "reports.view", "audit.view", "customers.manage", "discounts.manage",
    ]),
    ("cashier", "صندوقدار", ["pos.access", "orders.discount", "orders.transfer", "payments.take", "shifts.manage", "kitchen.access", "customers.manage"]),
    ("waiter", "گارسون", ["pos.access", "orders.transfer"]),
    ("kitchen", "آشپزخانه / بار", ["kitchen.access"]),
]

DISCOUNT_CEILING = {"cashier": 10}      # % a cashier may give without a manager PIN (editable in «تخفیف‌ها»)

USERS = [
    ("admin", "مدیر سیستم", "admin", "admin123", "1111"),
    ("sara", "سارا احمدی", "manager", "manager123", "2222"),
    ("reza", "رضا کریمی", "cashier", "cashier123", "3333"),
    ("ali", "علی محمدی", "waiter", "waiter123", "4444"),
    ("maryam", "مریم رضایی", "waiter", "waiter123", "5555"),
    ("chef", "آشپزخانه", "kitchen", "kitchen123", "6666"),
]


# Factory passwords: anyone still using one must choose a new password before using the system
# (see `force_password_change`). Production installs only get the `admin` account.
DEFAULT_PASSWORDS = {pwd for *_, pwd, _ in USERS}


def seed(db: Session) -> None:
    if db.query(Role).count():
        return
    roles = {}
    for name, title, perms in ROLES:
        roles[name] = Role(name=name, title=title, permissions=perms, is_system=True,
                           max_discount_pct=DISCOUNT_CEILING.get(name))
        db.add(roles[name])
    db.flush()
    sample = get_settings().seed_sample_users
    for username, full_name, role, pwd, pin in USERS if sample else USERS[:1]:
        db.add(User(username=username, full_name=full_name, role_id=roles[role].id,
                    password_hash=hash_password(pwd), pin_hash=hash_pin(pin) if sample else None, token_version=1))
