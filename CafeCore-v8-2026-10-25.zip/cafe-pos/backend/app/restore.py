"""Restore a backup (offline) and drill it without restoring. Usage, from `backend`:

    python -m app.restore --list                 # list backups
    python -m app.restore --drill                # restore the newest backup into a SCRATCH db and compare figures
    python -m app.restore --drill <name-or-path> # same, for one file
    python -m app.restore <name-or-path>         # replace the live database (server MUST be stopped)

The current database is verified-copied to data/backups/*-pre-restore.db first, so a restore can always be undone.
"""
import argparse
import socket
import sys
from pathlib import Path

from app.core.backup import BackupError, drill_and_record, restore_backup, verify
from app.core.config import get_settings


def server_running(port: int) -> bool:
    for host in ("127.0.0.1", "::1"):
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            continue
    return False


def main(argv: list[str] | None = None) -> int:
    s = get_settings()
    ap = argparse.ArgumentParser(description="Cafe POS — restore a database backup")
    ap.add_argument("backup", nargs="?", help="backup file (.db)")
    ap.add_argument("--list", action="store_true", help="list available backups")
    ap.add_argument("--drill", nargs="?", const="", help="restore a backup into a scratch database and compare "
                                                        "its figures (live database untouched)")
    ap.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    a = ap.parse_args(argv)
    if a.drill is None and not s.db_url.startswith("sqlite"):
        print("[ERROR] This tool restores the built-in SQLite backups only. The database is not SQLite "
              "(CAFE_DATABASE_URL is set) — use PostgreSQL's own tools instead, e.g.\n"
              "  pg_dump -Fc -f cafe.dump <db>      (backup)\n"
              "  pg_restore --clean -d <db> cafe.dump   (restore, with Cafe POS stopped)\n"
              "See README → PostgreSQL.")
        return 5
    if a.drill is not None:
        res = drill_and_record()
        ok = res.get("ok")
        print(f"[{'OK' if ok else 'FAILED'}] drill {res.get('backup', '-')} → {res.get('restored_into', '-')} "
              f"({res.get('duration_ms', 0)} ms)")
        if res.get("differences"):
            for d in res["differences"][:10]:
                print(f"   {d['field']}: manifest={d['expected']} restored={d['actual']}")
        if res.get("error"):
            print(f"   {res['error']}")
        for k, v in (res.get("figures") or {}).items():
            print(f"   {k} = {v}")
        return 0 if ok else 6
    if a.list or not a.backup:
        for p in sorted(s.backups_dir.glob("cafe-*.db"), reverse=True):
            print(f"{p.name}\t{p.stat().st_size / 1024:,.0f} KB")
        return 0
    path = Path(a.backup)
    if not path.exists():
        path = s.backups_dir / a.backup
    if server_running(s.port):
        print(f"[ERROR] Cafe POS is running on port {s.port}. Close it first, then run the restore again.")
        return 2
    try:
        info = verify(path)
    except BackupError as e:
        print(f"[ERROR] {e}")
        return 3
    print(f"Backup OK: {path.name}  orders={info['counts'].get('orders')}  payments={info['counts'].get('payments')}")
    if not a.yes and input("Replace the current database with this backup? (yes/no): ").strip().lower() != "yes":
        print("Cancelled.")
        return 1
    try:
        res = restore_backup(path)
    except BackupError as e:
        print(f"[ERROR] {e}")
        return 4
    print(f"Restored. Previous database saved as: {res['safety_copy']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
