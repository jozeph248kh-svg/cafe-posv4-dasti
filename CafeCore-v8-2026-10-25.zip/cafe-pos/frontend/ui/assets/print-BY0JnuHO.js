import{r as F,p as R,O as x,n as u,E as v,m as o,P as y,e as T,K as P}from"./index-CkCcyJBB.js";const z='"Vazirmatn FD", Vazirmatn, Tahoma, sans-serif',m=6,j=t=>String(t??"").replace(new RegExp("\\p{Extended_Pictographic}|\\uFE0F","gu"),"").replace(/\s+/g," ").trim();function S(t,n,e){const s=j(n).split(" "),i=[];let a="";for(const l of s){const c=a?`${a} ${l}`:l;a&&t.measureText(c).width>e?(i.push(a),a=l):a=c}return(a||!i.length)&&i.push(a),i}const q=t=>new Promise(n=>{const e=new Image;e.onload=()=>n(e),e.onerror=()=>n(null),e.src=t});async function B(t,n){try{await document.fonts.load(`24px ${z}`),await document.fonts.load(`700 24px ${z}`)}catch{}const e=document.createElement("canvas");e.width=n;let s=e.getContext("2d");s.direction="rtl";const i=(d,p)=>`${p?700:400} ${d}px ${z}`,a=[];let l=m;for(const d of t){if(!d)continue;if(d.space){l+=d.space;continue}if(d.hr){a.push({hr:d.hr,y:l+7}),l+=16;continue}if(d.img){const $=await q(d.img);if(!$)continue;const b=Math.min($.width,(d.maxWidth||.5)*n),_=Math.min($.height*(b/$.width),180),g=$.width*(_/$.height);a.push({img:$,x:(n-g)/2,y:l,w:g,h:_}),l+=_+8;continue}const p=d.size||22,f=Math.round(p*1.5);if(s.font=i(p,d.bold),d.left!==void 0&&d.left!==null){const $=j(d.left),b=s.measureText($).width;S(s,d.text,n-2*m-b-14).forEach((_,g)=>{a.push({t:_,x:n-m,y:l+p,align:"right",f:s.font}),g===0&&a.push({t:$,x:m,y:l+p,align:"left",f:s.font}),l+=f})}else{const $=d.align||"right";S(s,d.text,n-2*m).forEach(b=>{a.push({t:b,x:$==="center"?n/2:$==="left"?m:n-m,y:l+p,align:$,f:s.font}),l+=f})}}const c=Math.ceil(l+m);e.height=c,s=e.getContext("2d"),s.fillStyle="#fff",s.fillRect(0,0,n,c),s.fillStyle="#000",s.strokeStyle="#000",s.direction="rtl";for(const d of a)d.hr?(s.lineWidth=d.hr==="solid"?3:2,s.setLineDash(d.hr==="solid"?[]:[8,5]),s.beginPath(),s.moveTo(m,d.y),s.lineTo(n-m,d.y),s.stroke()):d.img?s.drawImage(d.img,d.x,d.y,d.w,d.h):(s.font=d.f,s.textAlign=d.align,s.fillText(d.t,d.x,d.y));return{width:n,height:c,data:M(C(s.getImageData(0,0,n,c).data,n,c))}}function C(t,n,e){const s=n/8,i=new Uint8Array(s*e);for(let a=0;a<e;a++)for(let l=0;l<n;l++){const c=(a*n+l)*4,d=(t[c]*299+t[c+1]*587+t[c+2]*114)/1e3;t[c+3]>128&&d<140&&(i[a*s+(l>>3)]|=128>>(l&7))}return i}function M(t){let n="";for(let e=0;e<t.length;e+=32768)n+=String.fromCharCode.apply(null,t.subarray(e,e+32768));return btoa(n)}function O(t){const n=(t?.["print.printers"]||[]).filter(s=>s.receipt),e=F();return n.find(s=>e&&s.register_id===e)||n.find(s=>!s.register_id)||null}const W=(t,n)=>(t?.["print.printers"]||[]).find(e=>(e.station_ids||[]).includes(n))||null;async function A(t,n,{drawer:e=!1,copies:s=1}={}){const i=await B(n,t.width||576);return R("/system/print",{printer_id:t.id,...i,drawer:e,copies:s})}async function E(t,n,e,s){if(!t)return s();try{await A(t,n,e)}catch(i){window.dispatchEvent(new CustomEvent("print:error",{detail:`${i.message} — چاپ از طریق مرورگر انجام می‌شود.`})),s()}}function I(t){return[t["receipt.show_logo"]&&t["business.logo"]&&{img:t["business.logo"],maxWidth:.5},{text:t["business.name"],align:"center",size:30,bold:!0},t["business.address"]&&{text:t["business.address"],align:"center",size:19},t["business.phone"]&&{text:`تلفن: ${t["business.phone"]}`,align:"center",size:19}]}function D(t,n=!0,e=!1){return t.filter(s=>s.status!=="void"&&!s.is_void).flatMap(s=>[n?{text:`${u(s.qty)}× ${s.name}`,left:o(s.unit_price*s.qty),size:22}:{text:`${u(s.qty)}× ${s.name}`,size:e?30:22,bold:!0},s.modifiers?.length&&{text:`   ${T(s.modifiers)}`,size:e?24:18},s.note&&{text:`   * ${s.note}`,size:e?24:18},n&&s.discount_amount&&{text:`   تخفیف${s.discount_type==="percent"?` ${u(s.discount_value)}٪`:""}`,left:`−${o(s.discount_amount)}`,size:18}])}function H(t,n,e="receipt"){const s=x[t.type],i=n["currency.label"]||"تومان",a=t.discount_amount-(t.line_discount_amount||0),l=(t.payments||[]).reduce((c,d)=>c+(d.change||0),0);return[...I(n),{hr:"dashed"},{text:`${e==="bill"?"پیش‌فاکتور":"رسید فروش"} — سفارش #${u(t.number)}`,align:"center",size:24,bold:!0},{text:`${s?.label||""}${t.table_name?` — میز ${t.table_name}`:""}`,left:v(t.closed_at||t.created_at),size:19},t.waiter_name&&{text:`گارسون: ${t.waiter_name}${t.guests>1?` — ${u(t.guests)} نفر`:""}`,size:19},t.customer_name&&{text:`مشتری: ${t.customer_name} ${t.customer_phone||""}`,size:19},t.customer_address&&{text:`آدرس: ${t.customer_address}`,size:19},{hr:"dashed"},...D(t.lines),{hr:"dashed"},{text:"جمع اقلام",left:o(t.subtotal)},t.line_discount_amount&&{text:"تخفیف اقلام",left:`−${o(t.line_discount_amount)}`},a>0&&{text:`تخفیف فاکتور${t.discount_type==="percent"?` (${u(t.discount_value)}٪)`:""}`,left:`−${o(a)}`},t.discount_amount&&{text:`سود شما از این خرید: ${o(t.discount_amount)} ${i}`,align:"center",bold:!0,size:20},t.service_amount&&{text:"حق سرویس",left:o(t.service_amount)},t.tax_amount&&{text:"مالیات بر ارزش افزوده",left:o(t.tax_amount)},t.rounding&&{text:"رُند",left:o(t.rounding)},{hr:"solid"},{text:"مبلغ قابل پرداخت",left:`${o(t.total)} ${i}`,size:26,bold:!0},{hr:"solid"},...e==="receipt"?(t.payments||[]).map(c=>({text:`${c.is_refund?"بازپرداخت ":""}${y[c.method]?.label||c.method}`,left:o(c.amount),size:20})):[],e==="receipt"&&l>0&&{text:"باقیمانده پرداختی به مشتری",left:o(l),size:20},{hr:"dashed"},n["business.wifi"]&&{text:`WiFi: ${n["business.wifi"]}`,align:"center",size:19},n["receipt.footer"]&&{text:n["receipt.footer"],align:"center",size:20},{space:10}]}function V(t,n){const e=x[t.order_type];return[{text:n||"آشپزخانه",align:"center",size:24,bold:!0},{text:`#${u(t.order_number)}`,align:"center",size:56,bold:!0},{text:t.table_name?`میز ${t.table_name}`:e?.label||"",align:"center",size:34,bold:!0},{text:t.waiter_name||"",left:v(t.created_at),size:19},{hr:"solid"},...D(t.items,!1,!0),t.note&&{hr:"dashed"},t.note&&{text:`* ${t.note}`,size:24,bold:!0},{space:10}]}const r=t=>String(t??"").replace(/[&<>"]/g,n=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[n]),K=`
@page { size: 80mm auto; margin: 3mm; }
* { box-sizing: border-box; }
body { font-family: Vazirmatn, 'Vazirmatn FD', Tahoma, sans-serif; direction: rtl; margin: 0; color: #000; font-size: 12px; width: 74mm; }
.c { text-align: center; } .b { font-weight: 700; } .big { font-size: 18px; } .xl { font-size: 26px; font-weight: 800; }
.muted { color: #444; font-size: 11px; }
hr { border: 0; border-top: 1px dashed #000; margin: 6px 0; }
table { width: 100%; border-collapse: collapse; }
td { padding: 2px 0; vertical-align: top; }
td.n { text-align: left; white-space: nowrap; }
.mods { font-size: 11px; color: #333; padding-right: 8px; }
.row { display: flex; justify-content: space-between; padding: 1px 0; }
.total { font-size: 16px; font-weight: 800; border-top: 1px solid #000; border-bottom: 1px solid #000; padding: 4px 0; margin-top: 4px; }
img.logo { max-width: 40mm; max-height: 22mm; display: block; margin: 0 auto 4px; }
`;function Y(){let t="";for(const n of document.styleSheets)try{for(const e of n.cssRules)e instanceof CSSFontFaceRule&&/vazir/i.test(e.cssText)&&(t+=e.cssText.replace(/url\("?(\/[^")]+)"?\)/g,`url("${location.origin}$1")`))}catch{}return t}function h(t,{css:n="",title:e="print"}={}){const s=document.createElement("iframe");Object.assign(s.style,{position:"fixed",left:"-10000px",top:0,width:"80mm",height:"10px",border:0}),document.body.appendChild(s);const i=s.contentDocument;i.open(),i.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>${r(e)}</title>
    <style>${Y()}${K}${n}</style></head><body>${t}</body></html>`),i.close();const a=()=>{s.contentWindow.focus(),s.contentWindow.print(),setTimeout(()=>s.remove(),1500)},l=[...i.images];l.length?Promise.all(l.map(c=>c.complete?0:new Promise(d=>{c.onload=c.onerror=d}))).then(()=>setTimeout(a,100)):setTimeout(a,150)}function w(t){return`${t["receipt.show_logo"]&&t["business.logo"]?`<img class="logo" src="${r(t["business.logo"])}">`:""}
    <div class="c big b">${r(t["business.name"])}</div>
    ${t["business.address"]?`<div class="c muted">${r(t["business.address"])}</div>`:""}
    ${t["business.phone"]?`<div class="c muted">تلفن: ${r(t["business.phone"])}</div>`:""}`}function Z(t,n=!0){return`<table>${t.filter(e=>e.status!=="void").map(e=>`
    <tr><td><span class="b">${u(e.qty)}×</span> ${r(e.name)}
      ${e.modifiers?.length?`<div class="mods">${r(T(e.modifiers))}</div>`:""}
      ${e.note?`<div class="mods">📝 ${r(e.note)}</div>`:""}
      ${n&&e.discount_amount?`<div class="mods">تخفیف${e.discount_type==="percent"?` ${u(e.discount_value)}٪`:""}: −${o(e.discount_amount)}</div>`:""}</td>
      ${n?`<td class="n">${o(e.unit_price*e.qty)}</td>`:""}</tr>`).join("")}</table>`}function J(t,n,e="receipt"){const s=n||{},i=e==="receipt"&&(t.payments||[]).some(a=>a.method==="cash"&&!a.is_refund);return E(O(s),H(t,s,e),{drawer:i},()=>L(t,s,e))}function L(t,n,e){const s=x[t.type],i=(t.payments||[]).map(l=>`<div class="row"><span>${l.is_refund?"بازپرداخت ":""}${y[l.method]?.label||l.method}</span><span>${o(l.amount)}</span></div>`).join(""),a=`${w(n)}<hr>
    <div class="c b">${e==="bill"?"پیش‌فاکتور":"رسید فروش"} — سفارش #${u(t.number)}</div>
    <div class="row muted"><span>${s?.label||""}${t.table_name?` — میز ${r(t.table_name)}`:""}</span><span>${v(t.closed_at||t.created_at)}</span></div>
    ${t.waiter_name?`<div class="muted">گارسون: ${r(t.waiter_name)}${t.guests>1?` — ${u(t.guests)} نفر`:""}</div>`:""}
    ${t.customer_name?`<div class="muted">مشتری: ${r(t.customer_name)} ${r(t.customer_phone||"")}</div>`:""}
    ${t.customer_address?`<div class="muted">آدرس: ${r(t.customer_address)}</div>`:""}
    <hr>${Z(t.lines)}<hr>
    <div class="row"><span>جمع اقلام</span><span>${o(t.subtotal)}</span></div>
    ${t.line_discount_amount?`<div class="row"><span>تخفیف اقلام</span><span>−${o(t.line_discount_amount)}</span></div>`:""}
    ${t.discount_amount-(t.line_discount_amount||0)>0?`<div class="row"><span>تخفیف فاکتور${t.discount_type==="percent"?` (${u(t.discount_value)}٪)`:""}</span><span>−${o(t.discount_amount-(t.line_discount_amount||0))}</span></div>`:""}
    ${t.discount_amount?`<div class="c b">سود شما از این خرید: ${o(t.discount_amount)} ${r(n["currency.label"]||"تومان")}</div>`:""}
    ${t.service_amount?`<div class="row"><span>حق سرویس</span><span>${o(t.service_amount)}</span></div>`:""}
    ${t.tax_amount?`<div class="row"><span>مالیات بر ارزش افزوده</span><span>${o(t.tax_amount)}</span></div>`:""}
    ${t.rounding?`<div class="row"><span>رُند</span><span>${o(t.rounding)}</span></div>`:""}
    <div class="row total"><span>مبلغ قابل پرداخت</span><span>${o(t.total)} ${r(n["currency.label"]||"تومان")}</span></div>
    ${e==="receipt"&&i?`<div style="margin-top:4px">${i}</div>`:""}
    ${e==="receipt"&&t.payments?.some(l=>l.change)?`<div class="row"><span>باقیمانده پرداختی به مشتری</span><span>${o(t.payments.reduce((l,c)=>l+(c.change||0),0))}</span></div>`:""}
    <hr>${n["business.wifi"]?`<div class="c muted">WiFi: ${r(n["business.wifi"])}</div>`:""}
    <div class="c">${r(n["receipt.footer"]||"")}</div>`;h(a,{title:`order-${t.number}`})}function N(t,n,e){return E(W(e,t.station_id),V(t,n),{},()=>U(t,n))}function U(t,n){const e=x[t.order_type],s=`<div class="c b">${r(n||"آشپزخانه")}</div>
    <div class="c xl">#${u(t.order_number)}</div>
    <div class="c big b">${t.table_name?`میز ${r(t.table_name)}`:e?.label||""}</div>
    <div class="row muted"><span>${r(t.waiter_name||"")}</span><span>${v(t.created_at)}</span></div><hr>
    <table>${t.items.filter(i=>!i.is_void).map(i=>`<tr><td class="big"><b>${u(i.qty)}×</b> ${r(i.name)}
      ${i.modifiers?.length?`<div class="mods" style="font-size:13px">${r(T(i.modifiers))}</div>`:""}
      ${i.note?`<div class="mods" style="font-size:13px">📝 ${r(i.note)}</div>`:""}</td></tr>`).join("")}</table>
    ${t.note?`<hr><div>📝 ${r(t.note)}</div>`:""}`;h(s,{title:`kitchen-${t.order_number}`})}function Q(t,n){const e=n||{},s=Object.entries(t.payments||{}).map(([a,l])=>`<div class="row"><span>${y[a]?.label||a}</span><span>${o(l)}</span></div>`).join(""),i=`${w(e)}<hr><div class="c b">گزارش شیفت صندوق #${u(t.id)}</div>
    ${t.register_name?`<div class="c">${r(t.register_name)}</div>`:""}
    <div class="row muted"><span>باز: ${r(t.opened_by)}</span><span>${v(t.opened_at)}</span></div>
    ${t.closed_at?`<div class="row muted"><span>بسته: ${r(t.closed_by)}</span><span>${v(t.closed_at)}</span></div>`:""}<hr>
    <div class="row"><span>تعداد سفارش</span><span>${u(t.orders)}</span></div>
    ${s}${t.total_sales!=null?`<div class="row total"><span>جمع فروش</span><span>${o(t.total_sales)}</span></div>`:""}
    <div class="row"><span>موجودی اول شیفت</span><span>${o(t.opening_cash)}</span></div>
    <div class="row"><span>واریز به صندوق</span><span>${o(t.cash_in)}</span></div>
    <div class="row"><span>برداشت از صندوق</span><span>${o(t.cash_out)}</span></div>
    ${t.expected_cash!=null?`<div class="row b"><span>نقد مورد انتظار</span><span>${o(t.expected_cash)}</span></div>`:'<div class="c muted">شمارش کور: نقد مورد انتظار پس از بستن صندوق</div>'}
    ${t.counted_cash!=null?`<div class="row"><span>نقد شمارش‌شده</span><span>${o(t.counted_cash)}</span></div>
    <div class="row b"><span>مغایرت</span><span>${o(t.difference)}</span></div>`:""}`;h(i,{title:`shift-${t.id}`})}function X(t,n){const e=n||{},s=t.data||{},i=s.orders||{},a=(p,f)=>`<div class="row"><span>${p}</span><span>${f}</span></div>`,l=p=>p==null?"—":`${u(Math.floor(p/60))}:${u(p%60).padStart(2,"۰")}`,c=p=>p==null?"پنهان":o(p),d=`${w(e)}<hr><div class="c b">گزارش پایان شیفت</div>
    <div class="c big b">${r(t.name||"")}</div>${t.role?`<div class="c muted">${r(t.role)}</div>`:""}
    ${a("از",v(t.period_start))}${a("تا",v(t.period_end))}${a("مدت حضور",l(s.minutes))}<hr>
    ${a(`سفارش تسویه‌شده (${u(i.closed)})`,o(i.sales))}${i.closed?a("میانگین فاکتور",o(i.avg)):""}
    ${i.open?a("⚠ سفارش باز",u(i.open)):""}${i.cancelled?a("سفارش لغوشده",u(i.cancelled)):""}<hr>
    <div class="b">دریافت‌ها</div>${Object.entries(s.payments||{}).map(([p,f])=>a(y[p]?.label||p,c(f))).join("")||'<div class="muted">—</div>'}
    ${s.refunds?.count?a(`بازپرداخت (${u(s.refunds.count)})`,`−${o(s.refunds.amount)}`):""}
    <div class="row total"><span>جمع دریافتی</span><span>${c(s.collected_total)}</span></div><hr>
    ${a(`تخفیف (${u(s.discounts?.count)})`,o(s.discounts?.amount))}${a(`حذف آیتم (${u(s.voids?.count)})`,o(s.voids?.amount))}
    ${a(`لغو سفارش (${u(s.cancels?.count)})`,o(s.cancels?.amount))}
    ${(s.drawers_closed||[]).map(p=>`<hr><div class="b">تحویل صندوق ${r(p.register_name||"")}</div>${a("شمارش‌شده",o(p.counted_cash))}${a("مورد انتظار",o(p.expected_cash))}
      <div class="row b"><span>مغایرت</span><span>${p.difference>0?"+":""}${o(p.difference)}</span></div>`).join("")}
    ${s.drawer?`<hr><div class="c b">⚠ صندوق ${r(s.drawer.register_name||"")} هنوز تحویل نشده</div>`:""}
    ${(s.open_orders||[]).length?`<hr><div class="b">سفارش‌های باز</div>${s.open_orders.map(p=>a(`#${u(p.number)}${p.table?` میز ${r(p.table)}`:""}`,o(p.total-p.paid))).join("")}`:""}
    ${t.note?`<hr><div class="b">یادداشت</div><div>${r(t.note)}</div>`:""}
    ${t.acknowledged_by?`<hr><div>تأیید مدیر: ${r(t.acknowledged_by)} — ${v(t.acknowledged_at)}</div>${t.manager_note?`<div>${r(t.manager_note)}</div>`:""}`:""}
    <hr><div class="c muted">امضای کارمند ............ امضای مدیر ............</div>`;h(d,{title:`staff-report-${t.id||"live"}`})}function k(t,n,e){const s=n||{},i=t.summary,a=(c,d)=>`<div class="row"><span>${c}</span><span>${d}</span></div>`,l=`${w(s)}<hr>
    <div class="c b">گزارش پایان روز (Z)</div>
    <div class="c">${P(t.day)}</div>
    <div class="c muted">چاپ: ${v(new Date)}${e?` — ${r(e)}`:""}</div><hr>
    ${a("تعداد فاکتور",u(i.orders))}${a("تعداد مهمان (سالن)",u(i.guests))}
    ${a("فروش ناخالص",o(i.gross))}${a("تخفیف",`−${o(i.discounts)}`)}
    ${i.service?a("حق سرویس",o(i.service)):""}${i.tax?a("مالیات",o(i.tax)):""}
    <div class="row total"><span>فروش خالص</span><span>${o(i.net)}</span></div>
    ${a("میانگین فاکتور",o(i.avg_ticket))}
    ${i.refunds?a("بازپرداخت",`−${o(i.refunds)}`):""}<hr>
    <div class="b">روش پرداخت</div>${t.by_payment.map(c=>a(r(c.label),o(c.amount))).join("")||'<div class="muted">—</div>'}<hr>
    <div class="b">نوع سفارش</div>${t.by_type.map(c=>a(`${r(c.label)} (${u(c.orders)})`,o(c.revenue))).join("")||'<div class="muted">—</div>'}<hr>
    <div class="b">کنترل</div>
    ${a(`تخفیف (${u(t.discounts.orders)} فاکتور)`,`${o(t.discounts.total)} — ${u(t.discounts.pct,1)}٪`)}
    ${a(`آیتم حذف‌شده (${u(t.voids.count)})`,o(t.voids.amount))}
    ${a(`سفارش لغوشده (${u(i.cancelled)})`,o(i.cancelled_amount))}
    ${t.open_orders?a("⚠ سفارش باز (تسویه‌نشده)",u(t.open_orders)):""}
    ${t.shifts.length?t.shifts.map(c=>a(`صندوق ${r(c.closed_by||"")} — مغایرت`,`${c.difference>0?"+":""}${o(c.difference)}`)).join(""):""}<hr>
    <div class="b">پرفروش‌ترین‌ها</div>${t.top_items.map((c,d)=>a(`${u(d+1)}. ${r(c.name)} ×${u(c.qty)}`,o(c.revenue))).join("")||'<div class="muted">—</div>'}
    ${t.discounts.by_reason.length?`<hr><div class="b">دلایل تخفیف</div>${t.discounts.by_reason.map(c=>a(`${r(c.reason)} (${u(c.count)})`,o(c.amount))).join("")}`:""}
    <hr><div class="c muted">امضای صندوقدار ............ امضای مدیر ............</div>`;h(l,{title:`z-${t.day}`})}export{X as a,N as b,Q as c,k as d,h as e,J as p};
