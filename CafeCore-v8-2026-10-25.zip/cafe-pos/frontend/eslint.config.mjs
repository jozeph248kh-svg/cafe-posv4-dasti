import js from '@eslint/js'
import globals from 'globals'
import reactHooks from 'eslint-plugin-react-hooks'
import react from 'eslint-plugin-react'

// Deliberately narrow: this config only guards React correctness and dead code, so `npm run lint`
// is useful on day one instead of drowning in style noise. Formatting is not enforced here.
export default [
  // vendored third-party file, kept as-is except for the calendar math (see its header)
  { ignores: ['dist/**', 'node_modules/**', 'shots/**', 'coverage/**', 'src/core/vendor/**'] },
  js.configs.recommended,
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'module',
      globals: { ...globals.browser, ...globals.node },
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    plugins: { 'react-hooks': reactHooks, react },
    rules: {
      ...reactHooks.configs.recommended.rules,
      // Known pattern in this codebase (≈20 dialogs copy their props into local state when they
      // open). It works, it is just not the modern shape — reported as a warning, to be cleaned up
      // while touching those components, not as a merge blocker.
      'react-hooks/set-state-in-effect': 'warn',
      // mark JSX components as "used" (core no-unused-vars doesn't know JSX); React 17+ transform
      'react/jsx-uses-vars': 'error',
      'react/jsx-uses-react': 'off',
      'no-unused-vars': ['warn', { args: 'none', varsIgnorePattern: '^_', caughtErrors: 'none' }],
      'no-empty': ['warn', { allowEmptyCatch: true }],
    },
  },
]
