import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { fileURLToPath, URL } from 'node:url'

// `antd-jalali` imports the `jalaliday` package internally for its date pickers. Redirect that
// import (and ours) to the vendored copy whose calendar math is correct — see the header of
// src/core/vendor/jalaliday.js for the why.
const jalalidayVendored = fileURLToPath(new URL('./src/core/vendor/jalaliday.js', import.meta.url))

const API = process.env.API_URL || 'http://127.0.0.1:8000'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      jalaliday: jalalidayVendored,
      // under vitest (Node ESM) antd's `es` build cannot resolve its own extensionless imports;
      // its CommonJS build can. The production build keeps using `es`.
      ...(process.env.VITEST ? { antd: 'antd/lib' } : {}),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api': API,
      '/uploads': API,
      '/ws': { target: API.replace('http', 'ws'), ws: true },
    },
  },
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.js'],
    include: ['src/**/*.test.{js,jsx}'],
    css: false,
    // antd dialogs mount slowly under jsdom (every render calls getComputedStyle); the default 5s
    // is not enough for a test that opens a modal and types into a form.
    testTimeout: 20000,
    // What counts towards coverage: application code. Excluded (with a reason):
    //  - src/core/vendor/**  → third-party jalaliday, kept as-is except the calendar math
    //  - src/test/**         → the test harness itself
    //  - src/main.jsx        → the entry point, exercised by the build, not by unit tests
    coverage: {
      provider: 'v8',
      include: ['src/**/*.{js,jsx}'],
      exclude: ['src/core/vendor/**', 'src/test/**', 'src/main.jsx', 'src/**/*.test.{js,jsx}'],
      reporter: ['text-summary', 'text', 'json-summary'],
      reportsDirectory: './coverage',
      // A ratchet, not a target: CI fails if coverage drops below what is covered today.
      // Raise these numbers whenever a batch of tests lands (see REPORT-STEP6.md for the plan).
      thresholds: { lines: 59, statements: 51, functions: 41, branches: 50 },
    },
  },
  build: {
    // The prebuilt UI is committed (the shop PC has no Node.js). The folder is deliberately NOT
    // called `dist`: build caches / snapshots / some deployment tools drop `dist` folders silently,
    // which is how the shipped bundle lost its UI twice. `ui` is never excluded.
    outDir: 'ui',
    emptyOutDir: true,
    chunkSizeWarningLimit: 2500,
    rollupOptions: {
      output: {
        manualChunks: { antd: ['antd', '@ant-design/icons'], charts: ['recharts'], react: ['react', 'react-dom', 'react-router-dom'] },
      },
    },
  },
})
