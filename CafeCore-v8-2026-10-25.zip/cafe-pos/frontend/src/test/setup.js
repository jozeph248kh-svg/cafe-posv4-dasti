import { beforeEach } from "vitest"

// jsdom gaps used by antd
if (!window.matchMedia) {
  window.matchMedia = (query) => ({
    matches: false, media: query, onchange: null,
    addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}, dispatchEvent() { return false },
  })
}
if (!window.ResizeObserver) {
  window.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} }
}
// jsdom has no canvas and cannot resolve pseudo-elements. recharts (the charts in Reports/Insights/dashboard)
// asks for both on every render; jsdom then reports them as *unhandled* errors, which vitest counts as run
// errors and — depending on timing — turns a green run into a failed one (it flaked for exactly this reason).
// Both calls are stubs here, so returning null / dropping the pseudo argument changes nothing for the code.
if (!window.HTMLCanvasElement.prototype.getContext) {
  window.HTMLCanvasElement.prototype.getContext = () => null
} else {
  window.HTMLCanvasElement.prototype.getContext = () => null
}
{
  const native = window.getComputedStyle.bind(window)
  window.getComputedStyle = (el) => native(el)
}
beforeEach(() => localStorage.clear())

// vitest runs without globals in this project, so @testing-library/react cannot register its own
// auto-cleanup; without this every render stays in the document and queries find leftovers.
import { afterEach } from 'vitest'
import { cleanup } from '@testing-library/react'
afterEach(() => cleanup())

// antd pages load in two hops (roles → users, floor → orders …); the default 1s waitFor timeout is
// too tight under jsdom, and a longer one only costs time when something is genuinely broken.
import { configure } from '@testing-library/dom'
configure({ asyncUtilTimeout: 5000 })
