import { ClockCircleOutlined, LockOutlined, NumberOutlined, UserOutlined } from '@ant-design/icons'
import { Alert, App, Button, Form, Input, Segmented, Space, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import PinPad from '../components/PinPad'
import { clock, hm } from '../components/TimeClockButton'
import { get, post } from '../core/api'
import { useAuth } from '../core/auth'

export default function Login() {
  const auth = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const { message } = App.useApp()
  const [mode, setMode] = useState(localStorage.getItem('cafe_login_mode') || 'pin')
  const [loading, setLoading] = useState(false)
  const [pinErr, setPinErr] = useState(null)
  const [punched, setPunched] = useState(null)  // last time-clock punch shown on the terminal
  const [needReport, setNeedReport] = useState(null)  // clock-out refused: { pin, message } → sign in to «شیفت من»
  const [opts, setOpts] = useState(null)        // { pin_enabled, sample_users } — what this install actually has

  useEffect(() => {
    get('/staff/auth/options').then((o) => {
      setOpts(o)
      if (!o.pin_enabled) setMode('pass')       // nobody has a PIN yet: the PIN pad can't work
    }).catch(() => {})
  }, [])

  if (auth.ready && auth.user) return <Navigate to={loc.state?.from || '/'} replace />

  const done = (u) => {
    message.success(`${u.full_name}، خوش آمدید`)
    nav(loc.state?.from || '/', { replace: true })
  }
  const pin = async (p) => {
    setLoading(true)
    try { done(await auth.pinLogin(p)) } catch (e) { setPinErr(Date.now()); message.error(e.message) } finally { setLoading(false) }
  }
  const pass = async (v) => {
    setLoading(true)
    try { done(await auth.login(v.username, v.password)) } catch (e) { message.error(e.message) } finally { setLoading(false) }
  }
  const switchMode = (m) => { setMode(m); setPunched(null); setNeedReport(null); if (m !== 'clock') localStorage.setItem('cafe_login_mode', m) }
  const punch = async (p) => {
    setLoading(true)
    try {
      const r = await post('/timeclock/punch', { pin: p })
      setPunched(r)
      setTimeout(() => setPunched((x) => (x === r ? null : x)), 6000)
    } catch (e) {
      if (['shift_report_required', 'drawer_open'].includes(e.code)) {
        const n = { pin: p, message: e.message }
        setNeedReport(n)
        setTimeout(() => setNeedReport((x) => (x === n ? null : x)), 30_000)   // don't keep the PIN around
      } else { setPinErr(Date.now()); message.error(e.message) }
    } finally { setLoading(false) }
  }
  const toReport = async () => {
    setLoading(true)
    try {
      const u = await auth.pinLogin(needReport.pin)
      setNeedReport(null)
      message.success(`${u.full_name}، گزارش پایان شیفت را کامل کنید`)
      nav('/my-shift', { replace: true })
    } catch (e) { message.error(e.message); setNeedReport(null) } finally { setLoading(false) }
  }
  const canClock = opts?.timeclock && opts?.pin_enabled

  return (
    <div className="login-bg">
      <div className="login-card fade-in">
        <div className="login-side">
          <div className="login-steam" aria-hidden><i /><i /><i /></div>
          <div className="login-cup" aria-hidden>☕</div>
          <div className="login-logo">☕</div>
          <Typography.Title level={1} style={{ color: '#fff', margin: '18px 0 6px', fontWeight: 900, position: 'relative' }}>کافه‌پوز</Typography.Title>
          <Typography.Text style={{ color: 'rgba(255,255,255,.92)', fontSize: 16, position: 'relative' }}>سیستم یکپارچه مدیریت کافه و رستوران</Typography.Text>
          <ul className="login-feats">
            <li>🧾 صندوق فروش سریع و لمسی</li>
            <li>🔥 نمایشگر آشپزخانه به‌صورت زنده</li>
            <li>📦 انبار هوشمند بر اساس رسپی</li>
            <li>📊 گزارش‌های دقیق و لحظه‌ای</li>
            <li>📱 اجرا روی همه دستگاه‌های شبکه</li>
          </ul>
        </div>
        <div className="login-form">
          <Typography.Title level={2} style={{ marginTop: 0, textAlign: 'center', fontWeight: 900 }}>ورود به سیستم</Typography.Title>
          <Segmented block value={mode} onChange={switchMode} style={{ marginBottom: 24 }}
            options={[{ value: 'pin', label: 'کد ورود سریع', icon: <NumberOutlined /> }, { value: 'pass', label: 'نام کاربری و رمز', icon: <UserOutlined /> },
              ...(canClock ? [{ value: 'clock', label: 'حضور و غیاب', icon: <ClockCircleOutlined /> }] : [])]} />
          {mode === 'clock' && canClock ? (
            <>
              {needReport ? (
                <div className="punch-result report-needed">
                  <div className="big">📝</div>
                  <b>خروج هنوز ثبت نشد</b>
                  <div style={{ margin: '8px 0' }}>{needReport.message}</div>
                  <Space wrap style={{ justifyContent: 'center' }}>
                    <Button type="primary" loading={loading} onClick={toReport} className="to-report">ورود و ارسال گزارش</Button>
                    <Button onClick={() => setNeedReport(null)}>انصراف</Button>
                  </Space>
                </div>
              ) : punched ? (
                <div className={`punch-result ${punched.action}`}>
                  <div className="big">{punched.action === 'in' ? '👋' : '✅'}</div>
                  <b>{punched.name}</b>
                  <div>{punched.action === 'in' ? `ورود شما ساعت ${clock(punched.at)} ثبت شد` : `خروج ساعت ${clock(punched.at)} ثبت شد`}</div>
                  {punched.action === 'out' && <div className="muted">مدت حضور: {hm(punched.minutes)}{punched.over_limit ? ' (بیش از سقف شیفت — مدیر بررسی کند)' : ''}</div>}
                  <Button style={{ marginTop: 14 }} onClick={() => setPunched(null)}>نفر بعدی</Button>
                </div>
              ) : <PinPad onSubmit={punch} loading={loading} error={pinErr} />}
              <Typography.Paragraph type="secondary" style={{ textAlign: 'center', marginTop: 16, fontSize: 12 }}>
                برای ثبت ورود یا خروج، کد شخصی خود را وارد کنید؛ وارد برنامه نمی‌شوید.
              </Typography.Paragraph>
            </>
          ) : mode === 'pin' ? (
            <>
              {opts && !opts.pin_enabled ? (
                <Alert type="info" showIcon style={{ marginBottom: 16 }} message="هنوز کد ورود سریع تعریف نشده است"
                  description={<>
                    ورود با کد، بعد از تعریف کد برای کاربران فعال می‌شود: با نام کاربری و رمز وارد شوید، سپس از بخش <b>پرسنل</b> برای هر نفر یک کد ۴ تا ۸ رقمی بگذارید.
                    <div style={{ marginTop: 10 }}><Button type="primary" size="small" onClick={() => switchMode('pass')}>ورود با نام کاربری و رمز</Button></div>
                  </>} />
              ) : (
                <>
                  <PinPad onSubmit={pin} loading={loading} error={pinErr} />
                  <Typography.Paragraph type="secondary" style={{ textAlign: 'center', marginTop: 16, fontSize: 12 }}>
                    کد ورود خود را وارد کنید{opts?.sample_users && ' (کاربران نمونه: مدیر ۱۱۱۱، صندوقدار ۳۳۳۳، گارسون ۴۴۴۴، آشپزخانه ۶۶۶۶)'}
                  </Typography.Paragraph>
                </>
              )}
            </>
          ) : (
            <Form layout="vertical" size="large" onFinish={pass} initialValues={{ username: '', password: '' }}>
              <Form.Item name="username" label="نام کاربری" rules={[{ required: true, message: 'نام کاربری را وارد کنید' }]}>
                <Input prefix={<UserOutlined />} autoFocus className="ltr" autoComplete="username" />
              </Form.Item>
              <Form.Item name="password" label="رمز عبور" rules={[{ required: true, message: 'رمز عبور را وارد کنید' }]}>
                <Input.Password prefix={<LockOutlined />} className="ltr" autoComplete="current-password" />
              </Form.Item>
              <Button type="primary" htmlType="submit" block loading={loading}>ورود</Button>
              {opts && (opts.sample_users || !opts.pin_enabled) && (
                <Typography.Paragraph type="secondary" style={{ textAlign: 'center', marginTop: 16, fontSize: 12 }}>
                  {opts.sample_users ? 'کاربر نمونه: admin / admin123' : <>اولین ورود: <span className="ltr">admin / admin123</span> — بلافاصله رمز جدید خواسته می‌شود</>}
                </Typography.Paragraph>
              )}
            </Form>
          )}
        </div>
      </div>
    </div>
  )
}
