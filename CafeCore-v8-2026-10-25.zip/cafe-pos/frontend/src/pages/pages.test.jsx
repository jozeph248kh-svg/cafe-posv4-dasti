import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

/**
 * The three entry screens: login (password + PIN + forced password change), the launcher (which app
 * to open) and «شیفت من» (the end-of-shift report a waiter must file before clocking out).
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
const auth = {
  user: null, ready: true, mustChange: false, system: { modules: ['orders', 'kitchen', 'shifts', 'reports'], settings: {} },
  settings: { 'business.name': 'کافه ونک', 'shift.hours': 8 }, hasModule: () => true, can: () => true, canAny: () => true,
  login: vi.fn(() => Promise.resolve()), pinLogin: vi.fn(() => Promise.resolve()),
  changePassword: vi.fn(() => Promise.resolve()), logout: vi.fn(), reloadSystem: vi.fn(() => Promise.resolve()),
}
vi.mock('../core/auth', () => ({ useAuth: () => auth }))
vi.mock('../core/realtime', () => ({ useWsStatus: () => 'online', useRealtime: () => {}, beep: () => {} }))
vi.mock('../core/print', () => ({ printShift: vi.fn(), printStaffReport: vi.fn(), printReceipt: vi.fn(), printHtml: vi.fn() }))
// these screens read the palette from the theme context
vi.mock('../core/theme', async () => {
  const { findSkin } = await import('../core/skins')
  const skin = findSkin('classic')
  return {
    useTheme: () => ({ vars: {}, dark: false, skin, chart: ['#111'], accent: '#4f46e5', setMode: vi.fn() }),
    useChart: () => ({ c: ['#111'], accent: '#4f46e5' }),
  }
})

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const at = (path) => render(<MemoryRouter initialEntries={[path]}><App>{null}</App></MemoryRouter>)

describe('Login', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); auth.login.mockClear(); auth.pinLogin.mockClear() })

  it('signs in with username and password', async () => {
    get.mockResolvedValue({ pin_enabled: false, sample: false })
    localStorage.setItem('cafe_login_mode', 'pass')
    const { default: Login } = await import('./Login')
    render(<MemoryRouter><App><Login /></App></MemoryRouter>)
    await waitFor(() => expect(document.querySelectorAll('input').length).toBeGreaterThan(1))
    // the PIN pad also renders an input; target the labelled fields of the password form
    fireEvent.change(screen.getByLabelText('نام کاربری'), { target: { value: 'admin' } })
    fireEvent.change(screen.getByLabelText('رمز عبور'), { target: { value: 'admin123' } })
    fireEvent.submit(document.querySelector('form'))
    await waitFor(() => expect(auth.login).toHaveBeenCalledWith('admin', 'admin123'))
  })

  it('offers the PIN pad when PIN login is enabled', async () => {
    get.mockResolvedValue({ pin_enabled: true, sample: false })
    const { default: Login } = await import('./Login')
    render(<MemoryRouter><App><Login /></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('رمز'))
    const pinTab = [...document.querySelectorAll('.ant-segmented-item-label, .ant-tabs-tab')].map((t) => t.textContent).join(' ')
    expect(pinTab.length).toBeGreaterThan(0)
  })
})

describe('Launcher', () => {
  beforeEach(() => {
    auth.user = { id: 1, full_name: 'رضا', permissions: ['pos.access', 'kitchen.access'] }
    auth.mustChange = false
    get.mockResolvedValue([])
  })

  it('offers only the apps the user may open', async () => {
    const { default: Launcher } = await import('./Launcher')
    render(<MemoryRouter><App><Launcher /></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('کافه ونک'))
    expect(text()).toContain('صندوق')
    expect(text()).toContain('آشپزخانه')
  })
})

describe('MyShift', () => {
  beforeEach(() => {
    get.mockReset(); post.mockReset()
    auth.user = { id: 1, full_name: 'علی', permissions: ['pos.access'] }
    auth.mustChange = false
  })

  it('shows what still blocks clocking out', async () => {
    get.mockImplementation((path) => {
      if (path === '/shifts/my-report') return Promise.resolve({
        status: { on_clock: true, clock_in: new Date(Date.now() - 2 * 3600000).toISOString(), shift_hours: 8, can_clock_out: false, last_report: null },
        data: { drawer: null, report: null },
      })
      if (path === '/timeclock/me') return Promise.resolve({ on_clock: true, since: new Date(Date.now() - 3600000).toISOString() })
      return Promise.resolve([])
    })
    const { default: MyShift } = await import('./MyShift')
    render(<MemoryRouter><App><MyShift /></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('شیفت'))
  })
})
