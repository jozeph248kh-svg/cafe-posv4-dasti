import ChangePasswordModal from '../components/ChangePasswordModal'
import { ArrowLeftOutlined, KeyOutlined, LogoutOutlined, WifiOutlined } from '@ant-design/icons'
import { Avatar, Button, Card, Col, QRCode, Row, Skeleton, Space, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ConnectionBadge from '../components/ConnectionBadge'
import TimeClockButton from '../components/TimeClockButton'
import { useAuth } from '../core/auth'
import { colorOf, compact, faToday, initials, money, num } from '../core/format'
import { useTheme } from '../core/theme'
import ThemeSwitcher from '../components/ThemeSwitcher'
import { useFetch } from '../core/useFetch'
import { APPS, visible } from '../modules/registry'

/** Live numbers strip — only for users who may see the dashboard (same endpoint & permission). */
function LiveStats({ d, loading }) {
  if (loading && !d) return <div className="l-stats">{[0, 1, 2, 3].map((i) => <div key={i} className="l-stat"><Skeleton active paragraph={{ rows: 1 }} title={false} /></div>)}</div>
  if (!d) return null
  const t = d.today || {}, y = d.yesterday || {}, live = d.live || {}
  const delta = y.net > 0 ? ((t.net - y.net) / y.net) * 100 : null
  const big = (v) => (Math.abs(v) >= 1e9 ? compact(v) : money(v))
  return (
    <div className="l-stats">
      <div className="l-stat hero">
        <span>فروش امروز</span>
        <b className="money">{big(t.net || 0)}<small>تومان</small></b>
        <small>{num(t.orders || 0)} سفارش{delta !== null && <> · <span className={delta >= 0 ? 'up' : 'down'}>{delta >= 0 ? '▲' : '▼'} {num(Math.abs(delta), 0)}٪</span> نسبت به دیروز</>}</small>
      </div>
      <div className="l-stat" style={{ animationDelay: '60ms' }}>
        <span>سفارش‌های باز</span>
        <b className="money">{num(live.open_orders || 0)}</b>
        <small>{big(live.open_amount || 0)} تومان در جریان</small>
      </div>
      <div className="l-stat" style={{ animationDelay: '120ms' }}>
        <span>میزهای اشغال</span>
        <b className="money">{num(live.occupied_tables || 0)}</b>
        <small>{num(live.guests || 0)} مهمان حاضر</small>
      </div>
      <div className="l-stat" style={{ animationDelay: '180ms' }}>
        <span>تیکت‌های آشپزخانه</span>
        <b className="money">{num(live.active_tickets || 0)}</b>
        <small>{live.late > 0 ? <span className="late">{num(live.late)} تیکت با تأخیر</span> : 'همه به‌موقع'}</small>
      </div>
    </div>
  )
}

export default function Launcher() {
  const [pwd, setPwd] = useState(false)
  const auth = useAuth()
  const nav = useNavigate()
  const { vars } = useTheme()
  const apps = APPS.filter((a) => visible(auth, a))
  const lan = auth.system.lan_urls || []
  const hour = new Date().getHours()
  const greet = hour < 12 ? 'صبح بخیر' : hour < 17 ? 'روز بخیر' : 'عصر بخیر'
  const showStats = auth.hasModule('reports') && auth.can('dashboard.view')
  const stats = useFetch('/reports/dashboard', null, { skip: !showStats })
  useEffect(() => {
    if (!showStats) return undefined
    const t = setInterval(() => stats.reload(true), 60000)
    return () => clearInterval(t)
  }, [showStats, stats.reload]) // eslint-disable-line react-hooks/exhaustive-deps
  const live = stats.data?.live
  const liveOf = (key) => {
    if (!live) return null
    if (key === 'pos' && live.open_orders) return { text: `${num(live.open_orders)} سفارش باز` }
    if (key === 'kds' && live.active_tickets) return { text: `${num(live.active_tickets)} تیکت فعال`, hot: live.late > 0 }
    return null
  }

  return (
    <div className="launcher">
      <div className="launcher-top">
        <Space size={14}>
          <Avatar size={54} shape="square" style={{ background: colorOf(auth.user.full_name), fontSize: 19, borderRadius: 18 }}>{initials(auth.user.full_name)}</Avatar>
          <div>
            <Typography.Title level={3} style={{ margin: 0, fontWeight: 900 }}>{greet}، {auth.user.full_name}</Typography.Title>
            <Typography.Text type="secondary">{auth.user.role_title} · {faToday()}</Typography.Text>
          </div>
        </Space>
        <Space wrap>
          <TimeClockButton />
          <ConnectionBadge label />
          <ThemeSwitcher type="default" />
          <Tooltip title="تغییر رمز عبور"><Button icon={<KeyOutlined />} onClick={() => setPwd(true)} /></Tooltip>
          <Button danger icon={<LogoutOutlined />} onClick={() => { auth.logout(); nav('/login') }}>خروج</Button>
          <ChangePasswordModal open={pwd} onClose={() => setPwd(false)} />
        </Space>
      </div>
      <div className="l-wrap">
        {showStats && <LiveStats d={stats.data} loading={stats.loading} />}
        <div className="l-title"><h2>{auth.settings['business.name']}</h2><span>بخش موردنظر را انتخاب کنید</span></div>
        <Row gutter={[18, 18]}>
          {apps.map((a, i) => {
            const lv = liveOf(a.key)
            return (
              <Col key={a.key} xs={24} sm={12} lg={8}>
                <Card hoverable className="app-tile fade-in" onClick={() => nav(a.path)} style={{ '--c': a.color, animationDelay: `${i * 50}ms` }} styles={{ body: { padding: 24 } }}>
                  <div className="app-tile-icon">{a.icon}</div>
                  <div className="app-tile-body">
                    <h4>{a.title}</h4>
                    <p>{a.desc}</p>
                  </div>
                  {lv && <span className={`app-tile-live ${lv.hot ? 'hot' : ''}`}>{lv.text}</span>}
                  <ArrowLeftOutlined className="app-tile-arrow" />
                </Card>
              </Col>
            )
          })}
        </Row>
        {lan.length > 0 && (
          <Card className="lan-card fade-in" styles={{ body: { padding: 20 } }}>
            <Space align="center" size={20} wrap>
              <QRCode value={lan[0]} size={110} bordered={false} color={vars['--text']} />
              <div>
                <Typography.Title level={5} style={{ marginTop: 0 }}><WifiOutlined /> اتصال سایر دستگاه‌ها</Typography.Title>
                <Typography.Paragraph type="secondary" style={{ marginBottom: 8 }}>
                  تبلت آشپزخانه، گوشی گارسون‌ها و سایر کامپیوترها (متصل به همین شبکه/وای‌فای) با اسکن کد یا وارد کردن این آدرس در مرورگر وارد شوند:
                </Typography.Paragraph>
                <Space wrap>{lan.map((u) => <Tag key={u} className="ltr url-latin" style={{ fontSize: 14, padding: '4px 10px' }}>{u}</Tag>)}</Space>
              </div>
            </Space>
          </Card>
        )}
      </div>
    </div>
  )
}
