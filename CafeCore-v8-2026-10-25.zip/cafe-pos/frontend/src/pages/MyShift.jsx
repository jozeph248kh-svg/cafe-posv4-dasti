import { ArrowRightOutlined, CheckCircleOutlined, ClockCircleOutlined, LockOutlined, LogoutOutlined, PrinterOutlined, SendOutlined } from '@ant-design/icons'
import { Alert, App, Avatar, Button, Card, Input, Progress, Space, Spin, Steps, Tag, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DrawerCloseModal from '../components/DrawerCloseModal'
import StaffReportView from '../components/StaffReportView'
import { hm } from '../components/TimeClockButton'
import { get, post } from '../core/api'
import { useAuth } from '../core/auth'
import { colorOf, faDateTime, faTime, initials, minutesSince, money, num } from '../core/format'
import { printStaffReport } from '../core/print'
import { useRealtime } from '../core/realtime'
import { clockOutBlockers, diffInfo, shiftProgress } from '../core/shiftview'
import { useFetch } from '../core/useFetch'

/** «شیفت من» — every employee: live result of the current shift, drawer hand-over (blind count), end-of-shift
 *  report to the manager and clock-out. */
export default function MyShift() {
  const auth = useAuth()
  const nav = useNavigate()
  const { message, modal } = App.useApp()
  const rep = useFetch('/shifts/my-report')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(null)
  const [drawerShift, setDrawerShift] = useState(null)
  const [, tick] = useState(0)
  useRealtime(['order.changed', 'shift.changed', 'staff_report.submitted'], () => rep.reload(true))
  useEffect(() => { const t = setInterval(() => tick((x) => x + 1), 60_000); return () => clearInterval(t) }, [])

  if (!rep.data) return <div className="launcher"><Spin style={{ display: 'block', margin: '30vh auto' }} /></div>
  const { status: st, data: d } = rep.data
  const worked = st.on_clock ? minutesSince(st.clock_in) : null
  const prog = shiftProgress(worked, st.shift_hours)
  const blockers = clockOutBlockers(st, d)
  const canClose = auth.can('shifts.manage')
  const step = d.drawer ? 0 : (st.last_report && st.can_clock_out) ? 2 : 1

  const openDrawer = async () => {
    try {
      const s = await get('/shifts/current', { register_id: d.drawer.register_id })
      if (!s) { rep.reload(); return }
      setDrawerShift(s)
    } catch (e) { message.error(e.message) }
  }
  const afterClose = (closed) => {
    setDrawerShift(null)
    const x = diffInfo(closed.difference)
    if (closed.difference) setNote((n) => `${n ? `${n}\n` : ''}${x.text} (صندوق ${closed.register_name || ''}) — توضیح: `)
    rep.reload()
  }
  const submit = async (clockOut) => {
    setBusy(clockOut ? 'out' : 'send')
    try {
      const r = await post('/shifts/my-report', { note })
      message.success('گزارش پایان شیفت برای مدیر ارسال شد')
      if (clockOut) {
        const p = await post('/timeclock/me/punch')
        modal.success({
          title: 'شیفت شما پایان یافت', closable: true,
          content: <div>خروج ساعت {faTime(p.at)} ثبت شد — {hm(p.minutes)} حضور.<br />خسته نباشید!</div>,
          okText: 'خروج از حساب کاربری', onOk: () => { auth.logout(); nav('/login') },
          footer: (_, { OkBtn }) => <Space><Button onClick={() => printStaffReport(r, auth.settings)} icon={<PrinterOutlined />}>چاپ گزارش</Button><OkBtn /></Space>,
        })
      }
      rep.reload()
    } catch (e) {
      message.error(e.message)
      rep.reload()
    } finally { setBusy(null) }
  }
  const printNow = () => printStaffReport({ name: rep.data.name, role: rep.data.role, period_start: rep.data.period_start, period_end: rep.data.period_end, note, data: d }, auth.settings)

  return (
    <div className="launcher my-shift">
      <div className="launcher-top">
        <Space size={12}>
          <Button icon={<ArrowRightOutlined />} onClick={() => nav('/')}>بازگشت</Button>
          <Avatar size={44} style={{ background: colorOf(auth.user.full_name) }}>{initials(auth.user.full_name)}</Avatar>
          <div>
            <Typography.Title level={4} style={{ margin: 0 }}>شیفت من</Typography.Title>
            <Typography.Text type="secondary">{rep.data.name} · {rep.data.role} · از {faDateTime(rep.data.period_start)}</Typography.Text>
          </div>
        </Space>
        <Button icon={<PrinterOutlined />} onClick={printNow}>چاپ گزارش</Button>
      </div>

      <div className="my-shift-body">
        <Card className="card-r my-shift-head" styles={{ body: { padding: 20 } }}>
          <div className="my-shift-progress">
            {st.on_clock ? (
              <>
                <Progress type="circle" size={96} percent={prog.pct} status={prog.overdue ? 'exception' : 'active'}
                  format={() => <span style={{ fontSize: 15 }}>{num(Math.floor(worked / 60))}:{num(worked % 60).padStart(2, '۰')}</span>} />
                <div>
                  <Typography.Title level={5} style={{ margin: 0 }}><ClockCircleOutlined /> حاضر از ساعت {faTime(st.clock_in)}</Typography.Title>
                  <Typography.Text type={prog.overdue ? 'danger' : 'secondary'}>
                    {prog.overdue ? `شیفت ${num(st.shift_hours)} ساعته شما تمام شده است — گزارش را ارسال کنید` : `${hm(prog.left)} تا پایان شیفت ${num(st.shift_hours)} ساعته`}
                  </Typography.Text>
                </div>
              </>
            ) : (
              <Alert type="info" showIcon style={{ flex: 1 }} message={st.timeclock ? 'ورود شما در حضور و غیاب ثبت نشده است' : 'گزارش از ابتدای روز کاری'}
                description={st.timeclock ? 'گزارش از ابتدای روز کاری (یا آخرین گزارش شما) محاسبه می‌شود.' : undefined} />
            )}
          </div>
          <Steps size="small" current={step} className="my-shift-steps" items={[
            { title: 'تحویل صندوق', description: d.drawer ? 'صندوق به نام شما باز است' : (d.drawers_closed || []).length ? 'تحویل شد' : 'صندوقی ندارید', status: d.drawer ? 'process' : 'finish' },
            { title: 'ارسال گزارش', description: st.last_report ? `آخرین ارسال ${faTime(st.last_report.submitted_at)}${st.last_report.acknowledged ? ' — تأیید مدیر ✓' : ''}` : 'ارسال نشده' },
            ...(st.timeclock ? [{ title: 'ثبت خروج', description: st.on_clock ? (blockers.length ? '' : 'آماده') : 'ثبت شد / حاضر نیستید' }] : []),
          ]} />
        </Card>

        {d.drawer && (
          <Alert className="drawer-alert" type="error" showIcon style={{ marginTop: 16 }}
            message={`«${d.drawer.register_name || 'صندوق'}» به نام شما باز است`}
            description={canClose ? 'پیش از ارسال گزارش، پول صندوق را بشمارید و صندوق را تحویل دهید. شمارش کور است: مبلغ مورد انتظار پس از ثبت شمارش نمایش داده می‌شود.' : 'برای تحویل صندوق به مدیر مراجعه کنید.'}
            action={canClose && <Button danger type="primary" icon={<LockOutlined />} className="handover-btn" onClick={openDrawer}>شمارش و تحویل صندوق</Button>} />
        )}

        <div style={{ marginTop: 16 }}><StaffReportView data={d} /></div>

        <Card className="card-r submit-card" style={{ marginTop: 16 }} title={<span><SendOutlined /> ارسال گزارش به مدیر</span>}
          extra={st.last_report && <Tag color={st.last_report.acknowledged ? 'green' : 'gold'}>{st.last_report.acknowledged ? 'آخرین گزارش تأیید شد' : 'آخرین گزارش در انتظار بررسی'}</Tag>}>
          <Input.TextArea rows={3} maxLength={1000} showCount value={note} onChange={(e) => setNote(e.target.value)} className="report-note"
            placeholder="توضیحات برای مدیر: علت کسری/اضافه صندوق، سفارش‌های باز تحویل‌شده، کمبود مواد، خرابی دستگاه، اتفاقات شیفت…" />
          <Space wrap style={{ marginTop: 12 }}>
            <Button icon={<SendOutlined />} loading={busy === 'send'} disabled={!!d.drawer || !!busy} onClick={() => submit(false)} className="send-report">ارسال گزارش</Button>
            {st.timeclock && st.on_clock && (
              <Button type="primary" icon={<LogoutOutlined />} loading={busy === 'out'} disabled={!!d.drawer || !!busy} onClick={() => submit(true)} className="send-and-out">ارسال گزارش و ثبت خروج</Button>
            )}
            {d.drawer && <Typography.Text type="danger">ابتدا صندوق را تحویل دهید</Typography.Text>}
            {!d.drawer && (d.open_orders || []).length > 0 && <Typography.Text type="warning">{num(d.open_orders.length)} سفارش باز دارید ({money(d.open_orders.reduce((a, x) => a + x.total - x.paid, 0))} تومان مانده) — در یادداشت بنویسید به چه کسی تحویل شد</Typography.Text>}
            {st.last_report?.acknowledged && <Typography.Text type="success"><CheckCircleOutlined /> مدیر گزارش قبلی را دید</Typography.Text>}
          </Space>
        </Card>
      </div>
      <DrawerCloseModal open={!!drawerShift} shift={drawerShift} title={`تحویل صندوق — ${d.drawer?.register_name || ''}`}
        onClose={() => setDrawerShift(null)} onClosed={afterClose} />
    </div>
  )
}
