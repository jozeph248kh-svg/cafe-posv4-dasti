import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { get, getToken, post, setToken } from './api'
import { setBusinessCutoff } from './format'
import { startRealtime, stopRealtime } from './realtime'

const AuthCtx = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [ready, setReady] = useState(false)
  const [system, setSystem] = useState({ modules: [], settings: {} })

  const loadSystem = useCallback(async () => {
    const [info, settings] = await Promise.all([get('/system/info'), get('/system/settings')])
    setBusinessCutoff(settings?.['day.cutoff_hour'])
    setSystem({ ...info, modules: info.modules.map((m) => m.name), moduleInfo: info.modules, settings })
  }, [])

  const [mustChange, setMustChange] = useState(false)
  const accept = useCallback(async ({ token, user: u, must_change_password: pwc }) => {
    setToken(token)
    setUser(u)
    setMustChange(!!pwc)
    if (pwc) return u                     // restricted token: only the password change is allowed
    await loadSystem().catch(() => {})
    startRealtime()
    return u
  }, [loadSystem])

  const logout = useCallback(() => {
    setToken(null)
    setUser(null)
    setMustChange(false)
    stopRealtime()
  }, [])

  useEffect(() => {
    const onLogout = () => { setUser(null); stopRealtime() }
    window.addEventListener('auth:logout', onLogout)
    if (getToken()) {
      get('/staff/auth/me')
        .then(async (u) => {
          setUser(u)
          if (u.must_change_password) { setMustChange(true); return }
          await loadSystem().catch(() => {}); startRealtime()
        })
        .catch(() => setToken(null))
        .finally(() => setReady(true))
    } else setReady(true)
    return () => window.removeEventListener('auth:logout', onLogout)
  }, [loadSystem])

  const value = useMemo(() => ({
    user, ready, system, mustChange,
    changePassword: (current_password, new_password) => post('/staff/auth/password', { current_password, new_password }).then(accept),
    settings: system.settings || {},
    reloadSystem: loadSystem,
    hasModule: (m) => system.modules?.includes(m),
    can: (...perms) => !!user && perms.every((p) => user.permissions.includes(p)),
    canAny: (...perms) => !!user && perms.some((p) => user.permissions.includes(p)),
    login: (username, password) => post('/staff/auth/login', { username, password }).then(accept),
    pinLogin: (pin) => post('/staff/auth/pin', { pin }).then(accept),
    logout,
  }), [user, ready, system, mustChange, loadSystem, accept, logout])

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>
}

export const useAuth = () => useContext(AuthCtx)
