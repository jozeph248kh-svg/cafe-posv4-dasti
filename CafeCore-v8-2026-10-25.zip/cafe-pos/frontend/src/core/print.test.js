import { describe, expect, it } from 'vitest'
import { kitchenBlocks, receiptBlocks } from './print'

const order = {
  number: 14, type: 'takeaway', created_at: '2026-10-23T09:52:00', customer_name: 'مشتری',
  lines: [
    { name: 'املت', qty: 1, unit_price: 280000, status: 'served', modifiers: [] },
    { name: 'باطل‌شده', qty: 1, unit_price: 1, status: 'void' },
  ],
  subtotal: 280000, discount_amount: 0, line_discount_amount: 0, service_amount: 0, tax_amount: 28000, rounding: 0, total: 308000,
  payments: [{ method: 'cash', amount: 308000 }],
}
const texts = (blocks) => blocks.filter(Boolean).map((b) => `${b.text ?? ''}|${b.left ?? ''}`)

describe('thermal receipt layout', () => {
  it('has header, lines, totals and payments; skips empty rows and voided items', () => {
    const t = texts(receiptBlocks(order, { 'business.name': 'کافه', 'receipt.footer': 'ممنون 🌿' }, 'receipt'))
    expect(t[0]).toBe('کافه|')
    expect(t.some((x) => x.includes('املت') && x.endsWith('۲۸۰٬۰۰۰'))).toBe(true)
    expect(t.some((x) => x.includes('باطل‌شده'))).toBe(false)
    expect(t.some((x) => x.startsWith('مالیات'))).toBe(true)
    expect(t.some((x) => x.startsWith('حق سرویس'))).toBe(false)          // zero → omitted
    expect(t.some((x) => x.startsWith('مبلغ قابل پرداخت') && x.includes('۳۰۸٬۰۰۰'))).toBe(true)
    expect(t.some((x) => x.startsWith('نقد'))).toBe(true)
  })
  it('a bill (پیش‌فاکتور) has no payment rows', () => {
    const t = texts(receiptBlocks(order, {}, 'bill'))
    expect(t.some((x) => x.includes('پیش‌فاکتور'))).toBe(true)
    expect(t.some((x) => x.startsWith('نقد'))).toBe(false)
  })
  it('kitchen ticket: big number, table, items without prices', () => {
    const b = kitchenBlocks({ order_number: 7, order_type: 'dine_in', table_name: '۵', created_at: '2026-10-23T10:00:00',
      items: [{ name: 'پاستا', qty: 2, modifiers: [{ name: 'تند' }], note: 'بدون پنیر' }, { name: 'حذف', qty: 1, is_void: true }] }, 'گریل').filter(Boolean)
    expect(b[1]).toMatchObject({ text: '#۷', size: 56 })
    expect(b.some((x) => x.text === 'میز ۵')).toBe(true)
    expect(b.some((x) => x.text?.includes('پاستا') && x.left === undefined)).toBe(true)
    expect(b.some((x) => x.text?.includes('حذف'))).toBe(false)
    expect(b.some((x) => x.text?.includes('بدون پنیر'))).toBe(true)
  })
})
