/**
 * Limited offline mode: when the server can't be reached, new orders / added items are kept in this device's queue
 * (localStorage) and sent automatically when the connection returns. Every entry carries a request id, so a replay
 * never creates a second order or adds items twice (server: client_requests). Payments are never queued.
 */
import { ApiError, post } from './api'
import { subscribe } from './realtime'

const KEY = 'cafe_outbox'
const read = () => { try { return JSON.parse(localStorage.getItem(KEY)) || [] } catch { return [] } }
const write = (list) => { localStorage.setItem(KEY, JSON.stringify(list)); window.dispatchEvent(new Event('outbox:changed')) }

export const outboxList = read
/** The server wasn't reached (no response / gateway errors) — the outcome of a write is unknown, retry with the same id. */
export const isOffline = (e) => e instanceof ApiError && (e.status === 0 || [502, 503, 504].includes(e.status))

/** Can the server be reached right now? (browser offline flag + a short health ping; the live link alone can lag) */
export async function serverReachable(ms = 3000) {
  if (navigator.onLine === false) return false
  const ctl = new AbortController()
  const t = setTimeout(() => ctl.abort(), ms)
  try { return (await fetch('/api/health', { signal: ctl.signal, cache: 'no-store' })).ok } catch { return false } finally { clearTimeout(t) }
}

export function enqueue(entry) {
  write([...read().filter((x) => x.id !== entry.id), { ...entry, created_at: Date.now(), error: null }])
}
export function dropEntry(id) { write(read().filter((x) => x.id !== id)) }
const markError = (id, error) => write(read().map((x) => (x.id === id ? { ...x, error } : x)))

async function send(e) {
  // `merge_if_busy` only for an entry that was created for a table this device already owned: then the order that
  // appeared meanwhile is that same visit. See the fallback below for why it must not be used there.
  const create = (rid, merge = true) => post('/orders', { ...e.draft, lines: e.lines, send: e.send, request_id: rid, merge_if_busy: merge })
  if (e.kind !== 'lines') return create(e.id)
  try {
    return await post(`/orders/${e.order_id}/lines`, { lines: e.lines, send: e.send, request_id: e.id })
  } catch (err) {
    // The bill these lines belong to was paid/closed (or deleted) while the device was offline (N-06).
    // They belong to *that* bill — never to whoever sits at the table now — so ask for a NEW order
    // (merge_if_busy: false). If the table is still occupied the server refuses with `table_busy`, the entry
    // stays in the queue with a visible error and the cashier decides (retry after freeing the table / merge).
    // The derived id is stable, so a repeated attempt can never create the order twice.
    if (!['order_not_open', 'not_found'].includes(err.code)) throw err
    return create(`${e.id}c`, false)
  }
}

let flushing = false
/** Send queued entries in order. Stops at the first network failure; business errors are kept for the user. */
export async function flushOutbox() {
  if (flushing || !read().some((x) => !x.error)) return 0
  flushing = true
  let sent = 0
  try {
    for (const e of read()) {
      if (e.error) continue
      try {
        await send(e)
        dropEntry(e.id)
        sent++
      } catch (err) {
        if (isOffline(err) || err.status === 401) break
        markError(e.id, err.message)
      }
    }
  } finally { flushing = false }
  if (sent) window.dispatchEvent(new CustomEvent('outbox:sent', { detail: sent }))
  return sent
}

export function retryEntry(id) {
  write(read().map((x) => (x.id === id ? { ...x, error: null } : x)))
  return flushOutbox()
}

let started = false
/** Background sync: every 10 s while something is queued, when the browser comes online and when the live link reconnects. */
export function startOutbox() {
  if (started) return
  started = true
  setInterval(() => { if (read().length) flushOutbox() }, 10000)
  window.addEventListener('online', () => flushOutbox())
  subscribe('_reconnected', () => flushOutbox())
  flushOutbox()
}
