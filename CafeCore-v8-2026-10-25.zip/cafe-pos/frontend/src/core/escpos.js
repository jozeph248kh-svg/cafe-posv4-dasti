/**
 * Direct printing to network thermal printers (ESC/POS). The receipt is drawn on a canvas — the browser shapes Persian
 * text and handles RTL with the app's font — then turned into a 1-bit image and sent to the server, which forwards it
 * to the printer (TCP 9100). No print dialog, no driver on the device; works from tablets and phones too.
 *
 * Blocks: { text, align: 'right'|'center'|'left', size, bold } | { text, left, size, bold } (row: label … value)
 *         | { hr: 'dashed'|'solid' } | { img: url, maxWidth } | { space: px }
 */
import { post } from './api'
import { getRegisterId } from './register'

const FONT = '"Vazirmatn FD", Vazirmatn, Tahoma, sans-serif'
const PAD = 6
// emoji become black blobs on a 1-bit printer
const clean = (s) => String(s ?? '').replace(/\p{Extended_Pictographic}|\uFE0F/gu, '').replace(/\s+/g, ' ').trim()

function wrap(ctx, text, maxW) {
  const words = clean(text).split(' ')
  const out = []
  let cur = ''
  for (const w of words) {
    const t = cur ? `${cur} ${w}` : w
    if (cur && ctx.measureText(t).width > maxW) { out.push(cur); cur = w } else cur = t
  }
  if (cur || !out.length) out.push(cur)
  return out
}

const loadImg = (src) => new Promise((resolve) => {
  const i = new Image()
  i.onload = () => resolve(i)
  i.onerror = () => resolve(null)
  i.src = src
})

/** Render blocks to { width, height, data } — data: base64 of packed rows, MSB = leftmost pixel, 1 = black. */
export async function rasterize(blocks, width) {
  try { await document.fonts.load(`24px ${FONT}`); await document.fonts.load(`700 24px ${FONT}`) } catch { /* fallback font */ }
  const canvas = document.createElement('canvas')
  canvas.width = width
  let ctx = canvas.getContext('2d')
  ctx.direction = 'rtl'
  const font = (size, bold) => `${bold ? 700 : 400} ${size}px ${FONT}`
  const ops = []
  let y = PAD
  for (const b of blocks) {
    if (!b) continue
    if (b.space) { y += b.space; continue }
    if (b.hr) { ops.push({ hr: b.hr, y: y + 7 }); y += 16; continue }
    if (b.img) {
      const img = await loadImg(b.img)
      if (!img) continue
      const w = Math.min(img.width, (b.maxWidth || 0.5) * width)
      const h = Math.min(img.height * (w / img.width), 180)
      const w2 = img.width * (h / img.height)
      ops.push({ img, x: (width - w2) / 2, y, w: w2, h })
      y += h + 8
      continue
    }
    const size = b.size || 22
    const lh = Math.round(size * 1.5)
    ctx.font = font(size, b.bold)
    if (b.left !== undefined && b.left !== null) {
      const left = clean(b.left)
      const lw = ctx.measureText(left).width
      wrap(ctx, b.text, width - 2 * PAD - lw - 14).forEach((t, i) => {
        ops.push({ t, x: width - PAD, y: y + size, align: 'right', f: ctx.font })
        if (i === 0) ops.push({ t: left, x: PAD, y: y + size, align: 'left', f: ctx.font })
        y += lh
      })
    } else {
      const align = b.align || 'right'
      wrap(ctx, b.text, width - 2 * PAD).forEach((t) => {
        ops.push({ t, x: align === 'center' ? width / 2 : align === 'left' ? PAD : width - PAD, y: y + size, align, f: ctx.font })
        y += lh
      })
    }
  }
  const height = Math.ceil(y + PAD)
  canvas.height = height
  ctx = canvas.getContext('2d')
  ctx.fillStyle = '#fff'
  ctx.fillRect(0, 0, width, height)
  ctx.fillStyle = '#000'
  ctx.strokeStyle = '#000'
  ctx.direction = 'rtl'
  for (const o of ops) {
    if (o.hr) {
      ctx.lineWidth = o.hr === 'solid' ? 3 : 2
      ctx.setLineDash(o.hr === 'solid' ? [] : [8, 5])
      ctx.beginPath(); ctx.moveTo(PAD, o.y); ctx.lineTo(width - PAD, o.y); ctx.stroke()
    } else if (o.img) {
      ctx.drawImage(o.img, o.x, o.y, o.w, o.h)
    } else {
      ctx.font = o.f
      ctx.textAlign = o.align
      ctx.fillText(o.t, o.x, o.y)
    }
  }
  return { width, height, data: toBase64(packBits(ctx.getImageData(0, 0, width, height).data, width, height)) }
}

/** RGBA pixels → packed 1-bit rows (printer order: MSB = leftmost pixel, 1 = black). Dark, opaque pixels print. */
export function packBits(px, width, height) {
  const row = width / 8
  const bits = new Uint8Array(row * height)
  for (let yy = 0; yy < height; yy++) {
    for (let x = 0; x < width; x++) {
      const i = (yy * width + x) * 4
      const lum = (px[i] * 299 + px[i + 1] * 587 + px[i + 2] * 114) / 1000
      if (px[i + 3] > 128 && lum < 140) bits[yy * row + (x >> 3)] |= 0x80 >> (x & 7)
    }
  }
  return bits
}

export function toBase64(bits) {
  let bin = ''
  for (let i = 0; i < bits.length; i += 0x8000) bin += String.fromCharCode.apply(null, bits.subarray(i, i + 0x8000))
  return btoa(bin)
}

/** The receipt printer for this device: one assigned to its register, else one for every register; null = browser print. */
export function receiptPrinter(settings) {
  const list = (settings?.['print.printers'] || []).filter((p) => p.receipt)
  const reg = getRegisterId()
  return list.find((p) => reg && p.register_id === reg) || list.find((p) => !p.register_id) || null
}

export const stationPrinter = (settings, stationId) => (settings?.['print.printers'] || []).find((p) => (p.station_ids || []).includes(stationId)) || null

export async function printBlocks(printer, blocks, { drawer = false, copies = 1 } = {}) {
  const r = await rasterize(blocks, printer.width || 576)
  return post('/system/print', { printer_id: printer.id, ...r, drawer, copies })
}
