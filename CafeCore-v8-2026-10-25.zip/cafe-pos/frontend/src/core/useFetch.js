import { useCallback, useEffect, useRef, useState } from 'react'
import { get } from './api'

/** const { data, loading, error, reload, setData } = useFetch('/path', params, { deps, skip }) */
export function useFetch(path, params, { skip = false, deps = [] } = {}) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(!skip)
  const [error, setError] = useState(null)
  const key = JSON.stringify(params || {})
  // `deps` lets a caller refetch on something the request itself doesn't carry (an open dialog, a
  // counter). It is folded into ONE value because a hook's dependency array must keep the same size
  // on every render — spreading it (`[...deps]`) breaks the moment a caller passes a different count.
  const depKey = JSON.stringify(deps)
  const seq = useRef(0)
  const reload = useCallback(async (silent = false) => {
    if (skip || !path) return
    const my = ++seq.current
    if (!silent) setLoading(true)
    try {
      const d = await get(path, params)
      if (my === seq.current) { setData(d); setError(null) }
      return d
    } catch (e) {
      if (my === seq.current) setError(e)
    } finally {
      if (my === seq.current) setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, key, skip, depKey])
  useEffect(() => { reload() }, [reload])
  return { data, loading, error, reload, setData }
}
