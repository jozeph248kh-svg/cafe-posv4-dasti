/**
 * Which cash register (drawer) this device works on. Stored per device (localStorage) and sent to the server as
 * `X-Register-Id` on every request; payments and cash movements go to that register's open shift.
 * No value = the main register.
 */
const KEY = 'cafe_register'

export const getRegisterId = () => {
  const v = Number(localStorage.getItem(KEY))
  return Number.isInteger(v) && v > 0 ? v : null
}

export const setRegisterId = (id) => {
  if (id) localStorage.setItem(KEY, String(id)); else localStorage.removeItem(KEY)
  window.dispatchEvent(new Event('register:changed'))
}
