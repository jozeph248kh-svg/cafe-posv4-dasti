import { describe, expect, it } from 'vitest'
import { contrast, inkOn } from './color'
import { BUILTIN, contrastReport, derive, exportSkin, importSkin, normalizeSkin } from './skins'

// The skin engine's promise: whatever colours a user picks, text stays readable.
const pairs = (v) => [
  ['text/card', v['--text'], v['--card'], 7],
  ['muted/card', v['--muted'], v['--card'], 4.5],
  ['muted/bg', v['--muted'], v['--bg'], 4.5],
  ['primary-text/card', v['--primary-text'], v['--card'], 4.5],
  ['primary-text/bg', v['--primary-text'], v['--bg'], 4.5],
  ['primary-ink/primary', v['--primary-ink'], v['--primary'], 4.5],
  ['green/card', v['--green'], v['--card'], 4.5],
  ['red/card', v['--red'], v['--card'], 4.5],
  ['amber/card', v['--amber'], v['--card'], 4.5],
  ['blue/card', v['--blue'], v['--card'], 4.5],
  ['white/ok-solid', '#ffffff', v['--ok-solid'], 4.5],
  ...Array.from({ length: 9 }, (_, i) => [`pal-ink/pal-${i + 1}`, v['--pal-ink'], v[`--pal-${i + 1}`], 4.5]),
]

function rand(seed) { let s = seed; return () => { s = (s * 16807) % 2147483647; return s / 2147483647 } }
const hex = (r) => `#${Array.from({ length: 3 }, () => Math.floor(r() * 256).toString(16).padStart(2, '0')).join('')}`

describe('skin engine contrast guarantees', () => {
  for (const skin of BUILTIN) {
    for (const dark of [false, true]) {
      it(`${skin.id} ${dark ? 'dark' : 'light'}: all text pairs readable`, () => {
        const v = derive(skin, dark).vars
        for (const [name, fg, bg, min] of pairs(v)) expect(contrast(fg, bg), `${name} ${fg} on ${bg}`).toBeGreaterThanOrEqual(min - 0.01)
      })
    }
    it(`${skin.id}: contrast report has no failing row`, () => {
      for (const row of contrastReport(skin)) expect(row.ratio, `${row.label} (${row.dark ? 'dark' : 'light'})`).toBeGreaterThanOrEqual(row.min - 0.01)
    })
  }

  it('random (even ugly) user colours are auto-fixed to readable', () => {
    const r = rand(42)
    for (let i = 0; i < 60; i++) {
      const base = BUILTIN[i % BUILTIN.length]
      const skin = normalizeSkin({ ...base, id: `rnd${i}`, name: 'rnd', light: { ...base.light, primary: hex(r), muted: hex(r), success: hex(r) }, dark: { ...base.dark, primary: hex(r), muted: hex(r), error: hex(r) } })
      for (const dark of [false, true]) {
        const v = derive(skin, dark).vars
        for (const [name, fg, bg, min] of pairs(v)) expect(contrast(fg, bg), `#${i} ${dark ? 'dark' : 'light'} ${name} ${fg} on ${bg}`).toBeGreaterThanOrEqual(min - 0.01)
      }
    }
  })

  it('inkOn picks the readable ink for data colours', () => {
    for (const c of ['#ff8a00', '#ffd666', '#4f46e5', '#0ea5e9', '#111827', '#ffffff', '#ff3e6c']) {
      expect(Math.max(contrast(inkOn(c), c))).toBeGreaterThanOrEqual(4.5)
    }
  })

  it('export → import round-trips and rejects junk', () => {
    const s = importSkin(exportSkin({ ...BUILTIN[1], id: 'my-latte', name: 'لاته من' }))
    expect(s.name).toBe('لاته من')
    expect(s.light.primary).toBe(BUILTIN[1].light.primary)
    expect(() => importSkin('not json')).toThrow()
    expect(() => importSkin('{"kind":"other"}')).toThrow()
  })
})
