import { describe, expect, it } from 'vitest'
import { setRegisterId } from './register'
import { packBits, receiptPrinter, stationPrinter, toBase64 } from './escpos'

const rgba = (w, h, black) => {
  const px = new Uint8ClampedArray(w * h * 4).fill(255)
  for (const [x, y] of black) { const i = (y * w + x) * 4; px[i] = px[i + 1] = px[i + 2] = 0 }
  return px
}

describe('1-bit packing', () => {
  it('MSB is the leftmost pixel, one bit per pixel, row by row', () => {
    const bits = packBits(rgba(16, 2, [[0, 0], [7, 0], [8, 0], [15, 1]]), 16, 2)
    expect([...bits]).toEqual([0b10000001, 0b10000000, 0, 0b00000001])
  })
  it('light grey and transparent pixels stay white', () => {
    const px = rgba(8, 1, [])
    px[0] = px[1] = px[2] = 200                       // light grey
    px[4] = px[5] = px[6] = 0; px[7] = 0              // black but transparent
    expect([...packBits(px, 8, 1)]).toEqual([0])
  })
  it('base64 matches the bytes (large buffers too)', () => {
    const bits = new Uint8Array(70000).map((_, i) => i % 256)
    expect(Uint8Array.from(atob(toBase64(bits)), (c) => c.charCodeAt(0))).toEqual(bits)
  })
})

describe('printer choice', () => {
  const settings = { 'print.printers': [
    { id: 1, name: 'همه', receipt: true, register_id: null, station_ids: [] },
    { id: 2, name: 'صندوق ۲', receipt: true, register_id: 2, station_ids: [] },
    { id: 3, name: 'آشپزخانه', receipt: false, station_ids: [5, 6] },
  ] }
  it('register-specific receipt printer wins, else the shared one', () => {
    expect(receiptPrinter(settings).id).toBe(1)
    setRegisterId(2)
    expect(receiptPrinter(settings).id).toBe(2)
    setRegisterId(9)
    expect(receiptPrinter(settings).id).toBe(1)
  })
  it('no receipt printer → browser printing', () => {
    expect(receiptPrinter({ 'print.printers': [settings['print.printers'][2]] })).toBeNull()
    expect(receiptPrinter({})).toBeNull()
  })
  it('kitchen tickets go to the printer of their station', () => {
    expect(stationPrinter(settings, 6).id).toBe(3)
    expect(stationPrinter(settings, 4)).toBeNull()
  })
})
