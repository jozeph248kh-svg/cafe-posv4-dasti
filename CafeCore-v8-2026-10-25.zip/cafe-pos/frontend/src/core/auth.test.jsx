import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor, act } from '@testing-library/react'
import { AuthProvider, useAuth } from './auth'
import { setToken, getToken } from './api'

/**
 * The auth context decides what a user may do everywhere else: `can()`, `hasModule()`, the forced
 * password change and the business settings that ride along with the session. It had no test.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('./api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a),
  getToken: vi.fn(() => null), setToken: vi.fn(), ApiError: class extends Error {},
  setOverrideHandler: vi.fn(), newRequestId: () => 'rid',
}))
vi.mock('./realtime', () => ({ startRealtime: vi.fn(), stopRealtime: vi.fn() }))

const INFO = { modules: [{ name: 'orders' }, { name: 'kitchen' }], version: '1.0.0', lan_urls: ['http://10.0.0.5:8000'] }
const SETTINGS = { 'business.name': 'کافه ونک', 'day.cutoff_hour': 6, 'shift.hours': 8 }
const USER = { id: 7, full_name: 'رضا', username: 'reza', permissions: ['pos.access', 'payments.take'], role: { name: 'cashier' } }

function Probe() {
  const auth = useAuth()
  return (
    <div>
      <span data-testid="ready">{String(auth.ready)}</span>
      <span data-testid="user">{auth.user?.full_name || '—'}</span>
      <span data-testid="must">{String(auth.mustChange)}</span>
      <span data-testid="can">{String(auth.can('payments.take'))}</span>
      <span data-testid="cannot">{String(auth.canAny('reports.view', 'settings.manage'))}</span>
      <span data-testid="mod">{String(auth.hasModule('kitchen'))}</span>
      <span data-testid="biz">{auth.settings['business.name'] || '—'}</span>
      <button onClick={() => auth.login('reza', 'cashier123')}>login</button>
      <button onClick={() => auth.login('reza', 'x')}>login-forced</button>
      <button onClick={() => auth.pinLogin('3333')}>pin</button>
      <button onClick={() => auth.logout()}>logout</button>
    </div>
  )
}
const show = (k) => screen.getByTestId(k).textContent

describe('AuthProvider', () => {
  beforeEach(() => {
    get.mockReset(); post.mockReset()
    get.mockImplementation((path) => (path === '/system/info' ? Promise.resolve(INFO) : Promise.resolve(SETTINGS)))
  })

  it('starts unauthenticated and ready', async () => {
    render(<AuthProvider><Probe /></AuthProvider>)
    await waitFor(() => expect(show('ready')).toBe('true'))
    expect(show('user')).toBe('—')
    expect(show('can')).toBe('false')
  })

  it('logs in: stores the token, loads modules and settings, and exposes the permissions', async () => {
    post.mockResolvedValue({ token: 'jwt', user: USER })
    render(<AuthProvider><Probe /></AuthProvider>)
    await waitFor(() => expect(show('ready')).toBe('true'))
    await act(async () => { screen.getByText('login').click() })
    await waitFor(() => expect(show('user')).toBe('رضا'))
    expect(setToken).toHaveBeenCalledWith('jwt')
    expect(show('can')).toBe('true')            // payments.take
    expect(show('cannot')).toBe('false')        // neither of the two asked
    expect(show('mod')).toBe('true')            // kitchen module loaded
    expect(show('biz')).toBe('کافه ونک')
  })

  it('marks a factory password as "must change" and skips loading the app', async () => {
    post.mockResolvedValue({ token: 'restricted', user: USER, must_change_password: true })
    render(<AuthProvider><Probe /></AuthProvider>)
    await waitFor(() => expect(show('ready')).toBe('true'))
    await act(async () => { screen.getByText('login-forced').click() })
    await waitFor(() => expect(show('must')).toBe('true'))
    expect(show('biz')).toBe('—')               // settings not loaded for a restricted token
  })

  it('supports PIN login', async () => {
    post.mockResolvedValue({ token: 'jwt', user: USER })
    render(<AuthProvider><Probe /></AuthProvider>)
    await waitFor(() => expect(show('ready')).toBe('true'))
    await act(async () => { screen.getByText('pin').click() })
    await waitFor(() => expect(post).toHaveBeenCalledWith('/staff/auth/pin', { pin: '3333' }))
    expect(show('user')).toBe('رضا')
  })

  it('logs out: clears the token and the user', async () => {
    post.mockResolvedValue({ token: 'jwt', user: USER })
    render(<AuthProvider><Probe /></AuthProvider>)
    await waitFor(() => expect(show('ready')).toBe('true'))
    await act(async () => { screen.getByText('login').click() })
    await waitFor(() => expect(show('user')).toBe('رضا'))
    await act(async () => { screen.getByText('logout').click() })
    await waitFor(() => expect(show('user')).toBe('—'))
    expect(setToken).toHaveBeenCalledWith(null)
  })

  it('changes the password through the API', async () => {
    post.mockResolvedValue({ token: 'jwt2', user: USER })
    const capturedAuth = []
    function Grab() { capturedAuth.push(useAuth()); return null }
    render(<AuthProvider><Grab /></AuthProvider>)
    await waitFor(() => expect(capturedAuth.length).toBeGreaterThan(0))
    await act(async () => { await capturedAuth[0].changePassword('old', 'new') })
    expect(post).toHaveBeenCalledWith('/staff/auth/password', { current_password: 'old', new_password: 'new' })
  })
})
