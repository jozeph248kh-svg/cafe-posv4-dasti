/** Printing through a hidden iframe: works with any OS printer (80mm thermal or A4) without browser popups. */
import { printBlocks, receiptPrinter, stationPrinter } from './escpos'
import { ORDER_TYPES, PAY_METHODS, faDate, faDateTime, modText, money, num } from './format'

/** Direct ESC/POS printing when a network printer is configured; on failure fall back to the browser print dialog. */
async function direct(printer, blocks, opts, fallback) {
  if (!printer) return fallback()
  try {
    await printBlocks(printer, blocks, opts)
  } catch (e) {
    window.dispatchEvent(new CustomEvent('print:error', { detail: `${e.message} — چاپ از طریق مرورگر انجام می‌شود.` }))
    fallback()
  }
}

function headerBlocks(s) {
  return [
    s['receipt.show_logo'] && s['business.logo'] && { img: s['business.logo'], maxWidth: 0.5 },
    { text: s['business.name'], align: 'center', size: 30, bold: true },
    s['business.address'] && { text: s['business.address'], align: 'center', size: 19 },
    s['business.phone'] && { text: `تلفن: ${s['business.phone']}`, align: 'center', size: 19 },
  ]
}

function lineBlocks(lines, withPrice = true, big = false) {
  return lines.filter((l) => l.status !== 'void' && !l.is_void).flatMap((l) => [
    withPrice ? { text: `${num(l.qty)}× ${l.name}`, left: money(l.unit_price * l.qty), size: 22 } : { text: `${num(l.qty)}× ${l.name}`, size: big ? 30 : 22, bold: true },
    l.modifiers?.length && { text: `   ${modText(l.modifiers)}`, size: big ? 24 : 18 },
    l.note && { text: `   * ${l.note}`, size: big ? 24 : 18 },
    withPrice && l.discount_amount && { text: `   تخفیف${l.discount_type === 'percent' ? ` ${num(l.discount_value)}٪` : ''}`, left: `−${money(l.discount_amount)}`, size: 18 },
  ])
}

export function receiptBlocks(order, s, kind = 'receipt') {
  const t = ORDER_TYPES[order.type]
  const cur = s['currency.label'] || 'تومان'
  const billDisc = order.discount_amount - (order.line_discount_amount || 0)
  const change = (order.payments || []).reduce((a, p) => a + (p.change || 0), 0)
  return [
    ...headerBlocks(s), { hr: 'dashed' },
    { text: `${kind === 'bill' ? 'پیش‌فاکتور' : 'رسید فروش'} — سفارش #${num(order.number)}`, align: 'center', size: 24, bold: true },
    { text: `${t?.label || ''}${order.table_name ? ` — میز ${order.table_name}` : ''}`, left: faDateTime(order.closed_at || order.created_at), size: 19 },
    order.waiter_name && { text: `گارسون: ${order.waiter_name}${order.guests > 1 ? ` — ${num(order.guests)} نفر` : ''}`, size: 19 },
    order.customer_name && { text: `مشتری: ${order.customer_name} ${order.customer_phone || ''}`, size: 19 },
    order.customer_address && { text: `آدرس: ${order.customer_address}`, size: 19 },
    { hr: 'dashed' }, ...lineBlocks(order.lines), { hr: 'dashed' },
    { text: 'جمع اقلام', left: money(order.subtotal) },
    order.line_discount_amount && { text: 'تخفیف اقلام', left: `−${money(order.line_discount_amount)}` },
    billDisc > 0 && { text: `تخفیف فاکتور${order.discount_type === 'percent' ? ` (${num(order.discount_value)}٪)` : ''}`, left: `−${money(billDisc)}` },
    order.discount_amount && { text: `سود شما از این خرید: ${money(order.discount_amount)} ${cur}`, align: 'center', bold: true, size: 20 },
    order.service_amount && { text: 'حق سرویس', left: money(order.service_amount) },
    order.tax_amount && { text: 'مالیات بر ارزش افزوده', left: money(order.tax_amount) },
    order.rounding && { text: 'رُند', left: money(order.rounding) },
    { hr: 'solid' }, { text: 'مبلغ قابل پرداخت', left: `${money(order.total)} ${cur}`, size: 26, bold: true }, { hr: 'solid' },
    ...(kind === 'receipt' ? (order.payments || []).map((p) => ({ text: `${p.is_refund ? 'بازپرداخت ' : ''}${PAY_METHODS[p.method]?.label || p.method}`, left: money(p.amount), size: 20 })) : []),
    kind === 'receipt' && change > 0 && { text: 'باقیمانده پرداختی به مشتری', left: money(change), size: 20 },
    { hr: 'dashed' },
    s['business.wifi'] && { text: `WiFi: ${s['business.wifi']}`, align: 'center', size: 19 },
    s['receipt.footer'] && { text: s['receipt.footer'], align: 'center', size: 20 },
    { space: 10 },
  ]
}

export function kitchenBlocks(ticket, stationName) {
  const t = ORDER_TYPES[ticket.order_type]
  return [
    { text: stationName || 'آشپزخانه', align: 'center', size: 24, bold: true },
    { text: `#${num(ticket.order_number)}`, align: 'center', size: 56, bold: true },
    { text: ticket.table_name ? `میز ${ticket.table_name}` : t?.label || '', align: 'center', size: 34, bold: true },
    { text: ticket.waiter_name || '', left: faDateTime(ticket.created_at), size: 19 },
    { hr: 'solid' }, ...lineBlocks(ticket.items, false, true),
    ticket.note && { hr: 'dashed' }, ticket.note && { text: `* ${ticket.note}`, size: 24, bold: true },
    { space: 10 },
  ]
}

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))

const BASE_CSS = `
@page { size: 80mm auto; margin: 3mm; }
* { box-sizing: border-box; }
body { font-family: Vazirmatn, 'Vazirmatn FD', Tahoma, sans-serif; direction: rtl; margin: 0; color: #000; font-size: 12px; width: 74mm; }
.c { text-align: center; } .b { font-weight: 700; } .big { font-size: 18px; } .xl { font-size: 26px; font-weight: 800; }
.muted { color: #444; font-size: 11px; }
hr { border: 0; border-top: 1px dashed #000; margin: 6px 0; }
table { width: 100%; border-collapse: collapse; }
td { padding: 2px 0; vertical-align: top; }
td.n { text-align: left; white-space: nowrap; }
.mods { font-size: 11px; color: #333; padding-right: 8px; }
.row { display: flex; justify-content: space-between; padding: 1px 0; }
.total { font-size: 16px; font-weight: 800; border-top: 1px solid #000; border-bottom: 1px solid #000; padding: 4px 0; margin-top: 4px; }
img.logo { max-width: 40mm; max-height: 22mm; display: block; margin: 0 auto 4px; }
`

// reuse the app's bundled Vazirmatn font inside the print frame
function fontFaces() {
  let out = ''
  for (const sheet of document.styleSheets) {
    try {
      for (const r of sheet.cssRules) if (r instanceof CSSFontFaceRule && /vazir/i.test(r.cssText)) out += r.cssText.replace(/url\("?(\/[^")]+)"?\)/g, `url("${location.origin}$1")`)
    } catch { /* cross-origin sheet */ }
  }
  return out
}

export function printHtml(body, { css = '', title = 'print' } = {}) {
  const iframe = document.createElement('iframe')
  Object.assign(iframe.style, { position: 'fixed', left: '-10000px', top: 0, width: '80mm', height: '10px', border: 0 })
  document.body.appendChild(iframe)
  const doc = iframe.contentDocument
  doc.open()
  doc.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>${esc(title)}</title>
    <style>${fontFaces()}${BASE_CSS}${css}</style></head><body>${body}</body></html>`)
  doc.close()
  const go = () => {
    iframe.contentWindow.focus()
    iframe.contentWindow.print()
    setTimeout(() => iframe.remove(), 1500)
  }
  const imgs = [...doc.images]
  if (!imgs.length) setTimeout(go, 150)
  else Promise.all(imgs.map((i) => (i.complete ? 0 : new Promise((r) => { i.onload = i.onerror = r })))).then(() => setTimeout(go, 100))
}

function header(s) {
  return `${s['receipt.show_logo'] && s['business.logo'] ? `<img class="logo" src="${esc(s['business.logo'])}">` : ''}
    <div class="c big b">${esc(s['business.name'])}</div>
    ${s['business.address'] ? `<div class="c muted">${esc(s['business.address'])}</div>` : ''}
    ${s['business.phone'] ? `<div class="c muted">تلفن: ${esc(s['business.phone'])}</div>` : ''}`
}

function linesTable(lines, withPrice = true) {
  return `<table>${lines.filter((l) => l.status !== 'void').map((l) => `
    <tr><td><span class="b">${num(l.qty)}×</span> ${esc(l.name)}
      ${l.modifiers?.length ? `<div class="mods">${esc(modText(l.modifiers))}</div>` : ''}
      ${l.note ? `<div class="mods">📝 ${esc(l.note)}</div>` : ''}
      ${withPrice && l.discount_amount ? `<div class="mods">تخفیف${l.discount_type === 'percent' ? ` ${num(l.discount_value)}٪` : ''}: −${money(l.discount_amount)}</div>` : ''}</td>
      ${withPrice ? `<td class="n">${money(l.unit_price * l.qty)}</td>` : ''}</tr>`).join('')}</table>`
}

/** Customer bill / receipt. `kind`: 'bill' (پیش‌فاکتور) | 'receipt' (رسید پرداخت) */
export function printReceipt(order, settings, kind = 'receipt') {
  const s = settings || {}
  const cash = kind === 'receipt' && (order.payments || []).some((p) => p.method === 'cash' && !p.is_refund)
  return direct(receiptPrinter(s), receiptBlocks(order, s, kind), { drawer: cash }, () => printReceiptHtml(order, s, kind))
}

function printReceiptHtml(order, s, kind) {
  const t = ORDER_TYPES[order.type]
  const pays = (order.payments || []).map((p) => `<div class="row"><span>${p.is_refund ? 'بازپرداخت ' : ''}${PAY_METHODS[p.method]?.label || p.method}</span><span>${money(p.amount)}</span></div>`).join('')
  const body = `${header(s)}<hr>
    <div class="c b">${kind === 'bill' ? 'پیش‌فاکتور' : 'رسید فروش'} — سفارش #${num(order.number)}</div>
    <div class="row muted"><span>${t?.label || ''}${order.table_name ? ` — میز ${esc(order.table_name)}` : ''}</span><span>${faDateTime(order.closed_at || order.created_at)}</span></div>
    ${order.waiter_name ? `<div class="muted">گارسون: ${esc(order.waiter_name)}${order.guests > 1 ? ` — ${num(order.guests)} نفر` : ''}</div>` : ''}
    ${order.customer_name ? `<div class="muted">مشتری: ${esc(order.customer_name)} ${esc(order.customer_phone || '')}</div>` : ''}
    ${order.customer_address ? `<div class="muted">آدرس: ${esc(order.customer_address)}</div>` : ''}
    <hr>${linesTable(order.lines)}<hr>
    <div class="row"><span>جمع اقلام</span><span>${money(order.subtotal)}</span></div>
    ${order.line_discount_amount ? `<div class="row"><span>تخفیف اقلام</span><span>−${money(order.line_discount_amount)}</span></div>` : ''}
    ${order.discount_amount - (order.line_discount_amount || 0) > 0 ? `<div class="row"><span>تخفیف فاکتور${order.discount_type === 'percent' ? ` (${num(order.discount_value)}٪)` : ''}</span><span>−${money(order.discount_amount - (order.line_discount_amount || 0))}</span></div>` : ''}
    ${order.discount_amount ? `<div class="c b">سود شما از این خرید: ${money(order.discount_amount)} ${esc(s['currency.label'] || 'تومان')}</div>` : ''}
    ${order.service_amount ? `<div class="row"><span>حق سرویس</span><span>${money(order.service_amount)}</span></div>` : ''}
    ${order.tax_amount ? `<div class="row"><span>مالیات بر ارزش افزوده</span><span>${money(order.tax_amount)}</span></div>` : ''}
    ${order.rounding ? `<div class="row"><span>رُند</span><span>${money(order.rounding)}</span></div>` : ''}
    <div class="row total"><span>مبلغ قابل پرداخت</span><span>${money(order.total)} ${esc(s['currency.label'] || 'تومان')}</span></div>
    ${kind === 'receipt' && pays ? `<div style="margin-top:4px">${pays}</div>` : ''}
    ${kind === 'receipt' && order.payments?.some((p) => p.change) ? `<div class="row"><span>باقیمانده پرداختی به مشتری</span><span>${money(order.payments.reduce((a, p) => a + (p.change || 0), 0))}</span></div>` : ''}
    <hr>${s['business.wifi'] ? `<div class="c muted">WiFi: ${esc(s['business.wifi'])}</div>` : ''}
    <div class="c">${esc(s['receipt.footer'] || '')}</div>`
  printHtml(body, { title: `order-${order.number}` })
}

/** Kitchen ticket (for kitchens using a printer instead of / beside the KDS screen). */
export function printKitchenTicket(ticket, stationName, settings) {
  return direct(stationPrinter(settings, ticket.station_id), kitchenBlocks(ticket, stationName), {}, () => printKitchenHtml(ticket, stationName))
}

function printKitchenHtml(ticket, stationName) {
  const t = ORDER_TYPES[ticket.order_type]
  const body = `<div class="c b">${esc(stationName || 'آشپزخانه')}</div>
    <div class="c xl">#${num(ticket.order_number)}</div>
    <div class="c big b">${ticket.table_name ? `میز ${esc(ticket.table_name)}` : t?.label || ''}</div>
    <div class="row muted"><span>${esc(ticket.waiter_name || '')}</span><span>${faDateTime(ticket.created_at)}</span></div><hr>
    <table>${ticket.items.filter((i) => !i.is_void).map((i) => `<tr><td class="big"><b>${num(i.qty)}×</b> ${esc(i.name)}
      ${i.modifiers?.length ? `<div class="mods" style="font-size:13px">${esc(modText(i.modifiers))}</div>` : ''}
      ${i.note ? `<div class="mods" style="font-size:13px">📝 ${esc(i.note)}</div>` : ''}</td></tr>`).join('')}</table>
    ${ticket.note ? `<hr><div>📝 ${esc(ticket.note)}</div>` : ''}`
  printHtml(body, { title: `kitchen-${ticket.order_number}` })
}

export function printShift(shift, settings) {
  const s = settings || {}
  const rows = Object.entries(shift.payments || {}).map(([m, v]) => `<div class="row"><span>${PAY_METHODS[m]?.label || m}</span><span>${money(v)}</span></div>`).join('')
  const body = `${header(s)}<hr><div class="c b">گزارش شیفت صندوق #${num(shift.id)}</div>
    ${shift.register_name ? `<div class="c">${esc(shift.register_name)}</div>` : ''}
    <div class="row muted"><span>باز: ${esc(shift.opened_by)}</span><span>${faDateTime(shift.opened_at)}</span></div>
    ${shift.closed_at ? `<div class="row muted"><span>بسته: ${esc(shift.closed_by)}</span><span>${faDateTime(shift.closed_at)}</span></div>` : ''}<hr>
    <div class="row"><span>تعداد سفارش</span><span>${num(shift.orders)}</span></div>
    ${rows}${shift.total_sales != null ? `<div class="row total"><span>جمع فروش</span><span>${money(shift.total_sales)}</span></div>` : ''}
    <div class="row"><span>موجودی اول شیفت</span><span>${money(shift.opening_cash)}</span></div>
    <div class="row"><span>واریز به صندوق</span><span>${money(shift.cash_in)}</span></div>
    <div class="row"><span>برداشت از صندوق</span><span>${money(shift.cash_out)}</span></div>
    ${shift.expected_cash != null ? `<div class="row b"><span>نقد مورد انتظار</span><span>${money(shift.expected_cash)}</span></div>`
    : '<div class="c muted">شمارش کور: نقد مورد انتظار پس از بستن صندوق</div>'}
    ${shift.counted_cash != null ? `<div class="row"><span>نقد شمارش‌شده</span><span>${money(shift.counted_cash)}</span></div>
    <div class="row b"><span>مغایرت</span><span>${money(shift.difference)}</span></div>` : ''}`
  printHtml(body, { title: `shift-${shift.id}` })
}

/** End-of-shift report of one employee (`r` = submitted report or { name, role, period_*, note, data }). */
export function printStaffReport(r, settings) {
  const s = settings || {}
  const d = r.data || {}
  const o = d.orders || {}
  const row = (a, b) => `<div class="row"><span>${a}</span><span>${b}</span></div>`
  const hmm = (m) => (m == null ? '—' : `${num(Math.floor(m / 60))}:${num(m % 60).padStart(2, '۰')}`)
  const cash = (v) => (v == null ? 'پنهان' : money(v))
  const body = `${header(s)}<hr><div class="c b">گزارش پایان شیفت</div>
    <div class="c big b">${esc(r.name || '')}</div>${r.role ? `<div class="c muted">${esc(r.role)}</div>` : ''}
    ${row('از', faDateTime(r.period_start))}${row('تا', faDateTime(r.period_end))}${row('مدت حضور', hmm(d.minutes))}<hr>
    ${row(`سفارش تسویه‌شده (${num(o.closed)})`, money(o.sales))}${o.closed ? row('میانگین فاکتور', money(o.avg)) : ''}
    ${o.open ? row('⚠ سفارش باز', num(o.open)) : ''}${o.cancelled ? row('سفارش لغوشده', num(o.cancelled)) : ''}<hr>
    <div class="b">دریافت‌ها</div>${Object.entries(d.payments || {}).map(([m, v]) => row(PAY_METHODS[m]?.label || m, cash(v))).join('') || '<div class="muted">—</div>'}
    ${d.refunds?.count ? row(`بازپرداخت (${num(d.refunds.count)})`, `−${money(d.refunds.amount)}`) : ''}
    <div class="row total"><span>جمع دریافتی</span><span>${cash(d.collected_total)}</span></div><hr>
    ${row(`تخفیف (${num(d.discounts?.count)})`, money(d.discounts?.amount))}${row(`حذف آیتم (${num(d.voids?.count)})`, money(d.voids?.amount))}
    ${row(`لغو سفارش (${num(d.cancels?.count)})`, money(d.cancels?.amount))}
    ${(d.drawers_closed || []).map((x) => `<hr><div class="b">تحویل صندوق ${esc(x.register_name || '')}</div>${row('شمارش‌شده', money(x.counted_cash))}${row('مورد انتظار', money(x.expected_cash))}
      <div class="row b"><span>مغایرت</span><span>${x.difference > 0 ? '+' : ''}${money(x.difference)}</span></div>`).join('')}
    ${d.drawer ? `<hr><div class="c b">⚠ صندوق ${esc(d.drawer.register_name || '')} هنوز تحویل نشده</div>` : ''}
    ${(d.open_orders || []).length ? `<hr><div class="b">سفارش‌های باز</div>${d.open_orders.map((x) => row(`#${num(x.number)}${x.table ? ` میز ${esc(x.table)}` : ''}`, money(x.total - x.paid))).join('')}` : ''}
    ${r.note ? `<hr><div class="b">یادداشت</div><div>${esc(r.note)}</div>` : ''}
    ${r.acknowledged_by ? `<hr><div>تأیید مدیر: ${esc(r.acknowledged_by)} — ${faDateTime(r.acknowledged_at)}</div>${r.manager_note ? `<div>${esc(r.manager_note)}</div>` : ''}` : ''}
    <hr><div class="c muted">امضای کارمند ............ امضای مدیر ............</div>`
  printHtml(body, { title: `staff-report-${r.id || 'live'}` })
}

/** End-of-day (Z) report on the 80 mm printer. `z` = /api/reports/insights/z */
export function printZReport(z, settings, who) {
  const s = settings || {}
  const m = z.summary
  const row = (a, b) => `<div class="row"><span>${a}</span><span>${b}</span></div>`
  const body = `${header(s)}<hr>
    <div class="c b">گزارش پایان روز (Z)</div>
    <div class="c">${faDate(z.day)}</div>
    <div class="c muted">چاپ: ${faDateTime(new Date())}${who ? ` — ${esc(who)}` : ''}</div><hr>
    ${row('تعداد فاکتور', num(m.orders))}${row('تعداد مهمان (سالن)', num(m.guests))}
    ${row('فروش ناخالص', money(m.gross))}${row('تخفیف', `−${money(m.discounts)}`)}
    ${m.service ? row('حق سرویس', money(m.service)) : ''}${m.tax ? row('مالیات', money(m.tax)) : ''}
    <div class="row total"><span>فروش خالص</span><span>${money(m.net)}</span></div>
    ${row('میانگین فاکتور', money(m.avg_ticket))}
    ${m.refunds ? row('بازپرداخت', `−${money(m.refunds)}`) : ''}<hr>
    <div class="b">روش پرداخت</div>${z.by_payment.map((p) => row(esc(p.label), money(p.amount))).join('') || '<div class="muted">—</div>'}<hr>
    <div class="b">نوع سفارش</div>${z.by_type.map((t) => row(`${esc(t.label)} (${num(t.orders)})`, money(t.revenue))).join('') || '<div class="muted">—</div>'}<hr>
    <div class="b">کنترل</div>
    ${row(`تخفیف (${num(z.discounts.orders)} فاکتور)`, `${money(z.discounts.total)} — ${num(z.discounts.pct, 1)}٪`)}
    ${row(`آیتم حذف‌شده (${num(z.voids.count)})`, money(z.voids.amount))}
    ${row(`سفارش لغوشده (${num(m.cancelled)})`, money(m.cancelled_amount))}
    ${z.open_orders ? row('⚠ سفارش باز (تسویه‌نشده)', num(z.open_orders)) : ''}
    ${z.shifts.length ? z.shifts.map((sh) => row(`صندوق ${esc(sh.closed_by || '')} — مغایرت`, `${sh.difference > 0 ? '+' : ''}${money(sh.difference)}`)).join('') : ''}<hr>
    <div class="b">پرفروش‌ترین‌ها</div>${z.top_items.map((i, k) => row(`${num(k + 1)}. ${esc(i.name)} ×${num(i.qty)}`, money(i.revenue))).join('') || '<div class="muted">—</div>'}
    ${z.discounts.by_reason.length ? `<hr><div class="b">دلایل تخفیف</div>${z.discounts.by_reason.map((r) => row(`${esc(r.reason)} (${num(r.count)})`, money(r.amount))).join('')}` : ''}
    <hr><div class="c muted">امضای صندوقدار ............ امضای مدیر ............</div>`
  printHtml(body, { title: `z-${z.day}` })
}