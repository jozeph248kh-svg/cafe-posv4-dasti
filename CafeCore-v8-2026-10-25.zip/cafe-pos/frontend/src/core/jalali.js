// Make Persian (Jalali) the default dayjs calendar app-wide, *before* any component builds a date value.
// Same plugins and order as antd-jalali's JalaliLocaleListener (dayjs.extend is idempotent).
import dayjs from 'dayjs'
import calendarPlugin from 'dayjs/plugin/calendar'
import jalaliday from './vendor/jalaliday'   // vendored: correct calendar math, see that file's header

dayjs.extend(calendarPlugin)
dayjs.extend(jalaliday)
dayjs.calendar('jalali')
