import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'

/**
 * Theme + navigation registry: what a user is allowed to see in the sidebar and which skin/scale is
 * applied. A permission bug here either hides a page the owner needs or shows one they must not open.
 */
const get = vi.fn()
vi.mock('./api', () => ({ get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn() }))
vi.mock('./realtime', async (orig) => ({ ...(await orig()), startRealtime: vi.fn(), stopRealtime: vi.fn(), useWsStatus: () => 'online', useRealtime: () => {} }))

const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('navigation registry', () => {
  it('builds the admin menu from the pages this user may open', async () => {
    const { ADMIN_PAGES, visible } = await import('../modules/registry')
    const cashier = { can: (p) => ['pos.access', 'customers.manage'].includes(p), canAny: (ps) => ps.some((p) => p === 'pos.access'), hasModule: () => true }
    const seen = ADMIN_PAGES.filter((p) => visible(cashier, p)).map((p) => p.key)
    expect(seen).toContain('customers')
    expect(seen).not.toContain('staff')          // needs staff.manage
    expect(seen).not.toContain('settings')
  })

  it('hides a page whose module is not loaded', async () => {
    const { ADMIN_PAGES, visible } = await import('../modules/registry')
    const noOnline = { can: () => true, canAny: () => true, hasModule: (m) => m !== 'online' }
    expect(ADMIN_PAGES.filter((p) => visible(noOnline, p)).map((p) => p.key)).not.toContain('online')
  })

  it('gives every admin page a unique path and a group', async () => {
    const { ADMIN_PAGES } = await import('../modules/registry')
    const paths = ADMIN_PAGES.map((p) => p.path)
    expect(new Set(paths).size).toBe(paths.length)
    expect(ADMIN_PAGES.every((p) => p.group && p.title)).toBe(true)
  })
})

describe('theme provider', () => {
  beforeEach(() => { localStorage.clear(); get.mockResolvedValue({}) })

  it('applies light/dark mode to the document and keeps the device preference', async () => {
    const { ThemeProvider, useTheme } = await import('./theme')
    let api
    function Grab() { api = useTheme(); return null }
    render(<ThemeProvider><Grab /></ThemeProvider>)
    await waitFor(() => expect(api).toBeTruthy())
    api.setMode('1')
    // the preference is stored on this device and drive the resolved theme
    await waitFor(() => expect(localStorage.getItem('cafe_dark')).toBe('1'))
    expect(api.mode).toBe('1')
    expect(api.dark).toBe(true)
  })

  it('changes the text scale on this device', async () => {
    const { ThemeProvider, useTheme } = await import('./theme')
    let api
    function Grab() { api = useTheme(); return null }
    render(<ThemeProvider><Grab /></ThemeProvider>)
    await waitFor(() => expect(api).toBeTruthy())
    api.setDeviceScale(1.2)
    await waitFor(() => expect(localStorage.getItem('cafe_fs')).toBe('1.2'))
  })

  it('exposes the chart palette for the active skin', async () => {
    const { ThemeProvider, useChart } = await import('./theme')
    let chart
    function Grab() { chart = useChart(); return null }
    render(<ThemeProvider><Grab /></ThemeProvider>)
    await waitFor(() => expect(chart).toBeTruthy())
    expect(Array.isArray(chart.c)).toBe(true)
    expect(chart.c.length).toBeGreaterThan(2)
  })
})

describe('print helpers used by the reports', () => {
  it('builds an iframe and prints once the document is ready', async () => {
    const { printHtml } = await import('./print')
    const write = vi.fn()
    const print = vi.fn()
    const origCreate = document.createElement.bind(document)
    vi.spyOn(document, 'createElement').mockImplementation((tag) => {
      const el = origCreate(tag)
      if (tag === 'iframe') {
        Object.defineProperty(el, 'contentDocument', {
          value: { open: vi.fn(), write, close: vi.fn(), readyState: 'complete', images: [], title: '' },
        })
        Object.defineProperty(el, 'contentWindow', { value: { print, focus: vi.fn() } })
      }
      return el
    })
    printHtml('<b>سلام</b>', { title: 'فیش' })
    expect(write).toHaveBeenCalled()
    vi.restoreAllMocks()
  })
})
