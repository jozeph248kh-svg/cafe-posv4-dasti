export const num = (n, digits = 0) => Number(n || 0).toLocaleString('fa-IR', { maximumFractionDigits: digits })
export const money = (n) => num(Math.round(n || 0))
export const toman = (n) => `${money(n)} تومان`

export const compact = (n) => {
  const v = Number(n || 0)
  const f = (x) => x.toLocaleString('fa-IR', { maximumFractionDigits: 1 })
  if (Math.abs(v) >= 1e9) return `${f(v / 1e9)} میلیارد`
  if (Math.abs(v) >= 1e6) return `${f(v / 1e6)} میلیون`
  if (Math.abs(v) >= 1e3) return `${f(v / 1e3)} هزار`
  return f(v)
}

const fmt = (opts) => new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-arabext', opts)
// backend sends naive local datetimes ("2026-10-22T18:30:00") — parse as local time
export const toDate = (d) => (d instanceof Date ? d : new Date(typeof d === 'string' && d.length === 10 ? `${d}T00:00:00` : d))
export const faDate = (d) => (d ? fmt({ year: 'numeric', month: 'long', day: 'numeric' }).format(toDate(d)) : '—')
export const faShort = (d) => (d ? fmt({ month: 'short', day: 'numeric' }).format(toDate(d)) : '—')
export const faWeekday = (d) => fmt({ weekday: 'long' }).format(toDate(d))
export const faTime = (d) => (d ? fmt({ hour: '2-digit', minute: '2-digit', hour12: false }).format(toDate(d)) : '—')
export const faDateTime = (d) => (d ? fmt({ year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(toDate(d)) : '—')
export const faToday = () => fmt({ weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(new Date())

export const minutesSince = (d) => Math.max(0, Math.floor((Date.now() - toDate(d).getTime()) / 60000))
export const clock = (d) => {
  const s = Math.max(0, Math.floor((Date.now() - toDate(d).getTime()) / 1000))
  const m = Math.floor(s / 60)
  return `${num(m)}:${num(s % 60).padStart(2, '۰')}`
}
export const timeAgo = (d) => {
  const diff = (Date.now() - toDate(d).getTime()) / 1000
  if (diff < 60) return 'همین الان'
  if (diff < 3600) return `${num(Math.floor(diff / 60))} دقیقه پیش`
  if (diff < 86400) return `${num(Math.floor(diff / 3600))} ساعت پیش`
  if (diff < 86400 * 30) return `${num(Math.floor(diff / 86400))} روز پیش`
  return faDate(d)
}
export const isoDate = (d = new Date()) => {
  const x = toDate(d)
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`
}

// warm brand palette (Round 8) — readable on both Latte and Espresso themes
// theme palette as CSS variables (the active skin fits them for text, avatars and tags; ink = var(--pal-ink)).
// HTML only — recharts attributes take useChart().c from core/theme.
export const PALETTE = Array.from({ length: 9 }, (_, i) => `var(--pal-${i + 1})`)
export const colorOf = (str = '') => {
  let h = 0
  for (const ch of String(str)) h = (h * 31 + ch.charCodeAt(0)) >>> 0
  return PALETTE[h % PALETTE.length]
}
export const initials = (name = '') => name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('‌')

// InputNumber helpers for money fields (accepts Persian digits too)
const FA = '۰۱۲۳۴۵۶۷۸۹'
export const toEnDigits = (s = '') => String(s).replace(/[۰-۹]/g, (c) => FA.indexOf(c)).replace(/[٠-٩]/g, (c) => '٠١٢٣٤٥٦٧٨٩'.indexOf(c))
export const moneyFormatter = (v) => (v === undefined || v === null || v === '' ? '' : `${v}`.replace(/\B(?=(\d{3})+(?!\d))/g, ','))
export const moneyParser = (v) => (v ? toEnDigits(v).replace(/[^\d]/g, '') : '')

export const ORDER_TYPES = {
  dine_in: { label: 'سالن', color: 'blue', icon: '🍽️' },
  takeaway: { label: 'بیرون‌بر', color: 'gold', icon: '🛍️' },
  delivery: { label: 'پیک', color: 'purple', icon: '🛵' },
}
export const PAY_METHODS = {
  cash: { label: 'نقد', color: 'var(--green)', icon: '💵' },
  card: { label: 'کارتخوان', color: 'var(--pal-1)', icon: '💳' },
  online: { label: 'آنلاین', color: 'var(--blue)', icon: '🌐' },
  credit: { label: 'نسیه', color: 'var(--amber)', icon: '📒' },
  wallet: { label: 'کیف پول', color: 'var(--violet)', icon: '👛' },
}
export const LINE_STATUS = {
  pending: { label: 'ثبت‌نشده', color: 'default' },
  sent: { label: 'در آشپزخانه', color: 'processing' },
  ready: { label: 'آماده', color: 'success' },
  served: { label: 'سرو شد', color: 'cyan' },
  void: { label: 'حذف‌شده', color: 'error' },
}
export const UNITS = { g: 'گرم', kg: 'کیلوگرم', ml: 'میلی‌لیتر', l: 'لیتر', pcs: 'عدد' }

/** Modifiers arrive as [{name}] on order lines and as a pre-joined string on kitchen tickets. */
export const modText = (m, sep = '، ') => (!m ? '' : Array.isArray(m) ? m.map((x) => x.name).join(sep) : String(m))

// Business day: the café's day ends at `day.cutoff_hour` (default 05:00), like the server's reports —
// at 01:00 "today" is still last night's business day. The cutoff is loaded with the system settings.
let cutoffHour = 5
export const setBusinessCutoff = (h) => { const n = Number(h); if (Number.isFinite(n) && n >= 0 && n <= 23) cutoffHour = n }
export const businessToday = () => new Date(Date.now() - cutoffHour * 3600 * 1000)
