/**
 * HTTP client for the backend. All calls go to relative `/api/...` URLs so the app works from any device on the LAN.
 *
 * Manager override: when the server replies 403 `override_required`, the registered handler (a PIN modal)
 * asks for a manager PIN and the request is retried with the `X-Manager-Pin` header — transparent to callers.
 */
import { getRegisterId } from './register'

const BASE = '/api'
let overrideHandler = null
export const setOverrideHandler = (fn) => { overrideHandler = fn }

export class ApiError extends Error {
  constructor(message, status, code, detail) {
    super(message)
    this.status = status
    this.code = code
    this.detail = detail
  }
}

export const newRequestId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`).replace(/[^A-Za-z0-9_-]/g, '')

export const getToken = () => localStorage.getItem('cafe_token')
export const setToken = (t) => (t ? localStorage.setItem('cafe_token', t) : localStorage.removeItem('cafe_token'))

function buildUrl(path, params) {
  const url = new URL(BASE + path, window.location.origin)
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v)
  })
  return url
}

async function parseError(res) {
  let message = 'خطا در ارتباط با سرور'
  let code = 'error'
  let detail = null
  try {
    const data = await res.json()
    detail = data.detail
    if (typeof detail === 'string') message = detail
    else if (Array.isArray(detail)) {
      message = 'اطلاعات واردشده معتبر نیست'
      code = 'validation'
    } else if (detail?.message) {
      message = detail.message
      code = detail.code || code
    }
  } catch { /* not json */ }
  if (res.status >= 500 && !detail?.message) message = 'خطای داخلی سرور؛ لطفاً دوباره تلاش کنید'   // proxy/HTML errors
  return new ApiError(message, res.status, code, detail)
}

export async function api(path, { method = 'GET', body, params, headers = {}, raw = false } = {}) {
  const token = getToken()
  let res
  try {
    res = await fetch(buildUrl(path, params), {
      method,
      headers: {
        ...(body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(getRegisterId() ? { 'X-Register-Id': String(getRegisterId()) } : {}),
        ...headers,
      },
      body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError('ارتباط با سرور برقرار نیست؛ اتصال شبکه را بررسی کنید', 0, 'network')
  }
  if (res.status === 401 && !path.startsWith('/staff/auth/')) {
    setToken(null)
    window.dispatchEvent(new Event('auth:logout'))
  }
  if (!res.ok) {
    const err = await parseError(res)
    // `X-Manager-Pin-Retry` is set on the retry itself: without it a server that keeps answering
    // "override required" made the client re-open the PIN dialog for ever.
    if (res.status === 403 && ['override_required', 'override_invalid'].includes(err.code) && overrideHandler && !headers['X-Manager-Pin-Retry']) {
      const pin = await overrideHandler(err)
      if (pin) return api(path, { method, body, params, raw, headers: { ...headers, 'X-Manager-Pin': pin, 'X-Manager-Pin-Retry': '1' } })
      throw new ApiError('عملیات لغو شد', 403, 'override_cancelled')
    }
    throw err
  }
  if (raw) return res
  return res.status === 204 ? null : res.json()
}

export const get = (p, params) => api(p, { params })
export const post = (p, body, opts) => api(p, { method: 'POST', body: body ?? {}, ...opts })
export const put = (p, body) => api(p, { method: 'PUT', body })
export const patch = (p, body) => api(p, { method: 'PATCH', body })
export const del = (p) => api(p, { method: 'DELETE' })

export async function download(path, params, filename) {
  const res = await api(path, { params, raw: true })
  const blob = await res.blob()
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = filename || res.headers.get('Content-Disposition')?.match(/filename="?([^"]+)"?/)?.[1] || 'download'
  a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 2000)
}

export async function upload(file) {
  const fd = new FormData()
  fd.append('file', file)
  return api('/system/upload', { method: 'POST', body: fd })
}
