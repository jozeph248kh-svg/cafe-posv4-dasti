// Helpers for blind cash counting and the end-of-shift report («شیفت من»). Pure functions → unit-tested.
import { money } from './format'

export const HIDDEN = 'پنهان'

/** Money that may be withheld by the server (blind count) — null means hidden, not zero. */
export const cashOr = (v, hidden = HIDDEN) => (v == null ? hidden : money(v))

/** Shift progress toward the planned length: { pct 0..100, overdue, left (minutes, ≥0) }. */
export function shiftProgress(minutes, hours) {
  const plan = Math.max(1, Number(hours) || 8) * 60
  const m = Math.max(0, Number(minutes) || 0)
  return { pct: Math.min(100, Math.round((m * 100) / plan)), overdue: m >= plan, left: Math.max(0, plan - m) }
}

/** Cash difference after counting: label + tone. diff = counted − expected. */
export function diffInfo(diff) {
  if (diff == null) return { text: '—', tone: 'default' }
  if (diff === 0) return { text: 'بدون مغایرت ✓', tone: 'success' }
  return diff > 0 ? { text: `اضافه صندوق: ${money(diff)} تومان`, tone: 'info' } : { text: `کسری صندوق: ${money(-diff)} تومان`, tone: 'error' }
}

/** Sum of a banknote count { denomination: pieces }. */
export const denomTotal = (counts) => Object.entries(counts || {}).reduce((a, [d, n]) => a + Number(d) * (Number(n) || 0), 0)

/** What still blocks clocking out, in order (empty → ready). `status` and `data` come from GET /shifts/my-report. */
export function clockOutBlockers(status, data) {
  const out = []
  if (data?.drawer) out.push('drawer')
  if (status?.required && !status?.can_clock_out) out.push('report')
  return out
}
