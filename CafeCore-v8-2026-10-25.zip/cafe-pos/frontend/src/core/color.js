/** Small colour toolkit for the theme engine: parsing, mixing, WCAG contrast and automatic contrast repair. */

export const HEX_RE = /^#[0-9a-fA-F]{6}$/

export function hexToRgb(hex) {
  const h = String(hex).replace('#', '')
  const f = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  const n = parseInt(f.slice(0, 6), 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export const rgbToHex = (rgb) => `#${rgb.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`

export function rgbToHsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  let h = 0, s = 0
  const l = (max + min) / 2
  if (max !== min) {
    const d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4
    h /= 6
  }
  return [h, s, l]
}

export function hslToRgb([h, s, l]) {
  if (!s) return [l * 255, l * 255, l * 255]
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s
  const p = 2 * l - q
  const hue = (t) => {
    if (t < 0) t += 1
    if (t > 1) t -= 1
    if (t < 1 / 6) return p + (q - p) * 6 * t
    if (t < 1 / 2) return q
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
    return p
  }
  return [hue(h + 1 / 3) * 255, hue(h) * 255, hue(h - 1 / 3) * 255]
}

/** WCAG relative luminance */
export function luminance(hex) {
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4 }
  const [r, g, b] = hexToRgb(hex)
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
}

export function contrast(a, b) {
  const x = luminance(a), y = luminance(b)
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05)
}

/** mix a → b by t (0 = a, 1 = b) */
export const mix = (a, b, t) => { const x = hexToRgb(a), y = hexToRgb(b); return rgbToHex(x.map((v, i) => v + (y[i] - v) * t)) }
export const withLightness = (hex, l) => { const [h, s] = rgbToHsl(hexToRgb(hex)); return rgbToHex(hslToRgb([h, s, Math.max(0, Math.min(1, l))])) }
export const lighten = (hex, d) => withLightness(hex, rgbToHsl(hexToRgb(hex))[2] + d)
export const darken = (hex, d) => withLightness(hex, rgbToHsl(hexToRgb(hex))[2] - d)
export const alpha = (hex, a) => { const [r, g, b] = hexToRgb(hex); return `rgba(${r}, ${g}, ${b}, ${a})` }
export const isDark = (hex) => luminance(hex) < 0.18

/**
 * Return `fg` (hue kept) moved just far enough in lightness to reach `min` contrast against `bg`.
 * Moves away from the background (lighter on dark backgrounds, darker on light ones).
 */
export function ensureContrast(fg, bg, min = 4.5) {
  if (contrast(fg, bg) >= min) return fg
  const [h, s, l0] = rgbToHsl(hexToRgb(fg))
  const up = isDark(bg)
  let lo = up ? l0 : 0, hi = up ? 1 : l0, best = up ? '#ffffff' : '#000000'
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2
    const c = rgbToHex(hslToRgb([h, s, mid]))
    if (contrast(c, bg) >= min) { best = c; if (up) hi = mid; else lo = mid } else if (up) lo = mid; else hi = mid
  }
  return best
}

/** keep the hue but move lightness until luminance falls inside [lo, hi] */
export function fitLuminance(hex, lo, hi) {
  const L = luminance(hex)
  if (L >= lo && L <= hi) return hex
  const target = L < lo ? lo : hi
  const [h, s] = rgbToHsl(hexToRgb(hex))
  let a = 0, b = 1, best = hex
  for (let i = 0; i < 24; i++) {
    const m = (a + b) / 2
    const c = rgbToHex(hslToRgb([h, s, m]))
    best = c
    if (luminance(c) < target) a = m; else b = m
  }
  return best
}

/** readable ink (text colour) for an arbitrary background */
export function inkOn(bg, light = '#ffffff', dark = '#16110d') {
  if (!bg || !HEX_RE.test(bg)) return light
  return contrast(light, bg) >= contrast(dark, bg) ? light : dark
}
