/**
 * Theme engine (Round 9 «تم و اسکین»).
 *
 * A skin = base colours for light + dark mode, a 9-colour palette and a few layout knobs.
 * `derive(skin, dark)` turns it into every CSS variable (index.css uses only var(--…)) and the Ant Design tokens.
 * Readability is enforced here, not left to the skin author: muted text, links, coloured text, text on buttons,
 * tags, avatars, sider and KDS are all pushed to WCAG contrast targets automatically.
 */
import { alpha, contrast, darken, ensureContrast, fitLuminance, HEX_RE, inkOn, isDark, lighten, mix } from './color'

export const COLOR_KEYS = ['primary', 'bg', 'card', 'text', 'muted', 'border', 'sider', 'success', 'warning', 'error', 'info']
export const COLOR_LABELS = {
  primary: 'رنگ اصلی (دکمه‌ها و لینک‌ها)', bg: 'زمینهٔ صفحه', card: 'زمینهٔ کارت‌ها', text: 'متن اصلی', muted: 'متن کم‌رنگ (توضیحات)',
  border: 'خطوط و حاشیه‌ها', sider: 'منوی کناری', success: 'موفق / سبز', warning: 'هشدار / زرد', error: 'خطا / قرمز', info: 'اطلاع / آبی',
}
export const FONTS = {
  vazirmatn: { label: 'وزیرمتن', css: "'Vazirmatn FD', Vazirmatn, Tahoma, sans-serif" },
  tahoma: { label: 'تاهوما', css: "Tahoma, 'Vazirmatn FD', Vazirmatn, sans-serif" },
  system: { label: 'فونت سیستم', css: "system-ui, -apple-system, 'Segoe UI', Tahoma, 'Vazirmatn FD', sans-serif" },
}
export const SCALES = [{ value: 0.9, label: 'کوچک' }, { value: 1, label: 'عادی' }, { value: 1.1, label: 'بزرگ' }, { value: 1.2, label: 'خیلی بزرگ' }]

const base = { radius: 12, font_scale: 1, density: 'comfortable', font: 'vazirmatn' }

export const BUILTIN = [
  { ...base, id: 'classic', name: 'کلاسیک', note: 'طرح اولیهٔ برنامه؛ نیلی و خنثی', radius: 10,
    light: { primary: '#4f46e5', bg: '#f4f5fb', card: '#ffffff', text: '#0f172a', muted: '#5b6678', border: '#e5e7ef', sider: '#111827', success: '#10b981', warning: '#f59e0b', error: '#ef4444', info: '#3b82f6' },
    dark: { primary: '#5b5bd6', bg: '#0b0f19', card: '#141a2a', text: '#e5e7eb', muted: '#9aa6b8', border: '#263049', sider: '#0d1220', success: '#34d399', warning: '#fbbf24', error: '#f87171', info: '#60a5fa' },
    palette: ['#6366f1', '#10b981', '#f59e0b', '#0ea5e9', '#ec4899', '#8b5cf6', '#14b8a6', '#ef4444', '#f97316'] },
  { ...base, id: 'latte', name: 'لاته و اسپرسو', note: 'گرم و قهوه‌ای؛ کرمی در روز، قهوه‌ای تیره در شب',
    light: { primary: '#b4532a', bg: '#f5efe7', card: '#fffdf9', text: '#2a1f17', muted: '#6b5a4b', border: '#e6dacb', sider: '#241a13', success: '#2f8f5b', warning: '#c98a12', error: '#c8402b', info: '#3a72b0' },
    dark: { primary: '#e3a35a', bg: '#12100e', card: '#1f1a16', text: '#f6ede2', muted: '#b9aa99', border: '#3a312a', sider: '#0f0d0b', success: '#86c28b', warning: '#eab54e', error: '#ec6a51', info: '#8db7e0' },
    palette: ['#c2693e', '#2f8f6b', '#d9a23b', '#3a72b0', '#c25b7a', '#7b5ea7', '#2a9d8f', '#d1495b', '#8c6a4f'] },
  { ...base, id: 'jade', name: 'یشم', note: 'سبز آرام و طبیعی',
    light: { primary: '#2f7d5b', bg: '#f2f5f1', card: '#ffffff', text: '#14231b', muted: '#56665d', border: '#dde6df', sider: '#10241c', success: '#2f8f5b', warning: '#c98a12', error: '#c8402b', info: '#2f6fa7' },
    dark: { primary: '#5fbf8f', bg: '#0c1310', card: '#141e19', text: '#e6efe9', muted: '#a3b5aa', border: '#24342c', sider: '#0a110e', success: '#6fcf97', warning: '#e7b65a', error: '#ef7a6a', info: '#7fb2e5' },
    palette: ['#2f7d5b', '#c98a12', '#2f6fa7', '#b5523b', '#7a5ea8', '#2a9d8f', '#d1495b', '#6b8e23', '#8c6a4f'] },
  { ...base, id: 'ocean', name: 'اقیانوس', note: 'آبی فیروزه‌ای، تمیز و روشن',
    light: { primary: '#0e7490', bg: '#f1f6f8', card: '#ffffff', text: '#0c1d26', muted: '#4f6a79', border: '#dae5ea', sider: '#0b1f2a', success: '#0f9f6e', warning: '#d18e12', error: '#d64545', info: '#2563eb' },
    dark: { primary: '#38bdf8', bg: '#071219', card: '#0e1c25', text: '#e2eef4', muted: '#9cb6c4', border: '#1d3340', sider: '#06101a', success: '#4ade80', warning: '#fbbf24', error: '#f87171', info: '#93c5fd' },
    palette: ['#0e7490', '#10b981', '#f59e0b', '#6366f1', '#ec4899', '#14b8a6', '#ef4444', '#8b5cf6', '#f97316'] },
  { ...base, id: 'rose', name: 'رز', note: 'زرشکی و صورتی ملایم',
    light: { primary: '#be185d', bg: '#fbf4f6', card: '#ffffff', text: '#2a0f1c', muted: '#73535f', border: '#f0dde5', sider: '#2a0f1c', success: '#15803d', warning: '#c2780a', error: '#dc2626', info: '#2563eb' },
    dark: { primary: '#f472b6', bg: '#140a0f', card: '#1f1118', text: '#fbe8f0', muted: '#c9a9b8', border: '#3b2230', sider: '#10070c', success: '#4ade80', warning: '#fbbf24', error: '#f87171', info: '#93c5fd' },
    palette: ['#be185d', '#0f766e', '#d97706', '#4f46e5', '#9333ea', '#0891b2', '#dc2626', '#65a30d', '#a16207'] },
  { ...base, id: 'graphite', name: 'گرافیت', note: 'سیاه و سفید مینیمال', radius: 8,
    light: { primary: '#27272a', bg: '#f5f5f6', card: '#ffffff', text: '#111113', muted: '#5c5d66', border: '#e4e4e7', sider: '#18181b', success: '#16a34a', warning: '#ca8a04', error: '#dc2626', info: '#2563eb' },
    dark: { primary: '#e4e4e7', bg: '#0a0a0b', card: '#161618', text: '#f4f4f5', muted: '#a8a8b0', border: '#2a2a2e', sider: '#000000', success: '#4ade80', warning: '#facc15', error: '#f87171', info: '#60a5fa' },
    palette: ['#52525b', '#16a34a', '#ca8a04', '#2563eb', '#db2777', '#7c3aed', '#0d9488', '#dc2626', '#ea580c'] },
]
export const DEFAULT_SKIN_ID = 'classic'
export const BUILTIN_IDS = BUILTIN.map((s) => s.id)

/** Make any (imported / stored / edited) skin object safe: valid hex colours, clamped knobs, fallbacks from classic. */
export function normalizeSkin(raw, fallback = BUILTIN[0]) {
  const s = raw && typeof raw === 'object' ? raw : {}
  const hex = (v, d) => (typeof v === 'string' && HEX_RE.test(v) ? v.toLowerCase() : d)
  const mode = (m, d) => Object.fromEntries(COLOR_KEYS.map((k) => [k, hex(m?.[k], d[k])]))
  const pal = Array.isArray(s.palette) ? s.palette.filter((c) => typeof c === 'string' && HEX_RE.test(c)).slice(0, 9) : []
  const num = (v, lo, hi, d) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d)
  return {
    id: typeof s.id === 'string' && /^[a-z0-9_-]{2,40}$/.test(s.id) ? s.id : fallback.id,
    name: typeof s.name === 'string' && s.name.trim() ? s.name.trim().slice(0, 40) : fallback.name,
    base: typeof s.base === 'string' ? s.base.slice(0, 40) : undefined,
    note: typeof s.note === 'string' ? s.note.slice(0, 120) : undefined,
    light: mode(s.light, fallback.light),
    dark: mode(s.dark, fallback.dark),
    palette: pal.length >= 3 ? [...pal, ...fallback.palette].slice(0, 9) : [...fallback.palette],
    radius: Math.round(num(s.radius, 0, 24, fallback.radius)),
    font_scale: num(s.font_scale, 0.85, 1.25, fallback.font_scale),
    density: s.density === 'compact' ? 'compact' : 'comfortable',
    font: FONTS[s.font] ? s.font : 'vazirmatn',
  }
}

export const allSkins = (custom = []) => [...BUILTIN, ...(custom || []).map((c) => normalizeSkin(c))]
export const findSkin = (id, custom = []) => allSkins(custom).find((s) => s.id === id) || BUILTIN[0]

/** Everything the UI needs for one skin in one mode. Pure function — also used for previews and the contrast report. */
export function derive(skin, dark, opts = {}) {
  const m = dark ? skin.dark : skin.light
  const { bg, card, sider } = m
  const darkUi = isDark(card)
  const text = ensureContrast(m.text, card, 7)
  const elev = darkUi ? lighten(card, 0.035) : card
  const soft = mix(card, text, darkUi ? 0.05 : 0.035)
  const soft2 = mix(card, text, darkUi ? 0.1 : 0.075)
  const bg2 = mix(bg, text, darkUi ? 0.04 : 0.035)
  // secondary text must read on cards, page background and the soft fills it sits on
  const muted = ensureContrast(ensureContrast(ensureContrast(m.muted, card, 4.6), bg, 4.6), soft, 4.5)
  const faint = ensureContrast(mix(muted, card, 0.35), card, 3.1)            // placeholders, decorations
  const border = m.border
  const primary = m.primary
  const primaryInk = inkOn(primary, '#ffffff', ensureContrast(darken(primary, 0.42), primary, 5.5))
  // hover/press move AWAY from the ink so the label keeps its contrast
  const whiteInk = primaryInk === '#ffffff'
  const primaryHover = whiteInk ? darken(primary, 0.08) : lighten(primary, 0.1)
  const primaryActive = whiteInk ? darken(primary, 0.15) : lighten(primary, 0.18)
  const primaryText = ensureContrast(ensureContrast(ensureContrast(primary, card, 4.6), bg, 4.5), elev, 4.6)   // links / primary-coloured text (cards, page, popovers)
  // a little headroom above 4.5 so the colour still reads on its own 10–15% tinted background
  const semantic = (c) => ensureContrast(ensureContrast(ensureContrast(ensureContrast(c, card, 5), bg, 4.6), elev, 4.6), mix(card, c, 0.14), 4.5)
  const green = semantic(m.success), amber = semantic(m.warning), red = semantic(m.error), blue = semantic(m.info)

  // palette: one band per mode so the same colour works as text, icon, chart and solid tag background
  //   light: dark-enough for white ink and for text on white;  dark: light-enough for dark ink and text on dark cards
  const palInk = darkUi ? '#14110f' : '#ffffff'
  const pal = skin.palette.map((c) => (darkUi ? fitLuminance(c, 0.3, 0.6) : fitLuminance(c, 0.04, 0.17)))
  const chart = skin.palette.map((c) => ensureContrast(c, card, 2.2))
  const violet = semantic(skin.palette[5] || primary)
  // solid fills that carry white text (ready table, account cards, reservation chip…) in every mode
  const solid = (c) => ensureContrast(c, '#ffffff', 4.6)

  // hero / gradients: white text must stay readable
  const heroBase = ensureContrast(darkUi ? mix(primary, card, 0.35) : primary, '#ffffff', 6)
  const heroLight = ensureContrast(mix(heroBase, '#ffffff', 0.16), '#ffffff', 5.4)
  const heroDeep = darken(heroBase, darkUi ? 0.16 : 0.2)
  const hero = darkUi
    ? `radial-gradient(130% 120% at 0% 0%, ${heroLight} 0%, ${heroBase} 42%, ${heroDeep} 100%)`
    : `radial-gradient(130% 120% at 0% 0%, ${heroLight} 0%, ${heroBase} 40%, ${heroDeep} 100%)`
  const heroFlat = `linear-gradient(135deg, ${heroBase} 0%, ${heroDeep} 100%)`

  // sider is a dark surface in every skin (unless someone picks a light sider — then ink flips automatically)
  const siderDark = isDark(sider)
  const siderText = siderDark ? ensureContrast(mix(sider, '#ffffff', 0.78), sider, 7) : ensureContrast(mix(sider, '#000000', 0.8), sider, 7)
  const siderMuted = ensureContrast(mix(sider, siderText, 0.55), sider, 4.5)
  const siderActive = ensureContrast(siderDark ? (darkUi ? primary : lighten(primary, 0.18)) : primary, sider, 4.8)
  const shadowTint = darkUi ? '0, 0, 0' : hexRgbStr(darken(text, 0.05))

  // KDS is always dark: it uses the skin's dark mode
  const k = skin.dark, kCard = k.card
  const kText = ensureContrast(k.text, kCard, 7)

  const radius = skin.radius
  const vars = {
    '--font': FONTS[skin.font]?.css || FONTS.vazirmatn.css,
    '--primary': primary, '--primary-ink': primaryInk, '--primary-text': primaryText,
    '--bg': bg, '--bg2': bg2, '--card': card, '--elev': elev, '--text': text, '--muted': muted, '--faint': faint,
    '--border': border, '--soft': soft, '--soft2': soft2,
    '--green': green, '--amber': amber, '--red': red, '--blue': blue, '--violet': violet,
    '--ok-solid': solid(m.success), '--warn-solid': solid(m.warning), '--bad-solid': solid(m.error), '--info-solid': solid(m.info),
    '--violet-solid': solid(skin.palette[5] || primary), '--muted-solid': solid(muted),
    '--green-raw': m.success, '--amber-raw': m.warning, '--red-raw': m.error, '--blue-raw': m.info,
    '--accent-soft': alpha(primary, darkUi ? 0.16 : 0.1), '--accent-2': pal[1] || primary,
    '--hero': hero, '--hero-flat': heroFlat, '--hero-base': heroBase, '--hero-ink': '#ffffff',
    '--glow': `0 0 0 ${darkUi ? 1 : 2}px ${alpha(primary, 0.35)}, 0 14px 30px -16px ${alpha(primary, 0.5)}`,
    '--shadow-rgb': shadowTint,
    '--shadow': darkUi ? '0 1px 0 rgba(255, 255, 255, .04) inset, 0 18px 40px -24px rgba(0, 0, 0, .8)' : `0 1px 2px rgba(${shadowTint}, .05), 0 12px 30px -18px rgba(${shadowTint}, .25)`,
    '--aurora': `radial-gradient(60% 50% at 90% 0%, ${alpha(primary, darkUi ? 0.13 : 0.09)}, transparent 70%), radial-gradient(50% 40% at 0% 100%, ${alpha(pal[1] || primary, darkUi ? 0.09 : 0.07)}, transparent 70%)`,
    '--radius': `${radius + 6}px`, '--radius-lg': `${radius + 4}px`, '--radius-md': `${radius}px`, '--radius-sm': `${Math.max(0, radius - 4)}px`,
    '--sider-bg': sider, '--sider-text': siderText, '--sider-muted': siderMuted, '--sider-active': siderActive,
    '--sider-active-bg': alpha(siderActive, 0.16), '--sider-hover': alpha(siderText, 0.07),
    '--brand-grad': `radial-gradient(120% 140% at 100% 0%, ${lighten(heroBase, 0.08)}, ${darken(heroBase, 0.18)})`,
    '--pal-ink': palInk, '--tooltip-bg': darkUi ? lighten(card, 0.12) : mix(text, '#000000', 0.15),
    '--k-bg': k.bg, '--k-top': mix(k.bg, kCard, 0.5), '--k-card': kCard, '--k-card2': lighten(kCard, 0.04), '--k-line': alpha(kText, 0.09),
    '--k-text': kText, '--k-muted': ensureContrast(k.muted, kCard, 4.6), '--k-soft': ensureContrast(mix(k.muted, kText, 0.35), kCard, 6),
    '--k-ok': ensureContrast(k.success, kCard, 4.5), '--k-warn': ensureContrast(k.warning, kCard, 4.5), '--k-late': ensureContrast(k.error, kCard, 4.5),
    '--k-ready': ensureContrast(k.info, kCard, 4.5), '--k-accent': ensureContrast(k.primary, kCard, 3.2), '--k-accent-ink': inkOn(ensureContrast(k.primary, kCard, 3.2), '#ffffff', '#14110f'),
    '--k-sel': lighten(kCard, 0.1),
  }
  pal.forEach((c, i) => { vars[`--pal-${i + 1}`] = c })
  chart.forEach((c, i) => { vars[`--chart-${i + 1}`] = c })

  const scale = opts.fontScale || skin.font_scale || 1
  const antd = {
    dark: darkUi, compact: skin.density === 'compact',
    token: {
      colorPrimary: primary, colorLink: primaryText,
      ...(darkUi ? { colorInfo: m.info, colorSuccess: m.success, colorWarning: m.warning, colorError: m.error }
        : { colorInfo: blue, colorSuccess: green, colorWarning: amber, colorError: red }),
      colorBgLayout: bg, colorBgContainer: card, colorBgElevated: elev, colorFillAlter: soft,
      colorBorder: border, colorBorderSecondary: mix(border, card, 0.45), colorSplit: alpha(text, darkUi ? 0.1 : 0.07),
      colorText: text, colorTextHeading: text, colorTextSecondary: muted, colorTextTertiary: muted, colorTextDescription: muted,
      colorTextPlaceholder: muted, colorTextQuaternary: faint, colorTextLabel: muted,
      colorTextLightSolid: primaryInk,
      borderRadius: radius, fontFamily: vars['--font'], fontSize: Math.round(14 * scale),
    },
    components: {
      Layout: { headerBg: card, siderBg: sider, bodyBg: bg },
      Card: { headerFontSize: Math.round(15 * scale) },
      Table: { headerBg: soft, headerColor: muted, rowHoverBg: mix(card, primary, 0.05) },
      // the sider menu text must contrast the sider, not the page
      Menu: { darkItemBg: 'transparent', darkItemColor: siderText, darkItemHoverColor: siderDark ? '#ffffff' : text, darkGroupTitleColor: siderMuted,
        darkItemSelectedBg: alpha(siderActive, 0.16), darkItemSelectedColor: siderActive, darkItemHoverBg: alpha(siderText, 0.07), colorTextLightSolid: siderText },
      Tooltip: { colorTextLightSolid: '#ffffff', colorBgSpotlight: vars['--tooltip-bg'] },
      Avatar: { colorTextLightSolid: palInk },
      Tag: { colorTextLightSolid: palInk },
      Badge: { colorTextLightSolid: '#ffffff', colorError: solid(m.error) },
      Tabs: { itemSelectedColor: primaryText, itemHoverColor: primaryText, itemActiveColor: primaryText, inkBarColor: primaryText },
      Segmented: { itemSelectedBg: darkUi ? soft2 : card, itemColor: muted, itemSelectedColor: text },
      Button: { fontWeight: 600, primaryShadow: 'none', dangerShadow: 'none', defaultShadow: 'none',
        colorPrimary: primary, colorPrimaryHover: primaryHover, colorPrimaryActive: primaryActive, primaryColor: primaryInk },
      Steps: { colorPrimary: primary, colorTextLightSolid: primaryInk },
    },
  }
  // charts: resolved hex values (SVG attributes; Safari can't be trusted with var() there)
  const g = (c) => ensureContrast(c, card, 2.4)
  const chartSem = { green: g(m.success), amber: g(m.warning), red: g(m.error), blue: g(m.info), faint: g(faint), grid: border, accent: chart[0] }
  return { vars, antd, chart, pal, chartSem }
}

const hexRgbStr = (hex) => { const n = parseInt(hex.slice(1), 16); return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}` }

/** Contrast report for the editor: what the user picked vs what the engine will actually render.
 *  `key` = the skin colour an «auto-fix» may overwrite with `used` (the engine already renders `used`). */
export function contrastReport(skin) {
  const rows = []
  for (const dark of [false, true]) {
    const m = dark ? skin.dark : skin.light
    const { vars } = derive(skin, dark)
    const add = (label, fg, bg, min, picked, key) => rows.push({ dark, label, key, bg, ratio: contrast(fg, bg), min, fixed: !!picked && picked !== fg, picked, used: fg })
    add('متن اصلی روی کارت', vars['--text'], m.card, 7, m.text, 'text')
    add('متن کم‌رنگ روی کارت', vars['--muted'], m.card, 4.5, m.muted, 'muted')
    add('متن کم‌رنگ روی زمینه', vars['--muted'], m.bg, 4.5, m.muted)
    add('لینک و متن رنگی', vars['--primary-text'], m.card, 4.5, m.primary)
    add('نوشتهٔ روی دکمهٔ اصلی', vars['--primary-ink'], m.primary, 4.5)
    add('منوی کناری', vars['--sider-text'], m.sider, 7)
    add('گزینهٔ فعال منو', vars['--sider-active'], m.sider, 4.5)
    add('متن سبز/موفق', vars['--green'], m.card, 4.5, m.success, 'success')
    add('متن قرمز/خطا', vars['--red'], m.card, 4.5, m.error, 'error')
    add('متن زرد/هشدار', vars['--amber'], m.card, 4.5, m.warning, 'warning')
    add('متن آبی/اطلاع', vars['--blue'], m.card, 4.5, m.info, 'info')
  }
  return rows
}

/** Apply a derived skin to <html> (inline custom properties beat the stylesheet's defaults). */
export function applyVars(vars, dark) {
  const el = document.documentElement
  Object.entries(vars).forEach(([k, v]) => el.style.setProperty(k, v))
  el.dataset.theme = dark ? 'dark' : 'light'
  el.style.colorScheme = dark ? 'dark' : 'light'
}

export const exportSkin = (skin) => JSON.stringify({ kind: 'cafe-pos-skin', version: 1, skin: normalizeSkin(skin) }, null, 2)
export function importSkin(text) {
  const data = JSON.parse(text)
  const raw = data?.kind === 'cafe-pos-skin' ? data.skin : data
  if (!raw || typeof raw !== 'object' || !raw.light || !raw.dark) throw new Error('فایل تم معتبر نیست')
  return normalizeSkin(raw)
}

export const contrastOK = (fg, bg, min = 4.5) => contrast(fg, bg) >= min
