import { describe, expect, it } from 'vitest'
import dayjs from 'dayjs'
import './jalali'          // installs the Persian calendar app-wide (same import main.jsx uses)

// Three calendars must agree: the backend (its own algorithm, cross-checked against `jdatetime`),
// the date pickers / printed receipts (dayjs + jalaliday, below) and the browser's ICU.
const icu = new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric' })
const asIcu = (d) => {
  const p = Object.fromEntries(icu.formatToParts(d).map((x) => [x.type, x.value]))
  return `${p.year}/${Number(p.month)}/${Number(p.day)}`
}
const asDayjs = (d) => {
  const j = dayjs(d).calendar('jalali')
  return `${j.year()}/${j.month() + 1}/${j.date()}`
}

describe('Persian (Jalali) calendar', () => {
  it.each([
    ['2024-03-19', '1402/12/29'],
    ['2024-03-20', '1403/1/1'],
    ['2025-03-19', '1403/12/29'],
    ['2026-03-21', '1405/1/1'],
    ['2026-10-23', '1405/8/1'],
  ])('%s is %s', (iso, jalali) => {
    expect(asDayjs(new Date(`${iso}T12:00:00`))).toBe(jalali)
    expect(asIcu(new Date(`${iso}T12:00:00`))).toBe(jalali)
  })

  it('agrees with the browser calendar for every day from 2020 to 2040', () => {
    const bad = []
    for (const d = new Date('2020-01-01T12:00:00'); d < new Date('2040-01-01T12:00:00'); d.setDate(d.getDate() + 1)) {
      const ours = asDayjs(d)
      const ref = asIcu(d)
      if (ours !== ref) bad.push(`${d.toISOString().slice(0, 10)}: ${ours} (expected ${ref})`)
    }
    expect(bad).toEqual([])
  })

  it('parses a Jalali date back to the same Gregorian day (the picker direction)', () => {
    const bad = []
    for (const d = new Date('2024-01-01T12:00:00'); d < new Date('2030-01-01T12:00:00'); d.setDate(d.getDate() + 1)) {
      const iso = d.toISOString().slice(0, 10)
      const parsed = dayjs(asIcu(d), { format: 'YYYY/MM/DD', jalali: true })
      if (!parsed.isValid()) { bad.push(`${iso}: \u200e${asIcu(d)} is not parseable`); continue }
      const back = parsed.toDate()
      const got = `${back.getFullYear()}-${String(back.getMonth() + 1).padStart(2, '0')}-${String(back.getDate()).padStart(2, '0')}`
      if (got !== iso) bad.push(`${iso} (${asIcu(d)}) -> ${got}`)
    }
    expect(bad).toEqual([])
  })

  it('keeps the leap day of 1403 and the short month of 1404', () => {
    // the two dates the old calendar math got wrong
    expect(asDayjs(new Date('2025-03-20T12:00:00'))).toBe('1403/12/30')
    expect(asDayjs(new Date('2026-03-20T12:00:00'))).toBe('1404/12/29')
    expect(asDayjs(new Date('2026-03-21T12:00:00'))).toBe('1405/1/1')
  })
})
