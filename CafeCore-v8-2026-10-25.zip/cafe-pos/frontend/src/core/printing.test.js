import { describe, expect, it, vi, beforeEach } from 'vitest'

/**
 * Receipts and kitchen tickets. These produce what the customer and the cook physically hold, so
 * the amounts, the "void lines are not printed" rule and the ESC/POS bit packing are all pinned.
 */
const post = vi.fn()
vi.mock('./api', () => ({
  get: vi.fn(), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('./register', () => ({ getRegisterId: () => 2 }))

const { receiptBlocks, kitchenBlocks } = await import('./print')
const { packBits, toBase64, receiptPrinter, stationPrinter, printBlocks } = await import('./escpos')

const SETTINGS = {
  'business.name': 'کافه ونک',
  'business.address': 'تهران، ونک',
  'business.phone': '02188776655',
  'business.logo': null,
  'business.wifi': 'cafe-1234',
  'receipt.show_logo': true,
  'receipt.footer': 'روز خوبی داشته باشید',
  'currency.label': 'تومان',
}
const ORDER = {
  number: 42, type: 'dine_in', table_name: '۳', waiter_name: 'علی', guests: 2, customer_name: 'شیرین',
  created_at: '2026-10-23T19:00:00', closed_at: '2026-10-23T19:40:00',
  subtotal: 370_000, line_discount_amount: 20_000, discount_amount: 50_000, discount_type: 'percent', discount_value: 10,
  service_amount: 32_000, tax_amount: 31_680, rounding: -680, total: 383_000,
  lines: [
    { name: 'اسپرسو', qty: 2, unit_price: 140_000, total: 280_000, status: 'served', modifiers: [{ name: 'بزرگ' }], note: 'بدون شکر', discount_amount: 20_000, discount_type: 'percent', discount_value: 10 },
    { name: 'چیزکیک', qty: 1, unit_price: 90_000, total: 90_000, status: 'served' },
    { name: 'حذف‌شده', qty: 1, unit_price: 50_000, total: 50_000, status: 'void' },
  ],
  payments: [
    { method: 'card', amount: 383_000, change: 0, is_refund: false },
    { method: 'cash', amount: 20_000, change: 5_000, is_refund: false },
  ],
}
const texts = (blocks) => blocks.filter((b) => b && b.text).map((b) => b.text)
const joined = (blocks) => texts(blocks).join(' | ')

describe('receiptBlocks', () => {
  it('prints the business header, the order and the table', () => {
    const b = receiptBlocks(ORDER, SETTINGS)
    expect(joined(b)).toContain('کافه ونک')
    expect(joined(b)).toContain('تهران، ونک')
    expect(joined(b)).toContain('تلفن: 02188776655')
    expect(joined(b)).toContain('#۴۲')
    expect(joined(b)).toContain('میز ۳')
    expect(joined(b)).toContain('گارسون: علی — ۲ نفر')
    expect(joined(b)).toContain('مشتری: شیرین')
  })

  it('prints each line with its price, modifiers, note and item discount', () => {
    const b = receiptBlocks(ORDER, SETTINGS)
    expect(joined(b)).toContain('۲× اسپرسو')
    expect(joined(b)).toContain('بزرگ')
    expect(joined(b)).toContain('* بدون شکر')
    const disc = b.find((x) => x && x.text && x.text.includes('تخفیف') && x.left)
    expect(disc.left).toContain('۲۰٬۰۰۰')
  })

  it('never prints a voided line', () => {
    expect(joined(receiptBlocks(ORDER, SETTINGS))).not.toContain('حذف‌شده')
  })

  it('prints the money block in the right order and the final amount', () => {
    const b = receiptBlocks(ORDER, SETTINGS)
    const t = joined(b)
    expect(t).toContain('جمع اقلام')
    expect(t).toContain('تخفیف اقلام')
    expect(t).toContain('تخفیف فاکتور')
    expect(t).toContain('سود شما از این خرید')
    expect(t).toContain('حق سرویس')
    expect(t).toContain('مالیات بر ارزش افزوده')
    expect(t).toContain('رُند')
    const total = b.find((x) => x && x.text === 'مبلغ قابل پرداخت')
    expect(total.left).toContain('۳۸۳٬۰۰۰')
    expect(total.left).toContain('تومان')
  })

  it('shows the bill discount without double counting the item discounts', () => {
    const b = receiptBlocks(ORDER, SETTINGS)
    const billDisc = b.find((x) => x && x.text && x.text.startsWith('تخفیف فاکتور'))
    // 50,000 total − 20,000 already given on the items = 30,000 on the bill
    expect(billDisc.left).toContain('۳۰٬۰۰۰')
  })

  it('prints the payments and the change on a receipt but not on a proforma bill', () => {
    expect(joined(receiptBlocks(ORDER, SETTINGS))).toContain('باقیمانده پرداختی به مشتری')
    const bill = receiptBlocks(ORDER, SETTINGS, 'bill')
    expect(joined(bill)).toContain('پیش‌فاکتور')
    expect(joined(bill)).not.toContain('باقیمانده پرداختی به مشتری')
  })

  it('prints the wifi and the footer at the bottom', () => {
    const t = joined(receiptBlocks(ORDER, SETTINGS))
    expect(t).toContain('WiFi: cafe-1234')
    expect(t).toContain('روز خوبی داشته باشید')
  })

  it('omits the logo block when no logo is configured', () => {
    const b = receiptBlocks(ORDER, { ...SETTINGS, 'business.logo': 'https://x/logo.png' })
    expect(b.some((x) => x && x.img)).toBe(true)
    expect(receiptBlocks(ORDER, SETTINGS).some((x) => x && x.img)).toBe(false)
  })
})

describe('kitchenBlocks', () => {
  const ticket = {
    order_number: 42, order_type: 'dine_in', table_name: '۳', waiter_name: 'علی', created_at: '2026-10-23T19:00:00',
    note: 'بدون یخ لطفاً',
    items: [
      { name: 'اسپرسو', qty: 2, modifiers: [{ name: 'بزرگ' }], note: 'بدون شکر' },
      { name: 'حذف‌شده', qty: 1, is_void: true },
    ],
  }

  it('prints the station, the big order number and the table', () => {
    const b = kitchenBlocks(ticket, 'بار')
    expect(joined(b)).toContain('بار')
    expect(joined(b)).toContain('#۴۲')
    expect(joined(b)).toContain('میز ۳')
    expect(b.find((x) => x && x.text === '#۴۲').size).toBeGreaterThan(40)   // big enough to read across the kitchen
  })

  it('prints no prices in the kitchen (only the time on the header line)', () => {
    const b = kitchenBlocks(ticket, 'بار').filter((x) => x && x.text && /اسپرسو|چیزکیک|×/.test(x.text))
    expect(b.length).toBeGreaterThan(0)
    expect(b.every((x) => !x.left)).toBe(true)
  })

  it('keeps voided items off the ticket and prints the note', () => {
    const t = joined(kitchenBlocks(ticket, 'بار'))
    expect(t).not.toContain('حذف‌شده')
    expect(t).toContain('بدون یخ لطفاً')
    expect(t).toContain('بزرگ')
  })
})

describe('ESC/POS helpers', () => {
  it('packs dark opaque pixels as black, MSB first', () => {
    // 8 pixels wide, 1 row: black, black, white…
    const px = []
    for (const [r, g, b, a] of [[0, 0, 0, 255], [0, 0, 0, 255], [255, 255, 255, 255], [255, 255, 255, 255], [255, 255, 255, 255], [255, 255, 255, 255], [255, 255, 255, 255], [255, 255, 255, 255]]) px.push(r, g, b, a)
    const bits = packBits(new Uint8ClampedArray(px), 8, 1)
    expect(bits[0]).toBe(0b11000000)
  })

  it('treats transparent or light pixels as white', () => {
    const px = new Uint8ClampedArray([0, 0, 0, 0, 240, 240, 240, 255])   // transparent black, then near-white
    const bits = packBits(px, 8, 1)
    expect(bits[0]).toBe(0)
  })

  it('encodes the bitmap as base64', () => {
    const bits = new Uint8Array([0b11000000, 0b00000001])
    expect(toBase64(bits)).toBe(btoa('\xc0\x01'))
  })

  it('picks the printer of this register, else the one for all registers', () => {
    const all = { id: 1, receipt: true }
    const mine = { id: 2, receipt: true, register_id: 2 }
    const other = { id: 3, receipt: true, register_id: 9 }
    expect(receiptPrinter({ 'print.printers': [all, other, mine] }).id).toBe(2)
    expect(receiptPrinter({ 'print.printers': [all, other] }).id).toBe(1)
    expect(receiptPrinter({ 'print.printers': [other] })).toBe(null)      // nothing for register 2
    expect(receiptPrinter({})).toBe(null)
  })

  it('routes a station to its own printer', () => {
    const printers = [{ id: 1, station_ids: [3, 4] }, { id: 2, station_ids: [5] }]
    expect(stationPrinter({ 'print.printers': printers }, 4).id).toBe(1)
    expect(stationPrinter({ 'print.printers': printers }, 5).id).toBe(2)
    expect(stationPrinter({ 'print.printers': printers }, 99)).toBe(null)
  })

  it('sends the raster and the drawer/copies flags to the printer endpoint', async () => {
    // jsdom has no canvas: give rasterize a 2d context that reports a tiny bitmap
    const ctx = { direction: 'rtl', fillStyle: '', textAlign: '', font: '', measureText: () => ({ width: 10 }), fillRect() {}, fillText() {}, drawImage() {},
      getImageData: (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4) }) }
    HTMLCanvasElement.prototype.getContext = function () { return ctx }
    post.mockClear()
    post.mockResolvedValue({ ok: true })
    await printBlocks({ id: 7, width: 576 }, [{ text: 'x' }], { drawer: true, copies: 2 })
    expect(post).toHaveBeenCalledWith('/system/print', expect.objectContaining({ printer_id: 7, drawer: true, copies: 2, width: 576 }))
  })
})
