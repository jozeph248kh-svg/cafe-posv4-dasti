/** One shared WebSocket per browser tab; auto-reconnects; components subscribe by topic. */
import { useEffect, useRef, useSyncExternalStore } from 'react'
import { getToken } from './api'

const listeners = new Map()          // topic -> Set(fn)
const statusSubs = new Set()
let ws = null
let status = 'offline'
let retry = 0
let pingTimer = null
let stopped = true

function setStatus(s) {
  status = s
  statusSubs.forEach((fn) => fn())
}

function connect() {
  const token = getToken()
  if (!token || stopped) return
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  ws = new WebSocket(`${proto}://${window.location.host}/ws?token=${encodeURIComponent(token)}`)
  setStatus('connecting')
  ws.onopen = () => {
    retry = 0
    setStatus('online')
    clearInterval(pingTimer)
    pingTimer = setInterval(() => ws?.readyState === 1 && ws.send('ping'), 25000)
    emit('_reconnected', null)        // let pages refresh data they may have missed
  }
  ws.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data)
      if (msg.topic !== 'pong') emit(msg.topic, msg.data)
    } catch { /* ignore */ }
  }
  ws.onclose = (e) => {
    clearInterval(pingTimer)
    ws = null
    setStatus('offline')
    if (e.code === 4401 || stopped) return
    retry = Math.min(retry + 1, 6)
    setTimeout(connect, 500 * 2 ** retry)
  }
}

function emit(topic, data) {
  listeners.get(topic)?.forEach((fn) => fn(data, topic))
  listeners.get('*')?.forEach((fn) => fn(data, topic))
}

export function startRealtime() {
  if (!stopped && ws) return
  stopped = false
  connect()
}
export function stopRealtime() {
  stopped = true
  ws?.close()
}

export function subscribe(topic, fn) {
  if (!listeners.has(topic)) listeners.set(topic, new Set())
  listeners.get(topic).add(fn)
  return () => listeners.get(topic)?.delete(fn)
}

/** useRealtime(['order.changed', 'floor.changed'], (data, topic) => ...) */
export function useRealtime(topics, handler) {
  const ref = useRef(handler)
  // keep the latest handler for the subscription below. Assigning during render is a React
  // violation (concurrent rendering may render without committing, leaving a callback from a
  // render that never happened) — an effect is the sanctioned place.
  useEffect(() => { ref.current = handler })
  const key = [].concat(topics).join('|')
  useEffect(() => {
    const offs = key.split('|').map((t) => subscribe(t, (d, tp) => ref.current(d, tp)))
    return () => offs.forEach((off) => off())
  }, [key])
}

export function useWsStatus() {
  return useSyncExternalStore((cb) => { statusSubs.add(cb); return () => statusSubs.delete(cb) }, () => status)
}

/** Short notification sound without audio files (WebAudio). */
let audioCtx = null
export function beep(kind = 'new') {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)()
    const notes = kind === 'ready' ? [880, 1175, 1568] : kind === 'call' ? [988, 784, 988, 784] : [660, 880]
    notes.forEach((f, i) => {
      const o = audioCtx.createOscillator()
      const g = audioCtx.createGain()
      o.type = 'sine'
      o.frequency.value = f
      const t = audioCtx.currentTime + i * 0.16
      g.gain.setValueAtTime(0.0001, t)
      g.gain.exponentialRampToValueAtTime(0.25, t + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.15)
      o.connect(g).connect(audioCtx.destination)
      o.start(t)
      o.stop(t + 0.16)
    })
  } catch { /* audio blocked until user interaction */ }
}
