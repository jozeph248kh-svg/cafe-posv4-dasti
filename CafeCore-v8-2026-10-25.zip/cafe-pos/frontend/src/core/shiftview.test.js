import { describe, expect, it } from 'vitest'
import { HIDDEN, cashOr, clockOutBlockers, denomTotal, diffInfo, shiftProgress } from './shiftview'

describe('blind count helpers', () => {
  it('null money is hidden, not zero', () => {
    expect(cashOr(null)).toBe(HIDDEN)
    expect(cashOr(undefined, '—')).toBe('—')
    expect(cashOr(0)).toBe('۰')
    expect(cashOr(1250000)).toBe('۱٬۲۵۰٬۰۰۰')
  })
  it('difference label and tone', () => {
    expect(diffInfo(0).tone).toBe('success')
    expect(diffInfo(-5000)).toEqual({ text: 'کسری صندوق: ۵٬۰۰۰ تومان', tone: 'error' })
    expect(diffInfo(2000).tone).toBe('info')
    expect(diffInfo(null).text).toBe('—')
  })
  it('banknote count total', () => {
    expect(denomTotal({ 100000: 3, 5000: '2', 500: null })).toBe(310000)
    expect(denomTotal(undefined)).toBe(0)
  })
})

describe('shift progress and clock-out', () => {
  it('progress toward the planned hours', () => {
    expect(shiftProgress(240, 8)).toEqual({ pct: 50, overdue: false, left: 240 })
    expect(shiftProgress(600, 8)).toEqual({ pct: 100, overdue: true, left: 0 })
    expect(shiftProgress(null, undefined).left).toBe(480)
    expect(shiftProgress(-5, 0).pct).toBe(0)
  })
  it('what blocks a clock-out', () => {
    expect(clockOutBlockers({ required: true, can_clock_out: false }, { drawer: { shift_id: 1 } })).toEqual(['drawer', 'report'])
    expect(clockOutBlockers({ required: true, can_clock_out: true }, { drawer: null })).toEqual([])
    expect(clockOutBlockers({ required: false, can_clock_out: false }, {})).toEqual([])
  })
})
