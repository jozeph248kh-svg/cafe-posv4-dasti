import { afterEach, describe, expect, it } from 'vitest'
import { businessToday, isoDate, modText, money, moneyFormatter, moneyParser, num, setBusinessCutoff, toEnDigits } from './format'

describe('number formatting', () => {
  it('Persian digits with grouping; money is rounded', () => {
    expect(num(1234567)).toBe('۱٬۲۳۴٬۵۶۷')
    expect(money(1999.6)).toBe('۲٬۰۰۰')
    expect(money(null)).toBe('۰')
  })
  it('inputs accept Persian/Arabic digits and separators', () => {
    expect(toEnDigits('۱۲۳٤٥')).toBe('12345')
    expect(moneyParser('۱٬۲۵۰٬۰۰۰ تومان')).toBe('1250000')
    expect(moneyFormatter(1250000)).toBe('1,250,000')
    expect(moneyFormatter('')).toBe('')
  })
  it('modifier text', () => {
    expect(modText([{ name: 'تند' }, { name: 'بزرگ' }])).toBe('تند، بزرگ')
    expect(modText(null)).toBe('')
  })
})

// The UI's "today" follows the business day exactly like the server (day.cutoff_hour, 05:00 by default):
// at 01:30 the café is still on last night's day. (Ported from the old qa/test_business_day.mjs script,
// which nothing ran.)
describe('business day', () => {
  const realNow = Date.now
  afterEach(() => { Date.now = realNow; setBusinessCutoff(5) })
  const at = (iso) => { const t = new Date(iso).getTime(); Date.now = () => t }

  it('rolls over at the cutoff hour', () => {
    at('2026-10-23T01:30:00'); expect(isoDate(businessToday())).toBe('2026-10-22')
    at('2026-10-23T04:59:00'); expect(isoDate(businessToday())).toBe('2026-10-22')
    at('2026-10-23T05:00:00'); expect(isoDate(businessToday())).toBe('2026-10-23')
    at('2026-10-23T23:59:00'); expect(isoDate(businessToday())).toBe('2026-10-23')
  })

  it('honours a configured cutoff and ignores garbage', () => {
    setBusinessCutoff(0); at('2026-10-23T00:10:00'); expect(isoDate(businessToday())).toBe('2026-10-23')
    setBusinessCutoff('abc'); expect(isoDate(businessToday())).toBe('2026-10-23')
    setBusinessCutoff(3); at('2026-10-23T02:00:00'); expect(isoDate(businessToday())).toBe('2026-10-22')
  })
})
