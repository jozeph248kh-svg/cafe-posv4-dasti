/**
 * Theme provider (Round 9): business-wide skin chosen by the manager + per-device overrides.
 *
 *   business theme  — server setting `ui.theme` = { skin, custom[] }   (GET /api/system/theme is public: login page needs it)
 *   device override — localStorage: cafe_skin (skin id or '' = follow business), cafe_dark ('0' | '1' | 'auto'),
 *                     cafe_fs (text size or '' = follow skin)
 *   preview         — temporary skin while editing in «ظاهر و تم» (this tab only)
 *
 * The derived CSS variables are written on <html> before React paints (from a cached copy), so there is no flash.
 */
import { App as AntApp, ConfigProvider, theme as antTheme } from 'antd'
import faIR from 'antd/locale/fa_IR'
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { get, put } from './api'
import { subscribe } from './realtime'
import { allSkins, applyVars, DEFAULT_SKIN_ID, derive, findSkin, normalizeSkin } from './skins'

const ThemeCtx = createContext(null)
const CACHE = 'cafe_theme_cache'
const ls = (k, d = '') => { try { return localStorage.getItem(k) ?? d } catch { return d } }
const lsSet = (k, v) => { try { if (v === '' || v === null || v === undefined) localStorage.removeItem(k); else localStorage.setItem(k, v) } catch { /* private mode */ } }

function readCache() {
  try {
    const t = JSON.parse(ls(CACHE, 'null'))
    if (t && typeof t.skin === 'string') return { skin: t.skin, custom: Array.isArray(t.custom) ? t.custom.map((c) => normalizeSkin(c)) : [] }
  } catch { /* corrupt cache */ }
  return { skin: DEFAULT_SKIN_ID, custom: [] }
}
const systemDark = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches

function resolve(business, deviceSkin, mode, deviceScale, preview) {
  const skin = preview || findSkin(deviceSkin || business.skin, business.custom)
  const dark = mode === 'auto' ? systemDark() : mode === '1'
  const fontScale = deviceScale ? Number(deviceScale) : skin.font_scale
  return { skin, dark, fontScale, ...derive(skin, dark, { fontScale }) }
}

// paint immediately (before the first React render) from the cached business theme + device prefs
try {
  const r = resolve(readCache(), ls('cafe_skin'), ls('cafe_dark', '0'), ls('cafe_fs'), null)
  applyVars(r.vars, r.dark)
} catch { /* never block startup on theming */ }

export function ThemeProvider({ children }) {
  const [business, setBusiness] = useState(readCache)
  const [deviceSkin, setDeviceSkinState] = useState(() => ls('cafe_skin'))
  const [mode, setModeState] = useState(() => (['0', '1', 'auto'].includes(ls('cafe_dark')) ? ls('cafe_dark') : '0'))
  const [deviceScale, setDeviceScaleState] = useState(() => ls('cafe_fs'))
  const [preview, setPreview] = useState(null)
  const [tick, setTick] = useState(0)

  const acceptBusiness = useCallback((t) => {
    if (!t || typeof t.skin !== 'string') return
    const next = { skin: t.skin, custom: Array.isArray(t.custom) ? t.custom.map((c) => normalizeSkin(c)) : [] }
    lsSet(CACHE, JSON.stringify(next))
    setBusiness(next)
  }, [])
  const reload = useCallback(() => get('/system/theme').then(acceptBusiness).catch(() => { /* offline: keep cache */ }), [acceptBusiness])

  useEffect(() => { reload() }, [reload])
  useEffect(() => subscribe('theme.changed', () => reload()), [reload])          // manager saved a new theme → every device follows
  useEffect(() => {                                                                 // «auto» follows the OS light/dark switch
    const mq = window.matchMedia?.('(prefers-color-scheme: dark)')
    if (!mq || mode !== 'auto') return undefined
    const fn = () => setTick((t) => t + 1)
    mq.addEventListener?.('change', fn)
    return () => mq.removeEventListener?.('change', fn)
  }, [mode])

  const r = useMemo(() => resolve(business, deviceSkin, mode, deviceScale, preview), [business, deviceSkin, mode, deviceScale, preview, tick])   // eslint-disable-line react-hooks/exhaustive-deps
  const { dark, skin } = r
  useEffect(() => { applyVars(r.vars, dark) }, [r, dark])

  const setMode = (m) => { lsSet('cafe_dark', m); setModeState(m) }
  const setDeviceSkin = (id) => { lsSet('cafe_skin', id || ''); setDeviceSkinState(id || '') }
  const setDeviceScale = (v) => { lsSet('cafe_fs', v ? String(v) : ''); setDeviceScaleState(v ? String(v) : '') }
  const saveBusiness = async (next) => { const saved = await put('/system/theme', next); acceptBusiness(saved); return saved }

  const config = useMemo(() => ({
    algorithm: [r.antd.dark ? antTheme.darkAlgorithm : antTheme.defaultAlgorithm, ...(r.antd.compact ? [antTheme.compactAlgorithm] : [])],
    token: r.antd.token,
    components: r.antd.components,
  }), [r])

  const value = {
    dark, mode, setMode, setDark: (d) => setMode(d ? '1' : '0'), toggle: () => setMode(dark ? '0' : '1'),
    skin, chart: r.chart, chartSem: r.chartSem, pal: r.pal, vars: r.vars,
    skins: allSkins(business.custom), business, deviceSkin, setDeviceSkin, deviceScale, setDeviceScale,
    preview, setPreview, saveBusiness, reload,
  }
  return (
    <ThemeCtx.Provider value={value}>
      <ConfigProvider direction="rtl" locale={faIR} theme={config}>
        <AntApp message={{ top: 64, maxCount: 3 }} notification={{ placement: 'topLeft' }}>{children}</AntApp>
      </ConfigProvider>
    </ThemeCtx.Provider>
  )
}

export const useTheme = () => useContext(ThemeCtx)

/** Chart colours as real hex values for recharts SVG attributes: { c: [9 series colours], accent, green, amber, red, blue, faint, grid } */
export function useChart() {
  const { chart, chartSem } = useContext(ThemeCtx)
  return useMemo(() => ({ c: chart, ...chartSem }), [chart, chartSem])
}
