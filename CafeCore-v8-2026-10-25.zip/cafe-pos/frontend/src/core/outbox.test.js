import { beforeEach, describe, expect, it, vi } from 'vitest'

const post = vi.fn()
vi.mock('./api', async (orig) => ({ ...(await orig()), post: (...a) => post(...a) }))
vi.mock('./realtime', () => ({ subscribe: () => () => {} }))

const { ApiError } = await import('./api')
const { dropEntry, enqueue, flushOutbox, isOffline, outboxList, retryEntry } = await import('./outbox')

const net = () => new ApiError('no network', 0, 'network')
const create = (id, extra = {}) => ({ id, kind: 'create', draft: { type: 'takeaway' }, lines: [{ menu_item_id: 1, qty: 2 }], send: true, ...extra })

describe('offline queue', () => {
  beforeEach(() => post.mockReset())

  it('classifies only unreachable-server errors as offline', () => {
    expect(isOffline(net())).toBe(true)
    expect(isOffline(new ApiError('bad gateway', 502, 'error'))).toBe(true)
    expect(isOffline(new ApiError('validation', 422, 'validation'))).toBe(false)
    expect(isOffline(new Error('x'))).toBe(false)
  })

  it('replays with the original request id and merge_if_busy, then empties', async () => {
    enqueue(create('req-aaaaaaaa'))
    post.mockResolvedValueOnce({ id: 10 })
    const sent = vi.fn()
    window.addEventListener('outbox:sent', sent)
    expect(await flushOutbox()).toBe(1)
    expect(post).toHaveBeenCalledWith('/orders', expect.objectContaining({ request_id: 'req-aaaaaaaa', merge_if_busy: true, send: true }))
    expect(outboxList()).toEqual([])
    expect(sent).toHaveBeenCalledOnce()
    window.removeEventListener('outbox:sent', sent)
  })

  it('stops at a network failure and keeps the order of entries', async () => {
    enqueue(create('req-1111111a'))
    enqueue(create('req-2222222b'))
    post.mockRejectedValueOnce(net())
    expect(await flushOutbox()).toBe(0)
    expect(post).toHaveBeenCalledTimes(1)
    expect(outboxList().map((e) => e.id)).toEqual(['req-1111111a', 'req-2222222b'])
  })

  it('keeps business errors for the user and continues with the rest', async () => {
    enqueue(create('req-bad00000'))
    enqueue(create('req-good0000'))
    post.mockRejectedValueOnce(new ApiError('میز معتبر نیست', 400, 'error')).mockResolvedValueOnce({ id: 11 })
    expect(await flushOutbox()).toBe(1)
    const left = outboxList()
    expect(left).toHaveLength(1)
    expect(left[0]).toMatchObject({ id: 'req-bad00000', error: 'میز معتبر نیست' })
    // failed entries are skipped by automatic sync, retried on request
    post.mockResolvedValueOnce({ id: 12 })
    await flushOutbox()
    expect(post).toHaveBeenCalledTimes(2)
    await retryEntry('req-bad00000')
    expect(post).toHaveBeenCalledTimes(3)
    expect(outboxList()).toEqual([])
  })

  it('items for an order that was closed meanwhile become a new order and never merge into another bill (N-06)', async () => {
    enqueue({ id: 'req-lines000', kind: 'lines', order_id: 7, draft: { type: 'dine_in', table_id: 3 }, lines: [{ menu_item_id: 1, qty: 1 }], send: true })
    post.mockRejectedValueOnce(new ApiError('closed', 400, 'order_not_open')).mockResolvedValueOnce({ id: 20 })
    expect(await flushOutbox()).toBe(1)
    expect(post.mock.calls[0][0]).toBe('/orders/7/lines')
    expect(post.mock.calls[0][1].request_id).toBe('req-lines000')
    // these lines belonged to bill #7. Whoever sits at table 3 now is a *different* customer: the replay must
    // not append them to that order (merge_if_busy would), it must ask for a new order.
    expect(post.mock.calls[1]).toEqual(['/orders', expect.objectContaining({ request_id: 'req-lines000c', table_id: 3, merge_if_busy: false })])
    expect(outboxList()).toEqual([])
  })

  it('a network drop during the fallback keeps the lines queued and the retry reuses the same request id', async () => {
    enqueue({ id: 'req-lines001', kind: 'lines', order_id: 7, draft: { type: 'takeaway' }, lines: [{ menu_item_id: 1, qty: 2 }], send: true })
    post.mockRejectedValueOnce(new ApiError('closed', 400, 'order_not_open')).mockRejectedValueOnce(net())
    expect(await flushOutbox()).toBe(0)
    expect(outboxList().map((e) => e.id)).toEqual(['req-lines001'])      // nothing lost
    expect(outboxList()[0].error).toBeNull()                            // an unreachable server is not a business error
    // second attempt: the lines call fails again, the fallback is sent with the SAME derived id → no duplicate order
    post.mockRejectedValueOnce(new ApiError('closed', 400, 'order_not_open')).mockResolvedValueOnce({ id: 21 })
    expect(await flushOutbox()).toBe(1)
    expect(post.mock.calls[1][1].request_id).toBe('req-lines001c')
    expect(post.mock.calls[3][1].request_id).toBe(post.mock.calls[1][1].request_id)
    expect(outboxList()).toEqual([])
  })

  it('when the table already has a new open bill the server refuses and the entry waits for a human', async () => {
    enqueue({ id: 'req-lines002', kind: 'lines', order_id: 7, draft: { type: 'dine_in', table_id: 3 }, lines: [{ menu_item_id: 1, qty: 1 }], send: true })
    post.mockRejectedValueOnce(new ApiError('closed', 400, 'order_not_open'))
      .mockRejectedValueOnce(new ApiError('میز ۳ سفارش باز دارد', 400, 'table_busy'))
    expect(await flushOutbox()).toBe(0)
    const left = outboxList()
    expect(left).toHaveLength(1)                                        // kept, not silently attached to bill #9
    expect(left[0]).toMatchObject({ id: 'req-lines002', error: 'میز ۳ سفارش باز دارد' })
    post.mockResolvedValueOnce({ id: 22 })                              // cashier frees the table → retry succeeds
    await retryEntry('req-lines002')
    expect(outboxList()).toEqual([])
  })

  it('a stopped session (401) waits instead of marking errors', async () => {
    enqueue(create('req-auth0000'))
    post.mockRejectedValueOnce(new ApiError('login', 401, 'unauthenticated'))
    await flushOutbox()
    expect(outboxList()[0].error).toBeNull()
  })

  it('drop removes an entry', () => {
    enqueue(create('req-drop0000'))
    dropEntry('req-drop0000')
    expect(outboxList()).toEqual([])
  })
})
