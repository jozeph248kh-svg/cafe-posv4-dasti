import { describe, expect, it, vi } from 'vitest'
import { getRegisterId, setRegisterId } from './register'

describe('device register', () => {
  it('defaults to none (= main register)', () => {
    expect(getRegisterId()).toBeNull()
  })
  it('stores, notifies and clears', () => {
    const seen = vi.fn()
    window.addEventListener('register:changed', seen)
    setRegisterId(3)
    expect(getRegisterId()).toBe(3)
    expect(localStorage.getItem('cafe_register')).toBe('3')
    setRegisterId(null)
    expect(getRegisterId()).toBeNull()
    expect(seen).toHaveBeenCalledTimes(2)
    window.removeEventListener('register:changed', seen)
  })
  it('ignores garbage left in storage', () => {
    for (const bad of ['abc', '-2', '0', '1.5', '']) {
      localStorage.setItem('cafe_register', bad)
      expect(getRegisterId()).toBeNull()
    }
  })
})
