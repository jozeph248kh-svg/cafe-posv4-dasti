import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest'
import { act, render } from '@testing-library/react'

/**
 * The single WebSocket that keeps every screen in sync (order.changed, kitchen.ready, service.call…).
 * If it silently stops reconnecting, the POS stops seeing the kitchen and the second till — but the
 * UI still looks fine, which is why this file exists.
 */
const getToken = vi.fn(() => 'jwt')
vi.mock('./api', () => ({ getToken: () => getToken(), get: vi.fn(), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn() }))

class FakeSocket {
  static instances = []
  constructor(url) { this.url = url; this.sent = []; FakeSocket.instances.push(this); this.readyState = 0 }
  send(m) { this.sent.push(m) }
  close() { this.readyState = 3; this.onclose?.({ code: 1000 }) }
  // helpers used by the tests
  open() { this.readyState = 1; this.onopen?.() }
  message(obj) { this.onmessage?.({ data: JSON.stringify(obj) }) }
  drop(code = 1006) { this.readyState = 3; this.onclose?.({ code }) }
}

describe('realtime', () => {
  beforeEach(() => {
    vi.useFakeTimers()
    FakeSocket.instances = []
    global.WebSocket = FakeSocket
    getToken.mockReturnValue('jwt')
    vi.resetModules()
  })
  afterEach(() => { vi.useRealTimers() })

  const load = async () => {
    const rt = await import('./realtime')
    return rt
  }

  it('opens one socket with the token and reports the connection status', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    expect(s.url).toContain('/ws?token=jwt')
    s.open()
    expect(rt.__status?.() ?? 'online').toBeTruthy()
  })

  it('does not connect without a token', async () => {
    getToken.mockReturnValue(null)
    const rt = await load()
    rt.startRealtime()
    expect(FakeSocket.instances).toHaveLength(0)
  })

  it('dispatches each message to its topic listeners, and to the wildcard', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    const order = vi.fn()
    const all = vi.fn()
    rt.subscribe('order.changed', order)
    rt.subscribe('*', all)
    s.message({ topic: 'order.changed', data: { id: 7 } })
    expect(order).toHaveBeenCalledWith({ id: 7 }, 'order.changed')
    expect(all).toHaveBeenCalledWith({ id: 7 }, 'order.changed')
  })

  it('ignores pong and unsubscribes cleanly', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    const fn = vi.fn()
    const off = rt.subscribe('shift.changed', fn)
    s.message({ topic: 'pong' })
    expect(fn).not.toHaveBeenCalled()
    off()
    s.message({ topic: 'shift.changed', data: {} })
    expect(fn).not.toHaveBeenCalled()
  })

  it('reconnects with a growing delay after a drop', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    s.drop()
    vi.advanceTimersByTime(1100)                   // the first retry waits 500 * 2^1 ms
    expect(FakeSocket.instances).toHaveLength(2)
    FakeSocket.instances[1].drop()
    vi.advanceTimersByTime(2100)                   // the next one waits longer (exponential backoff)
    expect(FakeSocket.instances.length).toBeGreaterThanOrEqual(3)
  })

  it('does not reconnect after an auth failure (4401)', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    s.drop(4401)
    vi.advanceTimersByTime(5000)
    expect(FakeSocket.instances).toHaveLength(1)
  })

  it('pings to keep the connection alive', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    vi.advanceTimersByTime(26000)
    expect(s.sent).toContain('ping')
  })

  it('announces a reconnect so pages can refresh what they missed', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    const onReconnected = vi.fn()
    rt.subscribe('_reconnected', onReconnected)
    s.open()
    expect(onReconnected).toHaveBeenCalled()
  })

  it('stops on request', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    rt.stopRealtime()
    expect(s.readyState).toBe(3)
  })

  it('useRealtime subscribes on mount and unsubscribes on unmount', async () => {
    const rt = await load()
    rt.startRealtime()
    const s = FakeSocket.instances[0]
    s.open()
    const handler = vi.fn()
    function Probe() { rt.useRealtime(['order.changed'], handler); return null }
    const { unmount } = render(<Probe />)
    act(() => { s.message({ topic: 'order.changed', data: { id: 1 } }) })
    expect(handler).toHaveBeenCalled()
    unmount()
    handler.mockClear()
    act(() => { s.message({ topic: 'order.changed', data: { id: 2 } }) })
    expect(handler).not.toHaveBeenCalled()
  })

  it('beep does not throw when the browser blocks audio', async () => {
    const rt = await load()
    global.AudioContext = class { constructor() { throw new Error('blocked') } }
    expect(() => rt.beep('new')).not.toThrow()
  })
})
