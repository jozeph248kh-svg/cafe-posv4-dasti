import { ArrowDownOutlined, ArrowLeftOutlined, ArrowUpOutlined, ClockCircleOutlined, FireOutlined, ReloadOutlined, RollbackOutlined, ShoppingCartOutlined, TableOutlined, TeamOutlined, WarningOutlined, WalletOutlined } from '@ant-design/icons'
import { Button, Card, Skeleton, Tooltip as Tip, Typography } from 'antd'
import { useMemo, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { PageHeader, StatCard, pctChange } from '../../components/common'
import { compact, faShort, faToday, money, num, PALETTE, UNITS } from '../../core/format'
import { useRealtime } from '../../core/realtime'
import { useChart } from '../../core/theme'
import { useFetch } from '../../core/useFetch'

export const COLORS = PALETTE   // CSS var() strings — for HTML only; charts use useChart().c
export const tooltipStyle = { borderRadius: 12, border: '1px solid var(--border)', background: 'var(--card)', color: 'var(--text)', fontFamily: 'inherit', boxShadow: '0 12px 30px -12px rgba(42,31,23,.35)' }
export const MoneyTip = ({ active, payload, label, labelFmt }) => (active && payload?.length ? (
  <div style={{ ...tooltipStyle, padding: '8px 12px' }}>
    <div style={{ fontWeight: 700, marginBottom: 4 }}>{labelFmt ? labelFmt(label) : label}</div>
    {payload.map((p) => <div key={p.dataKey} style={{ color: p.color }}>{p.name}: {p.dataKey === 'orders' ? num(p.value) : money(p.value)}</div>)}
  </div>
) : null)


function Delta({ value, invert }) {
  if (value === null || value === undefined) return null
  const good = (value >= 0) !== !!invert
  return <span className={`dh-delta ${good ? 'up' : 'down'}`}>{value >= 0 ? <ArrowUpOutlined /> : <ArrowDownOutlined />} {num(Math.abs(value), 1)}٪</span>
}

function LiveCell({ icon, label, value, hint, tone, onClick, children }) {
  return (
    <div className={`dl-cell ${tone || ''} ${onClick ? 'click' : ''}`} onClick={onClick} role={onClick ? 'button' : undefined}>
      <div className="dl-ic">{icon}</div>
      <div className="dl-body">
        <div className="dl-label">{label}</div>
        <div className="dl-value">{value}</div>
        {hint && <div className="dl-hint">{hint}</div>}
        {children}
      </div>
      {onClick && <ArrowLeftOutlined className="dl-go" />}
    </div>
  )
}

export default function Dashboard() {
  const nav = useNavigate()
  const ch = useChart()
  const accent = ch.accent
  const { data: d, loading, reload } = useFetch('/reports/dashboard')
  const t = useRef(null)
  useRealtime(['order.changed', 'kitchen.ticket'], () => { clearTimeout(t.current); t.current = setTimeout(() => reload(true), 1500) })

  const today = d?.today || {}
  const y = d?.yesterday || {}
  const live = d?.live || {}
  const hours = (d?.by_hour || []).filter((h) => h.hour >= 7)
  const pays = d?.by_payment || []
  const payPos = pays.filter((p) => p.amount > 0)                 // a pie can't draw refunds (negative cash)
  const payTotal = payPos.reduce((s, p) => s + p.amount, 0)
  const days = d?.last14 || []
  const avg14 = days.length ? days.reduce((s, x) => s + x.revenue, 0) / days.length : 0
  const lastDay = days[days.length - 1]?.date
  const peak = useMemo(() => hours.reduce((m, h) => (h.revenue > (m?.revenue || 0) ? h : m), null), [hours])
  const lateRatio = live.active_tickets ? Math.round((live.late / live.active_tickets) * 100) : 0
  const topMax = d?.top_items?.[0]?.revenue || 1

  return (
    <div className="fade-in dash">
      <PageHeader title="داشبورد" subtitle={faToday()}
        extra={<><span className="live-pill"><i />زنده</span><Button icon={<ReloadOutlined />} onClick={() => reload()}>به‌روزرسانی</Button></>} />

      <div className="dash-grid">
        {/* ---------- hero: today's net sales */}
        <div className="dash-hero">
          {loading && !d ? <Skeleton active paragraph={{ rows: 4 }} /> : (
            <>
              <div className="dh-top">
                <div>
                  <div className="dh-label"><WalletOutlined /> فروش خالص امروز</div>
                  <div className="dh-value">{money(today.net)}<small>تومان</small></div>
                  <div className="dh-sub"><Delta value={pctChange(today.net, y.net)} /> نسبت به دیروز <span className="dh-dim">({compact(y.net)})</span></div>
                </div>
                {peak?.revenue > 0 && <div className="dh-peak"><span>ساعت اوج</span><b>{num(peak.hour)}:۰۰</b></div>}
              </div>
              <div className="dh-spark">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={hours} margin={{ top: 4, left: 0, right: 0, bottom: 0 }}>
                    <defs><linearGradient id="dhg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#fff" stopOpacity={0.45} /><stop offset="100%" stopColor="#fff" stopOpacity={0} /></linearGradient></defs>
                    <XAxis dataKey="hour" hide reversed />
                    <Tooltip content={<MoneyTip labelFmt={(h) => `ساعت ${num(h)}`} />} cursor={{ stroke: 'rgba(255,255,255,.5)' }} />
                    <Area type="monotone" dataKey="revenue" name="فروش" stroke="#fff" strokeWidth={2.2} fill="url(#dhg)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="dh-foot">
                <div><span>ناخالص</span><b>{compact(today.gross)}</b></div>
                <div><span>مالیات</span><b>{compact(today.tax)}</b></div>
                <div><span>تخفیف</span><b>{compact(today.discounts)}</b></div>
                <div><span>بهای مواد</span><b>{num(today.food_cost_pct || 0, 1)}٪</b></div>
              </div>
            </>
          )}
        </div>

        {/* ---------- KPI tiles */}
        <StatCard className="dash-kpi" loading={loading} title="تعداد سفارش" value={today.orders} icon={<ShoppingCartOutlined />} color="var(--green)" delta={pctChange(today.orders, y.orders)} />
        <StatCard className="dash-kpi" loading={loading} title="میانگین هر فاکتور" value={today.avg_ticket} money suffix="تومان" icon={<FireOutlined />} color="var(--amber)" delta={pctChange(today.avg_ticket, y.avg_ticket)} />
        <StatCard className="dash-kpi" loading={loading} title="مهمانان سالن" value={today.guests} suffix="نفر" icon={<TeamOutlined />} color="var(--blue)" delta={pctChange(today.guests, y.guests)} />
        <StatCard className="dash-kpi" loading={loading} title="مرجوعی امروز" value={today.refunds} money suffix="تومان" icon={<RollbackOutlined />} color="var(--red)" delta={pctChange(today.refunds, y.refunds)} invert />

        {/* ---------- live strip */}
        <Card className="dash-live" styles={{ body: { padding: 0 } }}>
          <div className="dl-head"><span className="live-dot" /> همین حالا</div>
          <div className="dl-row">
            <LiveCell icon={<ClockCircleOutlined />} label="سفارش‌های باز" value={num(live.open_orders || 0)} hint={`${money(live.open_amount)} تومان در جریان`} onClick={() => nav('/pos')} />
            <LiveCell icon={<TableOutlined />} label="میزهای اشغال" value={num(live.occupied_tables || 0)} hint={`${num(live.guests || 0)} مهمان حاضر`} />
            <LiveCell icon={<FireOutlined />} label="تیکت‌های آشپزخانه" value={num(live.active_tickets || 0)} tone={live.late ? 'hot' : 'ok'}
              hint={live.late ? `${num(live.late)} تیکت با تأخیر` : 'بدون تأخیر'} onClick={() => nav('/kds')}>
              {live.active_tickets > 0 && <div className="dl-bar"><i style={{ width: `${lateRatio}%` }} /></div>}
            </LiveCell>
            <LiveCell icon={<WarningOutlined />} label="موجودی رو به اتمام" value={num(d?.low_stock?.length || 0)} tone={d?.low_stock?.length ? 'warn' : 'ok'}
              hint={d?.low_stock?.length ? d.low_stock.slice(0, 3).map((i) => `${i.name} (${num(i.stock, 1)} ${UNITS[i.unit] || ''})`).join('، ') : 'همه مواد کافی است'}
              onClick={() => nav('/admin/inventory/ingredients')} />
          </div>
        </Card>

        {/* ---------- hourly sales */}
        <Card title="فروش ساعتی امروز" className="card-r dash-c8" loading={loading && !d}
          extra={peak?.revenue > 0 && <Typography.Text type="secondary">اوج: ساعت {num(peak.hour)} | {compact(peak.revenue)}</Typography.Text>}>
          <ResponsiveContainer width="100%" height={270}>
            <AreaChart data={hours} margin={{ left: 10, right: 10 }}>
              <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={accent} stopOpacity={0.38} /><stop offset="100%" stopColor={accent} stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="hour" tickFormatter={(h) => `${num(h)}:۰۰`} tick={{ fontSize: 12 }} reversed axisLine={false} tickLine={false} />
              <YAxis tickFormatter={compact} tick={{ fontSize: 11 }} orientation="right" width={70} axisLine={false} tickLine={false} />
              <Tooltip content={<MoneyTip labelFmt={(h) => `ساعت ${num(h)}`} />} />
              <Area type="monotone" dataKey="revenue" name="فروش" stroke={accent} strokeWidth={2.5} fill="url(#g1)" activeDot={{ r: 5, strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* ---------- payments donut */}
        <Card title="روش‌های پرداخت امروز" className="card-r dash-c4" loading={loading && !d}>
          {pays.length ? (
            <>
              <div className="donut-wrap">
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={payPos} dataKey="amount" nameKey="label" innerRadius={58} outerRadius={80} paddingAngle={payPos.length > 1 ? 3 : 0} cornerRadius={payPos.length > 1 ? 6 : 0} stroke="none">
                      {payPos.map((p, i) => <Cell key={p.method} fill={ch.c[i % ch.c.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v) => money(v)} contentStyle={tooltipStyle} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="donut-center"><b>{compact(payTotal)}</b><span>دریافتی</span></div>
              </div>
              {pays.map((p) => {
                const i = payPos.indexOf(p)
                const pct = p.amount > 0 && payTotal ? Math.round((p.amount / payTotal) * 100) : null
                return (
                  <div key={p.method} className="dpay-row">
                    <span className="pr-dot" style={{ background: i >= 0 ? PALETTE[i % PALETTE.length] : 'var(--faint)' }} />
                    <span className="pr-name">{p.label}{p.amount < 0 && <Tip title="بازپرداخت مرجوعی بیشتر از دریافت نقدی بوده است"><span className="pr-neg">بازپرداخت</span></Tip>}</span>
                    {pct !== null && <span className="pr-pct">{num(pct)}٪</span>}
                    <b className={p.amount < 0 ? 'neg' : ''}>{money(p.amount)}</b>
                  </div>
                )
              })}
            </>
          ) : <Typography.Text type="secondary">هنوز پرداختی ثبت نشده</Typography.Text>}
        </Card>

        {/* ---------- 14 days */}
        <Card title="روند فروش ۱۴ روز اخیر" className="card-r dash-c7" loading={loading && !d}
          extra={avg14 > 0 && <Typography.Text type="secondary">میانگین روزانه: {compact(avg14)}</Typography.Text>}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={days} margin={{ left: 10, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" tickFormatter={faShort} tick={{ fontSize: 11 }} reversed axisLine={false} tickLine={false} />
              <YAxis tickFormatter={compact} tick={{ fontSize: 11 }} orientation="right" width={70} axisLine={false} tickLine={false} />
              <Tooltip content={<MoneyTip labelFmt={faShort} />} cursor={{ fill: 'var(--soft)' }} />
              {avg14 > 0 && <ReferenceLine y={avg14} stroke={accent} strokeDasharray="5 5" strokeOpacity={0.7} />}
              <Bar dataKey="revenue" name="فروش" radius={[8, 8, 3, 3]} maxBarSize={34}>
                {days.map((x) => <Cell key={x.date} fill={accent} fillOpacity={x.date === lastDay ? 1 : 0.5} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* ---------- top items */}
        <Card title="پرفروش‌ترین آیتم‌ها (۱۴ روز)" className="card-r dash-c5" loading={loading && !d} extra={<Button type="link" onClick={() => nav('/admin/reports')}>گزارش کامل</Button>}>
          <div className="top-list">
            {(d?.top_items || []).slice(0, 5).map((it, i) => (
              <div key={it.id} className="top-row">
                <span className={`rank r${i + 1}`}>{num(i + 1)}</span>
                <div className="top-main">
                  <div className="top-line"><span className="top-name">{it.name}</span><b>{compact(it.revenue)}</b></div>
                  <div className="top-meta"><span>{it.category}</span><span>{num(it.qty)} عدد</span></div>
                  <div className="top-bar"><i style={{ width: `${(it.revenue / topMax) * 100}%`, background: PALETTE[i % PALETTE.length] }} /></div>
                </div>
              </div>
            ))}
            {!d?.top_items?.length && <Typography.Text type="secondary">هنوز فروشی ثبت نشده</Typography.Text>}
          </div>
        </Card>
      </div>
    </div>
  )
}
