import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

// The dashboard is the first screen of the day: today's net sales, the live counters and the
// "running low" list. The numbers come straight from the server payload — nothing is recomputed
// here except the day-over-day percentage, which is what the tests pin.
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))
vi.mock('../../core/theme', () => ({
  useChart: () => ({ c: ['#111', '#222', '#333'], accent: '#4f46e5', grid: '#eee', axis: '#999' }),
}))
vi.mock('../../core/print', () => ({ printReceipt: vi.fn(), printHtml: vi.fn() }))

const { default: Dashboard } = await import('./Dashboard')

const DATA = {
  today: { orders: 12, gross: 3_000_000, discounts: 120_000, tax: 280_000, net: 2_600_000, avg_ticket: 216_666, guests: 34, refunds: 0, food_cost_pct: 29.4 },
  yesterday: { orders: 10, net: 2_000_000, avg_ticket: 200_000, guests: 30, refunds: 0 },
  by_hour: [{ hour: 8, revenue: 200_000, orders: 2 }, { hour: 12, revenue: 900_000, orders: 5 }, { hour: 19, revenue: 1_500_000, orders: 5 }],
  by_payment: [{ method: 'cash', label: 'نقد', amount: 1_600_000 }, { method: 'card', label: 'کارتخوان', amount: 1_000_000 }],
  last14: Array.from({ length: 14 }, (_, i) => ({ date: `2026-10-${String(10 + i).padStart(2, '0')}`, revenue: 1_000_000, orders: 5 })),
  live: { open_orders: 3, open_amount: 720_000, occupied_tables: 2, guests: 5, active_tickets: 4, late: 1 },
  low_stock: [{ name: 'شیر', stock: 2.5, min: 10, unit: 'l' }, { name: 'دانه قهوه', stock: 1, min: 3, unit: 'kg' }],
  top_items: [{ id: 1, name: 'اسپرسو', revenue: 2_000_000, qty: 30 }],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = () => render(<MemoryRouter><App><Dashboard /></App></MemoryRouter>)

describe('Dashboard', () => {
  beforeEach(() => {
    get.mockReset()
    get.mockImplementation((path) => (path === '/reports/dashboard' ? Promise.resolve(DATA) : Promise.resolve([])))
  })

  it('shows today’s net sales and the gross / tax / discount breakdown', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص امروز'))
    expect(text()).toContain('۲٬۶۰۰٬۰۰۰')
    expect(text()).toContain('ناخالص')
    expect(text()).toContain('مالیات')
    expect(text()).toContain('۲۹٫۴٪')            // food cost percentage
  })

  it('computes the day-over-day change from the two days in the payload', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص امروز'))
    expect(text()).toContain('نسبت به دیروز')
    expect(text()).toContain('۳۰٪')              // (2.6M − 2.0M) / 2.0M
  })

  it('shows the live strip: open orders, occupied tables, kitchen tickets, low stock', async () => {
    page()
    await waitFor(() => expect(text()).toContain('همین حالا'))
    expect(text()).toContain('سفارش‌های باز')
    expect(text()).toContain('۷۲۰٬۰۰۰')           // money in progress
    expect(text()).toContain('تیکت‌های آشپزخانه')
    expect(text()).toContain('تیکت با تأخیر')      // the late warning
  })

  it('names the ingredients that are running low', async () => {
    page()
    await waitFor(() => expect(text()).toContain('موجودی رو به اتمام'))
    expect(text()).toContain('شیر')
    expect(text()).toContain('دانه قهوه')
  })

  it('names the peak hour', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فروش ساعتی امروز'))
    expect(text()).toContain('اوج')
    expect(text()).toContain('۱۹')                // 19:00 had the highest revenue
  })

  it('renders an empty day without crashing or dividing by zero', async () => {
    get.mockImplementation(() => Promise.resolve({ today: {}, yesterday: {}, by_hour: [], by_payment: [], last14: [], live: { open_orders: 0, occupied_tables: 0, active_tickets: 0, late: 0 }, low_stock: [], top_items: [] }))
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص امروز'))
    expect(text()).toContain('همه مواد کافی است')
  })
})
