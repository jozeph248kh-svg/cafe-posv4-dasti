import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

// Online / QR order inbox: the cashier accepts or rejects what the guest sent from their phone.
// The stats are computed on the client from the history rows, so they are worth pinning.
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({
  useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: { 'online.public_url': 'https://order.example.ir' }, system: { lan_urls: ['http://192.168.1.10:8000'] } }),
}))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))

const { default: OnlineOrders } = await import('./OnlineOrders')

const PENDING = [
  { id: 9, mode: 'delivery', customer_name: 'شیرین دلاوری', phone: '09127770011', address: 'ونک', total: 480_000, status: 'pending', created_at: new Date(Date.now() - 3 * 60000).toISOString(), items: [{ qty: 2, name: 'اسپرسو' }, { qty: 1, name: 'کیک' }], waiting: 3, pay_method: 'cash' },
]
const HISTORY = [
  { id: 8, mode: 'pickup', customer_name: 'آرش کمالی', phone: '09121110022', total: 320_000, status: 'accepted', created_at: new Date(Date.now() - 3600000).toISOString(), items: [{ qty: 1, name: 'آمریکانو' }] },
  { id: 7, mode: 'table', table: 'میز ۳', customer_name: null, phone: null, total: 254_000, status: 'accepted', created_at: new Date(Date.now() - 7200000).toISOString(), items: [{ qty: 2, name: 'لاته' }] },
  { id: 6, mode: 'delivery', customer_name: 'مهدی', phone: '09120000000', total: 610_000, status: 'rejected', reject_reason: 'خارج از محدوده', created_at: new Date(Date.now() - 9000000).toISOString(), items: [{ qty: 3, name: 'شیر' }] },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path, params) => {
    if (path !== '/online/requests') return Promise.resolve([])
    return Promise.resolve(params?.scope === 'pending' ? PENDING : HISTORY)
  })
}
const page = () => render(<App><OnlineOrders /></App>)

describe('Online / QR order inbox', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('counts today’s orders, the accepted ones and the money they bring', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سفارش‌های امروز'))
    expect(text()).toContain('۳')                       // three orders in the history
    expect(text()).toContain('۲')                       // two accepted
    expect(text()).toContain('۵۷۴٬۰۰۰')                 // 320,000 + 254,000 accepted total
  })

  it('lists the pending requests waiting for approval', async () => {
    page()
    await waitFor(() => expect(text()).toContain('در انتظار تأیید'))
    expect(text()).toContain('شیرین دلاوری')
    expect(text()).toContain('۲× اسپرسو')
  })

  it('shows the shared order link from the configured public URL', async () => {
    page()
    await waitFor(() => expect(text()).toContain('لینک سفارش آنلاین'))
    expect(text()).toContain('https://order.example.ir/order')
  })

  it('falls back to the LAN address when no public URL is configured', async () => {
    const authMod = await import('../../core/auth')
    const original = authMod.useAuth
    // the module is mocked, so re-render with a patched value
    get.mockImplementation((path, params) => Promise.resolve(path !== '/online/requests' ? [] : params?.scope === 'pending' ? [] : HISTORY))
    page()
    await waitFor(() => expect(text()).toContain('لینک سفارش آنلاین'))
    expect(text()).toContain('/order')
    expect(original).toBeTruthy()
  })

  it('shows the history rows with mode, amount and status', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سوابق'))
    expect(text()).toContain('آرش کمالی')
    expect(text()).toContain('۳۲۰٬۰۰۰')
    expect(text()).toContain('میز ۳')
    expect(text()).toContain('رد شده')                 // the rejected row''s status tag
  })

  it('asks for pending and history separately', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/online/requests', { scope: 'pending' }))
    expect(get).toHaveBeenCalledWith('/online/requests', { scope: 'today' })
  })
})
