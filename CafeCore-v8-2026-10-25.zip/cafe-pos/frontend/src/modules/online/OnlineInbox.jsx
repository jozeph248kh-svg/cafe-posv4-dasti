import { CheckOutlined, CloseOutlined, GlobalOutlined } from '@ant-design/icons'
import { App, Badge, Button, Drawer, Empty, Input, Modal, Segmented, Space, Tag, Tooltip } from 'antd'
import { useCallback, useEffect, useState } from 'react'
import { get, post } from '../../core/api'
import { money, num, timeAgo } from '../../core/format'
import { beep, useRealtime } from '../../core/realtime'

export const MODE = {
  delivery: { label: 'پیک آنلاین', color: 'purple', icon: '🛵' },
  pickup: { label: 'بیرون‌بر آنلاین', color: 'gold', icon: '🛍️' },
  table: { label: 'سفارش میز (QR)', color: 'blue', icon: '📱' },
}
const REASONS = ['اتمام موجودی برخی اقلام', 'خارج از محدوده ارسال', 'حجم بالای سفارش‌ها', 'اطلاعات تماس نامعتبر']

export function RequestCard({ r, onAccept, onReject, busy }) {
  const [eta, setEta] = useState(r.mode === 'delivery' ? 45 : 20)
  const m = MODE[r.mode]
  return (
    <div className={`oi-card ${r.waiting >= 5 ? 'late' : ''}`}>
      <div className="oi-head">
        <Tag color={m.color}>{m.icon} {m.label}</Tag>
        {r.table && <b>میز {r.table}</b>}
        <span className="oi-time">{timeAgo(r.created_at)}</span>
      </div>
      {(r.customer_name || r.phone) && <div className="oi-cust">{r.customer_name} {r.phone && <a className="ltr" href={`tel:${r.phone}`}>{r.phone}</a>}</div>}
      {r.address && <div className="oi-addr">📍 {r.address}</div>}
      <ul className="oi-items">
        {r.items.map((i, k) => <li key={k}><b>{num(i.qty)}×</b> {i.name}{i.modifiers?.length ? <small> ({i.modifiers.join('، ')})</small> : null}{i.note ? <small> — {i.note}</small> : null}</li>)}
      </ul>
      {r.note && <div className="oi-note">📝 {r.note}</div>}
      <div className="oi-foot">
        <div>
          <b>{money(r.total)}</b>
          {r.mode !== 'table' && <Tag style={{ marginInlineStart: 6 }}>{r.pay_method === 'card' ? '💳 کارتخوان' : '💵 نقدی'}</Tag>}
        </div>
        {r.status === 'pending' && onAccept && (
          <Space size={6}>
            {r.mode !== 'table' && (
              <Tooltip title="زمان تقریبی آماده‌سازی/ارسال که به مشتری نمایش داده می‌شود">
                <Segmented size="small" value={eta} onChange={setEta} options={(r.mode === 'delivery' ? [30, 45, 60] : [15, 20, 30]).map((v) => ({ value: v, label: `${num(v)}′` }))} />
              </Tooltip>
            )}
            <Button size="small" danger icon={<CloseOutlined />} onClick={() => onReject(r)} disabled={!!busy} />
            <Button size="small" type="primary" icon={<CheckOutlined />} loading={busy === r.id} onClick={() => onAccept(r, r.mode === 'table' ? null : eta)}>تأیید و ارسال به آشپزخانه</Button>
          </Space>
        )}
        {r.status === 'rejected' && <Tag color="red">رد شد: {r.reject_reason}</Tag>}
        {r.status === 'accepted' && <Tag color="green">تأیید شد</Tag>}
      </div>
    </div>
  )
}

export function useRejectDialog(onDone) {
  const { message } = App.useApp()
  const [target, setTarget] = useState(null)
  const [reason, setReason] = useState('')
  const dialog = (
    <Modal open={!!target} title="رد سفارش" okText="رد سفارش" okButtonProps={{ danger: true, disabled: reason.trim().length < 2 }} cancelText="انصراف"
      onCancel={() => setTarget(null)}
      onOk={async () => {
        try {
          await post(`/online/requests/${target.id}/reject`, { reason: reason.trim() })
          message.info('سفارش رد شد و دلیل آن به مشتری نمایش داده می‌شود')
          setTarget(null); onDone?.()
        } catch (e) { message.error(e.message) }
      }}>
      <Space wrap style={{ marginBottom: 10 }}>{REASONS.map((x) => <Tag.CheckableTag key={x} checked={reason === x} onChange={() => setReason(x)}>{x}</Tag.CheckableTag>)}</Space>
      <Input.TextArea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="دلیل (به مشتری نمایش داده می‌شود)" maxLength={200} />
    </Modal>
  )
  return [(r) => { setReason(''); setTarget(r) }, dialog]
}

/** POS header button: incoming online / QR-table orders with sound alert. */
export default function OnlineInbox({ mobile, onAccepted }) {
  const { message, notification } = App.useApp()
  const [list, setList] = useState([])
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(null)
  const load = useCallback(() => get('/online/requests', { scope: 'pending' }).then(setList).catch(() => {}), [])
  const [reject, rejectDialog] = useRejectDialog(load)

  useEffect(() => { load() }, [load])
  useEffect(() => { const id = setInterval(load, 60000); return () => clearInterval(id) }, [load])
  useRealtime(['online.changed', '_reconnected'], load)
  useRealtime('online.new', (d) => {
    beep('call')
    const m = MODE[d.mode]
    notification.info({
      key: `online-${d.id}`, duration: 12, icon: <GlobalOutlined style={{ color: 'var(--primary)' }} />,
      message: `${m.icon} ${m.label} جدید${d.table ? ` · میز ${d.table}` : ''}`,
      description: `${d.name || ''} — ${money(d.total)}`,
      btn: <Button type="primary" size="small" onClick={() => { notification.destroy(`online-${d.id}`); setOpen(true) }}>بررسی</Button>,
    })
    load()
  })

  const accept = async (r, eta) => {
    setBusy(r.id)
    try {
      const res = await post(`/online/requests/${r.id}/accept`, { eta_minutes: eta })
      message.success(`سفارش #${num(res.number)} ثبت و به آشپزخانه ارسال شد`)
      notification.destroy(`online-${r.id}`)
      load(); onAccepted?.(res.order_id)
    } catch (e) { message.error(e.message); load() } finally { setBusy(null) }
  }

  return (
    <>
      <Badge count={list.length} size="small" color="var(--primary)">
        <Button icon={<GlobalOutlined />} className={list.length ? 'ring' : ''} onClick={() => setOpen(true)}>{!mobile && 'آنلاین'}</Button>
      </Badge>
      <Drawer open={open} onClose={() => setOpen(false)} width={mobile ? '100%' : 460} title={<span><GlobalOutlined /> سفارش‌های آنلاین و QR در انتظار تأیید</span>}>
        {list.length === 0 ? <Empty description="سفارش در انتظاری نیست" /> : list.map((r) => <RequestCard key={r.id} r={r} busy={busy} onAccept={accept} onReject={reject} />)}
      </Drawer>
      {rejectDialog}
    </>
  )
}
