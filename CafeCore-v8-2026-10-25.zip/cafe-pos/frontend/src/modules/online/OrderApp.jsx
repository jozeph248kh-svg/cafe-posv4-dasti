import {
  BellOutlined, CarOutlined, CheckCircleFilled, DeleteOutlined, FileTextOutlined, HistoryOutlined, InstagramOutlined, MinusOutlined,
  PhoneOutlined, PlusOutlined, ShoppingOutlined, WifiOutlined,
} from '@ant-design/icons'
import { Alert, App, Button, Checkbox, Drawer, Empty, Form, Input, Radio, Result, Segmented, Spin, Tag } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../core/api'
import { money, num } from '../../core/format'

const TRACK_KEY = 'cafe_online_orders'
export const rememberOrder = (t) => {
  const list = JSON.parse(localStorage.getItem(TRACK_KEY) || '[]').filter((x) => x.token !== t.token)
  list.unshift({ token: t.token, at: Date.now(), total: t.total, mode: t.mode })
  localStorage.setItem(TRACK_KEY, JSON.stringify(list.slice(0, 5)))
}
const recentOrders = () => JSON.parse(localStorage.getItem(TRACK_KEY) || '[]').filter((x) => Date.now() - x.at < 12 * 3600e3)

const lineKey = (itemId, opts, note) => `${itemId}|${opts.map((o) => o.id).sort().join(',')}|${note || ''}`
const unitOf = (l) => l.item.price + l.options.reduce((a, o) => a + o.price, 0)

/** Guest ordering — online (/order: pickup/delivery) or at the table (/menu/<token> when QR ordering is on). No login. */
export default function OrderApp({ table = null }) {
  const nav = useNavigate()
  const { message, modal } = App.useApp()
  const [info, setInfo] = useState(null)
  const [menu, setMenu] = useState(null)
  const [error, setError] = useState(null)
  const [q, setQ] = useState('')
  const [activeCat, setActiveCat] = useState(null)
  const [sheet, setSheet] = useState(null)
  const [checkout, setCheckout] = useState(false)
  const [sending, setSending] = useState(null)
  const storeKey = `cafe_cart_${table || 'online'}`
  const [cart, setCart] = useState(() => { try { return JSON.parse(sessionStorage.getItem(storeKey) || '[]') } catch { return [] } })
  const refs = useRef({})

  useEffect(() => {
    document.documentElement.dataset.theme = 'light'
    Promise.all([api('/online/public/info', { params: table ? { table } : {} }), api('/online/public/menu')])
      .then(([i, m]) => { setInfo(i); setMenu(m) }).catch((e) => setError(e.message))
  }, [table])
  useEffect(() => { sessionStorage.setItem(storeKey, JSON.stringify(cart)) }, [cart, storeKey])

  const grouped = useMemo(() => {
    if (!menu) return []
    const items = menu.items.filter((i) => !q || i.name.includes(q) || (i.description || '').includes(q))
    return menu.categories.map((c) => ({ ...c, items: items.filter((i) => i.category_id === c.id) })).filter((c) => c.items.length)
  }, [menu, q])

  const count = cart.reduce((a, l) => a + l.qty, 0)
  const subtotal = cart.reduce((a, l) => a + unitOf(l) * l.qty, 0)
  const qtyOf = (id) => cart.filter((l) => l.item.id === id).reduce((a, l) => a + l.qty, 0)

  const add = (item, options = [], qty = 1, note = '') => {
    const key = lineKey(item.id, options, note)
    setCart((c) => (c.some((l) => l.key === key) ? c.map((l) => (l.key === key ? { ...l, qty: l.qty + qty } : l)) : [...c, { key, item, options, qty, note }]))
  }
  const change = (key, d) => setCart((c) => c.map((l) => (l.key === key ? { ...l, qty: l.qty + d } : l)).filter((l) => l.qty > 0))
  const quickMinus = (item) => {
    const last = [...cart].reverse().find((l) => l.item.id === item.id)
    if (last) change(last.key, -1)
  }
  const tap = (item) => {
    if (!item.is_available) return
    if (item.groups?.length) setSheet(item)
    else add(item)
  }

  const call = async (kind) => {
    setSending(kind)
    try {
      await api('/public/call', { method: 'POST', body: { token: table, kind } })
      message.success(kind === 'bill' ? 'درخواست صورتحساب ارسال شد 🧾' : 'گارسون به‌زودی خدمت می‌رسد 🙋')
    } catch (e) { message.error(e.message) } finally { setSending(null) }
  }

  if (error) return <div className="center-screen"><Empty description={error} /></div>
  if (!info || !menu) return <div className="center-screen"><Spin size="large" /></div>
  const b = info.business
  const online = !table
  const closed = online && (!info.enabled || (!info.pickup && !info.delivery))
  const paused = online && !closed && !info.accepting
  const canOrder = !closed && !paused && (online || info.qr_ordering)
  const recent = recentOrders()

  return (
    <div className="qr oa">
      <div className="qr-hero">
        <div className="qr-logo">{b.logo ? <img src={b.logo} alt="" /> : '☕'}</div>
        <h1 style={{ margin: 0, fontSize: 24 }}>{b.name}</h1>
        {info.table ? <div className="qr-table">میز {info.table.name} · سفارش از روی میز</div> : <div className="qr-table">سفارش آنلاین {info.delivery ? '· ارسال با پیک' : ''} {info.pickup ? '· بیرون‌بر' : ''}</div>}
        <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap', marginTop: 12, fontSize: 13, opacity: 0.9 }}>
          {table && b.wifi && <span><WifiOutlined /> {b.wifi}</span>}
          {b.phone && <a href={`tel:${b.phone}`} style={{ color: '#fff' }}><PhoneOutlined /> {b.phone}</a>}
          {b.instagram && <span className="ltr"><InstagramOutlined /> {b.instagram}</span>}
        </div>
      </div>

      <div className="oa-notices">
        {closed && <Alert type="error" showIcon message="سفارش آنلاین در حال حاضر فعال نیست" description="می‌توانید منو را ببینید و تلفنی سفارش دهید." />}
        {paused && <Alert type="warning" showIcon message="به دلیل حجم بالای سفارش‌ها، ثبت سفارش موقتاً متوقف است" description="چند دقیقه دیگر دوباره سر بزنید." />}
        {info.notice && <Alert type="info" showIcon message={info.notice} />}
        {online && info.min_order > 0 && canOrder && <div className="oa-min">حداقل سفارش {money(info.min_order)} {b.currency}</div>}
        {recent.length > 0 && (
          <button type="button" className="oa-recent" onClick={() => nav(`/order/track/${recent[0].token}`)}>
            <HistoryOutlined /> پیگیری آخرین سفارش شما <span>{money(recent[0].total)} {b.currency}</span>
          </button>
        )}
      </div>

      <div className="qr-cats">
        {grouped.map((c) => (
          <button type="button" key={c.id} className={`cat-chip ${activeCat === c.id ? 'on' : ''}`} style={{ '--c': c.color }}
            onClick={() => { setActiveCat(c.id); refs.current[c.id]?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }}>{c.icon} {c.name}</button>
        ))}
      </div>
      <div style={{ padding: '0 14px' }}><Input.Search allowClear placeholder="جستجو در منو..." value={q} onChange={(e) => setQ(e.target.value)} size="large" /></div>
      {grouped.map((c) => (
        <section key={c.id} className="qr-section" ref={(el) => { refs.current[c.id] = el }} style={{ scrollMarginTop: 64 }}>
          <h3>{c.icon} {c.name}</h3>
          {c.items.map((i) => {
            const n = qtyOf(i.id)
            return (
              <div key={i.id} className={`qr-item ${i.is_available ? '' : 'off'} ${n ? 'in' : ''}`} onClick={() => canOrder && tap(i)} role="button" tabIndex={0}>
                <div className="qr-item-img">{i.image ? <img src={i.image} alt="" loading="lazy" /> : c.icon}</div>
                <div className="qr-item-body">
                  <b>{i.name} {i.tags?.split(',').filter(Boolean).map((t) => <Tag key={t} color="volcano" style={{ marginInlineStart: 6 }}>{t}</Tag>)}</b>
                  {i.description && <div className="qr-item-desc">{i.description}</div>}
                  {i.groups?.length > 0 && <div className="qr-item-desc">{i.groups.map((g) => g.name).join(' · ')}</div>}
                  <div className="oa-row">
                    <div className="qr-item-price">{i.is_available ? `${money(i.price)} ${b.currency}` : 'ناموجود'}</div>
                    {canOrder && i.is_available && (
                      n && !i.groups?.length ? (
                        <div className="oa-step" onClick={(e) => e.stopPropagation()} role="group">
                          <Button size="small" shape="circle" icon={<PlusOutlined />} onClick={() => add(i)} />
                          <b>{num(n)}</b>
                          <Button size="small" shape="circle" icon={<MinusOutlined />} onClick={() => quickMinus(i)} />
                        </div>
                      ) : (
                        <Button size="small" type={n ? 'primary' : 'default'} shape="round" icon={<PlusOutlined />} onClick={(e) => { e.stopPropagation(); tap(i) }}>
                          {n ? num(n) : 'افزودن'}
                        </Button>
                      )
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </section>
      ))}
      {info.tax_percent > 0 && <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>قیمت‌ها بدون احتساب {num(info.tax_percent)}٪ مالیات بر ارزش افزوده است</p>}

      <div className="qr-actions">
        {count > 0 ? (
          <button type="button" className="oa-cartbar" onClick={() => setCheckout(true)}>
            <span className="oa-count">{num(count)}</span>
            <span>مشاهده سبد و ثبت سفارش</span>
            <b>{money(subtotal)} {b.currency}</b>
          </button>
        ) : table && (
          <>
            <Button size="large" type="primary" icon={<BellOutlined />} block loading={sending === 'waiter'} onClick={() => call('waiter')} style={{ height: 50 }}>صدا زدن گارسون</Button>
            <Button size="large" icon={<FileTextOutlined />} block loading={sending === 'bill'} onClick={() => call('bill')} style={{ height: 50 }}>درخواست صورتحساب</Button>
          </>
        )}
      </div>

      <ItemSheet item={sheet} currency={b.currency} onClose={() => setSheet(null)} onAdd={(opts, qty, note) => { add(sheet, opts, qty, note); setSheet(null) }} />
      <Checkout open={checkout} onClose={() => setCheckout(false)} info={info} table={table} cart={cart} change={change} subtotal={subtotal}
        onDone={(t) => {
          rememberOrder(t)
          setCart([])
          setCheckout(false)
          if (table) {
            modal.success({ title: 'سفارش شما ثبت شد 🎉', content: t.stage === 'pending' ? 'پس از تأیید گارسون، سفارش به آشپزخانه ارسال می‌شود.' : 'سفارش به آشپزخانه ارسال شد.', okText: 'پیگیری سفارش', onOk: () => nav(`/order/track/${t.token}`) })
          } else nav(`/order/track/${t.token}`)
        }} />
    </div>
  )
}

function ItemSheet({ item, currency, onClose, onAdd }) {
  const [sel, setSel] = useState({})
  const [qty, setQty] = useState(1)
  const [note, setNote] = useState('')
  useEffect(() => {
    if (!item) return
    const init = {}
    item.groups.forEach((g) => { init[g.id] = g.options.filter((o) => o.is_default && o.is_available).map((o) => o.id).slice(0, g.max || 99) })
    setSel(init); setQty(1); setNote('')
  }, [item])
  if (!item) return null
  const opts = item.groups.flatMap((g) => g.options.filter((o) => (sel[g.id] || []).includes(o.id)))
  const missing = item.groups.filter((g) => (sel[g.id] || []).length < (g.min || 0))
  const unit = item.price + opts.reduce((a, o) => a + o.price, 0)
  return (
    <Drawer open={!!item} onClose={onClose} placement="bottom" height="auto" className="oa-sheet" title={item.name} styles={{ body: { paddingBottom: 90 } }}>
      {item.description && <p style={{ color: 'var(--muted)', marginTop: 0 }}>{item.description}</p>}
      {item.groups.map((g) => (
        <div key={g.id} className="oa-group">
          <div className="oa-group-h"><b>{g.name}</b>{g.min > 0 ? <Tag color="red">الزامی</Tag> : <Tag>اختیاری</Tag>}{g.max > 1 && <small>تا {num(g.max)} مورد</small>}</div>
          {g.max === 1 ? (
            <Radio.Group value={(sel[g.id] || [])[0]} onChange={(e) => setSel({ ...sel, [g.id]: [e.target.value] })} style={{ width: '100%' }}>
              {g.options.map((o) => (
                <label key={o.id} className={`oa-opt ${o.is_available ? '' : 'off'}`}><Radio value={o.id} disabled={!o.is_available}>{o.name}</Radio>{o.price !== 0 && <span>{o.price > 0 ? '+' : ''}{money(o.price)}</span>}</label>
              ))}
            </Radio.Group>
          ) : (
            g.options.map((o) => {
              const on = (sel[g.id] || []).includes(o.id)
              const full = !on && g.max && (sel[g.id] || []).length >= g.max
              return (
                <label key={o.id} className={`oa-opt ${o.is_available ? '' : 'off'}`}>
                  <Checkbox checked={on} disabled={!o.is_available || full}
                    onChange={(e) => setSel({ ...sel, [g.id]: e.target.checked ? [...(sel[g.id] || []), o.id] : (sel[g.id] || []).filter((x) => x !== o.id) })}>{o.name}</Checkbox>
                  {o.price !== 0 && <span>{o.price > 0 ? '+' : ''}{money(o.price)}</span>}
                </label>
              )
            })
          )}
        </div>
      ))}
      <Input.TextArea placeholder="توضیحات (مثلاً: کم‌شکر، بدون پیاز)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={120} autoSize={{ minRows: 1, maxRows: 3 }} style={{ marginTop: 8 }} />
      <div className="oa-sheet-foot">
        <div className="oa-step big">
          <Button shape="circle" icon={<PlusOutlined />} onClick={() => setQty(qty + 1)} />
          <b>{num(qty)}</b>
          <Button shape="circle" icon={<MinusOutlined />} disabled={qty <= 1} onClick={() => setQty(qty - 1)} />
        </div>
        <Button type="primary" size="large" disabled={missing.length > 0} onClick={() => onAdd(opts.map((o) => ({ id: o.id, name: o.name, price: o.price })), qty, note.trim())} style={{ flex: 1, height: 48 }}>
          {missing.length ? `انتخاب ${missing[0].name}` : `افزودن · ${money(unit * qty)} ${currency}`}
        </Button>
      </div>
    </Drawer>
  )
}

function Checkout({ open, onClose, info, table, cart, change, subtotal, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [mode, setMode] = useState(info.delivery ? 'delivery' : 'pickup')
  const [zoneId, setZoneId] = useState(null)
  const [busy, setBusy] = useState(false)
  const [code, setCode] = useState('')
  const [promo, setPromo] = useState(null)          // { code, name, discount } validated by the server for this cart
  const [promoErr, setPromoErr] = useState(null)
  const [promoBusy, setPromoBusy] = useState(false)
  const [otp, setOtp] = useState(null)              // null | { phone, sent, code, busy, token, wait }
  const b = info.business
  const zone = info.zones.find((z) => z.id === zoneId)
  const fee = !table && mode === 'delivery' && zone ? zone.fee : 0
  const discount = promo?.discount || 0
  const tax = Math.round((subtotal - discount + fee) * (info.tax_percent || 0) / 100)
  const lines = cart.map((l) => ({ menu_item_id: l.item.id, qty: l.qty, modifier_option_ids: l.options.map((o) => o.id), note: l.note || null }))
  const cartKey = JSON.stringify(lines) + mode
  const phoneNow = () => (form.getFieldValue('phone') || '').trim()
  const tokenFor = (ph) => (otp?.token && otp.phone === ph ? otp.token : null)
  const checkCode = async (c = code, token) => {
    if (!c.trim() || !lines.length) return
    setPromoBusy(true); setPromoErr(null)
    const ph = phoneNow()
    try {
      setPromo(await api('/online/public/promo', { method: 'POST', body: { code: c.trim(), mode: table ? 'table' : mode, phone: ph || null, otp_token: token || tokenFor(ph), lines } }))
    } catch (e) {
      setPromo(null)
      if (e.code === 'otp_required') { setOtp((o) => (o && o.phone === ph && !o.token ? o : { phone: ph })); setPromoErr(null) } else setPromoErr(e.message)
    } finally { setPromoBusy(false) }
  }
  const sendOtp = async () => {
    const ph = phoneNow()
    if (!ph) { form.validateFields(['phone']).catch(() => null); return }
    setOtp({ phone: ph, busy: true })
    try {
      const r = await api('/online/public/otp/send', { method: 'POST', body: { phone: ph } })
      setOtp({ phone: ph, sent: true, code: '' })
      message.success(`کد تأیید پیامک شد (اعتبار ${Math.round(r.expires_in / 60)} دقیقه)`)
    } catch (e) { setOtp({ phone: ph, sent: e.code === 'otp_wait' }); message.error(e.message) }
  }
  const verifyOtp = async () => {
    setOtp((o) => ({ ...o, busy: true }))
    try {
      const r = await api('/online/public/otp/verify', { method: 'POST', body: { phone: otp.phone, code: otp.code } })
      setOtp((o) => ({ ...o, busy: false, token: r.otp_token }))
      checkCode(code, r.otp_token)
    } catch (e) { setOtp((o) => ({ ...o, busy: false, code: '', sent: e.code === 'otp_wrong' })); message.error(e.message) }
  }
  // the cart or the delivery mode changed → the discount must be re-checked by the server
  useEffect(() => { if (promo) checkCode(promo.code) }, [cartKey]) // eslint-disable-line react-hooks/exhaustive-deps
  const minNeed = table ? 0 : Math.max(info.min_order || 0, mode === 'delivery' && zone ? zone.min_order || 0 : 0)
  const short = minNeed > subtotal ? minNeed - subtotal : 0

  useEffect(() => {
    if (!open) return
    try { form.setFieldsValue(JSON.parse(localStorage.getItem('cafe_guest') || '{}')) } catch { /* ignore */ }
  }, [open, form])

  const submit = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy(true)
    try {
      localStorage.setItem('cafe_guest', JSON.stringify({ customer_name: v.customer_name, phone: v.phone, address: v.address }))
      const body = {
        mode: table ? 'table' : mode, table_token: table, customer_name: v.customer_name, phone: v.phone || null,
        address: mode === 'delivery' ? v.address : null, zone_id: mode === 'delivery' ? zoneId : null, note: v.note, pay_method: v.pay_method || 'cash',
        promo_code: promo?.code || null, otp_token: promo ? tokenFor((v.phone || '').trim()) : null, lines,
      }
      const t = await api('/online/public/orders', { method: 'POST', body })
      onDone(t)
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }

  return (
    <Drawer open={open} onClose={onClose} placement="bottom" height="92%" className="oa-sheet" title="سبد خرید" styles={{ body: { paddingBottom: 110 } }}>
      {cart.length === 0 ? <Result status="info" title="سبد خالی است" /> : (
        <>
          <div className="oa-cart">
            {cart.map((l) => (
              <div key={l.key} className="oa-cart-line">
                <div style={{ flex: 1, minWidth: 0 }}>
                  <b>{l.item.name}</b>
                  {(l.options.length > 0 || l.note) && <div className="qr-item-desc">{[...l.options.map((o) => o.name), l.note].filter(Boolean).join('، ')}</div>}
                  <div className="oa-cart-price">{money(unitOf(l) * l.qty)}</div>
                </div>
                <div className="oa-step">
                  <Button size="small" shape="circle" icon={<PlusOutlined />} onClick={() => change(l.key, 1)} />
                  <b>{num(l.qty)}</b>
                  <Button size="small" shape="circle" icon={l.qty === 1 ? <DeleteOutlined /> : <MinusOutlined />} danger={l.qty === 1} onClick={() => change(l.key, -1)} />
                </div>
              </div>
            ))}
          </div>

          <Form form={form} layout="vertical" requiredMark={false} initialValues={{ pay_method: 'cash' }} style={{ marginTop: 16 }}>
            {!table && info.pickup && info.delivery && (
              <Segmented block size="large" value={mode} onChange={setMode} style={{ marginBottom: 16 }} options={[
                { value: 'delivery', label: <span><CarOutlined /> ارسال با پیک</span> },
                { value: 'pickup', label: <span><ShoppingOutlined /> تحویل حضوری</span> },
              ]} />
            )}
            <div className="oa-two">
              <Form.Item name="customer_name" label={table ? 'نام شما (اختیاری)' : 'نام و نام خانوادگی'} rules={table ? [] : [{ required: true, min: 2, message: 'نام را وارد کنید' }]}>
                <Input size="large" autoComplete="name" />
              </Form.Item>
              {!table && (
                <Form.Item name="phone" label="شماره موبایل" rules={[{ required: true, pattern: /^(\+98|0098|98|0)?9\d{9}$|^[۰-۹]{11}$/, message: 'موبایل معتبر وارد کنید' }]}>
                  <Input size="large" className="ltr" inputMode="tel" placeholder="09xxxxxxxxx" autoComplete="tel" />
                </Form.Item>
              )}
            </div>
            {!table && mode === 'delivery' && (
              <>
                <Form.Item label="منطقه" required>
                  <div className="oa-zones">
                    {info.zones.map((z) => (
                      <button type="button" key={z.id} className={`oa-zone ${zoneId === z.id ? 'on' : ''}`} onClick={() => setZoneId(z.id)}>
                        <b>{z.name}</b><small>ارسال {z.fee ? money(z.fee) : 'رایگان'} · ~{num(z.eta)} دقیقه</small>
                      </button>
                    ))}
                  </div>
                </Form.Item>
                <Form.Item name="address" label="آدرس دقیق" rules={[{ required: true, min: 8, message: 'آدرس کامل را وارد کنید' }]}>
                  <Input.TextArea autoSize={{ minRows: 2, maxRows: 4 }} placeholder="خیابان، کوچه، پلاک، واحد" autoComplete="street-address" />
                </Form.Item>
              </>
            )}
            {!table && (
              <Form.Item name="pay_method" label="روش پرداخت">
                <Radio.Group optionType="button" buttonStyle="solid" options={[{ value: 'cash', label: 'نقدی' }, { value: 'card', label: mode === 'delivery' ? 'کارتخوان پیک' : 'کارتخوان' }]} />
              </Form.Item>
            )}
            <Form.Item name="note" label="توضیحات سفارش"><Input.TextArea autoSize={{ minRows: 1, maxRows: 3 }} maxLength={300} /></Form.Item>
            <Form.Item label="کد تخفیف" validateStatus={promoErr ? 'error' : promo ? 'success' : undefined}
              help={promoErr || (promo ? `«${promo.name}» اعمال شد: ${money(promo.discount)} ${b.currency} تخفیف` : null)}>
              <div className="disc-code">
                <Input size="large" className="ltr" value={code} maxLength={30} placeholder="مثلاً OPEN30" allowClear
                  onChange={(e) => { setCode(e.target.value.toUpperCase()); if (!e.target.value) { setPromo(null); setPromoErr(null) } }}
                  onPressEnter={() => checkCode()} />
                <Button size="large" loading={promoBusy} disabled={!code.trim()} onClick={() => checkCode()}>اعمال</Button>
              </div>
            </Form.Item>
            {otp && !otp.token && !promo && (
              <div className="oa-otp" style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 12, padding: 12, marginTop: -8, marginBottom: 16 }}>
                <div style={{ marginBottom: 8 }}>این کد تخفیف برای هر مشتری محدود است؛ برای استفاده، شماره موبایل {otp.phone ? <b className="ltr" style={{ display: 'inline-block' }}>{otp.phone}</b> : 'خود'} را با کد پیامکی تأیید کنید.</div>
                {!otp.sent ? (
                  <Button type="primary" className="otp-send" loading={otp.busy} onClick={sendOtp}>ارسال کد تأیید</Button>
                ) : (
                  <div className="disc-code">
                    <Input size="large" className="ltr otp-code" inputMode="numeric" autoComplete="one-time-code" maxLength={5} placeholder="کد ۵ رقمی" value={otp.code}
                      onChange={(e) => setOtp({ ...otp, code: e.target.value.replace(/[^0-9۰-۹]/g, '') })} onPressEnter={() => otp.code?.length === 5 && verifyOtp()} />
                    <Button size="large" type="primary" loading={otp.busy} disabled={otp.code?.length !== 5} onClick={verifyOtp}>تأیید</Button>
                    <Button size="large" type="link" onClick={sendOtp}>ارسال دوباره</Button>
                  </div>
                )}
              </div>
            )}
          </Form>

          <div className="oa-sum">
            <div><span>جمع اقلام</span><span>{money(subtotal)}</span></div>
            {discount > 0 && <div style={{ color: 'var(--green)' }}><span>تخفیف ({promo.code})</span><span>−{money(discount)}</span></div>}
            {fee > 0 && <div><span>هزینه ارسال</span><span>{money(fee)}</span></div>}
            {tax > 0 && <div><span>مالیات ({num(info.tax_percent)}٪)</span><span>{money(tax)}</span></div>}
            <div className="tot"><span>مبلغ قابل پرداخت</span><span>{money(subtotal - discount + fee + tax)} {b.currency}</span></div>
          </div>
          <div className="oa-sheet-foot">
            <Button type="primary" size="large" block loading={busy} disabled={short > 0 || (!table && mode === 'delivery' && !zoneId)} onClick={submit} style={{ height: 52 }} icon={<CheckCircleFilled />}>
              {short > 0 ? `${money(short)} ${b.currency} تا حداقل سفارش` : !table && mode === 'delivery' && !zoneId ? 'منطقه را انتخاب کنید' : table ? 'ارسال سفارش برای میز' : 'ثبت نهایی سفارش'}
            </Button>
          </div>
        </>
      )}
    </Drawer>
  )
}
