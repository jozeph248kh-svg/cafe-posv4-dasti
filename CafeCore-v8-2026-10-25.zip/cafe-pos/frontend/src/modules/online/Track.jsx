import { ArrowRightOutlined, PhoneOutlined, ReloadOutlined } from '@ant-design/icons'
import { Button, Empty, Result, Spin, Steps } from 'antd'
import { useCallback, useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { api } from '../../core/api'
import { money, num } from '../../core/format'

const FLOWS = {
  delivery: [['pending', 'ثبت شد', 'در انتظار تأیید رستوران'], ['accepted', 'تأیید شد', 'سفارش پذیرفته شد'], ['preparing', 'در حال آماده‌سازی', 'آشپزخانه مشغول است'],
    ['ready', 'آماده ارسال', 'منتظر پیک'], ['out', 'پیک در راه است', 'به‌زودی می‌رسد'], ['delivered', 'تحویل شد', 'نوش جان!']],
  pickup: [['pending', 'ثبت شد', 'در انتظار تأیید'], ['accepted', 'تأیید شد', ''], ['preparing', 'در حال آماده‌سازی', ''], ['ready', 'آماده تحویل', 'به صندوق مراجعه کنید'], ['completed', 'تحویل شد', 'نوش جان!']],
  table: [['pending', 'ثبت شد', 'در انتظار تأیید گارسون'], ['accepted', 'تأیید شد', ''], ['preparing', 'در حال آماده‌سازی', ''], ['ready', 'آماده سرو', 'به‌زودی سر میز می‌آید']],
}
const DONE = ['rejected', 'cancelled', 'delivered', 'completed']

export default function Track() {
  const { token } = useParams()
  const nav = useNavigate()
  const [t, setT] = useState(null)
  const [err, setErr] = useState(null)
  const load = useCallback(() => api(`/online/public/orders/${token}`).then(setT).catch((e) => setErr(e.message)), [token])

  useEffect(() => { document.documentElement.dataset.theme = 'light'; load() }, [load])
  useEffect(() => {
    if (!t || DONE.includes(t.stage)) return undefined
    const id = setInterval(load, 8000)
    return () => clearInterval(id)
  }, [t, load])

  if (err) return <div className="center-screen"><Empty description={err} /></div>
  if (!t) return <div className="center-screen"><Spin size="large" /></div>
  const flow = FLOWS[t.mode]
  const idx = Math.max(0, flow.findIndex((s) => s[0] === t.stage))
  const b = t.business

  return (
    <div className="qr oa">
      <div className="qr-hero" style={{ paddingBottom: 60 }}>
        <div className="qr-logo">{b.logo ? <img src={b.logo} alt="" /> : '☕'}</div>
        <h1 style={{ margin: 0, fontSize: 22 }}>{b.name}</h1>
        <div className="qr-table">{t.number ? `سفارش #${num(t.number)}` : 'پیگیری سفارش'}</div>
      </div>
      <div className="trk-card">
        {t.stage === 'rejected' || t.stage === 'cancelled' ? (
          <Result status="error" title={t.stage === 'rejected' ? 'متأسفانه سفارش شما پذیرفته نشد' : 'سفارش لغو شد'} subTitle={t.reject_reason}
            extra={b.phone && <Button href={`tel:${b.phone}`} icon={<PhoneOutlined />}>تماس با {b.name}</Button>} />
        ) : (
          <>
            <div className="trk-head">
              <div className={`trk-emoji ${DONE.includes(t.stage) ? '' : 'pulse'}`}>{{ pending: '⏳', accepted: '👍', preparing: '👨‍🍳', ready: '🛎️', out: '🛵', delivered: '🎉', completed: '🎉' }[t.stage]}</div>
              <h2>{flow[idx][1]}</h2>
              <p>{flow[idx][2]}{t.eta_minutes && !DONE.includes(t.stage) && t.stage !== 'pending' ? ` · زمان تقریبی ${num(t.eta_minutes)} دقیقه` : ''}</p>
            </div>
            <Steps direction="vertical" size="small" current={idx} status={DONE.includes(t.stage) ? 'finish' : 'process'} items={flow.map((s) => ({ title: s[1] }))} />
          </>
        )}
      </div>
      <div className="trk-card">
        <b>جزئیات سفارش</b>
        {t.items.map((i, k) => (
          <div key={k} className="trk-line">
            <span>{num(i.qty)}× {i.name}{i.modifiers?.length ? <small> ({i.modifiers.join('، ')})</small> : null}</span>
            <span>{money(i.unit_price * i.qty)}</span>
          </div>
        ))}
        {t.discount > 0 && <div className="trk-line muted" style={{ color: 'var(--green)' }}><span>تخفیف {t.promo_code ? `(کد ${t.promo_code})` : ''}</span><span>−{money(t.discount)}</span></div>}
        {t.delivery_fee > 0 && <div className="trk-line muted"><span>هزینه ارسال</span><span>{money(t.delivery_fee)}</span></div>}
        {t.tax > 0 && <div className="trk-line muted"><span>مالیات</span><span>{money(t.tax)}</span></div>}
        <div className="trk-line tot"><span>جمع کل</span><span>{money(t.total)} تومان</span></div>
        {t.address && <div className="trk-addr">📍 {t.address}</div>}
      </div>
      <div style={{ display: 'flex', gap: 10, padding: '0 14px' }}>
        <Button block size="large" icon={<ArrowRightOutlined />} onClick={() => (window.history.length > 1 ? nav(-1) : nav('/order'))}>بازگشت به منو</Button>
        <Button block size="large" icon={<ReloadOutlined />} onClick={load}>به‌روزرسانی</Button>
      </div>
      {!DONE.includes(t.stage) && <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>این صفحه به‌صورت خودکار به‌روز می‌شود</p>}
    </div>
  )
}
