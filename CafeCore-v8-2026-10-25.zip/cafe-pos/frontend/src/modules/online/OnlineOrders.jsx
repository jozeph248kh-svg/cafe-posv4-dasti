import { CopyOutlined, ExportOutlined, GlobalOutlined, SaveOutlined, SettingOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, Empty, Form, Input, InputNumber, QRCode, Row, Segmented, Space, Switch, Table, Tag, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { money, num, timeAgo } from '../../core/format'
import { useRealtime } from '../../core/realtime'
import { useFetch } from '../../core/useFetch'
import { MODE, RequestCard, useRejectDialog } from './OnlineInbox'

const ST = { pending: { label: 'در انتظار', color: 'orange' }, accepted: { label: 'تأیید شده', color: 'green' }, rejected: { label: 'رد شده', color: 'red' } }

const Sw = ({ k, label, help }) => (
  <div className="ol-sw"><div><b>{label}</b>{help && <small>{help}</small>}</div><Form.Item name={k} valuePropName="checked" noStyle><Switch /></Form.Item></div>
)

function SettingsCard() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [busy, setBusy] = useState(false)
  const s = auth.settings
  const keys = ['online.enabled', 'online.accepting', 'online.pickup', 'online.delivery', 'online.min_order', 'online.qr_ordering', 'online.qr_auto_accept', 'online.promo_otp', 'online.notice', 'online.public_url']
  const init = Object.fromEntries(keys.map((k) => [k, s[k]]))
  const [form] = Form.useForm()
  const save = async () => {
    setBusy(true)
    try { await put('/system/settings', form.getFieldsValue(true)); await auth.reloadSystem(); message.success('تنظیمات ذخیره شد') } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Card title={<span><SettingOutlined /> تنظیمات</span>} extra={<Button type="primary" icon={<SaveOutlined />} loading={busy} onClick={save}>ذخیره</Button>}>
      <Form form={form} layout="vertical" initialValues={init}>
        <Sw k="online.enabled" label="صفحه سفارش آنلاین" help="مشتری بدون نصب اپ، از لینک سفارش می‌دهد" />
        <Sw k="online.accepting" label="پذیرش سفارش" help="در شلوغی موقتاً متوقف کنید" />
        <Sw k="online.delivery" label="ارسال با پیک" help="بر اساس محدوده‌های ارسال ماژول پیک" />
        <Sw k="online.pickup" label="تحویل حضوری (بیرون‌بر)" />
        <Sw k="online.qr_ordering" label="سفارش از روی میز با QR" help="مهمان از منوی QR سفارش می‌دهد" />
        <Sw k="online.qr_auto_accept" label="ارسال خودکار سفارش میز به آشپزخانه" help="بدون نیاز به تأیید گارسون" />
        <Sw k="online.promo_otp" label="تأیید پیامکی برای کدهای تخفیف محدود" help="کدهایی که «سقف برای هر مشتری» دارند فقط با کد پیامکی به همان موبایل اعمال می‌شوند (نیاز به فعال بودن پیامک)" />
        <Row gutter={12} style={{ marginTop: 12 }}>
          <Col span={24}><Form.Item name="online.min_order" label="حداقل مبلغ سفارش آنلاین (تومان)"><InputNumber min={0} step={10000} style={{ width: '100%' }} formatter={(v) => `${v}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')} parser={(v) => v.replace(/,/g, '')} /></Form.Item></Col>
          <Col span={24}><Form.Item name="online.notice" label="پیام بالای صفحه سفارش"><Input placeholder="مثلاً: ارسال رایگان برای سفارش بالای ۱ میلیون" maxLength={150} /></Form.Item></Col>
          <Col span={24}><Form.Item name="online.public_url" label="آدرس عمومی (دامنه)" help="برای سفارش از اینترنت؛ اگر خالی باشد آدرس شبکه داخلی استفاده می‌شود"><Input className="ltr" placeholder="https://order.mycafe.ir" /></Form.Item></Col>
        </Row>
      </Form>
    </Card>
  )
}

export default function OnlineOrders() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [scope, setScope] = useState('today')
  const pend = useFetch('/online/requests', { scope: 'pending' })
  const hist = useFetch('/online/requests', { scope })
  const reloadAll = () => { pend.reload(); hist.reload() }
  useRealtime(['online.new', 'online.changed'], reloadAll)
  const [reject, rejectDialog] = useRejectDialog(reloadAll)
  const [busy, setBusy] = useState(null)
  const base = (auth.settings['online.public_url'] || auth.system.lan_urls?.[0] || window.location.origin).replace(/\/$/, '')
  const link = `${base}/order`

  const accept = async (r, eta) => {
    setBusy(r.id)
    try { const res = await post(`/online/requests/${r.id}/accept`, { eta_minutes: eta }); message.success(`سفارش #${num(res.number)} ثبت شد`); reloadAll() } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  const rows = useMemo(() => hist.data || [], [hist.data])
  const stats = useMemo(() => {
    const acc = rows.filter((r) => r.status === 'accepted')
    return { count: rows.length, accepted: acc.length, rejected: rows.filter((r) => r.status === 'rejected').length, sales: acc.reduce((a, r) => a + r.total, 0) }
  }, [rows])

  return (
    <div>
      <PageHeader title="سفارش آنلاین و QR" subtitle="سفارش‌های رسیده از صفحه آنلاین و منوی QR میزها؛ پس از تأیید مستقیم به آشپزخانه می‌روند" icon={<GlobalOutlined />} />
      <Row gutter={[16, 16]}>
        <Col xs={12} lg={6}><StatCard title={scope === 'today' ? 'سفارش‌های امروز' : 'سفارش‌های ۳۰ روز'} value={stats.count} icon="🌐" color="var(--pal-1)" loading={hist.loading} /></Col>
        <Col xs={12} lg={6}><StatCard title="تأیید شده" value={stats.accepted} icon="✅" color="var(--green)" loading={hist.loading} /></Col>
        <Col xs={12} lg={6}><StatCard title="رد شده" value={stats.rejected} icon="⛔" color="var(--red)" loading={hist.loading} /></Col>
        <Col xs={12} lg={6}><StatCard title="مبلغ سفارش‌های تأییدشده" value={stats.sales} money icon="💰" color="var(--amber)" loading={hist.loading} /></Col>

        <Col xs={24} xl={16}>
          <Card title={<span>در انتظار تأیید <Tag color="orange">{num(pend.data?.length || 0)}</Tag></span>} style={{ marginBottom: 16 }}>
            {pend.data?.length ? <div className="oi-grid">{pend.data.map((r) => <RequestCard key={r.id} r={r} busy={busy} onAccept={accept} onReject={reject} />)}</div> : <Empty description="سفارش در انتظاری نیست" />}
          </Card>
          <Card title="سوابق" extra={<Segmented value={scope} onChange={setScope} options={[{ value: 'today', label: 'امروز' }, { value: 'month', label: '۳۰ روز' }]} />}>
            <Table rowKey="id" size="middle" loading={hist.loading} dataSource={rows} pagination={{ pageSize: 10, hideOnSinglePage: true }} scroll={{ x: 620 }}
              expandable={{ expandedRowRender: (r) => <RequestCard r={r} /> }}
              columns={[
                { title: 'زمان', dataIndex: 'created_at', width: 100, render: (v) => timeAgo(v) },
                { title: 'نوع', dataIndex: 'mode', render: (v, r) => <Tag color={MODE[v].color}>{MODE[v].icon} {MODE[v].label}{r.table ? ` · ${r.table}` : ''}</Tag> },
                { title: 'مشتری', render: (_, r) => <span>{r.customer_name || '—'} {r.phone && <Typography.Text type="secondary" className="ltr" style={{ fontSize: 12 }}>{r.phone}</Typography.Text>}</span> },
                { title: 'اقلام', dataIndex: 'items', render: (v) => num(v.reduce((a, i) => a + i.qty, 0)) },
                { title: 'مبلغ', dataIndex: 'total', render: (v) => money(v) },
                { title: 'وضعیت', dataIndex: 'status', render: (v, r) => <Tag color={ST[v].color} title={r.reject_reason || ''}>{ST[v].label}</Tag> },
              ]} />
          </Card>
        </Col>
        <Col xs={24} xl={8}>
          <Card title="لینک سفارش آنلاین" style={{ marginBottom: 16 }}>
            <div style={{ textAlign: 'center' }}>
              <QRCode value={link} size={170} style={{ margin: '0 auto' }} />
              <Typography.Paragraph className="ltr" style={{ margin: '10px 0', fontSize: 13 }} copyable={{ text: link, icon: [<CopyOutlined key="c" />, <CopyOutlined key="d" />] }}>{link}</Typography.Paragraph>
              <Space>
                <Button icon={<ExportOutlined />} href="/order" target="_blank">مشاهده صفحه</Button>
              </Space>
              <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 10, marginBottom: 0 }}>
                این لینک را در اینستاگرام، گوگل‌مپ و روی جعبه‌ها قرار دهید. سفارش میزها از طریق همان QR روی میز انجام می‌شود.
              </Typography.Paragraph>
            </div>
          </Card>
          {auth.can('settings.manage') && <SettingsCard />}
        </Col>
      </Row>
      {rejectDialog}
    </div>
  )
}
