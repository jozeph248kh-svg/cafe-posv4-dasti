import { MinusOutlined, PlusOutlined, UserOutlined } from '@ant-design/icons'
import { AutoComplete, Button, Empty, Form, Input, InputNumber, Modal, Radio, Segmented, Select, Space, Tag, Typography } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { get } from '../../core/api'
import { inkOn } from '../../core/color'
import { modText, money, moneyFormatter, moneyParser, num } from '../../core/format'

export function ReasonModal({ open, title, presets = [], onClose, onOk, loading, okText = 'تأیید', danger }) {
  const [reason, setReason] = useState('')
  useEffect(() => { if (open) setReason('') }, [open])
  return (
    <Modal open={open} title={title} onCancel={onClose} centered destroyOnClose okText={okText} okButtonProps={{ danger, disabled: reason.trim().length < 2, loading }}
      onOk={() => onOk(reason.trim())}>
      <Space wrap style={{ marginBottom: 12 }}>
        {presets.map((p) => <Tag.CheckableTag key={p} checked={reason === p} onChange={() => setReason(p)} className="big-tag">{p}</Tag.CheckableTag>)}
      </Space>
      <Input.TextArea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="دلیل را بنویسید..." maxLength={200} autoFocus />
    </Modal>
  )
}

const DISCOUNT_REASONS = ['مشتری دائمی', 'جبران تأخیر / نارضایتی', 'همکار / پرسنل', 'مناسبت ویژه', 'مهمان مدیریت', 'آیتم معیوب / سوخته']
const presetLabel = (p) => (p.kind === 'bogo' ? `${num(p.buy_qty)} بخر، ${num(p.get_qty)} ${p.value >= 100 ? 'رایگان' : `با ${num(p.value)}٪ تخفیف`}`
  : p.kind === 'combo' ? `منوی ترکیبی ${money(p.value)}` : null) || (p.value ? (p.kind === 'percent' ? `${num(p.value)}٪` : money(p.value)) : 'مبلغ دلخواه') + (p.max_amount ? ` (تا ${money(p.max_amount)})` : '')

/**
 * Bill or item discount. Shows ready-made presets (from «تخفیف‌ها»), a free discount, the user's ceiling and a preview.
 * Over the ceiling the server asks for a manager PIN (handled globally by OverrideProvider).
 */
export function DiscountModal({ open, order, line, onClose, onOk, loading }) {
  const scope = line ? 'item' : 'order'
  const [presets, setPresets] = useState([])
  const [limit, setLimit] = useState(null)
  const [presetId, setPresetId] = useState(null)
  const [type, setType] = useState('percent')
  const [value, setValue] = useState(10)
  const [reason, setReason] = useState('')
  const [tried, setTried] = useState(false)
  const [code, setCode] = useState('')          // show validation errors after the first click on «اعمال»
  const reasonRef = useRef(null)
  const current = line || order
  useEffect(() => {
    if (!open || !order) return
    get('/orders/discounts/presets', { order_id: order.id }).then((list) => setPresets(list.filter((p) => p.scope === scope || p.scope === 'both'))).catch(() => setPresets([]))
    get('/orders/discounts/my-limit').then(setLimit).catch(() => setLimit(null))
    setPresetId(null)
    setTried(false)
    setCode('')
    setType(current?.discount_type || 'percent')
    setValue(current?.discount_value || (current?.discount_type === 'amount' ? 50_000 : 10))
    setReason(current?.discount_type ? (current.discount_reason || '') : '')
  }, [open, order?.id, line?.id]) // eslint-disable-line react-hooks/exhaustive-deps
  if (!order) return null

  const preset = presets.find((p) => p.id === presetId)
  const lineTotal = line ? line.unit_price * line.qty : 0
  // what the discount applies to: the item, or the bill after item discounts
  const base = line ? lineTotal : order.subtotal - (order.line_discount_amount || 0)
  const kind = preset ? preset.kind : type
  const rule = kind === 'bogo' || kind === 'combo'          // computed by the server from the items in the order
  const val = preset ? (preset.value || value) : value
  let preview = rule ? 0 : kind === 'percent' ? Math.round(base * Math.min(val || 0, 100) / 100) : Math.min(val || 0, base)
  if (preset?.max_amount) preview = Math.min(preview, preset.max_amount)
  const pct = base > 0 ? (preview * 100) / base : 0
  const overLimit = limit && ((limit.max_pct != null && pct > limit.max_pct + 0.0001) || (limit.max_amount != null && preview > limit.max_amount))
  const periodOver = limit && ((limit.max_daily != null && (limit.used_today || 0) + preview > limit.max_daily) ||
    (limit.max_monthly != null && (limit.used_month || 0) + preview > limit.max_monthly))
  const needsPin = !limit?.can_discount || overLimit || periodOver || (preset?.requires_manager && !limit?.can_manage)
  const needValue = preset ? !preset.value : true
  const needReason = preset ? preset.reason_required : (limit?.reason_required ?? true)
  const valueError = needValue && !(val > 0) ? (kind === 'percent' ? 'درصد تخفیف را وارد کنید' : 'مبلغ تخفیف را وارد کنید') : null
  const reasonError = needReason && reason.trim().length < 2 ? (preset ? 'برای این تخفیف توضیح لازم است (مثلاً نام مهمان یا شماره کارت)' : 'دلیل تخفیف را انتخاب کنید یا بنویسید') : null
  const valid = !valueError && !reasonError
  const limitText = !limit ? '' : !limit.can_discount ? 'شما مجوز تخفیف ندارید؛ با تأیید مدیر' :
    (limit.max_pct == null && limit.max_amount == null) ? 'بدون سقف' :
      [limit.max_pct != null && `${num(limit.max_pct)}٪`, limit.max_amount != null && `${money(limit.max_amount)} تومان`].filter(Boolean).join(' و ')

  const submit = () => {
    if (!valid) {                     // never a silently-disabled button: say what is missing
      setTried(true)
      if (reasonError) setTimeout(() => reasonRef.current?.focus(), 0)
      return
    }
    send()
  }
  const send = () => onOk(preset ? { preset_id: preset.id, value: preset.value ? 0 : val, reason: reason.trim() || null }
    : { type, value: val, reason: reason.trim() || null })

  return (
    <Modal open={open} onCancel={onClose} centered destroyOnClose width={560}
      title={line ? <span>تخفیف آیتم «{line.name}» <Typography.Text type="secondary" style={{ fontSize: 13 }}>({num(line.qty)}× · {money(lineTotal)})</Typography.Text></span> : 'تخفیف کل فاکتور'}
      footer={[
        current?.discount_type && !current?.discount_auto && <Button key="rm" danger onClick={() => onOk({ type: null, value: 0 })}>حذف تخفیف</Button>,
        <Button key="c" onClick={onClose}>انصراف</Button>,
        <Button key="ok" type="primary" loading={loading} onClick={submit} className="disc-apply">{needsPin ? 'اعمال با تأیید مدیر' : 'اعمال تخفیف'}</Button>,
      ]}>
      <Space direction="vertical" style={{ width: '100%' }} size={14}>
        {presets.length > 0 && (
          <div>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>تخفیف‌های آماده</Typography.Text>
            <div className="disc-presets">
              {presets.map((p) => (
                <button type="button" key={p.id} disabled={!!p.unavailable} title={p.unavailable || ''}
                  className={`disc-preset ${presetId === p.id ? 'on' : ''}`} style={{ '--c': p.color || '#4f46e5', '--ci': inkOn(p.color || '#4f46e5') }}
                  onClick={() => { setPresetId(presetId === p.id ? null : p.id); if (!p.value) setValue(p.kind === 'percent' ? 10 : 50_000) }}>
                  <b>{p.name}{p.requires_manager ? ' 🔒' : ''}</b>
                  <small>{p.unavailable || presetLabel(p)}</small>
                </button>
              ))}
            </div>
          </div>
        )}
        {(!preset || !preset.value) && <>
          {!preset && <Segmented block value={type} onChange={(v) => { setType(v); setValue(v === 'percent' ? 10 : 50_000) }} options={[{ value: 'percent', label: 'درصدی' }, { value: 'amount', label: 'مبلغ ثابت' }]} />}
          {kind === 'percent' && <Space wrap>{[5, 10, 15, 20, 25, 50, 100].map((p) => <Button key={p} type={val === p ? 'primary' : 'default'} onClick={() => setValue(p)}>{p === 100 ? 'رایگان (۱۰۰٪)' : `${num(p)}٪`}</Button>)}</Space>}
          <InputNumber size="large" style={{ width: '100%' }} value={value} min={0} max={kind === 'percent' ? 100 : base} onChange={setValue}
            formatter={kind === 'amount' ? moneyFormatter : undefined} parser={kind === 'amount' ? moneyParser : undefined} addonAfter={kind === 'percent' ? '٪' : 'تومان'} />
        </>}
        {(needReason || !preset) && (
          <div>
            {!preset && (
              <div className="disc-reasons">
                {DISCOUNT_REASONS.map((r) => <Tag.CheckableTag key={r} checked={reason === r} onChange={() => setReason(reason === r ? '' : r)} className="big-tag">{r}</Tag.CheckableTag>)}
              </div>
            )}
            <Input ref={reasonRef} className="disc-reason" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={100} allowClear
              status={tried && reasonError ? 'error' : undefined}
              placeholder={preset ? 'توضیح — مثلاً نام مهمان یا شماره کارت' : needReason ? 'یا دلیل دیگری بنویسید (الزامی)' : 'دلیل (اختیاری)'} />
            {tried && reasonError && <div className="field-error">{reasonError}</div>}
          </div>
        )}
        {tried && valueError && <div className="field-error">{valueError}</div>}
        <div className="disc-code">
          <Input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="کد تخفیف دارید؟" className="ltr" maxLength={30} allowClear
            onPressEnter={() => code.trim() && onOk({ code: code.trim() })} />
          <Button disabled={!code.trim()} loading={loading} onClick={() => onOk({ code: code.trim() })}>اعمال کد</Button>
        </div>
        <div className="disc-summary">
          {rule
            ? <div><span>مبلغ تخفیف</span><b style={{ fontSize: 15 }}>بر اساس اقلام سفارش</b><span className="muted">{kind === 'bogo' ? 'ارزان‌ترین اقلام واجد شرایط تخفیف می‌گیرند' : 'برای هر مجموعه کامل از اجزای منو'}</span></div>
            : <div><span>مبلغ تخفیف</span><b>{money(preview)} <small>تومان</small></b><span className="muted">{base > 0 ? `${num(Math.round(pct * 10) / 10)}٪ از ${money(base)}` : ''}</span></div>}
          {limit && <div className={needsPin ? 'warn' : 'ok'}>{needsPin ? '🔒 نیاز به تأیید مدیر' : '✓ در محدوده مجاز شما'}<span className="muted">سقف شما: {limitText}</span>
            {limit.max_daily != null && <span className="muted">امروز: {money(limit.used_today || 0)} از {money(limit.max_daily)}</span>}
            {limit.max_monthly != null && <span className="muted">این ماه: {money(limit.used_month || 0)} از {money(limit.max_monthly)}</span>}
          </div>}
        </div>
      </Space>
    </Modal>
  )
}

export function TransferModal({ open, floor, current, onClose, onOk }) {
  const free = (floor || []).map((a) => ({ ...a, tables: a.tables.filter((t) => t.status === 'free') })).filter((a) => a.tables.length)
  return (
    <Modal open={open} title={`انتقال از میز ${current?.table_name || ''}`} onCancel={onClose} footer={null} centered width={560}>
      {!free.length && <Empty description="میز آزادی وجود ندارد" />}
      {free.map((a) => (
        <div key={a.id} style={{ marginBottom: 14 }}>
          <Typography.Text type="secondary">{a.name}</Typography.Text>
          <div className="pick-grid">{a.tables.map((t) => <button type="button" key={t.id} className="pick-table" onClick={() => onOk(t.id)}>{t.name}<small>{num(t.seats)} نفره</small></button>)}</div>
        </div>
      ))}
    </Modal>
  )
}

export function MergeModal({ open, orders, current, onClose, onOk }) {
  const others = (orders || []).filter((o) => o.id !== current?.id)
  return (
    <Modal open={open} title="ادغام با سفارش دیگر" onCancel={onClose} footer={null} centered width={560}>
      <Typography.Paragraph type="secondary">اقلام این سفارش به سفارش انتخاب‌شده منتقل و این سفارش بسته می‌شود.</Typography.Paragraph>
      {!others.length && <Empty description="سفارش باز دیگری وجود ندارد" />}
      <div className="pick-grid">
        {others.map((o) => (
          <button type="button" key={o.id} className="pick-table" onClick={() => onOk(o.id)}>
            {o.table_name ? `میز ${o.table_name}` : o.customer_name || 'بیرون‌بر'}
            <small>#{num(o.number)} · {money(o.total)}</small>
          </button>
        ))}
      </div>
    </Modal>
  )
}

export function SplitModal({ open, order, onClose, onOk, loading }) {
  const [sel, setSel] = useState({})
  useEffect(() => { if (open) setSel({}) }, [open])
  if (!order) return null
  const lines = order.lines.filter((l) => l.status !== 'void')
  const moved = lines.reduce((a, l) => a + (sel[l.id] || 0) * l.unit_price, 0)
  const set = (l, q) => setSel({ ...sel, [l.id]: Math.max(0, Math.min(l.qty, q)) })
  const payload = Object.entries(sel).filter(([, q]) => q > 0).map(([id, qty]) => ({ line_id: Number(id), qty }))
  return (
    <Modal open={open} title="تقسیم صورتحساب" onCancel={onClose} centered width={560} okText={`ایجاد صورتحساب جدید · ${money(moved)}`}
      okButtonProps={{ disabled: !payload.length, loading }} onOk={() => onOk(payload)}>
      <Typography.Paragraph type="secondary">اقلامی که می‌خواهید جداگانه حساب شوند را انتخاب کنید (مثلاً سهم یک نفر).</Typography.Paragraph>
      <div className="split-list">
        {lines.map((l) => (
          <div key={l.id} className={`split-row ${sel[l.id] ? 'on' : ''}`}>
            <div><b>{l.name}</b>{l.modifiers?.length > 0 && <div className="ol-mods">{modText(l.modifiers)}</div>}</div>
            <Space>
              <Typography.Text type="secondary">{money(l.unit_price)}</Typography.Text>
              <Space.Compact>
                <Button icon={<PlusOutlined />} onClick={() => set(l, (sel[l.id] || 0) + 1)} disabled={(sel[l.id] || 0) >= l.qty} />
                <Button style={{ width: 64, pointerEvents: 'none' }}>{num(sel[l.id] || 0)}/{num(l.qty)}</Button>
                <Button icon={<MinusOutlined />} onClick={() => set(l, (sel[l.id] || 0) - 1)} disabled={!sel[l.id]} />
              </Space.Compact>
            </Space>
          </div>
        ))}
      </div>
    </Modal>
  )
}

/** Customer phone lookup + name/address (takeaway / delivery / credit) and guests/waiter for dine-in. */
export function OrderInfoModal({ open, initial, type, waiters, onClose, onOk, loading, title }) {
  const [form] = Form.useForm()
  const [options, setOptions] = useState([])
  const [history, setHistory] = useState(null)
  useEffect(() => { if (open) { form.resetFields(); form.setFieldsValue({ guests: 2, ...initial }); setHistory(null) } }, [open]) // eslint-disable-line
  // debounced customer lookup. The timer and the request sequence live in refs: the modal can close
  // while a request is in flight, and a slow answer for an older query must never overwrite a newer one.
  const searchTimer = useRef(null)
  const searchSeq = useRef(0)
  useEffect(() => () => clearTimeout(searchTimer.current), [])
  const search = useMemo(() => (q) => {
    clearTimeout(searchTimer.current)
    if (!q || q.length < 3) { setOptions([]); return }
    const my = ++searchSeq.current
    searchTimer.current = setTimeout(() => get('/customers', { q, limit: 8 })
      .then((rows) => { if (my === searchSeq.current) setOptions(rows.map((c) => ({
        value: c.phone, c, label: <div className="cust-opt"><b>{c.name}</b><span className="ltr">{c.phone}</span><small>{num(c.visits)} خرید</small></div>,
      }))) })
      .catch(() => {}), 250)
  }, [])
  const pickCustomer = (_, opt) => {
    // customer_id lets the server use the real number when this user only sees it masked (0912***4567)
    form.setFieldsValue({ customer_id: opt.c.id, customer_name: opt.c.name, customer_phone: opt.c.phone, customer_address: opt.c.address || form.getFieldValue('customer_address') })
    setHistory(opt.c)
  }
  return (
    <Modal open={open} title={title} onCancel={onClose} centered destroyOnClose okText="تأیید" confirmLoading={loading} onOk={() => form.submit()}>
      <Form form={form} layout="vertical" onFinish={onOk} requiredMark={false}>
        <Form.Item name="customer_id" hidden><Input /></Form.Item>
        {type === 'dine_in' && (
          <Space size={16} style={{ display: 'flex' }}>
            <Form.Item name="guests" label="تعداد نفرات"><InputNumber min={1} max={100} size="large" /></Form.Item>
            {waiters?.length > 0 && (
              <Form.Item name="waiter_id" label="گارسون" style={{ flex: 1 }}>
                <Select size="large" allowClear placeholder="انتخاب گارسون" options={waiters.map((w) => ({ value: w.id, label: w.full_name }))} />
              </Form.Item>
            )}
          </Space>
        )}
        <Form.Item name="customer_phone" label="شماره تماس مشتری" rules={type === 'delivery' ? [{ required: true, message: 'برای پیک الزامی است' }] : []}>
          <AutoComplete options={options} onSearch={search} onSelect={pickCustomer} size="large" placeholder="۰۹۱۲..." className="ltr-input"
            onChange={(v) => { if (!String(v || '').includes('*')) form.setFieldsValue({ customer_id: undefined }) }}>
            <Input prefix={<UserOutlined />} inputMode="tel" />
          </AutoComplete>
        </Form.Item>
        {history && <Tag color="green" style={{ marginTop: -12, marginBottom: 12 }}>مشتری قدیمی · {num(history.visits)} خرید · مجموع {money(history.total_spent)}</Tag>}
        <Form.Item name="customer_name" label="نام مشتری"><Input size="large" /></Form.Item>
        {type === 'delivery' && (
          <Form.Item name="customer_address" label="آدرس" rules={[{ required: true, message: 'آدرس را وارد کنید' }]}><Input.TextArea rows={2} /></Form.Item>
        )}
        <Form.Item name="note" label="توضیحات سفارش"><Input /></Form.Item>
      </Form>
    </Modal>
  )
}

export function ShiftOpenModal({ open, onClose, onOk, loading }) {
  const [cash, setCash] = useState(0)
  return (
    <Modal open={open} title="باز کردن شیفت صندوق" onCancel={onClose} centered okText="باز کردن صندوق" confirmLoading={loading} onOk={() => onOk(cash)}>
      <Typography.Paragraph type="secondary">برای دریافت پرداخت، ابتدا شیفت صندوق را باز کنید. موجودی نقدی فعلی داخل صندوق را وارد کنید.</Typography.Paragraph>
      <InputNumber size="large" style={{ width: '100%' }} value={cash} min={0} onChange={(v) => setCash(v || 0)} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" autoFocus />
      <Space wrap style={{ marginTop: 10 }}>{[0, 500_000, 1_000_000, 2_000_000].map((v) => <Button key={v} onClick={() => setCash(v)}>{money(v)}</Button>)}</Space>
    </Modal>
  )
}

export function LineNoteModal({ line, onClose, onOk }) {
  const [note, setNote] = useState('')
  useEffect(() => { setNote(line?.note || '') }, [line])
  return (
    <Modal open={!!line} title={`توضیح برای ${line?.name || ''}`} onCancel={onClose} onOk={() => onOk(note)} centered>
      <Input.TextArea value={note} onChange={(e) => setNote(e.target.value)} rows={2} maxLength={200} autoFocus />
    </Modal>
  )
}

export const VOID_REASONS = ['مشتری منصرف شد', 'اشتباه در ثبت', 'تأخیر زیاد', 'کیفیت نامناسب', 'تمام شدن مواد']
export const CANCEL_REASONS = ['مشتری منصرف شد', 'سفارش تکراری', 'اشتباه در ثبت', 'عدم پاسخگویی مشتری']

export { Radio }
