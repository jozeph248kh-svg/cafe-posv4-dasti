import { LeftOutlined, RightOutlined, SearchOutlined } from '@ant-design/icons'
import { Empty, Input, Tag } from 'antd'
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { money, num, toEnDigits } from '../../core/format'

export default function MenuPicker({ menu, onPick, counts = {} }) {
  const [cat, setCat] = useState('all')
  const [q, setQ] = useState('')
  const inputRef = useRef(null)
  // The category strip is one row of fixed-width chips. Its scrollbar is hidden by design, so with a mouse only
  // there was no way to reach the chips that overflow (they looked cut in half, and the last categories could not
  // be opened at all). Arrow buttons on the side that still has chips + wheel-to-scroll fix that.
  const catsRef = useRef(null)
  const [edge, setEdge] = useState({ left: false, right: false })   // is something still hidden on that side?

  const measure = useCallback(() => {
    const el = catsRef.current
    if (!el) return
    const max = el.scrollWidth - el.clientWidth
    const pos = Math.abs(el.scrollLeft)            // RTL: scrollLeft runs 0 → −max, so work with magnitudes
    const dir = el.closest('[dir]')?.getAttribute('dir') || document.documentElement.dir || 'ltr'
    const rtl = dir === 'rtl'
    // which side still has hidden chips? (in RTL the row starts at the right edge)
    const left = rtl ? pos < max - 2 : pos > 2
    const right = rtl ? pos > 2 : pos < max - 2
    setEdge({ left: max > 2 && left, right: max > 2 && right })
  }, [])

  useLayoutEffect(() => { measure() }, [menu, measure])

  useEffect(() => {
    const el = catsRef.current
    if (!el) return undefined
    measure()
    let ro
    if (typeof ResizeObserver !== 'undefined') {       // the strip is wider/narrower after a resize or a zoom
      ro = new ResizeObserver(measure)
      ro.observe(el)
    }
    window.addEventListener('resize', measure)
    // a vertical mouse wheel over the strip scrolls it sideways (the page behind it does not jump)
    const onWheel = (e) => {
      if (el.scrollWidth <= el.clientWidth) return
      const d = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX
      if (!d) return
      e.preventDefault()
      el.scrollBy({ left: -d, behavior: 'auto' })
      measure()
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => {
      window.removeEventListener('resize', measure)
      if (ro) ro.disconnect()
      el.removeEventListener('wheel', onWheel)
    }
  }, [measure])

  const scrollCats = (side) => {
    const el = catsRef.current
    if (!el) return
    const dir = el.closest('[dir]')?.getAttribute('dir') || document.documentElement.dir || 'ltr'
    const unit = (el.querySelector('.cat-chip')?.offsetWidth || 116) + 10      // one chip + the gap
    const wanted = Math.max(240, el.clientWidth * 0.8)
    const step = Math.max(1, Math.round(wanted / unit)) * unit                  // land on a chip boundary
    // "left" means: reveal the chips hidden on the left edge (negative scrollLeft in RTL)
    const delta = side === 'left' ? (dir === 'rtl' ? -step : step) : (dir === 'rtl' ? step : -step)
    el.scrollBy({ left: delta, behavior: 'smooth' })
    setTimeout(measure, 320)
  }

  const cats = useMemo(() => (menu?.categories || []).filter((c) => c.is_active), [menu])
  const catMap = useMemo(() => Object.fromEntries(cats.map((c) => [c.id, c])), [cats])

  const catCount = useMemo(() => {
    const m = {}
    ;(menu?.items || []).forEach((i) => { if (i.is_active) m[i.category_id] = (m[i.category_id] || 0) + 1 })
    return m
  }, [menu])
  const total = Object.values(catCount).reduce((a, b) => a + b, 0)

  const items = useMemo(() => {
    let list = (menu?.items || []).filter((i) => i.is_active && catMap[i.category_id])
    const query = toEnDigits(q.trim())
    if (query) list = list.filter((i) => i.name.includes(query) || (i.code && i.code.startsWith(query)))
    else if (cat !== 'all') list = list.filter((i) => i.category_id === cat)
    return list
  }, [menu, cat, q, catMap])

  const onEnter = () => {
    const code = toEnDigits(q.trim())
    const exact = (menu?.items || []).find((i) => i.code === code && i.is_active)
    const pick = exact || (items.length === 1 ? items[0] : null)
    if (pick && pick.is_available) { onPick(pick); setQ('') }
  }

  return (
    <div className="menu-picker">
      <div className="mp-top">
        <Input ref={inputRef} allowClear size="large" prefix={<SearchOutlined />} placeholder="جستجوی نام یا کد آیتم (Enter برای افزودن)"
          value={q} onChange={(e) => setQ(e.target.value)} onPressEnter={onEnter} />
      </div>
      <div className={`mp-cats-wrap${edge.right ? ' more-start' : ''}${edge.left ? ' more-end' : ''}`}>
        {edge.right && (
          <button type="button" className="mp-arrow start" aria-label="دسته‌های سمت راست" onClick={() => scrollCats('right')}>
            <RightOutlined />
          </button>
        )}
        <div className="mp-cats" ref={catsRef} onScroll={measure}>
          <button type="button" className={`cat-chip ${cat === 'all' && !q ? 'on' : ''}`} onClick={() => { setCat('all'); setQ('') }}>
            <span className="cc-icon">🍴</span><span className="cc-name">همه</span><small className="cc-count">{num(total)} آیتم</small>
          </button>
          {cats.map((c) => (
            <button type="button" key={c.id} className={`cat-chip ${cat === c.id && !q ? 'on' : ''}`} style={{ '--c': c.color }} onClick={() => { setCat(c.id); setQ('') }} title={c.name}>
              <span className="cc-icon">{c.icon || '🍽️'}</span><span className="cc-name">{c.name}</span><small className="cc-count">{num(catCount[c.id] || 0)} آیتم</small>
            </button>
          ))}
        </div>
        {edge.left && (
          <button type="button" className="mp-arrow end" aria-label="دسته‌های سمت چپ" onClick={() => scrollCats('left')}>
            <LeftOutlined />
          </button>
        )}
      </div>
      <div className="mp-grid">
        {items.map((i) => {
          const c = catMap[i.category_id]
          return (
            <button type="button" key={i.id} className={`item-card ${i.is_available ? '' : 'off'} ${counts[i.id] > 0 ? 'in' : ''}`} style={{ '--c': c?.color }}
              disabled={!i.is_available} onClick={() => onPick(i)}>
              {counts[i.id] > 0 && <span className="ic-count" key={counts[i.id]}>{counts[i.id].toLocaleString('fa-IR')}</span>}
              {/* real photo when uploaded, otherwise the category emoji on a tinted tile */}
              <span className="ic-pic">{i.image ? <img src={i.image} alt="" className="ic-img" loading="lazy" /> : <span className="ic-emoji">{c?.icon || '🍽️'}</span>}</span>
              <span className="ic-body">
                <span className="ic-name">{i.name}</span>
                <span className="ic-foot">
                  <span className="ic-price">{money(i.price)}</span>
                  {i.code && <span className="ic-code">{Number(i.code).toLocaleString('fa-IR', { useGrouping: false })}</span>}
                </span>
              </span>
              {!i.is_available && <span className="ic-off">ناموجود</span>}
              {i.tags?.includes('پرفروش') && i.is_available && <Tag color="volcano" className="ic-tag">پرفروش</Tag>}
            </button>
          )
        })}
        {!items.length && <Empty description="آیتمی یافت نشد" style={{ gridColumn: '1/-1', marginTop: 40 }} />}
      </div>
    </div>
  )
}
