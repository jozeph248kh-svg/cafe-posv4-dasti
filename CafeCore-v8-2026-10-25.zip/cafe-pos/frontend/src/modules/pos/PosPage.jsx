import {
  AppstoreOutlined, BellOutlined, LockOutlined, PlusOutlined, ReloadOutlined, ShoppingOutlined, WalletOutlined,
} from '@ant-design/icons'
import { App, Badge, Button, Dropdown, Grid, List, Modal, Result, Segmented, Space, Tag, Tooltip, Typography } from 'antd'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ConnectionBadge from '../../components/ConnectionBadge'
import OutboxBadge from '../../components/OutboxBadge'
import { DeviceRegisterModal, deviceRegister } from '../../components/Registers'
import TimeClockButton from '../../components/TimeClockButton'
import { ApiError, del, get, newRequestId, patch, post } from '../../core/api'
import { enqueue, isOffline, serverReachable, startOutbox } from '../../core/outbox'
import { useAuth } from '../../core/auth'
import { getRegisterId } from '../../core/register'
import { ORDER_TYPES, money, num, timeAgo } from '../../core/format'
import { printReceipt } from '../../core/print'
import { beep, useRealtime, useWsStatus } from '../../core/realtime'
import ThemeSwitcher from '../../components/ThemeSwitcher'
import FloorView from './FloorView'
import MenuPicker from './MenuPicker'
import ModifierModal from './ModifierModal'
import OrderPanel from './OrderPanel'
import MarketInbox from '../marketplace/MarketInbox'
import OnlineInbox from '../online/OnlineInbox'
import PaymentModal from './PaymentModal'
import {
  CANCEL_REASONS, DiscountModal, LineNoteModal, MergeModal, OrderInfoModal, ReasonModal, ShiftOpenModal, SplitModal, TransferModal, VOID_REASONS,
} from './dialogs'

let keySeq = 0
const sameLine = (a, b) => a.menu_item_id === b.menu_item_id && (a.note || '') === (b.note || '') &&
  JSON.stringify([...a.modifier_option_ids].sort()) === JSON.stringify([...b.modifier_option_ids].sort())

export default function PosPage() {
  const auth = useAuth()
  const nav = useNavigate()
  const { message, notification, modal } = App.useApp()
  const screens = Grid.useBreakpoint()
  const mobile = !screens.lg

  const [menu, setMenu] = useState(null)
  const [floor, setFloor] = useState(null)
  const [openOrders, setOpenOrders] = useState([])
  const [loadingFloor, setLoadingFloor] = useState(false)
  const [shift, setShift] = useState(undefined)
  const [registers, setRegisters] = useState(null)
  const wsStatus = useWsStatus()
  const [regBad, setRegBad] = useState(false)
  const [calls, setCalls] = useState([])
  const [waiters, setWaiters] = useState([])
  const [view, setView] = useState('floor')            // floor | orders
  const [order, setOrder] = useState(null)              // server order
  const [draft, setDraft] = useState(null)              // not yet saved order header
  const [newLines, setNewLines] = useState([])
  const [busy, setBusy] = useState(null)
  const [dialog, setDialog] = useState(null)            // { kind, ... }
  const [modItem, setModItem] = useState(null)
  const [mobileTab, setMobileTab] = useState('menu')
  const activeId = useRef(null)
  activeId.current = order?.id

  const groups = useMemo(() => Object.fromEntries((menu?.modifier_groups || []).map((g) => [g.id, g])), [menu])
  const active = order || draft
  const hasShifts = auth.hasModule('shifts')

  // ------------------------------------------------------------ data loading
  const loadMenu = useCallback(() => get('/menu/full').then((m) => {
    setMenu(m)
    try { localStorage.setItem('cafe_menu_cache', JSON.stringify(m)) } catch { /* storage full: cache is optional */ }
  }).catch((e) => {
    let cached = null
    try { cached = JSON.parse(localStorage.getItem('cafe_menu_cache')) } catch { /* ignore */ }
    if (isOffline(e) && cached) { setMenu((cur) => cur || cached); message.warning('ارتباط با سرور قطع است؛ منو از حافظه این دستگاه نمایش داده می‌شود') }
    else message.error(e.message)
  }), [message])
  const loadFloor = useCallback(async () => {
    setLoadingFloor(true)
    try {
      const [f, o] = await Promise.all([get('/orders/floor'), get('/orders/active')])
      setFloor(f)
      setOpenOrders(o)
    } catch (e) {
      if (!isOffline(e)) message.error(e.message)      // offline: keep the last floor on screen; the queue warning says the rest
    } finally { setLoadingFloor(false) }
  }, [message])
  const loadShift = useCallback(() => {
    if (!hasShifts) return
    get('/shifts/current').then((x) => { setShift(x); setRegBad(false) }).catch((e) => { if (e.code === 'register_invalid') { setShift(null); setRegBad(true) } })
    get('/shifts/registers').then(setRegisters).catch(() => {})
  }, [hasShifts])
  const loadCalls = useCallback(() => auth.hasModule('public') && get('/public/calls').then(setCalls).catch(() => {}), [auth])
  const refreshOrder = useCallback(async (id) => {
    const o = await get(`/orders/${id}`)
    if (o.status !== 'open') { setOrder(null); setNewLines([]); return null }
    setOrder(o)
    return o
  }, [])

  useEffect(() => {
    startOutbox()
    const sent = (ev) => { message.success(`${num(ev.detail)} سفارش از صف آفلاین به سرور ارسال شد`); scheduleFloor() }
    window.addEventListener('outbox:sent', sent)
    return () => window.removeEventListener('outbox:sent', sent)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    loadMenu(); loadFloor(); loadShift(); loadCalls()
    get('/staff/users/basic').then((u) => setWaiters(u.filter((x) => ['waiter', 'cashier', 'manager'].includes(x.role)))).catch(() => {})
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // live updates from other devices
  const floorTimer = useRef(null)
  const scheduleFloor = () => { clearTimeout(floorTimer.current); floorTimer.current = setTimeout(loadFloor, 250) }
  useRealtime(['order.changed', 'floor.changed', '_reconnected'], (d, topic) => {
    scheduleFloor()
    if (topic === '_reconnected') { loadMenu(); loadShift(); loadCalls() }
    if (activeId.current && (!d || d.id === activeId.current)) refreshOrder(activeId.current).catch(() => {})
  })
  useRealtime('menu.changed', loadMenu)
  useRealtime('shift.changed', loadShift)
  useEffect(() => {
    window.addEventListener('register:changed', loadShift)
    return () => window.removeEventListener('register:changed', loadShift)
  }, [loadShift])
  const multiReg = (registers || []).filter((r) => r.is_active).length > 1
  const devReg = deviceRegister(registers)
  const askRegister = hasShifts && auth.can('payments.take') && registers && ((multiReg && !getRegisterId()) || regBad || !devReg.valid)
  useRealtime('kitchen.ready', (d) => {
    if (!d.waiter_id || d.waiter_id === auth.user.id || auth.can('payments.take')) {
      beep('ready')
      notification.success({ message: `سفارش #${num(d.order_number)} ${d.table_name ? `· میز ${d.table_name}` : ''} آماده است`, description: d.items?.join('، '), duration: 8 })
    }
  })
  useRealtime('service.call', (d) => {
    beep('call')
    notification.warning({ message: `میز ${d.table_name}`, description: d.kind === 'bill' ? 'درخواست صورتحساب دارد 🧾' : 'گارسون را صدا می‌زند 🙋', duration: 0, key: `call-${d.id}` })
    loadCalls()
  })
  useRealtime('service.ack', (d) => { notification.destroy(`call-${d.id}`); loadCalls() })

  // ------------------------------------------------------------ helpers
  const run = async (key, fn, okMsg) => {
    setBusy(key)
    try {
      const r = await fn()
      if (okMsg) message.success(okMsg)
      return r
    } catch (e) {
      if (e.code === 'shift_closed') setDialog({ kind: 'shift' })
      else if (e.code === 'queued') message.warning({ content: 'ارتباط با سرور قطع است؛ سفارش در «صف آفلاین» این دستگاه ذخیره شد و با وصل شدن، خودکار ارسال می‌شود.', duration: 7 })
      else if (e.code !== 'override_cancelled') message.error(e.message)
      throw e
    } finally { setBusy(null) }
  }
  const closeActive = () => {
    if (newLines.length) {
      modal.confirm({ title: 'آیتم‌های ثبت‌نشده', content: 'آیتم‌های جدید هنوز ثبت نشده‌اند. بدون ذخیره خارج می‌شوید؟', okText: 'خروج بدون ذخیره', cancelText: 'بازگشت', okButtonProps: { danger: true }, onOk: reset })
    } else reset()
  }
  function reset() { setOrder(null); setDraft(null); setNewLines([]); setMobileTab('menu'); loadFloor() }

  const openTable = async (t) => {
    if (newLines.length) { message.warning('ابتدا آیتم‌های سفارش فعلی را ثبت یا حذف کنید'); return }
    if (t.order_id) {
      try { await refreshOrder(t.order_id); setDraft(null); setNewLines([]); setMobileTab('order') } catch (e) { message.error(e.message) }
    } else {
      setOrder(null); setNewLines([]); setMobileTab('menu')
      setDraft({ type: 'dine_in', table_id: t.id, table_name: t.name, guests: Math.min(2, t.seats), waiter_id: auth.user.id })
    }
  }
  const openOrder = async (o) => {
    if (newLines.length) { message.warning('ابتدا آیتم‌های سفارش فعلی را ثبت یا حذف کنید'); return }
    await refreshOrder(o.id); setDraft(null); setNewLines([]); setMobileTab('order')
  }
  const newNonTable = (type) => setDialog({ kind: 'newcustomer', type })

  // ------------------------------------------------------------ lines
  const addLine = (l) => {
    setNewLines((cur) => {
      const same = cur.find((x) => sameLine(x, l))
      if (same) return cur.map((x) => (x === same ? { ...x, qty: x.qty + l.qty } : x))
      return [...cur, { ...l, key: ++keySeq }]
    })
    if (navigator.vibrate) navigator.vibrate(15)
  }
  const pickItem = (item) => {
    if (!active) { message.info('ابتدا میز یا نوع سفارش را انتخاب کنید'); return }
    if (item.modifier_group_ids?.length) setModItem({ item })
    else addLine({ menu_item_id: item.id, name: item.name, qty: 1, unit_price: item.price, modifier_option_ids: [], modifiers: [], note: null })
  }
  const onLine = async (kind, l, value) => {
    if (kind === 'local-qty') setNewLines((cur) => cur.map((x) => (x.key === l.key ? { ...x, qty: value } : x)))
    else if (kind === 'local-remove') setNewLines((cur) => cur.filter((x) => x.key !== l.key))
    else if (kind === 'local-edit') {
      const item = menu.items.find((i) => i.id === l.menu_item_id)
      if (item.modifier_group_ids?.length) setModItem({ item, edit: l })
      else setDialog({ kind: 'note', line: l })
    } else if (kind === 'server-qty') await run('line', async () => setOrder(await patch(`/orders/${order.id}/lines/${l.id}`, { qty: value })))
    else if (kind === 'server-remove') await run('line', async () => setOrder(await del(`/orders/${order.id}/lines/${l.id}`)))
    else if (kind === 'void') setDialog({ kind: 'void', line: l })
    else if (kind === 'discount') setDialog({ kind: 'discount', line: l })
  }
  const toPayload = (lines) => lines.map(({ menu_item_id, qty, modifier_option_ids, note }) => ({ menu_item_id, qty, modifier_option_ids, note }))

  // ------------------------------------------------------------ save / send
  const save = async (send) => {
    const r = await run(send ? 'send' : 'save', async () => {
      let o
      const rid = newRequestId()      // the same id is used if this write ends up in the offline queue → no duplicates
      const lines = toPayload(newLines)
      try {
        if (!order) o = await post('/orders', { ...draft, lines, send, request_id: rid })
        else if (newLines.length) o = await post(`/orders/${order.id}/lines`, { lines, send, request_id: rid })
      } catch (e) {
        if (!isOffline(e)) throw e
        const head = order ? { type: order.type, table_id: order.table_id, table_name: order.table_name, guests: order.guests, waiter_id: order.waiter_id,
          customer_name: order.customer_name, customer_phone: order.customer_phone, customer_address: order.customer_address } : draft
        enqueue({ id: rid, kind: order ? 'lines' : 'create', order_id: order?.id, order_number: order?.number, draft: head, lines, send })
        setOrder(null); setDraft(null); setNewLines([])
        throw new ApiError('queued', 0, 'queued')
      }
      if (!o) {
        if (!send) return order
        o = await post(`/orders/${order.id}/send`)
      }
      setOrder(o); setDraft(null); setNewLines([])
      return o
    }, send ? 'سفارش به آشپزخانه ارسال شد 🔥' : 'سفارش ذخیره شد')
    scheduleFloor()
    return r
  }
  // button handlers: errors were already shown to the user by run() — don't leave unhandled rejections
  const quiet = (fn) => (...args) => fn(...args).catch(() => {})
  const ensureSaved = async () => (newLines.length || !order ? save(false) : order)

  const bill = async () => {
    const o = await ensureSaved()
    const b = await run('bill', () => post(`/orders/${o.id}/bill`))
    setOrder(b)
    printReceipt(b, auth.settings, 'bill')
  }
  const startPay = async () => {
    if (wsStatus === 'offline' || !(await serverReachable())) {
      modal.warning({ title: 'پرداخت در حالت آفلاین ممکن نیست', content: 'ارتباط با سرور قطع است. سفارش‌ها در صف این دستگاه ذخیره می‌شوند، اما پرداخت و کارتخوان فقط با اتصال به سرور کار می‌کنند. پس از وصل شدن، پرداخت را انجام دهید.', okText: 'متوجه شدم' })
      return
    }
    if (hasShifts && !shift && auth.settings['shift.required'] !== false) { setDialog({ kind: 'shift', then: 'pay' }); return }
    const o = await ensureSaved()
    setDialog({ kind: 'pay', order: o })
  }
  // Idempotency: the same request id is reused only when the previous attempt's outcome is unknown (network error /
  // server busy), so a retry can never charge twice; any definite answer starts a fresh id.
  const payRid = useRef(null)
  const pay = async (payments) => {
    if (!payRid.current) payRid.current = newRequestId()
    const rid = payRid.current
    const o = await run('pay', () => post(`/orders/${dialog.order.id}/payments`, { payments, request_id: rid }).then(
      (r) => { payRid.current = null; return r },
      (e) => { if (!(e.status === 0 || e.status >= 500)) payRid.current = null; throw e },
    ))
    if (o.status === 'closed') {
      setDialog({ kind: 'paid', order: o })
      setOrder(null); setDraft(null); setNewLines([])
      loadShift()
    } else {
      setOrder(o); setDialog(null)
      message.success('پرداخت ثبت شد')
    }
    scheduleFloor()
  }

  // ------------------------------------------------------------ order actions
  const action = async (key) => {
    if (key === 'served') { setOrder(await run('x', () => post(`/orders/${order.id}/served`), 'ثبت شد')); return }
    if (key === 'info') { setDialog({ kind: 'info' }); return }
    if (key === 'discount') {
      try { await ensureSaved() } catch { return }       // a discount needs a saved order (keeps unsent items unsent)
      setDialog({ kind: 'discount' })
      return
    }
    if (key === 'split' && newLines.length) { message.warning('ابتدا آیتم‌های جدید را ثبت کنید'); return }
    setDialog({ kind: key })
  }
  const submitDialog = async (payload) => {
    const id = order?.id
    const k = dialog.kind
    try {
      if (k === 'void') setOrder(await run('dlg', () => post(`/orders/${id}/lines/${dialog.line.id}/void`, { reason: payload }), 'آیتم حذف شد'))
      if (k === 'discount') {
        const url = dialog.line ? `/orders/${id}/lines/${dialog.line.id}/discount` : `/orders/${id}/discount`
        setOrder(await run('dlg', () => post(url, payload), payload.type === null ? 'تخفیف حذف شد' : 'تخفیف اعمال شد'))
      }
      if (k === 'cancel') { await run('dlg', () => post(`/orders/${id}/cancel`, { reason: payload }), 'سفارش لغو شد'); reset() }
      if (k === 'transfer') setOrder(await run('dlg', () => post(`/orders/${id}/transfer`, { table_id: payload }), 'میز منتقل شد'))
      if (k === 'merge') { const o = await run('dlg', () => post(`/orders/${id}/merge`, { target_order_id: payload }), 'سفارش‌ها ادغام شدند'); setOrder(o) }
      if (k === 'split') {
        const n = await run('dlg', () => post(`/orders/${id}/split`, { lines: payload }), 'صورتحساب جدید ایجاد شد')
        setOrder(n)
        if (auth.can('payments.take')) setDialog({ kind: 'pay', order: n })
        else setDialog(null)
        scheduleFloor()
        return
      }
      if (k === 'info') {
        if (order) setOrder(await run('dlg', () => patch(`/orders/${id}`, payload), 'ذخیره شد'))
        else setDraft({ ...draft, ...payload })
      }
      if (k === 'newcustomer') {
        setOrder(null); setNewLines([]); setMobileTab('menu')
        setDraft({ type: dialog.type, guests: 1, ...payload })
      }
      if (k === 'shift') {
        await run('dlg', () => post('/shifts/open', { opening_cash: payload }), 'شیفت صندوق باز شد')
        await loadShift()
        if (dialog.then === 'pay') { setDialog(null); setTimeout(startPay, 50); return }
      }
      if (k === 'note') setNewLines((cur) => cur.map((x) => (x.key === dialog.line.key ? { ...x, note: payload || null } : x)))
      setDialog(null)
      scheduleFloor()
    } catch { /* message already shown */ }
  }

  const ackCall = (c) => post(`/public/calls/${c.id}/ack`).then(loadCalls)

  // ------------------------------------------------------------ render
  const counts = useMemo(() => {
    const m = {}
    newLines.forEach((l) => { m[l.menu_item_id] = (m[l.menu_item_id] || 0) + l.qty })
    return m
  }, [newLines])
  const nonTable = openOrders.filter((o) => o.type !== 'dine_in')

  const panel = (
    <OrderPanel order={order} draft={draft} newLines={newLines} busy={busy} auth={auth}
      onClose={closeActive} onLine={onLine} onSave={quiet(save)} onPay={quiet(startPay)} onBill={quiet(bill)} onAction={action}
      onEditInfo={() => setDialog({ kind: 'info' })} onRefresh={() => order && refreshOrder(order.id)} />
  )

  const ordersList = (
    <div className="orders-board">
      {['takeaway', 'delivery', 'dine_in'].map((type) => {
        const list = openOrders.filter((o) => o.type === type)
        return (
          <div key={type} className="ob-col">
            <div className="ob-head">{ORDER_TYPES[type].icon} {ORDER_TYPES[type].label} <Badge count={list.length} showZero color="var(--muted-solid)" /></div>
            {list.map((o) => (
              <button type="button" key={o.id} className="ob-card" onClick={() => openOrder(o)}>
                <div className="ob-row"><b>#{num(o.number)} {o.table_name ? `· میز ${o.table_name}` : o.customer_name ? `· ${o.customer_name}` : ''}</b><span>{money(o.total)}</span></div>
                <div className="ob-row muted"><span>{timeAgo(o.created_at)}</span><span>{o.waiter_name}</span></div>
                <div className="ob-tags">
                  {o.lines.some((l) => l.status === 'ready') && <Tag color="success">آماده</Tag>}
                  {o.lines.some((l) => l.status === 'pending') && <Tag color="warning">ثبت‌نشده</Tag>}
                  {o.paid_amount > 0 && <Tag color="blue">پرداخت ناقص</Tag>}
                  {o.customer_address && <Tag>{o.customer_address.slice(0, 28)}</Tag>}
                </div>
              </button>
            ))}
            {!list.length && <div className="ob-empty">سفارشی نیست</div>}
          </div>
        )
      })}
    </div>
  )

  const main = active ? <MenuPicker menu={menu} onPick={pickItem} counts={counts} /> : view === 'floor'
    ? <FloorView floor={floor} loading={loadingFloor} onTable={openTable} mobile={mobile} /> : ordersList

  return (
    <div className="pos">
      <header className="pos-top">
        <Space size={8}>
          <Tooltip title="برنامه‌ها"><Button type="text" icon={<AppstoreOutlined />} onClick={() => nav('/')} /></Tooltip>
          {!mobile && <span className="pos-brand"><span className="pos-logo">☕</span>{auth.settings['business.name']}</span>}
          {!active && (
            <Segmented value={view} onChange={setView} options={[
              { value: 'floor', label: 'سالن' },
              { value: 'orders', label: <span>{mobile ? 'باز' : 'سفارش‌های باز'} <Badge count={openOrders.length} size="small" color="var(--primary)" style={{ color: 'var(--primary-ink)' }} /></span> },
            ]} />
          )}
        </Space>
        <Space size={6} wrap={false}>
          <Button icon={<ShoppingOutlined />} onClick={() => newNonTable('takeaway')}>{!mobile && 'بیرون‌بر'}</Button>
          <Button icon={<PlusOutlined />} onClick={() => newNonTable('delivery')}>{!mobile && 'پیک'}</Button>
          {auth.hasModule('online') && auth.can('online.manage') && <OnlineInbox mobile={mobile} onAccepted={scheduleFloor} />}
          {auth.hasModule('marketplace') && auth.can('market.orders') && <MarketInbox mobile={mobile} />}
          {hasShifts && auth.can('shifts.manage') && (
            <Tooltip title={`${multiReg && devReg.current ? `${devReg.current.name} · ` : ''}${shift ? `شیفت باز از ${timeAgo(shift.opened_at)}${shift.opened_by ? ` (${shift.opened_by})` : ''}${shift.total_sales != null ? ` · فروش ${money(shift.total_sales)}` : ''}` : 'صندوق بسته است'}`}>
              <Tag color={shift ? 'green' : 'red'} icon={<WalletOutlined />} className="shift-tag" onClick={() => (shift ? nav('/admin/shifts') : setDialog({ kind: 'shift' }))}>
                {!mobile && (multiReg && devReg.current ? `${devReg.current.name}: ${shift ? 'باز' : 'بسته'}` : shift ? 'صندوق باز' : 'صندوق بسته')}
              </Tag>
            </Tooltip>
          )}
          {auth.hasModule('public') && (
            <Dropdown trigger={['click']} dropdownRender={() => (
              <div className="calls-dd">
                <List size="small" header={<b>درخواست‌های مشتریان</b>} dataSource={calls} locale={{ emptyText: 'درخواستی نیست' }}
                  renderItem={(c) => (
                    <List.Item actions={[<Button key="a" size="small" type="primary" onClick={() => ackCall(c)}>انجام شد</Button>]}>
                      <span>{c.kind === 'bill' ? '🧾' : '🙋'} میز {c.table_name} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{timeAgo(c.created_at)}</Typography.Text></span>
                    </List.Item>
                  )} />
              </div>
            )}>
              <Badge count={calls.length} size="small"><Button type="text" icon={<BellOutlined />} className={calls.length ? 'ring' : ''} /></Badge>
            </Dropdown>
          )}
          <TimeClockButton compact />
          <OutboxBadge />
          <ConnectionBadge />
          {!mobile && <Button type="text" icon={<ReloadOutlined />} onClick={() => { loadFloor(); loadMenu() }} />}
          {!mobile && <ThemeSwitcher />}
          <Tooltip title={`${auth.user.full_name} — قفل و تعویض کاربر`}>
            <Button icon={<LockOutlined />} onClick={() => { auth.logout(); nav('/login') }}>{!mobile && auth.user.full_name}</Button>
          </Tooltip>
        </Space>
      </header>

      <div className="pos-body">
        {mobile && active ? (
          <>
            <div className="pos-main">{mobileTab === 'menu' ? main : panel}</div>
            <div className="pos-mobile-bar">
              <Segmented block value={mobileTab} onChange={setMobileTab} options={[
                { value: 'menu', label: 'منو' },
                { value: 'order', label: <span>سفارش {(newLines.length + (order?.lines.filter((l) => l.status !== 'void').length || 0)) > 0 && <Badge count={newLines.reduce((a, l) => a + l.qty, 0) + (order?.lines.filter((l) => l.status !== 'void').reduce((a, l) => a + l.qty, 0) || 0)} size="small" />}</span> },
              ]} />
            </div>
          </>
        ) : (
          <>
            <div className="pos-main">{main}</div>
            {!mobile && <aside className="pos-side">{active ? panel : (
              <div className="order-panel empty">
                <div className="side-hint">
                  <div className="hint-emoji">🍽️</div>
                  <Typography.Title level={5}>میز را انتخاب کنید</Typography.Title>
                  <Typography.Text type="secondary">یا برای بیرون‌بر و پیک از دکمه‌های بالا استفاده کنید</Typography.Text>
                  {nonTable.length > 0 && (
                    <div style={{ marginTop: 24, width: '100%' }}>
                      <Typography.Text strong>سفارش‌های بیرون‌بر و پیک باز</Typography.Text>
                      {nonTable.map((o) => (
                        <button type="button" key={o.id} className="ob-card" onClick={() => openOrder(o)} style={{ marginTop: 8 }}>
                          <div className="ob-row"><b>{ORDER_TYPES[o.type].icon} #{num(o.number)} {o.customer_name || ''}</b><span>{money(o.total)}</span></div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}</aside>}
          </>
        )}
      </div>

      {modItem && (
        <ModifierModal item={modItem.item} groups={groups} initial={modItem.edit} onClose={() => setModItem(null)}
          onAdd={(l) => {
            if (modItem.edit) setNewLines((cur) => cur.map((x) => (x.key === modItem.edit.key ? { ...l, key: x.key } : x)))
            else addLine(l)
            setModItem(null)
          }} />
      )}
      <PaymentModal open={dialog?.kind === 'pay'} order={dialog?.order} loading={busy === 'pay'} onClose={() => setDialog(null)} onSubmit={pay} />
      <ReasonModal open={dialog?.kind === 'void'} title={`حذف «${dialog?.line?.name || ''}»`} presets={VOID_REASONS} danger okText="حذف آیتم" loading={busy === 'dlg'} onClose={() => setDialog(null)} onOk={submitDialog} />
      <ReasonModal open={dialog?.kind === 'cancel'} title="لغو کل سفارش" presets={CANCEL_REASONS} danger okText="لغو سفارش" loading={busy === 'dlg'} onClose={() => setDialog(null)} onOk={submitDialog} />
      <DiscountModal open={dialog?.kind === 'discount'} order={order} line={dialog?.kind === 'discount' ? dialog.line : null} loading={busy === 'dlg'} onClose={() => setDialog(null)} onOk={submitDialog} />
      <TransferModal open={dialog?.kind === 'transfer'} floor={floor} current={order} onClose={() => setDialog(null)} onOk={submitDialog} />
      <MergeModal open={dialog?.kind === 'merge'} orders={openOrders} current={order} onClose={() => setDialog(null)} onOk={submitDialog} />
      <SplitModal open={dialog?.kind === 'split'} order={order} loading={busy === 'dlg'} onClose={() => setDialog(null)} onOk={submitDialog} />
      <OrderInfoModal open={dialog?.kind === 'info'} title="مشخصات سفارش" type={active?.type} waiters={waiters} loading={busy === 'dlg'}
        initial={active ? { guests: active.guests, waiter_id: active.waiter_id, customer_name: active.customer_name, customer_phone: active.customer_phone, customer_address: active.customer_address, note: active.note } : {}}
        onClose={() => setDialog(null)} onOk={submitDialog} />
      <OrderInfoModal open={dialog?.kind === 'newcustomer'} title={dialog?.type === 'delivery' ? '🛵 سفارش پیک جدید' : '🛍️ سفارش بیرون‌بر جدید'} type={dialog?.type}
        initial={{}} onClose={() => setDialog(null)} onOk={submitDialog} />
      <ShiftOpenModal open={dialog?.kind === 'shift'} loading={busy === 'dlg'} onClose={() => setDialog(null)} onOk={submitDialog} />
      <DeviceRegisterModal open={!!askRegister} registers={registers} onDone={() => { setRegBad(false); loadShift() }} />
      <LineNoteModal line={dialog?.kind === 'note' ? dialog.line : null} onClose={() => setDialog(null)} onOk={submitDialog} />
      <Modal open={dialog?.kind === 'paid'} footer={null} onCancel={() => { setDialog(null); reset() }} centered width={420}>
        {dialog?.kind === 'paid' && (
          <Result status="success" title="پرداخت با موفقیت ثبت شد" subTitle={`سفارش #${num(dialog.order.number)} · ${money(dialog.order.total)} تومان`}
            extra={[
              <Button key="p" type="primary" size="large" onClick={() => { printReceipt(dialog.order, auth.settings, 'receipt'); setDialog(null); reset() }}>چاپ رسید</Button>,
              <Button key="c" size="large" onClick={() => { setDialog(null); reset() }}>بدون چاپ</Button>,
            ]}>
            {dialog.order.payments.some((p) => p.change > 0) && (
              <div className="change-box" style={{ textAlign: 'center' }}>باقیمانده به مشتری: <b>{money(dialog.order.payments.reduce((a, p) => a + p.change, 0))}</b> تومان</div>
            )}
          </Result>
        )}
      </Modal>
    </div>
  )
}
