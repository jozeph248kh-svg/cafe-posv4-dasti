import { describe, expect, it, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import { App } from 'antd'
import userEvent from '@testing-library/user-event'

// The order panel is the running bill the cashier reads out to the customer. Its totals line is the
// last place a wrong number can hide, so the tests below build an order with every kind of money on
// it (item discount, bill discount, service, tax, an already-paid part, not-yet-saved lines) and
// check the grand total the customer is told.
vi.mock('../../core/api', () => ({ get: vi.fn(() => Promise.resolve([])), put: vi.fn(() => Promise.resolve({})) }))

const { default: OrderPanel, isFeeLine } = await import('./OrderPanel')

const noop = () => {}
const auth = { can: () => true, hasModule: () => false }
const line = (over) => ({
  id: 1, menu_item_id: 1, station_id: 1, name: 'اسپرسو', unit_price: 140_000, qty: 2, total: 280_000,
  status: 'pending', modifiers: [], note: null, discount_amount: 0, ...over,
})
const baseOrder = {
  id: 9, number: 42, type: 'dine_in', status: 'open', table_name: 'میز ۳', guests: 2,
  subtotal: 370_000, discount_amount: 0, line_discount_amount: 0, service_amount: 0, tax_amount: 0,
  total: 370_000, paid_amount: 0, remaining: 370_000, created_at: new Date().toISOString(),
  lines: [line({}), line({ id: 2, name: 'کیک', unit_price: 90_000, qty: 1, total: 90_000, status: 'sent' })],
}
const panel = (props = {}) => render(
  <App>
    <OrderPanel order={baseOrder} draft={null} newLines={[]} busy={null} auth={auth}
      onClose={noop} onLine={noop} onSave={noop} onPay={noop} onBill={noop} onAction={noop}
      onEditInfo={noop} onRefresh={noop} {...props} />
  </App>,
)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('OrderPanel', () => {
  it('asks for a table when nothing is selected', () => {
    render(<OrderPanel order={null} draft={null} newLines={[]} auth={auth} onClose={noop} />)
    expect(screen.getByText('یک میز یا سفارش را انتخاب کنید')).toBeTruthy()
  })

  it('shows the subtotal when there is no discount, service or tax', () => {
    panel()
    expect(text()).toContain('جمع اقلام')
    expect(text()).toContain('۳۷۰٬۰۰۰')          // the server's subtotal, shown as-is
  })

  it('shows every money row and a grand total that adds up', () => {
    const order = {
      ...baseOrder,
      subtotal: 370_000,
      line_discount_amount: 20_000,
      discount_amount: 50_000,                  // 20,000 on items + 30,000 on the bill
      service_amount: 32_000,
      tax_amount: 31_680,
      total: 383_680,
    }
    panel({ order })
    expect(text()).toContain('تخفیف اقلام')
    expect(text()).toContain('−۲۰٬۰۰۰')
    expect(text()).toContain('تخفیف فاکتور')
    expect(text()).toContain('−۳۰٬۰۰۰')          // only the bill part, not the total discount
    expect(text()).toContain('حق سرویس')
    expect(text()).toContain('مالیات')
    expect(text()).toContain('۳۸۳٬۶۸۰')
  })

  it('labels the grand total "remaining" once part of the bill is paid', () => {
    const order = { ...baseOrder, subtotal: 370_000, total: 370_000, paid_amount: 100_000, remaining: 270_000 }
    panel({ order })
    expect(text()).toContain('مانده')
    expect(text()).toContain('۲۷۰٬۰۰۰')
  })

  it('adds not-yet-saved lines on top of the saved total', () => {
    const local = [
      { key: 1, menu_item_id: 3, name: 'آمریکانو', unit_price: 160_000, qty: 1, modifiers: [] },
      { key: 2, menu_item_id: 3, name: 'آمریکانو', unit_price: 160_000, qty: 2, modifiers: [] },
    ]
    panel({ newLines: local })
    expect(text()).toContain('آیتم‌های جدید (ثبت‌نشده)')
    expect(text()).toContain('+۴۸۰٬۰۰۰')
    expect(text()).toContain('۸۵۰٬۰۰۰')           // 370,000 saved + 480,000 unsaved
  })

  it('hides voided lines but keeps them in a folded section', () => {
    const order = { ...baseOrder, lines: [...baseOrder.lines, line({ id: 3, name: 'قهوه حذف‌شده', status: 'void' })] }
    panel({ order })
    expect(text()).toContain('۱ آیتم حذف‌شده')
  })

  it('offers the send/pay buttons and counts what is still unsent', () => {
    panel()
    expect(screen.getByRole('button', { name: /ارسال به آشپزخانه/ }).textContent).toContain('۱')
    expect(screen.getByRole('button', { name: /پرداخت/ })).toBeTruthy()
  })

  it('hides the payment button for a user who may not take payments', () => {
    panel({ auth: { can: () => false, hasModule: () => false } })
    expect(screen.queryByRole('button', { name: /پرداخت/ })).toBeNull()
  })

  it('edits a saved line through the callbacks the page gives it', async () => {
    const onLine = vi.fn()
    panel({ onLine })
    const plus = screen.getAllByRole('button').find((b) => b.querySelector('[data-icon="plus"]'))
    await userEvent.click(plus)
    expect(onLine).toHaveBeenCalledWith('server-qty', expect.objectContaining({ id: 1 }), 3)
  })

  it('recognises delivery fee lines (they are money, not kitchen items)', () => {
    expect(isFeeLine({ station_id: null, name: 'هزینه ارسال (منطقه ۱)' })).toBe(true)
    expect(isFeeLine({ station_id: 2, name: 'هزینه ارسال (منطقه ۱)' })).toBe(false)
    expect(isFeeLine({ station_id: null, name: 'اسپرسو' })).toBe(false)
  })
})
