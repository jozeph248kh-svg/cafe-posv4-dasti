import { describe, expect, it, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

// The floor screen is what a waiter looks at all day: free tables, who is sitting where, how long
// they have been waiting, and whether a bill was printed. Getting a status wrong sends a waiter to
// an occupied table. The API and the realtime socket are stubbed; the component is the real one.
// mutable so a single test can change the business settings (the dwell target comes from them)
const AUTH = { hasModule: () => false, can: () => true, settings: {} }
vi.mock('../../core/auth', () => ({
  useAuth: () => AUTH,
}))
vi.mock('../../core/realtime', () => ({
  useRealtime: () => {},
  useWsStatus: () => 'online',
  subscribe: () => () => {},
  startRealtime: () => {},
  stopRealtime: () => {},
  beep: () => {},
}))
vi.mock('../../core/api', () => ({
  get: vi.fn(() => Promise.resolve({})),
  api: vi.fn(() => Promise.resolve({})),
}))

const { default: FloorView, sittingProgress, DEFAULT_WARN_MINUTES, DEFAULT_LIMIT_MINUTES } = await import('./FloorView')

const table = (over) => ({
  id: 1, name: '۱', x: 0, y: 0, shape: 'square', seats: 4, status: 'free',
  guests: 0, total: 0, minutes: 0, idle_minutes: 0, waiter: null, ready: 0, pending: 0, ...over,
})
const floor = [
  {
    id: 10, name: 'سالن اصلی', tables: [
      table({ id: 1, name: 'میز ۱', seats: 4 }),
      table({ id: 2, name: 'میز ۲', status: 'occupied', guests: 3, total: 254_000, minutes: 42, idle_minutes: 42, waiter: 'علی' }),
    ],
  },
  {
    id: 20, name: 'تراس', tables: [
      table({ id: 3, name: 'تراس ۱', status: 'billing', guests: 2, total: 96_000, minutes: 75, waiter: 'مریم', ready: 1 }),
    ],
  },
]

describe('sittingProgress', () => {
  it('is green (ok) below the warning time and empty at 0 minutes', () => {
    expect(sittingProgress(0, 60, 90)).toMatchObject({ pct: 0, level: 'ok', over: 0 })
    expect(sittingProgress(59, 60, 90)).toMatchObject({ level: 'ok' })
  })

  it('turns amber exactly at the warning time and red at the sitting limit', () => {
    expect(sittingProgress(60, 60, 90).level).toBe('warn')
    expect(sittingProgress(89, 60, 90).level).toBe('warn')
    expect(sittingProgress(90, 60, 90).level).toBe('late')
  })

  it('counts the overtime minutes past the limit and never overfills the bar', () => {
    expect(sittingProgress(120, 60, 90)).toMatchObject({ pct: 100, level: 'late', over: 30 })
  })

  it('clamps a warn value that a manager saved above the limit', () => {
    // 120 warn / 90 limit must not produce a tile that can never turn amber
    const p = sittingProgress(95, 120, 90)
    expect(p.warn).toBe(90)
    expect(p.level).toBe('late')
  })

  it('never divides by zero or renders a negative bar', () => {
    expect(sittingProgress(30, 0, 0).limit).toBe(DEFAULT_LIMIT_MINUTES)
    expect(sittingProgress(30, 0, 0).warn).toBe(DEFAULT_WARN_MINUTES)
    expect(sittingProgress(-5, 60, 90).pct).toBe(0)
    expect(sittingProgress(undefined, 60, 90).pct).toBe(0)
  })

  it('puts the amber tick on the bar where the warning starts', () => {
    expect(sittingProgress(0, 45, 90).warnPct).toBe(50)
  })
})

describe('FloorView', () => {
  it('shows a spinner until the floor arrives', () => {
    const { container } = render(<FloorView floor={null} loading onTable={() => {}} />)
    expect(container.querySelector('.ant-spin')).toBeTruthy()
  })

  it('counts free and busy tables across ALL areas, not just the visible one', () => {
    render(<FloorView floor={floor} onTable={() => {}} />)
    // 3 tables in total: one free, one occupied, one billing → 2 busy, 1 free
    expect(document.body.textContent.replace(/\s+/g, ' ')).toContain('۲ مشغول · ۱ آزاد')
  })

  it('marks an occupied table with its bill, waiter and seated time', () => {
    render(<FloorView floor={floor} onTable={() => {}} />)
    expect(screen.getByText('میز ۲')).toBeTruthy()
    expect(screen.getByText('۲۵۴٬۰۰۰')).toBeTruthy()
    expect(screen.getByText('علی')).toBeTruthy()
    expect(screen.getByText(/۴۲/)).toBeTruthy()
  })

  it('flags a table waiting 30+ minutes', () => {
    const { container } = render(<FloorView floor={floor} onTable={() => {}} />)
    expect(container.querySelector('.table-card.waiting')).toBeTruthy()   // 42 minutes
  })

  it('shows "bill printed" and ready items for a billing table after switching area', async () => {
    render(<FloorView floor={floor} onTable={() => {}} />)
    await userEvent.click(screen.getByText(/تراس/))
    expect(screen.getByText('صورتحساب چاپ شد')).toBeTruthy()
    expect(screen.getByText(/۱ آماده/)).toBeTruthy()
  })

  it('remembers the chosen area on the device', async () => {
    render(<FloorView floor={floor} onTable={() => {}} />)
    await userEvent.click(screen.getByText(/تراس/))
    expect(localStorage.getItem('pos_area')).toBe('20')
  })

  it('names the status in words on the tile, not only with a colour', () => {
    const { container } = render(<FloorView floor={floor} onTable={() => {}} />)
    const pill = container.querySelector('.table-card.occupied .tc-pill')
    expect(pill.textContent).toBe('مشغول')
    expect(container.querySelector('.table-card.free .tc-pill').textContent).toBe('آزاد')
  })

  it('invites the waiter to start an order on a free table and labels the tile for screen readers', () => {
    render(<FloorView floor={floor} onTable={() => {}} />)
    expect(screen.getByText('شروع سفارش')).toBeTruthy()
    expect(screen.getByRole('button', { name: 'میز ۱ — آزاد' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'میز ۲ — مشغول' })).toBeTruthy()
  })

  it('shows the sitting minutes and a bar against the sitting limit', () => {
    const { container } = render(<FloorView floor={floor} onTable={() => {}} />)
    const bar = container.querySelector('.table-card.occupied .tc-bar')
    expect(bar).toBeTruthy()
    expect(bar.className).toContain('ok')                       // 42 of 90 minutes, warning at 60
    expect(bar.querySelector('i').style.width).toBe('47%')
    expect(bar.getAttribute('aria-valuenow')).toBe('42')
    expect(bar.getAttribute('aria-valuemax')).toBe('90')
    expect(container.querySelector('.table-card.occupied .tc-clock').textContent).toContain('۴۲')
  })

  it('colours the sitting time and prints the overtime on a table that passed its limit', () => {
    const late = [{ id: 10, name: 'سالن', tables: [table({ id: 5, name: 'میز ۵', status: 'occupied', guests: 2, total: 100000, minutes: 120, idle_minutes: 5, waiter: 'علی' })] }]
    const { container } = render(<FloorView floor={late} onTable={() => {}} />)
    expect(container.querySelector('.tc-bar.late')).toBeTruthy()
    const clock = container.querySelector('.tc-clock.late')
    expect(clock).toBeTruthy()
    expect(clock.textContent).toContain('۱۲۰')
    expect(clock.querySelector('.tc-over').textContent).toBe('+۳۰')     // 30 minutes over the 90 limit
  })

  it('turns amber between the warning time and the limit', () => {
    const warn = [{ id: 10, name: 'سالن', tables: [table({ id: 6, name: 'میز ۶', status: 'occupied', guests: 2, total: 100000, minutes: 70, idle_minutes: 5, waiter: 'علی' })] }]
    const { container } = render(<FloorView floor={warn} onTable={() => {}} />)
    expect(container.querySelector('.tc-clock.warn')).toBeTruthy()
    expect(container.querySelector('.tc-bar.warn')).toBeTruthy()
  })

  it('follows the two business settings for warning and limit', () => {
    AUTH.settings = { 'pos.table_warn_minutes': 30, 'pos.table_limit_minutes': 60 }
    try {
      const { container } = render(<FloorView floor={floor} onTable={() => {}} />)   // table 2 sits 42 min
      const bar = container.querySelector('.table-card.occupied .tc-bar')
      expect(bar.getAttribute('aria-valuemax')).toBe('60')
      expect(bar.querySelector('i').style.width).toBe('70%')
      expect(bar.className).toContain('warn')
      expect(container.querySelector('.tc-clock.warn')).toBeTruthy()
    } finally {
      AUTH.settings = {}
    }
  })

  it('still understands an installation that only has the old single target key', () => {
    AUTH.settings = { 'pos.table_target_minutes': 90 }
    try {
      const { container } = render(<FloorView floor={floor} onTable={() => {}} />)
      const bar = container.querySelector('.table-card.occupied .tc-bar')
      expect(bar.getAttribute('aria-valuemax')).toBe('90')     // limit = old target
      expect(bar.className).toContain('ok')                    // warn = 2/3 of it = 60 → 42 is still ok
    } finally {
      AUTH.settings = {}
    }
  })

  it('opens the table the waiter taps', async () => {
    const onTable = vi.fn()
    render(<FloorView floor={floor} onTable={onTable} />)
    await userEvent.click(screen.getByText('میز ۱'))
    expect(onTable).toHaveBeenCalledWith(expect.objectContaining({ id: 1 }))
  })
})
