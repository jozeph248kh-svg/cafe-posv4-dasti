import { describe, expect, it, vi, beforeEach } from 'vitest'
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

/**
 * The two panels the cashier touches for every single line: the menu picker (search by name/code,
 * Enter-to-add) and the modifier dialog (required choices, quantity, quick notes, price delta).
 * Both compute the price that ends up on the bill, so both are pinned here.
 */
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

const { default: MenuPicker } = await import('./MenuPicker')
const { default: ModifierModal } = await import('./ModifierModal')

const MENU = {
  categories: [{ id: 1, name: 'قهوه گرم', is_active: true }, { id: 2, name: 'کیک', is_active: true }, { id: 3, name: 'قدیمی', is_active: false }],
  items: [
    { id: 11, name: 'اسپرسو', code: '101', category_id: 1, price: 140_000, is_active: true, is_available: true, modifier_group_ids: [] },
    { id: 12, name: 'آمریکانو', code: '102', category_id: 1, price: 160_000, is_active: true, is_available: true, modifier_group_ids: [7] },
    { id: 13, name: 'چیزکیک', code: '201', category_id: 2, price: 190_000, is_active: true, is_available: true, modifier_group_ids: [] },
    { id: 14, name: 'ناموجود', code: '103', category_id: 1, price: 150_000, is_active: true, is_available: false, modifier_group_ids: [] },
    { id: 15, name: 'غیرفعال', code: '301', category_id: 2, price: 100_000, is_active: false, is_available: true, modifier_group_ids: [] },
  ],
}
const GROUPS = {
  7: {
    id: 7, name: 'سایز', min_select: 1, max_select: 1,
    options: [
      { id: 71, name: 'کوچک', price_delta: 0, is_default: true, is_available: true },
      { id: 72, name: 'بزرگ', price_delta: 20_000, is_default: false, is_available: true },
    ],
  },
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('MenuPicker', () => {
  beforeEach(() => get.mockReset())

  it('lists only active items in active categories', async () => {
    render(<App><MenuPicker menu={MENU} onPick={() => {}} /></App>)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('چیزکیک')
    expect(text()).not.toContain('غیرفعال')
  })

  it('filters by category when one is chosen', async () => {
    render(<App><MenuPicker menu={MENU} onPick={() => {}} /></App>)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    fireEvent.click(screen.getAllByText(/کیک/)[0])   // the category chip, not the item name
    await waitFor(() => expect(text()).toContain('چیزکیک'))
    expect(text()).not.toContain('آمریکانو')
  })

  it('adds the exact match on Enter (by code) even when several items are listed', async () => {
    const onPick = vi.fn()
    render(<App><MenuPicker menu={MENU} onPick={onPick} /></App>)
    const input = screen.getByPlaceholderText(/جستجوی نام یا کد آیتم/)
    fireEvent.change(input, { target: { value: '102' } })
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter', keyCode: 13 })
    await waitFor(() => expect(onPick).toHaveBeenCalledWith(expect.objectContaining({ id: 12 })))
  })

  it('does not add an unavailable item', async () => {
    const onPick = vi.fn()
    render(<App><MenuPicker menu={MENU} onPick={onPick} /></App>)
    const input = screen.getByPlaceholderText(/جستجوی نام یا کد آیتم/)
    fireEvent.change(input, { target: { value: '103' } })
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter', keyCode: 13 })
    await waitFor(() => expect(onPick).not.toHaveBeenCalled())
  })
})

describe('ModifierModal', () => {
  const item = { id: 12, name: 'آمریکانو', price: 160_000, modifier_group_ids: [7] }

  it('preselects the default option and shows the base price', () => {
    render(<App><ModifierModal item={item} groups={GROUPS} onClose={() => {}} onAdd={() => {}} /></App>)
    expect(text()).toContain('آمریکانو')
    expect(text()).toContain('۱۶۰٬۰۰۰')
    expect(text()).toContain('کوچک')
  })

  it('adds the price delta of the chosen option and sends the line', async () => {
    const onAdd = vi.fn()
    render(<App><ModifierModal item={item} groups={GROUPS} onClose={() => {}} onAdd={onAdd} /></App>)
    fireEvent.click(screen.getByText(/بزرگ/))
    await waitFor(() => expect(text()).toContain('۱۸۰٬۰۰۰'))
    fireEvent.click(screen.getByRole('button', { name: /افزودن|اضافه/ }))
    await waitFor(() => expect(onAdd).toHaveBeenCalled())
    const line = onAdd.mock.calls[0][0]
    expect(line.unit_price).toBe(180_000)
    expect(line.modifier_option_ids).toEqual([72])
    expect(line.modifiers[0]).toMatchObject({ name: 'بزرگ', price: 20_000, group: 'سایز' })
  })

  it('increases the quantity and keeps a free-text note', async () => {
    const onAdd = vi.fn()
    render(<App><ModifierModal item={item} groups={GROUPS} onClose={() => {}} onAdd={onAdd} /></App>)
    const plus = [...document.querySelectorAll('button')].find((b) => b.querySelector('[data-icon="plus"]'))
    if (plus) fireEvent.click(plus)
    const noteInput = document.querySelector('.ant-modal textarea, .ant-modal input[type="text"]')
    if (noteInput) fireEvent.change(noteInput, { target: { value: 'بدون شکر' } })
    fireEvent.click(screen.getByRole('button', { name: /افزودن|اضافه/ }))
    await waitFor(() => expect(onAdd).toHaveBeenCalled())
    const line = onAdd.mock.calls[0][0]
    expect(line.qty).toBeGreaterThanOrEqual(1)
    expect(line).toHaveProperty('note')
  })

  it('renders nothing without an item', () => {
    const { container } = render(<App><ModifierModal item={null} groups={GROUPS} onClose={() => {}} onAdd={() => {}} /></App>)
    expect(container.textContent).toBe('')
  })
})

describe('MenuPicker · the category strip is reachable with a mouse', () => {
  const manyCats = () => ({
    categories: Array.from({ length: 9 }, (_, i) => ({ id: i + 1, name: `دسته ${i + 1}`, is_active: true, color: '#6366f1' })),
    items: Array.from({ length: 9 }, (_, i) => ({ id: i + 1, name: `آیتم ${i + 1}`, category_id: i + 1, is_active: true, is_available: true, price: 100_000 })),
  })

  const overflow = (strip, width = 1400, view = 600, pos = 0) => {
    // jsdom reports 0 for every layout number, so give the row a real overflow to measure
    Object.defineProperty(strip, 'scrollWidth', { value: width, configurable: true })
    Object.defineProperty(strip, 'clientWidth', { value: view, configurable: true })
    Object.defineProperty(strip, 'scrollLeft', { value: pos, configurable: true, writable: true })
    Object.defineProperty(strip, 'scrollBy', { value: vi.fn(), configurable: true })
  }

  beforeEach(() => { document.documentElement.dir = 'rtl' })      // the app is Persian/RTL

  it('shows an arrow on the side where chips are hidden and scrolls towards them', async () => {
    const { container } = render(<MenuPicker menu={manyCats()} onPick={() => {}} />)
    const strip = container.querySelector('.mp-cats')
    overflow(strip)                                    // 1400 wide in a 600 box, at the RTL start (right edge)
    act(() => { fireEvent.scroll(strip) })
    const left = container.querySelector('.mp-arrow.end')          // hidden chips are to the left in RTL
    expect(left).toBeTruthy()
    expect(container.querySelector('.mp-arrow.start')).toBeNull()  // nothing hidden on the right yet
    await userEvent.click(left)
    expect(strip.scrollBy).toHaveBeenCalled()
    expect(strip.scrollBy.mock.calls[0][0].left).toBeLessThan(0)   // moves towards the hidden categories
  })

  it('shows the opposite arrow once the row has been scrolled', () => {
    const { container } = render(<MenuPicker menu={manyCats()} onPick={() => {}} />)
    const strip = container.querySelector('.mp-cats')
    overflow(strip, 1400, 600, -800)                   // scrolled all the way to the end
    act(() => { fireEvent.scroll(strip) })
    expect(container.querySelector('.mp-arrow.start')).toBeTruthy()
    expect(container.querySelector('.mp-arrow.end')).toBeNull()
  })

  it('shows no arrow when every category fits', () => {
    const { container } = render(<MenuPicker menu={manyCats()} onPick={() => {}} />)
    const strip = container.querySelector('.mp-cats')
    overflow(strip, 500, 500)
    act(() => { fireEvent.scroll(strip) })
    expect(container.querySelectorAll('.mp-arrow').length).toBe(0)
  })

  it('a vertical mouse wheel over the strip scrolls it sideways instead of the page', () => {
    const { container } = render(<MenuPicker menu={manyCats()} onPick={() => {}} />)
    const strip = container.querySelector('.mp-cats')
    overflow(strip, 1400, 600, 0)
    const ev = new WheelEvent('wheel', { deltaY: 120, bubbles: true, cancelable: true })
    act(() => { strip.dispatchEvent(ev) })
    expect(ev.defaultPrevented).toBe(true)
    expect(strip.scrollBy).toHaveBeenCalled()
  })
})
