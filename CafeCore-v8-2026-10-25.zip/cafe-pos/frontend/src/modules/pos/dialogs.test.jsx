import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { App } from 'antd'

/**
 * The POS dialogs (pos/dialogs.jsx, 292 lines) — the manager-facing decisions taken at the counter:
 * a discount and its preview, a transfer, a merge, a bill split, a shift opening and a line note.
 * The discount preview is money the customer sees *before* it is applied, so it is pinned hardest.
 */
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

const {
  ReasonModal, DiscountModal, TransferModal, MergeModal, SplitModal, ShiftOpenModal, LineNoteModal, VOID_REASONS, CANCEL_REASONS,
} = await import('./dialogs')

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const ORDER = {
  id: 9, number: 42, subtotal: 370_000, line_discount_amount: 20_000, total: 383_680, remaining: 383_680,
  discount_type: null, discount_value: 0, lines: [
    { id: 1, name: 'اسپرسو', unit_price: 140_000, qty: 2, total: 280_000, status: 'served', modifiers: [] },
    { id: 2, name: 'چیزکیک', unit_price: 90_000, qty: 1, total: 90_000, status: 'served', modifiers: [] },
  ],
}
const LIMIT = { can_discount: true, can_manage: true, max_pct: 20, max_amount: null, max_daily: null, max_monthly: null, used_today: 0, used_month: 0, reason_required: true }
const PRESETS = [
  { id: 1, name: 'کارمندی', kind: 'percent', value: 20, scope: 'order', reason_required: true },
  { id: 2, name: 'جبران', kind: 'amount', value: 100_000, scope: 'order', max_amount: 60_000 },
  { id: 3, name: 'یکی بخر یکی ببر', kind: 'bogo', value: 100, scope: 'order', buy_qty: 2, get_qty: 1 },
]

const respond = () => get.mockImplementation((path) => {
  if (path === '/orders/discounts/presets') return Promise.resolve(PRESETS)
  if (path === '/orders/discounts/my-limit') return Promise.resolve(LIMIT)
  return Promise.resolve([])
})
const page = (ui) => render(<App>{ui}</App>)

describe('ReasonModal', () => {
  it('will not submit a reason shorter than two characters and offers the presets', () => {
    const onOk = vi.fn()
    page(<ReasonModal open title="دلیل حذف" presets={VOID_REASONS} onClose={() => {}} onOk={onOk} />)
    expect(text()).toContain(VOID_REASONS[0])
    const ok = [...document.querySelectorAll('button')].find((b) => b.textContent === 'تأیید')
    expect(ok.disabled).toBe(true)
    fireEvent.click(screen.getByText(VOID_REASONS[0]))
    const ok2 = [...document.querySelectorAll('button')].find((b) => b.textContent === 'تأیید')
    fireEvent.click(ok2)
    expect(onOk).toHaveBeenCalledWith(VOID_REASONS[0])
  })
})

describe('DiscountModal', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('previews a percentage discount on the bill after item discounts', async () => {
    page(<DiscountModal open order={ORDER} onClose={() => {}} onOk={() => {}} />)
    await waitFor(() => expect(text()).toContain('۱۰٪'))         // the default
    // base = 370,000 − 20,000 item discounts = 350,000 → 10% = 35,000
    expect(text()).toContain('۳۵٬۰۰۰')
  })

  it('stops the preview at a preset ceiling', async () => {
    page(<DiscountModal open order={ORDER} onClose={() => {}} onOk={() => {}} />)
    await waitFor(() => expect(text()).toContain('جبران'))
    fireEvent.click(screen.getByText('جبران'))
    // 100,000 asked, 60,000 ceiling → the preview must show 60,000
    await waitFor(() => expect(text()).toContain('۶۰٬۰۰۰'))
  })

  it('shows no money preview for a rule-based preset (the server computes it)', async () => {
    page(<DiscountModal open order={ORDER} onClose={() => {}} onOk={() => {}} />)
    await waitFor(() => expect(text()).toContain('یکی بخر'))
    fireEvent.click(screen.getByText('یکی بخر یکی ببر'))
    await waitFor(() => expect(document.body.textContent).toContain('یکی بخر'))
  })

  it('refuses to submit without a reason and says why', async () => {
    const onOk = vi.fn()
    page(<DiscountModal open order={ORDER} onClose={() => {}} onOk={onOk} />)
    await waitFor(() => expect(text()).toContain('کارمندی'))
    fireEvent.click(document.querySelector('.disc-apply'))   // the footer button, not the "اعمال کد" one
    // the dialog never disables the button silently: it prints what is missing
    await waitFor(() => expect(text()).toMatch(/دلیل|توضیح/))
    expect(onOk).not.toHaveBeenCalled()
  })

  it('warns when the discount is above the user’s own ceiling (manager PIN will be needed)', async () => {
    get.mockImplementation((path) => {
      if (path === '/orders/discounts/presets') return Promise.resolve(PRESETS)
      if (path === '/orders/discounts/my-limit') return Promise.resolve({ ...LIMIT, max_pct: 5 })
      return Promise.resolve([])
    })
    page(<DiscountModal open order={ORDER} onClose={() => {}} onOk={() => {}} />)
    await waitFor(() => expect(text()).toContain('۱۰٪'))
    expect(text()).toMatch(/مدیر|سقف/)
  })

  it('applies a discount on a single line using that line’s total', async () => {
    const onOk = vi.fn()
    page(<DiscountModal open order={ORDER} line={ORDER.lines[0]} onClose={() => {}} onOk={onOk} />)
    await waitFor(() => expect(text()).toContain('۱۰٪'))
    expect(text()).toContain('۲۸٬۰۰۰')          // 10% of 280,000 (the line, not the bill)
  })
})

describe('TransferModal', () => {
  const floor = [
    { id: 1, name: 'سالن', tables: [{ id: 1, name: '۱', seats: 4, status: 'free' }, { id: 2, name: '۲', seats: 2, status: 'occupied' }] },
    { id: 2, name: 'تراس', tables: [{ id: 3, name: '۳', seats: 6, status: 'free' }] },
  ]

  it('offers only free tables', () => {
    page(<TransferModal open floor={floor} current={{ table_name: '۹' }} onClose={() => {}} onOk={() => {}} />)
    expect(text()).toContain('سالن')
    expect(text()).toContain('تراس')
    const buttons = [...document.querySelectorAll('.pick-table')].map((b) => b.textContent)
    expect(buttons).toHaveLength(2)                // table 2 is occupied
    expect(buttons.join(' ')).not.toContain('۲ نفره')
  })

  it('says so when no table is free', () => {
    page(<TransferModal open floor={[{ id: 1, name: 'سالن', tables: [{ id: 2, name: '۲', seats: 2, status: 'occupied' }] }]} current={{}} onClose={() => {}} onOk={() => {}} />)
    expect(text()).toContain('میز آزادی وجود ندارد')
  })

  it('returns the chosen table id', () => {
    const onOk = vi.fn()
    page(<TransferModal open floor={floor} current={{}} onClose={() => {}} onOk={onOk} />)
    fireEvent.click([...document.querySelectorAll('.pick-table')][0])
    expect(onOk).toHaveBeenCalledWith(1)
  })
})

describe('MergeModal', () => {
  const orders = [
    { id: 9, number: 42, table_name: '۳', total: 370_000 },
    { id: 10, number: 43, table_name: null, customer_name: 'شیرین', total: 254_000 },
  ]

  it('lists the other open orders, never the current one', () => {
    page(<MergeModal open orders={orders} current={orders[0]} onClose={() => {}} onOk={() => {}} />)
    expect(text()).toContain('شیرین')
    expect(text()).toContain('۲۵۴٬۰۰۰')
    expect(document.querySelectorAll('.pick-table')).toHaveLength(1)
  })

  it('says so when there is nothing to merge with', () => {
    page(<MergeModal open orders={[orders[0]]} current={orders[0]} onClose={() => {}} onOk={() => {}} />)
    expect(text()).toContain('سفارش باز دیگری وجود ندارد')
  })
})

describe('SplitModal', () => {
  it('counts the moved amount and submits only the chosen quantities', async () => {
    const onOk = vi.fn()
    page(<SplitModal open order={ORDER} onClose={() => {}} onOk={onOk} />)
    const plus = [...document.querySelectorAll('.split-row button')].find((b) => b.querySelector('[data-icon="plus"]'))
    fireEvent.click(plus)                                 // one espresso → 140,000
    await waitFor(() => expect(text()).toContain('۱۴۰٬۰۰۰'))
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /ایجاد صورتحساب/.test(b.textContent)))
    expect(onOk).toHaveBeenCalledWith([{ line_id: 1, qty: 1 }])
  })

  it('cannot exceed the line quantity and ignores voided lines', () => {
    const withVoid = { ...ORDER, lines: [...ORDER.lines, { id: 3, name: 'حذف‌شده', unit_price: 50_000, qty: 1, status: 'void' }] }
    page(<SplitModal open order={withVoid} onClose={() => {}} onOk={() => {}} />)
    expect(text()).toContain('اسپرسو')
    expect(text()).not.toContain('حذف‌شده')
  })
})

describe('ShiftOpenModal and LineNoteModal', () => {
  it('asks for the opening cash', async () => {
    const onOk = vi.fn()
    page(<ShiftOpenModal open onClose={() => {}} onOk={onOk} />)
    const input = document.querySelector('.ant-modal input')
    fireEvent.change(input, { target: { value: '500000' } })
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /باز کردن|ثبت/.test(b.textContent)))
    await waitFor(() => expect(onOk).toHaveBeenCalled())
  })

  it('edits a line note', async () => {
    const onOk = vi.fn()
    page(<LineNoteModal line={{ name: 'اسپرسو', note: 'بدون شکر' }} onClose={() => {}} onOk={onOk} />)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    fireEvent.click(document.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(onOk).toHaveBeenCalled())
  })

  it('ships the reason presets the POS offers', () => {
    expect(VOID_REASONS.length).toBeGreaterThan(3)
    expect(CANCEL_REASONS.length).toBeGreaterThan(3)
  })
})
