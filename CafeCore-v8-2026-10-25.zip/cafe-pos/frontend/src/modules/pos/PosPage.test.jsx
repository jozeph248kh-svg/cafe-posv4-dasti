import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

/**
 * The till itself (PosPage, ~490 lines): it boots the menu, the floor and the shift, then turns
 * taps into orders. A full click-through needs the whole device stack, so this file pins the parts
 * that must never break silently: it loads, it degrades to the cached menu when the server is
 * unreachable, and the shift/register banner appears when it must.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class ApiError extends Error {}, setOverrideHandler: vi.fn(),
  getToken: () => 't', setToken: vi.fn(), isOffline: () => false, serverReachable: () => Promise.resolve(true),
}))
vi.mock('../../core/auth', () => ({
  useAuth: () => ({
    user: { id: 1, full_name: 'رضا', permissions: ['pos.access', 'payments.take'] },
    can: () => true, canAny: () => true, hasModule: () => true,
    settings: { 'business.name': 'کافه ونک', 'shift.hours': 8 }, system: {}, logout: vi.fn(),
  }),
}))
const realtime = { useRealtime: vi.fn(), useWsStatus: () => 'online', beep: vi.fn(), startRealtime: vi.fn(), stopRealtime: vi.fn() }
vi.mock('../../core/realtime', () => realtime)
// keep the real outbox module (it exposes a small observable queue) but never touch the network
vi.mock('../../core/outbox', async (orig) => {
  const actual = await orig()
  return { ...actual, startOutbox: vi.fn(), enqueue: vi.fn(), isOffline: () => false, serverReachable: () => Promise.resolve(true) }
})
vi.mock('../../core/register', () => ({ getRegisterId: () => 1, setRegisterId: vi.fn() }))
vi.mock('../../core/print', () => ({ printReceipt: vi.fn(), printHtml: vi.fn(), printShift: vi.fn() }))
vi.mock('react-router-dom', async (orig) => ({ ...(await orig()), useNavigate: () => vi.fn() }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: PosPage } = await import('./PosPage')

const MENU = {
  categories: [{ id: 1, name: 'قهوه گرم', icon: '☕', is_active: true }],
  items: [{ id: 11, name: 'اسپرسو', code: '101', category_id: 1, price: 140_000, is_active: true, is_available: true, modifier_group_ids: [] }],
  modifier_groups: [],
}
const FLOOR = [{ id: 1, name: 'سالن اصلی', tables: [{ id: 1, name: '۱', seats: 4, status: 'free', x: 0, y: 0, shape: 'square' }] }]
const SHIFT = {
  id: 12, status: 'open', register_id: 1, register_name: 'صندوق اصلی', opened_by: 'رضا', opened_at: '2026-10-23T09:00:00',
  opening_cash: 500_000, total_sales: 0, orders: 0, expected_cash: 500_000, blind: false, payments: { cash: 0, card: 0 }, movements: [],
}
const REGISTERS = [{ id: 1, name: 'صندوق اصلی', is_active: true }]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = (over = {}) => get.mockImplementation((path) => {
  if (path === '/menu/full') return Promise.resolve(over.menu ?? MENU)
  if (path === '/orders/floor') return Promise.resolve(over.floor ?? FLOOR)
  if (path === '/orders/active') return Promise.resolve([])
  if (path === '/shifts/current') return Promise.resolve(over.shift === undefined ? SHIFT : over.shift)
  if (path === '/shifts/registers') return Promise.resolve(REGISTERS)
  if (path === '/staff/users/basic') return Promise.resolve([{ id: 3, full_name: 'علی', role: 'waiter' }])
  if (path === '/public/calls') return Promise.resolve([])
  return Promise.resolve([])
})
const page = () => render(<MemoryRouter><App><PosPage /></App></MemoryRouter>)
// on a narrow jsdom viewport the till opens on the floor; the menu lives behind the "منو" tab
const openMenu = () => {
  const tab = [...document.querySelectorAll('.ant-segmented-item, button')].find((b) => b.textContent.trim() === 'منو')
  if (tab) fireEvent.click(tab)
}

describe('POS page', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond(); localStorage.clear(); realtime.useRealtime.mockClear() })

  it('loads the menu, the floor and the open shift on boot', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/menu/full'))
    expect(get).toHaveBeenCalledWith('/orders/floor')
    expect(get).toHaveBeenCalledWith('/shifts/current')
    await waitFor(() => expect(document.querySelector('.floor-wrap')).toBeTruthy())
  })

  it('paints the floor with its tables and the free/occupied legend', async () => {
    page()
    await waitFor(() => expect(document.querySelectorAll('.table-card').length).toBe(1))
    expect(text()).toContain('سالن اصلی')
    expect(text()).toContain('آزاد')
  })

  it('subscribes to the live topics that keep a second till in sync', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalled())
    const topics = realtime.useRealtime.mock.calls.map(([t]) => [].concat(t).join('|'))
    expect(topics.join(' ')).toContain('order.changed')
    expect(topics.join(' ')).toContain('kitchen.ready')
    expect(topics.join(' ')).toContain('service.call')
  })

  it('keeps working when the menu request fails (it falls back to the cached copy)', async () => {
    localStorage.setItem('cafe_menu_cache', JSON.stringify(MENU))
    const offline = Object.assign(new Error('offline'), { code: 'offline' })
    get.mockImplementation((path) => (path === '/menu/full' ? Promise.reject(offline) : Promise.resolve(path === '/shifts/registers' ? REGISTERS : [])))
    page()
    await waitFor(() => expect(document.querySelector('.floor-wrap')).toBeTruthy())
    expect(JSON.parse(localStorage.getItem('cafe_menu_cache')).items[0].name).toBe('اسپرسو')
  })

  it('renders when the shift is closed (it must still open the drawer first)', async () => {
    respond({ shift: null })
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/shifts/current'))
    await waitFor(() => expect(document.body.textContent.length).toBeGreaterThan(50))
  })

  it('renders the empty order panel hint before a table is chosen', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سالن اصلی'))
    expect(document.querySelector('.order-panel, .pos-menu, .floor-wrap')).toBeTruthy()
  })
})
