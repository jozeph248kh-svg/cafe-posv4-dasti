import {
  CloseOutlined, DeleteOutlined, DollarOutlined, EditOutlined, MinusOutlined, MoreOutlined, PercentageOutlined,
  PlusOutlined, PrinterOutlined, SendOutlined, StopOutlined, SwapOutlined, TeamOutlined, MergeCellsOutlined,
  ScissorOutlined, CheckOutlined, UserOutlined,
} from '@ant-design/icons'
import { App, Button, Dropdown, Empty, Select, Space, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { get, put } from '../../core/api'
import { LINE_STATUS, ORDER_TYPES, minutesSince, modText, money, num } from '../../core/format'

export const isFeeLine = (l) => !l.station_id && l.name?.startsWith('هزینه ارسال')

let zonesCache = null
/** Delivery zone + courier info for delivery orders (delivery module). */
function DeliveryBar({ order, onRefresh }) {
  const { message } = App.useApp()
  const [zones, setZones] = useState(zonesCache || [])
  const [d, setD] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => {
    if (!zonesCache) get('/delivery/zones').then((z) => { zonesCache = z.filter((x) => x.is_active); setZones(zonesCache) }).catch(() => {})
  }, [])
  useEffect(() => { get(`/delivery/orders/${order.id}`).then(setD).catch(() => {}) }, [order.id, order.subtotal])
  const pick = async (zone_id) => {
    setBusy(true)
    try { setD(await put(`/delivery/orders/${order.id}`, zone_id ? { zone_id } : { clear_zone: true })); await onRefresh?.() } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  const ST = { waiting: ['در انتظار پیک', 'default'], assigned: ['پیک تعیین شد', 'processing'], out: ['در مسیر', 'purple'], delivered: ['تحویل شد', 'green'], failed: ['ناموفق', 'red'] }
  return (
    <div className="op-delivery">
      <span>🛵</span>
      <Select size="small" placeholder="منطقه ارسال / هزینه پیک" value={d?.zone_id ?? undefined} loading={busy} allowClear onChange={(v) => pick(v)} style={{ flex: 1, minWidth: 0 }}
        options={zones.map((z) => ({ value: z.id, label: `${z.name} · ${money(z.customer_fee)}` }))} popupMatchSelectWidth={false} />
      {d && <Tag color={ST[d.status]?.[1]} style={{ margin: 0 }}>{ST[d.status]?.[0]}{d.courier ? ` · ${d.courier}` : ''}</Tag>}
    </div>
  )
}

function LineRow({ l, local, onInc, onDec, onRemove, onEdit, onVoid, onDiscount, canEdit }) {
  const st = LINE_STATUS[local ? 'pending' : l.status]
  const isVoid = l.status === 'void'
  return (
    <div className={`ol-row ${isVoid ? 'void' : ''} ${local ? 'local' : ''}`}>
      <div className="ol-main">
        <div className="ol-name">
          <span className="ol-qty">{num(l.qty)}×</span> {l.name}
          {!local && <Tag color={st.color} className="ol-tag">{st.label}</Tag>}
          {local && <Tag color="orange" className="ol-tag">جدید</Tag>}
        </div>
        {l.modifiers?.length > 0 && <div className="ol-mods">{modText(l.modifiers)}</div>}
        {l.note && <div className="ol-note">📝 {l.note}</div>}
        {isVoid && l.void_reason && <div className="ol-note">دلیل حذف: {l.void_reason}</div>}
        {!isVoid && l.discount_amount > 0 && <div className="ol-disc">{l.discount_auto ? '⚡ ' : '٪ '}تخفیف{l.discount_type === 'percent' ? ` ${num(l.discount_value)}٪` : ''}: −{money(l.discount_amount)}{l.discount_reason ? ` · ${l.discount_reason}` : ''}{l.discount_auto ? ' (خودکار)' : ''}</div>}
      </div>
      <div className="ol-side">
        <div className="ol-price">{!isVoid && l.discount_amount > 0 ? <><s>{money(l.unit_price * l.qty)}</s>{l.unit_price * l.qty - l.discount_amount > 0 ? money(l.unit_price * l.qty - l.discount_amount) : <span style={{ color: 'var(--green)' }}>رایگان</span>}</> : money(l.unit_price * l.qty)}</div>
        {canEdit && !isVoid && (
          (local || l.status === 'pending') ? (
            <Space size={2}>
              <Button size="small" type="text" icon={<PlusOutlined />} onClick={onInc} />
              <Button size="small" type="text" icon={l.qty > 1 ? <MinusOutlined /> : <DeleteOutlined />} danger={l.qty <= 1} onClick={l.qty > 1 ? onDec : onRemove} />
              {local && <Button size="small" type="text" icon={<EditOutlined />} onClick={onEdit} />}
              {!local && onDiscount && <Tooltip title="تخفیف این آیتم"><Button size="small" type="text" icon={<PercentageOutlined />} onClick={onDiscount} /></Tooltip>}
            </Space>
          ) : (
            <Space size={2}>
              {onDiscount && <Tooltip title="تخفیف این آیتم"><Button size="small" type="text" icon={<PercentageOutlined />} onClick={onDiscount} /></Tooltip>}
              <Tooltip title="حذف آیتم ارسال‌شده (نیاز به دلیل)"><Button size="small" type="text" danger icon={<StopOutlined />} onClick={onVoid} /></Tooltip>
            </Space>
          )
        )}
      </div>
    </div>
  )
}

export default function OrderPanel({
  order, draft, newLines, busy, auth, onClose, onLine, onSave, onPay, onBill, onAction, onEditInfo, onRefresh,
}) {
  const info = order || draft
  if (!info) {
    return <div className="order-panel empty"><Empty description="یک میز یا سفارش را انتخاب کنید" /></div>
  }
  const lines = order?.lines || []
  const visibleLines = lines.filter((l) => l.status !== 'void')
  const voided = lines.filter((l) => l.status === 'void')
  const newTotal = newLines.reduce((a, l) => a + l.unit_price * l.qty, 0)
  const pending = lines.filter((l) => l.status === 'pending').length + newLines.length
  const t = ORDER_TYPES[info.type]
  const isEmpty = !visibleLines.length && !newLines.length
  const canPay = auth.can('payments.take')
  const canMove = auth.can('orders.transfer')
  const hasReady = lines.some((l) => l.status === 'ready')

  const moreItems = order ? [
    { key: 'discount', icon: <PercentageOutlined />, label: 'تخفیف' },
    { key: 'info', icon: <UserOutlined />, label: 'ویرایش مشخصات / تعداد نفرات' },
    ...(canMove && info.type === 'dine_in' ? [{ key: 'transfer', icon: <SwapOutlined />, label: 'انتقال به میز دیگر' }] : []),
    ...(canMove ? [{ key: 'merge', icon: <MergeCellsOutlined />, label: 'ادغام با سفارش دیگر' }] : []),
    ...(canMove ? [{ key: 'split', icon: <ScissorOutlined />, label: 'تقسیم صورتحساب' }] : []),
    ...(hasReady ? [{ key: 'served', icon: <CheckOutlined />, label: 'ثبت سرو آیتم‌های آماده' }] : []),
    { type: 'divider' },
    { key: 'cancel', icon: <CloseOutlined />, label: 'لغو کل سفارش', danger: true },
  ] : []

  return (
    <div className="order-panel">
      <div className="op-head">
        <div>
          <div className="op-title">
            <span className="op-type">{t.icon}</span>
            {info.type === 'dine_in' ? `میز ${info.table_name}` : t.label}
            {order && <span className="op-num">#{num(order.number)}</span>}
          </div>
          <div className="op-sub">
            {info.type === 'dine_in' && <span><TeamOutlined /> {num(info.guests || 1)} نفر</span>}
            {info.customer_name && <span><UserOutlined /> {info.customer_name}</span>}
            {order?.waiter_name && <span>👤 {order.waiter_name}</span>}
            {order && <span>⏱ {num(minutesSince(order.created_at))} دقیقه</span>}
            {!order && <Tag color="orange">سفارش جدید</Tag>}
          </div>
        </div>
        <Space size={4}>
          {order && <Button type="text" icon={<EditOutlined />} onClick={onEditInfo} />}
          {order && <Dropdown menu={{ items: moreItems, onClick: ({ key }) => onAction(key) }} trigger={['click']}><Button icon={<MoreOutlined />} /></Dropdown>}
          <Button type="text" icon={<CloseOutlined />} onClick={onClose} />
        </Space>
      </div>

      {order && info.type === 'delivery' && auth.hasModule('delivery') && <DeliveryBar order={order} onRefresh={onRefresh} />}
      <div className="op-lines">
        {isEmpty && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="هنوز آیتمی اضافه نشده؛ از منو انتخاب کنید" style={{ marginTop: 40 }} />}
        {visibleLines.map((l) => (
          <LineRow key={l.id} l={l} canEdit={!isFeeLine(l)}
            onInc={() => onLine('server-qty', l, l.qty + 1)} onDec={() => onLine('server-qty', l, l.qty - 1)}
            onRemove={() => onLine('server-remove', l)} onVoid={() => onLine('void', l)} onDiscount={() => onLine('discount', l)} />
        ))}
        {newLines.map((l) => (
          <LineRow key={l.key} l={l} local canEdit
            onInc={() => onLine('local-qty', l, l.qty + 1)} onDec={() => onLine('local-qty', l, l.qty - 1)}
            onRemove={() => onLine('local-remove', l)} onEdit={() => onLine('local-edit', l)} />
        ))}
        {voided.length > 0 && (
          <details className="ol-voided"><summary>{num(voided.length)} آیتم حذف‌شده</summary>
            {voided.map((l) => <LineRow key={l.id} l={l} />)}
          </details>
        )}
      </div>

      <div className="op-totals">
        {order && <>
          <div className="row"><span>جمع اقلام</span><span>{money(order.subtotal)}</span></div>
          {order.line_discount_amount > 0 && <div className="row discount"><span>تخفیف اقلام</span><span>−{money(order.line_discount_amount)}</span></div>}
          {order.discount_amount - (order.line_discount_amount || 0) > 0 && (
            <Tooltip title={order.discount_reason}>
              <div className="row discount clickable" onClick={() => onAction('discount')}><span>{order.discount_auto ? '⚡ ' : ''}{order.discount_auto || order.discount_code || ['bogo', 'combo'].includes(order.discount_type)
                  ? (order.discount_reason || 'تخفیف') : 'تخفیف فاکتور'} {order.discount_type === 'percent' && `(${num(order.discount_value)}٪)`}{order.discount_code && <span className="ltr" style={{ fontSize: 11, opacity: 0.8 }}> {order.discount_code}</span>}</span><span>−{money(order.discount_amount - (order.line_discount_amount || 0))}</span></div>
            </Tooltip>
          )}
          {order.service_amount > 0 && <div className="row"><span>حق سرویس</span><span>{money(order.service_amount)}</span></div>}
          {order.tax_amount > 0 && <div className="row"><span>مالیات</span><span>{money(order.tax_amount)}</span></div>}
          {order.paid_amount > 0 && <div className="row paid"><span>پرداخت‌شده</span><span>{money(order.paid_amount)}</span></div>}
        </>}
        {newLines.length > 0 && <div className="row new"><span>آیتم‌های جدید (ثبت‌نشده)</span><span>+{money(newTotal)}</span></div>}
        <div className="row grand">
          <span>{order?.paid_amount ? 'مانده' : 'مبلغ کل'}</span>
          <span>{money((order ? (order.paid_amount ? order.remaining : order.total) : 0) + newTotal)} <small>تومان</small></span>
        </div>
      </div>

      <div className="op-actions">
        <Button size="large" icon={<SendOutlined />} disabled={!pending} loading={busy === 'send'} onClick={() => onSave(true)} className="btn-send">
          ارسال به آشپزخانه {pending > 0 && <span className="cnt">{num(pending)}</span>}
        </Button>
        <Space.Compact block>
          <Button size="large" icon={<PercentageOutlined />} disabled={isEmpty} onClick={() => onAction('discount')} style={{ flex: 0.9 }} className="btn-discount">تخفیف</Button>
          <Button size="large" icon={<PrinterOutlined />} disabled={isEmpty} loading={busy === 'bill'} onClick={onBill} style={{ flex: 1 }}>پیش‌فاکتور</Button>
          {canPay && <Button size="large" type="primary" icon={<DollarOutlined />} disabled={isEmpty} loading={busy === 'pay'} onClick={onPay} style={{ flex: 1.4 }} className="btn-pay">پرداخت</Button>}
        </Space.Compact>
        {newLines.length > 0 && <Typography.Link onClick={() => onSave(false)} style={{ textAlign: 'center', fontSize: 12 }}>ذخیره بدون ارسال</Typography.Link>}
      </div>
    </div>
  )
}
