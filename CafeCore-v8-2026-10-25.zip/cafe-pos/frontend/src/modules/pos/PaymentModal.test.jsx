import { describe, expect, it, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

// The payment dialog decides how much money leaves the customer's hand and what gets sent to the
// server. A number that is off by one rounding step here is a real cash difference at closing time.
// The auth context and the card-reader are stubbed; everything else is the real component.
vi.mock('../../core/auth', () => ({
  useAuth: () => ({ hasModule: () => false, can: () => true }),   // no loyalty, no card reader
}))
vi.mock('../cardreader/CardCharge', () => ({ default: () => null }))
vi.mock('../../core/api', () => ({ get: vi.fn(() => Promise.resolve(null)), newRequestId: () => 'req-1' }))

const { default: PaymentModal } = await import('./PaymentModal')

const order = { id: 7, number: 21, total: 254_000, paid_amount: 0, remaining: 254_000, customer_phone: null }
const render1 = (props = {}) => render(
  <PaymentModal order={order} open onClose={() => {}} onSubmit={() => {}} {...props} />,
)

describe('PaymentModal', () => {
  it('starts on the card method with the full remaining amount', () => {
    render1()
    expect(screen.getByText('مانده قابل پرداخت')).toBeTruthy()
    expect(screen.getByRole('button', { name: /ثبت پرداخت و بستن سفارش|ثبت پرداخت/ })).toBeTruthy()
  })

  it('sends one card payment for the whole remaining amount', async () => {
    const onSubmit = vi.fn()
    render1({ onSubmit })
    await userEvent.click(screen.getByRole('button', { name: /ثبت پرداخت/ }))
    expect(onSubmit).toHaveBeenCalledTimes(1)
    expect(onSubmit.mock.calls[0][0]).toEqual([{ method: 'card', amount: 254_000, tendered: undefined }])
  })

  it('splits into equal parts rounded UP to 1,000 toman, never under-collecting', async () => {
    render1()
    await userEvent.click(screen.getByRole('button', { name: '۳ نفره' }))
    // 254,000 / 3 = 84,666.6 → 85,000 per person (rounding down would leave the till short)
    expect(screen.getAllByText(/۱۶۹٬۰۰۰/).length).toBeGreaterThan(0)      // what is still owed
  })

  it('cash: tendering more than the amount shows the change and sends the tendered value', async () => {
    const onSubmit = vi.fn()
    render1({ onSubmit })
    await userEvent.click(screen.getByRole('button', { name: /نقد/ }))
    // quick-pick buttons are the amount plus the rounded-up notes above it (254,000 → 300,000)
    await userEvent.click(screen.getByRole('button', { name: '۳۰۰٬۰۰۰' }))
    expect(screen.getByText(/باقیمانده به مشتری/)).toBeTruthy()
    await userEvent.click(screen.getByRole('button', { name: /ثبت پرداخت/ }))
    const sent = onSubmit.mock.calls[0][0]
    expect(sent).toHaveLength(1)
    expect(sent[0]).toMatchObject({ method: 'cash', amount: 254_000 })
    expect(sent[0].tendered).toBeGreaterThan(254_000)     // the server computes the change from this
  })

  it('partial payment: adds an entry, then the rest can be taken with another method', async () => {
    const onSubmit = vi.fn()
    render1({ onSubmit })
    await userEvent.click(screen.getByRole('button', { name: '۲ نفره' }))     // 127,000
    await userEvent.click(screen.getByRole('button', { name: /افزودن این پرداخت/ }))
    await waitFor(() => expect(document.querySelectorAll('.pay-entry').length).toBe(1))
    await userEvent.click(screen.getByRole('button', { name: /ثبت پرداخت/ }))
    const sent = onSubmit.mock.calls[0][0]
    expect(sent.reduce((a, e) => a + e.amount, 0)).toBe(254_000)             // the whole bill, no more
  })

  it('a fully discounted bill (total 0) can be closed without a payment', async () => {
    // the reported bug: after a 100 % discount the submit button was disabled and the order stayed open forever
    const onSubmit = vi.fn()
    const comped = { id: 9, number: 33, total: 0, paid_amount: 0, remaining: 0, discount_amount: 254_000, customer_phone: null }
    render(<PaymentModal order={comped} open onClose={() => {}} onSubmit={onSubmit} />)
    expect(screen.getByText(/مبلغ این سفارش صفر است/)).toBeTruthy()
    const btn = screen.getByRole('button', { name: /بستن سفارش/ })
    expect(btn.disabled).toBe(false)
    await userEvent.click(btn)
    expect(onSubmit).toHaveBeenCalledTimes(1)
    expect(onSubmit.mock.calls[0][0]).toEqual([])          // the settle call: no payment rows
  })

  it('never sends more than the remaining amount', async () => {
    const onSubmit = vi.fn()
    const half = { ...order, paid_amount: 200_000, remaining: 54_000 }
    render(<PaymentModal order={half} open onClose={() => {}} onSubmit={onSubmit} />)
    await userEvent.click(screen.getByRole('button', { name: /ثبت پرداخت/ }))
    expect(onSubmit.mock.calls[0][0][0].amount).toBe(54_000)
  })
})
