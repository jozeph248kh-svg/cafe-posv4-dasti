import { CreditCardOutlined, DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import { Alert, App, Button, Divider, InputNumber, Modal, Space, Tag, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { get } from '../../core/api'
import { useAuth } from '../../core/auth'
import { PAY_METHODS, money, moneyFormatter, moneyParser, num } from '../../core/format'
import CardCharge from '../cardreader/CardCharge'
import { TierTag } from '../loyalty/AccountPanel'

const roundUp = (v, step) => Math.ceil(v / step) * step

export default function PaymentModal({ order, open, onClose, onSubmit, loading }) {
  const [method, setMethod] = useState('card')
  const [amount, setAmount] = useState(0)
  const [tendered, setTendered] = useState(null)
  const [entries, setEntries] = useState([])
  const [people, setPeople] = useState(1)
  const [acct, setAcct] = useState(null)
  const auth = useAuth()
  const loyalty = auth.hasModule('loyalty')
  const reader = auth.hasModule('cardreader')
  const [cc, setCc] = useState(false)
  const { modal } = App.useApp()

  const remaining = order?.remaining || 0
  const planned = entries.reduce((a, e) => a + e.amount, 0)
  const left = Math.max(remaining - planned, 0)

  useEffect(() => {
    if (open) { setEntries([]); setMethod('card'); setAmount(order?.remaining || 0); setTendered(null); setPeople(1) }
  }, [open, order?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { setAmount(left); setTendered(null) }, [left])

  useEffect(() => {
    setAcct(null)
    if (open && loyalty && order?.customer_phone) get(`/loyalty/by-phone/${encodeURIComponent(order.customer_phone)}`).then(setAcct).catch(() => {})
  }, [open, loyalty, order?.customer_phone])

  const walletPlanned = entries.filter((e) => e.method === 'wallet').reduce((a, e) => a + e.amount, 0)
  const walletAvail = Math.max((acct?.wallet || 0) - walletPlanned, 0)
  const pick = (k) => { setMethod(k); if (k === 'wallet') setAmount(Math.min(left, walletAvail)) }
  const methods = Object.entries(PAY_METHODS).filter(([k]) => k !== 'wallet' || loyalty)

  const cashOptions = useMemo(() => {
    const v = amount || 0
    return [...new Set([v, roundUp(v, 50_000), roundUp(v, 100_000), roundUp(v, 500_000), roundUp(v, 1_000_000)])].filter((x) => x >= v).slice(0, 4)
  }, [amount])

  if (!order) return null
  const change = method === 'cash' && tendered ? Math.max(tendered - amount, 0) : 0
  const addEntry = () => {
    if (!amount) return
    setEntries([...entries, { method, amount: Math.min(amount, left), tendered: method === 'cash' ? tendered || amount : undefined }])
  }
  const cardApproved = (tx) => {
    setCc(false)
    const list = [...entries, { method: 'card', amount: tx.amount, reference: tx.rrn, locked: true, card: tx.card }]
    setEntries(list)
    if (list.reduce((a, e) => a + e.amount, 0) >= remaining) onSubmit(list)
    else setAmount(remaining - list.reduce((a, e) => a + e.amount, 0))
  }
  const close = () => {
    if (!entries.some((e) => e.locked)) return onClose()
    modal.confirm({ title: 'پرداخت کارتخوان ثبت نشده است', content: 'مبلغی از کارت مشتری کسر شده ولی هنوز در سفارش ثبت نشده. بدون ثبت خارج می‌شوید؟ (در فهرست «تراکنش‌های تطبیق‌نشده» باقی می‌ماند)', okText: 'خروج', okType: 'danger', cancelText: 'بازگشت', onOk: onClose })
  }
  const submit = () => {
    const list = [...entries]
    if (left > 0 && amount > 0) list.push({ method, amount: Math.min(amount, left), tendered: method === 'cash' ? tendered || amount : undefined })
    if (!list.length) return
    onSubmit(list)
  }
  const finalLeft = left - (amount > 0 ? Math.min(amount, left) : 0)
  // a 100 % discount / comped bill: the total is 0, so there is nothing to pay — the bill only has to be closed.
  // (Before, the submit button stayed disabled here and the order could never be closed.)
  const nothingDue = (order.total || 0) === 0 && remaining <= 0

  return (
    <Modal open={open} onCancel={close} width={620} centered destroyOnClose title={`پرداخت سفارش #${num(order.number)}`}
      footer={nothingDue ? (
        <Button type="primary" size="large" block loading={loading} onClick={() => onSubmit([])}>
          بستن سفارش (بدون پرداخت)
        </Button>
      ) : (
        <Button type="primary" size="large" block loading={loading} disabled={!entries.length && !amount} onClick={submit}>
          {finalLeft <= 0 ? 'ثبت پرداخت و بستن سفارش' : `ثبت پرداخت · مانده ${money(finalLeft)}`}
        </Button>
      )}>
      <div className="pay-summary">
        <div><span>مبلغ کل</span><b>{money(order.total)}</b></div>
        {order.paid_amount > 0 && <div><span>پرداخت قبلی</span><b className="green">{money(order.paid_amount)}</b></div>}
        <div className="big"><span>مانده قابل پرداخت</span><b>{money(left)}</b></div>
      </div>

      {nothingDue && (
        <Alert type="info" showIcon style={{ marginBottom: 12 }}
          message="مبلغ این سفارش صفر است (تخفیف کامل) — پرداختی لازم نیست."
          description="با زدن دکمهٔ زیر سفارش بسته می‌شود، موجودی انبار بر اساس رسپی کسر می‌گردد و در گزارش‌ها به‌عنوان فروش با تخفیف کامل ثبت می‌شود." />
      )}

      {entries.length > 0 && (
        <div className="pay-entries">
          {entries.map((e, i) => (
            <div key={i} className="pay-entry">
              <span>{PAY_METHODS[e.method].icon} {PAY_METHODS[e.method].label}{e.locked && <Tag color="green" style={{ marginInlineStart: 6 }}>کارتخوان ✓ <span className="ltr">{e.reference}</span></Tag>}</span>
              <b>{money(e.amount)}</b>
              {!e.locked && <Button size="small" type="text" danger icon={<DeleteOutlined />} onClick={() => setEntries(entries.filter((_, j) => j !== i))} />}
            </div>
          ))}
        </div>
      )}

      {left > 0 && <>
        <div className="pay-methods">
          {methods.map(([k, m]) => (
            <button type="button" key={k} className={`pay-method ${method === k ? 'on' : ''}`} style={{ '--c': m.color }} onClick={() => pick(k)}
              disabled={k === 'wallet' && !walletAvail} title={k === 'wallet' && !walletAvail ? 'مشتری موجودی کیف پول ندارد یا شماره او ثبت نشده' : undefined}>
              <span className="pm-icon">{m.icon}</span>{m.label}{k === 'wallet' && walletAvail > 0 && <small style={{ display: 'block', fontSize: 11 }}>{money(walletAvail)}</small>}
            </button>
          ))}
        </div>
        {acct && (
          <div className="pay-wallet-info">
            <span>{acct.name} <TierTag tier={acct.tier} style={{ marginInlineStart: 4 }} /></span>
            <span>کیف پول: <b>{money(acct.wallet)}</b>{acct.debt > 0 && <> · بدهی نسیه: <b style={{ color: 'var(--red)' }}>{money(acct.debt)}</b></>}</span>
          </div>
        )}
        {method === 'wallet' && amount > walletAvail && <Alert type="error" showIcon message={`موجودی کیف پول کافی نیست (قابل استفاده: ${money(walletAvail)} تومان)`} style={{ marginBottom: 12 }} />}
        {method === 'credit' && acct && acct.credit_limit === 0 && <Alert type="error" showIcon message="فروش نسیه برای این مشتری مجاز نیست" style={{ marginBottom: 12 }} />}
        {method === 'credit' && acct && acct.effective_limit > 0 && acct.debt + amount > acct.effective_limit && (
          <Alert type="warning" showIcon message={`از سقف نسیه مشتری (${money(acct.effective_limit)}) بیشتر است؛ بدهی فعلی ${money(acct.debt)}`} style={{ marginBottom: 12 }} />
        )}
        {method === 'credit' && !order.customer_phone && (loyalty || !order.customer_name) && (
          <Alert type="warning" showIcon message={loyalty ? 'برای ثبت در حساب نسیه، شماره موبایل مشتری را در مشخصات سفارش وارد کنید' : 'برای فروش نسیه ابتدا نام یا شماره مشتری را در مشخصات سفارش ثبت کنید'} style={{ marginBottom: 12 }} />
        )}
        <Space direction="vertical" style={{ width: '100%' }} size={10}>
          <div className="pay-row">
            <span>مبلغ</span>
            <InputNumber size="large" value={amount} min={0} max={left} onChange={(v) => setAmount(v || 0)} formatter={moneyFormatter} parser={moneyParser} style={{ flex: 1 }} addonAfter="تومان" />
          </div>
          <div className="pay-row">
            <span>تقسیم</span>
            <Space wrap>
              {[2, 3, 4, 5].map((n) => <Button key={n} type={people === n ? 'primary' : 'default'} onClick={() => { setPeople(n); setAmount(Math.ceil(left / n / 1000) * 1000) }}>{num(n)} نفره</Button>)}
              <Button onClick={() => { setPeople(1); setAmount(left) }}>کل مبلغ</Button>
            </Space>
          </div>
          {method === 'card' && reader && amount > 0 && (
            <Button size="large" block className="cc-btn" icon={<CreditCardOutlined />} onClick={() => setCc(true)}>
              ارسال {money(Math.min(amount, left))} تومان به کارتخوان
            </Button>
          )}
          {method === 'cash' && (
            <>
              <div className="pay-row">
                <span>دریافتی</span>
                <Space wrap>{cashOptions.map((v) => <Button key={v} type={tendered === v ? 'primary' : 'default'} onClick={() => setTendered(v)}>{money(v)}</Button>)}</Space>
              </div>
              <div className="pay-row">
                <span />
                <InputNumber placeholder="مبلغ دریافتی از مشتری" value={tendered} min={0} onChange={setTendered} formatter={moneyFormatter} parser={moneyParser} style={{ flex: 1 }} />
              </div>
              {change > 0 && <div className="change-box">باقیمانده به مشتری: <b>{money(change)}</b> تومان</div>}
            </>
          )}
          {amount < left && amount > 0 && (
            <Button icon={<PlusOutlined />} block onClick={addEntry}>افزودن این پرداخت و تعیین روش برای مانده ({money(left - amount)})</Button>
          )}
        </Space>
      </>}
      <Divider style={{ margin: '16px 0 0' }} />
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>پس از تسویه کامل، سفارش بسته شده و موجودی انبار بر اساس رسپی کسر می‌شود.</Typography.Text>
      {reader && <CardCharge open={cc} amount={Math.min(amount, left)} orderId={order.id} onApproved={cardApproved} onClose={() => setCc(false)} />}
    </Modal>
  )
}
