import { ClockCircleOutlined, TeamOutlined } from '@ant-design/icons'
import { Badge, Segmented, Spin, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { get } from '../../core/api'
import { useAuth } from '../../core/auth'
import { compact, faTime, money, num } from '../../core/format'
import { useRealtime } from '../../core/realtime'

/** Upcoming reservations per table (reservations module) — refreshed every minute and on changes. */
function useUpcoming() {
  const auth = useAuth()
  const on = auth.hasModule('reservations')
  const [data, setData] = useState({})
  const load = () => on && get('/reservations/upcoming', { hours: 3 }).then(setData).catch(() => {})
  useEffect(() => { load(); const t = on && setInterval(load, 60000); return () => clearInterval(t) }, [on]) // eslint-disable-line react-hooks/exhaustive-deps
  useRealtime(['reservation.changed', 'floor.changed'], () => load())
  return data
}

export const TABLE_STATUS = {
  free: { label: 'آزاد', cls: 'free' },
  occupied: { label: 'مشغول', cls: 'occupied' },
  ready: { label: 'آماده سرو', cls: 'ready' },
  billing: { label: 'صورتحساب', cls: 'billing' },
}

// = settings defaults: «هشدار طولانی شدن نشستن» / «سقف مجاز نشستن» (تنظیمات ← صندوق و عملیات)
export const DEFAULT_WARN_MINUTES = 60
export const DEFAULT_LIMIT_MINUTES = 90

/**
 * How long a table has been seated, how full its bar is, and how worried the waiter should be.
 *
 * Both numbers are business decisions, so both are settings — not constants:
 *   pos.table_warn_minutes   from here the tile turns amber (still allowed)
 *   pos.table_limit_minutes  from here it turns red (over the sitting limit) and the overtime is printed
 * A manager can save a warn value that is not below the limit; that must never produce a tile that is red and
 * amber at once, so the warn threshold is clamped to the limit here (one predictable rule, no surprises).
 * Pure function on purpose: the boundaries are the only thing worth unit-testing on a tile.
 */
export function sittingProgress(minutes, warn = DEFAULT_WARN_MINUTES, limit = DEFAULT_LIMIT_MINUTES) {
  const lim = Number(limit) > 0 ? Number(limit) : DEFAULT_LIMIT_MINUTES
  const wrn = Math.min(Number(warn) > 0 ? Number(warn) : DEFAULT_WARN_MINUTES, lim)
  const m = Math.max(0, Math.round(Number(minutes) || 0))
  const pct = Math.min(100, Math.round((m / lim) * 100))
  const level = m >= lim ? 'late' : m >= wrn ? 'warn' : 'ok'
  return {
    pct,
    level,                       // ok | warn | late → the same three names the CSS uses
    minutes: m,
    warn: wrn,
    limit: lim,
    over: Math.max(0, m - lim),  // minutes past the sitting limit (0 while still inside it)
    warnPct: Math.round((wrn / lim) * 100),   // where the amber tick sits on the bar
  }
}

function TableCard({ t, onClick, compactMode, resv, sitting }) {
  const st = TABLE_STATUS[t.status] || TABLE_STATUS.free
  const waiting = t.status !== 'free' && t.idle_minutes >= 30
  const soon = resv && resv.minutes <= 60
  const sit = t.status !== 'free' ? sittingProgress(t.minutes, sitting.warn, sitting.limit) : null
  return (
    <button type="button" className={`table-card ${st.cls} ${t.shape} ${waiting ? 'waiting' : ''} ${soon && t.status === 'free' ? 'resv-soon' : ''}`} onClick={() => onClick(t)}
      aria-label={`${t.name} — ${st.label}`} title={`${t.name} — ${st.label}`}
      style={compactMode ? undefined : { gridColumn: t.x + 1, gridRow: t.y + 1 }}>
      <div className="tc-head">
        <span className="tc-name">{t.name}</span>
        <span className={`tc-pill ${st.cls}`}>{st.label}</span>
      </div>
      <div className="tc-tags">
        <span className="tc-seats"><TeamOutlined /> {num(t.status === 'free' ? t.seats : `${t.guests}`)}</span>
        {t.status !== 'free' && (
          <span className={`tc-clock ${sit.level}`} title={`نشستن: ${num(sit.minutes)} دقیقه · هشدار ${num(sit.warn)}′ · سقف ${num(sit.limit)}′`}>
            <ClockCircleOutlined /> {num(sit.minutes)}′{sit.over > 0 && <b className="tc-over">+{num(sit.over)}</b>}
          </span>
        )}
        {t.status !== 'free' && t.waiter && <span className="tc-waiter">{t.waiter}</span>}
      </div>
      {resv && (
        <div className={`tc-resv ${soon ? 'soon' : ''}`} title={`${resv.name} — ${num(resv.guests)} نفر`}>
          📅 رزرو {faTime(resv.start_at)}{resv.minutes < 0 ? ' (تأخیر)' : ''} · {resv.name}
        </div>
      )}
      {t.status === 'free' ? (
        <div className="tc-free"><span className="tc-plus" aria-hidden="true">＋</span> شروع سفارش</div>
      ) : (
        <>
          <div className="tc-total">{Math.abs(t.total) >= 1e7 ? compact(t.total) : money(t.total)}</div>
          <div className={`tc-bar ${sit.level}`} style={{ '--warn-at': `${sit.warnPct}%` }}
            title={`${num(sit.minutes)} از ${num(sit.limit)} دقیقهٔ مجاز`}
            role="progressbar" aria-valuemin={0} aria-valuemax={sit.limit} aria-valuenow={sit.minutes}
            aria-label={`مدت نشستن: ${num(sit.minutes)} از ${num(sit.limit)} دقیقه`}>
            <i style={{ width: `${sit.pct}%` }} />
          </div>
          <div className="tc-status">
            {t.ready > 0 && <Badge color="var(--green-raw)" text={`${num(t.ready)} آماده`} />}
            {t.pending > 0 && <Badge color="var(--amber-raw)" text={`${num(t.pending)} ثبت‌نشده`} />}
            {t.status === 'billing' && <Badge color="var(--amber-raw)" text="صورتحساب چاپ شد" />}
            {waiting && <Badge color="var(--red-raw)" text="منتظر" />}
          </div>
        </>
      )}
    </button>
  )
}

export default function FloorView({ floor, loading, onTable, mobile }) {
  const auth = useAuth()
  const settings = auth?.settings || {}
  // legacy: an installation that only has the old single key keeps working (warn = 2/3 of it)
  const legacy = Number(settings['pos.table_target_minutes']) || 0
  const sitting = {
    warn: Number(settings['pos.table_warn_minutes']) || (legacy ? Math.round(legacy * 2 / 3) : DEFAULT_WARN_MINUTES),
    limit: Number(settings['pos.table_limit_minutes']) || legacy || DEFAULT_LIMIT_MINUTES,
  }
  const [area, setArea] = useState(() => localStorage.getItem('pos_area'))
  useEffect(() => {
    if (floor?.length && !floor.some((a) => String(a.id) === String(area))) setArea(String(floor[0].id))
  }, [floor, area])
  const current = floor?.find((a) => String(a.id) === String(area))
  const upcoming = useUpcoming()
  const counts = useMemo(() => {
    const all = (floor || []).flatMap((a) => a.tables)
    return { free: all.filter((t) => t.status === 'free').length, busy: all.filter((t) => t.status !== 'free').length }
  }, [floor])

  if (!floor) return <div className="center-fill"><Spin size="large" /></div>
  const cols = Math.max(1, ...(current?.tables || []).map((t) => t.x + 1))
  return (
    <div className="floor-wrap">
      <div className="floor-bar">
        <Segmented value={String(area)} onChange={(v) => { setArea(v); localStorage.setItem('pos_area', v) }}
          options={floor.map((a) => ({ value: String(a.id), label: <span>{a.name} <span className="seg-count">{num(a.tables.filter((t) => t.status !== 'free').length)}/{num(a.tables.length)}</span></span> }))} />
        <div className="floor-legend">
          {Object.entries(TABLE_STATUS).map(([k, v]) => <span key={k} className={`lg ${v.cls}`}>{v.label}</span>)}
          <Typography.Text type="secondary">{num(counts.busy)} مشغول · {num(counts.free)} آزاد</Typography.Text>
          {loading && <Spin size="small" />}
        </div>
      </div>
      <div className={`floor-grid ${mobile ? 'flow' : ''}`} style={mobile ? undefined : { gridTemplateColumns: `repeat(${cols}, minmax(136px, 1fr))` }}>
        {current?.tables.map((t) => <TableCard key={t.id} t={t} onClick={onTable} compactMode={mobile} resv={upcoming[t.id]} sitting={sitting} />)}
      </div>
    </div>
  )
}
