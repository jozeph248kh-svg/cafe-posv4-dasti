import { MinusOutlined, PlusOutlined } from '@ant-design/icons'
import { Button, Input, Modal, Space, Tag, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { money, num } from '../../core/format'

const QUICK_NOTES = ['بدون پیاز', 'تند', 'کم‌نمک', 'بدون یخ', 'خیلی داغ', 'سس جدا', 'بیرون‌بر']

export default function ModifierModal({ item, groups, onClose, onAdd, initial }) {
  const [sel, setSel] = useState({})
  const [qty, setQty] = useState(1)
  const [note, setNote] = useState('')
  const itemGroups = useMemo(() => (item?.modifier_group_ids || []).map((id) => groups[id]).filter(Boolean), [item, groups])

  useEffect(() => {
    if (!item) return
    const s = {}
    itemGroups.forEach((g) => {
      s[g.id] = initial ? g.options.filter((o) => initial.modifier_option_ids.includes(o.id)).map((o) => o.id)
        : g.options.filter((o) => o.is_default && o.is_available).map((o) => o.id)
    })
    setSel(s)
    setQty(initial?.qty || 1)
    setNote(initial?.note || '')
  }, [item, itemGroups, initial])

  if (!item) return null
  const toggle = (g, o) => setSel((s) => {
    const cur = s[g.id] || []
    if (cur.includes(o.id)) return { ...s, [g.id]: g.min_select >= 1 && g.max_select === 1 ? cur : cur.filter((x) => x !== o.id) }
    if (g.max_select === 1) return { ...s, [g.id]: [o.id] }
    if (cur.length >= g.max_select) return s
    return { ...s, [g.id]: [...cur, o.id] }
  })
  const chosen = itemGroups.flatMap((g) => g.options.filter((o) => (sel[g.id] || []).includes(o.id)).map((o) => ({ ...o, group: g.name })))
  const unit = item.price + chosen.reduce((a, o) => a + o.price_delta, 0)
  const missing = itemGroups.filter((g) => (sel[g.id] || []).length < g.min_select)

  const submit = () => onAdd({
    menu_item_id: item.id, name: item.name, qty, note: note.trim() || null, unit_price: unit,
    modifier_option_ids: chosen.map((o) => o.id), modifiers: chosen.map((o) => ({ id: o.id, name: o.name, price: o.price_delta, group: o.group })),
  })

  return (
    <Modal open onCancel={onClose} title={<span>{item.name} <Typography.Text type="secondary" style={{ fontWeight: 400 }}>· {money(item.price)}</Typography.Text></span>}
      width={560} centered destroyOnClose
      footer={(
        <div className="mod-footer">
          <Space.Compact>
            <Button icon={<PlusOutlined />} onClick={() => setQty(qty + 1)} />
            <Button style={{ width: 52, pointerEvents: 'none' }}>{num(qty)}</Button>
            <Button icon={<MinusOutlined />} disabled={qty <= 1} onClick={() => setQty(qty - 1)} />
          </Space.Compact>
          <Button type="primary" size="large" disabled={missing.length > 0} onClick={submit} style={{ minWidth: 200 }}>
            {initial ? 'ذخیره تغییرات' : 'افزودن'} · {money(unit * qty)}
          </Button>
        </div>
      )}>
      {item.description && <Typography.Paragraph type="secondary">{item.description}</Typography.Paragraph>}
      {itemGroups.map((g) => (
        <div key={g.id} className="mod-group">
          <div className="mod-title">
            <b>{g.name}</b>
            <Tag color={g.min_select ? 'red' : 'default'}>
              {g.min_select ? 'الزامی' : 'اختیاری'}{g.max_select > 1 ? ` · حداکثر ${num(g.max_select)}` : ''}
            </Tag>
          </div>
          <div className="mod-options">
            {g.options.map((o) => {
              const on = (sel[g.id] || []).includes(o.id)
              return (
                <button type="button" key={o.id} disabled={!o.is_available} className={`mod-opt ${on ? 'on' : ''}`} onClick={() => toggle(g, o)}>
                  <span>{o.name}</span>
                  {o.price_delta !== 0 && <small>{o.price_delta > 0 ? '+' : ''}{money(o.price_delta)}</small>}
                </button>
              )
            })}
          </div>
        </div>
      ))}
      <div className="mod-group">
        <div className="mod-title"><b>توضیحات برای آشپزخانه</b></div>
        <div className="mod-options" style={{ marginBottom: 8 }}>
          {QUICK_NOTES.map((n) => (
            <Tag.CheckableTag key={n} checked={note.includes(n)}
              onChange={(c) => setNote((v) => (c ? [v, n].filter(Boolean).join('، ') : v.split('، ').filter((x) => x !== n).join('، ')))}>{n}</Tag.CheckableTag>
          ))}
        </div>
        <Input value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} placeholder="مثلاً: نان جدا سرو شود" allowClear />
      </div>
    </Modal>
  )
}
