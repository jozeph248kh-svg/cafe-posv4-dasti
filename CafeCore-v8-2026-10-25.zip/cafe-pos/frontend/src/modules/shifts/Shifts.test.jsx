import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Shifts & cash drawer. Two things can go badly wrong here and both are pinned below:
//   1. a cashier who does NOT have supervision rights must never see the expected cash (blind count);
//   2. opening / cashing-in / cashing-out must send the right amount and the right register.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
const auth = { can: () => true, canAny: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online' }))
vi.mock('../../core/print', () => ({ printShift: vi.fn() }))

const { default: Shifts } = await import('./Shifts')

const REGISTERS = [{ id: 1, name: 'صندوق اصلی', is_active: true }, { id: 2, name: 'صندوق بیرون‌بر', is_active: true }]
const SHIFT = {
  id: 12, status: 'open', register_id: 1, register_name: 'صندوق اصلی', opened_by: 'سارا', opened_at: '2026-10-23T09:00:00',
  opening_cash: 500_000, total_sales: 1_180_000, orders: 7, expected_cash: 800_800, blind: false,
  payments: { cash: 800_800, card: 385_000, online: 0, credit: 0, wallet: 0 },
  cash_in: 0, cash_out: 0, refunds: 0, movements: [{ id: 1, kind: 'out', amount: 100_000, reason: 'خرید نان', created_at: '2026-10-23T11:00:00' }],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = ({ shift = SHIFT, registers = REGISTERS } = {}) => {
  get.mockImplementation((path) => {
    if (path === '/shifts/registers') return Promise.resolve(registers)
    if (path === '/shifts/current') return Promise.resolve(shift)
    if (path === '/shifts') return Promise.resolve([{ ...(shift || {}), id: 11, status: 'closed', counted_cash: 800_000, difference: -800 }])
    return Promise.resolve([])
  })
}
const page = () => render(<App><Shifts /></App>)

describe('Shifts & cash drawer', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); auth.can = () => true; auth.canAny = () => true })

  it('shows the open shift totals and the manual cash movements', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('فروش این شیفت'))
    expect(text()).toContain('۱٬۱۸۰٬۰۰۰')
    expect(text()).toContain('۸۰۰٬۸۰۰')          // expected cash
    expect(text()).toContain('خرید نان')          // the cash-out movement
  })

  it('shows nothing a cashier could use to work out the expected cash (blind count)', async () => {
    // exactly what the server sends a blind viewer: no expected cash, no total, and the cash
    // payment method removed from the breakdown (see shift_out() in backend shifts/router.py)
    respond({ shift: { ...SHIFT, blind: true, expected_cash: null, total_sales: null, payments: { card: 385_000, online: 0, credit: 0, wallet: 0 } } })
    page()
    await waitFor(() => expect(text()).toContain('شمارش کور فعال است'))
    expect(text()).toContain('پنهان')
    expect(text()).not.toContain('۸۰۰٬۸۰۰')       // neither the total nor the cash row is in the DOM
  })

  it('opening the drawer sends the counted opening cash', async () => {
    respond({ shift: null })
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('صندوق بسته است'))
    await user().click(screen.getAllByRole('button', { name: /باز کردن صندوق/ })[0])
    const dlg = await screen.findByRole('dialog')
    const input = dlg.querySelector('input')
    await user().clear(input)
    await user().type(input, '350000')
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalledWith('/shifts/open', expect.objectContaining({ opening_cash: 350000, register_id: 1 })))
  })

  it('cash-out requires a reason and sends the amount', async () => {
    respond()
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('برداشت از صندوق'))
    await user().click(screen.getByRole('button', { name: /برداشت از صندوق/ }))
    const dlg = await screen.findByRole('dialog')
    const [amount, reason] = dlg.querySelectorAll('input')
    await user().clear(amount); await user().type(amount, '50000')
    await user().type(reason, 'پرداخت به پیک')
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalledWith('/shifts/cash', expect.objectContaining({ kind: 'out', amount: 50000, reason: 'پرداخت به پیک' })))
  })

  it('never renders a difference column value for a shift that is still open', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('تاریخچه شیفت‌ها'))
    expect(text()).toContain('۸۰۰')              // the closed shift's difference (short by 800)
  })
})
