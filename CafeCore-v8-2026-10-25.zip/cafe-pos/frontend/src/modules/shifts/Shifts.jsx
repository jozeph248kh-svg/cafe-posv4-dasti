import { DesktopOutlined, EyeInvisibleOutlined, LockOutlined, MinusCircleOutlined, PlusCircleOutlined, PrinterOutlined, SettingOutlined, UnlockOutlined, WalletOutlined } from '@ant-design/icons'
import { Alert, App, Button, Card, Col, Descriptions, Empty, Form, Input, InputNumber, Modal, Row, Select, Space, Table, Tag, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import DrawerCloseModal from '../../components/DrawerCloseModal'
import { RegisterManager, deviceRegister, registerOptions } from '../../components/Registers'
import { post } from '../../core/api'
import { useAuth } from '../../core/auth'
import { getRegisterId, setRegisterId } from '../../core/register'
import { PAY_METHODS, faDateTime, money, moneyFormatter, moneyParser, num, timeAgo } from '../../core/format'
import { printShift } from '../../core/print'
import { cashOr } from '../../core/shiftview'
import { useRealtime } from '../../core/realtime'
import { useFetch } from '../../core/useFetch'
import StaffReports from './StaffReports'

const HIDDEN_LABEL = <span className="blind-value" style={{ fontSize: 18, color: 'var(--muted)' }}>پنهان</span>

export default function Shifts() {
  const auth = useAuth()
  const { message } = App.useApp()
  const regs = useFetch('/shifts/registers')
  const [regId, setRegId] = useState(null)              // register shown on this page (default: this device's)
  const [devId, setDevId] = useState(getRegisterId())
  const [manage, setManage] = useState(false)
  const dev = deviceRegister(regs.data)
  const viewId = regId || dev.current?.id
  const multi = (regs.data || []).filter((r) => r.is_active).length > 1
  const cur = useFetch('/shifts/current', { register_id: viewId }, { skip: !viewId, deps: [viewId] })
  const list = useFetch('/shifts', { limit: 60 })
  const [dlg, setDlg] = useState(null)
  const [busy, setBusy] = useState(false)
  const [form] = Form.useForm()
  useRealtime(['order.changed', 'shift.changed'], () => { cur.reload(true); list.reload(true); regs.reload(true) })
  useEffect(() => {
    const f = () => setDevId(getRegisterId())
    window.addEventListener('register:changed', f)
    return () => window.removeEventListener('register:changed', f)
  }, [])
  const s = cur.data
  const viewName = (regs.data || []).find((r) => r.id === viewId)?.name

  const submit = async (v) => {
    setBusy(true)
    try {
      if (dlg === 'open') await post('/shifts/open', { opening_cash: v.amount || 0, note: v.note, register_id: viewId })
      if (dlg === 'in' || dlg === 'out') await post('/shifts/cash', { kind: dlg, amount: v.amount, reason: v.reason, register_id: viewId })
      message.success('ثبت شد')
      setDlg(null); form.resetFields()
      cur.reload(); list.reload(); regs.reload(true)
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }

  return (
    <div className="fade-in">
      <PageHeader title={multi && viewName ? `شیفت و صندوق — ${viewName}` : 'شیفت و صندوق'} subtitle="مدیریت موجودی نقدی، برداشت و واریز، بستن صندوق با شمارش پول" extra={
        s ? [
          <Button key="in" icon={<PlusCircleOutlined />} onClick={() => setDlg('in')}>واریز به صندوق</Button>,
          <Button key="out" icon={<MinusCircleOutlined />} onClick={() => setDlg('out')}>برداشت از صندوق</Button>,
          <Button key="close" type="primary" danger icon={<LockOutlined />} onClick={() => setDlg('close')}>بستن صندوق</Button>,
        ] : <Button type="primary" icon={<UnlockOutlined />} onClick={() => setDlg('open')}>باز کردن صندوق</Button>
      } />
      {!dev.valid && (
        <Alert type="error" showIcon style={{ marginBottom: 16 }} message="صندوقِ انتخاب‌شده برای این دستگاه حذف یا غیرفعال شده است؛ پرداخت از این دستگاه ثبت نمی‌شود تا صندوق دیگری انتخاب کنید." />
      )}
      {(multi || auth.can('shifts.manage')) && (
        <Card className="card-r registers-bar" size="small" style={{ marginBottom: 16 }}>
          <Space wrap style={{ width: '100%', justifyContent: 'space-between' }}>
            <Space wrap>
              {multi && <>
                <span>صندوق:</span>
                <Select className="reg-view" style={{ minWidth: 220 }} value={viewId} onChange={setRegId} options={registerOptions(regs.data)} />
                {devId === viewId || (!devId && dev.current?.id === viewId && dev.valid)
                  ? <Tag icon={<DesktopOutlined />} color="blue">صندوق این دستگاه</Tag>
                  : <Button className="reg-use" icon={<DesktopOutlined />} onClick={() => { setRegisterId(viewId); message.success(`این دستگاه از «${viewName}» استفاده می‌کند`) }}>استفاده در این دستگاه</Button>}
              </>}
              {!multi && <Typography.Text type="secondary">یک صندوق تعریف شده است ({viewName || '—'}). برای صندوق دوم (مثلاً بیرون‌بر)، صندوق جدید اضافه کنید.</Typography.Text>}
            </Space>
            {auth.can('shifts.manage') && <Button className="reg-manage" icon={<SettingOutlined />} onClick={() => setManage(true)}>مدیریت صندوق‌ها</Button>}
          </Space>
        </Card>
      )}
      {s ? (
        <>
          {s.blind && (
            <Alert className="blind-banner" type="warning" showIcon icon={<EyeInvisibleOutlined />} style={{ marginBottom: 16 }}
              message="شمارش کور فعال است" description="مبلغ نقدی که باید در صندوق باشد فقط به مدیر نمایش داده می‌شود. هنگام تحویل صندوق، پول را بشمارید؛ نتیجه پس از ثبت شمارش نمایش داده می‌شود." />
          )}
          <Row gutter={[16, 16]}>
            <Col xs={12} lg={6}><StatCard title="فروش این شیفت" value={s.blind ? HIDDEN_LABEL : s.total_sales} money={!s.blind} icon={<WalletOutlined />} hint={`${num(s.orders)} سفارش`} /></Col>
            <Col xs={12} lg={6}><StatCard title="نقد مورد انتظار در صندوق" value={s.blind ? HIDDEN_LABEL : s.expected_cash} money={!s.blind} color="var(--green)" icon={s.blind ? <EyeInvisibleOutlined /> : '💵'} hint={s.blind ? 'شمارش کور' : undefined} /></Col>
            <Col xs={12} lg={6}><StatCard title="کارتخوان" value={s.payments.card || 0} money color="var(--pal-1)" icon="💳" /></Col>
            <Col xs={12} lg={6}><StatCard title="آنلاین و نسیه" value={(s.payments.online || 0) + (s.payments.credit || 0)} money color="var(--amber)" icon="🌐" /></Col>
          </Row>
          <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
            <Col xs={24} lg={10}>
              <Card className="card-r" title={<span><Tag color="green">باز</Tag> شیفت #{num(s.id)}</span>} extra={<Button icon={<PrinterOutlined />} onClick={() => printShift(s, auth.settings)}>چاپ</Button>}>
                <Descriptions column={1} size="small">
                  <Descriptions.Item label="بازکننده">{s.opened_by}</Descriptions.Item>
                  <Descriptions.Item label="زمان باز شدن">{faDateTime(s.opened_at)} ({timeAgo(s.opened_at)})</Descriptions.Item>
                  <Descriptions.Item label="موجودی اول شیفت">{money(s.opening_cash)}</Descriptions.Item>
                  {Object.entries(s.payments).map(([m, v]) => <Descriptions.Item key={m} label={PAY_METHODS[m]?.label}>{money(v)}</Descriptions.Item>)}
                  <Descriptions.Item label="واریز / برداشت">{money(s.cash_in)} / {money(s.cash_out)}</Descriptions.Item>
                  <Descriptions.Item label="بازپرداخت‌ها">{money(s.refunds)}</Descriptions.Item>
                </Descriptions>
              </Card>
            </Col>
            <Col xs={24} lg={14}>
              <Card className="card-r" title="گردش نقدی دستی">
                <Table size="small" rowKey="id" dataSource={s.movements} pagination={false} locale={{ emptyText: 'واریز یا برداشتی ثبت نشده' }}
                  columns={[
                    { title: 'نوع', dataIndex: 'kind', render: (k) => (k === 'in' ? <Tag color="green">واریز</Tag> : <Tag color="red">برداشت</Tag>) },
                    { title: 'مبلغ', dataIndex: 'amount', render: money },
                    { title: 'بابت', dataIndex: 'reason' },
                    { title: 'زمان', dataIndex: 'created_at', render: faDateTime },
                  ]} />
              </Card>
            </Col>
          </Row>
        </>
      ) : !cur.loading && viewId && (
        <Card className="card-r"><Empty description="صندوق بسته است؛ برای شروع فروش، شیفت را باز کنید"><Button type="primary" onClick={() => setDlg('open')}>باز کردن صندوق</Button></Empty></Card>
      )}

      <Card className="card-r" title="تاریخچه شیفت‌ها" style={{ marginTop: 16 }}>
        <Table rowKey="id" loading={list.loading} dataSource={list.data || []} scroll={{ x: 900 }} pagination={{ pageSize: 10 }}
          columns={[
            { title: 'شیفت', dataIndex: 'id', render: (v, r) => <span>#{num(v)} {r.status === 'open' && <Tag color="green">باز</Tag>}</span> },
            ...(multi ? [{ title: 'صندوق', dataIndex: 'register_name', filters: (regs.data || []).map((x) => ({ text: x.name, value: x.name })), onFilter: (v, r) => r.register_name === v }] : []),
            { title: 'باز', render: (_, r) => <div>{faDateTime(r.opened_at)}<div style={{ fontSize: 12, color: 'var(--muted)' }}>{r.opened_by}</div></div> },
            { title: 'بسته', render: (_, r) => (r.closed_at ? <div>{faDateTime(r.closed_at)}<div style={{ fontSize: 12, color: 'var(--muted)' }}>{r.closed_by}</div></div> : '—') },
            { title: 'سفارش', dataIndex: 'orders', render: (v) => num(v) },
            { title: 'فروش', dataIndex: 'total_sales', render: (v) => <b>{cashOr(v)}</b> },
            { title: 'نقد مورد انتظار', dataIndex: 'expected_cash', render: (v) => cashOr(v) },
            { title: 'شمارش‌شده', dataIndex: 'counted_cash', render: (v) => (v == null ? '—' : money(v)) },
            { title: 'مغایرت', dataIndex: 'difference', render: (v) => (v == null ? '—' : <Tag color={v === 0 ? 'green' : v > 0 ? 'blue' : 'red'}>{v > 0 ? '+' : ''}{money(v)}</Tag>) },
            { title: '', render: (_, r) => <Button type="text" icon={<PrinterOutlined />} onClick={() => printShift(r, auth.settings)} /> },
          ]} />
      </Card>

      <DrawerCloseModal open={dlg === 'close'} shift={s} title={`بستن صندوق و شمارش پول${multi && viewName ? ` — ${viewName}` : ''}`}
        onClose={() => setDlg(null)} onClosed={() => { setDlg(null); cur.reload(); list.reload(); regs.reload(true) }} />
      <Modal open={!!dlg && dlg !== 'close'} onCancel={() => setDlg(null)} onOk={() => form.submit()} confirmLoading={busy} destroyOnClose width={460}
        title={`${{ open: 'باز کردن صندوق', in: 'واریز به صندوق', out: 'برداشت از صندوق' }[dlg] || ''}${multi && viewName ? ` — ${viewName}` : ''}`}
        okText="ثبت">
        <Form form={form} layout="vertical" onFinish={submit} preserve={false}>
          <Form.Item name="amount" label={dlg === 'open' ? 'موجودی نقدی اول شیفت (شمارش خودتان)' : 'مبلغ'} initialValue={dlg === 'open' ? 0 : undefined}
            rules={[{ required: true, message: 'مبلغ را وارد کنید' }]}>
            <InputNumber min={0} size="large" style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" autoFocus />
          </Form.Item>
          {(dlg === 'in' || dlg === 'out') && (
            <Form.Item name="reason" label="بابت" rules={[{ required: true, min: 2, message: 'دلیل را وارد کنید' }]}>
              <Input placeholder={dlg === 'out' ? 'مثلاً: خرید نان، پرداخت به پیک' : 'مثلاً: پول خرد'} />
            </Form.Item>
          )}
          {dlg === 'open' && <Form.Item name="note" label="یادداشت"><Input.TextArea rows={2} /></Form.Item>}
        </Form>
      </Modal>
      {auth.can('shifts.supervise') && <StaffReports />}
      <RegisterManager open={manage} onClose={() => setManage(false)} onChanged={() => { regs.reload(true); list.reload(true) }} />
    </div>
  )
}
