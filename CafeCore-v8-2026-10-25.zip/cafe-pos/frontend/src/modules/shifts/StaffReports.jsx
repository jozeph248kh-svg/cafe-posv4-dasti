import { CheckOutlined, EyeOutlined, FileTextOutlined, PrinterOutlined } from '@ant-design/icons'
import { App, Avatar, Badge, Button, Card, Drawer, Input, Segmented, Space, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import StaffReportView from '../../components/StaffReportView'
import { hm } from '../../components/TimeClockButton'
import { post } from '../../core/api'
import { useAuth } from '../../core/auth'
import { colorOf, faDateTime, faTime, initials, money, num } from '../../core/format'
import { printStaffReport } from '../../core/print'
import { useRealtime } from '../../core/realtime'
import { diffInfo } from '../../core/shiftview'
import { useFetch } from '../../core/useFetch'

const drawerDiff = (d) => (d?.drawers_closed || []).reduce((a, s) => (s.difference == null ? a : (a ?? 0) + s.difference), null)

/** Managers (shifts.supervise): end-of-shift reports of the staff — review and acknowledge. */
export default function StaffReports() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [filter, setFilter] = useState('pending')
  const list = useFetch('/shifts/staff-reports', filter === 'pending' ? { pending: true } : {}, { deps: [filter] })
  const [open, setOpen] = useState(null)
  const [mnote, setMnote] = useState('')
  const [busy, setBusy] = useState(false)
  useRealtime(['staff_report.submitted'], () => list.reload(true))

  const ack = async () => {
    setBusy(true)
    try {
      const r = await post(`/shifts/staff-reports/${open.id}/ack`, { note: mnote })
      message.success(`گزارش ${r.name} تأیید شد`)
      setOpen(r); list.reload(true)
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  const show = (r) => { setOpen(r); setMnote(r.manager_note || '') }

  return (
    <Card className="card-r staff-reports" style={{ marginTop: 16 }}
      title={<span><FileTextOutlined /> گزارش‌های پایان شیفت کارکنان {filter === 'pending' && list.data?.length > 0 && <Badge count={list.data.length} style={{ marginInlineStart: 6 }} />}</span>}
      extra={<Segmented value={filter} onChange={setFilter} options={[{ label: 'در انتظار بررسی', value: 'pending' }, { label: 'همه', value: 'all' }]} />}>
      <Table rowKey="id" size="small" loading={list.loading} dataSource={list.data || []} scroll={{ x: 900 }} pagination={{ pageSize: 8 }}
        locale={{ emptyText: filter === 'pending' ? 'گزارش بررسی‌نشده‌ای نیست ✓' : 'هنوز گزارشی ارسال نشده' }}
        onRow={(r) => ({ onClick: () => show(r), style: { cursor: 'pointer' } })}
        columns={[
          { title: 'کارمند', render: (_, r) => <Space><Avatar size="small" style={{ background: colorOf(r.name) }}>{initials(r.name)}</Avatar><div>{r.name}<div style={{ fontSize: 12, color: 'var(--muted)' }}>{r.role}</div></div></Space> },
          { title: 'شیفت', render: (_, r) => <div>{faTime(r.period_start)} تا {faTime(r.period_end)}<div style={{ fontSize: 12, color: 'var(--muted)' }}>{faDateTime(r.submitted_at)}</div></div> },
          { title: 'حضور', render: (_, r) => (r.data.minutes == null ? '—' : hm(r.data.minutes)) },
          { title: 'سفارش / فروش', render: (_, r) => <span>{num(r.data.orders?.closed)} — <b>{money(r.data.orders?.sales)}</b></span> },
          { title: 'صندوق', render: (_, r) => { const v = drawerDiff(r.data); if (v == null) return '—'; const x = diffInfo(v); return <Tag color={x.tone === 'success' ? 'green' : x.tone === 'info' ? 'blue' : 'red'}>{v === 0 ? 'بدون مغایرت' : `${v > 0 ? '+' : '−'}${money(Math.abs(v))}`}</Tag> } },
          { title: 'کنترل', render: (_, r) => <span style={{ fontSize: 12 }}>{r.data.voids?.count ? <Tag color="red">{num(r.data.voids.count)} حذف</Tag> : null}{r.data.discounts?.count ? <Tag color="gold">{num(r.data.discounts.count)} تخفیف</Tag> : null}{r.data.open_orders?.length ? <Tag color="orange">{num(r.data.open_orders.length)} باز</Tag> : null}</span> },
          { title: 'یادداشت', dataIndex: 'note', ellipsis: true, render: (v) => v || <span style={{ color: 'var(--muted)' }}>—</span> },
          { title: 'وضعیت', render: (_, r) => (r.acknowledged_at ? <Tag color="green" icon={<CheckOutlined />}>{r.acknowledged_by}</Tag> : <Tag color="gold">در انتظار</Tag>) },
          { title: '', render: (_, r) => <Button size="small" type="text" icon={<EyeOutlined />} className="report-open" onClick={(e) => { e.stopPropagation(); show(r) }} /> },
        ]} />
      <Drawer open={!!open} onClose={() => setOpen(null)} width={Math.min(900, window.innerWidth)} destroyOnClose
        title={open && <span>گزارش پایان شیفت — {open.name} <Typography.Text type="secondary" style={{ fontSize: 13 }}>({faDateTime(open.period_start)} تا {faTime(open.period_end)})</Typography.Text></span>}
        extra={open && <Button icon={<PrinterOutlined />} onClick={() => printStaffReport(open, auth.settings)}>چاپ</Button>}>
        {open && (
          <>
            {open.note && <Card size="small" className="card-r" style={{ marginBottom: 12, background: 'var(--soft)' }}><b>یادداشت کارمند:</b> {open.note}</Card>}
            <StaffReportView data={open.data} compact />
            <Card size="small" className="card-r" style={{ marginTop: 12 }} title="بررسی مدیر">
              {open.acknowledged_at
                ? <div><Tag color="green" icon={<CheckOutlined />}>تأییدشده توسط {open.acknowledged_by} — {faDateTime(open.acknowledged_at)}</Tag>{open.manager_note && <p style={{ marginTop: 8 }}>{open.manager_note}</p>}</div>
                : (
                  <>
                    <Input.TextArea rows={2} maxLength={500} value={mnote} onChange={(e) => setMnote(e.target.value)} className="ack-note" placeholder="یادداشت مدیر (اختیاری) — مثلاً: کسری از حقوق کسر شود / توضیح پذیرفته شد" />
                    <Button type="primary" icon={<CheckOutlined />} loading={busy} style={{ marginTop: 8 }} onClick={ack} className="ack-btn">دیدم و تأیید شد</Button>
                  </>
                )}
            </Card>
          </>
        )}
      </Drawer>
    </Card>
  )
}
