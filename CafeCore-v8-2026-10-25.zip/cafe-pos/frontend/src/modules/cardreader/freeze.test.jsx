import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * REGRESSION: the card-reader dialog used to be a trap.
 *
 * While `state === 'waiting'` the modal was rendered with closable={false}, maskClosable={false}
 * and onCancel={undefined} — and the only visible button ("لغو تراکنش") posted the cancel to the
 * server but never changed the state. So after pressing cancel (or if the terminal never answered)
 * the cashier was left with a modal that could not be closed at all: the POS was frozen until the
 * page was reloaded. These tests pin that every path out of 'waiting' actually closes the dialog.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

const { default: CardCharge } = await import('./CardCharge')

const TERM = { id: 1, name: 'پارس‌کالا', driver: 'bridge', driver_title: 'پل (PC-POS)', psp_title: 'به‌پرداخت ملت', is_active: true }
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('CardCharge — no dead end while waiting for the terminal', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); localStorage.clear(); get.mockImplementation(() => Promise.resolve([TERM])) })

  it('cancelling a waiting transaction returns to a usable state', async () => {
    // the charge never answers → the dialog stays in 'waiting'
    post.mockImplementation((path) => (path.startsWith('/cardreader/charge/') ? Promise.resolve({}) : new Promise(() => {})))
    const onClose = vi.fn()
    render(<App><CardCharge open amount={254_000} orderId={9} onApproved={() => {}} onClose={onClose} /></App>)
    await waitFor(() => expect(text()).toContain('پارس‌کالا'))
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /ارسال مبلغ/.test(b.textContent)))
    await waitFor(() => expect(text()).toContain('رمز را وارد کنید'))

    fireEvent.click(screen.getByRole('button', { name: /لغو تراکنش/ }))
    // after cancelling, the cashier must be able to get out of the dialog
    await waitFor(() => expect(text()).not.toContain('رمز را وارد کنید'), { timeout: 3000 })
  })

  it('offers a close affordance when the terminal hangs (no endless spinner)', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true })
    post.mockImplementation((path) => (path.startsWith('/cardreader/charge/') ? Promise.resolve({}) : new Promise(() => {})))
    render(<App><CardCharge open amount={100_000} orderId={9} onApproved={() => {}} onClose={() => {}} /></App>)
    await waitFor(() => expect(text()).toContain('پارس‌کالا'))
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /ارسال مبلغ/.test(b.textContent)))
    await waitFor(() => expect(text()).toContain('رمز را وارد کنید'))
    // after the timeout the dialog must become closable again
    vi.advanceTimersByTime(130_000)
    await waitFor(() => expect(document.querySelector('.ant-modal-close')).toBeTruthy(), { timeout: 3000 })
    vi.useRealTimers()
  })
})
