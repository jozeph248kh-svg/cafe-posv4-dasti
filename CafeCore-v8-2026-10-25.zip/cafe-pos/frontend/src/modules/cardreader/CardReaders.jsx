import { ApiOutlined, CheckCircleFilled, CreditCardOutlined, DeleteOutlined, EditOutlined, PlusOutlined, WarningOutlined } from '@ant-design/icons'
import { Alert, App, Badge, Button, Card, Col, Collapse, Drawer, Empty, Form, Input, InputNumber, Popconfirm, Row, Segmented, Select, Space, Switch, Table, Tag, Tooltip, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { del, post, put } from '../../core/api'
import { faDateTime, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { loadTerminals } from './CardCharge'

const ST = { approved: ['موفق', 'success'], declined: ['رد شده', 'error'], error: ['خطا', 'error'], cancelled: ['لغو', 'default'], pending: ['در انتظار', 'processing'] }

function TerminalForm({ open, item, meta, onClose, onSaved }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const driver = Form.useWatch('driver', form)
  const [busy, setBusy] = useState(false)
  const save = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy(true)
    try {
      if (item?.id) await put(`/cardreader/terminals/${item.id}`, v); else await post('/cardreader/terminals', v)
      message.success('ذخیره شد'); loadTerminals(true); onSaved()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Drawer open={open} onClose={onClose} width={480} title={item?.id ? 'ویرایش کارتخوان' : 'کارتخوان جدید'} destroyOnClose
      afterOpenChange={(o) => o && form.setFieldsValue(item || { driver: 'simulator', psp: 'sadad', timeout_sec: 90, is_active: true })}
      extra={<Button type="primary" loading={busy} onClick={save}>ذخیره</Button>}>
      <Form form={form} layout="vertical">
        <Form.Item name="name" label="نام" rules={[{ required: true }]}><Input placeholder="کارتخوان صندوق ۱" /></Form.Item>
        <Form.Item name="psp" label="شرکت ارائه‌دهنده (PSP)"><Select options={Object.entries(meta?.psps || {}).map(([value, label]) => ({ value, label }))} /></Form.Item>
        <Form.Item name="driver" label="نوع اتصال">
          <Segmented block options={Object.entries(meta?.drivers || {}).map(([value, label]) => ({ value, label: label.split(' (')[0] }))} />
        </Form.Item>
        {driver === 'simulator' && <Alert type="info" showIcon style={{ marginBottom: 16 }} message="شبیه‌ساز برای آموزش و تست است: پس از ۳ ثانیه تأیید می‌کند. مبالغی که به ۱۳ هزار تومان ختم شوند (مثل ۱۱۳٬۰۰۰) رد می‌شوند." />}
        {driver === 'manual' && <Alert type="info" showIcon style={{ marginBottom: 16 }} message="برای کارتخوان‌های بدون اتصال: صندوقدار مبلغ را روی دستگاه می‌زند و شماره پیگیری رسید را در نرم‌افزار ثبت می‌کند." />}
        {driver === 'bridge' && <>
          <Form.Item name="url" label="آدرس پل کارتخوان" rules={[{ required: true }]} extra="برنامه پل روی کامپیوتر ویندوزی کنار کارتخوان اجرا می‌شود (tools/pcpos_bridge.py)"><Input className="ltr" placeholder="http://192.168.1.20:8090" /></Form.Item>
          <Form.Item name="token" label="توکن امنیتی پل"><Input.Password className="ltr" autoComplete="off" /></Form.Item>
          <Form.Item name="device_ip" label="IP و پورت خود کارتخوان" extra="از منوی تنظیمات شبکه دستگاه؛ مثلاً 192.168.1.227:8888"><Input className="ltr" placeholder="192.168.1.227:8888" /></Form.Item>
          <Form.Item name="timeout_sec" label="حداکثر زمان انتظار"><InputNumber min={20} max={300} addonAfter="ثانیه" /></Form.Item>
        </>}
        <Form.Item name="terminal_code" label="شماره ترمینال (روی دستگاه)"><Input className="ltr" /></Form.Item>
        <Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item>
      </Form>
    </Drawer>
  )
}

export default function CardReaders() {
  const { message } = App.useApp()
  const meta = useFetch('/cardreader/meta')
  const terms = useFetch('/cardreader/terminals')
  const [days, setDays] = useState(1)
  const [onlyUnlinked, setOnlyUnlinked] = useState(false)
  const tx = useFetch('/cardreader/txns', { days, unlinked: onlyUnlinked })
  const [edit, setEdit] = useState(null)
  const [pings, setPings] = useState({})
  const termName = (id) => terms.data?.find((t) => t.id === id)?.name || '—'

  const ping = async (t) => {
    setPings({ ...pings, [t.id]: { loading: true } })
    const r = await post(`/cardreader/terminals/${t.id}/ping`).catch((e) => ({ ok: false, message: e.message }))
    setPings((p) => ({ ...p, [t.id]: r }))
  }

  return (
    <div>
      <PageHeader title="کارتخوان‌ها" subtitle="اتصال کارتخوان بانکی به صندوق (PC-POS) و تطبیق تراکنش‌ها" icon={<CreditCardOutlined />}
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setEdit({})}>کارتخوان جدید</Button>} />
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={12} lg={8}><StatCard loading={tx.loading} title="تراکنش موفق" value={tx.data?.approved_count} icon={<CheckCircleFilled />} color="var(--green)" hint={days === 1 ? 'امروز' : `${num(days)} روز اخیر`} /></Col>
        <Col xs={12} lg={8}><StatCard loading={tx.loading} title="جمع دریافتی کارتخوان" value={tx.data?.approved_total} money icon={<CreditCardOutlined />} color="var(--pal-1)" /></Col>
        <Col xs={24} lg={8}><StatCard loading={tx.loading} title="تطبیق‌نشده" value={tx.data?.unlinked} icon={<WarningOutlined />} color={tx.data?.unlinked ? 'var(--red)' : 'var(--muted)'} hint="موفق در دستگاه ولی بدون ثبت در سفارش" onClick={() => setOnlyUnlinked(true)} /></Col>
      </Row>

      <Row gutter={[16, 16]}>
        {(terms.data || []).map((t) => (
          <Col xs={24} md={12} xl={8} key={t.id}>
            <Card className={`cr-term ${t.is_active ? '' : 'off'}`} actions={[
              <Button key="p" type="text" icon={<ApiOutlined />} loading={pings[t.id]?.loading} onClick={() => ping(t)}>تست اتصال</Button>,
              <Button key="e" type="text" icon={<EditOutlined />} onClick={() => setEdit(t)}>ویرایش</Button>,
              <Popconfirm key="d" title="حذف کارتخوان؟" description="اگر تراکنش داشته باشد فقط غیرفعال می‌شود." onConfirm={async () => { await del(`/cardreader/terminals/${t.id}`); loadTerminals(true); terms.reload(); message.success('انجام شد') }}>
                <Button type="text" danger icon={<DeleteOutlined />} />
              </Popconfirm>,
            ]}>
              <div className="cr-head">
                <div className="cr-icon"><CreditCardOutlined /></div>
                <div style={{ minWidth: 0 }}>
                  <b>{t.name}</b>
                  <div><Tag>{t.psp_title}</Tag><Tag color={t.driver === 'bridge' ? 'blue' : t.driver === 'manual' ? 'default' : 'orange'}>{t.driver_title.split(' (')[0]}</Tag>{!t.is_active && <Tag color="red">غیرفعال</Tag>}</div>
                </div>
              </div>
              <div className="cr-info">
                {t.driver === 'bridge' && <div><span>پل</span><span className="ltr">{t.url}</span></div>}
                {t.device_ip && <div><span>دستگاه</span><span className="ltr">{t.device_ip}</span></div>}
                {t.terminal_code && <div><span>ترمینال</span><span className="ltr">{t.terminal_code}</span></div>}
              </div>
              {pings[t.id] && !pings[t.id].loading && <Alert style={{ marginTop: 10 }} type={pings[t.id].ok ? 'success' : 'error'} showIcon message={pings[t.id].message} />}
            </Card>
          </Col>
        ))}
        {!terms.loading && !terms.data?.length && <Col span={24}><Card><Empty description="هنوز کارتخوانی تعریف نشده" /></Card></Col>}
      </Row>

      <Card style={{ marginTop: 16 }} title="تراکنش‌ها" extra={<Space wrap>
        <Segmented value={days} onChange={setDays} options={[{ value: 1, label: 'امروز' }, { value: 7, label: '۷ روز' }, { value: 30, label: '۳۰ روز' }]} />
        <Space size={6}><Switch size="small" checked={onlyUnlinked} onChange={setOnlyUnlinked} />فقط تطبیق‌نشده</Space>
      </Space>}>
        {tx.data?.unlinked > 0 && !onlyUnlinked && <Alert type="warning" showIcon style={{ marginBottom: 12 }} message={`${num(tx.data.unlinked)} تراکنش موفق کارتخوان هنوز در هیچ سفارشی ثبت نشده است. آن‌ها را بررسی کنید.`} action={<Button size="small" onClick={() => setOnlyUnlinked(true)}>نمایش</Button>} />}
        <Table rowKey="id" size="middle" loading={tx.loading} dataSource={tx.data?.items || []} scroll={{ x: 820 }} pagination={{ pageSize: 12, hideOnSinglePage: true }}
          columns={[
            { title: 'زمان', dataIndex: 'created_at', width: 140, render: faDateTime },
            { title: 'کارتخوان', dataIndex: 'terminal_id', render: termName },
            { title: 'مبلغ', dataIndex: 'amount', render: (v) => <b>{money(v)}</b> },
            { title: 'وضعیت', dataIndex: 'status', render: (v, r) => <Tooltip title={r.message}><Badge status={ST[v]?.[1]} text={ST[v]?.[0]} /></Tooltip> },
            { title: 'پیگیری', dataIndex: 'rrn', render: (v) => v ? <span className="ltr">{v}</span> : '—' },
            { title: 'کارت', dataIndex: 'card', render: (v) => v ? <span className="ltr" style={{ fontSize: 12 }}>{v}</span> : '—' },
            { title: 'سفارش', render: (_, r) => r.payment_id ? <Tag color="green">ثبت در سفارش</Tag> : r.status === 'approved' ? (
              <Space size={4}><Tag color="red">تطبیق‌نشده</Tag>
                <Popconfirm title="این تراکنش بررسی شد؟" description="مثلاً مبلغ در دستگاه برگشت خورده یا به‌صورت دستی ثبت شده" onConfirm={async () => { await post(`/cardreader/txns/${r.id}/dismiss`); tx.reload() }}>
                  <Button size="small" type="link">تطبیق دستی</Button>
                </Popconfirm>
              </Space>) : '—' },
          ]} />
      </Card>

      <Collapse style={{ marginTop: 16 }} items={[{ key: 'h', label: 'راهنمای اتصال کارتخوان واقعی', children: (
        <Typography>
          <Typography.Paragraph>شرکت‌های PSP (سداد، به‌پرداخت ملت، پارسیان، سامان‌کیش، ایران‌کیش، آسان‌پرداخت، پاسارگاد و…) پروتکل کارتخوان را به‌صورت عمومی منتشر نمی‌کنند و برای هر دستگاه یک SDK ویندوزی اختصاصی (DLL یا سرویس) می‌دهند. به همین دلیل نرم‌افزار از طریق یک «پل» کوچک با دستگاه صحبت می‌کند:</Typography.Paragraph>
          <ol>
            <li>از پشتیبانی PSP بخواهید قابلیت <b>PC-POS</b> را روی کارتخوان شما فعال کنند و SDK آن را بگیرید.</li>
            <li>کارتخوان را با کابل شبکه به مودم وصل کنید و IP آن را از منوی دستگاه ببینید.</li>
            <li>روی کامپیوتر صندوق، برنامه <Typography.Text code>tools/pcpos_bridge.py</Typography.Text> را اجرا کنید (آداپتور SDK را داخل آن قرار دهید؛ نمونه در توضیحات فایل هست).</li>
            <li>اینجا یک کارتخوان با نوع «اتصال شبکه» بسازید، آدرس پل را وارد کنید و «تست اتصال» بزنید.</li>
          </ol>
          <Typography.Paragraph type="secondary">تا آن زمان می‌توانید از حالت «دستی» استفاده کنید تا شماره پیگیری هر پرداخت کارتی ثبت و قابل تطبیق باشد.</Typography.Paragraph>
        </Typography>
      ) }]} />

      <TerminalForm open={!!edit} item={edit?.id ? edit : null} meta={meta.data} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); terms.reload() }} />
    </div>
  )
}
