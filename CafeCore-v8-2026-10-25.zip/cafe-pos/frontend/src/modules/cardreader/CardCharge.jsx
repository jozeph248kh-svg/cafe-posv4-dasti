import { CheckCircleFilled, CloseCircleFilled, CreditCardOutlined, EditOutlined, RedoOutlined } from '@ant-design/icons'
import { Alert, Button, Input, Modal, Select, Space, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { get, post } from '../../core/api'
import { money, num } from '../../core/format'

const KEY = 'cafe_terminal_id'
let cache = null

export async function loadTerminals(force) {
  if (!cache || force) cache = get('/cardreader/terminals').then((r) => r.filter((t) => t.is_active)).catch(() => [])
  return cache
}

/** Sends an amount to the bank card reader and waits for the customer. Calls onApproved(txn) on success. */
export default function CardCharge({ open, amount, orderId, onApproved, onClose }) {
  const [terms, setTerms] = useState([])
  const [tid, setTid] = useState(() => Number(localStorage.getItem(KEY)) || null)
  const [state, setState] = useState('idle')          // idle | waiting | approved | failed | manual
  const [res, setRes] = useState(null)
  const [secs, setSecs] = useState(0)
  const [rrn, setRrn] = useState('')
  const [card, setCard] = useState('')
  const [stuck, setStuck] = useState(false)      // the terminal stopped answering: let the cashier out
  const uid = useRef(null)

  useEffect(() => {
    if (!open) return
    setState('idle'); setRes(null); setRrn(''); setCard(''); setStuck(false)
    loadTerminals().then((t) => {
      setTerms(t)
      setTid((cur) => (t.some((x) => x.id === cur) ? cur : t[0]?.id || null))
    })
  }, [open])
  useEffect(() => {
    if (state !== 'waiting') { setStuck(false); return undefined }
    const i = setInterval(() => setSecs((s) => {
      const next = s + 1
      if (next === 90) setStuck(true)            // never leave the cashier without a way out
      return next
    }), 1000)
    return () => clearInterval(i)
  }, [state])

  const term = terms.find((t) => t.id === tid)
  const pick = (v) => { setTid(v); localStorage.setItem(KEY, v) }

  const charge = async () => {
    if (term?.driver === 'manual') { setState('manual'); return }
    uid.current = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`
    setSecs(0); setState('waiting')
    try {
      const r = await post('/cardreader/charge', { terminal_id: tid, amount, order_id: orderId, uid: uid.current })
      setRes(r)
      if (r.status === 'approved') { setState('approved'); setTimeout(() => onApproved(r), 900) } else setState('failed')
    } catch (e) {
      setRes({ status: 'error', message: e.message }); setState('failed')
    }
  }
  const cancel = async () => {
    const id = uid.current
    uid.current = null
    if (id) await post(`/cardreader/charge/${id}/cancel`).catch(() => {})
    // the important part: the dialog always becomes usable again (it used to stay on "waiting" forever)
    setRes({ status: 'cancelled', message: 'تراکنش لغو شد' })
    setState('failed')
  }
  const saveManual = async () => {
    try {
      const r = await post('/cardreader/manual', { terminal_id: tid, amount, order_id: orderId, rrn, card: card ? `****${card}` : null })
      onApproved(r)
    } catch (e) { setRes({ status: 'error', message: e.message }) }
  }

  const canClose = state !== 'waiting' || stuck
  return (
    <Modal open={open} onCancel={canClose ? onClose : undefined} closable={canClose} maskClosable={false} footer={null} width={420} centered destroyOnClose
      title={<span><CreditCardOutlined /> پرداخت با کارتخوان</span>}>
      <div className="cc-amount"><small>مبلغ</small><b>{money(amount)}</b><span>تومان</span></div>
      {!terms.length && <Alert type="warning" showIcon message="هیچ کارتخوانی تعریف نشده است" description="از بخش مدیریت ← کارتخوان‌ها، دستگاه را اضافه کنید یا از روش «ثبت دستی» استفاده کنید." />}

      {state === 'idle' && terms.length > 0 && (
        <Space direction="vertical" style={{ width: '100%' }} size={12}>
          {terms.length > 1 && <Select value={tid} onChange={pick} style={{ width: '100%' }} options={terms.map((t) => ({ value: t.id, label: `${t.name} · ${t.driver_title}` }))} />}
          {terms.length === 1 && <Typography.Text type="secondary">{term?.name} · {term?.psp_title}</Typography.Text>}
          <Button type="primary" size="large" block icon={term?.driver === 'manual' ? <EditOutlined /> : <CreditCardOutlined />} onClick={charge} disabled={!tid}>
            {term?.driver === 'manual' ? 'ثبت شماره پیگیری رسید' : 'ارسال مبلغ به کارتخوان'}
          </Button>
          {term?.driver !== 'manual' && <Button block type="link" onClick={() => setState('manual')}>دستگاه وصل نیست؟ ثبت دستی</Button>}
        </Space>
      )}

      {state === 'waiting' && (
        <div className="cc-wait">
          <div className="cc-card"><CreditCardOutlined /></div>
          <b>لطفاً کارت را بکشید و رمز را وارد کنید…</b>
          <small>{term?.name} · {num(secs)} ثانیه</small>
          {stuck && <Alert type="warning" showIcon message="دستگاه پاسخ نمی‌دهد" description="می‌توانید این پنجره را ببندید؛ تراکنش روی کارتخوان را خودتان بررسی کنید." />}
          <Button danger onClick={cancel}>لغو تراکنش</Button>
        </div>
      )}

      {state === 'approved' && (
        <div className="cc-result ok">
          <CheckCircleFilled />
          <b>تراکنش موفق</b>
          <small>شماره پیگیری: <span className="ltr">{res?.rrn}</span>{res?.card && <> · <span className="ltr">{res.card}</span></>}</small>
        </div>
      )}

      {state === 'failed' && (
        <div className="cc-result bad">
          <CloseCircleFilled />
          <b>{res?.status === 'cancelled' ? 'تراکنش لغو شد' : res?.status === 'declined' ? 'تراکنش ناموفق' : 'خطا در ارتباط'}</b>
          <small>{res?.message}{res?.code ? ` (کد ${res.code})` : ''}</small>
          <Space>
            <Button type="primary" icon={<RedoOutlined />} onClick={charge}>تلاش دوباره</Button>
            <Button onClick={() => setState('manual')}>ثبت دستی</Button>
          </Space>
        </div>
      )}

      {state === 'manual' && (
        <Space direction="vertical" style={{ width: '100%' }} size={10}>
          <Alert type="info" showIcon message="مبلغ را روی خود دستگاه وارد کنید و پس از چاپ رسید، شماره پیگیری (مرجع) را اینجا ثبت کنید." />
          <Input size="large" className="ltr" placeholder="شماره پیگیری / مرجع رسید" value={rrn} onChange={(e) => setRrn(e.target.value.replace(/\D/g, ''))} autoFocus />
          <Input className="ltr" placeholder="۴ رقم آخر کارت (اختیاری)" maxLength={4} value={card} onChange={(e) => setCard(e.target.value.replace(/\D/g, ''))} />
          {res?.status === 'error' && <Alert type="error" message={res.message} />}
          <Button type="primary" size="large" block disabled={rrn.length < 4 || !tid} onClick={saveManual}>ثبت پرداخت کارتی</Button>
        </Space>
      )}
    </Modal>
  )
}
