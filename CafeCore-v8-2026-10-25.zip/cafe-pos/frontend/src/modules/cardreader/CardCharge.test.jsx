import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * Sending an amount to the bank card reader and reading the answer back. This is the moment money
 * actually moves, so: the amount is shown, an approved transaction reports its RRN to the caller,
 * a failure says why, and the manual (receipt-number) path is available when the device is offline.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

const { default: CardCharge } = await import('./CardCharge')

const TERMS = [
  { id: 1, name: 'پارس‌کالا', driver: 'bridge', driver_title: 'پل (PC-POS)', psp_title: 'به‌پرداخت ملت', is_active: true },
  { id: 2, name: 'دستی', driver: 'manual', driver_title: 'ثبت دستی', psp_title: '—', is_active: true },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = (props = {}) => render(<App><CardCharge open amount={254_000} orderId={9} onApproved={() => {}} onClose={() => {}} {...props} /></App>)

describe('CardCharge', () => {
  beforeEach(() => {
    get.mockReset(); post.mockReset()
    localStorage.clear()
    get.mockImplementation(() => Promise.resolve([TERMS[0]]))
  })

  it('shows the amount to charge', async () => {
    page()
    await waitFor(() => expect(text()).toContain('۲۵۴٬۰۰۰'))
    expect(text()).toContain('مبلغ')
  })

  it('sends the amount to the terminal and reports the approved RRN', async () => {
    post.mockResolvedValue({ status: 'approved', rrn: '123456789', amount: 254_000, card: '****1234' })
    const onApproved = vi.fn()
    page({ onApproved })
    await waitFor(() => expect(text()).toContain('پارس‌کالا'))
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /ارسال مبلغ/.test(b.textContent)))
    await waitFor(() => expect(post).toHaveBeenCalledWith('/cardreader/charge', expect.objectContaining({ terminal_id: 1, amount: 254_000, order_id: 9 })))
    await waitFor(() => expect(text()).toContain('تراکنش موفق'))
    expect(text()).toContain('123456789')
    await waitFor(() => expect(onApproved).toHaveBeenCalledWith(expect.objectContaining({ rrn: '123456789' })), { timeout: 3000 })
  })

  it('shows why a transaction failed', async () => {
    post.mockRejectedValue(Object.assign(new Error('دستگاه پاسخ نداد'), { status: 502 }))
    page()
    await waitFor(() => expect(text()).toContain('پارس‌کالا'))
    fireEvent.click([...document.querySelectorAll('button')].find((b) => /ارسال مبلغ/.test(b.textContent)))
    await waitFor(() => expect(text()).toMatch(/دستگاه پاسخ نداد|ناموفق/))
  })

  it('offers the manual receipt path and passes the RRN through', async () => {
    post.mockResolvedValue({ status: 'approved', rrn: '987654', amount: 254_000, manual: true })
    const onApproved = vi.fn()
    page({ onApproved })
    await waitFor(() => expect(text()).toContain('پارس‌کالا'))
    fireEvent.click(screen.getByText(/دستگاه وصل نیست/))
    await waitFor(() => expect(text()).toMatch(/شماره پیگیری/))
    const input = document.querySelector('.ant-modal input')
    fireEvent.change(input, { target: { value: '987654' } })
    const save = [...document.querySelectorAll('button')].find((b) => /ثبت|تأیید/.test(b.textContent))
    fireEvent.click(save)
    await waitFor(() => expect(post).toHaveBeenCalledWith('/cardreader/manual', expect.objectContaining({ rrn: '987654', amount: 254_000 })))
  })

  it('explains that no terminal is defined', async () => {
    get.mockImplementation(() => Promise.resolve([]))
    page()
    await waitFor(() => expect(text()).toMatch(/هیچ کارتخوانی تعریف نشده/))
  })
})
