import { ApiOutlined, BankOutlined, CopyOutlined, DeleteOutlined, ExperimentOutlined, SettingOutlined, ShopOutlined, WarningOutlined } from '@ant-design/icons'
import { Alert, App, Badge, Button, Card, Col, DatePicker, Descriptions, Drawer, Empty, Form, Input, InputNumber, Modal, Popconfirm, Row, Segmented, Select, Space, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader, StatCard, DataTag } from '../../components/common'
import { del, post, put } from '../../core/api'
import { faDate, faDateTime, isoDate, money, moneyFormatter, moneyParser, num, timeAgo } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { inkOn } from '../../core/color'

const ST = { new: ['جدید', 'warning'], accepted: ['در حال آماده‌سازی', 'processing'], picked: ['تحویل پیک', 'success'], rejected: ['رد شده', 'error'], cancelled: ['لغو کانال', 'default'] }
const MODE = { test: ['آزمایشی', 'orange'], live: ['اتصال واقعی', 'green'], manual: ['ثبت دستی', 'default'] }

function ChannelDrawer({ ch, onClose, onSaved }) {
  const [form] = Form.useForm()
  const { message } = App.useApp()
  const mode = Form.useWatch('mode', form)
  const [busy, setBusy] = useState(false)
  const origin = window.location.origin
  const save = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy(true)
    try { if (ch?.id) await put(`/marketplace/channels/${ch.id}`, v); else await post('/marketplace/channels', v); message.success('ذخیره شد'); onSaved() } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Drawer open={!!ch} onClose={onClose} width={520} destroyOnClose title={ch?.id ? `تنظیمات ${ch.name}` : 'کانال جدید'} extra={<Button type="primary" loading={busy} onClick={save}>ذخیره</Button>}
      afterOpenChange={(o) => o && form.setFieldsValue(ch?.id ? ch : { mode: 'manual', commission_pct: 20, settlement_days: 7, prep_minutes: 20, color: '#0ea5e9', is_active: true, config: {} })}>
      <Form form={form} layout="vertical">
        <Row gutter={12}>
          <Col span={16}><Form.Item name="name" label="نام کانال" rules={[{ required: true }]}><Input /></Form.Item></Col>
          <Col span={8}><Form.Item name="color" label="رنگ"><Input type="color" /></Form.Item></Col>
          {!ch?.id && <Col span={24}><Form.Item name="key" label="شناسه انگلیسی (در آدرس وب‌هوک)" rules={[{ pattern: /^[a-z0-9_-]{2,20}$/, message: 'فقط حروف کوچک انگلیسی و عدد' }]}><Input className="ltr" placeholder="tapsifood" /></Form.Item></Col>}
          <Col span={8}><Form.Item name="commission_pct" label="کمیسیون"><InputNumber min={0} max={60} step={0.5} addonAfter="٪" style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={8}><Form.Item name="settlement_days" label="دوره تسویه"><InputNumber min={0} max={90} addonAfter="روز" style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={8}><Form.Item name="prep_minutes" label="زمان آماده‌سازی"><InputNumber min={5} max={180} addonAfter="دقیقه" style={{ width: '100%' }} /></Form.Item></Col>
        </Row>
        <Form.Item name="mode" label="نوع اتصال">
          <Segmented block options={Object.entries(MODE).map(([value, [label]]) => ({ value, label }))} />
        </Form.Item>
        {mode === 'test' && <Alert type="warning" showIcon style={{ marginBottom: 16 }} message="حالت آزمایشی: با دکمه «سفارش آزمایشی» سفارش واقعی‌نما ساخته می‌شود و کل مسیر (آشپزخانه، تحویل، کمیسیون، تسویه) را می‌توانید تست کنید." />}
        {mode === 'manual' && <Alert type="info" showIcon style={{ marginBottom: 16 }} message="سفارش‌ها از تبلت کانال با «ثبت سریع» در صندوق وارد می‌شوند؛ کمیسیون و مطالبات خودکار محاسبه می‌شود." />}
        {mode !== 'manual' && <>
          <Typography.Title level={5}>اطلاعات اتصال (پس از عقد قرارداد)</Typography.Title>
          <Form.Item name={['config', 'vendor_code']} label="کد فروشنده (Vendor Code)"><Input className="ltr" /></Form.Item>
          <Form.Item name={['config', 'api_key']} label="کلید API"><Input.Password className="ltr" autoComplete="off" /></Form.Item>
          <Form.Item name={['config', 'status_url']} label="آدرس اعلام وضعیت (تأیید/رد/تحویل)" extra="نرم‌افزار وضعیت سفارش را با امضای HMAC به این آدرس ارسال می‌کند"><Input className="ltr" placeholder="https://…" /></Form.Item>
          <Form.Item name={['config', 'amounts_in_rial']} label="مبالغ وب‌هوک به ریال است" valuePropName="checked"><Switch /></Form.Item>
          {ch?.id && (
            <Descriptions size="small" column={1} bordered style={{ marginBottom: 16 }}>
              <Descriptions.Item label="آدرس وب‌هوک"><Typography.Text copyable className="ltr" style={{ fontSize: 12 }}>{`${origin}${ch.webhook_path}`}</Typography.Text></Descriptions.Item>
              <Descriptions.Item label="کلید امضا"><Typography.Text copyable={{ icon: <CopyOutlined /> }} className="ltr" style={{ fontSize: 12 }}>{ch.config?.webhook_secret}</Typography.Text></Descriptions.Item>
            </Descriptions>
          )}
        </>}
        <Row gutter={12}>
          <Col span={12}><Form.Item name="auto_accept" label="تأیید خودکار سفارش" valuePropName="checked" tooltip="اگر همه اقلام شناخته شده باشند، بدون دخالت صندوقدار به آشپزخانه می‌رود"><Switch /></Form.Item></Col>
          <Col span={12}><Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
    </Drawer>
  )
}

function Orders({ channels }) {
  const [f, setF] = useState({ days: 1, status: undefined, channel_id: undefined })
  const { data, loading } = useFetch('/marketplace/orders', f)
  const [view, setView] = useState(null)
  return (
    <Card extra={<Space wrap>
      <Segmented value={f.days} onChange={(days) => setF({ ...f, days })} options={[{ value: 1, label: 'امروز' }, { value: 7, label: '۷ روز' }, { value: 30, label: '۳۰ روز' }]} />
      <Select allowClear placeholder="کانال" style={{ width: 130 }} value={f.channel_id} onChange={(channel_id) => setF({ ...f, channel_id })} options={channels.map((c) => ({ value: c.id, label: c.name }))} />
      <Select allowClear placeholder="وضعیت" style={{ width: 150 }} value={f.status} onChange={(status) => setF({ ...f, status })} options={Object.entries(ST).map(([value, [label]]) => ({ value, label }))} />
    </Space>} title="سفارش‌ها">
      <Table rowKey="id" size="middle" loading={loading} dataSource={data || []} scroll={{ x: 900 }} onRow={(r) => ({ onClick: () => setView(r), style: { cursor: 'pointer' } })} pagination={{ pageSize: 15, hideOnSinglePage: true }}
        columns={[
          { title: 'زمان', dataIndex: 'created_at', width: 130, render: (v) => faDateTime(v) },
          { title: 'کانال', dataIndex: 'channel', render: (v, r) => <DataTag color={r.color}>{v}</DataTag> },
          { title: 'کد', dataIndex: 'external_id', render: (v) => <span className="ltr">{v}</span> },
          { title: 'اقلام', dataIndex: 'items', render: (v) => <Typography.Text ellipsis style={{ maxWidth: 220 }}>{v.map((i) => `${num(i.qty)}× ${i.name}`).join('، ')}</Typography.Text> },
          { title: 'مبلغ', render: (_, r) => money(r.subtotal - r.vendor_discount) },
          { title: 'کمیسیون', dataIndex: 'commission', render: (v) => <span style={{ color: 'var(--red)' }}>{money(v)}</span> },
          { title: 'خالص', dataIndex: 'net', render: (v) => <b style={{ color: 'var(--green)' }}>{money(v)}</b> },
          { title: 'وضعیت', dataIndex: 'status', render: (v, r) => <Space size={4}><Badge status={ST[v][1]} text={ST[v][0]} />{r.settled && <Tag color="green">تسویه</Tag>}</Space> },
        ]} />
      <Modal open={!!view} onCancel={() => setView(null)} footer={null} title={view && `${view.channel} #${view.external_id}`} width={560}>
        {view && <>
          <Descriptions size="small" column={2} bordered>
            <Descriptions.Item label="مشتری">{view.customer_name || '—'}</Descriptions.Item>
            <Descriptions.Item label="وضعیت">{ST[view.status][0]}</Descriptions.Item>
            <Descriptions.Item label="جمع اقلام">{money(view.subtotal)}</Descriptions.Item>
            <Descriptions.Item label="تخفیف رستوران">{money(view.vendor_discount)}</Descriptions.Item>
            <Descriptions.Item label="تخفیف کانال">{money(view.channel_discount)}</Descriptions.Item>
            <Descriptions.Item label="هزینه ارسال">{money(view.delivery_fee)}</Descriptions.Item>
            <Descriptions.Item label="کمیسیون">{money(view.commission)}</Descriptions.Item>
            <Descriptions.Item label="خالص دریافتی"><b>{money(view.net)}</b></Descriptions.Item>
            {view.reject_reason && <Descriptions.Item label="دلیل" span={2}>{view.reject_reason}</Descriptions.Item>}
          </Descriptions>
          <ul className="oi-items" style={{ marginTop: 12 }}>{view.items.map((i, k) => <li key={k}><b>{num(i.qty)}×</b> {i.name} — {money(i.price)}</li>)}</ul>
          {view.outbound?.length > 0 && <>
            <Typography.Text type="secondary">وضعیت‌های اعلام‌شده به کانال:</Typography.Text>
            {view.outbound.map((o, k) => <div key={k} style={{ fontSize: 12 }}><Tag>{o.status}</Tag>{o.at?.slice(11, 16)} {o.sent ? '✓ ارسال شد' : o.error ? `✗ ${o.error}` : '(آزمایشی، ارسال نشد)'}</div>)}
          </>}
        </>}
      </Modal>
    </Card>
  )
}

function Finance({ channels }) {
  const { message } = App.useApp()
  const rep = useFetch('/marketplace/report')
  const [form] = Form.useForm()
  const [settleOpen, setSettleOpen] = useState(false)
  const r = rep.data
  const name = (id) => channels.find((c) => c.id === id)?.name
  const totals = (r?.channels || []).reduce((a, x) => ({ gross: a.gross + x.gross - x.vendor_discount, commission: a.commission + x.commission, outstanding: a.outstanding + x.outstanding }), { gross: 0, commission: 0, outstanding: 0 })
  const submit = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    try {
      const res = await post('/marketplace/settlements', { ...v, date: isoDate(v.date.toDate()) })
      message.success(`تسویه ثبت شد: ${num(res.orders_count)} سفارش${res.diff ? ` · اختلاف ${money(res.diff)} تومان` : ''}`)
      setSettleOpen(false); form.resetFields(); rep.reload()
    } catch (e) { message.error(e.message) }
  }
  return (
    <>
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={24} md={8}><StatCard loading={rep.loading} title="فروش کانال‌ها (۳۰ روز)" value={totals.gross} money icon={<ShopOutlined />} color="#ff3e6c" /></Col>
        <Col xs={12} md={8}><StatCard loading={rep.loading} title="کمیسیون پرداختی" value={totals.commission} money icon={<ApiOutlined />} color="var(--amber)" /></Col>
        <Col xs={12} md={8}><StatCard loading={rep.loading} title="طلب از کانال‌ها" value={totals.outstanding} money icon={<BankOutlined />} color="var(--pal-1)" hint="تحویل‌شده و تسویه‌نشده" /></Col>
      </Row>
      <Card title="مطالبات به تفکیک کانال" extra={<Button type="primary" icon={<BankOutlined />} onClick={() => setSettleOpen(true)}>ثبت واریز کانال</Button>} loading={rep.loading}>
        <Table rowKey={(x) => x.channel.id} pagination={false} dataSource={r?.channels || []} scroll={{ x: 820 }}
          columns={[
            { title: 'کانال', render: (_, x) => <DataTag color={x.channel.color}>{x.channel.name}</DataTag> },
            { title: 'سفارش موفق', dataIndex: 'orders', render: (v) => num(v) },
            { title: 'رد/لغو', dataIndex: 'rejected', render: (v) => v ? <span style={{ color: 'var(--red)' }}>{num(v)}</span> : '—' },
            { title: 'فروش', render: (_, x) => money(x.gross - x.vendor_discount) },
            { title: 'کمیسیون', render: (_, x) => <span>{money(x.commission)} <small style={{ color: 'var(--muted)' }}>({num(x.channel.commission_pct, 1)}٪)</small></span> },
            { title: 'خالص', dataIndex: 'net', render: (v) => <b>{money(v)}</b> },
            { title: 'طلب فعلی', render: (_, x) => <Space size={4}><b style={{ color: x.overdue ? 'var(--red)' : undefined }}>{money(x.outstanding)}</b>{x.overdue && <Tag color="red" icon={<WarningOutlined />}>معوق</Tag>}</Space> },
            { title: 'قدیمی‌ترین', dataIndex: 'oldest_unsettled', render: (v) => (v ? timeAgo(v) : '—') },
          ]} />
      </Card>
      <Card title="واریزهای ثبت‌شده" style={{ marginTop: 16 }}>
        {!r?.settlements?.length ? <Empty description="هنوز واریزی ثبت نشده" /> : (
          <Table rowKey="id" size="small" pagination={{ pageSize: 10, hideOnSinglePage: true }} dataSource={r.settlements}
            columns={[{ title: 'تاریخ', dataIndex: 'date', render: faDate }, { title: 'کانال', dataIndex: 'channel_id', render: name }, { title: 'مبلغ', dataIndex: 'amount', render: (v) => <b>{money(v)}</b> },
              { title: 'سفارش‌ها', dataIndex: 'orders_count', render: (v) => num(v) }, { title: 'مورد انتظار', dataIndex: 'expected', render: money },
              { title: 'اختلاف', render: (_, s) => (s.amount - s.expected ? <span style={{ color: s.amount < s.expected ? 'var(--red)' : 'var(--green)' }}>{money(s.amount - s.expected)}</span> : '✓') },
              { title: 'مرجع', dataIndex: 'reference', render: (v) => v || '—' }]} />
        )}
      </Card>
      <Modal open={settleOpen} onCancel={() => setSettleOpen(false)} onOk={submit} title="ثبت واریز از کانال فروش" okText="ثبت" cancelText="انصراف" destroyOnClose>
        <Alert type="info" showIcon style={{ marginBottom: 12 }} message="مبلغ واریزی به ترتیب با قدیمی‌ترین سفارش‌های تسویه‌نشده تطبیق داده می‌شود و کمیسیون همان سفارش‌ها خودکار در «هزینه‌ها» ثبت می‌شود." />
        <Form form={form} layout="vertical">
          <Form.Item name="channel_id" label="کانال" rules={[{ required: true }]}><Select options={(r?.channels || []).map((x) => ({ value: x.channel.id, label: `${x.channel.name} — طلب ${money(x.outstanding)}` }))} /></Form.Item>
          <Form.Item name="amount" label="مبلغ واریزی (تومان)" rules={[{ required: true }]}><InputNumber style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item>
          <Form.Item name="date" label="تاریخ واریز" rules={[{ required: true }]}><DatePicker style={{ width: '100%' }} /></Form.Item>
          <Form.Item name="reference" label="شماره پیگیری بانکی"><Input className="ltr" /></Form.Item>
        </Form>
      </Modal>
    </>
  )
}

function Maps({ channels }) {
  const { data, loading, reload } = useFetch('/marketplace/maps')
  return (
    <Card title="اقلام اتصال‌داده‌شده" extra={<Typography.Text type="secondary">محصولات کانال که به منوی شما وصل شده‌اند</Typography.Text>}>
      <Table rowKey="id" loading={loading} dataSource={data || []} pagination={{ pageSize: 15, hideOnSinglePage: true }} locale={{ emptyText: 'اقلامی که با نام دقیق منو یکسان باشند خودکار شناخته می‌شوند و نیازی به اتصال ندارند.' }}
        columns={[{ title: 'کانال', dataIndex: 'channel_id', render: (v) => channels.find((c) => c.id === v)?.name }, { title: 'نام در کانال', dataIndex: 'ext_name' }, { title: 'کد', dataIndex: 'ext_key', render: (v) => <span className="ltr">{v}</span> },
          { title: 'کالای منو', dataIndex: 'menu_name', render: (v) => <b>{v}</b> },
          { width: 60, render: (_, r) => <Popconfirm title="حذف اتصال؟" onConfirm={async () => { await del(`/marketplace/maps/${r.id}`); reload() }}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm> }]} />
    </Card>
  )
}

export default function Marketplace() {
  const { message } = App.useApp()
  const ch = useFetch('/marketplace/channels')
  const [edit, setEdit] = useState(null)
  const [tab, setTab] = useState('orders')
  const [rk, setRk] = useState(0)
  const channels = ch.data || []
  const simulate = async (c) => {
    try { const r = await post(`/marketplace/channels/${c.id}/simulate`); message.success(`سفارش آزمایشی ${r.external_id} ساخته شد — در صندوق، دکمه «اسنپ‌فود» را ببینید`); setRk(rk + 1) } catch (e) { message.error(e.message) }
  }
  return (
    <div>
      <PageHeader title="کانال‌های فروش" subtitle="اسنپ‌فود، تپسی‌فود و سایر پلتفرم‌ها — سفارش، کمیسیون، مطالبات و تسویه" icon={<ShopOutlined />}
        extra={<Button icon={<SettingOutlined />} onClick={() => setEdit({})}>کانال جدید</Button>} />
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        {channels.map((c) => (
          <Col xs={24} md={12} xl={8} key={c.id}>
            <Card className="mk-ch" style={{ '--c': c.color }} actions={[
              <Button key="s" type="text" icon={<SettingOutlined />} onClick={() => setEdit(c)}>تنظیمات</Button>,
              c.mode === 'test' && <Button key="t" type="text" icon={<ExperimentOutlined />} onClick={() => simulate(c)}>سفارش آزمایشی</Button>,
            ].filter(Boolean)}>
              <div className="mk-ch-head">
                <div className="mk-ch-logo" style={{ color: inkOn(c.color) }}>{c.name.slice(0, 1)}</div>
                <div><b>{c.name}</b><div><Tag color={MODE[c.mode][1]}>{MODE[c.mode][0]}</Tag>{c.auto_accept && <Tag color="blue">تأیید خودکار</Tag>}{!c.is_active && <Tag color="red">غیرفعال</Tag>}</div></div>
              </div>
              <div className="cr-info">
                <div><span>کمیسیون</span><b>{num(c.commission_pct, 1)}٪</b></div>
                <div><span>دوره تسویه</span><span>{num(c.settlement_days)} روز</span></div>
              </div>
            </Card>
          </Col>
        ))}
      </Row>
      <Tabs activeKey={tab} onChange={setTab} destroyInactiveTabPane items={[
        { key: 'orders', label: 'سفارش‌ها', children: <Orders key={rk} channels={channels} /> },
        { key: 'finance', label: 'مطالبات و تسویه', children: <Finance channels={channels} /> },
        { key: 'maps', label: 'اتصال اقلام', children: <Maps channels={channels} /> },
      ]} />
      <ChannelDrawer ch={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); ch.reload() }} />
    </div>
  )
}
