import { CarOutlined, CheckOutlined, CloseOutlined, LinkOutlined, PlusOutlined, ShopOutlined } from '@ant-design/icons'
import { Alert, App, Badge, Button, Drawer, Empty, Form, Input, InputNumber, Modal, Select, Space, Tabs, Tag } from 'antd'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { get, post } from '../../core/api'
import { money, moneyFormatter, moneyParser, num, timeAgo } from '../../core/format'
import { beep, useRealtime } from '../../core/realtime'
import { DataTag } from '../../components/common'

const REASONS = ['اتمام موجودی برخی اقلام', 'حجم بالای سفارش‌ها', 'خارج از ساعت کاری', 'مشکل فنی']

function useMenuItems(open) {
  const [items, setItems] = useState([])
  useEffect(() => { if (open && !items.length) get('/menu/items').then((r) => setItems(r.filter((i) => i.is_active !== false))).catch(() => {}) }, [open, items.length])
  return items
}

export function MarketCard({ m, busy, onAccept, onReject, onPicked, onMap }) {
  return (
    <div className="mk-card" style={{ '--c': m.color }}>
      <div className="oi-head">
        <DataTag color={m.color}>{m.channel}</DataTag>
        <b className="ltr">#{m.external_id}</b>
        <span className="oi-time">{timeAgo(m.created_at)}</span>
      </div>
      {m.customer_name && <div className="oi-cust">{m.customer_name} {m.phone && <span className="ltr" style={{ fontWeight: 400 }}>{m.phone}</span>}</div>}
      <ul className="oi-items">
        {m.items.map((i, k) => <li key={k} className={i.menu_item_id ? '' : 'mk-unmapped'}><b>{num(i.qty)}×</b> {i.name}{!i.menu_item_id && <Tag color="red" style={{ marginInlineStart: 6 }}>نامشخص در منو</Tag>}{i.note ? <small> — {i.note}</small> : null}</li>)}
      </ul>
      {m.note && <div className="oi-note">📝 {m.note}</div>}
      <div className="mk-money">
        <span>مبلغ: <b>{money(m.subtotal - m.vendor_discount)}</b></span>
        <span>کمیسیون: <b style={{ color: 'var(--red)' }}>{money(m.commission)}</b></span>
        <span>خالص: <b style={{ color: 'var(--green)' }}>{money(m.net)}</b></span>
      </div>
      <div className="oi-foot">
        {m.status === 'new' && (
          <Space size={6} style={{ marginInlineStart: 'auto' }}>
            {m.unmapped > 0 && <Button size="small" icon={<LinkOutlined />} onClick={() => onMap(m)}>اتصال اقلام به منو</Button>}
            <Button size="small" danger icon={<CloseOutlined />} onClick={() => onReject(m)} disabled={!!busy} />
            <Button size="small" type="primary" icon={<CheckOutlined />} loading={busy === m.id} disabled={m.unmapped > 0} onClick={() => onAccept(m)}>تأیید</Button>
          </Space>
        )}
        {m.status === 'accepted' && (
          <Space size={6} style={{ marginInlineStart: 'auto' }}>
            <Tag color="processing">در حال آماده‌سازی · {timeAgo(m.accepted_at)}</Tag>
            <Button size="small" type="primary" icon={<CarOutlined />} loading={busy === m.id} onClick={() => onPicked(m)}>تحویل به پیک</Button>
          </Space>
        )}
      </div>
    </div>
  )
}

function MapDialog({ target, items, onClose, onDone }) {
  const { message } = App.useApp()
  const [maps, setMaps] = useState({})
  useEffect(() => { setMaps({}) }, [target])
  if (!target) return null
  const opts = items.map((i) => ({ value: i.id, label: `${i.name} — ${money(i.price)}` }))
  return (
    <Modal open title="اتصال اقلام کانال به منوی شما" okText="ذخیره" cancelText="انصراف" onCancel={onClose}
      onOk={async () => { try { await post(`/marketplace/orders/${target.id}/map`, { maps }); message.success('ذخیره شد؛ دفعه بعد خودکار شناخته می‌شود'); onDone() } catch (e) { message.error(e.message) } }}>
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="هر محصول فقط یک بار اتصال داده می‌شود و در سفارش‌های بعدی خودکار شناسایی خواهد شد (برای کسر صحیح انبار و گزارش فروش)." />
      {target.items.map((it, idx) => !it.menu_item_id && (
        <div key={idx} className="mk-map-row">
          <span>{it.name} <small>({money(it.price)})</small></span>
          <Select showSearch optionFilterProp="label" placeholder="انتخاب از منو" style={{ width: 240 }} options={opts} value={maps[idx]} onChange={(v) => setMaps({ ...maps, [idx]: v })} />
        </div>
      ))}
    </Modal>
  )
}

function QuickEntry({ open, channels, items, onClose, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const lines = Form.useWatch('items', form) || []
  const priceOf = useMemo(() => Object.fromEntries(items.map((i) => [i.id, i.price])), [items])
  const sum = lines.reduce((a, l) => a + (l?.menu_item_id ? (priceOf[l.menu_item_id] || 0) * (l.qty || 1) : 0), 0)
  const [busy, setBusy] = useState(false)
  const submit = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy(true)
    try {
      await post('/marketplace/orders/manual', { ...v, subtotal: v.subtotal || undefined, items: v.items.filter((x) => x?.menu_item_id) })
      message.success('سفارش ثبت و به آشپزخانه ارسال شد'); form.resetFields(); onDone()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open={open} onCancel={onClose} title="ثبت سریع سفارش کانال فروش" okText="ثبت و ارسال به آشپزخانه" cancelText="انصراف" onOk={submit} confirmLoading={busy} width={560} destroyOnClose>
      <Form form={form} layout="vertical" initialValues={{ channel_id: channels[0]?.id, items: [{ qty: 1 }], vendor_discount: 0 }}>
        <Space.Compact block>
          <Form.Item name="channel_id" label="کانال" rules={[{ required: true }]} style={{ flex: 1 }}><Select options={channels.map((c) => ({ value: c.id, label: c.name }))} /></Form.Item>
          <Form.Item name="external_id" label="کد سفارش در کانال" style={{ flex: 1 }}><Input className="ltr" /></Form.Item>
        </Space.Compact>
        <Form.List name="items">
          {(fields, { add, remove }) => (
            <>
              {fields.map((f) => (
                <Space key={f.key} align="baseline" style={{ display: 'flex' }}>
                  <Form.Item name={[f.name, 'menu_item_id']} rules={[{ required: true, message: 'انتخاب کنید' }]} style={{ width: 330 }}>
                    <Select showSearch optionFilterProp="label" placeholder="کالا" options={items.map((i) => ({ value: i.id, label: i.name }))} />
                  </Form.Item>
                  <Form.Item name={[f.name, 'qty']}><InputNumber min={1} max={99} style={{ width: 80 }} /></Form.Item>
                  {fields.length > 1 && <Button type="text" danger icon={<CloseOutlined />} onClick={() => remove(f.name)} />}
                </Space>
              ))}
              <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({ qty: 1 })} style={{ marginBottom: 12 }}>افزودن قلم</Button>
            </>
          )}
        </Form.List>
        <Space.Compact block>
          <Form.Item name="subtotal" label="مبلغ در کانال (اگر با منو فرق دارد)" style={{ flex: 1 }}><InputNumber placeholder={money(sum)} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item>
          <Form.Item name="vendor_discount" label="تخفیف سهم رستوران" style={{ flex: 1 }}><InputNumber style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item>
        </Space.Compact>
        <Form.Item name="customer_name" label="نام مشتری"><Input /></Form.Item>
      </Form>
    </Modal>
  )
}

/** POS header button for SnappFood & other marketplace orders. */
export default function MarketInbox({ mobile, onChanged }) {
  const { message, notification, modal } = App.useApp()
  const [list, setList] = useState([])
  const [channels, setChannels] = useState([])
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(null)
  const [mapT, setMapT] = useState(null)
  const [quick, setQuick] = useState(false)
  const items = useMenuItems(open)
  const load = useCallback(() => get('/marketplace/orders', { active: true }).then(setList).catch(() => {}), [])
  useEffect(() => { load(); get('/marketplace/channels').then((c) => setChannels(c.filter((x) => x.is_active))).catch(() => {}) }, [load])
  useEffect(() => { const id = setInterval(load, 60000); return () => clearInterval(id) }, [load])
  useRealtime(['market.changed', '_reconnected'], load)
  useRealtime('market.new', (d) => {
    beep('call')
    notification.info({ key: `mk-${d.id}`, duration: 15, icon: <ShopOutlined style={{ color: '#ff3e6c' }} />, message: `سفارش جدید ${d.channel}`, description: `کد ${d.number}`,
      btn: <Button type="primary" size="small" onClick={() => { notification.destroy(`mk-${d.id}`); setOpen(true) }}>بررسی</Button> })
    load()
  })
  const act = async (m, path, ok, body) => {
    setBusy(m.id)
    try { await post(`/marketplace/orders/${m.id}/${path}`, body); message.success(ok); load(); onChanged?.() } catch (e) { message.error(e.message); load() } finally { setBusy(null) }
  }
  const reject = (m) => {
    let reason = REASONS[0]
    modal.confirm({ title: `رد سفارش ${m.channel} #${m.external_id}`, okText: 'رد سفارش', okType: 'danger', cancelText: 'انصراف',
      content: <Select defaultValue={reason} style={{ width: '100%', marginTop: 8 }} onChange={(v) => { reason = v }} options={REASONS.map((r) => ({ value: r, label: r }))} />,
      onOk: () => act(m, 'reject', 'سفارش رد شد', { reason }) })
  }
  const fresh = list.filter((m) => m.status === 'new')
  const doing = list.filter((m) => m.status === 'accepted')
  const cards = (arr) => (arr.length ? arr.map((m) => <MarketCard key={m.id} m={m} busy={busy} onMap={setMapT} onReject={reject}
    onAccept={(x) => act(x, 'accept', 'سفارش تأیید و به آشپزخانه ارسال شد')} onPicked={(x) => act(x, 'picked', 'تحویل پیک شد و سفارش بسته شد')} />) : <Empty description="موردی نیست" />)

  return (
    <>
      <Badge count={fresh.length} size="small" color="#ff3e6c">
        <Button icon={<ShopOutlined />} className={fresh.length ? 'ring' : ''} onClick={() => setOpen(true)}>{!mobile && 'اسنپ‌فود'}</Button>
      </Badge>
      <Drawer open={open} onClose={() => setOpen(false)} width={mobile ? '100%' : 480} title={<span><ShopOutlined /> سفارش‌های کانال‌های فروش</span>}
        extra={<Button icon={<PlusOutlined />} onClick={() => setQuick(true)}>ثبت سریع</Button>}>
        <Tabs items={[
          { key: 'new', label: <span>جدید {fresh.length > 0 && <Badge count={fresh.length} color="#ff3e6c" />}</span>, children: cards(fresh) },
          { key: 'doing', label: <span>در حال آماده‌سازی ({num(doing.length)})</span>, children: cards(doing) },
        ]} />
      </Drawer>
      <MapDialog target={mapT} items={items} onClose={() => setMapT(null)} onDone={() => { setMapT(null); load() }} />
      <QuickEntry open={quick} channels={channels} items={items} onClose={() => setQuick(false)} onDone={() => { setQuick(false); load(); onChanged?.() }} />
    </>
  )
}
