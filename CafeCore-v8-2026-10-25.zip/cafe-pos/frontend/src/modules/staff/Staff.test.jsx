import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Staff & access. Adding an employee means creating a login: username rules and the PIN format are
// the two fields that, if wrong, lock somebody out or let them into the drawer.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
const put = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
const auth = { can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))

const { default: Staff } = await import('./Staff')

const ROLES = [
  { id: 1, name: 'admin', title: 'مدیر کل', permissions: ['*'] },
  { id: 3, name: 'cashier', title: 'صندوقدار', permissions: ['pos.access', 'payments.take'] },
  { id: 4, name: 'waiter', title: 'گارسون', permissions: ['pos.access'] },
]
const USERS = [
  { id: 1, full_name: 'مدیر سیستم', username: 'admin', role_id: 1, phone: null, has_pin: true, last_login: '2026-10-23T09:00:00', is_active: true },
  { id: 4, full_name: 'رضا صندوق‌دار', username: 'reza', role_id: 3, phone: '09121110022', has_pin: true, last_login: null, is_active: true },
]

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/staff/users') return Promise.resolve(USERS)
    if (path === '/staff/roles') return Promise.resolve(ROLES)
    if (path === '/staff/permissions') return Promise.resolve({})
    return Promise.resolve([])
  })
}
const page = () => render(<App><Staff /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Staff & access', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); put.mockReset() })

  it('lists users with their role and PIN state', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('رضا صندوق'))
    expect(text()).toContain('صندوقدار')
    expect(text()).toContain('PIN دارد')
    expect(text()).toContain('reza')
  })

  it('refuses to deactivate the account you are logged in with', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('مدیر سیستم'))
    const switches = [...document.querySelectorAll('.ant-switch')]
    expect(switches[0].classList.contains('ant-switch-disabled')).toBe(true)     // own account
    expect(switches[1].classList.contains('ant-switch-disabled')).toBe(false)    // other account
  })

  it('rejects an invalid username instead of creating an unusable login', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('رضا صندوق'))
    await user().click(screen.getByRole('button', { name: /کاربر جدید/ }))
    const dlg = await screen.findByRole('dialog')
    const inputs = dlg.querySelectorAll('input')
    await user().type(inputs[0], 'کاربر تست')             // full name
    await user().type(inputs[1], 'ab')                   // too short username
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(text()).toContain('۳ حرف انگلیسی'))
    expect(post).not.toHaveBeenCalled()
  })

  it('rejects a PIN that is not 4–8 digits', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('رضا صندوق'))
    await user().click(screen.getByRole('button', { name: /کاربر جدید/ }))
    const dlg = await screen.findByRole('dialog')
    const pins = [...dlg.querySelectorAll('input')].filter((i) => i.getAttribute('maxlength') === '8')
    await user().type(pins[0], '12')
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(text()).toContain('۴ تا ۸ رقم'))
    expect(post).not.toHaveBeenCalled()
  })

  it('creates a user with a blank password sent as null, never as an empty string', async () => {
    post.mockResolvedValue({ id: 10 })
    respond()
    page()
    await waitFor(() => expect(text()).toContain('رضا صندوق'))
    await user().click(screen.getByRole('button', { name: /کاربر جدید/ }))
    const dlg = await screen.findByRole('dialog')
    const inputs = dlg.querySelectorAll('input')
    await user().type(inputs[0], 'نگار تست')
    await user().type(inputs[1], 'negar')
    // password field
    const pw = [...dlg.querySelectorAll('input')].find((i) => i.getAttribute('type') === 'password')
    await user().type(pw, 'secret123')
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalled())
    const body = post.mock.calls[0][1]
    expect(body.username).toBe('negar')
    expect(body.password).toBe('secret123')
    expect(body.pin).toBeNull()                     // untouched PIN must not be sent as ''
  })
})
