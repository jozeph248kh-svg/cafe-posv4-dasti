import { DeleteOutlined, EditOutlined, KeyOutlined, LockOutlined, PlusOutlined, SafetyOutlined } from '@ant-design/icons'
import { App, Avatar, Button, Card, Checkbox, Col, Divider, Form, Input, Modal, Popconfirm, Row, Select, Space, Switch, Table, Tabs, Tag, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader } from '../../components/common'
import { del, post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { colorOf, faDateTime, initials, num, timeAgo } from '../../core/format'
import { useFetch } from '../../core/useFetch'

const ROLE_COLORS = { admin: 'magenta', manager: 'purple', cashier: 'blue', waiter: 'green', kitchen: 'orange' }

function UsersTab({ roles }) {
  const auth = useAuth()
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/staff/users')
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const roleMap = Object.fromEntries(roles.map((r) => [r.id, r]))
  const save = async (v) => {
    try {
      const body = { ...v, password: v.password || null, pin: v.pin || null }
      if (edit.id) await put(`/staff/users/${edit.id}`, body); else await post('/staff/users', body)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const quickActive = async (u, v) => { try { await put(`/staff/users/${u.id}`, { ...u, is_active: v, password: null, pin: null }); reload(true) } catch (e) { message.error(e.message) } }
  return (
    <>
      <Button type="primary" icon={<PlusOutlined />} style={{ marginBottom: 14 }} onClick={() => { form.resetFields(); form.setFieldsValue({ is_active: true, role_id: roles.find((r) => r.name === 'waiter')?.id }); setEdit({}) }}>کاربر جدید</Button>
      <Table rowKey="id" loading={loading} dataSource={data || []} pagination={false} scroll={{ x: 760 }}
        columns={[
          { title: 'نام', dataIndex: 'full_name', render: (v, r) => <Space><Avatar style={{ background: colorOf(v) }}>{initials(v)}</Avatar><div><b>{v}</b><div className="ltr muted" style={{ fontSize: 12, textAlign: 'right' }}>{r.username}</div></div></Space> },
          { title: 'نقش', dataIndex: 'role_id', render: (v) => <Tag color={ROLE_COLORS[roleMap[v]?.name] || 'geekblue'}>{roleMap[v]?.title}</Tag> },
          { title: 'تلفن', dataIndex: 'phone', render: (v) => <span className="ltr">{v || '—'}</span> },
          { title: 'ورود سریع', dataIndex: 'has_pin', render: (v) => (v ? <Tag icon={<KeyOutlined />} color="cyan">PIN دارد</Tag> : <Tag>ندارد</Tag>) },
          { title: 'آخرین ورود', dataIndex: 'last_login', render: (v) => (v ? <span title={faDateTime(v)}>{timeAgo(v)}</span> : '—') },
          { title: 'فعال', dataIndex: 'is_active', render: (v, r) => <Switch size="small" checked={v} disabled={r.id === auth.user.id} onChange={(x) => quickActive(r, x)} /> },
          { title: '', render: (_, r) => <Button type="text" icon={<EditOutlined />} onClick={() => { form.resetFields(); form.setFieldsValue({ ...r, password: '', pin: '' }); setEdit(r) }} /> },
        ]} />
      <Modal open={!!edit} title={edit?.id ? `ویرایش ${edit.full_name}` : 'کاربر جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="full_name" label="نام و نام خانوادگی" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={12}><Form.Item name="username" label="نام کاربری (انگلیسی)" rules={[{ required: true, pattern: /^[A-Za-z0-9_.]{3,}$/, message: 'حداقل ۳ حرف انگلیسی' }]}><Input className="ltr" /></Form.Item></Col>
            <Col span={12}><Form.Item name="role_id" label="نقش" rules={[{ required: true }]}><Select options={roles.map((r) => ({ value: r.id, label: r.title }))} /></Form.Item></Col>
            <Col span={12}><Form.Item name="phone" label="موبایل"><Input className="ltr" /></Form.Item></Col>
            <Col span={12}><Form.Item name="password" label={edit?.id ? 'رمز جدید (اختیاری)' : 'رمز عبور'} rules={[{ required: !edit?.id, min: 6, message: 'حداقل ۶ کاراکتر' }]}><Input.Password prefix={<LockOutlined />} autoComplete="new-password" /></Form.Item></Col>
            <Col span={12}><Form.Item name="pin" label={edit?.has_pin ? 'PIN جدید (اختیاری)' : 'کد PIN ورود سریع'} rules={[{ pattern: /^\d{4,8}$/, message: '۴ تا ۸ رقم' }]} tooltip="برای ورود سریع در صندوق و تأیید مدیر"><Input.Password className="ltr" inputMode="numeric" maxLength={8} autoComplete="off" /></Form.Item></Col>
          </Row>
          <Space size={24}>
            <Form.Item name="is_active" valuePropName="checked"><Checkbox>فعال</Checkbox></Form.Item>
            {edit?.has_pin && <Form.Item name="clear_pin" valuePropName="checked"><Checkbox>حذف PIN</Checkbox></Form.Item>}
          </Space>
        </Form>
      </Modal>
    </>
  )
}

function RolesTab({ roles, reload }) {
  const { message } = App.useApp()
  const perms = useFetch('/staff/permissions')
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    try {
      if (edit.id) await put(`/staff/roles/${edit.id}`, v); else await post('/staff/roles', v)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const total = Object.values(perms.data || {}).reduce((a, g) => a + Object.keys(g.items).length, 0)
  return (
    <>
      <Button type="primary" icon={<PlusOutlined />} style={{ marginBottom: 14 }} onClick={() => { form.resetFields(); form.setFieldsValue({ permissions: [] }); setEdit({}) }}>نقش جدید</Button>
      <Row gutter={[16, 16]}>
        {roles.map((r) => (
          <Col key={r.id} xs={24} md={12} xl={8}>
            <Card className="card-r hover-lift" size="small"
              title={<Space><SafetyOutlined /><b>{r.title}</b>{r.is_system && <Tag>سیستمی</Tag>}</Space>}
              extra={<Space size={0}>
                {!r.permissions.includes('*') && <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(r); setEdit(r) }} />}
                {!r.is_system && <Popconfirm title="نقش حذف شود؟" onConfirm={() => del(`/staff/roles/${r.id}`).then(reload).catch((e) => message.error(e.message))}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>}
              </Space>}>
              {r.permissions.includes('*') ? <Tag color="magenta">دسترسی کامل به همه بخش‌ها</Tag> : (
                <>
                  <Typography.Text type="secondary">{num(r.permissions.length)} از {num(total)} دسترسی</Typography.Text>
                  <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {r.permissions.slice(0, 8).map((p) => <Tag key={p} style={{ margin: 0 }}>{Object.values(perms.data || {}).find((g) => g.items[p])?.items[p] || p}</Tag>)}
                    {r.permissions.length > 8 && <Tag>+{num(r.permissions.length - 8)}</Tag>}
                  </div>
                </>
              )}
            </Card>
          </Col>
        ))}
      </Row>
      <Modal open={!!edit} title={edit?.id ? `دسترسی‌های «${edit.title}»` : 'نقش جدید'} width={720} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="title" label="عنوان نقش" rules={[{ required: true, min: 2 }]}><Input placeholder="مثلاً: سرگارسون" /></Form.Item></Col>
            <Col span={12}><Form.Item name="name" label="شناسه (انگلیسی)" rules={[{ required: true, pattern: /^[a-z0-9_]{2,}$/, message: 'حروف کوچک انگلیسی' }]}><Input className="ltr" disabled={edit?.is_system} /></Form.Item></Col>
          </Row>
          <Form.Item name="permissions" label="دسترسی‌ها">
            <Checkbox.Group style={{ width: '100%' }}>
              {Object.entries(perms.data || {}).map(([mod, g]) => (
                <div key={mod} style={{ marginBottom: 6 }}>
                  <Divider orientation="right" plain style={{ margin: '8px 0' }}><b>{g.title}</b></Divider>
                  <Row gutter={[8, 6]}>{Object.entries(g.items).map(([code, t]) => <Col key={code} xs={24} sm={12}><Checkbox value={code}>{t}</Checkbox></Col>)}</Row>
                </div>
              ))}
            </Checkbox.Group>
          </Form.Item>
        </Form>
      </Modal>
    </>
  )
}

export default function Staff() {
  const roles = useFetch('/staff/roles')
  return (
    <div className="fade-in">
      <PageHeader title="پرسنل و دسترسی" subtitle="کاربران، کد ورود سریع (PIN) و نقش‌ها با دسترسی دقیق به هر بخش" />
      <Card className="card-r" loading={!roles.data}>
        {roles.data && <Tabs items={[
          { key: 'u', label: 'کاربران', children: <UsersTab roles={roles.data} /> },
          { key: 'r', label: 'نقش‌ها و دسترسی‌ها', children: <RolesTab roles={roles.data} reload={() => roles.reload(true)} /> },
        ]} />}
      </Card>
    </div>
  )
}
