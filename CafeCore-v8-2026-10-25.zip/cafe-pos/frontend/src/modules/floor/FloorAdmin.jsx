import { DeleteOutlined, EditOutlined, PlusOutlined, PrinterOutlined, QrcodeOutlined, ReloadOutlined, SaveOutlined } from '@ant-design/icons'
import { App, Button, Card, Checkbox, Col, Empty, Form, Input, InputNumber, Modal, Popconfirm, QRCode, Row, Segmented, Select, Space, Table, Tabs, Tag, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { PageHeader } from '../../components/common'
import { del, post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { num } from '../../core/format'
import { printHtml } from '../../core/print'
import { useFetch } from '../../core/useFetch'

const SHAPES = { square: 'مربع', round: 'گرد', rect: 'مستطیل' }

function PlanEditor({ tables, onSave }) {
  const [pos, setPos] = useState({})
  const [over, setOver] = useState(null)
  const [drag, setDrag] = useState(null)
  useEffect(() => setPos(Object.fromEntries(tables.map((t) => [t.id, { x: t.x, y: t.y }]))), [tables])
  const cols = Math.max(6, ...Object.values(pos).map((p) => p.x + 2))
  const rows = Math.max(3, ...Object.values(pos).map((p) => p.y + 2))
  const at = (x, y) => tables.find((t) => pos[t.id]?.x === x && pos[t.id]?.y === y)
  const drop = (x, y) => {
    if (!drag) return
    const other = at(x, y)
    const from = pos[drag]
    setPos({ ...pos, [drag]: { x, y }, ...(other && other.id !== drag ? { [other.id]: from } : {}) })
    setDrag(null); setOver(null)
  }
  const dirty = tables.some((t) => pos[t.id] && (pos[t.id].x !== t.x || pos[t.id].y !== t.y))
  return (
    <>
      <Space style={{ marginBottom: 10 }}>
        <Typography.Text type="secondary">میزها را بکشید و در جای واقعی‌شان رها کنید؛ صندوق همین چیدمان را نمایش می‌دهد.</Typography.Text>
        <Button type="primary" icon={<SaveOutlined />} disabled={!dirty} onClick={() => onSave(Object.entries(pos).map(([id, p]) => ({ id: Number(id), ...p })))}>ذخیره چیدمان</Button>
      </Space>
      <div className="plan-grid" style={{ gridTemplateColumns: `repeat(${cols}, minmax(90px, 1fr))` }}>
        {Array.from({ length: rows * cols }).map((_, i) => {
          const x = i % cols
          const y = Math.floor(i / cols)
          const t = at(x, y)
          return (
            <div key={i} className={`plan-cell ${over === i ? 'over' : ''}`} onDragOver={(e) => { e.preventDefault(); setOver(i) }} onDragLeave={() => setOver(null)} onDrop={() => drop(x, y)}>
              {t && (
                <div className={`plan-table ${t.shape}`} draggable onDragStart={() => setDrag(t.id)} onDragEnd={() => setDrag(null)}>
                  <b>{t.name}</b><small>{num(t.seats)} نفره</small>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </>
  )
}

export default function FloorAdmin() {
  const auth = useAuth()
  const { message } = App.useApp()
  const areas = useFetch('/floor/areas')
  const tables = useFetch('/floor/tables')
  const [area, setArea] = useState(null)
  const [mode, setMode] = useState('plan')
  const [editT, setEditT] = useState(null)
  const [editA, setEditA] = useState(null)
  const [qr, setQr] = useState(null)
  const [tf] = Form.useForm()
  const [af] = Form.useForm()
  useEffect(() => { if (areas.data?.length && !areas.data.some((a) => a.id === area)) setArea(areas.data[0].id) }, [areas.data, area])
  const list = useMemo(() => (tables.data || []).filter((t) => t.area_id === area), [tables.data, area])
  const reload = () => { areas.reload(true); tables.reload(true) }
  const baseUrl = (auth.system.lan_urls?.[0] || window.location.origin)
  const qrUrl = (t) => `${baseUrl}/menu/${t.qr_token}`

  const saveTable = async (v) => {
    try {
      const body = { ...editT, ...v, area_id: v.area_id || area }
      if (!editT.id) {
        const used = new Set(list.map((t) => `${t.x}-${t.y}`))
        let i = 0
        while (used.has(`${i % 6}-${Math.floor(i / 6)}`)) i++
        Object.assign(body, { x: i % 6, y: Math.floor(i / 6), sort: list.length })
      }
      if (editT.id) await put(`/floor/tables/${editT.id}`, body); else await post('/floor/tables', body)
      message.success('ذخیره شد'); setEditT(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const saveArea = async (v) => {
    try {
      if (editA.id) await put(`/floor/areas/${editA.id}`, { ...editA, ...v }); else { const a = await post('/floor/areas', { ...v, sort: areas.data.length }); setArea(a.id) }
      message.success('ذخیره شد'); setEditA(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const printQrs = (ts) => {
    const cards = ts.map((t) => {
      const canvas = document.querySelector(`#qr-${t.id} canvas`)
      return `<div style="page-break-inside:avoid;border:1px dashed #999;border-radius:12px;padding:12px;margin:6px;text-align:center;width:62mm;display:inline-block">
        <div style="font-weight:800;font-size:15px">${auth.settings['business.name'] || ''}</div>
        ${canvas ? `<img src="${canvas.toDataURL()}" style="width:48mm;height:48mm">` : ''}
        <div style="font-size:22px;font-weight:900">میز ${t.name}</div><div style="font-size:11px">برای مشاهده منو و صدا زدن گارسون اسکن کنید</div></div>`
    }).join('')
    printHtml(`<div style="width:auto">${cards}</div>`, { css: '@page{size:A4;margin:10mm} body{width:auto}' })
  }

  return (
    <div className="fade-in">
      <PageHeader title="سالن و میزها" subtitle="تعریف سالن‌ها، میزها، چیدمان و کد QR منوی دیجیتال هر میز"
        extra={[
          <Button key="a" icon={<PlusOutlined />} onClick={() => { af.resetFields(); setEditA({}) }}>سالن جدید</Button>,
          <Button key="t" type="primary" icon={<PlusOutlined />} disabled={!area} onClick={() => { tf.resetFields(); tf.setFieldsValue({ seats: 4, shape: 'square', is_active: true, area_id: area }); setEditT({}) }}>میز جدید</Button>,
        ]} />
      <Card className="card-r" loading={!areas.data || !tables.data}>
        {areas.data?.length ? (
          <>
            <Tabs activeKey={String(area)} onChange={(k) => setArea(Number(k))}
              items={areas.data.map((a) => ({ key: String(a.id), label: a.name }))}
              tabBarExtraContent={(
                <Space>
                  <Button size="small" icon={<EditOutlined />} onClick={() => { const a = areas.data.find((x) => x.id === area); af.setFieldsValue(a); setEditA(a) }}>ویرایش سالن</Button>
                  <Popconfirm title="سالن حذف شود؟" onConfirm={() => del(`/floor/areas/${area}`).then(reload).catch((e) => message.error(e.message))}><Button size="small" danger icon={<DeleteOutlined />} /></Popconfirm>
                </Space>
              )} />
            <Space style={{ marginBottom: 14 }} wrap>
              <Segmented value={mode} onChange={setMode} options={[{ value: 'plan', label: 'نقشه سالن' }, { value: 'list', label: 'فهرست میزها' }, { value: 'qr', label: 'کدهای QR' }]} />
            </Space>
            {mode === 'plan' && (list.length ? <PlanEditor tables={list} onSave={async (p) => { await post('/floor/tables/positions', p); message.success('چیدمان ذخیره شد'); reload() }} /> : <Empty description="میزی در این سالن نیست" />)}
            {mode === 'list' && (
              <Table rowKey="id" dataSource={list} pagination={false}
                columns={[
                  { title: 'میز', dataIndex: 'name', render: (v) => <b style={{ fontSize: 16 }}>{v}</b> },
                  { title: 'ظرفیت', dataIndex: 'seats', render: (v) => `${num(v)} نفر` },
                  { title: 'شکل', dataIndex: 'shape', render: (v) => SHAPES[v] },
                  { title: 'وضعیت', dataIndex: 'is_active', render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
                  { title: '', render: (_, t) => (
                    <Space size={0}>
                      <Button type="text" icon={<QrcodeOutlined />} onClick={() => setQr(t)} />
                      <Button type="text" icon={<EditOutlined />} onClick={() => { tf.setFieldsValue(t); setEditT(t) }} />
                      <Popconfirm title="میز حذف شود؟" onConfirm={() => del(`/floor/tables/${t.id}`).then(reload).catch((e) => message.error(e.message))}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>
                    </Space>
                  ) },
                ]} />
            )}
            {mode === 'qr' && (
              <>
                <Space style={{ marginBottom: 12 }}>
                  <Button icon={<PrinterOutlined />} type="primary" onClick={() => printQrs(list)}>چاپ همه کدهای این سالن</Button>
                  <Typography.Text type="secondary">آدرس پایه: <span className="ltr">{baseUrl}</span></Typography.Text>
                </Space>
                <Row gutter={[16, 16]}>
                  {list.map((t) => (
                    <Col key={t.id} xs={12} md={8} xl={4}>
                      <div className="qr-print-card" id={`qr-${t.id}`}>
                        <QRCode value={qrUrl(t)} size={140} bordered={false} />
                        <b style={{ fontSize: 18 }}>میز {t.name}</b>
                        <Space size={4}>
                          <Button size="small" icon={<PrinterOutlined />} onClick={() => printQrs([t])} />
                          <Button size="small" href={qrUrl(t)} target="_blank">مشاهده</Button>
                          <Popconfirm title="کد قبلی باطل شود؟" onConfirm={() => post(`/floor/tables/${t.id}/regenerate-qr`).then(reload)}><Button size="small" icon={<ReloadOutlined />} /></Popconfirm>
                        </Space>
                      </div>
                    </Col>
                  ))}
                </Row>
              </>
            )}
          </>
        ) : <Empty description="هنوز سالنی تعریف نشده" />}
      </Card>
      <Modal open={!!editT} title={editT?.id ? `ویرایش میز ${editT.name}` : 'میز جدید'} onCancel={() => setEditT(null)} onOk={() => tf.submit()} destroyOnClose>
        <Form form={tf} layout="vertical" onFinish={saveTable}>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="name" label="نام / شماره میز" rules={[{ required: true }]}><Input /></Form.Item></Col>
            <Col span={12}><Form.Item name="seats" label="ظرفیت"><InputNumber min={1} max={40} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={12}><Form.Item name="shape" label="شکل"><Select options={Object.entries(SHAPES).map(([k, v]) => ({ value: k, label: v }))} /></Form.Item></Col>
            <Col span={12}><Form.Item name="area_id" label="سالن"><Select options={(areas.data || []).map((a) => ({ value: a.id, label: a.name }))} /></Form.Item></Col>
          </Row>
          <Form.Item name="is_active" valuePropName="checked"><Checkbox>فعال</Checkbox></Form.Item>
        </Form>
      </Modal>
      <Modal open={!!editA} title="سالن" onCancel={() => setEditA(null)} onOk={() => af.submit()} destroyOnClose>
        <Form form={af} layout="vertical" onFinish={saveArea}><Form.Item name="name" label="نام سالن" rules={[{ required: true, min: 2 }]}><Input placeholder="مثلاً: طبقه دوم، حیاط" /></Form.Item></Form>
      </Modal>
      <Modal open={!!qr} title={`QR میز ${qr?.name}`} footer={null} onCancel={() => setQr(null)} width={320} centered>
        {qr && <div style={{ textAlign: 'center' }}><QRCode value={qrUrl(qr)} size={240} style={{ margin: '0 auto' }} /><Typography.Paragraph copyable className="ltr" style={{ marginTop: 10, fontSize: 12 }}>{qrUrl(qr)}</Typography.Paragraph></div>}
      </Modal>
    </div>
  )
}
