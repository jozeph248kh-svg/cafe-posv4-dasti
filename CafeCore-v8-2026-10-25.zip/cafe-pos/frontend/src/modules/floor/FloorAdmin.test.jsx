import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Floor admin defines the rooms and tables the POS and the table QR codes depend on. The two things
// worth pinning: the table list per room, and that the QR code of a table points at *that* table's
// token (a copy-paste bug here would put table 5's menu on table 2).
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: { 'business.name': 'کافه ونک' }, system: { lan_urls: ['http://192.168.1.10:8000'] } }) }))
vi.mock('../../core/print', () => ({ printHtml: vi.fn() }))

const { default: FloorAdmin } = await import('./FloorAdmin')

const AREAS = [{ id: 1, name: 'سالن اصلی' }, { id: 2, name: 'تراس' }]
const TABLES = [
  { id: 1, area_id: 1, name: '۱', seats: 4, shape: 'square', is_active: true, x: 0, y: 0, qr_token: 'tok-table-1' },
  { id: 2, area_id: 1, name: '۲', seats: 2, shape: 'round', is_active: true, x: 1, y: 0, qr_token: 'tok-table-2' },
  { id: 3, area_id: 2, name: 'تراس ۱', seats: 6, shape: 'rect', is_active: false, x: 0, y: 0, qr_token: 'tok-table-3' },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/floor/areas') return Promise.resolve(AREAS)
    if (path === '/floor/tables') return Promise.resolve(TABLES)
    return Promise.resolve([])
  })
}
const page = () => render(<App><FloorAdmin /></App>)

describe('Floor admin', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows one tab per room and only that room’s tables', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سالن اصلی'))
    expect(text()).toContain('تراس')
    await user().click(screen.getByText('فهرست میزها'))
    await waitFor(() => expect(text()).toContain('۴ نفر'))   // seats of table 1
    expect(text()).not.toContain('تراس ۱')          // belongs to the other room
  })

  it('marks an inactive table as such', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سالن اصلی'))
    await user().click(screen.getByText('تراس'))     // switch room
    await user().click(screen.getByText('فهرست میزها'))
    await waitFor(() => expect(text()).toContain('تراس ۱'))
    expect(text()).toContain('غیرفعال')
  })

  it('gives every table its own QR link', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سالن اصلی'))
    await user().click(screen.getByText('کدهای QR'))
    await waitFor(() => expect(text()).toContain('چاپ همه کدهای این سالن'))
    // one QR card per table of the *current* room, each pointing at its own token
    const cards = document.querySelectorAll('.qr-print-card')
    expect(cards).toHaveLength(2)
    expect(text()).toContain('آدرس پایه')
  })

  it('prints all QR codes of the room on one sheet', async () => {
    const { printHtml } = await import('../../core/print')
    page()
    await waitFor(() => expect(text()).toContain('سالن اصلی'))
    await user().click(screen.getByText('کدهای QR'))
    await user().click(screen.getByRole('button', { name: /چاپ همه کدهای این سالن/ }))
    await waitFor(() => expect(printHtml).toHaveBeenCalled())
    const html = printHtml.mock.calls[0][0]
    expect(html.split('میز').length - 1).toBeGreaterThanOrEqual(2)     // both tables on the sheet
  })

  it('asks for areas and tables once', async () => {
    page()
    await waitFor(() => expect(get.mock.calls.some(([p]) => p === '/floor/areas')).toBe(true))
    expect(get.mock.calls.some(([p]) => p === '/floor/tables')).toBe(true)
  })
})
