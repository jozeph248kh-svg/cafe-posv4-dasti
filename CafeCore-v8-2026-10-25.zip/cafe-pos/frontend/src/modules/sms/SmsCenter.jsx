import {
  CheckCircleFilled, CloseCircleFilled, ClockCircleOutlined, MessageOutlined, NotificationOutlined, ReloadOutlined, SaveOutlined, SendOutlined, SettingOutlined, StopOutlined, ThunderboltOutlined,
} from '@ant-design/icons'
import { Alert, App, Badge, Button, Card, Col, Empty, Form, Input, InputNumber, Popconfirm, Radio, Row, Select, Space, Switch, Table, Tabs, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { del, post, put } from '../../core/api'
import { faDateTime, num, timeAgo } from '../../core/format'
import { useFetch } from '../../core/useFetch'

const KIND = {
  reservation_created: ['تأیید رزرو', 'blue'], reservation_reminder: ['یادآوری رزرو', 'geekblue'], online_accepted: ['سفارش آنلاین', 'purple'],
  order_ready: ['آماده تحویل', 'green'], delivery_out: ['ارسال پیک', 'magenta'], wallet_topup: ['کیف پول', 'gold'], campaign: ['کمپین', 'volcano'],
  manual: ['دستی', 'default'], test: ['آزمایشی', 'default'],
}
const STATUS = { sent: ['ارسال شد', 'success', <CheckCircleFilled key="s" />], queued: ['در صف', 'processing', <ClockCircleOutlined key="q" />], sending: ['در حال ارسال', 'processing', <ClockCircleOutlined key="g" />], failed: ['ناموفق', 'error', <CloseCircleFilled key="f" />] }
const PH = { name: 'نام مشتری', date: 'تاریخ', time: 'ساعت', guests: 'تعداد نفرات', business: 'نام کافه', number: 'شماره سفارش', eta: 'زمان تقریبی', link: 'لینک پیگیری', courier: 'نام پیک', amount_line: 'مبلغ قابل پرداخت', amount: 'مبلغ', balance: 'موجودی' }
const SAMPLE = { name: 'سارا', date: '۲ آبان', time: '۲۰:۰۰', guests: '۴', business: 'کافه رستوران من', number: '۱۲۸', eta: '۴۰', link: 'https://…/order/track/abc', courier: 'مهدی رنجبر', amount_line: 'مبلغ قابل پرداخت: ۷۷۰٬۰۰۰ تومان', amount: '۵۰۰٬۰۰۰', balance: '۸۲۰٬۰۰۰' }
const fill = (t) => (t || '').replace(/\{(\w+)\}/g, (_, k) => SAMPLE[k] ?? '')
const smsParts = (t) => ((t || '').length <= 70 ? 1 : Math.ceil(t.length / 67))

function Phone({ text }) {
  return (
    <div className="sms-phone">
      <div className="sms-phone-top">پیام‌ها</div>
      <div className="sms-bubble">{text || <span style={{ opacity: 0.5 }}>متن پیامک…</span>}</div>
      <div className="sms-meta">{num((text || '').length)} کاراکتر · {num(smsParts(text))} پیامک</div>
    </div>
  )
}

function Messages({ reloadKey }) {
  const [f, setF] = useState({ status: undefined, kind: undefined, q: '', page: 1 })
  const { data, loading, reload } = useFetch('/sms/messages', { ...f, size: 15 }, { deps: [reloadKey] })
  const { message } = App.useApp()
  return (
    <Card title="پیامک‌های ارسالی" extra={<Space wrap>
      <Input.Search allowClear placeholder="شماره یا متن" style={{ width: 180 }} onSearch={(q) => setF({ ...f, q, page: 1 })} />
      <Select allowClear placeholder="نوع" style={{ width: 140 }} value={f.kind} onChange={(kind) => setF({ ...f, kind, page: 1 })} options={Object.entries(KIND).map(([value, [label]]) => ({ value, label }))} />
      <Select allowClear placeholder="وضعیت" style={{ width: 120 }} value={f.status} onChange={(status) => setF({ ...f, status, page: 1 })} options={Object.entries(STATUS).map(([value, [label]]) => ({ value, label }))} />
      <Button icon={<ReloadOutlined />} onClick={() => reload()} />
    </Space>}>
      <Table rowKey="id" size="middle" loading={loading} dataSource={data?.items || []} scroll={{ x: 820 }}
        pagination={{ current: f.page, pageSize: 15, total: data?.total, onChange: (page) => setF({ ...f, page }), showSizeChanger: false }}
        columns={[
          { title: 'زمان', dataIndex: 'created_at', width: 120, render: (v) => <Tooltip title={faDateTime(v)}>{timeAgo(v)}</Tooltip> },
          { title: 'گیرنده', dataIndex: 'to', width: 130, render: (v) => <span className="ltr">{v}</span> },
          { title: 'نوع', dataIndex: 'kind', width: 120, render: (v) => <Tag color={KIND[v]?.[1]}>{KIND[v]?.[0] || v}</Tag> },
          { title: 'متن', dataIndex: 'text', render: (v) => <Typography.Paragraph ellipsis={{ rows: 2, tooltip: v }} style={{ margin: 0, whiteSpace: 'pre-line' }}>{v}</Typography.Paragraph> },
          { title: 'وضعیت', dataIndex: 'status', width: 150, render: (v, r) => (
            <Space size={4}>
              <Badge status={STATUS[v][1]} text={STATUS[v][0]} />
              {r.error && <Tooltip title={r.error}><Tag color="red" style={{ cursor: 'help' }}>خطا</Tag></Tooltip>}
              {v === 'failed' && <Button size="small" type="link" onClick={async () => { await post(`/sms/messages/${r.id}/retry`); message.success('دوباره در صف قرار گرفت'); reload() }}>تلاش مجدد</Button>}
            </Space>
          ) },
        ]} />
    </Card>
  )
}

function Templates() {
  const { message } = App.useApp()
  const { data, loading } = useFetch('/sms/templates')
  const [items, setItems] = useState({})
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (data) setItems(Object.fromEntries(data.map((t) => [t.key, { enabled: t.enabled, text: t.text }]))) }, [data])
  if (loading || !data) return <Card loading />
  const save = async () => {
    setBusy(true)
    try { await put('/sms/templates', { items }); message.success('متن پیامک‌ها ذخیره شد') } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <>
      <Alert type="info" showIcon style={{ marginBottom: 16 }} message="این پیامک‌ها به‌صورت خودکار و هنگام وقوع رویداد ارسال می‌شوند. عبارت‌های داخل {} با اطلاعات واقعی جایگزین می‌شوند."
        action={<Button type="primary" icon={<SaveOutlined />} loading={busy} onClick={save}>ذخیره همه</Button>} />
      <Row gutter={[16, 16]}>
        {data.map((t) => {
          const it = items[t.key] || {}
          return (
            <Col xs={24} xl={12} key={t.key}>
              <Card size="small" className={`sms-tpl ${it.enabled ? '' : 'off'}`} title={<Space><Switch size="small" checked={!!it.enabled} onChange={(v) => setItems({ ...items, [t.key]: { ...it, enabled: v } })} />{t.title}</Space>}
                extra={<Button size="small" type="link" onClick={() => setItems({ ...items, [t.key]: { ...it, text: t.default } })}>متن پیش‌فرض</Button>}>
                <div className="sms-tpl-body">
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <Input.TextArea value={it.text} onChange={(e) => setItems({ ...items, [t.key]: { ...it, text: e.target.value } })} autoSize={{ minRows: 3, maxRows: 6 }} disabled={!it.enabled} />
                    <Space size={[4, 4]} wrap style={{ marginTop: 8 }}>
                      {t.placeholders.map((p) => <Tag key={p} style={{ cursor: 'pointer' }} onClick={() => setItems({ ...items, [t.key]: { ...it, text: `${it.text || ''}{${p}}` } })}>{PH[p] || p} <span className="ltr" style={{ opacity: 0.6 }}>{`{${p}}`}</span></Tag>)}
                    </Space>
                  </div>
                  <div className="sms-tpl-preview">
                    <div className="sms-bubble small">{fill(it.text)}</div>
                    <small>{num(smsParts(fill(it.text)))} پیامک</small>
                  </div>
                </div>
              </Card>
            </Col>
          )
        })}
      </Row>
    </>
  )
}

function Campaigns({ onSent }) {
  const { message, modal } = App.useApp()
  const [form] = Form.useForm()
  const seg = Form.useWatch('segment', form) || { type: 'all' }
  const text = Form.useWatch('text', form) || ''
  const [pv, setPv] = useState(null)
  const [busy, setBusy] = useState(false)
  const list = useFetch('/sms/campaigns')
  const tiers = useFetch('/loyalty/summary', null, { skip: false })
  const segKey = JSON.stringify(seg)

  useEffect(() => {
    const id = setTimeout(() => {
      const s = form.getFieldValue('segment') || { type: 'all' }
      const body = { segment: { ...s, phones: (s.phones_text || '').split(/[\s,،]+/).filter(Boolean) }, text: form.getFieldValue('text') || '' }
      delete body.segment.phones_text
      post('/sms/campaigns/preview', body).then(setPv).catch(() => setPv(null))
    }, 350)
    return () => clearTimeout(id)
  }, [segKey, text, form])

  const send = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    const segment = { ...v.segment, phones: (v.segment.phones_text || '').split(/[\s,،]+/).filter(Boolean) }
    delete segment.phones_text
    modal.confirm({
      title: `ارسال کمپین به ${num(pv?.count || 0)} نفر؟`, content: `حدود ${num(pv?.total_parts || 0)} پیامک مصرف می‌شود. پیامک‌های تبلیغاتی در ساعات استراحت (شب) ارسال نمی‌شوند و صبح ادامه پیدا می‌کنند.`,
      okText: 'ارسال', cancelText: 'انصراف',
      onOk: async () => {
        setBusy(true)
        try { const r = await post('/sms/campaigns', { title: v.title, text: v.text, segment }); message.success(`کمپین برای ${num(r.total)} نفر در صف ارسال قرار گرفت`); form.resetFields(['title', 'text']); list.reload(); onSent?.() } catch (e) { message.error(e.message) } finally { setBusy(false) }
      },
    })
  }
  const tierOpts = (tiers.data?.tiers || []).map((t) => ({ value: t.key, label: t.name }))

  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xl={14}>
        <Card title={<span><NotificationOutlined /> کمپین جدید</span>}>
          <Form form={form} layout="vertical" initialValues={{ segment: { type: 'all', days: 30, top: 50 } }}>
            <Form.Item name="title" label="عنوان (داخلی)" rules={[{ required: true, min: 2 }]}><Input placeholder="مثلاً: تخفیف آخر هفته" /></Form.Item>
            <Form.Item name={['segment', 'type']} label="گیرندگان">
              <Radio.Group optionType="button" options={[
                { value: 'all', label: 'همه مشتریان' }, { value: 'tier', label: 'سطح باشگاه' }, { value: 'inactive', label: 'مدتی نیامده‌اند' },
                { value: 'recent', label: 'مشتریان اخیر' }, { value: 'top', label: 'پرخریدترین‌ها' }, { value: 'phones', label: 'شماره‌های دلخواه' },
              ]} />
            </Form.Item>
            {seg.type === 'tier' && <Form.Item name={['segment', 'tier']} label="سطح" rules={[{ required: true }]}><Select options={tierOpts} style={{ maxWidth: 240 }} /></Form.Item>}
            {(seg.type === 'inactive' || seg.type === 'recent') && <Form.Item name={['segment', 'days']} label={seg.type === 'inactive' ? 'بیش از چند روز است نیامده‌اند؟' : 'در چند روز گذشته آمده‌اند؟'}><InputNumber min={1} max={3650} addonAfter="روز" /></Form.Item>}
            {seg.type === 'top' && <Form.Item name={['segment', 'top']} label="تعداد"><InputNumber min={1} max={10000} addonAfter="نفر" /></Form.Item>}
            {seg.type === 'phones' && <Form.Item name={['segment', 'phones_text']} label="شماره‌ها (با فاصله یا ویرگول جدا کنید)"><Input.TextArea className="ltr" autoSize={{ minRows: 2 }} /></Form.Item>}
            <Form.Item name="text" label="متن پیامک" rules={[{ required: true, min: 2 }]} extra="برای نوشتن نام هر مشتری از {name} استفاده کنید. عبارت لغو۱۱ طبق قانون خودکار اضافه می‌شود.">
              <Input.TextArea autoSize={{ minRows: 4 }} maxLength={600} showCount placeholder="{name} عزیز، این آخر هفته ۲۰٪ تخفیف روی همه نوشیدنی‌ها 🎉" />
            </Form.Item>
            <div className="sms-camp-foot">
              <div>
                <b>{num(pv?.count || 0)}</b> گیرنده · <b>{num(pv?.total_parts || 0)}</b> پیامک
                {pv?.sample?.length > 0 && <div className="sms-sample">{pv.sample.map((s) => s.name || s.phone).join('، ')}{pv.count > pv.sample.length ? ' و …' : ''}</div>}
              </div>
              <Button type="primary" size="large" icon={<SendOutlined />} loading={busy} disabled={!pv?.count} onClick={send}>ارسال کمپین</Button>
            </div>
          </Form>
        </Card>
      </Col>
      <Col xs={24} xl={10}>
        <Card title="پیش‌نمایش" style={{ marginBottom: 16 }}><Phone text={(pv?.text || text).replace('{name}', pv?.sample?.[0]?.name || 'سارا')} /></Card>
        <Card title="کمپین‌های اخیر" loading={list.loading}>
          {!list.data?.length ? <Empty description="هنوز کمپینی ارسال نشده" /> : list.data.map((c) => (
            <div key={c.id} className="sms-camp-row">
              <div><b>{c.title}</b><small>{timeAgo(c.created_at)}</small></div>
              <Space size={4}>
                <Tag color="green">{num(c.sent)} ارسال</Tag>
                {c.queued > 0 && <Tag color="blue">{num(c.queued)} در صف</Tag>}
                {c.failed > 0 && <Tag color="red">{num(c.failed)} ناموفق</Tag>}
              </Space>
            </div>
          ))}
        </Card>
      </Col>
    </Row>
  )
}

function Config({ status, reload }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const prov = Form.useWatch('provider', form)
  const [busy, setBusy] = useState(null)
  const [testTo, setTestTo] = useState('')
  const opt = useFetch('/sms/optout')
  const [optPhone, setOptPhone] = useState('')
  useEffect(() => { form.setFieldsValue({ ...status, config: status.config || {} }) }, [status, form])
  const p = status.providers.find((x) => x.key === prov)
  const save = async () => {
    setBusy('save')
    try { await put('/sms/config', form.getFieldsValue(true)); message.success('تنظیمات ذخیره شد'); reload() } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  const test = async () => {
    setBusy('test')
    try { await put('/sms/config', form.getFieldsValue(true)); await post('/sms/test', { to: testTo }); message.success('پیامک آزمایشی با موفقیت ارسال شد ✅'); reload() } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xl={14}>
        <Card title={<span><SettingOutlined /> سرویس‌دهنده پیامک</span>} extra={<Button type="primary" icon={<SaveOutlined />} loading={busy === 'save'} onClick={save}>ذخیره</Button>}>
          <Form form={form} layout="vertical">
            <Form.Item name="enabled" valuePropName="checked" label="ارسال پیامک"><Switch checkedChildren="فعال" unCheckedChildren="خاموش" /></Form.Item>
            <Form.Item name="provider" label="سرویس">
              <Radio.Group className="sms-provs">
                {status.providers.map((x) => <Radio.Button key={x.key} value={x.key}>{x.title}</Radio.Button>)}
              </Radio.Group>
            </Form.Item>
            {prov === 'test' && <Alert type="warning" showIcon style={{ marginBottom: 16 }} message="در حالت آزمایشی هیچ پیامکی واقعاً ارسال نمی‌شود؛ فقط در فهرست ثبت می‌شود. برای ارسال واقعی یکی از سرویس‌ها را انتخاب و کلید API را وارد کنید." />}
            {p?.fields.map((f) => (
              <Form.Item key={f.key} name={['config', prov, f.key]} label={f.label} rules={f.required ? [{ required: true }] : []}>
                {f.key.includes('key') || f.key === 'token' ? <Input.Password className="ltr" autoComplete="off" /> : <Input className="ltr" />}
              </Form.Item>
            ))}
            <Row gutter={12}>
              <Col xs={24} md={8}><Form.Item name="reminder_minutes" label="یادآوری رزرو (دقیقه قبل)"><InputNumber min={15} max={1440} style={{ width: '100%' }} /></Form.Item></Col>
              <Col xs={12} md={8}><Form.Item name="quiet_start" label="شروع ساعت سکوت" tooltip="پیامک‌های تبلیغاتی در این بازه ارسال نمی‌شوند"><InputNumber min={0} max={23} style={{ width: '100%' }} addonAfter=":۰۰" /></Form.Item></Col>
              <Col xs={12} md={8}><Form.Item name="quiet_end" label="پایان ساعت سکوت"><InputNumber min={0} max={23} style={{ width: '100%' }} addonAfter=":۰۰" /></Form.Item></Col>
              <Col xs={24}><Form.Item name="optout_footer" label="عبارت انصراف در پیامک تبلیغاتی"><Input style={{ maxWidth: 200 }} /></Form.Item></Col>
            </Row>
          </Form>
          <div className="sms-test">
            <Input className="ltr" placeholder="09xxxxxxxxx" value={testTo} onChange={(e) => setTestTo(e.target.value)} style={{ maxWidth: 200 }} />
            <Button icon={<ThunderboltOutlined />} loading={busy === 'test'} disabled={testTo.length < 10} onClick={test}>ذخیره و ارسال آزمایشی</Button>
          </div>
        </Card>
      </Col>
      <Col xs={24} xl={10}>
        <Card title={<span><StopOutlined /> فهرست انصراف</span>} extra={<Typography.Text type="secondary" style={{ fontSize: 12 }}>پیامک تبلیغاتی دریافت نمی‌کنند</Typography.Text>}>
          <Space.Compact style={{ width: '100%', marginBottom: 12 }}>
            <Input className="ltr" placeholder="09xxxxxxxxx" value={optPhone} onChange={(e) => setOptPhone(e.target.value)} />
            <Button onClick={async () => { try { await post('/sms/optout', { phone: optPhone }); setOptPhone(''); opt.reload() } catch (e) { message.error(e.message) } }}>افزودن</Button>
          </Space.Compact>
          <Table rowKey="id" size="small" dataSource={opt.data || []} loading={opt.loading} pagination={{ pageSize: 8, hideOnSinglePage: true }} locale={{ emptyText: 'خالی' }}
            columns={[{ title: 'شماره', dataIndex: 'phone', render: (v) => <span className="ltr">{v}</span> }, { title: 'از', dataIndex: 'created_at', render: timeAgo },
              { width: 50, render: (_, r) => <Popconfirm title="حذف از فهرست؟" onConfirm={async () => { await del(`/sms/optout/${r.id}`); opt.reload() }}><Button size="small" type="text" danger icon={<CloseCircleFilled />} /></Popconfirm> }]} />
        </Card>
      </Col>
    </Row>
  )
}

export default function SmsCenter() {
  const st = useFetch('/sms/status')
  const [tab, setTab] = useState('messages')
  const [rk, setRk] = useState(0)
  const s = st.data
  const provTitle = useMemo(() => s?.providers.find((p) => p.key === s.provider)?.title, [s])
  return (
    <div>
      <PageHeader title="مرکز پیامک" subtitle="پیامک‌های خودکار، کمپین تبلیغاتی و تنظیمات سرویس‌دهنده" icon={<MessageOutlined />}
        extra={s && <Tag color={s.enabled ? (s.provider === 'test' ? 'orange' : 'green') : 'red'} style={{ padding: '4px 10px', fontSize: 13 }}>{s.enabled ? provTitle : 'ارسال پیامک خاموش است'}</Tag>} />
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="ارسال امروز" value={s?.sent_today} icon={<CheckCircleFilled />} color="var(--green)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="در صف ارسال" value={s?.queued} icon={<ClockCircleOutlined />} color="var(--pal-1)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="ناموفق امروز" value={s?.failed_today} icon={<CloseCircleFilled />} color="var(--red)" hint={s?.last_error ? 'آخرین خطا: ' + s.last_error.slice(0, 40) : undefined} /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="اعتبار باقی‌مانده" value={s?.credit || '—'} icon={<ThunderboltOutlined />} color="var(--amber)" hint={s?.credit_error ? s.credit_error.slice(0, 50) : `${num(s?.parts_30d || 0)} پیامک در ۳۰ روز`} /></Col>
      </Row>
      <Tabs activeKey={tab} onChange={setTab} items={[
        { key: 'messages', label: 'ارسال‌ها', children: <Messages reloadKey={rk} /> },
        { key: 'campaigns', label: 'کمپین تبلیغاتی', children: <Campaigns onSent={() => { setRk(rk + 1); st.reload() }} /> },
        { key: 'templates', label: 'پیامک‌های خودکار', children: <Templates /> },
        { key: 'config', label: 'تنظیمات سرویس', children: s ? <Config status={s} reload={st.reload} /> : null },
      ]} />
    </div>
  )
}
