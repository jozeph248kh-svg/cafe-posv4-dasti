import { EditOutlined, PlusOutlined, UserOutlined } from '@ant-design/icons'
import { App, Avatar, Button, Card, Drawer, Form, Input, Modal, Space, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader } from '../../components/common'
import { get, post, put } from '../../core/api'
import { ORDER_TYPES, colorOf, faDate, faDateTime, initials, money, num, timeAgo } from '../../core/format'
import { useAuth } from '../../core/auth'
import { useFetch } from '../../core/useFetch'
import AccountPanel from '../loyalty/AccountPanel'

export default function Customers() {
  const { message } = App.useApp()
  const auth = useAuth()
  const [q, setQ] = useState('')
  const { data, loading, reload } = useFetch('/customers', { q, limit: 500 })
  const [edit, setEdit] = useState(null)
  const [view, setView] = useState(null)
  const [form] = Form.useForm()

  const save = async (v) => {
    try {
      if (edit.id) await put(`/customers/${edit.id}`, v)
      else await post('/customers', v)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const openView = async (c) => setView({ c, orders: await get(`/customers/${c.id}/orders`) })

  return (
    <div className="fade-in">
      <PageHeader title="مشتریان" subtitle="مشتریانی که با شماره تلفن سفارش داده‌اند به‌صورت خودکار ثبت می‌شوند"
        extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => { form.resetFields(); setEdit({}) }}>مشتری جدید</Button>} />
      <Card className="card-r">
        <Input.Search placeholder="جستجوی نام یا شماره" allowClear onSearch={setQ} style={{ maxWidth: 320, marginBottom: 14 }} />
        <Table rowKey="id" loading={loading} dataSource={data || []} scroll={{ x: 800 }} onRow={(r) => ({ onClick: () => openView(r), style: { cursor: 'pointer' } })}
          columns={[
            { title: 'مشتری', dataIndex: 'name', render: (v, r) => <Space><Avatar style={{ background: colorOf(v) }}>{initials(v)}</Avatar><div><b>{v}</b><div className="ltr" style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'right' }}>{r.phone}</div></div></Space> },
            { title: 'تعداد خرید', dataIndex: 'visits', render: (v) => <Tag color={v >= 10 ? 'gold' : v >= 3 ? 'blue' : 'default'}>{num(v)}</Tag>, sorter: (a, b) => a.visits - b.visits },
            { title: 'مجموع خرید', dataIndex: 'total_spent', render: (v) => <b>{money(v)}</b>, sorter: (a, b) => a.total_spent - b.total_spent, defaultSortOrder: 'descend' },
            { title: 'آخرین خرید', dataIndex: 'last_visit', render: (v) => (v ? timeAgo(v) : '—') },
            { title: 'آدرس', dataIndex: 'address', ellipsis: true },
            { title: '', width: 50, render: (_, r) => <Button type="text" icon={<EditOutlined />} onClick={(e) => { e.stopPropagation(); form.setFieldsValue(r); setEdit(r) }} /> },
          ]} />
      </Card>
      <Modal open={!!edit} title={edit?.id ? 'ویرایش مشتری' : 'مشتری جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save} preserve={false} initialValues={edit}>
          <Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input prefix={<UserOutlined />} /></Form.Item>
          <Form.Item name="phone" label="شماره تماس" rules={[{ required: true, min: 8 }]}><Input className="ltr" inputMode="tel" /></Form.Item>
          <Form.Item name="address" label="آدرس"><Input.TextArea rows={2} /></Form.Item>
          <Form.Item name="note" label="یادداشت (سلیقه، حساسیت غذایی...)"><Input.TextArea rows={2} /></Form.Item>
        </Form>
      </Modal>
      <Drawer open={!!view} onClose={() => setView(null)} width={Math.min(auth.hasModule('loyalty') ? 600 : 480, window.innerWidth)} title={view?.c.name}>
        {view && (
          <>
            <Space direction="vertical" style={{ width: '100%' }}>
              <div className="kpi-mini"><span>شماره</span><b className="ltr">{view.c.phone}</b></div>
              <div className="kpi-mini"><span>تعداد خرید</span><b>{num(view.c.visits)}</b></div>
              <div className="kpi-mini"><span>مجموع خرید</span><b>{money(view.c.total_spent)}</b></div>
              <div className="kpi-mini"><span>میانگین خرید</span><b>{money(view.c.total_spent / (view.c.visits || 1))}</b></div>
              <div className="kpi-mini"><span>عضویت از</span><b>{faDate(view.c.created_at)}</b></div>
              {view.c.address && <div className="kpi-mini"><span>آدرس</span><span>{view.c.address}</span></div>}
              {view.c.note && <div className="kpi-mini"><span>یادداشت</span><span>{view.c.note}</span></div>}
            </Space>
            {auth.hasModule('loyalty') && <><Typography.Title level={5} style={{ marginTop: 20 }}>باشگاه و کیف پول</Typography.Title><AccountPanel key={view.c.id} customerId={view.c.id} /></>}
            <Typography.Title level={5} style={{ marginTop: 20 }}>سفارش‌های اخیر</Typography.Title>
            <Table size="small" rowKey="id" dataSource={view.orders} pagination={false}
              columns={[
                { title: '#', dataIndex: 'number', render: (v) => num(v) },
                { title: 'زمان', dataIndex: 'created_at', render: faDateTime },
                { title: 'نوع', dataIndex: 'type', render: (t) => ORDER_TYPES[t]?.label },
                { title: 'مبلغ', dataIndex: 'total', render: money },
              ]} />
          </>
        )}
      </Drawer>
    </div>
  )
}
