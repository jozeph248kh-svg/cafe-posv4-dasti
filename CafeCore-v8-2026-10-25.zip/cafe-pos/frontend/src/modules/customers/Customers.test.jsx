import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

const user = () => userEvent.setup({ delay: null })   // antd + jsdom is slow enough without per-key delays
import { App } from 'antd'

// Customers page: search + create/edit + the drawer that shows one customer's history.
// Uses the real `useFetch`, the real antd table and the real form; only the HTTP layer is stubbed.
const get = vi.fn()
const post = vi.fn()
const put = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a),
  del: vi.fn(), download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ hasModule: () => false, can: () => true, user: { id: 1 } }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online' }))

const { default: Customers } = await import('./Customers')

const CUSTOMERS = [
  { id: 1, name: 'شیرین دلاوری', phone: '09127770011', visits: 12, total_spent: 4_250_000, last_visit: '2026-10-22T18:00:00', address: 'ونک، خیابان سرو', note: 'بدون شکر' },
  { id: 2, name: 'آرش کمالی', phone: '09121110022', visits: 2, total_spent: 380_000, last_visit: null, address: null, note: null },
]
const page = () => render(<App><Customers /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Customers page', () => {
  beforeEach(() => {
    get.mockReset(); post.mockReset(); put.mockReset()
    get.mockImplementation((path) => Promise.resolve(path.startsWith('/customers') && path.split('/').length === 2 ? CUSTOMERS : []))
  })

  it('lists customers with their visit count and total spend', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیرین دلاوری'))
    expect(text()).toContain('09127770011')
    expect(text()).toContain('۴٬۲۵۰٬۰۰۰')
    expect(text()).toContain('آرش کمالی')
  })

  it('searches by re-querying the server, not by filtering locally', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalled())
    get.mockClear()
    await user().type(screen.getByPlaceholderText('جستجوی نام یا شماره'), '0912{enter}')
    await waitFor(() => expect(get).toHaveBeenCalledWith('/customers', { q: '0912', limit: 500 }))
  })

  it('rejects a new customer without a phone number (server-side rule is mirrored in the form)', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیرین'))
    await user().click(screen.getByRole('button', { name: /مشتری جدید/ }))
    const dialog = await screen.findByRole('dialog')
    await user().type(dialog.querySelector('input#name') || dialog.querySelectorAll('input')[0], 'مشتری تست')
    await user().click(dialog.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(text()).toContain('شماره تماس'))     // validation message, not a POST
    expect(post).not.toHaveBeenCalled()
  })

  it('creates a customer when the form is valid', async () => {
    post.mockResolvedValue({ id: 9 })
    page()
    await waitFor(() => expect(text()).toContain('شیرین'))
    await user().click(screen.getByRole('button', { name: /مشتری جدید/ }))
    const dialog = await screen.findByRole('dialog')
    const inputs = dialog.querySelectorAll('input')
    await user().type(inputs[0], 'مشتری تست')
    await user().type(inputs[1], '09125558877')
    await user().click(dialog.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalledWith('/customers', expect.objectContaining({ name: 'مشتری تست', phone: '09125558877' })))
  })

  it('opens the drawer with the history of the clicked customer', async () => {
    get.mockImplementation((path) => {
      if (path === '/customers') return Promise.resolve(CUSTOMERS)
      if (path === '/customers/1/orders') return Promise.resolve([{ id: 5, number: 77, created_at: '2026-10-22T18:00:00', type: 'takeaway', total: 254_000 }])
      return Promise.resolve([])
    })
    page()
    await waitFor(() => expect(text()).toContain('شیرین دلاوری'))
    await user().click(screen.getByText('شیرین دلاوری'))
    await waitFor(() => expect(text()).toContain('سفارش‌های اخیر'))
    expect(text()).toContain('میانگین خرید')
    expect(text()).toContain('۲۵۴٬۰۰۰')
    expect(get).toHaveBeenCalledWith('/customers/1/orders')
  })
})
