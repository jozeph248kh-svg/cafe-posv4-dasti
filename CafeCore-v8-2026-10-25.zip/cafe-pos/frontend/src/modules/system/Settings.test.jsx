import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

// The settings screen is where the money rules live (tax, service charge, rounding, business day).
// A silent failure here changes every future bill, so the tests pin: values load from the server,
// saving sends exactly what was edited, and the numeric fields refuse out-of-range input.
const user = () => userEvent.setup({ delay: null })
const put = vi.fn()
const post = vi.fn()
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
// the printers and theme tabs have their own API traffic — not what this file is about
vi.mock('./Printers', () => ({ default: () => <div>PRINTERS-STUB</div> }))
vi.mock('./ThemeStudio', () => ({ default: () => <div>THEME-STUB</div> }))

const SETTINGS = {
  'business.name': 'کافه ونک', 'business.phone': '02188776655', 'business.address': 'تهران، ونک',
  'tax.enabled': true, 'tax.percent': 10, 'service.enabled': true, 'service.percent': 0,
  'rounding.step': 0, 'currency.label': 'تومان', 'shift.required': true, 'day.cutoff_hour': 5,
}
const auth = {
  can: () => true, hasModule: () => false, user: { id: 1 }, settings: SETTINGS,
  system: { lan_urls: ['http://192.168.1.10:8000'], modules: [] }, reloadSystem: vi.fn(() => Promise.resolve()),
}
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))

const { default: Settings } = await import('./Settings')

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = (url = '/settings') => render(<MemoryRouter initialEntries={[url]}><App><Settings /></App></MemoryRouter>)

describe('Settings', () => {
  beforeEach(() => { put.mockReset(); post.mockReset(); get.mockReset(); auth.reloadSystem.mockClear() })

  it('fills the form from the server values', async () => {
    page()
    await waitFor(() => expect(text()).toContain('اطلاعات مجموعه'))
    expect(await screen.findByDisplayValue('کافه ونک')).toBeTruthy()
    expect(screen.getByDisplayValue('02188776655')).toBeTruthy()
    expect(screen.getByDisplayValue('تهران، ونک')).toBeTruthy()
  })

  it('saves with PUT and refreshes the app-wide settings', async () => {
    put.mockResolvedValue({})
    page()
    await screen.findByDisplayValue('کافه ونک')
    await user().click(screen.getByRole('button', { name: /ذخیره تنظیمات/ }))
    await waitFor(() => expect(put).toHaveBeenCalled())
    const [path, body] = put.mock.calls[0]
    expect(path).toBe('/system/settings')
    expect(body['business.name']).toBe('کافه ونک')
    expect(body['tax.percent']).toBe(10)
    await waitFor(() => expect(auth.reloadSystem).toHaveBeenCalled())
  })

  it('reports a rejected save instead of pretending it worked', async () => {
    put.mockRejectedValue(Object.assign(new Error('مقدار «tax.percent» باید بین 0 و 100 باشد'), { status: 422 }))
    page()
    await screen.findByDisplayValue('کافه ونک')
    await user().click(screen.getByRole('button', { name: /ذخیره تنظیمات/ }))
    await waitFor(() => expect(text()).toContain('باید بین'))
  })

  it('keeps the money rules together on the tax & service tab', async () => {
    page('/settings?tab=money')
    await waitFor(() => expect(text()).toContain('مالیات بر ارزش افزوده'))
    expect(text()).toContain('حق سرویس')
    expect(text()).toContain('گرد کردن مبلغ نهایی')
    expect(text()).toContain('واحد پول')
  })

  it('puts the business-day cutoff on the operations tab, next to the cash-drawer rules', async () => {
    page('/settings?tab=ops')
    await waitFor(() => expect(text()).toContain('ساعت پایان روز کاری'))
    expect(text()).toContain('شمارش کور صندوق')
    expect(text()).toContain('الزام باز بودن شیفت صندوق')
  })

  it('opens the right tab from the URL (?tab=) so links can deep-link into it', async () => {
    get.mockResolvedValue([])
    page('/settings?tab=backup')
    await waitFor(() => expect(text()).toContain('پشتیبان‌گیری خودکار'))
  })

  it('hides the save button on the theme tab (it has its own apply flow)', async () => {
    page('/settings?tab=theme')
    await waitFor(() => expect(text()).toContain('THEME-STUB'))
    expect(screen.queryByRole('button', { name: /ذخیره تنظیمات/ })).toBeNull()
  })
})
