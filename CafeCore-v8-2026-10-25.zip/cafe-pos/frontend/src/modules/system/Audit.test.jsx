import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// The audit trail is the answer to "who changed this?" — every sensitive action must be visible,
// and the destructive ones must stand out in red so they are not lost among routine entries.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

const { default: Audit } = await import('./Audit')

const ROWS = [
  { id: 101, created_at: '2026-10-23T19:02:00', action: 'order.void', summary: 'حذف «اسپرسو» ×۲ از سفارش #41 — دلیل: اشتباه', user_name: 'رضا', approver_name: 'سارا' },
  { id: 102, created_at: '2026-10-23T18:40:00', action: 'settings.update', summary: 'به‌روزرسانی تنظیمات', user_name: 'مدیر سیستم', approver_name: null },
  { id: 103, created_at: '2026-10-23T18:10:00', action: 'payment.refund', summary: 'بازپرداخت ۲۵۴٬۰۰۰ تومان سفارش #39', user_name: 'رضا', approver_name: 'سارا' },
  { id: 104, created_at: '2026-10-23T17:55:00', action: 'inventory.waste', summary: 'ثبت ضایعات ۲ لیتر شیر', user_name: 'سارا', approver_name: null },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => get.mockImplementation((path) => (path === '/system/audit' ? Promise.resolve(ROWS) : Promise.resolve([])))
const page = () => render(<App><Audit /></App>)

describe('Audit trail', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('lists entries with the user, the approver and the group', async () => {
    page()
    await waitFor(() => expect(text()).toContain('حذف «اسپرسو»'))
    expect(text()).toContain('رضا')
    expect(text()).toContain('سارا')                  // manager approval tag
    expect(text()).toContain('سفارش')                 // group tag from action prefix
    expect(text()).toContain('تنظیمات')
    expect(text()).toContain('انبار')
  })

  it('renders destructive actions in red', async () => {
    page()
    await waitFor(() => expect(text()).toContain('بازپرداخت'))
    // void / refund / waste rows get the antd danger text style
    expect(document.querySelectorAll('.ant-typography-danger').length).toBe(3)
  })

  it('searches via the server with the typed text', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalled())
    get.mockClear()
    await user().type(screen.getByPlaceholderText('جستجو در شرح یا نام کاربر'), 'تخفیف{enter}')
    await waitFor(() => expect(get).toHaveBeenCalledWith('/system/audit', expect.objectContaining({ q: 'تخفیف' })))
  })

  it('keeps the row limit with every filter', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalled())
    expect(get).toHaveBeenCalledWith('/system/audit', { limit: 300 })
  })

  it('does not crash when the trail is empty', async () => {
    get.mockResolvedValue([])
    page()
    await waitFor(() => expect(text()).toContain('رویدادهای سیستم'))
    expect(text()).toContain('No data')
  })
})
