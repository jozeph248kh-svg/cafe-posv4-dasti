import { Card, Input, Select, Space, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader } from '../../components/common'
import { faDateTime } from '../../core/format'
import { useFetch } from '../../core/useFetch'

const GROUPS = {
  order: ['سفارش', 'blue'], payment: ['پرداخت', 'green'], shift: ['صندوق', 'gold'], menu: ['منو', 'purple'], inventory: ['انبار', 'cyan'],
  user: ['کاربر', 'magenta'], role: ['نقش', 'magenta'], auth: ['ورود', 'default'], settings: ['تنظیمات', 'geekblue'], backup: ['پشتیبان', 'default'], floor: ['سالن', 'lime'], customer: ['مشتری', 'orange'],
}
const RED = ['void', 'cancel', 'refund', 'discount', 'waste', 'delete']

export default function Audit() {
  const [f, setF] = useState({ limit: 300 })
  const { data, loading } = useFetch('/system/audit', f)
  return (
    <div className="fade-in">
      <PageHeader title="رویدادهای سیستم" subtitle="ثبت همه عملیات حساس: ابطال، تخفیف، استرداد، تغییر قیمت و... همراه با نام کاربر و تأییدکننده" />
      <Card className="card-r">
        <Space wrap style={{ marginBottom: 14 }}>
          <Input.Search placeholder="جستجو در شرح یا نام کاربر" allowClear onSearch={(q) => setF({ ...f, q: q || undefined })} style={{ width: 280 }} />
          <Select allowClear placeholder="بخش" style={{ width: 160 }} onChange={(v) => setF({ ...f, action: v })} options={Object.entries(GROUPS).map(([k, v]) => ({ value: k, label: v[0] }))} />
        </Space>
        <Table rowKey="id" size="middle" loading={loading} dataSource={data || []} pagination={{ pageSize: 30 }} scroll={{ x: 760 }}
          columns={[
            { title: 'زمان', dataIndex: 'created_at', width: 150, render: faDateTime },
            { title: 'بخش', dataIndex: 'action', width: 100, render: (a) => { const g = GROUPS[a.split('.')[0]]; return <Tag color={g?.[1]}>{g?.[0] || a}</Tag> } },
            { title: 'شرح', dataIndex: 'summary', render: (v, r) => <Typography.Text type={RED.some((x) => r.action.includes(x)) ? 'danger' : undefined}>{v}</Typography.Text> },
            { title: 'کاربر', dataIndex: 'user_name', width: 130 },
            { title: 'تأیید مدیر', dataIndex: 'approver_name', width: 120, render: (v) => v && <Tag color="purple">{v}</Tag> },
          ]} />
      </Card>
    </div>
  )
}
