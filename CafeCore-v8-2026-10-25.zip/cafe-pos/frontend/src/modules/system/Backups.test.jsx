import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

// The backup tab is the only place a manager can see whether the shop's data can actually come back.
// These tests pin the three things that matter: the 24-hour warning is impossible to miss, a failed restore
// drill is shown as a failure (not hidden), and the drill result is reported with real numbers.
const user = () => userEvent.setup({ delay: null })
const put = vi.fn()
const post = vi.fn()
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('./Printers', () => ({ default: () => <div>PRINTERS-STUB</div> }))
vi.mock('./ThemeStudio', () => ({ default: () => <div>THEME-STUB</div> }))

const auth = {
  can: () => true, hasModule: () => false, user: { id: 1 }, settings: { 'business.name': 'کافه' },
  system: { lan_urls: [], modules: [] }, reloadSystem: vi.fn(() => Promise.resolve()),
}
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))

const { default: Settings } = await import('./Settings')

const STATUS_OK = {
  database: 'sqlite', enabled: true, interval_minutes: 60, keep_days: 14, count: 3, total_size: 5_242_880,
  newest: { name: 'cafe-20261025-090000-manual.db', size: 1_000_000, created_at: '2026-10-25T09:00:00', age_hours: 2.5, kind: 'manual', verified_manifest: true },
  stale: false, stale_after_hours: 24, drill_state: 'ok',
  last_drill: { ok: true, backup: 'cafe-20261025-090000-manual.db', restored_into: 'sqlite:temp-file', checked_at: '2026-10-25T09:05:00', figures: { 'orders.count': 12 } },
  last_successful_backup: { at: '2026-10-25T09:00:00', file: 'cafe-20261025-090000-manual.db' },
  recent: [
    { id: 2, kind: 'drill', status: 'ok', at: '2026-10-25T09:05:00', file: 'cafe-20261025-090000-manual.db', detail: null },
    { id: 1, kind: 'backup', status: 'ok', at: '2026-10-25T09:00:00', file: 'cafe-20261025-090000-manual.db', detail: null },
  ],
  errors: [], pg_tools: null, disk_free: 10_000_000_000,
}

function routeData(status = STATUS_OK, list = [], policy = { interval_minutes: 60, keep_days: 14, enabled: true, database: 'sqlite' }) {
  get.mockImplementation((path) => {
    if (path === '/system/backups/status') return Promise.resolve(status)
    if (path === '/system/backups') return Promise.resolve(list)
    if (path === '/system/backups/policy') return Promise.resolve(policy)
    return Promise.resolve({})
  })
}

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = () => render(<MemoryRouter initialEntries={['/settings?tab=backup']}><App><Settings /></App></MemoryRouter>)
const openBackupTab = async () => {
  await screen.findByText('اطلاعات مجموعه')
  await user().click(screen.getByRole('tab', { name: /پشتیبان‌گیری/ }))
  await waitFor(() => expect(text()).toContain('وضعیت پشتیبان‌گیری'))
}

describe('backup status and restore drill', () => {
  beforeEach(() => { put.mockReset(); post.mockReset(); get.mockReset() })

  it('shows the age of the newest backup and a green state when it is fresh', async () => {
    routeData()
    page()
    await openBackupTab()
    expect(text()).toContain('۲٫۵')
    expect(text()).toContain('آزمون بازیابی موفق')
    expect(text()).not.toContain('بیش از ۲۴ ساعت قدیمی')
  })

  it('warns loudly when the last backup is older than 24 hours', async () => {
    routeData({ ...STATUS_OK, stale: true, newest: { ...STATUS_OK.newest, age_hours: 30.2 } })
    page()
    await openBackupTab()
    expect(text()).toContain('بیش از ۲۴ ساعت قدیمی است')
    expect(text()).toContain('۳۰٫۲')
  })

  it('shows a failed restore drill as a failure, with its reason', async () => {
    routeData({
      ...STATUS_OK, drill_state: 'failed',
      last_drill: { ok: false, backup: 'cafe-bad.db', error: 'داده‌های بازیابی‌شده با نسخهٔ پشتیبان یکسان نیست' },
      errors: [{ id: 3, kind: 'drill', status: 'failed', at: '2026-10-25T09:07:00', detail: 'داده‌های بازیابی‌شده یکسان نیست' }],
    })
    page()
    await openBackupTab()
    expect(text()).toContain('آزمون بازیابی ناموفق')
    expect(text()).toContain('یکسان نیست')
  })

  it('says so when a backup has never been restore-tested', async () => {
    routeData({ ...STATUS_OK, drill_state: 'never', last_drill: null })
    page()
    await openBackupTab()
    expect(text()).toContain('هنوز آزمایش نشده')
  })

  it('runs the drill and reports the matched figures', async () => {
    routeData()
    post.mockResolvedValue({ ok: true, duration_ms: 120, backup: 'cafe-x.db', figures: { 'orders.count': 12, 'payments.sum': 4_500_000 } })
    page()
    await openBackupTab()
    await user().click(screen.getByRole('button', { name: /آزمون بازیابی/ }))
    await waitFor(() => expect(post).toHaveBeenCalledWith('/system/backups/drill'))
    await waitFor(() => expect(text()).toContain('۱۲ سفارش'))
  })

  it('tells the manager when the drill failed instead of a success message', async () => {
    routeData()
    post.mockRejectedValue(new Error('داده‌های بازیابی‌شده با نسخهٔ پشتیبان یکسان نیست'))
    page()
    await openBackupTab()
    await user().click(screen.getByRole('button', { name: /آزمون بازیابی/ }))
    await waitFor(() => expect(text()).toContain('آزمون بازیابی ناموفق'))
  })

  it('explains PostgreSQL backups and warns when pg_dump is missing', async () => {
    routeData({ ...STATUS_OK, database: 'postgresql', pg_tools: { pg_dump: null, pg_restore: null } },
      [], { interval_minutes: 60, keep_days: 14, enabled: true, database: 'postgresql' })
    page()
    await openBackupTab()
    expect(text()).toContain('pg_dump')
    expect(text()).toContain('نصب نیست')
  })
})
