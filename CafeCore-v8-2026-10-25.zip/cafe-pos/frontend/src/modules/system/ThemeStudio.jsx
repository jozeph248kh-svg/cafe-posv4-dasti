/**
 * Settings → «ظاهر و تم»: skin gallery, business default (all devices), per-device choice, editor with live preview,
 * readability (contrast) report with auto-fix, JSON import/export.
 */
import {
  CheckCircleFilled, CopyOutlined, DeleteOutlined, DownloadOutlined, EditOutlined, ExclamationCircleFilled, PlusOutlined,
  StarFilled, ThunderboltOutlined, UploadOutlined,
} from '@ant-design/icons'
import { Alert, App, Button, Card, ColorPicker, Drawer, Input, Segmented, Select, Slider, Space, Switch, Table, Tag, Tooltip, Typography, Upload } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { DevicePrefs, MODE_OPTIONS } from '../../components/ThemeSwitcher'
import { num } from '../../core/format'
import {
  BUILTIN_IDS, COLOR_KEYS, COLOR_LABELS, contrastReport, DEFAULT_SKIN_ID, derive, exportSkin, findSkin, FONTS, importSkin, normalizeSkin, SCALES,
} from '../../core/skins'
import { useTheme } from '../../core/theme'

const MAX_CUSTOM = 20
const newId = () => `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`
const clone = (x) => JSON.parse(JSON.stringify(x))

/** A miniature of the app painted with the skin's own variables (scoped to this element). */
export function SkinPreview({ skin, dark, big }) {
  const vars = useMemo(() => derive(skin, dark).vars, [skin, dark])
  return (
    <div className={`mini ${big ? 'big' : ''}`} style={vars} aria-hidden>
      <div className="mini-sider"><i className="logo" /><i className="on" /><i /><i /><i /></div>
      <div className="mini-main">
        <div className="mini-top"><b>داشبورد</b><span className="mini-pill">{dark ? 'تیره' : 'روشن'}</span></div>
        <div className="mini-cards">
          <div className="mini-card hero"><small>فروش امروز</small><b>۱۲٫۴ م</b></div>
          <div className="mini-card"><small>سفارش‌ها</small><b>۸۴</b><span className="mini-ok">+۱۲٪</span></div>
        </div>
        <div className="mini-card list">
          <div><span className="mini-tag" style={{ background: vars['--pal-1'] }}>کافه</span><small>کاپوچینو</small><span className="mini-bad">−۲</span></div>
          <div><span className="mini-tag" style={{ background: vars['--pal-2'] }}>غذا</span><small>پاستا آلفردو</small><span className="mini-warn">۳ دقیقه</span></div>
        </div>
        <div className="mini-row"><span className="mini-btn">ثبت سفارش</span><span className="mini-link">جزئیات</span></div>
      </div>
    </div>
  )
}

function ContrastTable({ skin, onFix }) {
  const rows = useMemo(() => contrastReport(skin), [skin])
  const fixable = rows.filter((r) => r.key && r.fixed)
  const bad = rows.filter((r) => r.ratio < r.min)
  return (
    <>
      <Space wrap style={{ marginBottom: 10 }}>
        {bad.length === 0
          ? <Tag color="success" icon={<CheckCircleFilled />}>همهٔ متن‌ها خوانا هستند</Tag>
          : <Tag color="error" icon={<ExclamationCircleFilled />}>{num(bad.length)} مورد کم‌کنتراست</Tag>}
        {fixable.length > 0 && <Typography.Text type="secondary" style={{ fontSize: 12 }}>{num(fixable.length)} رنگ هنگام نمایش خودکار پررنگ/کم‌رنگ می‌شود تا خوانا بماند.</Typography.Text>}
        {fixable.length > 0 && <Button size="small" icon={<ThunderboltOutlined />} onClick={() => onFix(fixable)} className="contrast-fix">اعمال اصلاح در رنگ‌ها</Button>}
      </Space>
      <Table size="small" pagination={false} rowKey={(r) => `${r.dark}-${r.label}`} dataSource={rows} className="contrast-table" scroll={{ x: 460 }}
        columns={[
          { title: 'حالت', dataIndex: 'dark', width: 52, render: (d) => (d ? 'تیره' : 'روشن') },
          { title: 'مورد', dataIndex: 'label', render: (v) => <span className="cx-label">{v}</span> },
          { title: 'نمونه', width: 64, render: (_, r) => <span className="cx-sample" style={{ background: r.bg, color: r.used }}>متن</span> },
          { title: 'کنتراست (حداقل)', dataIndex: 'ratio', width: 120, render: (v, r) => <span className="cx-ratio"><b style={{ color: v >= r.min ? 'var(--green)' : 'var(--red)' }}>{num(v, 1)}</b> <small>({num(r.min, 1)})</small></span> },
          { title: 'وضعیت', width: 104, render: (_, r) => (r.ratio < r.min ? <Tag color="error">ناخوانا</Tag> : r.fixed ? <Tooltip title={`رنگ انتخابی ${r.picked} ← نمایش ${r.used}`}><Tag color="processing">اصلاح خودکار</Tag></Tooltip> : <Tag color="success">خوب</Tag>) },
        ]} />
    </>
  )
}

function SkinEditor({ draft, setDraft, isNew, onClose, onSave, saving }) {
  const t = useTheme()
  const [mode, setMode] = useState(t.dark ? 'dark' : 'light')
  const [live, setLive] = useState(true)
  const skin = useMemo(() => normalizeSkin(draft), [draft])
  const { setPreview } = t
  useEffect(() => {                                     // debounced: dragging a colour must not re-render the whole app per pixel
    const id = setTimeout(() => setPreview(live ? skin : null), 120)
    return () => clearTimeout(id)
  }, [live, skin, setPreview])
  useEffect(() => () => setPreview(null), [setPreview])
  const setColor = (k, hex) => setDraft((d) => ({ ...d, [mode]: { ...d[mode], [k]: hex } }))
  const setPal = (i, hex) => setDraft((d) => { const p = [...d.palette]; p[i] = hex; return { ...d, palette: p } })
  const applyFix = (rows) => setDraft((d) => {
    const n = clone(d)
    rows.forEach((r) => { n[r.dark ? 'dark' : 'light'][r.key] = r.used })
    return n
  })
  const hex = (c) => (typeof c === 'string' ? c : c?.toHexString?.() || '#000000')
  return (
    <Drawer open width={Math.min(980, window.innerWidth)} onClose={onClose} className="skin-editor"
      title={isNew ? 'تم جدید' : `ویرایش «${draft.name}»`}
      extra={<Space>
        <Button onClick={onClose}>انصراف</Button>
        <Button onClick={() => onSave(skin, false)} loading={saving} className="skin-save">ذخیره</Button>
        <Button type="primary" icon={<StarFilled />} onClick={() => onSave(skin, true)} loading={saving} className="skin-save-default">ذخیره و پیش‌فرض مجموعه</Button>
      </Space>}>
      <div className="se-grid">
        <div className="se-form">
          <Card size="small" title="نام و حالت">
            <Input value={draft.name} maxLength={40} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} placeholder="نام تم" className="skin-name" />
            <Space style={{ marginTop: 12, width: '100%', justifyContent: 'space-between' }} wrap>
              <Segmented value={mode} onChange={setMode} options={[{ value: 'light', label: MODE_OPTIONS[0].label }, { value: 'dark', label: MODE_OPTIONS[1].label }]} />
              <span><Switch size="small" checked={live} onChange={setLive} /> <Typography.Text type="secondary" style={{ fontSize: 12 }}>پیش‌نمایش زنده روی کل برنامه</Typography.Text></span>
            </Space>
          </Card>
          <Card size="small" title={`رنگ‌ها — حالت ${mode === 'dark' ? 'تیره' : 'روشن'}`} style={{ marginTop: 12 }}>
            <div className="se-colors">
              {COLOR_KEYS.map((k) => (
                <label key={k} className="se-color">
                  <ColorPicker value={draft[mode][k]} disabledAlpha format="hex" onChange={(c) => setColor(k, hex(c))} size="small" />
                  <span>{COLOR_LABELS[k]}</span>
                </label>
              ))}
            </div>
          </Card>
          <Card size="small" title="پالت (برچسب‌ها، آواتارها و نمودارها)" style={{ marginTop: 12 }}>
            <Space wrap>{draft.palette.map((c, i) => <ColorPicker key={i} value={c} disabledAlpha format="hex" size="small" onChange={(v) => setPal(i, hex(v))} />)}</Space>
          </Card>
          <Card size="small" title="شکل و نوشته" style={{ marginTop: 12 }}>
            <div className="se-knob"><span>گردی گوشه‌ها</span><Slider min={0} max={24} value={draft.radius} onChange={(v) => setDraft((d) => ({ ...d, radius: v }))} tooltip={{ formatter: (v) => `${num(v)} px` }} /></div>
            <div className="se-knob"><span>اندازهٔ متن</span><Segmented size="small" value={draft.font_scale} onChange={(v) => setDraft((d) => ({ ...d, font_scale: v }))} options={SCALES} /></div>
            <div className="se-knob"><span>فاصله‌ها</span><Segmented size="small" value={draft.density} onChange={(v) => setDraft((d) => ({ ...d, density: v }))} options={[{ value: 'comfortable', label: 'راحت' }, { value: 'compact', label: 'فشرده' }]} /></div>
            <div className="se-knob"><span>فونت</span><Select size="small" style={{ width: 160 }} value={draft.font} onChange={(v) => setDraft((d) => ({ ...d, font: v }))} options={Object.entries(FONTS).map(([value, f]) => ({ value, label: f.label }))} /></div>
          </Card>
        </div>
        <div className="se-side">
          <div className="se-previews"><SkinPreview skin={skin} dark={false} big /><SkinPreview skin={skin} dark big /></div>
          <Card size="small" title="خوانایی متن‌ها (کنتراست WCAG)" style={{ marginTop: 12 }}>
            <ContrastTable skin={skin} onFix={applyFix} />
          </Card>
        </div>
      </div>
    </Drawer>
  )
}

export default function ThemeStudio() {
  const t = useTheme()
  const { message, modal } = App.useApp()
  const [draft, setDraft] = useState(null)
  const [isNew, setIsNew] = useState(false)
  const [saving, setSaving] = useState(false)
  const custom = t.business.custom
  const businessId = findSkin(t.business.skin, custom).id

  const persist = async (next, okMsg) => {
    setSaving(true)
    try { await t.saveBusiness(next); message.success(okMsg); return true } catch (e) { message.error(e.message); return false } finally { setSaving(false) }
  }
  const makeDefault = (s) => persist({ skin: s.id, custom }, `«${s.name}» تم پیش‌فرض مجموعه شد؛ دستگاه‌هایی که تم جدا ندارند خودکار به‌روز می‌شوند`)
  const startCopy = (s) => {
    if (custom.length >= MAX_CUSTOM) return message.warning(`حداکثر ${num(MAX_CUSTOM)} تم سفارشی`)
    setDraft({ ...clone(normalizeSkin(s)), id: newId(), name: `${s.name} — نسخهٔ من`.slice(0, 40), base: s.id, note: undefined }); setIsNew(true)
  }
  const startEdit = (s) => { setDraft(clone(s)); setIsNew(false) }
  const remove = (s) => modal.confirm({
    title: `حذف تم «${s.name}»؟`, okText: 'حذف', okType: 'danger', cancelText: 'انصراف',
    content: s.id === businessId ? 'این تم پیش‌فرض مجموعه است؛ پیش‌فرض به «کلاسیک» برمی‌گردد.' : 'دستگاه‌هایی که این تم را انتخاب کرده‌اند به پیش‌فرض مجموعه برمی‌گردند.',
    onOk: async () => {
      const ok = await persist({ skin: s.id === businessId ? DEFAULT_SKIN_ID : businessId, custom: custom.filter((c) => c.id !== s.id) }, 'تم حذف شد')
      if (ok && t.deviceSkin === s.id) t.setDeviceSkin('')
    },
  })
  const save = async (skin, asDefault) => {
    if (!skin.name.trim()) return message.error('نام تم را وارد کنید')
    const list = isNew ? [...custom, skin] : custom.map((c) => (c.id === skin.id ? skin : c))
    const ok = await persist({ skin: asDefault ? skin.id : businessId, custom: list }, asDefault ? `«${skin.name}» ذخیره و پیش‌فرض مجموعه شد` : `«${skin.name}» ذخیره شد`)
    if (ok) setDraft(null)
  }
  const exportFile = (s) => {
    const url = URL.createObjectURL(new Blob([exportSkin(s)], { type: 'application/json' }))
    const a = Object.assign(document.createElement('a'), { href: url, download: `${s.id}.cafe-skin.json` })
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  const importFile = async (file) => {
    try {
      if (file.size > 64 * 1024) throw new Error('فایل تم بیش از حد بزرگ است')
      const s = importSkin(await file.text())
      if (custom.length >= MAX_CUSTOM) throw new Error(`حداکثر ${num(MAX_CUSTOM)} تم سفارشی`)
      const clash = BUILTIN_IDS.includes(s.id) || custom.some((c) => c.id === s.id)
      setDraft({ ...s, id: clash ? newId() : s.id }); setIsNew(true)
      message.info('فایل خوانده شد؛ بررسی کنید و ذخیره بزنید')
    } catch (e) { message.error(e instanceof SyntaxError ? 'فایل JSON معتبر نیست' : e.message) }
    return false
  }

  return (
    <div className="theme-studio">
      <Alert type="info" showIcon style={{ marginBottom: 16 }}
        message="تم پیش‌فرض مجموعه روی همهٔ دستگاه‌ها اعمال می‌شود"
        description={<>هر دستگاه (صندوق، تبلت گارسون، نمایشگر آشپزخانه) می‌تواند از دکمهٔ «ظاهر و تم» در نوار بالا، تم، حالت تیره/روشن و اندازهٔ متن خودش را جدا انتخاب کند. رنگ متن‌ها همیشه خودکار طوری تنظیم می‌شود که خوانا بماند.</>} />
      <div className="studio-grid">
        <Card size="small" title="این دستگاه" className="studio-device"><DevicePrefs /></Card>
        <div>
          <div className="skin-toolbar">
            <Typography.Title level={5} style={{ margin: 0 }}>تم‌ها</Typography.Title>
            <Space wrap>
              <Upload accept=".json,application/json" showUploadList={false} beforeUpload={importFile}><Button icon={<UploadOutlined />} className="skin-import">ورود فایل تم</Button></Upload>
              <Button type="primary" icon={<PlusOutlined />} onClick={() => startCopy(findSkin(businessId, custom))} className="skin-new">تم جدید</Button>
            </Space>
          </div>
          <div className="skin-grid">
            {t.skins.map((s) => {
              const isCustom = !BUILTIN_IDS.includes(s.id)
              return (
                <div key={s.id} className={`skin-card ${s.id === businessId ? 'is-default' : ''}`} data-skin={s.id}>
                  <div className="skin-prev"><SkinPreview skin={s} dark={false} /><SkinPreview skin={s} dark /></div>
                  <div className="skin-meta">
                    <b>{s.name}</b>
                    {s.id === businessId && <Tag color="gold" icon={<StarFilled />}>پیش‌فرض مجموعه</Tag>}
                    {t.deviceSkin === s.id && <Tag color="blue">این دستگاه</Tag>}
                    {isCustom && <Tag>سفارشی</Tag>}
                    {s.note && <small>{s.note}</small>}
                  </div>
                  <div className="skin-actions">
                    {s.id !== businessId && <Button size="small" type="primary" ghost icon={<StarFilled />} onClick={() => makeDefault(s)} loading={saving} className="make-default">پیش‌فرض مجموعه</Button>}
                    <Button size="small" onClick={() => t.setDeviceSkin(t.deviceSkin === s.id ? '' : s.id)} className="use-device">{t.deviceSkin === s.id ? 'برگشت به پیش‌فرض' : 'فقط این دستگاه'}</Button>
                    <Tooltip title="کپی و ویرایش"><Button size="small" icon={<CopyOutlined />} onClick={() => startCopy(s)} aria-label="کپی و ویرایش" /></Tooltip>
                    {isCustom && <Tooltip title="ویرایش"><Button size="small" icon={<EditOutlined />} onClick={() => startEdit(s)} aria-label="ویرایش" /></Tooltip>}
                    <Tooltip title="خروجی فایل"><Button size="small" icon={<DownloadOutlined />} onClick={() => exportFile(s)} aria-label="خروجی فایل" /></Tooltip>
                    {isCustom && <Tooltip title="حذف"><Button size="small" danger icon={<DeleteOutlined />} onClick={() => remove(s)} aria-label="حذف" /></Tooltip>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
      {draft && <SkinEditor draft={draft} setDraft={setDraft} isNew={isNew} saving={saving} onClose={() => setDraft(null)} onSave={save} />}
    </div>
  )
}
