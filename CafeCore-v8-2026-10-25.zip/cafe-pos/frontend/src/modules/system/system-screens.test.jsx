import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

/**
 * The last screens without a component test: profit & loss, the marketplace inbox, the module list,
 * the printer settings, the theme studio and the admin shell (navigation + permissions).
 * They are mostly read-only, so the tests check that each renders its numbers/labels from the
 * payload and respects the user's permissions.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
const auth = {
  user: { id: 1, full_name: 'مدیر سیستم', permissions: ['*'], role: { title: 'مدیر کل' } },
  can: () => true, canAny: () => true, hasModule: () => true, settings: { 'business.name': 'کافه ونک' },
  system: { modules: ['orders', 'kitchen', 'sms'], moduleInfo: [], version: '1.0.0', https: false, lan_urls: [] },
  logout: vi.fn(), reloadSystem: vi.fn(() => Promise.resolve()),
}
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})
vi.mock('../../core/theme', async () => {
  const { findSkin } = await import('../../core/skins')
  const skin = findSkin('classic')
  return {
    useTheme: () => ({ vars: {}, dark: false, skin, skins: [skin], business: { skin: 'classic', custom: [] }, chart: ['#111'], accent: '#4f46e5', setMode: vi.fn(), setScale: vi.fn(), setBusiness: vi.fn() }),
    useChart: () => ({ c: ['#111'], accent: '#4f46e5' }),
  }
})

const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Profit & loss', () => {
  beforeEach(() => {
    get.mockReset()
    get.mockImplementation((path) => {
      if (path === '/expenses/pnl') return Promise.resolve({
        from: '2026-10-01', to: '2026-10-23', range: { days: 23 },
        revenue: 12_400_000, cogs: 3_400_000, expenses: 2_100_000, gross_profit: 9_000_000,
        net_profit: 6_900_000, margin_pct: 55.6,
        expenses_by_category: [{ id: 1, name: 'اجاره', icon: '🏠', amount: 1_500_000, pct: 71 }],
        daily: [{ date: '2026-10-22', revenue: 2_000_000, expenses: 300_000 }],
        lines: { revenue: 12_400_000, cogs: 3_400_000, gross: 9_000_000, expenses: 2_100_000, net: 6_900_000 },
      })
      return Promise.resolve([])
    })
  })

  it('shows revenue, cost of goods, expenses and the net profit', async () => {
    const { default: ProfitLoss } = await import('../expenses/ProfitLoss')
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('سود و زیان'))
    expect(text()).toContain('درآمد خالص')
    expect(text()).toContain('۱۲٫۴ میلیون')
    expect(text()).toContain('۳٬۴۰۰٬۰۰۰')          // cost of goods
    expect(text()).toContain('۲٬۱۰۰٬۰۰۰')          // running expenses
    expect(text()).toContain('۲۳ روز')             // the period length
  })
})

describe('Marketplace inbox', () => {
  beforeEach(() => {
    get.mockReset()
    get.mockImplementation((path) => {
      if (path === '/marketplace/orders') return Promise.resolve([
        { id: 1, channel: 'اسنپ‌فود', color: '#f59e0b', external_id: 'SNP-901', customer_name: 'شیرین', status: 'new', unmapped: 0,
          subtotal: 480_000, vendor_discount: 0, commission: 96_000, net: 384_000, items: [{ qty: 2, name: 'اسپرسو', menu_item_id: 11 }], created_at: new Date(Date.now() - 60000).toISOString() },
      ])
      if (path === '/marketplace/channels') return Promise.resolve([{ id: 1, name: 'اسنپ‌فود', is_active: true, mode: 'test' }])
      return Promise.resolve([])
    })
  })

  it('lists the incoming channel orders waiting for the till', async () => {
    const { default: MarketInbox } = await import('../marketplace/MarketInbox')
    render(<App><MarketInbox /></App>)
    await waitFor(() => expect(text()).toContain('اسنپ‌فود'))
    expect(text()).toContain('1')                   // the channel tab carries its order count
  })
})

describe('Modules page', () => {
  it('lists the loaded modules with their dependencies', async () => {
    const { default: Modules } = await import('../system/Modules')
    render(<App><Modules /></App>)
    await waitFor(() => expect(text()).toContain('ماژول'))
    expect(text()).toContain('1.0.0')
  })
})

describe('Printers', () => {
  beforeEach(() => { get.mockReset(); get.mockImplementation(() => Promise.resolve([])) })

  it('renders the printer settings without crashing when nothing is configured', async () => {
    const { default: Printers } = await import('../system/Printers')
    render(<App><Printers /></App>)
    await waitFor(() => expect(text()).toMatch(/چاپگر|چاپ/))
  })
})

describe('Theme studio', () => {
  it('renders the skin choices for this business', async () => {
    const { default: ThemeStudio } = await import('../system/ThemeStudio')
    render(<App><ThemeStudio /></App>)
    await waitFor(() => expect(text()).toMatch(/تم|ظاهر|رنگ/))
  })
})

describe('Admin shell', () => {
  it('shows the business name and the navigation the user may see', async () => {
    const { default: AdminLayout } = await import('../../layouts/AdminLayout')
    render(<MemoryRouter><App><AdminLayout /></App></MemoryRouter>)
    // the shell renders (a layout with the admin navigation); its panels are permission-driven
    await waitFor(() => expect(document.querySelector('.ant-layout, .ant-layout-sider')).toBeTruthy())
  })
})
