import { CheckCircleFilled } from '@ant-design/icons'
import { Alert, Card, Col, Row, Tag, Typography } from 'antd'
import { PageHeader } from '../../components/common'
import { useAuth } from '../../core/auth'

export default function Modules() {
  const { system } = useAuth()
  const mods = system.moduleInfo || []
  const titles = Object.fromEntries(mods.map((m) => [m.name, m.title]))
  return (
    <div className="fade-in">
      <PageHeader title="ماژول‌ها" subtitle={`نسخه ${system.version || ''} — معماری ماژولار: هر قابلیت جدید به‌صورت یک ماژول مستقل اضافه می‌شود`} />
      <Typography.Title level={5}>ماژول‌های نصب‌شده</Typography.Title>
      <Row gutter={[16, 16]} style={{ marginBottom: 20 }}>
        {mods.map((m) => (
          <Col key={m.name} xs={24} sm={12} xl={6}>
            <Card className="card-r hover-lift" size="small">
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><b><CheckCircleFilled style={{ color: 'var(--green)' }} /> {m.title}</b>{m.core ? <Tag>هسته</Tag> : <Tag color="blue">v{m.version}</Tag>}</div>
              <Typography.Paragraph type="secondary" style={{ margin: '8px 0 0', fontSize: 12 }}>{m.description}</Typography.Paragraph>
              {m.depends?.length > 0 && <div className="muted" style={{ fontSize: 11, marginTop: 6 }}>وابسته به: {m.depends.map((d) => titles[d] || d).join('، ')}</div>}
              <span className="ltr muted" style={{ fontSize: 11 }}>{m.name}</span>
            </Card>
          </Col>
        ))}
      </Row>
      <Alert type="success" showIcon message={`${mods.length} ماژول نصب و فعال است`}
        description="هر قابلیت یک ماژول مستقل در پوشه backend/app/modules است؛ قابلیت جدید بدون دست زدن به بخش‌های دیگر، به‌صورت یک ماژول تازه اضافه می‌شود." />
    </div>
  )
}
