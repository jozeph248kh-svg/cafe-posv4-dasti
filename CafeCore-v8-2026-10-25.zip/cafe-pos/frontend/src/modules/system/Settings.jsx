import { CheckCircleOutlined, CloudDownloadOutlined, DatabaseOutlined, ExperimentOutlined, SaveOutlined, UploadOutlined, WarningOutlined } from '@ant-design/icons'
import { Alert, App, Button, Card, Col, Descriptions, Divider, Form, Input, InputNumber, Row, Space, Statistic, Switch, Table, Tabs, Tag, Typography, Upload } from 'antd'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { PageHeader } from '../../components/common'
import { download, post, put, upload } from '../../core/api'
import { useAuth } from '../../core/auth'
import Printers from './Printers'
import ThemeStudio from './ThemeStudio'
import { faDateTime, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

// Settings keys contain dots; antd Form treats names as paths only when given as arrays, so a string name is safe.
function Field({ k, label, children, help, bool }) {
  return <Form.Item name={k} label={label} extra={help} valuePropName={bool ? 'checked' : 'value'}>{children}</Form.Item>
}

function Logo({ value, onChange }) {
  const { message } = App.useApp()
  return (
    <Space>
      {value && <img src={value} alt="" style={{ height: 56, borderRadius: 10, background: '#fff', padding: 4 }} />}
      <Upload showUploadList={false} accept="image/*" customRequest={async ({ file }) => { try { onChange((await upload(file)).url) } catch (e) { message.error(e.message) } }}>
        <Button icon={<UploadOutlined />}>{value ? 'تغییر لوگو' : 'بارگذاری لوگو'}</Button>
      </Upload>
      {value && <Button type="text" danger onClick={() => onChange(null)}>حذف</Button>}
    </Space>
  )
}

const BACKUP_KINDS = {
  hourly: ['ساعتی', 'blue'], daily: ['روزانه', 'green'], auto: ['روزانه', 'green'], manual: ['دستی', 'purple'],
  'pre-upgrade': ['قبل از ارتقا', 'orange'], 'pre-restore': ['قبل از بازیابی', 'orange'],
}

const DRILL_STATE = { ok: ['آزمون بازیابی موفق', 'success'], failed: ['آزمون بازیابی ناموفق', 'error'], never: ['هنوز آزمایش نشده', 'warning'] }

/** Backup status card: is the newest backup recent, and has it been *proven* restorable? */
function BackupStatus({ state, onDrill, busy, onRefresh }) {
  if (!state) return null
  const newest = state.newest
  const [drillLabel, drillColor] = DRILL_STATE[state.drill_state] || DRILL_STATE.never
  return (
    <Card size="small" style={{ marginBottom: 12 }} title={<Space><DatabaseOutlined />وضعیت پشتیبان‌گیری</Space>}
      extra={<Space>
        <Button size="small" icon={<ExperimentOutlined />} loading={busy} onClick={onDrill}>آزمون بازیابی</Button>
        <Button size="small" onClick={onRefresh}>به‌روزرسانی</Button>
      </Space>}>
      <Row gutter={[12, 12]}>
        <Col xs={12} md={6}><Statistic title="آخرین نسخه" value={newest ? num(newest.age_hours ?? 0, 1) : '—'}
          suffix={newest ? 'ساعت پیش' : ''} prefix={state.stale ? <WarningOutlined style={{ color: 'var(--red)' }} /> : <CheckCircleOutlined style={{ color: 'var(--green)' }} />} /></Col>
        <Col xs={12} md={6}><Statistic title="تعداد نسخه‌ها" value={state.count} suffix={`· ${num((state.total_size || 0) / 1024 / 1024, 1)} مگابایت`} /></Col>
        <Col xs={12} md={6}><Statistic title="آزمون بازیابی" value={drillLabel} valueStyle={{ fontSize: 15, color: drillColor === 'success' ? 'var(--green)' : drillColor === 'error' ? 'var(--red)' : 'var(--amber)' }} /></Col>
        <Col xs={12} md={6}><Statistic title="پایگاه داده" value={state.database === 'postgresql' ? 'PostgreSQL' : 'SQLite'} valueStyle={{ fontSize: 15 }} /></Col>
      </Row>
      <Descriptions size="small" column={1} style={{ marginTop: 8 }} items={[
        newest && { key: 'f', label: 'فایل', children: <span className="ltr">{newest.name}</span> },
        state.last_drill && { key: 'd', label: 'آخرین آزمون بازیابی', children:
          <span>{state.last_drill.ok ? 'موفق' : 'ناموفق'} — {state.last_drill.backup || '—'}
            {state.last_drill.checked_at ? ` · ${faDateTime(state.last_drill.checked_at)}` : ''}
            {state.last_drill.restored_into ? ` · مقصد: ${state.last_drill.restored_into}` : ''}</span> },
        state.last_successful_backup && { key: 's', label: 'آخرین پشتیبان موفق', children: faDateTime(state.last_successful_backup.at) },
      ].filter(Boolean)} />
      {state.stale && (
        <Alert type="error" showIcon style={{ marginTop: 8 }} message="آخرین پشتیبان بیش از ۲۴ ساعت قدیمی است"
          description="اگر همین حالا اطلاعات از دست برود، تا این لحظه چیزی قابل بازیابی نیست. یک نسخه جدید بسازید و فضای دیسک/دسترسی پوشه را بررسی کنید." />
      )}
      {state.drill_state === 'failed' && (
        <Alert type="error" showIcon style={{ marginTop: 8 }} message="آزمون بازیابی ناموفق بود"
          description={state.last_drill?.error || 'جزئیات در جدول پایین آمده است.'} />
      )}
    </Card>
  )
}

function Backups() {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/system/backups')
  const { data: policy } = useFetch('/system/backups/policy')
  const { data: state, reload: reloadState } = useFetch('/system/backups/status')
  const [busy, setBusy] = useState(false)
  const [drilling, setDrilling] = useState(false)
  const refresh = () => { reload(); reloadState() }
  const drill = async () => {
    setDrilling(true)
    try {
      const r = await post('/system/backups/drill')
      message.success(`آزمون بازیابی موفق بود (${num(r.duration_ms)} میلی‌ثانیه) — ${num(r.figures?.['orders.count'] || 0)} سفارش و ${num(r.figures?.['payments.sum'] || 0)} تومان پرداخت تطبیق داده شد`)
    } catch (e) {
      message.error(`آزمون بازیابی ناموفق: ${e.message}`)
    } finally { setDrilling(false); refresh() }
  }
  return (
    <>
      <BackupStatus state={state} busy={drilling} onDrill={drill} onRefresh={refresh} />
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="پشتیبان‌گیری خودکار"
        description={policy && (policy.enabled ? <>
          هر {num(policy.interval_minutes)} دقیقه، اگر اطلاعات تغییر کرده باشد، یک نسخه <b>ساعتی</b> گرفته می‌شود.
          با <b>بستن صندوق</b> یا شروع روز کاری بعد، فقط آخرین نسخه آن روز به‌عنوان نسخه <b>روزانه</b> می‌ماند و نسخه‌های ساعتی همان روز حذف می‌شوند.
          نسخه‌های روزانه {num(policy.keep_days)} روز نگه داشته می‌شوند؛ نسخه‌های دستی هرگز خودکار حذف نمی‌شوند.
          برای اطمینان بیشتر، نسخه‌ها را روی فلش یا فضای ابری هم نگه دارید.
        </> : 'کارهای پس‌زمینه خاموش است (CAFE_BACKGROUND_JOBS=false)؛ پشتیبان خودکار فقط هنگام اجرای برنامه گرفته می‌شود.')} />
      <Button type="primary" icon={<DatabaseOutlined />} loading={busy} style={{ marginBottom: 12 }} onClick={async () => { setBusy(true); try { await post('/system/backups'); message.success('نسخه پشتیبان ایجاد شد'); refresh() } catch (e) { message.error(e.message) } finally { setBusy(false) } }}>ایجاد نسخه پشتیبان</Button>
      {Boolean(state?.recent?.length) && (
        <Table rowKey="id" size="small" style={{ marginBottom: 12 }} dataSource={state.recent} pagination={false}
          title={() => 'رویدادهای اخیر پشتیبان‌گیری و بازیابی'}
          columns={[
            { title: 'نوع', dataIndex: 'kind', width: 90, render: (v) => (v === 'drill' ? <Tag color="geekblue">آزمون بازیابی</Tag> : <Tag>پشتیبان</Tag>) },
            { title: 'نتیجه', dataIndex: 'status', width: 90, render: (v) => (v === 'ok' ? <Tag color="green">موفق</Tag> : <Tag color="red">ناموفق</Tag>) },
            { title: 'زمان', dataIndex: 'at', width: 150, render: faDateTime },
            { title: 'فایل', dataIndex: 'file', responsive: ['md'], render: (v) => <span className="ltr muted" style={{ fontSize: 12 }}>{v || '—'}</span> },
            { title: 'خطا', dataIndex: 'detail', render: (v) => (v ? <span style={{ color: 'var(--red)', fontSize: 12 }}>{v}</span> : '—') },
          ]} />
      )}
      {policy?.database === 'postgresql' && (
        <Alert type="success" showIcon style={{ marginBottom: 12 }} message="پایگاه داده: PostgreSQL"
          description={<>نسخه‌ها با <span className="ltr">pg_dump -Fc</span> گرفته می‌شوند و آزمون بازیابی، هر نسخه را در یک پایگاه‌دادهٔ
            <b> موقت و جداگانه</b> بازسازی می‌کند؛ پایگاه‌دادهٔ اصلی هرگز بازنویسی نمی‌شود.
            {state?.pg_tools && !state.pg_tools.pg_dump ? ' ابزار pg_dump روی این سیستم نصب نیست — postgresql-client را نصب کنید.' : ''}</>} />
      )}
      <Table rowKey="name" size="small" loading={loading} dataSource={data || []} pagination={{ pageSize: 10 }} scroll={{ x: 560 }}
        columns={[
          { title: 'نوع', dataIndex: 'kind', width: 120, render: (v) => { const [t, c] = BACKUP_KINDS[v] || [v, 'default']; return <Tag color={c}>{t}</Tag> },
            filters: Object.entries({ hourly: 'ساعتی', daily: 'روزانه', manual: 'دستی' }).map(([value, text]) => ({ value, text })), onFilter: (v, r) => r.kind === v || (v === 'daily' && r.kind === 'auto') },
          { title: 'زمان', dataIndex: 'created_at', render: faDateTime },
          { title: 'حجم', dataIndex: 'size', render: (v) => `${num(v / 1024 / 1024, 2)} مگابایت` },
          { title: 'فایل', dataIndex: 'name', responsive: ['lg'], render: (v) => <span className="ltr muted" style={{ fontSize: 12 }}>{v}</span> },
          { title: '', render: (_, r) => <Button size="small" icon={<CloudDownloadOutlined />} onClick={() => download(`/system/backups/${r.name}`, null, r.name)}>دانلود</Button> },
        ]} />
    </>
  )
}

export default function Settings() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [saving, setSaving] = useState(false)
  useEffect(() => { form.setFieldsValue(auth.settings) }, [auth.settings, form])
  const save = async () => {
    setSaving(true)
    try {
      await put('/system/settings', form.getFieldsValue(true))
      await auth.reloadSystem()
      message.success('تنظیمات ذخیره شد')
    } catch (e) { message.error(e.message) } finally { setSaving(false) }
  }
  const lan = auth.system.lan_urls || []
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') || 'biz'
  return (
    <div className="fade-in">
      <PageHeader title="تنظیمات" subtitle="اطلاعات مجموعه، مالیات و سرویس، فیش، آشپزخانه، پشتیبان‌گیری و ظاهر برنامه"
        extra={tab !== 'theme' && <Button type="primary" icon={<SaveOutlined />} loading={saving} onClick={save}>ذخیره تنظیمات</Button>} />
      <Form form={form} layout="vertical">
        <Card className="card-r">
          <Tabs tabPosition={window.innerWidth > 900 ? 'right' : 'top'} activeKey={tab} onChange={(k) => setParams(k === 'biz' ? {} : { tab: k }, { replace: true })} items={[
            { key: 'biz', label: 'اطلاعات مجموعه', children: (
              <Row gutter={16}>
                <Col xs={24} md={12}><Field k="business.name" label="نام کافه / رستوران"><Input /></Field></Col>
                <Col xs={24} md={12}><Field k="business.phone" label="تلفن"><Input className="ltr" /></Field></Col>
                <Col xs={24}><Field k="business.address" label="آدرس"><Input /></Field></Col>
                <Col xs={24} md={12}><Field k="business.instagram" label="اینستاگرام"><Input className="ltr" placeholder="cafe.example" /></Field></Col>
                <Col xs={24} md={12}><Field k="business.wifi" label="رمز وای‌فای مهمان" help="در منوی QR به مشتری نمایش داده می‌شود"><Input className="ltr" /></Field></Col>
                <Col xs={24}><Field k="business.logo" label="لوگو"><Logo /></Field></Col>
              </Row>
            ) },
            { key: 'money', label: 'مالیات و سرویس', children: (
              <Row gutter={16}>
                <Col xs={12} md={6}><Field k="tax.enabled" label="مالیات بر ارزش افزوده" bool><Switch /></Field></Col>
                <Col xs={12} md={6}><Field k="tax.percent" label="درصد مالیات"><InputNumber min={0} max={30} addonAfter="٪" /></Field></Col>
                <Col xs={12} md={6}><Field k="service.enabled" label="حق سرویس (فقط سالن)" bool><Switch /></Field></Col>
                <Col xs={12} md={6}><Field k="service.percent" label="درصد سرویس"><InputNumber min={0} max={30} addonAfter="٪" /></Field></Col>
                <Col xs={24} md={12}><Field k="rounding.step" label="گرد کردن مبلغ نهایی" help="مثلاً ۱۰۰۰ = گرد به نزدیک‌ترین هزار تومان؛ صفر = خاموش"><InputNumber min={0} step={500} style={{ width: 200 }} addonAfter="تومان" /></Field></Col>
                <Col xs={24} md={12}><Field k="currency.label" label="واحد پول"><Input style={{ width: 160 }} /></Field></Col>
              </Row>
            ) },
            { key: 'ops', label: 'صندوق و عملیات', children: (
              <Row gutter={16}>
                <Col xs={24} md={12}><Field k="shift.required" label="الزام باز بودن شیفت صندوق برای دریافت پول" bool help="برای کنترل دقیق نقدینگی توصیه می‌شود روشن باشد"><Switch /></Field></Col>
                <Col xs={24} md={12}><Field k="day.cutoff_hour" label="ساعت پایان روز کاری" help="فروش قبل از این ساعت (بعد از نیمه‌شب) جزو روز قبل حساب می‌شود"><InputNumber min={0} max={12} addonAfter="بامداد" /></Field></Col>
                <Col xs={24} md={12}><Field k="qr.call_enabled" label="امکان صدا زدن گارسون از منوی QR" bool><Switch /></Field></Col>
                <Col xs={24}><Divider orientation="right" plain>میزها و مدت نشستن</Divider></Col>
                <Col xs={24} md={12}><Field k="pos.table_warn_minutes" label="هشدار طولانی شدن نشستن" help="از این مدت به بعد، کارت میز زرد می‌شود (هنوز مجاز است)"><InputNumber min={1} max={600} addonAfter="دقیقه" /></Field></Col>
                <Col xs={24} md={12}><Field k="pos.table_limit_minutes" label="سقف مجاز نشستن" help="از این مدت به بعد کارت میز قرمز می‌شود و مدت اضافه روی میز نشان داده می‌شود"><InputNumber min={5} max={600} addonAfter="دقیقه" /></Field></Col>
                <Col xs={24} md={12}><Field k="discount.reason_required" label="الزام نوشتن دلیل برای تخفیف دستی" bool help="تخفیف‌های آماده نام خودشان را به‌عنوان دلیل ثبت می‌کنند"><Switch /></Field></Col>
                <Col xs={24}><Divider orientation="right" plain>پایان شیفت کارکنان</Divider></Col>
                <Col xs={24} md={12}><Field k="shift.blind_close" label="شمارش کور صندوق" bool help="صندوقدار مبلغ نقدی مورد انتظار را نمی‌بیند و پول را بی‌طرفانه می‌شمارد؛ فقط نقش‌های دارای «دیدن نقد مورد انتظار صندوق» (مدیر) آن را می‌بینند"><Switch /></Field></Col>
                <Col xs={24} md={12}><Field k="shift.report_required" label="الزام گزارش پایان شیفت قبل از ثبت خروج" bool help="هر کارمند قبل از ثبت خروج باید صندوق باز به نام خود را تحویل دهد و گزارش شیفت را برای مدیر بفرستد"><Switch /></Field></Col>
                <Col xs={24} md={12}><Field k="shift.hours" label="طول شیفت کاری" help="برای نمایش پیشرفت شیفت و یادآوری پایان آن"><InputNumber min={1} max={16} addonAfter="ساعت" /></Field></Col>
              </Row>
            ) },
            { key: 'kitchen', label: 'آشپزخانه', children: (
              <Row gutter={16}>
                <Col xs={24} md={12}><Field k="kitchen.late_minutes" label="زمان هشدار تأخیر سفارش" help="بعد از این زمان، تیکت در نمایشگر آشپزخانه قرمز می‌شود"><InputNumber min={3} max={90} addonAfter="دقیقه" /></Field></Col>
                <Col xs={24} md={12}><Field k="kitchen.sound" label="صدای اعلان سفارش جدید" bool><Switch /></Field></Col>
              </Row>
            ) },
            { key: 'receipt', label: 'فیش و چاپ', children: (
              <Row gutter={16}>
                <Col xs={24}><Field k="receipt.footer" label="متن پایین فیش"><Input.TextArea rows={2} /></Field></Col>
                <Col xs={24} md={12}><Field k="receipt.show_logo" label="چاپ لوگو روی فیش" bool><Switch /></Field></Col>
                <Col xs={24}><Typography.Text type="secondary">بدون پرینتر شبکه‌ای، چاپ از طریق مرورگر انجام می‌شود؛ در تنظیمات چاپ مرورگر، حاشیه را «هیچ» و مقیاس را ۱۰۰٪ قرار دهید.</Typography.Text></Col>
                <Col xs={24} style={{ marginTop: 16 }}><Printers /></Col>
              </Row>
            ) },
            { key: 'network', label: 'شبکه و دستگاه‌ها', children: (
              <>
                <Typography.Paragraph>دستگاه‌های دیگر (تبلت آشپزخانه، گوشی گارسون‌ها) در همین شبکه وای‌فای با این آدرس‌ها وصل می‌شوند:</Typography.Paragraph>
                {lan.length ? lan.map((u) => <Typography.Paragraph key={u} copyable className="ltr url-latin" style={{ fontSize: 18, fontWeight: 700 }}>{u}</Typography.Paragraph>) : <Typography.Text type="secondary">آدرس شبکه‌ای پیدا نشد.</Typography.Text>}
                {auth.system.https ? (
                  <Alert className="https-box" type="success" showIcon style={{ marginTop: 16 }} message="ارتباط امن (HTTPS) فعال است"
                    description={<>
                      <div>برای اینکه هر دستگاه بدون هشدار وصل شود، یک بار «گواهی این سرور» را روی آن نصب کنید:{' '}
                        <a href="/ca.crt" download="cafe-pos-ca.crt"><b>دانلود گواهی</b></a></div>
                      <ul style={{ margin: '8px 0 0', paddingInlineStart: 18 }}>
                        <li>اندروید: تنظیمات ← امنیت ← رمزگذاری و اعتبارنامه‌ها ← نصب گواهی ← گواهی CA ← فایل دانلودشده</li>
                        <li>آیفون/آیپد: باز کردن فایل در Safari ← تنظیمات ← نمایه دانلودشده ← نصب؛ سپس عمومی ← درباره ← تنظیمات اعتماد گواهی ← روشن کردن «Cafe POS Local CA»</li>
                        <li>ویندوز: دوبار کلیک روی فایل ← نصب گواهی ← Local Machine ← «Trusted Root Certification Authorities»</li>
                      </ul>
                    </>} />
                ) : (
                  <Alert type="info" showIcon style={{ marginTop: 16 }} message="ارتباط شبکه: HTTP (بدون رمزنگاری)"
                    description={<>برای رمزنگاری ارتباط دستگاه‌ها در وای‌فای، در فایل <span className="ltr">backend/.env</span> (کنار پوشه برنامه) خط <span className="ltr">CAFE_HTTPS=true</span> را اضافه کنید و برنامه را دوباره اجرا کنید؛ آدرس‌ها با https شروع می‌شوند و راهنمای نصب گواهی همین‌جا نمایش داده می‌شود.</>} />
                )}
              </>
            ) },
            { key: 'backup', label: 'پشتیبان‌گیری', children: <Backups /> },
            { key: 'theme', label: 'ظاهر و تم', children: <ThemeStudio /> },
          ]} />
        </Card>
      </Form>
    </div>
  )
}
