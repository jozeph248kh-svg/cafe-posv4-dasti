/** Network thermal printers (ESC/POS, port 9100): receipt printer per register, kitchen printers per station. */
import { DeleteOutlined, PlusOutlined, PrinterOutlined, SaveOutlined } from '@ant-design/icons'
import { Alert, App, Button, Input, InputNumber, Select, Space, Switch, Table, Tooltip } from 'antd'
import { useEffect, useState } from 'react'
import { get, post, put } from '../../core/api'
import { useAuth } from '../../core/auth'

const WIDTHS = [{ value: 576, label: '۸۰ میلی‌متر' }, { value: 512, label: '۷۲ میلی‌متر' }, { value: 384, label: '۵۸ میلی‌متر' }]

export default function Printers() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [rows, setRows] = useState([])
  const [dirty, setDirty] = useState(false)
  const [busy, setBusy] = useState(null)
  const [stations, setStations] = useState([])
  const [registers, setRegisters] = useState([])
  useEffect(() => {
    get('/system/printers').then(setRows).catch((e) => message.error(e.message))
    get('/menu/stations').then(setStations).catch(() => {})
    if (auth.hasModule('shifts')) get('/shifts/registers').then(setRegisters).catch(() => {})
  }, [auth, message])
  const set = (id, patch) => { setRows((r) => r.map((x) => (x.id === id ? { ...x, ...patch } : x))); setDirty(true) }
  const add = () => {
    const id = Math.max(0, ...rows.map((r) => r.id)) + 1
    setRows([...rows, { id, name: rows.length ? `چاپگر ${id}` : 'چاپگر صندوق', host: '', port: 9100, width: 576, receipt: !rows.length, register_id: null, drawer: false, station_ids: [] }])
    setDirty(true)
  }
  const save = async () => {
    setBusy('save')
    try { setRows(await put('/system/printers', { printers: rows })); setDirty(false); await auth.reloadSystem(); message.success('چاپگرها ذخیره شد') } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  const test = async (r) => {
    setBusy(r.id)
    try { await post(`/system/printers/${r.id}/test`); message.success(`صفحه آزمایشی به «${r.name}» ارسال شد`) } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  return (
    <div className="printers">
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message="چاپ مستقیم با پرینتر حرارتی شبکه‌ای"
        description="پرینترهای حرارتی شبکه‌ای (LAN، پورت ۹۱۰۰ — ESC/POS) بدون پنجره چاپ و بدون نصب درایور روی تبلت یا گوشی چاپ می‌کنند. فیش با فونت برنامه به‌صورت تصویر چاپ می‌شود، پس فارسی درست نمایش داده می‌شود. اگر پرینتری تعریف نشود یا در دسترس نباشد، چاپ از طریق مرورگر انجام می‌شود. آی‌پی پرینتر را ثابت کنید (صفحه تست خود پرینتر آن را نشان می‌دهد)." />
      <Table size="small" rowKey="id" dataSource={rows} pagination={false} scroll={{ x: 1050 }}
        locale={{ emptyText: 'چاپگری تعریف نشده — چاپ از طریق مرورگر' }}
        columns={[
          { title: 'نام', width: 150, render: (_, r) => <Input className="pr-name" value={r.name} maxLength={40} onChange={(e) => set(r.id, { name: e.target.value })} /> },
          { title: 'آی‌پی', width: 150, render: (_, r) => <Input className="ltr pr-host" placeholder="192.168.1.50" value={r.host} onChange={(e) => set(r.id, { host: e.target.value.trim() })} /> },
          { title: 'پورت', width: 90, render: (_, r) => <InputNumber className="pr-port" min={1} max={65535} value={r.port} onChange={(v) => set(r.id, { port: v || 9100 })} style={{ width: 80 }} /> },
          { title: 'عرض کاغذ', width: 120, render: (_, r) => <Select value={r.width} options={WIDTHS} onChange={(v) => set(r.id, { width: v })} style={{ width: 110 }} /> },
          { title: <Tooltip title="فیش مشتری و پیش‌فاکتور روی این پرینتر چاپ شود">فیش مشتری</Tooltip>, width: 90, render: (_, r) => <Switch size="small" checked={r.receipt} onChange={(v) => set(r.id, { receipt: v })} /> },
          ...(registers.length > 1 ? [{ title: 'صندوق', width: 150, render: (_, r) => (
            <Select disabled={!r.receipt} value={r.register_id ?? ''} style={{ width: 140 }} onChange={(v) => set(r.id, { register_id: v || null })}
              options={[{ value: '', label: 'همه صندوق‌ها' }, ...registers.filter((x) => x.is_active).map((x) => ({ value: x.id, label: x.name }))]} />
          ) }] : []),
          { title: <Tooltip title="کشوی پول به این پرینتر وصل است؛ با چاپ رسید پرداخت نقدی باز می‌شود">کشوی پول</Tooltip>, width: 90, render: (_, r) => <Switch size="small" checked={r.drawer} onChange={(v) => set(r.id, { drawer: v })} /> },
          { title: 'تیکت آشپزخانه (ایستگاه‌ها)', render: (_, r) => (
            <Select mode="multiple" allowClear placeholder="—" value={r.station_ids} style={{ minWidth: 180, width: '100%' }} onChange={(v) => set(r.id, { station_ids: v })}
              options={stations.map((st) => ({ value: st.id, label: st.name }))} />
          ) },
          { title: '', width: 90, render: (_, r) => (
            <Space size={4}>
              <Tooltip title={dirty ? 'ابتدا ذخیره کنید' : 'چاپ صفحه آزمایشی'}><Button size="small" icon={<PrinterOutlined />} disabled={dirty} loading={busy === r.id} onClick={() => test(r)} /></Tooltip>
              <Button size="small" danger type="text" icon={<DeleteOutlined />} onClick={() => { setRows(rows.filter((x) => x.id !== r.id)); setDirty(true) }} />
            </Space>
          ) },
        ]} />
      <Space style={{ marginTop: 12 }}>
        <Button icon={<PlusOutlined />} onClick={add} disabled={rows.length >= 20}>افزودن چاپگر</Button>
        <Button type="primary" icon={<SaveOutlined />} disabled={!dirty} loading={busy === 'save'} onClick={save} className="pr-save">ذخیره چاپگرها</Button>
      </Space>
    </div>
  )
}
