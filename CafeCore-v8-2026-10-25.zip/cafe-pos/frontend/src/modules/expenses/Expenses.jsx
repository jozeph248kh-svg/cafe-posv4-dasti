import { DeleteOutlined, EditOutlined, PlusOutlined, WalletOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, ColorPicker, Form, Input, InputNumber, Modal, Popconfirm, Progress, Row, Select, Switch, Table, Tabs, Tag, Tooltip, Typography } from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { useMemo, useState } from 'react'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader, StatCard } from '../../components/common'
import { del, post, put } from '../../core/api'
import { businessToday, faDate, isoDate, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

export const EXP_METHODS = { cash: { label: 'نقد', color: 'green' }, card: { label: 'کارت', color: 'blue' }, transfer: { label: 'حواله / انتقال', color: 'purple' } }

function ExpenseForm({ value, categories, onClose, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const editing = !!value?.id
  const method = Form.useWatch('method', form)
  const submit = async (v) => {
    setBusy(true)
    try {
      const body = { ...v, expense_date: isoDate(v.expense_date.toDate()), from_register: v.method === 'cash' && !!v.from_register }
      if (editing) await put(`/expenses/${value.id}`, body); else await post('/expenses', body)
      message.success(body.from_register && !editing ? 'هزینه ثبت و به‌عنوان برداشت از صندوق شیفت ثبت شد' : 'هزینه ذخیره شد')
      onDone()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  const init = editing ? { ...value, expense_date: dayjs(value.expense_date) } : { expense_date: dayjs(businessToday()), method: 'cash', from_register: false }
  return (
    <Modal open title={editing ? 'ویرایش هزینه' : 'ثبت هزینه جدید'} onCancel={onClose} onOk={() => form.submit()} confirmLoading={busy} okText="ذخیره" destroyOnClose width={560}>
      <JalaliLocaleListener />
      <Form form={form} layout="vertical" onFinish={submit} initialValues={init}>
        <Row gutter={12}>
          <Col span={14}>
            <Form.Item name="category_id" label="دسته هزینه" rules={[{ required: true, message: 'دسته را انتخاب کنید' }]}>
              <Select showSearch optionFilterProp="label" options={categories.filter((c) => c.is_active || c.id === value?.category_id).map((c) => ({ value: c.id, label: `${c.icon || ''} ${c.name}` }))} />
            </Form.Item>
          </Col>
          <Col span={10}><Form.Item name="expense_date" label="تاریخ" rules={[{ required: true }]}><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" /></Form.Item></Col>
          <Col span={14}>
            <Form.Item name="amount" label="مبلغ (تومان)" rules={[{ required: true, message: 'مبلغ را وارد کنید' }]}>
              <InputNumber min={1} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} disabled={editing && value.from_register} />
            </Form.Item>
          </Col>
          <Col span={10}>
            <Form.Item name="method" label="روش پرداخت">
              <Select disabled={editing && value.from_register} options={Object.entries(EXP_METHODS).map(([k, m]) => ({ value: k, label: m.label }))} />
            </Form.Item>
          </Col>
        </Row>
        {method === 'cash' && (
          <Form.Item name="from_register" valuePropName="checked" label="پرداخت از صندوق شیفت جاری" extra="در صورت فعال بودن، مبلغ به‌عنوان «برداشت از صندوق» در شیفت باز ثبت و در کسری/اضافه صندوق لحاظ می‌شود.">
            <Switch disabled={editing} />
          </Form.Item>
        )}
        <Form.Item name="payee" label="دریافت‌کننده / طرف حساب"><Input maxLength={80} placeholder="مثلاً: قبض برق، آقای رحیمی" /></Form.Item>
        <Form.Item name="note" label="توضیحات"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  )
}

function Categories({ cats }) {
  const { message } = App.useApp()
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    const body = { ...v, color: typeof v.color === 'string' ? v.color : v.color?.toHexString?.() || 'var(--pal-1)', is_active: v.is_active ?? true }
    try {
      if (edit.id) await put(`/expenses/categories/${edit.id}`, body); else await post('/expenses/categories', body)
      message.success('ذخیره شد'); setEdit(null); cats.reload()
    } catch (e) { message.error(e.message) }
  }
  const remove = async (c) => { try { await del(`/expenses/categories/${c.id}`); message.success('حذف شد (در صورت داشتن سابقه، غیرفعال می‌شود)'); cats.reload() } catch (e) { message.error(e.message) } }
  return (
    <>
      <Button icon={<PlusOutlined />} style={{ marginBottom: 12 }} onClick={() => { form.resetFields(); setEdit({}) }}>دسته جدید</Button>
      <Table rowKey="id" loading={cats.loading} dataSource={cats.data || []} pagination={false} size="middle"
        columns={[
          { title: 'دسته', render: (_, c) => <span style={{ fontWeight: 600 }}><span className="exp-dot" style={{ background: c.color }}>{c.icon}</span>{c.name}</span> },
          { title: 'وضعیت', dataIndex: 'is_active', width: 110, render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
          { title: '', width: 110, render: (_, c) => (<>
            <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(c); setEdit(c) }} />
            <Popconfirm title="این دسته حذف شود؟" onConfirm={() => remove(c)}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>
          </>) },
        ]} />
      <Modal open={!!edit} title={edit?.id ? 'ویرایش دسته' : 'دسته جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save} initialValues={{ color: 'var(--pal-1)', sort: 0, is_active: true }}>
          <Row gutter={12}>
            <Col span={16}><Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={8}><Form.Item name="icon" label="آیکن (ایموجی)"><Input maxLength={4} /></Form.Item></Col>
            <Col span={8}><Form.Item name="color" label="رنگ"><ColorPicker /></Form.Item></Col>
            <Col span={8}><Form.Item name="sort" label="ترتیب"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={8}><Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item></Col>
          </Row>
        </Form>
      </Modal>
    </>
  )
}

export default function Expenses() {
  const { message } = App.useApp()
  const [range, setRange] = useState(rangeOf('last30'))
  const [cat, setCat] = useState()
  const [q, setQ] = useState('')
  const [edit, setEdit] = useState(null)
  const cats = useFetch('/expenses/categories')
  const list = useFetch('/expenses', { date_from: range.from, date_to: range.to, category_id: cat, q: q || undefined })
  const d = list.data
  const days = useMemo(() => Math.max(1, Math.round((new Date(range.to) - new Date(range.from)) / 864e5) + 1), [range])
  const cash = (d?.items || []).filter((e) => e.from_register).reduce((a, e) => a + e.amount, 0)
  const remove = async (e) => { try { await del(`/expenses/${e.id}`); message.success(e.from_register ? 'هزینه حذف و مبلغ به صندوق برگشت داده شد' : 'هزینه حذف شد'); list.reload() } catch (err) { message.error(err.message) } }

  return (
    <div className="fade-in">
      <PageHeader title="هزینه‌ها" subtitle="ثبت هزینه‌های جاری کافه/رستوران؛ در صورت پرداخت از صندوق، در حساب شیفت هم لحاظ می‌شود"
        extra={[<JalaliRange key="r" value={range} onChange={setRange} presets={['today', 'week', 'month', 'last30', 'lastMonth']} />,
          <Button key="n" type="primary" icon={<PlusOutlined />} onClick={() => setEdit({})}>ثبت هزینه</Button>]} />
      <Row gutter={[16, 16]}>
        <Col xs={12} lg={6}><StatCard loading={list.loading} title="جمع هزینه‌ها" value={d?.total} money icon={<WalletOutlined />} color="var(--red)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={list.loading} title="تعداد" value={d?.items.length} icon={<span>🧾</span>} color="var(--pal-1)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={list.loading} title="میانگین روزانه" value={(d?.total || 0) / days} money icon={<span>📅</span>} color="var(--amber)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={list.loading} title="پرداخت از صندوق" value={cash} money icon={<span>💵</span>} color="var(--green)" /></Col>
      </Row>
      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24} xl={17}>
          <Card className="card-r">
            <Tabs items={[
              {
                key: 'list', label: 'فهرست هزینه‌ها', children: (<>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
                    <Select allowClear placeholder="همه دسته‌ها" style={{ width: 220 }} value={cat} onChange={setCat} options={(cats.data || []).map((c) => ({ value: c.id, label: `${c.icon || ''} ${c.name}` }))} />
                    <Input.Search allowClear placeholder="جستجو در طرف حساب / توضیحات" style={{ width: 280 }} onSearch={setQ} />
                  </div>
                  <Table rowKey="id" loading={list.loading} dataSource={d?.items || []} scroll={{ x: 760 }} pagination={{ pageSize: 15, hideOnSinglePage: true }}
                    summary={(rows) => rows.length ? (
                      <Table.Summary.Row><Table.Summary.Cell index={0} colSpan={3}><b>جمع</b></Table.Summary.Cell><Table.Summary.Cell index={3}><b>{money(rows.reduce((a, r) => a + r.amount, 0))}</b></Table.Summary.Cell><Table.Summary.Cell index={4} colSpan={3} /></Table.Summary.Row>
                    ) : null}
                    columns={[
                      { title: 'تاریخ', dataIndex: 'expense_date', render: faDate, width: 130 },
                      { title: 'دسته', render: (_, e) => <span><span className="exp-dot" style={{ background: e.color }}>{e.icon}</span>{e.category}</span> },
                      { title: 'طرف حساب / شرح', render: (_, e) => (<div>{e.payee || '—'}{e.note && <div style={{ fontSize: 12, color: 'var(--muted)' }}>{e.note}</div>}</div>) },
                      { title: 'مبلغ (تومان)', dataIndex: 'amount', render: (v) => <b>{money(v)}</b>, sorter: (a, b) => a.amount - b.amount },
                      { title: 'روش', dataIndex: 'method', render: (m, e) => (<><Tag color={EXP_METHODS[m]?.color}>{EXP_METHODS[m]?.label}</Tag>{e.from_register && <Tooltip title="از صندوق شیفت برداشت شده"><Tag color="gold">صندوق</Tag></Tooltip>}</>) },
                      { title: '', width: 96, render: (_, e) => (<>
                        <Button type="text" icon={<EditOutlined />} onClick={() => setEdit(e)} />
                        <Popconfirm title={e.from_register ? 'حذف شود؟ مبلغ به صندوق شیفت جاری برمی‌گردد.' : 'این هزینه حذف شود؟'} onConfirm={() => remove(e)}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>
                      </>) },
                    ]} />
                </>),
              },
              { key: 'cats', label: 'دسته‌بندی هزینه‌ها', children: <Categories cats={cats} /> },
            ]} />
          </Card>
        </Col>
        <Col xs={24} xl={7}>
          <Card className="card-r" title="تفکیک بر اساس دسته" loading={list.loading}>
            {(d?.by_category || []).length ? d.by_category.map((c) => (
              <div key={c.id} style={{ marginBottom: 12, cursor: 'pointer' }} onClick={() => setCat(cat === c.id ? undefined : c.id)}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span>{c.icon} {c.name} <Typography.Text type="secondary" style={{ fontSize: 11 }}>({num(c.count)})</Typography.Text></span><b>{money(c.amount)}</b>
                </div>
                <Progress percent={Math.round((c.amount / d.total) * 100)} strokeColor={c.color} size="small" format={(p) => `${num(p)}٪`} />
              </div>
            )) : <Typography.Text type="secondary">هزینه‌ای در این بازه ثبت نشده</Typography.Text>}
          </Card>
        </Col>
      </Row>
      {edit && <ExpenseForm value={edit} categories={cats.data || []} onClose={() => setEdit(null)} onDone={() => { setEdit(null); list.reload() }} />}
    </div>
  )
}
