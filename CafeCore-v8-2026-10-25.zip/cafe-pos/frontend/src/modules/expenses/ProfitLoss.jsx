import { FallOutlined, FireOutlined, RiseOutlined, ShoppingOutlined, WalletOutlined, DollarOutlined } from '@ant-design/icons'
import { Card, Col, Row, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { Bar, CartesianGrid, Cell, ComposedChart, Line, Pie, PieChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader, StatCard } from '../../components/common'
import { compact, faDate, faShort, faWeekday, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { MoneyTip, tooltipStyle } from '../dashboard/Dashboard'
import { useChart } from '../../core/theme'

function Row2({ label, value, pct, strong, neg, indent, color, border }) {
  // `neg` marks a row that is DEDUCTED (a cost line) — its number is shown in parentheses and red.
  // A row without `neg` keeps its own sign: a negative net revenue or gross profit must never be printed as a
  // positive number (that was the reported defect), so the sign always comes from the value itself.
  const v = Number(value || 0)
  const negative = neg ? v > 0 : v < 0
  return (
    <div className={`pnl-row${strong ? ' strong' : ''}${border ? ' border' : ''}`} style={{ paddingInlineStart: indent ? 22 : 0 }}>
      <span>{label}</span>
      <span style={{ display: 'flex', gap: 16, alignItems: 'baseline' }}>
        {pct !== undefined && <span className="pnl-pct">{num(pct, 1)}٪</span>}
        <span className="money" style={{ color: color || (negative ? 'var(--red)' : undefined), minWidth: 120, textAlign: 'left' }}>
          {negative && v ? '(' : ''}{money(Math.abs(v))}{negative && v ? ')' : ''}
        </span>
      </span>
    </div>
  )
}

export default function ProfitLoss() {
  const ch = useChart()
  const [range, setRange] = useState(rangeOf('last30'))
  const { data: p, loading } = useFetch('/expenses/pnl', { date_from: range.from, date_to: range.to })
  const s = p?.sales || {}
  const positive = (p?.net_profit || 0) >= 0
  return (
    <div className="fade-in">
      <PageHeader title="سود و زیان" subtitle={p ? `${faDate(range.from)} تا ${faDate(range.to)} — ${num(p.range.days)} روز` : ''}
        extra={<JalaliRange value={range} onChange={setRange} presets={['week', 'month', 'last30', 'lastMonth']} />} />
      <Row gutter={[16, 16]}>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="درآمد خالص (بدون مالیات)" value={p?.revenue} money icon={<DollarOutlined />} color="var(--primary-text)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="بهای مواد مصرفی" value={p?.cogs} money hint={`${num(p?.cogs_pct, 1)}٪ از درآمد`} icon={<FireOutlined />} color="var(--amber)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="سود ناخالص" value={p?.gross_profit} money hint={`حاشیه ${num(p?.gross_margin, 1)}٪`} icon={<RiseOutlined />} color="var(--green)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="هزینه‌های جاری" value={p?.expenses} money hint={`${num(p?.expenses_pct, 1)}٪ از درآمد`} icon={<WalletOutlined />} color="var(--red)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title={positive ? 'سود خالص' : 'زیان خالص'} value={p?.net_profit} money hint={`حاشیه ${num(p?.net_margin, 1)}٪`} icon={positive ? <RiseOutlined /> : <FallOutlined />} color={positive ? 'var(--green)' : 'var(--red)'} /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="خرید مواد (نقدینگی)" value={p?.purchases} money hint="مبلغ فاکتورهای خرید" icon={<ShoppingOutlined />} color="var(--blue)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="بهای جایگزینی روز" value={p?.replacement_cost} money hint="همان مواد با قیمت امروز — شاخص جداگانه" icon={<ShoppingOutlined />} color="var(--pal-5)" /></Col>
      </Row>
      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24} xl={10}>
          <Card className="card-r" title="صورت سود و زیان" loading={loading}>
            {p && (<div className="pnl">
              <Row2 label="فروش ناخالص منو" value={s.gross} />
              <Row2 label="تخفیف‌ها" value={s.discounts} neg indent />
              <Row2 label="حق سرویس" value={s.service} indent />
              <Row2 label="مرجوعی‌ها" value={s.refunds} neg indent />
              <Row2 label="درآمد خالص" value={p.revenue} pct={100} strong border />
              <Row2 label="بهای تمام‌شده مواد مصرفی" value={p.cogs} pct={p.cogs_pct} neg indent />
              {p.waste > 0 && <Row2 label="ضایعات انبار" value={p.waste} neg indent />}
              <Row2 label="سود ناخالص" value={p.gross_profit} pct={p.gross_margin} strong border />
              {p.expenses_by_category.map((c) => <Row2 key={c.id} label={`${c.icon || ''} ${c.name}`} value={c.amount} pct={c.pct} neg indent />)}
              <Row2 label="جمع هزینه‌های جاری" value={p.expenses} pct={p.expenses_pct} neg border />
              <div className={`pnl-total ${positive ? 'pos' : 'neg'}`}>
                <span>{positive ? 'سود خالص' : 'زیان خالص'}</span>
                <span><span className="pnl-pct">{num(p.net_margin, 1)}٪</span> <span className="money">{money(p.net_profit)}</span> <small>تومان</small></span>
              </div>
              {p.replacement_cost > 0 && (
                <Row2 label="بهای جایگزینی روز (قیمت امروز مواد)" value={p.replacement_cost} indent color="var(--blue)" border />
              )}
              <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginTop: 10 }}>
                مالیات بر ارزش افزوده ({money(s.tax)} تومان) جزو درآمد نیست. بهای مواد مصرفی به‌صورت <b>تاریخی</b> (قیمت میانگین موزون در لحظهٔ فروش، شامل رسپی افزودنی‌ها) ثبت می‌شود؛ خرید جدید سود گذشته را تغییر نمی‌دهد.
                «بهای جایگزینی روز» فقط برای مقایسه است و جای بهای تاریخی را نمی‌گیرد.
                {p.cogs_estimated_lines > 0 && <> {num(p.cogs_estimated_lines)} قلم از فروش‌های قدیمی (قبل از ثبت بهای تاریخی) برآورد شده است.</>}
                {p.cogs_unknown_lines > 0 && <span style={{ color: 'var(--red)' }}> بهای مواد {num(p.cogs_unknown_lines)} قلم فروش قدیمی قابل بازسازی نبود (نه snapshot دارد نه حرکت انبار) و در جمع بهای مواد لحاظ نشده — سود واقعی از این عدد کمتر است.</span>}
              </Typography.Text>
            </div>)}
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          <Card className="card-r" title="روند روزانه درآمد و هزینه · سود تجمعی" loading={loading}>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={p?.series || []} margin={{ left: 10, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="date" tickFormatter={faShort} tick={{ fontSize: 11 }} reversed />
                <YAxis yAxisId="m" tickFormatter={compact} tick={{ fontSize: 11 }} orientation="right" width={86} />
                <YAxis yAxisId="c" tickFormatter={compact} tick={{ fontSize: 11 }} orientation="left" width={86} />
                <Tooltip content={<MoneyTip labelFmt={(d) => `${faWeekday(d)} ${faShort(d)}`} />} />
                <Bar yAxisId="m" dataKey="revenue" name="درآمد" fill={ch.accent} radius={[5, 5, 0, 0]} maxBarSize={22} />
                <Bar yAxisId="m" dataKey="expenses" name="هزینه" fill={ch.red} radius={[5, 5, 0, 0]} maxBarSize={22} />
                <Bar yAxisId="m" dataKey="waste" name="ضایعات" stackId="loss" fill={ch.amber || '#f59e0b'} radius={[5, 5, 0, 0]} maxBarSize={22} />
                <Line yAxisId="c" type="monotone" dataKey="cumulative" name="سود تجمعی" stroke={ch.green} strokeWidth={2.5} dot={false} />
                <ReferenceLine yAxisId="c" y={0} stroke={ch.faint} strokeDasharray="4 4" />
              </ComposedChart>
            </ResponsiveContainer>
          </Card>
          <Card className="card-r" title="ترکیب هزینه‌ها" style={{ marginTop: 16 }} loading={loading}>
            <Row gutter={16} align="middle">
              <Col xs={24} md={10}>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={[{ name: 'مواد مصرفی', amount: p?.cogs || 0, color: 'var(--amber)' }, ...(p?.expenses_by_category || [])]} dataKey="amount" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                      {[{ color: 'var(--amber)' }, ...(p?.expenses_by_category || [])].map((c, i) => <Cell key={i} fill={c.color} />)}
                    </Pie>
                    <Tooltip formatter={(v) => `${money(v)} تومان`} contentStyle={tooltipStyle} />
                  </PieChart>
                </ResponsiveContainer>
              </Col>
              <Col xs={24} md={14}>
                <Table size="small" rowKey="name" pagination={false} dataSource={[{ name: 'مواد مصرفی (فودکاست)', icon: '🥩', color: 'var(--amber)', amount: p?.cogs || 0, pct: p?.cogs_pct }, ...(p?.expenses_by_category || [])]}
                  columns={[
                    { title: 'شرح', render: (_, c) => <span><span className="exp-dot" style={{ background: c.color }}>{c.icon}</span>{c.name}</span> },
                    { title: 'مبلغ', dataIndex: 'amount', render: money },
                    { title: 'از درآمد', dataIndex: 'pct', render: (v) => <Tag>{num(v, 1)}٪</Tag> },
                  ]} />
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    </div>
  )
}
