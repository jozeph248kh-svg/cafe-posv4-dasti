import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor } from '@testing-library/react'
import { App } from 'antd'

// Expenses feed the profit & loss report, and an expense paid "from the register" is also a cash-out
// on the open shift — so the amount and that flag have to survive the form untouched.
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: Expenses } = await import('./Expenses')

const CATS = [
  { id: 1, name: 'اجاره', icon: '🏠', color: '#64748b', is_active: true },
  { id: 2, name: 'مواد اولیه', icon: '🥛', color: '#0ea5e9', is_active: true },
]
const LIST = {
  total: 3_150_000,
  items: [
    { id: 1, expense_date: '2026-10-20', category: 'اجاره', icon: '🏠', color: '#64748b', payee: 'آقای رحیمی', note: 'اجاره مهر', amount: 2_500_000, method: 'transfer', from_register: false },
    { id: 2, expense_date: '2026-10-22', category: 'مواد اولیه', icon: '🥛', color: '#0ea5e9', payee: 'لبنیات ونک', amount: 650_000, method: 'cash', from_register: true },
  ],
}

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/expenses/categories') return Promise.resolve(CATS)
    if (path === '/expenses') return Promise.resolve(LIST)
    return Promise.resolve([])
  })
}
const page = () => render(<App><Expenses /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Expenses', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows the period total, the count and the part paid from the register', async () => {
    page()
    await waitFor(() => expect(text()).toContain('جمع هزینه‌ها'))
    expect(text()).toContain('۳٬۱۵۰٬۰۰۰')
    expect(text()).toContain('۶۵۰٬۰۰۰')            // "paid from the drawer" card
  })

  it('lists each expense with payee, method and the register flag', async () => {
    page()
    await waitFor(() => expect(text()).toContain('آقای رحیمی'))
    expect(text()).toContain('۲٬۵۰۰٬۰۰۰')
    expect(text()).toContain('حواله / انتقال')
    expect(text()).toContain('صندوق')              // the from_register tag
    expect(text()).toContain('لبنیات ونک')
  })

  it('shows the table summary row that re-adds the visible rows', async () => {
    page()
    await waitFor(() => expect(text()).toContain('آقای رحیمی'))
    const summary = document.querySelector('.ant-table-summary')
    expect(summary).toBeTruthy()
    expect(summary.textContent.replace(/\s+/g, ' ')).toContain('۳٬۱۵۰٬۰۰۰')
  })

  it('asks the server for the chosen date range and search', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/expenses', expect.objectContaining({
      date_from: expect.any(String), date_to: expect.any(String),
    })))
  })

  it('offers both tabs: the list and the categories', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فهرست هزینه‌ها'))
    const tabs = [...document.querySelectorAll('.ant-tabs-tab')].map((t) => t.textContent)
    expect(tabs.join(' ')).toContain('دسته‌بندی هزینه‌ها')
  })
})
