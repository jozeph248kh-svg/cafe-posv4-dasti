import { render, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { beforeEach, describe, expect, it, vi } from 'vitest'

/**
 * The P&L table must never print a negative figure as a positive one (reported defect R2-UI-001: the summary
 * card showed a loss while the «درآمد خالص» / «سود ناخالص» rows showed the same number without a sign).
 * These tests pin the presentation rules: a deducted line is in parentheses, and a negative result keeps its
 * parentheses/red colour wherever it appears.
 */
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid', api: vi.fn(),
  ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/theme', () => ({ useChart: () => ({ c: ['#111', '#222'], accent: '#4f46e5', grid: '#eee', axis: '#999', red: '#dc2626', green: '#16a34a', faint: '#ddd', amber: '#f59e0b' }) }))
vi.mock('../../components/JalaliRange', () => {
  const Stub = () => null
  return { default: Stub, rangeOf: () => ({ from: '2026-10-01', to: '2026-10-23' }) }
})

const { default: ProfitLoss } = await import('./ProfitLoss')

const PNL = (over = {}) => ({
  range: { from: '2026-10-01', to: '2026-10-23', days: 23 },
  sales: { gross: 1_000_000, discounts: 0, service: 0, tax: 90_000, refunds: 1_090_000, orders: 1 },
  revenue: -90_000,                    // a fully refunded taxed bill: revenue went negative (the old bug)
  cogs: 50_000, cogs_pct: -55.6, cogs_estimated_lines: 0,
  waste: 0,
  gross_profit: -140_000, gross_margin: -155.6,
  expenses: 0, expenses_pct: 0,
  expenses_by_category: [],
  net_profit: -140_000, net_margin: -155.6,
  purchases: 0, replacement_cost: 0,
  series: [{ date: '2026-10-23', revenue: -90_000, cogs: 50_000, waste: 0, expenses: 0, profit: -140_000, cumulative: -140_000 }],
  ...over,
})
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('<ProfitLoss/>', () => {
  beforeEach(() => {
    get.mockReset()
    get.mockImplementation((path) => (path === '/expenses/pnl' ? Promise.resolve(PNL()) : Promise.resolve([])))
  })

  it('never shows a negative net revenue or gross profit as a positive number', async () => {
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('درآمد خالص'))
    const rows = [...document.querySelectorAll('.pnl-row')].map((r) => r.textContent.replace(/\s+/g, ' '))
    const revenueRow = rows.find((r) => r.startsWith('درآمد خالص'))
    const grossRow = rows.find((r) => r.startsWith('سود ناخالص'))
    expect(revenueRow).toContain('(۹۰٬۰۰۰)')       // 90,000 in parentheses = negative, not +90,000
    expect(grossRow).toContain('(۱۴۰٬۰۰۰)')
  })

  it('keeps the deduction rows in parentheses and the losses red', async () => {
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('بهای تمام‌شده مواد مصرفی'))
    const costRow = [...document.querySelectorAll('.pnl-row')].find((r) => r.textContent.includes('بهای تمام‌شده مواد مصرفی'))
    expect(costRow.textContent).toContain('(۵۰٬۰۰۰)')
    const moneyEls = [...document.querySelectorAll('.pnl-row .money')].map((e) => e.getAttribute('style') || '')
    expect(moneyEls.some((s) => s.includes('var(--red)'))).toBe(true)
  })

  it('shows the loss in the total line and keeps the positive case plain', async () => {
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(document.querySelector('.pnl-total')).toBeTruthy())
    expect(document.querySelector('.pnl-total').textContent).toContain('زیان خالص')
    expect(document.querySelector('.pnl-total').className).toContain('neg')
  })

  it('shows the replacement cost as its own indicator (never merged into COGS)', async () => {
    get.mockImplementation((path) => (path === '/expenses/pnl'
      ? Promise.resolve(PNL({ revenue: 1_000_000, gross_profit: 400_000, net_profit: 300_000, cogs: 600_000, replacement_cost: 800_000 }))
      : Promise.resolve([])))
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('بهای جایگزینی روز'))
    const rows = [...document.querySelectorAll('.pnl-row')].map((r) => r.textContent.replace(/\s+/g, ' '))
    expect(rows.find((r) => r.startsWith('بهای تمام‌شده مواد مصرفی'))).toContain('۶۰۰٬۰۰۰')
    expect(rows.find((r) => r.startsWith('بهای جایگزینی روز'))).toContain('۸۰۰٬۰۰۰')
  })

  it('warns when old sales had to be estimated', async () => {
    get.mockImplementation((path) => (path === '/expenses/pnl'
      ? Promise.resolve(PNL({ revenue: 1_000_000, gross_profit: 400_000, net_profit: 300_000, cogs: 600_000, cogs_estimated_lines: 12 }))
      : Promise.resolve([])))
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('برآورد شده است'))
    expect(text()).toContain('۱۲ قلم')
  })
})

describe('<ProfitLoss/> unknown legacy cost', () => {
  it('says out loud when some old sales could not be costed at all', async () => {
    get.mockReset()
    get.mockImplementation((path) => (path === '/expenses/pnl'
      ? Promise.resolve(PNL({ revenue: 1_000_000, gross_profit: 400_000, net_profit: 300_000, cogs: 600_000,
                              cogs_estimated_lines: 3, cogs_unknown_lines: 4 }))
      : Promise.resolve([])))
    render(<App><ProfitLoss /></App>)
    await waitFor(() => expect(text()).toContain('قابل بازسازی نبود'))
    expect(text()).toContain('۴ قلم')
  })
})
