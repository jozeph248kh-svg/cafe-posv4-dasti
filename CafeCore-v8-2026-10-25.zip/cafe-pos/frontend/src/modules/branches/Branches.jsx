import { ApartmentOutlined, CloudServerOutlined, CloudSyncOutlined, CopyOutlined, DownloadOutlined, KeyOutlined, PlusOutlined, ShopOutlined, WarningOutlined, WifiOutlined } from '@ant-design/icons'
import { Alert, App, Badge, Button, Card, Col, DatePicker, Empty, Form, Input, Modal, Popconfirm, Radio, Row, Space, Statistic, Table, Tabs, Tag, Typography } from 'antd'
import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { PageHeader, StatCard } from '../../components/common'
import { post, put } from '../../core/api'
import { PAY_METHODS, compact, faDateTime, faShort, isoDate, money, num, timeAgo } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { useChart } from '../../core/theme'

const COLORS = [1, 2, 3, 8, 4, 6, 5, 7].map((n) => `var(--chart-${n})`)   // HTML; the stacked bar uses useChart()
const MODES = {
  standalone: { title: 'تک‌شعبه', desc: 'یک مجموعه با یک سرور (پیش‌فرض)', icon: <ShopOutlined /> },
  branch: { title: 'شعبه', desc: 'این سرور یک شعبه است و فروش را به سرور مرکزی می‌فرستد', icon: <WifiOutlined /> },
  central: { title: 'سرور مرکزی', desc: 'گزارش تجمیعی همه شعبه‌ها و ارسال منو', icon: <CloudServerOutlined /> },
}

function KeyModal({ data, onClose }) {
  if (!data) return null
  return (
    <Modal open onCancel={onClose} onOk={onClose} cancelButtonProps={{ style: { display: 'none' } }} okText="ذخیره کردم" title={<span><KeyOutlined /> کلید شعبه «{data.name}»</span>}>
      <Alert type="warning" showIcon style={{ marginBottom: 12 }} message="این کلید فقط همین یک بار نمایش داده می‌شود. آن را در تنظیمات سرور شعبه (مدیریت ← شعبه‌ها ← حالت «شعبه») وارد کنید." />
      <Typography.Paragraph copyable={{ icon: <CopyOutlined /> }} className="md-json" style={{ fontSize: 13 }}>{data.api_key}</Typography.Paragraph>
      <Typography.Text type="secondary">آدرس سرور مرکزی برای شعبه: </Typography.Text><Typography.Text copyable className="ltr">{window.location.origin}</Typography.Text>
    </Modal>
  )
}

function Consolidated() {
  const ch = useChart()
  const [range, setRange] = useState(null)
  const params = range ? { date_from: isoDate(range[0].toDate()), date_to: isoDate(range[1].toDate()) } : {}
  const { data, loading } = useFetch('/branches/report', params)
  const br = data?.branches || []
  const chart = (data?.days || []).map((d) => ({ date: d, ...Object.fromEntries(br.map((b) => [b.name, b.daily[d] || 0])) }))
  return (
    <>
      <Space style={{ marginBottom: 16 }} wrap>
        <DatePicker.RangePicker onChange={setRange} allowClear />
        <Typography.Text type="secondary">{data && `از ${faShort(data.from)} تا ${faShort(data.to)}`}</Typography.Text>
      </Space>
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={24} md={8}><StatCard loading={loading} title="فروش کل مجموعه" value={data?.totals.sales} money icon={<ApartmentOutlined />} color="var(--pal-1)" /></Col>
        <Col xs={12} md={8}><StatCard loading={loading} title="تعداد سفارش" value={data?.totals.orders} icon={<ShopOutlined />} color="var(--green)" /></Col>
        <Col xs={12} md={8}><StatCard loading={loading} title="هزینه‌ها" value={data?.totals.expenses} money icon={<WarningOutlined />} color="var(--red)" /></Col>
      </Row>
      {!loading && !br.length && <Card><Empty description="هنوز داده‌ای از شعبه‌ها نرسیده است" /></Card>}
      {br.length > 0 && <>
        <Card title="فروش روزانه به تفکیک شعبه" style={{ marginBottom: 16 }}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" tickFormatter={faShort} tick={{ fontSize: 11 }} reversed />
              <YAxis tickFormatter={compact} tick={{ fontSize: 11 }} orientation="right" width={80} />
              <Tooltip formatter={(v) => money(v)} labelFormatter={faShort} />
              <Legend />
              {br.map((b, i) => <Bar key={b.key} dataKey={b.name} stackId="a" fill={ch.c[[0, 1, 2, 7, 3, 5, 4, 6][i % 8]]} radius={i === br.length - 1 ? [6, 6, 0, 0] : 0} />)}
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Row gutter={[16, 16]}>
          {br.map((b, i) => (
            <Col xs={24} lg={12} xxl={8} key={b.key}>
              <Card className="br-card" style={{ '--c': COLORS[i % COLORS.length] }} title={<Space>{b.online !== null && <Badge status={b.online ? 'success' : 'default'} />}{b.name}</Space>}
                extra={b.last_seen && <Typography.Text type="secondary" style={{ fontSize: 12 }}>آخرین ارتباط {timeAgo(b.last_seen)}</Typography.Text>}>
                <Row gutter={8}>
                  <Col span={8}><Statistic title="فروش" value={b.sales} formatter={(v) => compact(v)} /></Col>
                  <Col span={8}><Statistic title="سفارش" value={b.orders} formatter={(v) => num(v)} /></Col>
                  <Col span={8}><Statistic title="میانگین فاکتور" value={b.avg_ticket} formatter={(v) => compact(v)} /></Col>
                </Row>
                <div className="br-pay">
                  {Object.entries(b.payments).map(([m, a]) => <Tag key={m}>{PAY_METHODS[m]?.label || m}: {compact(a)}</Tag>)}
                  {b.expenses > 0 && <Tag color="red">هزینه: {compact(b.expenses)}</Tag>}
                  {b.refunds > 0 && <Tag color="magenta">مرجوعی: {compact(b.refunds)} · خالص: {compact(b.net)}</Tag>}
                </div>
                {b.top_items.length > 0 && <div className="br-top">{b.top_items.slice(0, 3).map((t) => <span key={t.name}>{t.name} <b>×{num(t.qty)}</b></span>)}</div>}
                {b.snapshot?.at && (
                  <div className="br-live">
                    <span>الان: <b>{num(b.snapshot.open_orders)}</b> سفارش باز · امروز <b>{compact(b.snapshot.today_sales)}</b></span>
                    {b.snapshot.low_stock?.length > 0 && <Tag color="orange" icon={<WarningOutlined />}>{num(b.snapshot.low_stock.length)} کالای رو به اتمام</Tag>}
                  </div>
                )}
              </Card>
            </Col>
          ))}
        </Row>
        <Card title="پرفروش‌ترین‌های کل مجموعه" style={{ marginTop: 16 }}>
          <Table rowKey="name" size="small" pagination={false} dataSource={data.top_items}
            columns={[{ title: '#', render: (_, __, i) => num(i + 1), width: 50 }, { title: 'کالا', dataIndex: 'name' }, { title: 'تعداد', dataIndex: 'qty', render: (v) => num(v) }, { title: 'فروش', dataIndex: 'total', render: (v) => <b>{money(v)}</b> }]} />
        </Card>
      </>}
    </>
  )
}

function BranchList() {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/branches')
  const [form] = Form.useForm()
  const [open, setOpen] = useState(false)
  const [key, setKey] = useState(null)
  const create = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    try { const r = await post('/branches', v); setOpen(false); form.resetFields(); setKey(r); reload() } catch (e) { message.error(e.message) }
  }
  return (
    <Card title="شعبه‌های ثبت‌شده" extra={<Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>شعبه جدید</Button>}>
      <Table rowKey="id" loading={loading} dataSource={data || []} pagination={false} locale={{ emptyText: 'هنوز شعبه‌ای ثبت نشده' }} scroll={{ x: 760 }}
        columns={[
          { title: 'شعبه', dataIndex: 'name', render: (v, r) => <Space><Badge status={r.online ? 'success' : 'default'} /><b>{v}</b><Tag>{r.code}</Tag>{!r.is_active && <Tag color="red">غیرفعال</Tag>}</Space> },
          { title: 'آخرین ارتباط', dataIndex: 'last_seen', render: (v) => (v ? <span title={faDateTime(v)}>{timeAgo(v)}</span> : <Typography.Text type="secondary">هرگز</Typography.Text>) },
          { title: 'امروز', render: (_, r) => (r.snapshot?.at ? `${compact(r.snapshot.today_sales)} · ${num(r.snapshot.today_orders)} سفارش` : '—') },
          { title: 'IP / نسخه', render: (_, r) => <span className="ltr" style={{ fontSize: 12 }}>{r.last_ip || '—'} {r.version && `v${r.version}`}</span> },
          { title: 'کلید', dataIndex: 'key_prefix', render: (v) => <span className="ltr" style={{ fontSize: 12 }}>{v}…</span> },
          { width: 150, render: (_, r) => (
            <Popconfirm title="کلید جدید ساخته شود؟" description="کلید قبلی بلافاصله از کار می‌افتد و باید در شعبه به‌روز شود." onConfirm={async () => { const k = await post(`/branches/${r.id}/rotate-key`); setKey({ ...k, name: r.name }) }}>
              <Button size="small" icon={<KeyOutlined />}>کلید جدید</Button>
            </Popconfirm>
          ) },
        ]} />
      <Modal open={open} onCancel={() => setOpen(false)} onOk={create} title="شعبه جدید" okText="ساخت و دریافت کلید" cancelText="انصراف" destroyOnClose>
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="نام شعبه" rules={[{ required: true }]}><Input placeholder="شعبه ونک" /></Form.Item>
          <Form.Item name="code" label="کد کوتاه" rules={[{ required: true }]}><Input className="ltr" placeholder="VNK" maxLength={20} /></Form.Item>
          <Form.Item name="address" label="آدرس"><Input /></Form.Item>
        </Form>
      </Modal>
      <KeyModal data={key} onClose={() => setKey(null)} />
    </Card>
  )
}

function LocalSettings({ st, reload }) {
  const { message, modal } = App.useApp()
  const [mode, setMode] = useState(st.mode)
  const [url, setUrl] = useState(st.central_url || '')
  const [key, setKey] = useState('')
  const [busy, setBusy] = useState(null)
  const run = async (name, fn) => { setBusy(name); try { await fn() } catch (e) { message.error(e.message) } finally { setBusy(null) } }
  const save = () => run('save', async () => { await put('/branches/local/config', { mode, central_url: url, api_key: key || null }); setKey(''); message.success('ذخیره شد'); reload() })
  return (
    <Card title={<span><CloudSyncOutlined /> نقش این سرور</span>} extra={<Button type="primary" loading={busy === 'save'} onClick={save}>ذخیره</Button>}>
      <Radio.Group value={mode} onChange={(e) => setMode(e.target.value)} className="br-modes">
        {Object.entries(MODES).map(([k, m]) => (
          <Radio.Button key={k} value={k}><span className="br-mode-icon">{m.icon}</span><b>{m.title}</b><small>{m.desc}</small></Radio.Button>
        ))}
      </Radio.Group>
      {mode === 'branch' && (
        <div style={{ marginTop: 16 }}>
          <Alert type="info" showIcon style={{ marginBottom: 12 }} message="شعبه همیشه روی سرور خودش کار می‌کند؛ اگر اینترنت قطع باشد فروش ادامه دارد و پس از وصل شدن، خودکار به مرکز ارسال می‌شود." />
          <Form layout="vertical">
            <Form.Item label="آدرس سرور مرکزی"><Input className="ltr" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://central.mycafe.ir" /></Form.Item>
            <Form.Item label="کلید شعبه" extra={st.has_key ? `کلید فعلی: ${st.key_hint} (برای تغییر، کلید جدید را وارد کنید)` : 'از سرور مرکزی ← شعبه‌ها ← شعبه جدید'}><Input.Password className="ltr" value={key} onChange={(e) => setKey(e.target.value)} autoComplete="off" /></Form.Item>
          </Form>
          {st.mode === 'branch' && (
            <>
              <Row gutter={16} className="br-sync">
                <Col span={8}><Statistic title="در صف ارسال" value={st.pending} formatter={(v) => num(v)} valueStyle={{ color: st.pending ? 'var(--amber)' : 'var(--green)' }} /></Col>
                <Col span={16}><Statistic title="آخرین ارسال موفق" value={st.last_push ? timeAgo(st.last_push) : 'هنوز'} /></Col>
              </Row>
              {st.last_error && <Alert type="error" showIcon style={{ margin: '12px 0' }} message={`آخرین خطا: ${st.last_error}`} />}
              <Space wrap style={{ marginTop: 12 }}>
                <Button icon={<WifiOutlined />} loading={busy === 'test'} onClick={() => run('test', async () => { const r = await post('/branches/local/test'); message.success(`متصل به «${r.central || 'مرکز'}» به‌عنوان «${r.branch}»`) })}>تست اتصال</Button>
                <Button icon={<CloudSyncOutlined />} loading={busy === 'push'} onClick={() => run('push', async () => { const r = await post('/branches/local/push'); message.success(`${num(r.sent)} فروش ارسال شد`); reload() })}>ارسال الان</Button>
                <Button icon={<DownloadOutlined />} loading={busy === 'pull'} onClick={() => modal.confirm({
                  title: 'دریافت منو از سرور مرکزی', okText: 'فقط قیمت‌ها', cancelText: 'انصراف',
                  content: 'قیمت‌ها (و در صورت انتخاب، نام و اقلام جدید) از منوی مرکز به‌روز می‌شود. اقلام با نام یکسان تطبیق داده می‌شوند.',
                  footer: (_, { OkBtn, CancelBtn }) => <><CancelBtn /><Button onClick={() => { Modal.destroyAll(); run('pull', async () => { const r = await post('/branches/local/pull-catalog'); message.success(`${num(r.created)} قلم جدید، ${num(r.updated)} به‌روزرسانی`) }) }}>منو کامل</Button><OkBtn /></>,
                  onOk: () => run('pull', async () => { const r = await post('/branches/local/pull-catalog', null, { params: { prices_only: true } }); message.success(`${num(r.updated)} قیمت به‌روز شد`) }),
                })}>دریافت منو از مرکز</Button>
                <Popconfirm title="ارسال دوباره فروش ۳۰ روز اخیر؟" description="برای اولین اتصال شعبه‌ای که از قبل فروش داشته" onConfirm={() => run('resync', async () => { const r = await post('/branches/local/resync'); message.success(`${num(r.queued)} فروش در صف قرار گرفت`); reload() })}>
                  <Button type="link">ارسال سوابق قبلی</Button>
                </Popconfirm>
              </Space>
            </>
          )}
        </div>
      )}
    </Card>
  )
}

export default function Branches() {
  const st = useFetch('/branches/local/status')
  const s = st.data
  const central = s?.mode === 'central' || s?.branches > 0
  return (
    <div>
      <PageHeader title="شعبه‌ها" subtitle="سرور مستقل در هر شعبه + همگام‌سازی با سرور مرکزی و گزارش تجمیعی" icon={<ApartmentOutlined />}
        extra={s && <Tag color={s.mode === 'standalone' ? 'default' : 'blue'} style={{ padding: '4px 10px', fontSize: 13 }}>{MODES[s.mode]?.title}</Tag>} />
      {s && (
        <Tabs defaultActiveKey={central ? 'report' : 'settings'} items={[
          central && { key: 'report', label: 'گزارش تجمیعی', children: <Consolidated /> },
          central && { key: 'list', label: 'مدیریت شعبه‌ها', children: <BranchList /> },
          { key: 'settings', label: 'تنظیمات این سرور', children: <LocalSettings st={s} reload={st.reload} /> },
        ].filter(Boolean)} />
      )}
    </div>
  )
}
