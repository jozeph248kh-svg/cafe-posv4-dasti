import {
  AuditOutlined, CheckCircleFilled, ClockCircleOutlined, CloseCircleFilled, CodeOutlined, KeyOutlined, ReloadOutlined, SafetyCertificateOutlined, SaveOutlined, StopOutlined, SyncOutlined,
} from '@ant-design/icons'
import { Alert, App, Badge, Button, Card, Col, Descriptions, Form, Input, InputNumber, Modal, Popconfirm, Row, Segmented, Select, Space, Steps, Switch, Table, Tabs, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useMemo, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { get, post, put } from '../../core/api'
import { faDateTime, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

const ST = {
  queued: ['در صف ارسال', 'processing'], sending: ['در حال ارسال', 'processing'], sent: ['در انتظار نتیجه', 'warning'], success: ['ثبت شد', 'success'], failed: ['رد شد', 'error'], not_sent: ['نیاز به اصلاح', 'error'],
}
const MODES = { mock: ['آزمایشی (بدون ارسال)', 'orange'], sandbox: ['محیط تست سازمان', 'blue'], production: ['عملیاتی', 'green'] }

function Invoices({ reloadKey, onChange }) {
  const { message } = App.useApp()
  const [f, setF] = useState({ days: 7, status: undefined, page: 1 })
  const { data, loading, reload } = useFetch('/moadian/invoices', { ...f, size: 15 }, { deps: [reloadKey] })
  const [json, setJson] = useState(null)
  const act = async (fn, ok) => { try { await fn(); message.success(ok); reload(); onChange?.() } catch (e) { message.error(e.message) } }
  return (
    <Card title="صورتحساب‌های الکترونیکی" extra={<Space wrap>
      <Segmented value={f.days} onChange={(days) => setF({ ...f, days, page: 1 })} options={[{ value: 1, label: 'امروز' }, { value: 7, label: '۷ روز' }, { value: 30, label: '۳۰ روز' }]} />
      <Select allowClear placeholder="وضعیت" style={{ width: 150 }} value={f.status} onChange={(status) => setF({ ...f, status, page: 1 })} options={Object.entries(ST).map(([value, [label]]) => ({ value, label }))} />
      <Button icon={<SyncOutlined />} onClick={() => act(() => post('/moadian/run'), 'ارسال و استعلام انجام شد')}>ارسال و استعلام الان</Button>
    </Space>}>
      <Table rowKey="id" size="middle" loading={loading} dataSource={data?.items || []} scroll={{ x: 980 }}
        pagination={{ current: f.page, pageSize: 15, total: data?.total, onChange: (page) => setF({ ...f, page }), showSizeChanger: false }}
        columns={[
          { title: 'زمان', dataIndex: 'created_at', width: 130, render: faDateTime },
          { title: 'سفارش', dataIndex: 'order_number', width: 80, render: (v) => (v ? `#${num(v)}` : '—') },
          { title: 'نوع', dataIndex: 'kind', width: 80, render: (v) => (v === 'cancel' ? <Tag color="red">ابطالی</Tag> : <Tag>فروش</Tag>) },
          { title: 'شماره مالیاتی', dataIndex: 'tax_id', render: (v) => (v ? <Typography.Text copyable className="ltr" style={{ fontSize: 12, fontFamily: 'monospace' }}>{v}</Typography.Text> : '—') },
          { title: 'مبلغ (ریال)', dataIndex: 'total', render: (v) => money(v) },
          { title: 'مالیات', dataIndex: 'vat', render: (v) => money(v) },
          { title: 'وضعیت', dataIndex: 'status', width: 200, render: (v, r) => (
            <Space direction="vertical" size={0}>
              <Space size={4}><Badge status={ST[v]?.[1]} text={ST[v]?.[0]} />{r.mode !== 'production' && <Tag style={{ fontSize: 10 }}>{r.mode}</Tag>}</Space>
              {r.errors?.length > 0 && <Tooltip title={r.errors.map((e) => `${e.code}: ${e.message}`).join(' | ')}><Typography.Text type="danger" ellipsis style={{ fontSize: 12, maxWidth: 190 }}>{r.errors[0].message}</Typography.Text></Tooltip>}
            </Space>
          ) },
          { title: '', width: 150, render: (_, r) => (
            <Space size={0}>
              <Tooltip title="مشاهده JSON"><Button size="small" type="text" icon={<CodeOutlined />} disabled={!r.tax_id} onClick={async () => setJson(await get(`/moadian/invoices/${r.id}/payload`))} /></Tooltip>
              {['failed', 'not_sent'].includes(r.status) && <Button size="small" type="link" icon={<ReloadOutlined />} onClick={() => act(() => post(`/moadian/invoices/${r.id}/retry`), 'دوباره در صف قرار گرفت')}>ارسال مجدد</Button>}
              {r.status === 'success' && r.kind === 'sale' && (
                <Popconfirm title="صدور صورتحساب ابطالی؟" description="فقط برای فروش‌های برگشتی/اشتباه" onConfirm={() => act(() => post(`/moadian/invoices/${r.id}/cancel`), 'صورتحساب ابطالی در صف ارسال قرار گرفت')}>
                  <Button size="small" type="link" danger icon={<StopOutlined />}>ابطال</Button>
                </Popconfirm>
              )}
            </Space>
          ) },
        ]} />
      <Modal open={!!json} onCancel={() => setJson(null)} footer={null} width={720} title="محتوای صورتحساب (قبل از امضا و رمزنگاری)">
        <pre className="md-json">{json && JSON.stringify(json, null, 2)}</pre>
      </Modal>
    </Card>
  )
}

function Items() {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/moadian/items')
  const [edits, setEdits] = useState({})
  const [q, setQ] = useState('')
  const rows = useMemo(() => (data || []).filter((r) => !q || r.name.includes(q) || (r.category || '').includes(q)), [data, q])
  const missing = (data || []).filter((r) => !(edits[r.id] ?? r.sstid)).length
  const save = async () => {
    try { await put('/moadian/items', { items: edits }); message.success('ذخیره شد'); setEdits({}); reload() } catch (e) { message.error(e.message) }
  }
  return (
    <Card title="شناسه کالا و خدمت (۱۳ رقمی)" extra={<Space><Input.Search allowClear placeholder="جستجو" onSearch={setQ} style={{ width: 180 }} /><Button type="primary" icon={<SaveOutlined />} disabled={!Object.keys(edits).length} onClick={save}>ذخیره تغییرات</Button></Space>}>
      <Alert type="info" showIcon style={{ marginBottom: 12 }} message={<>شناسه هر کالا را از سامانه <b>stuffid.tax.gov.ir</b> (شناسه‌های عمومی) بگیرید. برای اقلامی که شناسه اختصاصی ندارند، «شناسه پیش‌فرض» در تنظیمات استفاده می‌شود.{missing > 0 && <> — <b>{num(missing)}</b> قلم بدون شناسه اختصاصی.</>}</>} />
      <Table rowKey="id" size="small" loading={loading} dataSource={rows} pagination={{ pageSize: 20, hideOnSinglePage: true }}
        columns={[{ title: 'دسته', dataIndex: 'category', width: 140 }, { title: 'کالا', dataIndex: 'name' }, { title: 'قیمت', dataIndex: 'price', render: money, width: 120 },
          { title: 'شناسه ۱۳ رقمی', width: 220, render: (_, r) => {
            const v = edits[r.id] ?? r.sstid
            return <Input className="ltr" size="small" maxLength={13} value={v} status={v && v.length !== 13 ? 'error' : undefined} placeholder="پیش‌فرض" onChange={(e) => setEdits({ ...edits, [r.id]: e.target.value.replace(/\D/g, '') })} />
          } }]} />
    </Card>
  )
}

function Settings({ st, reload }) {
  const { message, modal } = App.useApp()
  const [form] = Form.useForm()
  const [gen] = Form.useForm()
  const mode = Form.useWatch('mode', form)
  const [keys, setKeys] = useState({ private_key: '', certificate: '' })
  const [busy, setBusy] = useState(null)
  useEffect(() => { form.setFieldsValue(st) }, [st, form])
  const save = async () => {
    setBusy('save')
    try { await put('/moadian/config', await form.validateFields()); message.success('تنظیمات ذخیره شد'); reload() } catch (e) { if (e.message) message.error(e.message) } finally { setBusy(null) }
  }
  const test = async () => {
    setBusy('test')
    try { await put('/moadian/config', await form.validateFields()); const r = await post('/moadian/test'); modal.success({ title: 'اتصال برقرار است', content: <pre className="md-json">{JSON.stringify(r.info, null, 2)}</pre>, width: 560 }) } catch (e) { if (e.message) message.error(e.message) } finally { setBusy(null) }
  }
  const generate = async () => {
    const v = await gen.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy('gen')
    try {
      const r = await post('/moadian/keys/generate', v)
      modal.info({ width: 640, title: 'کلید خصوصی ساخته شد', content: (
        <div>
          <Typography.Paragraph>کلید خصوصی روی همین سرور ذخیره شد. «کلید عمومی» زیر را در کارپوشه سامانه مودیان (my.tax.gov.ir ← عضویت حافظه مالیاتی) وارد کنید تا شناسه یکتای حافظه صادر شود؛ برای گواهی امضا نیز فایل CSR را به مرکز صدور گواهی بدهید.</Typography.Paragraph>
          <Typography.Text strong>کلید عمومی:</Typography.Text>
          <Typography.Paragraph copyable className="md-json" style={{ fontSize: 11 }}>{r.public_key}</Typography.Paragraph>
          <Typography.Text strong>درخواست گواهی (CSR):</Typography.Text>
          <Typography.Paragraph copyable className="md-json" style={{ fontSize: 11, whiteSpace: 'pre' }}>{r.csr}</Typography.Paragraph>
        </div>
      ) })
      reload()
    } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  const upload = async () => {
    setBusy('up')
    try { await put('/moadian/keys', keys); message.success('ذخیره شد'); setKeys({ private_key: '', certificate: '' }); reload() } catch (e) { message.error(e.message) } finally { setBusy(null) }
  }
  const cert = st.certificate
  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xl={13}>
        <Card title={<span><AuditOutlined /> تنظیمات ارسال</span>} extra={<Space><Button onClick={test} loading={busy === 'test'}>تست اتصال</Button><Button type="primary" icon={<SaveOutlined />} loading={busy === 'save'} onClick={save}>ذخیره</Button></Space>}>
          <Form form={form} layout="vertical">
            <Row gutter={12}>
              <Col span={12}><Form.Item name="enabled" label="ارسال به سامانه مودیان" valuePropName="checked"><Switch checkedChildren="فعال" unCheckedChildren="خاموش" /></Form.Item></Col>
              <Col span={12}><Form.Item name="auto_send" label="ارسال خودکار هر فاکتور" valuePropName="checked" tooltip="پس از تسویه هر سفارش، صورتحساب آن خودکار صادر و ارسال می‌شود"><Switch /></Form.Item></Col>
            </Row>
            <Form.Item name="mode" label="محیط">
              <Segmented block options={Object.entries(MODES).map(([value, [label]]) => ({ value, label }))} />
            </Form.Item>
            {mode === 'mock' && <Alert type="warning" showIcon style={{ marginBottom: 16 }} message="در حالت آزمایشی، صورتحساب‌ها کامل ساخته و اعتبارسنجی می‌شوند (شماره مالیاتی، جمع مبالغ، شناسه کالا) ولی به سازمان ارسال نمی‌شوند." />}
            {mode === 'production' && <Alert type="error" showIcon style={{ marginBottom: 16 }} message="در حالت عملیاتی صورتحساب‌ها واقعاً در پرونده مالیاتی شما ثبت می‌شوند." />}
            <Row gutter={12}>
              <Col xs={24} md={12}><Form.Item name="memory_id" label="شناسه یکتای حافظه مالیاتی" rules={[{ len: 6, message: '۶ کاراکتر', required: mode !== 'mock' }]}><Input className="ltr" maxLength={6} placeholder="A1B2C3" /></Form.Item></Col>
              <Col xs={24} md={12}><Form.Item name="economic_code" label="شماره اقتصادی / شناسه ملی"><Input className="ltr" maxLength={14} /></Form.Item></Col>
              <Col xs={12} md={8}><Form.Item name="vat_percent" label="نرخ مالیات بر ارزش افزوده"><InputNumber min={0} max={30} addonAfter="٪" style={{ width: '100%' }} /></Form.Item></Col>
              <Col xs={12} md={8}><Form.Item name="price_includes_vat" label="قیمت‌ها شامل مالیات است" valuePropName="checked"><Switch /></Form.Item></Col>
              <Col xs={24} md={8}><Form.Item name="min_amount" label="حداقل مبلغ ارسال (تومان)"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>
              <Col xs={24} md={12}><Form.Item name="default_sstid" label="شناسه کالای پیش‌فرض" rules={[{ pattern: /^(\d{13})?$/, message: '۱۳ رقم' }]} extra="برای اقلامی که شناسه اختصاصی ندارند"><Input className="ltr" maxLength={13} /></Form.Item></Col>
              <Col xs={24} md={12}><Form.Item name="default_mu" label="واحد اندازه‌گیری"><Select options={[{ value: '1627', label: 'عدد (1627)' }, { value: '164', label: 'کیلوگرم (164)' }, { value: '1631', label: 'پرس (1631)' }, { value: '16100', label: 'لیوان (16100)' }]} /></Form.Item></Col>
            </Row>
          </Form>
        </Card>
      </Col>
      <Col xs={24} xl={11}>
        <Card title={<span><KeyOutlined /> کلید و گواهی امضا</span>} style={{ marginBottom: 16 }}>
          <Steps direction="vertical" size="small" current={st.has_key ? (cert && !cert.self_signed ? 3 : 1) : 0} items={[
            { title: 'ساخت کلید خصوصی و CSR', description: st.has_key ? 'کلید خصوصی موجود است ✓' : 'با فرم زیر بسازید یا کلید موجود را بارگذاری کنید' },
            { title: 'ثبت کلید عمومی در کارپوشه مودیان', description: 'my.tax.gov.ir ← دریافت شناسه یکتای حافظه مالیاتی' },
            { title: 'دریافت و بارگذاری گواهی امضا', description: cert ? (cert.self_signed ? 'فعلاً گواهی موقت (فقط برای تست)' : `معتبر تا ${cert.not_after?.slice(0, 10)}`) : 'از مراکز صدور گواهی الکترونیکی' },
          ]} />
          {cert?.subject && <Descriptions size="small" column={1} bordered style={{ margin: '8px 0 16px' }}><Descriptions.Item label="گواهی"><span className="ltr" style={{ fontSize: 11 }}>{cert.subject}</span></Descriptions.Item></Descriptions>}
          <Form form={gen} layout="vertical" initialValues={{ individual: false }}>
            <Row gutter={8}>
              <Col span={12}><Form.Item name="common_name" label="نام (لاتین یا فارسی)" rules={[{ required: true }]}><Input /></Form.Item></Col>
              <Col span={12}><Form.Item name="national_id" label="شناسه/کد ملی" rules={[{ required: true, pattern: /^\d{10,11}$/, message: '۱۰ یا ۱۱ رقم' }]}><Input className="ltr" /></Form.Item></Col>
              <Col span={12}><Form.Item name="individual" label="شخص حقیقی" valuePropName="checked"><Switch /></Form.Item></Col>
              <Col span={12} style={{ display: 'flex', alignItems: 'center' }}>
                <Popconfirm title={st.has_key ? 'کلید فعلی جایگزین شود؟' : 'کلید ساخته شود؟'} onConfirm={generate}><Button icon={<KeyOutlined />} loading={busy === 'gen'}>ساخت کلید و CSR</Button></Popconfirm>
              </Col>
            </Row>
          </Form>
        </Card>
        <Card title={<span><SafetyCertificateOutlined /> بارگذاری کلید/گواهی موجود</span>} size="small">
          <Input.TextArea className="ltr" rows={3} placeholder="-----BEGIN PRIVATE KEY-----" value={keys.private_key} onChange={(e) => setKeys({ ...keys, private_key: e.target.value })} style={{ marginBottom: 8, fontSize: 11 }} />
          <Input.TextArea className="ltr" rows={3} placeholder="-----BEGIN CERTIFICATE-----" value={keys.certificate} onChange={(e) => setKeys({ ...keys, certificate: e.target.value })} style={{ marginBottom: 8, fontSize: 11 }} />
          <Button block loading={busy === 'up'} disabled={!keys.private_key && !keys.certificate} onClick={upload}>ذخیره</Button>
        </Card>
      </Col>
    </Row>
  )
}

export default function Moadian() {
  const st = useFetch('/moadian/status')
  const [rk, setRk] = useState(0)
  const s = st.data
  const c = s?.counts || {}
  return (
    <div>
      <PageHeader title="سامانه مودیان" subtitle="صورتحساب الکترونیکی فروش (نوع دوم) — صدور، امضا، ارسال و پیگیری خودکار" icon={<AuditOutlined />}
        extra={s && <Tag color={s.enabled ? MODES[s.mode][1] : 'red'} style={{ padding: '4px 10px', fontSize: 13 }}>{s.enabled ? MODES[s.mode][0] : 'ارسال خاموش است'}</Tag>} />
      {s && !s.enabled && <Alert type="info" showIcon style={{ marginBottom: 16 }} message="ارسال به سامانه مودیان خاموش است. از تب «تنظیمات و کلیدها» حالت آزمایشی را فعال کنید تا صورتحساب‌ها ساخته و بررسی شوند؛ پس از دریافت شناسه حافظه و گواهی، فقط محیط را به «عملیاتی» تغییر دهید." />}
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="ثبت‌شده (۳۰ روز)" value={c.success || 0} icon={<CheckCircleFilled />} color="var(--green)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="در صف / انتظار" value={(c.queued || 0) + (c.sending || 0) + (c.sent || 0)} icon={<ClockCircleOutlined />} color="var(--pal-1)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="نیاز به بررسی" value={(c.failed || 0) + (c.not_sent || 0)} icon={<CloseCircleFilled />} color="var(--red)" /></Col>
        <Col xs={12} lg={6}><StatCard loading={st.loading} title="مالیات ثبت‌شده (تومان)" value={Math.round((s?.vat_30d || 0) / 10)} money icon={<AuditOutlined />} color="var(--amber)" /></Col>
      </Row>
      <Tabs items={[
        { key: 'inv', label: 'صورتحساب‌ها', children: <Invoices reloadKey={rk} onChange={st.reload} /> },
        { key: 'items', label: 'شناسه کالاها', children: <Items /> },
        { key: 'cfg', label: 'تنظیمات و کلیدها', children: s ? <Settings st={s} reload={() => { st.reload(); setRk(rk + 1) }} /> : null },
      ]} />
    </div>
  )
}
