import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor } from '@testing-library/react'
import { App } from 'antd'

/**
 * The five "connected service" screens (SMS, tax authority, branches, sales channels, card readers).
 * Their real behaviour lives in the backend and is covered by pytest; what is pinned here is the
 * front end's contract: the page renders from a status payload, shows the on/off state, the counters
 * an operator reacts to, and the right tabs. A blank screen on any of them means the shop cannot see
 * whether a service is even switched on.
 */
const get = vi.fn()
vi.mock('../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = (Comp) => render(<App><Comp /></App>)

const RESPONSES = {
  '/sms/status': {
    enabled: true, provider: 'kavenegar', providers: [{ key: 'kavenegar', title: 'کاوه‌نگار' }],
    sent_today: 42, queued: 3, failed_today: 1, credit: 5200, parts_30d: 1200, last_error: null, credit_error: null,
  },
  '/moadian/status': {
    enabled: true, mode: 'mock', counts: { success: 12, queued: 2, sending: 0, sent: 1, failed: 1, not_sent: 0 }, vat_30d: 1_200_000,
  },
  '/branches/local/status': { mode: 'standalone', branches: 0, last_push: null, last_error: null, central_url: '' },
  '/marketplace/channels': [{ id: 1, name: 'اسنپ‌فود', color: '#f59e0b', mode: 'test', is_active: true, commission_pct: 25, settlement_days: 7 }],
  '/cardreader/meta': { drivers: [], psps: [] },
  '/cardreader/terminals': [{ id: 1, name: 'پارس‌کالا', psp_title: 'به‌پرداخت ملت', driver: 'bridge', driver_title: 'پل (PC-POS)', url: 'http://127.0.0.1:4000', is_active: true }],
  '/cardreader/txns': { approved_count: 18, approved_total: 4_200_000, unlinked: 2, items: [] },
}

describe('Connected-service screens', () => {
  beforeEach(() => {
    get.mockReset()
    get.mockImplementation((path) => Promise.resolve(RESPONSES[path] ?? []))
  })

  it('SMS centre: shows the provider and the counters', async () => {
    const { default: SmsCenter } = await import('./sms/SmsCenter')
    page(SmsCenter)
    await waitFor(() => expect(text()).toContain('مرکز پیامک'))
    expect(text()).toContain('کاوه‌نگار')
    expect(text()).toContain('۴۲')          // sent today
    expect(text()).toContain('۵٬۲۰۰')       // credit
  })

  it('Tax authority: shows the mode tag and the queue counters', async () => {
    const { default: Moadian } = await import('./moadian/Moadian')
    page(Moadian)
    await waitFor(() => expect(text()).toContain('سامانه مودیان'))
    expect(text()).toContain('۱۲')          // successfully filed
    expect(text()).toContain('۳')           // queued + sent
  })

  it('Branches: shows this server as standalone with its settings tab', async () => {
    const { default: Branches } = await import('./branches/Branches')
    page(Branches)
    await waitFor(() => expect(text()).toContain('شعبه‌ها'))
    const tabs = [...document.querySelectorAll('.ant-tabs-tab')].map((t) => t.textContent)
    expect(tabs.join(' ')).toContain('تنظیمات این سرور')
    expect(tabs.join(' ')).not.toContain('مدیریت شعبه‌ها')   // nothing to manage in standalone mode
  })

  it('Sales channels: lists the channel card and offers a test order', async () => {
    const { default: Marketplace } = await import('./marketplace/Marketplace')
    page(Marketplace)
    await waitFor(() => expect(text()).toContain('کانال‌های فروش'))
    expect(text()).toContain('اسنپ‌فود')
    expect(text()).toContain('سفارش آزمایشی')       // only offered while the channel is in test mode
  })

  it('Card readers: shows the terminal, the approved total and the unmatched count', async () => {
    const { default: CardReaders } = await import('./cardreader/CardReaders')
    page(CardReaders)
    await waitFor(() => expect(text()).toContain('کارتخوان‌ها'))
    expect(text()).toContain('پارس‌کالا')
    expect(text()).toContain('۴٬۲۰۰٬۰۰۰')
    expect(text()).toContain('۲')                    // transactions on the device but not linked to an order
  })
})
