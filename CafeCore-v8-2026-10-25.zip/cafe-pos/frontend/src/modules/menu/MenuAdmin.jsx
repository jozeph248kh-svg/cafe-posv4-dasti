import { DeleteOutlined, EditOutlined, PlusOutlined, UploadOutlined, MinusCircleOutlined } from '@ant-design/icons'
import {
  App, Button, Card, Checkbox, Col, ColorPicker, Divider, Drawer, Form, Input, InputNumber, Modal, Popconfirm, Row, Segmented, Select, Space, Switch, Table, Tabs, Tag, Typography, Upload,
} from 'antd'
import { useMemo, useState } from 'react'
import { DataTag, PageHeader } from '../../components/common'
import { del, patch, post, put, upload } from '../../core/api'
import { useAuth } from '../../core/auth'
import { money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import RecipeEditor from '../inventory/RecipeEditor'

const hex = (c) => (typeof c === 'string' ? c : c?.toHexString?.() || '#6366f1')

function ImageField({ value, onChange }) {
  const { message } = App.useApp()
  return (
    <Space>
      {value && <img src={value} alt="" style={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 10 }} />}
      <Upload showUploadList={false} accept="image/*" customRequest={async ({ file }) => { try { onChange((await upload(file)).url) } catch (e) { message.error(e.message) } }}>
        <Button icon={<UploadOutlined />}>{value ? 'تغییر تصویر' : 'بارگذاری تصویر'}</Button>
      </Upload>
      {value && <Button type="text" danger onClick={() => onChange(null)}>حذف</Button>}
    </Space>
  )
}

function ItemsTab({ items, cats, groups, stations, reload }) {
  const auth = useAuth()
  const { message } = App.useApp()
  const [cat, setCat] = useState('all')
  const [q, setQ] = useState('')
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const catMap = Object.fromEntries(cats.map((c) => [c.id, c]))
  const list = items.filter((i) => i.is_active && (cat === 'all' || i.category_id === cat) && (!q || i.name.includes(q) || i.code === q))

  const open = (it) => {
    setEdit(it || {})
    form.resetFields()
    form.setFieldsValue(it || { category_id: cat !== 'all' ? cat : cats[0]?.id, price: 0, prep_minutes: 10, is_available: true, show_in_qr: true, modifier_group_ids: [], station_id: stations[0]?.id })
  }
  const save = async (v) => {
    try {
      const body = { ...edit, ...v, is_active: true, tags: Array.isArray(v.tags) ? v.tags.join(',') : v.tags }
      const r = edit.id ? await put(`/menu/items/${edit.id}`, body) : await post('/menu/items', body)
      message.success('ذخیره شد'); reload()
      if (!edit.id) setEdit(r); else setEdit(null)
    } catch (e) { message.error(e.message) }
  }
  const toggle = async (it, v) => { try { await patch(`/menu/items/${it.id}/availability?available=${v}`); reload() } catch (e) { message.error(e.message) } }
  const remove = async (it) => { await del(`/menu/items/${it.id}`); message.success('حذف شد'); reload() }

  return (
    <>
      <Space wrap style={{ marginBottom: 14, width: '100%', justifyContent: 'space-between' }}>
        <Space wrap>
          <Select value={cat} onChange={setCat} style={{ width: 200 }} options={[{ value: 'all', label: 'همه دسته‌ها' }, ...cats.map((c) => ({ value: c.id, label: `${c.icon || ''} ${c.name}` }))]} />
          <Input.Search placeholder="جستجوی نام یا کد" allowClear onChange={(e) => setQ(e.target.value)} style={{ width: 240 }} />
        </Space>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => open(null)}>آیتم جدید</Button>
      </Space>
      <Table rowKey="id" dataSource={list} pagination={{ pageSize: 20 }} scroll={{ x: 900 }}
        columns={[
          { title: 'آیتم', dataIndex: 'name', render: (v, r) => <Space>{r.image ? <img src={r.image} alt="" style={{ width: 40, height: 40, borderRadius: 8, objectFit: 'cover' }} /> : <span style={{ fontSize: 24 }}>{catMap[r.category_id]?.icon}</span>}<div><b>{v}</b>{r.tags && <div>{r.tags.split(',').map((t) => <Tag key={t} color="volcano" style={{ fontSize: 10 }}>{t}</Tag>)}</div>}</div></Space> },
          { title: 'کد', dataIndex: 'code', width: 70, render: (v) => v && <Tag>{v}</Tag> },
          { title: 'دسته', dataIndex: 'category_id', render: (v) => <DataTag color={catMap[v]?.color}>{catMap[v]?.name}</DataTag> },
          { title: 'قیمت', dataIndex: 'price', render: (v) => <b>{money(v)}</b>, sorter: (a, b) => a.price - b.price },
          { title: 'ایستگاه', dataIndex: 'station_id', render: (v) => stations.find((s) => s.id === v)?.name || '—' },
          { title: 'افزودنی‌ها', dataIndex: 'modifier_group_ids', render: (ids) => ids.map((id) => groups.find((g) => g.id === id)?.name).filter(Boolean).join('، ') || '—', ellipsis: true },
          { title: 'موجود', dataIndex: 'is_available', width: 80, render: (v, r) => <Switch size="small" checked={v} onChange={(x) => toggle(r, x)} /> },
          { title: '', width: 90, render: (_, r) => (
            <Space size={0}>
              <Button type="text" icon={<EditOutlined />} onClick={() => open(r)} />
              <Popconfirm title="این آیتم حذف شود؟" onConfirm={() => remove(r)} okText="حذف" cancelText="انصراف"><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>
            </Space>
          ) },
        ]} />
      <Drawer open={!!edit} onClose={() => setEdit(null)} width={Math.min(640, window.innerWidth)} title={edit?.id ? `ویرایش «${edit.name}»` : 'آیتم جدید'} destroyOnClose
        extra={<Button type="primary" onClick={() => form.submit()}>ذخیره</Button>}>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={16}><Form.Item name="name" label="نام آیتم" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={8}><Form.Item name="code" label="کد سریع" tooltip="کد عددی برای ثبت سریع در صندوق"><Input className="ltr" /></Form.Item></Col>
            <Col span={12}><Form.Item name="category_id" label="دسته‌بندی" rules={[{ required: true }]}><Select options={cats.map((c) => ({ value: c.id, label: `${c.icon || ''} ${c.name}` }))} /></Form.Item></Col>
            <Col span={12}><Form.Item name="price" label="قیمت فروش (تومان)" rules={[{ required: true }]}><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
            <Col span={12}><Form.Item name="station_id" label="ایستگاه آماده‌سازی"><Select allowClear options={stations.map((s) => ({ value: s.id, label: s.name }))} /></Form.Item></Col>
            <Col span={12}><Form.Item name="prep_minutes" label="زمان آماده‌سازی (دقیقه)"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>
          </Row>
          <Form.Item name="description" label="توضیحات (در منوی دیجیتال نمایش داده می‌شود)"><Input.TextArea rows={2} /></Form.Item>
          <Form.Item name="modifier_group_ids" label="گروه‌های افزودنی / انتخاب"><Select mode="multiple" options={groups.map((g) => ({ value: g.id, label: g.name }))} /></Form.Item>
          <Form.Item name="tags" label="برچسب‌ها" getValueProps={(v) => ({ value: typeof v === 'string' ? v.split(',').filter(Boolean) : v })}>
            <Select mode="tags" options={['پرفروش', 'ویژه', 'جدید', 'گیاهی', 'تند'].map((t) => ({ value: t, label: t }))} />
          </Form.Item>
          <Form.Item name="image" label="تصویر"><ImageField /></Form.Item>
          <Space size={24}>
            <Form.Item name="is_available" valuePropName="checked"><Checkbox>موجود</Checkbox></Form.Item>
            <Form.Item name="show_in_qr" valuePropName="checked"><Checkbox>نمایش در منوی QR</Checkbox></Form.Item>
          </Space>
        </Form>
        {edit?.id && auth.hasModule('inventory') && auth.can('inventory.manage') && (
          <>
            <Divider orientation="right">دستور پخت و بهای تمام‌شده</Divider>
            <Typography.Paragraph type="secondary">با هر فروش، این مواد به‌صورت خودکار از انبار کسر می‌شوند.</Typography.Paragraph>
            <RecipeEditor itemId={edit.id} price={form.getFieldValue('price') || edit.price} compact />
          </>
        )}
      </Drawer>
    </>
  )
}

function CategoriesTab({ cats, items, reload }) {
  const { message } = App.useApp()
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const counts = useMemo(() => { const m = {}; items.filter((i) => i.is_active).forEach((i) => { m[i.category_id] = (m[i.category_id] || 0) + 1 }); return m }, [items])
  const save = async (v) => {
    try {
      const body = { ...v, color: hex(v.color) }
      if (edit.id) await put(`/menu/categories/${edit.id}`, body); else await post('/menu/categories', body)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  return (
    <>
      <Button type="primary" icon={<PlusOutlined />} style={{ marginBottom: 14 }} onClick={() => { form.resetFields(); form.setFieldsValue({ color: '#6366f1', section: 'restaurant', is_active: true, sort: cats.length }); setEdit({}) }}>دسته جدید</Button>
      <Table rowKey="id" dataSource={cats} pagination={false}
        columns={[
          { title: 'دسته', dataIndex: 'name', render: (v, r) => <Space><span style={{ fontSize: 22 }}>{r.icon}</span><b>{v}</b></Space> },
          { title: 'بخش', dataIndex: 'section', render: (v) => (v === 'cafe' ? <Tag color="brown">کافه</Tag> : <Tag color="volcano">رستوران</Tag>) },
          { title: 'رنگ', dataIndex: 'color', render: (v) => <span style={{ display: 'inline-block', width: 22, height: 22, borderRadius: 6, background: v }} /> },
          { title: 'تعداد آیتم', render: (_, r) => num(counts[r.id] || 0) },
          { title: 'ترتیب', dataIndex: 'sort', render: (v) => num(v) },
          { title: 'فعال', dataIndex: 'is_active', render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
          { title: '', render: (_, r) => (
            <Space size={0}>
              <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(r); setEdit(r) }} />
              <Popconfirm title="دسته حذف شود؟" onConfirm={() => del(`/menu/categories/${r.id}`).then(reload).catch((e) => message.error(e.message))}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm>
            </Space>
          ) },
        ]} />
      <Modal open={!!edit} title={edit?.id ? 'ویرایش دسته' : 'دسته جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={6}><Form.Item name="icon" label="آیکن"><Input placeholder="☕" style={{ textAlign: 'center', fontSize: 20 }} /></Form.Item></Col>
            <Col span={18}><Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={8}><Form.Item name="section" label="بخش"><Select options={[{ value: 'cafe', label: 'کافه' }, { value: 'restaurant', label: 'رستوران' }]} /></Form.Item></Col>
            <Col span={8}><Form.Item name="color" label="رنگ"><ColorPicker showText /></Form.Item></Col>
            <Col span={8}><Form.Item name="sort" label="ترتیب"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          </Row>
          <Form.Item name="is_active" valuePropName="checked"><Checkbox>فعال</Checkbox></Form.Item>
        </Form>
      </Modal>
    </>
  )
}

function GroupsTab({ groups, reload }) {
  const { message } = App.useApp()
  const auth = useAuth()
  const [edit, setEdit] = useState(null)
  const [recipeOpt, setRecipeOpt] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    try {
      if (v.max_select < v.min_select) { message.error('حداکثر نباید کمتر از حداقل باشد'); return }
      if (edit.id) await put(`/menu/modifier-groups/${edit.id}`, v); else await post('/menu/modifier-groups', v)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  return (
    <>
      <Typography.Paragraph type="secondary">گروه‌هایی مثل «سایز»، «نوع شیر»، «درجه پخت» یا «افزودنی برگر» را تعریف و به آیتم‌ها وصل کنید.</Typography.Paragraph>
      <Button type="primary" icon={<PlusOutlined />} style={{ marginBottom: 14 }} onClick={() => { form.resetFields(); form.setFieldsValue({ min_select: 0, max_select: 1, options: [{ name: '', price_delta: 0 }] }); setEdit({}) }}>گروه جدید</Button>
      <Row gutter={[16, 16]}>
        {groups.map((g) => (
          <Col key={g.id} xs={24} md={12} xl={8}>
            <Card size="small" className="card-r" title={g.name}
              extra={<Space size={0}><Tag color={g.min_select ? 'red' : 'default'}>{g.min_select ? 'الزامی' : 'اختیاری'}</Tag><Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(g); setEdit(g) }} />
                <Popconfirm title="گروه حذف شود؟" onConfirm={() => del(`/menu/modifier-groups/${g.id}`).then(reload).catch((e) => message.error(e.message))}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm></Space>}>
              {g.options.map((o) => (
                <div key={o.id} className="kpi-mini">
                  <span>{o.name} {o.is_default && <Tag color="blue">پیش‌فرض</Tag>}{!o.is_available && <Tag>ناموجود</Tag>}</span>
                  <Space>{o.price_delta ? <b>+{money(o.price_delta)}</b> : <Typography.Text type="secondary">رایگان</Typography.Text>}
                    {auth.hasModule('inventory') && auth.can('inventory.manage') && <Typography.Link style={{ fontSize: 12 }} onClick={() => setRecipeOpt(o)}>مواد</Typography.Link>}</Space>
                </div>
              ))}
            </Card>
          </Col>
        ))}
      </Row>
      <Modal open={!!edit} title={edit?.id ? 'ویرایش گروه' : 'گروه جدید'} width={640} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="name" label="نام گروه" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={6}><Form.Item name="min_select" label="حداقل انتخاب"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={6}><Form.Item name="max_select" label="حداکثر انتخاب"><InputNumber min={1} style={{ width: '100%' }} /></Form.Item></Col>
          </Row>
          <Form.List name="options">
            {(fields, { add, remove }) => (
              <>
                {fields.map((f) => (
                  <Space key={f.key} align="baseline" style={{ display: 'flex', marginBottom: 4 }} wrap>
                    <Form.Item name={[f.name, 'id']} hidden><Input /></Form.Item>
                    <Form.Item name={[f.name, 'name']} rules={[{ required: true, message: 'نام' }]}><Input placeholder="نام گزینه" style={{ width: 180 }} /></Form.Item>
                    <Form.Item name={[f.name, 'price_delta']}><InputNumber placeholder="قیمت اضافه" style={{ width: 140 }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item>
                    <Form.Item name={[f.name, 'is_default']} valuePropName="checked"><Checkbox>پیش‌فرض</Checkbox></Form.Item>
                    <Form.Item name={[f.name, 'is_available']} valuePropName="checked" initialValue><Checkbox>موجود</Checkbox></Form.Item>
                    <MinusCircleOutlined onClick={() => remove(f.name)} style={{ color: 'var(--red)' }} />
                  </Space>
                ))}
                <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({ name: '', price_delta: 0, is_available: true })}>افزودن گزینه</Button>
              </>
            )}
          </Form.List>
        </Form>
      </Modal>
      <Modal open={!!recipeOpt} title={`مواد مصرفی گزینه «${recipeOpt?.name}»`} footer={null} width={640} onCancel={() => setRecipeOpt(null)} destroyOnClose>
        <Typography.Paragraph type="secondary">مثلاً «شیر بادام»: ۲۰۰ میلی‌لیتر شیر بادام. این مقدار علاوه بر رسپی آیتم کسر می‌شود.</Typography.Paragraph>
        {recipeOpt && <RecipeEditor optionId={recipeOpt.id} price={recipeOpt.price_delta} compact onSaved={() => setRecipeOpt(null)} />}
      </Modal>
    </>
  )
}

function StationsTab({ stations, reload }) {
  const { message } = App.useApp()
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    try {
      const body = { ...v, color: hex(v.color) }
      if (edit.id) await put(`/menu/stations/${edit.id}`, body); else await post('/menu/stations', body)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  return (
    <>
      <Typography.Paragraph type="secondary">هر آیتم به یک ایستگاه (آشپزخانه گرم، بار، سرد و دسر...) ارسال می‌شود و در نمایشگر همان ایستگاه نمایش داده می‌شود.</Typography.Paragraph>
      <Button type="primary" icon={<PlusOutlined />} style={{ marginBottom: 14 }} onClick={() => { form.resetFields(); form.setFieldsValue({ kind: 'kitchen', color: '#f97316', is_active: true, sort: stations.length }); setEdit({}) }}>ایستگاه جدید</Button>
      <Table rowKey="id" dataSource={stations} pagination={false}
        columns={[
          { title: 'ایستگاه', dataIndex: 'name', render: (v, r) => <Space><span style={{ width: 14, height: 14, borderRadius: 4, background: r.color, display: 'inline-block' }} /><b>{v}</b></Space> },
          { title: 'نوع', dataIndex: 'kind', render: (v) => (v === 'bar' ? 'بار / نوشیدنی' : 'آشپزخانه') },
          { title: 'فعال', dataIndex: 'is_active', render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
          { title: '', render: (_, r) => <Space size={0}><Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(r); setEdit(r) }} />
            <Popconfirm title="حذف شود؟" onConfirm={() => del(`/menu/stations/${r.id}`).then(reload).catch((e) => message.error(e.message))}><Button type="text" danger icon={<DeleteOutlined />} /></Popconfirm></Space> },
        ]} />
      <Modal open={!!edit} title="ایستگاه" onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item>
          <Space size={16}>
            <Form.Item name="kind" label="نوع"><Segmented options={[{ value: 'kitchen', label: 'آشپزخانه' }, { value: 'bar', label: 'بار' }]} /></Form.Item>
            <Form.Item name="color" label="رنگ"><ColorPicker /></Form.Item>
            <Form.Item name="sort" label="ترتیب"><InputNumber /></Form.Item>
          </Space>
          <Form.Item name="is_active" valuePropName="checked"><Checkbox>فعال</Checkbox></Form.Item>
        </Form>
      </Modal>
    </>
  )
}

export default function MenuAdmin() {
  const items = useFetch('/menu/items')
  const cats = useFetch('/menu/categories')
  const groups = useFetch('/menu/modifier-groups')
  const stations = useFetch('/menu/stations')
  const reloadAll = () => { items.reload(true); cats.reload(true); groups.reload(true); stations.reload(true) }
  const ready = items.data && cats.data && groups.data && stations.data
  return (
    <div className="fade-in">
      <PageHeader title="منو و قیمت‌ها" subtitle="آیتم‌ها، دسته‌بندی‌ها، گزینه‌های انتخابی و ایستگاه‌های آشپزخانه" />
      <Card className="card-r" loading={!ready}>
        {ready && (
          <Tabs items={[
            { key: 'items', label: `آیتم‌ها (${num(items.data.filter((i) => i.is_active).length)})`, children: <ItemsTab items={items.data} cats={cats.data} groups={groups.data} stations={stations.data} reload={reloadAll} /> },
            { key: 'cats', label: 'دسته‌بندی‌ها', children: <CategoriesTab cats={cats.data} items={items.data} reload={reloadAll} /> },
            { key: 'groups', label: 'گزینه‌ها و افزودنی‌ها', children: <GroupsTab groups={groups.data} reload={reloadAll} /> },
            { key: 'stations', label: 'ایستگاه‌ها', children: <StationsTab stations={stations.data} reload={reloadAll} /> },
          ]} />
        )}
      </Card>
    </div>
  )
}
