import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Menu prices are what every bill is built from. This file pins the list (price, station, add-ons,
// availability) and the two edits a cashier does mid-service: flipping availability, and saving a
// changed price — the most common and most expensive typo in a café.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const put = vi.fn()
const post = vi.fn()
const patch = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a), patch: (...a) => patch(...a),
  del: vi.fn(), download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../inventory/RecipeEditor', () => ({ default: () => <div>RECIPE-STUB</div> }))

const { default: MenuAdmin } = await import('./MenuAdmin')

const CATS = [
  { id: 1, name: 'قهوه گرم', icon: '☕', color: '#92400e' },
  { id: 2, name: 'کیک', icon: '🍰', color: '#be185d' },
]
const ITEMS = [
  { id: 11, name: 'اسپرسو', code: '101', category_id: 1, price: 140_000, station_id: 1, is_active: true, is_available: true, show_in_qr: true, modifier_group_ids: [], tags: 'پرفروش' },
  { id: 12, name: 'آمریکانو', code: '102', category_id: 1, price: 160_000, station_id: 1, is_active: true, is_available: false, show_in_qr: true, modifier_group_ids: [7], tags: '' },
  { id: 13, name: 'چیزکیک', code: '201', category_id: 2, price: 190_000, station_id: 2, is_active: true, is_available: true, show_in_qr: false, modifier_group_ids: [], tags: '' },
]
const GROUPS = [{ id: 7, name: 'سایز' }]
const STATIONS = [{ id: 1, name: 'بار' }, { id: 2, name: 'قنادی' }]

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/menu/items') return Promise.resolve(ITEMS)
    if (path === '/menu/categories') return Promise.resolve(CATS)
    if (path === '/menu/modifier-groups') return Promise.resolve(GROUPS)
    if (path === '/menu/stations') return Promise.resolve(STATIONS)
    return Promise.resolve([])
  })
}
const page = () => render(<App><MenuAdmin /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Menu admin', () => {
  beforeEach(() => { get.mockReset(); put.mockReset(); post.mockReset(); patch.mockReset(); respond() })

  it('lists items with price, category, station and add-ons', async () => {
    page()
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('۱۴۰٬۰۰۰')
    expect(text()).toContain('قهوه گرم')
    expect(text()).toContain('بار')
    expect(text()).toContain('سایز')            // the modifier group name, not its id
    expect(text()).toContain('پرفروش')          // tag chip
  })

  it('filters by category and by search text without a round-trip', async () => {
    page()
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    get.mockClear()
    await user().type(screen.getByPlaceholderText('جستجوی نام یا کد'), 'چیز')
    await waitFor(() => expect(text()).toContain('چیزکیک'))
    expect(text()).not.toContain('آمریکانو')
    expect(get).not.toHaveBeenCalled()          // filtering is local
  })

  it('flips availability with PATCH and the right query flag', async () => {
    patch.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('آمریکانو'))
    const switches = [...document.querySelectorAll('.ant-switch')]
    await user().click(switches[1])             // second row = آمریکانو (currently unavailable)
    await waitFor(() => expect(patch).toHaveBeenCalledWith('/menu/items/12/availability?available=true'))
  })

  it('saves a changed price and sends the whole item back', async () => {
    put.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    const editButtons = [...document.querySelectorAll('.anticon-edit')]
    await user().click(editButtons[0].closest('button'))
    await waitFor(() => expect(text()).toContain('ویرایش «اسپرسو»'))
    // typing digit-by-digit into an antd InputNumber inside a jsdom drawer is slow; a single
    // change event exercises the same code path (the form value + what save() sends)
    const price = document.querySelector('.ant-drawer input[id$="price"]') || [...document.querySelectorAll('.ant-drawer input')][3]
    fireEvent.change(price, { target: { value: '150000' } })
    await user().click(screen.getByRole('button', { name: 'ذخیره' }))
    await waitFor(() => expect(put).toHaveBeenCalled())
    const [path, body] = put.mock.calls[0]
    expect(path).toBe('/menu/items/11')
    expect(body.price).toBe(150000)
    expect(body.category_id).toBe(1)            // untouched fields are not dropped
  })

  it('counts the active items in the tab label', async () => {
    page()
    await waitFor(() => expect(text()).toContain('آیتم‌ها'))
    expect(text()).toContain('آیتم‌ها (۳)')
  })

  it('shows every management tab', async () => {
    page()
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    const tabs = [...document.querySelectorAll('.ant-tabs-tab')].map((t) => t.textContent)
    expect(tabs.join(' ')).toContain('دسته‌بندی‌ها')
    expect(tabs.join(' ')).toContain('گزینه‌ها و افزودنی‌ها')
    expect(tabs.join(' ')).toContain('ایستگاه‌ها')
  })
})
