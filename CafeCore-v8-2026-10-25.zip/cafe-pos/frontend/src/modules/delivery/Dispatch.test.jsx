import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Dispatch board: delivery orders move through columns, and each move is an API call. The board is
// what the cashier stares at while couriers are on the road, so the column counts and the courier
// state ("out" vs "free") must match the payload.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
const put = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: (...a) => put(...a), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: Dispatch } = await import('./Dispatch')

const BOARD = {
  orders: [
    { order_id: 71, number: 41, status: 'waiting', customer_name: 'خانم رضایی', phone: '09121234567', address: 'ونک، خیابان سرو', total: 480_000, delivery_fee: 45_000, customer_address: 'ونک، خیابان سرو', customer_phone: '09121234567', items: [{ qty: 2, name: 'اسپرسو' }, { qty: 1, name: 'کیک' }], order_status: 'closed', created_at: new Date(Date.now() - 8 * 60000).toISOString(), zone_id: 1, courier_id: null },
    { order_id: 72, number: 42, status: 'assigned', customer_name: 'آقای محمدی', phone: '09127654321', address: 'سعادت‌آباد', total: 320_000, delivery_fee: 35_000, customer_address: 'سعادت‌آباد', customer_phone: '09127654321', items: [{ qty: 1, name: 'آمریکانو' }], order_status: 'closed', created_at: new Date(Date.now() - 20 * 60000).toISOString(), zone_id: 1, courier_id: 5, courier: 'مهدی' },
    { order_id: 73, number: 43, status: 'out', customer_name: 'خانم کریمی', phone: '09120000000', address: 'شریعتی', total: 610_000, delivery_fee: 50_000, customer_address: 'شریعتی', customer_phone: '09120000000', items: [{ qty: 3, name: 'لاته' }], order_status: 'closed', created_at: new Date(Date.now() - 35 * 60000).toISOString(), zone_id: 2, courier_id: 6, courier: 'سعید' },
  ],
  couriers: [
    { id: 5, name: 'مهدی', vehicle: 'motor', active: 1, out: 0, today: 4, unsettled: 120_000 },
    { id: 6, name: 'سعید', vehicle: 'bike', active: 0, out: 1, today: 2, unsettled: 0 },
  ],
  zones: [{ id: 1, name: 'ونک', customer_fee: 45_000 }, { id: 2, name: 'شریعتی', customer_fee: 50_000 }],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => (path === '/delivery/board' ? Promise.resolve(BOARD) : Promise.resolve([])))
}
const page = () => render(<App><Dispatch /></App>)

describe('Dispatch board', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); put.mockReset(); respond() })

  it('puts every order in its status column and counts them', async () => {
    page()
    await waitFor(() => expect(text()).toContain('در انتظار پیک'))
    expect(text()).toContain('خانم رضایی')
    expect(text()).toContain('آقای محمدی')
    expect(text()).toContain('خانم کریمی')
    // the "out" column has one order, the "delivered" column is empty
    expect(text()).toContain('سفارشی نیست')
  })

  it('shows who is on the road and who is free', async () => {
    page()
    await waitFor(() => expect(text()).toContain('خانم رضایی'))     // the board must be loaded first
    expect(text()).toContain('مهدی')
    expect(text()).toContain('در مسیر (۱)')          // سعید
    expect(text()).toContain('۱ سفارش تخصیص‌یافته')  // مهدی
  })

  it('offers settlement only for a courier who owes money', async () => {
    page()
    await waitFor(() => expect(text()).toContain('خانم رضایی'))
    const settleButtons = [...document.querySelectorAll('button')].filter((b) => b.textContent.includes('تسویه'))
    expect(settleButtons).toHaveLength(1)            // only مهدی has unsettled cash
  })

  it('switches between the four tabs', async () => {
    page()
    await waitFor(() => expect(text()).toContain('تابلوی ارسال'))
    const tabs = [...document.querySelectorAll('.ant-segmented-item-label')].map((t) => t.textContent)
    expect(tabs).toEqual(['تابلوی ارسال', 'پیک‌ها', 'مناطق و تعرفه', 'گزارش و تسویه‌ها'])
  })

  it('asks for the board and then for the couriers when that tab is opened', async () => {
    page()
    await waitFor(() => expect(get.mock.calls.some(([p]) => p === '/delivery/board')).toBe(true))
    get.mockClear()
    const tab = [...document.querySelectorAll('.ant-segmented-item-label')].find((t) => t.textContent === 'پیک‌ها')
    await user().click(tab)
    await waitFor(() => expect(get.mock.calls.some(([p]) => p === '/delivery/couriers')).toBe(true))
  })
})
