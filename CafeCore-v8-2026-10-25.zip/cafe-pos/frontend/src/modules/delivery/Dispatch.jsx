import { CheckOutlined, EditOutlined, EnvironmentOutlined, PhoneOutlined, PlusOutlined, ReloadOutlined, RollbackOutlined, SendOutlined } from '@ant-design/icons'
import { App, Badge, Button, Card, Col, Dropdown, Empty, Form, Input, InputNumber, Modal, Radio, Row, Segmented, Space, Switch, Table, Tag, Tooltip, Typography } from 'antd'
import { useState } from 'react'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader, StatCard } from '../../components/common'
import { post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { faDateTime, faTime, minutesSince, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useRealtime } from '../../core/realtime'
import { useFetch } from '../../core/useFetch'

export const D_STATUS = {
  waiting: { label: 'در انتظار پیک', color: 'var(--warn-solid)', tag: 'gold' }, assigned: { label: 'پیک تعیین شد', color: 'var(--hero-base)', tag: 'blue' },
  out: { label: 'در مسیر', color: 'var(--violet-solid)', tag: 'purple' }, delivered: { label: 'تحویل شد', color: 'var(--ok-solid)', tag: 'green' }, failed: { label: 'ناموفق', color: 'var(--bad-solid)', tag: 'red' },
}
const VEH = { motor: '🏍️ موتور', car: '🚗 خودرو', bike: '🚲 دوچرخه' }
const COLS = ['waiting', 'assigned', 'out', 'delivered']

function OrderCard({ r, couriers, zones, onUpdate, onStatus }) {
  const mins = minutesSince(r.created_at)
  const late = r.status !== 'delivered' && r.eta && mins > r.eta + 10
  const courierMenu = { items: couriers.map((c) => ({ key: c.id, label: <span>{c.name} <Typography.Text type="secondary" style={{ fontSize: 11 }}>({num(c.active)} فعال)</Typography.Text></span> })), onClick: ({ key }) => onUpdate(r, { courier_id: Number(key) }) }
  const zoneMenu = { items: zones.map((z) => ({ key: z.id, label: `${z.name} · ${money(z.customer_fee)}` })), onClick: ({ key }) => onUpdate(r, { zone_id: Number(key) }) }
  return (
    <div className={`dp-card ${late ? 'late' : ''}`} style={{ '--c': D_STATUS[r.status]?.color }}>
      <div className="dp-head">
        <b>#{num(r.number)}</b>
        {r.source !== 'pos' && <Tag color="cyan" style={{ margin: 0 }}>{r.source === 'online' ? 'آنلاین' : r.source}</Tag>}
        <span className="dp-time">{r.status === 'delivered' ? `✔ ${faTime(r.delivered_at)}` : `⏱ ${num(mins)} دقیقه`}</span>
      </div>
      <div className="dp-cust"><b>{r.customer_name || 'مشتری'}</b> <a className="ltr" href={`tel:${r.customer_phone}`}><PhoneOutlined /> {r.customer_phone}</a></div>
      <div className="dp-addr"><EnvironmentOutlined /> {r.customer_address}</div>
      <div className="dp-items">{r.items.map((i) => `${num(i.qty)}× ${i.name}`).join('، ')}</div>
      <div className="dp-meta">
        <Dropdown menu={zoneMenu} trigger={['click']} disabled={r.settled}><Tag className="dp-click" color={r.zone ? 'geekblue' : 'default'}>{r.zone || 'تعیین منطقه'}</Tag></Dropdown>
        {r.status !== 'delivered' && (r.kitchen_ready ? <Tag color="green">✓ آماده</Tag> : <Tag>در آشپزخانه</Tag>)}
        {r.order_status === 'closed' ? <Tag color="green">پرداخت‌شده</Tag> : r.collect ? <Tag color="orange">دریافت در محل {money(r.collect_amount)}</Tag> : <Tag color="red">پرداخت‌نشده</Tag>}
        {r.settled && <Tag>تسویه‌شده</Tag>}
      </div>
      <div className="dp-foot">
        <b className="money">{money(r.total)}</b>
        <Space size={4}>
          {!r.settled && r.status !== 'delivered' && (
            <Dropdown menu={courierMenu} trigger={['click']}><Button size="small" icon={<span>🛵</span>}>{r.courier || 'انتخاب پیک'}</Button></Dropdown>
          )}
          {r.status === 'delivered' && r.courier && <Tag style={{ margin: 0 }}>🛵 {r.courier}</Tag>}
          {r.status === 'assigned' && <Button size="small" type="primary" icon={<SendOutlined />} onClick={() => onStatus(r, 'out')}>ارسال</Button>}
          {r.status === 'out' && <Button size="small" type="primary" style={{ background: 'var(--ok-solid)', color: '#fff' }} icon={<CheckOutlined />} onClick={() => onStatus(r, 'delivered')}>تحویل</Button>}
          {(r.status === 'out' || r.status === 'assigned') && <Tooltip title="بازگشت به صف انتظار"><Button size="small" type="text" icon={<RollbackOutlined />} onClick={() => onStatus(r, 'waiting')} /></Tooltip>}
        </Space>
      </div>
    </div>
  )
}

function SettleModal({ courier, onClose, onDone }) {
  const { message } = App.useApp()
  const { data, loading } = useFetch(`/delivery/couriers/${courier.id}/unsettled`)
  const [method, setMethod] = useState('cash')
  const [busy, setBusy] = useState(false)
  const submit = async () => {
    setBusy(true)
    try { const r = await post(`/delivery/couriers/${courier.id}/settle`, { method }); message.success(`تسویه انجام شد — ${r.net >= 0 ? 'دریافت از پیک' : 'پرداخت به پیک'}: ${money(Math.abs(r.net))} تومان`); onDone() } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open title={`تسویه حساب با ${courier.name}`} width={680} onCancel={onClose} onOk={submit} okText="ثبت تسویه" confirmLoading={busy} okButtonProps={{ disabled: !data?.orders.length }}>
      <Table size="small" rowKey="order_id" loading={loading} dataSource={data?.orders || []} pagination={false} scroll={{ y: 300 }}
        columns={[
          { title: '#', dataIndex: 'number', render: (v) => num(v), width: 60 },
          { title: 'مشتری', dataIndex: 'customer_name' },
          { title: 'منطقه', dataIndex: 'zone', render: (v) => v || '—' },
          { title: 'دریافت در محل', dataIndex: 'collect_amount', render: (v) => (v ? <b>{money(v)}</b> : '—') },
          { title: 'حق‌الزحمه', dataIndex: 'courier_fee', render: money },
        ]} />
      {data && (
        <div className="settle-box">
          <div><span>وجه نقد دریافتی پیک از مشتریان</span><b>{money(data.collected)}</b></div>
          <div><span>حق‌الزحمه پیک ({num(data.orders.length)} سفارش)</span><b style={{ color: 'var(--red)' }}>−{money(data.fees)}</b></div>
          <div className="big"><span>{data.net >= 0 ? 'مبلغ قابل دریافت از پیک' : 'مبلغ قابل پرداخت به پیک'}</span><b>{money(Math.abs(data.net))} تومان</b></div>
          {data.unpaid.length > 0 && <Typography.Text type="warning" style={{ fontSize: 12 }}>سفارش‌های {data.unpaid.map((n) => `#${num(n)}`).join('، ')} پرداخت‌نشده‌اند و پس از تسویه همچنان در صندوق باز می‌مانند.</Typography.Text>}
        </div>
      )}
      <div style={{ marginTop: 12 }}>
        <span style={{ marginLeft: 10 }}>پرداخت حق‌الزحمه:</span>
        <Radio.Group value={method} onChange={(e) => setMethod(e.target.value)} optionType="button" options={[{ value: 'cash', label: 'نقد از صندوق' }, { value: 'card', label: 'کارت' }, { value: 'transfer', label: 'انتقال بانکی' }]} />
      </div>
    </Modal>
  )
}

function Board() {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/delivery/board')
  const [settle, setSettle] = useState(null)
  const [busyId, setBusyId] = useState(null)
  useRealtime(['delivery.changed', 'order.changed', 'kitchen.ready', '_reconnected'], () => reload(true))
  const run = async (r, fn) => { setBusyId(r.order_id); try { await fn(); reload(true) } catch (e) { message.error(e.message) } finally { setBusyId(null) } }
  const onUpdate = (r, body) => run(r, () => put(`/delivery/orders/${r.order_id}`, body))
  const onStatus = (r, status) => run(r, () => post(`/delivery/orders/${r.order_id}/status`, { status }))
  const rows = data?.orders || []
  return (
    <Row gutter={[16, 16]}>
      <Col xs={24} xxl={18}>
        <div className="dp-board">
          {COLS.map((k) => {
            const list = rows.filter((r) => r.status === k)
            return (
              <div key={k} className="dp-col">
                <div className="dp-col-head" style={{ '--c': D_STATUS[k].color }}><span>{D_STATUS[k].label}</span><Badge count={list.length} showZero color={D_STATUS[k].color} /></div>
                <div className="dp-col-body">
                  {list.length ? list.map((r) => (
                    <div key={r.order_id} style={{ opacity: busyId === r.order_id ? 0.5 : 1 }}>
                      <OrderCard r={r} couriers={data.couriers} zones={data.zones} onUpdate={onUpdate} onStatus={onStatus} />
                    </div>
                  )) : <div className="dp-empty">{loading ? '...' : 'سفارشی نیست'}</div>}
                </div>
              </div>
            )
          })}
        </div>
      </Col>
      <Col xs={24} xxl={6}>
        <Card className="card-r" title="پیک‌ها" size="small" extra={<Button size="small" type="text" icon={<ReloadOutlined />} onClick={() => reload()} />}>
          {(data?.couriers || []).length === 0 && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="پیک فعالی تعریف نشده" />}
          {(data?.couriers || []).map((c) => (
            <div key={c.id} className="courier-row">
              <div className={`courier-av ${c.out ? 'busy' : c.active ? 'assigned' : 'free'}`}>{c.vehicle === 'car' ? '🚗' : c.vehicle === 'bike' ? '🚲' : '🏍️'}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <b>{c.name}</b>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>{c.out ? `در مسیر (${num(c.out)})` : c.active ? `${num(c.active)} سفارش تخصیص‌یافته` : 'آزاد'} · امروز {num(c.today)}</div>
              </div>
              {c.unsettled > 0 && <Button size="small" onClick={() => setSettle(c)}>تسویه ({num(c.unsettled)})</Button>}
            </div>
          ))}
        </Card>
      </Col>
      {settle && <SettleModal courier={settle} onClose={() => setSettle(null)} onDone={() => { setSettle(null); reload(true) }} />}
    </Row>
  )
}

function Couriers() {
  const { message } = App.useApp()
  const auth = useAuth()
  const { data, loading, reload } = useFetch('/delivery/couriers')
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    try { if (edit.id) await put(`/delivery/couriers/${edit.id}`, v); else await post('/delivery/couriers', v); message.success('ذخیره شد'); setEdit(null); reload() } catch (e) { message.error(e.message) }
  }
  const can = auth.can('delivery.manage')
  return (<>
    {can && <Button icon={<PlusOutlined />} style={{ marginBottom: 12 }} onClick={() => { form.resetFields(); setEdit({}) }}>پیک جدید</Button>}
    <Table rowKey="id" loading={loading} dataSource={data || []} pagination={false} scroll={{ x: 640 }}
      columns={[
        { title: 'نام', dataIndex: 'name', render: (v) => <b>{v}</b> },
        { title: 'تلفن', dataIndex: 'phone', render: (v) => <span className="ltr">{v}</span> },
        { title: 'وسیله', dataIndex: 'vehicle', render: (v, c) => <span>{VEH[v]} {c.plate && <Typography.Text type="secondary" style={{ fontSize: 12 }}>({c.plate})</Typography.Text>}</span> },
        { title: 'حق‌الزحمه پیش‌فرض', dataIndex: 'default_fee', render: money },
        { title: 'وضعیت', dataIndex: 'is_active', render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
        { title: '', width: 50, render: (_, c) => can && <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(c); setEdit(c) }} /> },
      ]} />
    <Modal open={!!edit} title={edit?.id ? 'ویرایش پیک' : 'پیک جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
      <Form form={form} layout="vertical" onFinish={save} initialValues={{ vehicle: 'motor', default_fee: 0, is_active: true }}>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="phone" label="موبایل"><Input className="ltr" inputMode="tel" /></Form.Item></Col>
          <Col span={12}><Form.Item name="vehicle" label="وسیله"><Radio.Group optionType="button" options={Object.entries(VEH).map(([value, label]) => ({ value, label }))} /></Form.Item></Col>
          <Col span={12}><Form.Item name="plate" label="پلاک"><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="default_fee" label="حق‌الزحمه هر سفارش (اگر منطقه تعیین نکند)"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
          <Col span={12}><Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
        <Form.Item name="note" label="توضیحات"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  </>)
}

function Zones() {
  const { message } = App.useApp()
  const auth = useAuth()
  const { data, loading, reload } = useFetch('/delivery/zones')
  const [edit, setEdit] = useState(null)
  const [form] = Form.useForm()
  const save = async (v) => {
    try { if (edit.id) await put(`/delivery/zones/${edit.id}`, v); else await post('/delivery/zones', v); message.success('ذخیره شد'); setEdit(null); reload() } catch (e) { message.error(e.message) }
  }
  const can = auth.can('delivery.manage')
  return (<>
    {can && <Button icon={<PlusOutlined />} style={{ marginBottom: 12 }} onClick={() => { form.resetFields(); setEdit({}) }}>منطقه جدید</Button>}
    <Table rowKey="id" loading={loading} dataSource={data || []} pagination={false} scroll={{ x: 640 }}
      columns={[
        { title: 'منطقه', dataIndex: 'name', render: (v) => <b>{v}</b> },
        { title: 'هزینه ارسال (مشتری)', dataIndex: 'customer_fee', render: money },
        { title: 'حق‌الزحمه پیک', dataIndex: 'courier_fee', render: money },
        { title: 'زمان تقریبی', dataIndex: 'eta_minutes', render: (v) => `${num(v)} دقیقه` },
        { title: 'حداقل سفارش', dataIndex: 'min_order', render: (v) => (v ? money(v) : '—') },
        { title: 'وضعیت', dataIndex: 'is_active', render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag>غیرفعال</Tag>) },
        { title: '', width: 50, render: (_, z) => can && <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(z); setEdit(z) }} /> },
      ]} />
    <Modal open={!!edit} title={edit?.id ? 'ویرایش منطقه' : 'منطقه جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
      <Form form={form} layout="vertical" onFinish={save} initialValues={{ customer_fee: 0, courier_fee: 0, eta_minutes: 30, min_order: 0, sort: 0, is_active: true }}>
        <Form.Item name="name" label="نام منطقه" rules={[{ required: true, min: 2 }]}><Input placeholder="مثلاً: محدوده ۱ — تا ۲ کیلومتر" /></Form.Item>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="customer_fee" label="هزینه ارسال (روی فاکتور مشتری)"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
          <Col span={12}><Form.Item name="courier_fee" label="حق‌الزحمه پیک"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
          <Col span={8}><Form.Item name="eta_minutes" label="زمان (دقیقه)"><InputNumber min={5} max={240} style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={8}><Form.Item name="min_order" label="حداقل سفارش"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
          <Col span={8}><Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
    </Modal>
  </>)
}

function Reports() {
  const [range, setRange] = useState(rangeOf('week'))
  const rep = useFetch('/delivery/report', { date_from: range.from, date_to: range.to })
  const st = useFetch('/delivery/settlements', { date_from: range.from, date_to: range.to })
  const r = rep.data
  return (<>
    <div style={{ marginBottom: 14 }}><JalaliRange value={range} onChange={setRange} /></div>
    <Row gutter={[12, 12]}>
      <Col xs={12} md={6}><StatCard loading={rep.loading} title="سفارش پیک" value={r?.orders} icon={<span>🛵</span>} color="var(--violet)" /></Col>
      <Col xs={12} md={6}><StatCard loading={rep.loading} title="تحویل‌شده" value={r?.delivered} hint={r?.failed ? `${num(r.failed)} ناموفق` : undefined} icon={<CheckOutlined />} color="var(--green)" /></Col>
      <Col xs={12} md={6}><StatCard loading={rep.loading} title="هزینه ارسال دریافتی" value={r?.customer_fees} money icon={<span>💰</span>} color="var(--blue)" /></Col>
      <Col xs={12} md={6}><StatCard loading={rep.loading} title="حق‌الزحمه پیک‌ها" value={r?.courier_fees} money icon={<span>🧾</span>} color="var(--pal-9)" /></Col>
    </Row>
    <Row gutter={16} style={{ marginTop: 16 }}>
      <Col xs={24} lg={12}>
        <Typography.Title level={5}>عملکرد پیک‌ها</Typography.Title>
        <Table size="small" rowKey="name" pagination={false} dataSource={r?.by_courier || []}
          columns={[{ title: 'پیک', dataIndex: 'name' }, { title: 'تحویل', dataIndex: 'count', render: (v) => num(v) }, { title: 'میانگین زمان تحویل', dataIndex: 'avg_minutes', render: (v) => (v ? `${num(v)} دقیقه` : '—') }, { title: 'حق‌الزحمه', dataIndex: 'fees', render: money }]} />
      </Col>
      <Col xs={24} lg={12}>
        <Typography.Title level={5}>بر اساس منطقه</Typography.Title>
        <Table size="small" rowKey="name" pagination={false} dataSource={r?.by_zone || []}
          columns={[{ title: 'منطقه', dataIndex: 'name' }, { title: 'سفارش', dataIndex: 'count', render: (v) => num(v) }, { title: 'فروش', dataIndex: 'revenue', render: money }]} />
      </Col>
    </Row>
    <Typography.Title level={5} style={{ marginTop: 20 }}>تسویه‌های پیک</Typography.Title>
    <Table size="small" rowKey="id" loading={st.loading} dataSource={st.data || []} pagination={{ pageSize: 10, hideOnSinglePage: true }} scroll={{ x: 700 }}
      columns={[
        { title: 'زمان', dataIndex: 'created_at', render: faDateTime }, { title: 'پیک', dataIndex: 'courier' }, { title: 'سفارش', dataIndex: 'deliveries', render: (v) => num(v) },
        { title: 'وجه دریافتی', dataIndex: 'collected', render: money }, { title: 'حق‌الزحمه', dataIndex: 'fees', render: money },
        { title: 'خالص', dataIndex: 'net', render: (v) => <b style={{ color: v >= 0 ? 'var(--green)' : 'var(--red)' }}>{money(v)}</b> }, { title: 'توسط', dataIndex: 'by' },
      ]} />
  </>)
}

export default function Dispatch() {
  const [tab, setTab] = useState('board')
  return (
    <div className="fade-in">
      <PageHeader title="پیک و ارسال" subtitle="توزیع سفارش‌های بیرون‌بر بین پیک‌ها، پیگیری لحظه‌ای و تسویه حساب پیک"
        extra={<Segmented value={tab} onChange={setTab} options={[{ value: 'board', label: 'تابلوی ارسال' }, { value: 'couriers', label: 'پیک‌ها' }, { value: 'zones', label: 'مناطق و تعرفه' }, { value: 'reports', label: 'گزارش و تسویه‌ها' }]} />} />
      {tab === 'board' && <Board />}
      {tab !== 'board' && <Card className="card-r">{tab === 'couriers' ? <Couriers /> : tab === 'zones' ? <Zones /> : <Reports />}</Card>}
    </div>
  )
}
