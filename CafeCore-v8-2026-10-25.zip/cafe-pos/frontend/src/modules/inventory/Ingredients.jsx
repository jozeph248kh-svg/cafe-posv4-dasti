import { DeleteOutlined, EditOutlined, ExperimentOutlined, PlusOutlined, WarningOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, Divider, Form, Input, InputNumber, Modal, Progress, Row, Segmented, Select, Space, Table, Tag, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { UNITS, compact, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useRealtime } from '../../core/realtime'
import { useFetch } from '../../core/useFetch'

export default function Ingredients() {
  const auth = useAuth()
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/inventory/ingredients')
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [cat, setCat] = useState(null)
  const [edit, setEdit] = useState(null)
  const [adj, setAdj] = useState(null)
  const [form] = Form.useForm()
  const [af] = Form.useForm()
  const canManage = auth.can('inventory.manage')
  useRealtime(['inventory.low', 'order.changed'], () => reload(true))

  const cats = useMemo(() => [...new Set((data || []).map((i) => i.category).filter(Boolean))], [data])
  const list = (data || []).filter((i) => (!q || i.name.includes(q)) && (filter === 'all' || (filter === 'low' ? i.is_low : !i.is_active)) && (!cat || i.category === cat) && (filter === 'inactive' || i.is_active))
  const totalValue = (data || []).reduce((a, i) => a + i.stock_value, 0)
  const lowCount = (data || []).filter((i) => i.is_low && i.is_active).length

  const save = async (v) => {
    try {
      if (edit.id) await put(`/inventory/ingredients/${edit.id}`, { ...edit, ...v }); else await post('/inventory/ingredients', v)
      message.success('ذخیره شد'); setEdit(null); reload()
    } catch (e) { message.error(e.message) }
  }
  const saveAdj = async (v) => {
    try {
      const qty = v.kind === 'adjust' && v.direction === 'minus' ? -v.qty : v.qty
      await post(`/inventory/ingredients/${adj.id}/adjust`, { kind: v.kind, qty, note: v.note })
      message.success('ثبت شد'); setAdj(null); reload()
    } catch (e) { message.error(e.message) }
  }

  return (
    <div className="fade-in">
      <PageHeader title="مواد اولیه" subtitle="موجودی لحظه‌ای انبار — با هر فروش بر اساس رسپی به‌صورت خودکار کسر می‌شود"
        extra={canManage && <Button type="primary" icon={<PlusOutlined />} onClick={() => { form.resetFields(); form.setFieldsValue({ unit: 'g', min_stock: 0, cost_per_unit: 0, opening_stock: 0, is_active: true, purchase_units: [] }); setEdit({}) }}>ماده جدید</Button>} />
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={24} md={8}><StatCard title="ارزش کل موجودی انبار" value={totalValue} money suffix="تومان" icon="📦" loading={loading} /></Col>
        <Col xs={12} md={8}><StatCard title="تعداد اقلام" value={(data || []).filter((i) => i.is_active).length} icon={<ExperimentOutlined />} color="var(--blue)" loading={loading} /></Col>
        <Col xs={12} md={8}><StatCard title="زیر حداقل موجودی" value={lowCount} icon={<WarningOutlined />} color={lowCount ? 'var(--red)' : 'var(--green)'} loading={loading} onClick={() => setFilter('low')} /></Col>
      </Row>
      <Card className="card-r">
        <Space wrap style={{ marginBottom: 14 }}>
          <Input.Search placeholder="جستجو" allowClear onChange={(e) => setQ(e.target.value)} style={{ width: 220 }} />
          <Segmented value={filter} onChange={setFilter} options={[{ value: 'all', label: 'همه' }, { value: 'low', label: `کمبود (${num(lowCount)})` }, { value: 'inactive', label: 'غیرفعال' }]} />
          <Select allowClear placeholder="دسته" style={{ width: 150 }} value={cat} onChange={setCat} options={cats.map((c) => ({ value: c, label: c }))} />
        </Space>
        <Table rowKey="id" loading={loading} dataSource={list} pagination={{ pageSize: 25 }} scroll={{ x: 900 }} rowClassName={(r) => (r.is_low ? 'low-row' : '')}
          columns={[
            { title: 'ماده', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> {r.is_low && <Tag color="red">کمبود</Tag>}</span>, sorter: (a, b) => a.name.localeCompare(b.name, 'fa') },
            { title: 'دسته', dataIndex: 'category', render: (v) => v && <Tag>{v}</Tag> },
            { title: 'موجودی', dataIndex: 'stock', sorter: (a, b) => a.stock / (a.min_stock || 1) - b.stock / (b.min_stock || 1), render: (v, r) => (
              <div style={{ minWidth: 150 }}>
                <b style={{ color: r.is_low ? 'var(--red)' : undefined }}>{num(v, 1)}</b> <Typography.Text type="secondary">{UNITS[r.unit]}</Typography.Text>
                {r.min_stock > 0 && <Progress size="small" showInfo={false} percent={Math.min(100, (v / (r.min_stock * 3)) * 100)} strokeColor={r.is_low ? 'var(--red-raw)' : v < r.min_stock * 1.5 ? 'var(--amber-raw)' : 'var(--green-raw)'} />}
              </div>
            ) },
            { title: 'حداقل', dataIndex: 'min_stock', render: (v, r) => `${num(v, 1)} ${UNITS[r.unit]}` },
            { title: 'بهای واحد', dataIndex: 'cost_per_unit', render: (v, r) => <span>{money(v)} <Typography.Text type="secondary" style={{ fontSize: 11 }}>/ {UNITS[r.unit]}</Typography.Text></span> },
            { title: 'ارزش موجودی', dataIndex: 'stock_value', render: (v) => compact(v), sorter: (a, b) => a.stock_value - b.stock_value },
            ...(canManage ? [{ title: '', width: 150, render: (_, r) => (
              <Space size={0}>
                <Button size="small" onClick={() => { af.resetFields(); af.setFieldsValue({ kind: 'waste', direction: 'plus' }); setAdj(r) }}>ضایعات / اصلاح</Button>
                <Button type="text" icon={<EditOutlined />} onClick={() => { form.setFieldsValue(r); setEdit(r) }} />
              </Space>
            ) }] : []),
          ]} />
      </Card>
      <Modal open={!!edit} title={edit?.id ? `ویرایش «${edit.name}»` : 'ماده اولیه جدید'} onCancel={() => setEdit(null)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={save}>
          <Row gutter={12}>
            <Col span={16}><Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
            <Col span={8}><Form.Item name="unit" label="واحد"><Select options={Object.entries(UNITS).map(([k, v]) => ({ value: k, label: v }))} /></Form.Item></Col>
            <Col span={12}><Form.Item name="category" label="دسته"><Select showSearch allowClear mode="tags" maxCount={1} options={cats.map((c) => ({ value: c, label: c }))} onChange={(v) => form.setFieldValue('category', Array.isArray(v) ? v[v.length - 1] : v)} /></Form.Item></Col>
            <Col span={12}><Form.Item name="min_stock" label="حداقل موجودی (هشدار)"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={12}><Form.Item name="cost_per_unit" label="بهای هر واحد (تومان)"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
            {!edit?.id && <Col span={12}><Form.Item name="opening_stock" label="موجودی اولیه"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>}
          </Row>
          <Divider orientation="right" plain style={{ margin: '4px 0 12px' }}>واحدهای خرید</Divider>
          <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 8 }}>اگر این ماده را به صورت کارتن، بسته یا گالن می‌خرید، اینجا تعریف کنید تا در فاکتور خرید همان واحد را بنویسید؛ موجودی و بها همچنان با واحد اصلی حساب می‌شود. (گرم↔کیلوگرم و میلی‌لیتر↔لیتر خودکار است.)</Typography.Paragraph>
          <Form.List name="purchase_units">
            {(fields, { add, remove }) => (
              <>
                {fields.map((f) => (
                  <Space key={f.key} align="baseline" wrap>
                    <span>هر</span>
                    <Form.Item name={[f.name, 'name']} rules={[{ required: true, whitespace: true, message: 'نام واحد' }]}><Input className="pu-name" placeholder="مثلاً کارتن" maxLength={20} style={{ width: 130 }} /></Form.Item>
                    <span>=</span>
                    <Form.Item noStyle shouldUpdate={(a, b) => a.unit !== b.unit}>{() => (
                      <Form.Item name={[f.name, 'factor']} rules={[{ required: true, message: 'مقدار' }]}><InputNumber className="pu-factor" min={0.001} max={1000000} addonAfter={UNITS[form.getFieldValue('unit')]} style={{ width: 190 }} /></Form.Item>
                    )}</Form.Item>
                    <DeleteOutlined onClick={() => remove(f.name)} style={{ color: 'var(--red)' }} />
                  </Space>
                ))}
                {fields.length < 10 && <Button type="dashed" size="small" icon={<PlusOutlined />} onClick={() => add({})}>افزودن واحد خرید</Button>}
              </>
            )}
          </Form.List>
          {edit?.id && <div style={{ marginTop: 10 }}><Typography.Text type="secondary">برای افزایش موجودی، فاکتور خرید ثبت کنید تا بهای میانگین به‌روز شود.</Typography.Text></div>}
        </Form>
      </Modal>
      <Modal open={!!adj} title={`ثبت برای «${adj?.name}»`} onCancel={() => setAdj(null)} onOk={() => af.submit()} destroyOnClose>
        <Form form={af} layout="vertical" onFinish={saveAdj}>
          <Form.Item name="kind"><Segmented block options={[{ value: 'waste', label: 'ضایعات / دورریز' }, { value: 'adjust', label: 'اصلاح موجودی' }]} /></Form.Item>
          <Form.Item noStyle shouldUpdate>{() => af.getFieldValue('kind') === 'adjust' && (
            <Form.Item name="direction"><Segmented options={[{ value: 'plus', label: 'افزایش' }, { value: 'minus', label: 'کاهش' }]} /></Form.Item>
          )}</Form.Item>
          <Form.Item name="qty" label={`مقدار (${UNITS[adj?.unit] || ''})`} rules={[{ required: true }]}><InputNumber min={0.001} style={{ width: '100%' }} /></Form.Item>
          <Form.Item name="note" label="توضیح"><Input placeholder="مثلاً: تاریخ گذشته، ریختن، شکستن" /></Form.Item>
        </Form>
      </Modal>
    </div>
  )
}
