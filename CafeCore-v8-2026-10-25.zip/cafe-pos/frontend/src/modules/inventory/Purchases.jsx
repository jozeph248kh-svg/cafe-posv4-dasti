import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, Form, Input, InputNumber, Modal, Row, Select, Space, Table, Tabs, Typography } from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { useState } from 'react'
import { PageHeader } from '../../components/common'
import { post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { UNITS, businessToday, faDate, isoDate, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

function PurchaseForm({ open, onClose, onDone, suppliers, ingredients }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const ingMap = Object.fromEntries(ingredients.map((i) => [i.id, i]))
  const submit = async (v) => {
    setBusy(true)
    try {
      await post('/inventory/purchases', { ...v, purchase_date: isoDate(v.purchase_date.toDate()), lines: v.lines.map((l) => ({ ingredient_id: l.ingredient_id, qty: l.qty, total: Math.round(l.total), purchase_unit: l.purchase_unit || null })) })
      message.success('فاکتور خرید ثبت و موجودی انبار افزایش یافت'); form.resetFields(); onDone()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open={open} title="ثبت فاکتور خرید" width={760} onCancel={onClose} onOk={() => form.submit()} confirmLoading={busy} okText="ثبت فاکتور" destroyOnClose>
      <JalaliLocaleListener />
      <Form form={form} layout="vertical" onFinish={submit} initialValues={{ purchase_date: dayjs(businessToday()), lines: [{}] }}>
        <Row gutter={12}>
          <Col span={10}><Form.Item name="supplier_id" label="تأمین‌کننده"><Select allowClear showSearch optionFilterProp="label" options={suppliers.map((s) => ({ value: s.id, label: s.name }))} /></Form.Item></Col>
          <Col span={7}><Form.Item name="invoice_no" label="شماره فاکتور"><Input /></Form.Item></Col>
          <Col span={7}><Form.Item name="purchase_date" label="تاریخ" rules={[{ required: true }]}><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" /></Form.Item></Col>
        </Row>
        <Form.List name="lines">
          {(fields, { add, remove }) => (
            <>
              {fields.map((f) => (
                <Form.Item key={f.key} noStyle shouldUpdate>{() => {
                  const ing = ingMap[form.getFieldValue(['lines', f.name, 'ingredient_id'])]
                  const qty = form.getFieldValue(['lines', f.name, 'qty'])
                  const total = form.getFieldValue(['lines', f.name, 'total'])
                  const opts = ing?.unit_options || (ing ? [{ name: UNITS[ing.unit], factor: 1 }] : [])
                  const pu = opts.find((o) => o.name === form.getFieldValue(['lines', f.name, 'purchase_unit'])) || opts[0]
                  return (
                    <Space align="baseline" wrap style={{ display: 'flex' }}>
                      <Form.Item name={[f.name, 'ingredient_id']} rules={[{ required: true, message: 'انتخاب' }]}><Select showSearch optionFilterProp="label" placeholder="ماده اولیه" style={{ width: 200 }} options={ingredients.map((i) => ({ value: i.id, label: i.name }))}
                        onChange={() => form.setFieldValue(['lines', f.name, 'purchase_unit'], undefined)} /></Form.Item>
                      <Form.Item name={[f.name, 'qty']} rules={[{ required: true, message: 'مقدار' }]}><InputNumber min={0.001} placeholder="مقدار" style={{ width: 110 }} /></Form.Item>
                      <Form.Item name={[f.name, 'purchase_unit']}><Select className="pu-select" placeholder={ing ? UNITS[ing.unit] : 'واحد'} disabled={!ing} style={{ width: 120 }} popupMatchSelectWidth={false}
                        options={opts.map((o) => ({ value: o.base ? '' : o.name, label: o.name }))} /></Form.Item>
                      <Form.Item name={[f.name, 'total']} rules={[{ required: true, message: 'مبلغ' }]}><InputNumber min={0} placeholder="مبلغ کل ردیف" formatter={moneyFormatter} parser={moneyParser} style={{ width: 160 }} /></Form.Item>
                      {qty > 0 && total > 0 && <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                        {money(total / qty)} / {pu?.name}
                        {pu && pu.factor !== 1 && <> — {num(qty * pu.factor, 2)} {UNITS[ing.unit]} به انبار</>}
                      </Typography.Text>}
                      {fields.length > 1 && <DeleteOutlined onClick={() => remove(f.name)} style={{ color: 'var(--red)' }} />}
                    </Space>
                  )
                }}</Form.Item>
              ))}
              <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({})}>افزودن ردیف</Button>
            </>
          )}
        </Form.List>
        <Form.Item noStyle shouldUpdate>{() => <Typography.Title level={5} style={{ marginTop: 14 }}>جمع فاکتور: {money((form.getFieldValue('lines') || []).reduce((a, l) => a + (l?.total || 0), 0))} تومان</Typography.Title>}</Form.Item>
        <Form.Item name="note" label="توضیحات"><Input /></Form.Item>
      </Form>
    </Modal>
  )
}

export default function Purchases() {
  const auth = useAuth()
  const { message } = App.useApp()
  const purchases = useFetch('/inventory/purchases')
  const suppliers = useFetch('/inventory/suppliers')
  const ingredients = useFetch('/inventory/ingredients')
  const [open, setOpen] = useState(false)
  const [sup, setSup] = useState(null)
  const [sf] = Form.useForm()
  const canManage = auth.can('inventory.manage')

  const saveSup = async (v) => {
    try {
      if (sup.id) await put(`/inventory/suppliers/${sup.id}`, { ...v, is_active: true }); else await post('/inventory/suppliers', v)
      message.success('ذخیره شد'); setSup(null); suppliers.reload()
    } catch (e) { message.error(e.message) }
  }
  return (
    <div className="fade-in">
      <PageHeader title="خرید و تأمین‌کنندگان" subtitle="ثبت فاکتور خرید موجودی را افزایش داده و بهای میانگین موزون را به‌روز می‌کند"
        extra={canManage && <Button type="primary" icon={<PlusOutlined />} onClick={() => setOpen(true)}>فاکتور خرید جدید</Button>} />
      <Card className="card-r">
        <Tabs items={[
          {
            key: 'p', label: 'فاکتورهای خرید', children: (
              <Table rowKey="id" loading={purchases.loading} dataSource={purchases.data || []} scroll={{ x: 700 }}
                expandable={{ expandedRowRender: (p) => (
                  <Table size="small" rowKey="ingredient_id" pagination={false} dataSource={p.lines}
                    columns={[{ title: 'ماده', dataIndex: 'name' }, { title: 'مقدار', render: (_, l) => (l.purchase_unit ? <span>{num(l.pu_qty, 2)} {l.purchase_unit} <Typography.Text type="secondary" style={{ fontSize: 12 }}>({num(l.qty, 2)} {UNITS[l.unit]})</Typography.Text></span> : `${num(l.qty, 2)} ${UNITS[l.unit]}`) }, { title: 'فی', dataIndex: 'unit_cost', render: (v, l) => (l.purchase_unit ? `${money(l.pu_price)} / ${l.purchase_unit}` : money(v)) }, { title: 'جمع', dataIndex: 'total', render: money }]} />
                ) }}
                columns={[
                  { title: 'تاریخ', dataIndex: 'purchase_date', render: faDate },
                  { title: 'تأمین‌کننده', dataIndex: 'supplier_name', render: (v) => v || '—' },
                  { title: 'شماره فاکتور', dataIndex: 'invoice_no', render: (v) => v || '—' },
                  { title: 'اقلام', render: (_, p) => p.lines.map((l) => l.name).join('، '), ellipsis: true },
                  { title: 'مبلغ', dataIndex: 'total', render: (v) => <b>{money(v)}</b> },
                ]} />
            ),
          },
          {
            key: 's', label: 'تأمین‌کنندگان', children: (
              <>
                {canManage && <Button icon={<PlusOutlined />} style={{ marginBottom: 12 }} onClick={() => { sf.resetFields(); setSup({}) }}>تأمین‌کننده جدید</Button>}
                <Table rowKey="id" loading={suppliers.loading} dataSource={suppliers.data || []} pagination={false}
                  columns={[
                    { title: 'نام', dataIndex: 'name', render: (v) => <b>{v}</b> },
                    { title: 'تلفن', dataIndex: 'phone', render: (v) => <span className="ltr">{v}</span> },
                    { title: 'توضیحات', dataIndex: 'note' },
                    { title: '', render: (_, s) => canManage && <Button type="text" icon={<EditOutlined />} onClick={() => { sf.setFieldsValue(s); setSup(s) }} /> },
                  ]} />
              </>
            ),
          },
        ]} />
      </Card>
      {open && <PurchaseForm open={open} onClose={() => setOpen(false)} onDone={() => { setOpen(false); purchases.reload(); ingredients.reload() }} suppliers={suppliers.data || []} ingredients={(ingredients.data || []).filter((i) => i.is_active)} />}
      <Modal open={!!sup} title="تأمین‌کننده" onCancel={() => setSup(null)} onOk={() => sf.submit()} destroyOnClose>
        <Form form={sf} layout="vertical" onFinish={saveSup}>
          <Form.Item name="name" label="نام" rules={[{ required: true, min: 2 }]}><Input /></Form.Item>
          <Form.Item name="phone" label="تلفن"><Input className="ltr" /></Form.Item>
          <Form.Item name="note" label="توضیحات"><Input.TextArea rows={2} /></Form.Item>
        </Form>
      </Modal>
    </div>
  )
}
