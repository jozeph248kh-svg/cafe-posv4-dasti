import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * Inventory screens: purchases (what we buy), stock count (what we count), movements (what happened),
 * recipe editor (what a dish costs) and the food-cost report. Together they decide the cost of every
 * plate, so the numbers on screen are pinned to the server payload.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online' }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const page = (Comp) => render(<App><Comp /></App>)

const PURCHASES = {
  total: 4_250_000,
  items: [
    { id: 1, purchase_date: '2026-10-22', supplier_name: 'لبنیات ونک', total: 3_000_000, paid: true, lines: [{ id: 1, name: 'شیر', qty: 40, unit: 'l', unit_cost: 45_000, total: 1_800_000 }] },
    { id: 2, purchase_date: '2026-10-23', supplier_name: 'قهوه ایران', total: 1_250_000, paid: false, lines: [{ id: 2, name: 'دانه قهوه', qty: 1, unit: 'kg', unit_cost: 1_250_000, total: 1_250_000 }] },
  ],
}
const MOVEMENTS = [
  { id: 1, ingredient: 'شیر', name: 'شیر', kind: 'sale', qty: -0.2, balance: 39.8, unit: 'l', note: 'سفارش #41', created_at: '2026-10-23T19:00:00' },
  { id: 2, ingredient: 'شیر', name: 'شیر', kind: 'purchase', qty: 40, balance: 40, unit: 'l', note: 'خرید', created_at: '2026-10-22T09:00:00' },
  { id: 3, ingredient: 'شیر', name: 'شیر', kind: 'waste', qty: -0.5, balance: 39.5, unit: 'l', note: 'شکستن بطری', created_at: '2026-10-23T12:00:00' },
]
const COUNT = {
  items: [
    { id: 1, name: 'شیر', unit: 'l', stock: 39.8, is_active: true, cost_per_unit: 45_000, counted: null },
    { id: 2, name: 'دانه قهوه', unit: 'kg', stock: 8, is_active: true, cost_per_unit: 1_200_000, counted: null },
  ],
}
const FOOD_COST = {
  rows: [
    { id: 11, name: 'اسپرسو', category: 'قهوه', price: 140_000, cost: 42_000, profit: 98_000, food_cost_pct: 30.0, has_recipe: true, qty: 90 },
    { id: 12, name: 'چیزکیک', category: 'کیک', price: 200_000, cost: 90_000, profit: 110_000, food_cost_pct: 45.0, has_recipe: true, qty: 20 },
  ],
  summary: { avg_pct: 34.5, total_cost: 3_400_000, no_recipe: 3 },
}

const respond = () => get.mockImplementation((path) => {
  if (path === '/inventory/purchases') return Promise.resolve(PURCHASES.items)   // the screen reads a list
  if (path === '/inventory/movements') return Promise.resolve(MOVEMENTS)
  if (path === '/inventory/food-cost') return Promise.resolve(FOOD_COST.rows)   // a flat row list; the screen averages it
  // screens that list ingredients read the flat ingredient array
  if (path === '/inventory/ingredients') return Promise.resolve(COUNT.items)
  if (path === '/inventory/suppliers') return Promise.resolve([{ id: 1, name: 'لبنیات ونک' }])
  return Promise.resolve([])
})

describe('Purchases', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('lists purchases with supplier, total and payment state', async () => {
    const { default: Purchases } = await import('./Purchases')
    page(Purchases)
    await waitFor(() => expect(get.mock.calls.length).toBeGreaterThan(0))
    await waitFor(() => expect(get.mock.calls.length).toBeGreaterThan(0))
    await waitFor(() => expect(text()).toContain('لبنیات ونک'))
    expect(text()).toContain('۳٬۰۰۰٬۰۰۰')
    expect(text()).toContain('قهوه ایران')
    expect(text()).toContain('۱٬۲۵۰٬۰۰۰')          // the second invoice
  })

  it('shows the items of a purchase in its row', async () => {
    const { default: Purchases } = await import('./Purchases')
    page(Purchases)
    await waitFor(() => expect(text()).toContain('قهوه ایران'))
    expect(text()).toContain('دانه قهوه')          // the line names are summarised in the row
  })
})

describe('Movements', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows the signed quantity, the running balance and the reason', async () => {
    const { default: Movements } = await import('./Movements')
    page(Movements)
    await waitFor(() => expect(text()).toContain('شیر'))
    expect(text()).toContain('شکستن بطری')
    expect(text()).toContain('۳۹٫۸')
  })
})

describe('StockCount', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('starts from the system stock and lets the counter type what is on the shelf', async () => {
    const { default: StockCount } = await import('./StockCount')
    page(StockCount)
    await waitFor(() => expect(text()).toContain('شیر'))
    const input = document.querySelector('.ant-table-tbody input')
    fireEvent.change(input, { target: { value: '38' } })
    await waitFor(() => expect(text()).toMatch(/۱٫۸|مغایرت/))
  })

  it('sends the counted quantities on save', async () => {
    post.mockResolvedValue({})
    const { default: StockCount } = await import('./StockCount')
    page(StockCount)
    await waitFor(() => expect(text()).toContain('شیر'))
    const input = document.querySelector('.ant-table-tbody input')
    fireEvent.change(input, { target: { value: '38' } })
    const save = [...document.querySelectorAll('button')].find((b) => /ثبت شمارش/.test(b.textContent))
    await waitFor(() => expect(save.disabled).toBe(false))
    fireEvent.click(save)
    // submitting asks for confirmation first (it corrects stock for the whole count)
    await waitFor(() => expect(document.querySelector('.ant-modal-confirm')).toBeTruthy())
    const confirm = [...document.querySelectorAll('.ant-modal-confirm button')].find((b) => /ثبت/.test(b.textContent))
    fireEvent.click(confirm)
    await waitFor(() => expect(post).toHaveBeenCalledWith('/inventory/stock-count', expect.any(Array)))
  })
})

describe('FoodCost', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows each dish’s cost percentage and flags the expensive ones', async () => {
    const { default: FoodCost } = await import('./FoodCost')
    page(FoodCost)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('۳۰٪')
    expect(text()).toContain('۴۵٪')                 // cheesecake is over the healthy range
    expect(text()).toContain('۳۷٫۵٪')               // the average of 30% and 45%
  })

  it('says how many dishes have no recipe yet (so their cost is wrong)', async () => {
    const { default: FoodCost } = await import('./FoodCost')
    page(FoodCost)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('۲')                   // both dishes have a recipe
  })
})

describe('RecipeEditor', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('lists the recipe lines of an item and its total cost', async () => {
    const { default: RecipeEditor } = await import('./RecipeEditor')
    get.mockImplementation((path) => {
      if (path === '/inventory/recipes/item/11') return Promise.resolve([{ ingredient_id: 1, qty: 0.02, unit: 'l', name: 'شیر', cost_per_unit: 45_000 }])
      if (path === '/inventory/ingredients') return Promise.resolve(COUNT.items)
      return Promise.resolve([])
    })
    render(<App><RecipeEditor itemId={11} price={140_000} onSaved={() => {}} /></App>)
    await waitFor(() => expect(get).toHaveBeenCalledWith('/inventory/recipes/item/11'))
    await waitFor(() => expect(document.body.textContent.replace(/\s+/g, ' ')).toMatch(/شیر|هزینه|مواد/))
  })
})
