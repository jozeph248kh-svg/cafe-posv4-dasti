import { SaveOutlined } from '@ant-design/icons'
import { Alert, App, Button, Card, Input, InputNumber, Space, Table, Tag, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { PageHeader } from '../../components/common'
import { post } from '../../core/api'
import { UNITS, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

export default function StockCount() {
  const { message, modal } = App.useApp()
  const { data, loading, reload } = useFetch('/inventory/ingredients')
  const [counts, setCounts] = useState({})
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)
  const list = (data || []).filter((i) => i.is_active && (!q || i.name.includes(q)))
  const changed = useMemo(() => (data || []).filter((i) => counts[i.id] !== undefined && counts[i.id] !== null && counts[i.id] !== i.stock), [data, counts])
  const variance = changed.reduce((a, i) => a + (counts[i.id] - i.stock) * i.cost_per_unit, 0)

  const submit = () => modal.confirm({
    title: 'ثبت انبارگردانی', content: `موجودی ${num(changed.length)} قلم به مقدار شمارش‌شده اصلاح می‌شود. مغایرت ریالی: ${money(variance)} تومان`, okText: 'ثبت', cancelText: 'انصراف',
    onOk: async () => {
      setBusy(true)
      try {
        await post('/inventory/stock-count', changed.map((i) => ({ ingredient_id: i.id, counted: counts[i.id] })))
        message.success('انبارگردانی ثبت شد'); setCounts({}); reload()
      } catch (e) { message.error(e.message) } finally { setBusy(false) }
    },
  })

  return (
    <div className="fade-in">
      <PageHeader title="انبارگردانی" subtitle="شمارش فیزیکی انبار و ثبت مغایرت (موجودی واقعی در برابر موجودی سیستم)"
        extra={<Button type="primary" icon={<SaveOutlined />} disabled={!changed.length} loading={busy} onClick={submit}>ثبت شمارش ({num(changed.length)} قلم)</Button>} />
      {changed.length > 0 && <Alert style={{ marginBottom: 16, borderRadius: 12 }} type={variance < 0 ? 'warning' : 'info'} showIcon message={`مغایرت فعلی: ${money(variance)} تومان (${variance < 0 ? 'کسری' : 'اضافی'} انبار)`} />}
      <Card className="card-r">
        <Input.Search placeholder="جستجو" allowClear onChange={(e) => setQ(e.target.value)} style={{ width: 240, marginBottom: 14 }} />
        <Table rowKey="id" loading={loading} dataSource={list} pagination={false} scroll={{ x: 700 }}
          columns={[
            { title: 'ماده', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> {r.category && <Tag>{r.category}</Tag>}</span> },
            { title: 'موجودی سیستم', dataIndex: 'stock', render: (v, r) => `${num(v, 2)} ${UNITS[r.unit]}` },
            { title: 'شمارش واقعی', render: (_, r) => <InputNumber min={0} value={counts[r.id]} placeholder={num(r.stock, 2)} onChange={(v) => setCounts({ ...counts, [r.id]: v })} addonAfter={UNITS[r.unit]} style={{ width: 180 }} /> },
            { title: 'مغایرت', render: (_, r) => {
              const c = counts[r.id]
              if (c === undefined || c === null) return '—'
              const d = c - r.stock
              return d === 0 ? <Tag color="green">بدون مغایرت</Tag> : <Space direction="vertical" size={0}><Tag color={d < 0 ? 'red' : 'blue'}>{d > 0 ? '+' : ''}{num(d, 2)} {UNITS[r.unit]}</Tag><Typography.Text type="secondary" style={{ fontSize: 11 }}>{money(d * r.cost_per_unit)} تومان</Typography.Text></Space>
            } },
          ]} />
      </Card>
    </div>
  )
}
