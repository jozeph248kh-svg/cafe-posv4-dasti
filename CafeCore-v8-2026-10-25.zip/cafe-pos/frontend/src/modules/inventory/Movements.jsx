import { Card, Select, Space, Table, Tag } from 'antd'
import { useState } from 'react'
import { PageHeader } from '../../components/common'
import { UNITS, faDateTime, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

export const KINDS = { purchase: ['خرید', 'green'], sale: ['فروش', 'blue'], return: ['برگشت از فروش', 'cyan'], waste: ['ضایعات', 'red'], adjust: ['اصلاح', 'orange'], opening: ['اول دوره', 'default'] }

export default function Movements() {
  const [f, setF] = useState({ limit: 500 })
  const ings = useFetch('/inventory/ingredients')
  const { data, loading } = useFetch('/inventory/movements', f)
  return (
    <div className="fade-in">
      <PageHeader title="گردش انبار" subtitle="کاردکس: همه ورود و خروج‌های مواد اولیه" />
      <Card className="card-r">
        <Space wrap style={{ marginBottom: 14 }}>
          <Select allowClear showSearch optionFilterProp="label" placeholder="ماده اولیه" style={{ width: 220 }} onChange={(v) => setF({ ...f, ingredient_id: v })} options={(ings.data || []).map((i) => ({ value: i.id, label: i.name }))} />
          <Select allowClear placeholder="نوع گردش" style={{ width: 150 }} onChange={(v) => setF({ ...f, kind: v })} options={Object.entries(KINDS).map(([k, v]) => ({ value: k, label: v[0] }))} />
        </Space>
        <Table rowKey="id" size="middle" loading={loading} dataSource={data || []} pagination={{ pageSize: 30 }} scroll={{ x: 800 }}
          columns={[
            { title: 'زمان', dataIndex: 'created_at', render: faDateTime },
            { title: 'ماده', dataIndex: 'ingredient', render: (v) => <b>{v}</b> },
            { title: 'نوع', dataIndex: 'kind', render: (k) => <Tag color={KINDS[k]?.[1]}>{KINDS[k]?.[0]}</Tag> },
            { title: 'مقدار', dataIndex: 'qty', render: (v, r) => <span className="ltr" style={{ color: v < 0 ? 'var(--red)' : 'var(--green)', fontWeight: 600 }}>{v > 0 ? '+' : ''}{num(v, 2)} {UNITS[r.unit]}</span> },
            { title: 'مانده', dataIndex: 'balance', render: (v, r) => `${num(v, 2)} ${UNITS[r.unit]}` },
            { title: 'ارزش', dataIndex: 'value', render: (v) => money(Math.abs(v)) },
            { title: 'شرح', dataIndex: 'note' },
          ]} />
      </Card>
    </div>
  )
}
