import { DeleteOutlined, PlusOutlined } from '@ant-design/icons'
import { App, Button, Empty, InputNumber, Select, Space, Spin, Table, Tag, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { get, put } from '../../core/api'
import { UNITS, money, num } from '../../core/format'

/** Edit the ingredient list (recipe) of a menu item or modifier option, with live cost calculation. */
export default function RecipeEditor({ itemId, optionId, price, onSaved, compact }) {
  const { message } = App.useApp()
  const [rows, setRows] = useState(null)
  const [ings, setIngs] = useState([])
  const [saving, setSaving] = useState(false)
  const path = itemId ? `/inventory/recipes/item/${itemId}` : `/inventory/recipes/option/${optionId}`

  useEffect(() => {
    setRows(null)
    Promise.all([get(path), get('/inventory/ingredients')]).then(([r, i]) => { setRows(r.map((x, k) => ({ ...x, key: k }))); setIngs(i.filter((x) => x.is_active)) })
      .catch((e) => message.error(e.message))
  }, [path, message])

  if (!rows) return <Spin />
  const ingMap = Object.fromEntries(ings.map((i) => [i.id, i]))
  const cost = rows.reduce((a, r) => a + (ingMap[r.ingredient_id]?.cost_per_unit || 0) * (r.qty || 0), 0)
  const set = (key, patch) => setRows(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)))
  const save = async () => {
    setSaving(true)
    try {
      await put(path, rows.filter((r) => r.ingredient_id && r.qty > 0).map(({ ingredient_id, qty }) => ({ ingredient_id, qty })))
      message.success('دستور پخت ذخیره شد'); onSaved?.()
    } catch (e) { message.error(e.message) } finally { setSaving(false) }
  }
  const pct = price ? (cost / price) * 100 : 0

  return (
    <div>
      <Table size="small" pagination={false} rowKey="key" dataSource={rows} locale={{ emptyText: <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="ماده‌ای تعریف نشده" /> }}
        columns={[
          { title: 'ماده اولیه', render: (_, r) => (
            <Select showSearch optionFilterProp="label" value={r.ingredient_id} onChange={(v) => set(r.key, { ingredient_id: v })} style={{ width: compact ? 170 : 220 }} placeholder="انتخاب"
              options={ings.map((i) => ({ value: i.id, label: i.name }))} />
          ) },
          { title: 'مقدار', render: (_, r) => <InputNumber min={0} value={r.qty} onChange={(v) => set(r.key, { qty: v })} addonAfter={UNITS[ingMap[r.ingredient_id]?.unit] || ''} style={{ width: 150 }} /> },
          { title: 'بها', render: (_, r) => money((ingMap[r.ingredient_id]?.cost_per_unit || 0) * (r.qty || 0)) },
          { title: '', width: 40, render: (_, r) => <Button type="text" danger icon={<DeleteOutlined />} onClick={() => setRows(rows.filter((x) => x.key !== r.key))} /> },
        ]} />
      <Space style={{ marginTop: 10, width: '100%', justifyContent: 'space-between' }} wrap>
        <Button icon={<PlusOutlined />} onClick={() => setRows([...rows, { key: Date.now(), ingredient_id: undefined, qty: 0 }])}>افزودن ماده</Button>
        <Space>
          <Typography.Text>بهای تمام‌شده: <b>{money(cost)}</b></Typography.Text>
          {price > 0 && <Tag color={pct > 40 ? 'red' : pct > 30 ? 'orange' : 'green'}>{num(pct, 1)}٪ قیمت فروش</Tag>}
          <Button type="primary" loading={saving} onClick={save}>ذخیره دستور پخت</Button>
        </Space>
      </Space>
    </div>
  )
}
