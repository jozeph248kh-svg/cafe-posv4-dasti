import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Stock is food cost: the value card, the low-stock warning and the signed adjustment (a "minus"
// adjustment must reach the server as a negative number, or the warehouse goes up when it went down).
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online' }))

const { default: Ingredients } = await import('./Ingredients')

const ING = [
  { id: 1, name: 'شیر', category: 'لبنیات', unit: 'l', stock: 2.5, min_stock: 10, cost_per_unit: 45_000, stock_value: 112_500, is_low: true, is_active: true },
  { id: 2, name: 'دانه قهوه', category: 'قهوه', unit: 'kg', stock: 8, min_stock: 3, cost_per_unit: 1_200_000, stock_value: 9_600_000, is_low: false, is_active: true },
  { id: 3, name: 'شکر', category: 'خشک', unit: 'kg', stock: 0, min_stock: 0, cost_per_unit: 60_000, stock_value: 0, is_low: false, is_active: false },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => (path === '/inventory/ingredients' ? Promise.resolve(ING) : Promise.resolve([])))
}
const page = () => render(<App><Ingredients /></App>)

describe('Ingredients (stock)', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('totals the warehouse value and counts the active items', async () => {
    page()
    await waitFor(() => expect(text()).toContain('ارزش کل موجودی انبار'))
    expect(text()).toContain('۹٬۷۱۲٬۵۰۰')          // 112,500 + 9,600,000
    expect(text()).toContain('۲')                   // two active items (sugar is inactive)
  })

  it('flags the item under its minimum and shows the shortage count', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیر'))
    expect(text()).toContain('کمبود')
    expect(text()).toContain('زیر حداقل موجودی')
    expect(document.querySelectorAll('.low-row').length).toBe(1)
  })

  it('hides inactive items unless the "inactive" filter is chosen', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیر'))
    expect(text()).not.toContain('شکر')
    await user().click(screen.getByText('غیرفعال'))
    await waitFor(() => expect(text()).toContain('شکر'))
    expect(text()).not.toContain('شیر')
  })

  it('filters by search text locally', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیر'))
    get.mockClear()
    await user().type(screen.getByPlaceholderText('جستجو'), 'قهوه')
    await waitFor(() => expect(text()).toContain('دانه قهوه'))
    expect(text()).not.toContain('شیر')
    expect(get).not.toHaveBeenCalled()
  })

  it('sends an "adjust minus" as a negative qty so stock goes down', async () => {
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('شیر'))
    // the row action is the labelled "waste / adjust" button (antd renders a hidden measure row first,
    // so target the first *visible* button by its label)
    const btns = await screen.findAllByText('ضایعات / اصلاح')
    await user().click(btns[0])
    const dlg = await screen.findByRole('dialog')
    await waitFor(() => expect(dlg.textContent).toContain('شیر'))
    const qty = dlg.querySelector('input[id$="qty"]') || dlg.querySelector('input')
    await user().type(qty, '5')
    await user().click(dlg.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalled())
    const [path, body] = post.mock.calls[0]
    expect(path).toBe('/inventory/ingredients/1/adjust')
    expect(body.qty).toBe(5)                        // default kind is "waste", direction "plus"
  })
})
