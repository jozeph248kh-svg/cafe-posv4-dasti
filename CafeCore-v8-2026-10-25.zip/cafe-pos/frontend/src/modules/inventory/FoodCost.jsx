import { EditOutlined } from '@ant-design/icons'
import { Card, Col, Drawer, Input, Row, Segmented, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import RecipeEditor from './RecipeEditor'

export default function FoodCost() {
  const { data, loading, reload } = useFetch('/inventory/food-cost')
  const [edit, setEdit] = useState(null)
  const [f, setF] = useState('all')
  const [q, setQ] = useState('')
  const rows = (data || []).filter((r) => (!q || r.name.includes(q)) && (f === 'all' || (f === 'none' ? !r.has_recipe : f === 'high' ? r.has_recipe && r.food_cost_pct > 35 : true)))
  const withR = (data || []).filter((r) => r.has_recipe)
  const avg = withR.length ? withR.reduce((a, r) => a + r.food_cost_pct, 0) / withR.length : 0
  return (
    <div className="fade-in">
      <PageHeader title="رسپی و بهای تمام‌شده" subtitle="دستور پخت هر آیتم، بهای مواد مصرفی و حاشیه سود" />
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={24} md={8}><StatCard title="میانگین درصد فودکاست" value={`${num(avg, 1)}٪`} icon="🥘" color={avg > 35 ? 'var(--red)' : 'var(--green)'} hint="استاندارد کافه و رستوران: ۲۵ تا ۳۵ درصد" loading={loading} /></Col>
        <Col xs={12} md={8}><StatCard title="آیتم‌های دارای رسپی" value={`${num(withR.length)} از ${num(data?.length || 0)}`} icon="📋" color="var(--blue)" loading={loading} /></Col>
        <Col xs={12} md={8}><StatCard title="فودکاست بالای ۳۵٪" value={withR.filter((r) => r.food_cost_pct > 35).length} icon="⚠️" color="var(--amber)" loading={loading} onClick={() => setF('high')} /></Col>
      </Row>
      <Card className="card-r">
        <Input.Search placeholder="جستجو" allowClear onChange={(e) => setQ(e.target.value)} style={{ width: 220, marginBottom: 14, marginLeft: 12 }} />
        <Segmented value={f} onChange={setF} options={[{ value: 'all', label: 'همه' }, { value: 'none', label: 'بدون رسپی' }, { value: 'high', label: 'فودکاست بالا' }]} />
        <Table rowKey="id" loading={loading} dataSource={rows} pagination={{ pageSize: 25 }} scroll={{ x: 760 }} onRow={(r) => ({ onClick: () => setEdit(r), style: { cursor: 'pointer' } })}
          columns={[
            { title: 'آیتم', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.category}</Typography.Text></span> },
            { title: 'قیمت فروش', dataIndex: 'price', render: money, sorter: (a, b) => a.price - b.price },
            { title: 'بهای مواد', dataIndex: 'cost', render: (v, r) => (r.has_recipe ? money(v) : <Tag>بدون رسپی</Tag>), sorter: (a, b) => a.cost - b.cost },
            { title: 'سود ناخالص', dataIndex: 'profit', render: (v, r) => (r.has_recipe ? <b style={{ color: 'var(--green)' }}>{money(v)}</b> : '—'), sorter: (a, b) => a.profit - b.profit },
            { title: 'فودکاست', dataIndex: 'food_cost_pct', sorter: (a, b) => a.food_cost_pct - b.food_cost_pct, render: (v, r) => (r.has_recipe ? <Tag color={v > 40 ? 'red' : v > 30 ? 'orange' : 'green'} style={{ minWidth: 56, textAlign: 'center' }}>{num(v, 1)}٪</Tag> : '—') },
            { title: '', width: 50, render: () => <EditOutlined /> },
          ]} />
      </Card>
      <Drawer open={!!edit} onClose={() => { setEdit(null); reload(true) }} width={Math.min(640, window.innerWidth)} title={edit && `دستور پخت «${edit.name}»`} destroyOnClose>
        {edit && (
          <>
            <Typography.Paragraph type="secondary">قیمت فروش: {money(edit.price)} تومان. مقدار هر ماده برای یک پُرس را وارد کنید.</Typography.Paragraph>
            <RecipeEditor itemId={edit.id} price={edit.price} onSaved={() => reload(true)} />
          </>
        )}
      </Drawer>
    </div>
  )
}
