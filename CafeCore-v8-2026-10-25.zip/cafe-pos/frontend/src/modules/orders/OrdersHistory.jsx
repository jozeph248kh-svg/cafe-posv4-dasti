import { EyeOutlined, PrinterOutlined, RollbackOutlined, SearchOutlined } from '@ant-design/icons'
import { App, Button, Card, Descriptions, Drawer, Input, InputNumber, Modal, Select, Space, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader } from '../../components/common'
import { get, newRequestId, post } from '../../core/api'
import { useAuth } from '../../core/auth'
import { LINE_STATUS, ORDER_TYPES, PAY_METHODS, faDateTime, modText, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { printReceipt } from '../../core/print'
import { useFetch } from '../../core/useFetch'

const STATUS = { open: ['باز', 'processing'], closed: ['بسته', 'success'], cancelled: ['لغو', 'error'] }

export default function OrdersHistory() {
  const auth = useAuth()
  const { message } = App.useApp()
  const [range, setRange] = useState(rangeOf('today'))
  const [filters, setFilters] = useState({ page: 1, size: 20 })
  const [q, setQ] = useState('')
  const [detail, setDetail] = useState(null)
  const [refund, setRefund] = useState(null)
  const [busy, setBusy] = useState(false)
  const { data, loading, reload } = useFetch('/orders', { date_from: range.from, date_to: range.to, ...filters })

  const open = async (id) => setDetail(await get(`/orders/${id}`))
  const doRefund = async () => {
    if (busy) return
    setBusy(true)
    try {
      // the request_id is fixed for this dialog: a retry after a lost response can't refund twice
      const restock = Object.entries(refund.restock || {}).filter(([, q]) => q > 0).map(([id, q]) => ({ line_id: Number(id), qty: q }))
      const o = await post(`/orders/${detail.id}/refund`, { ...refund, restock })
      setDetail(o); setRefund(null); reload(true)
      message.success('بازپرداخت ثبت شد')
    } catch (e) { if (e.code !== 'override_cancelled') message.error(e.message) } finally { setBusy(false) }
  }

  const returnable = (detail?.lines || []).filter((l) => l.status !== 'void' && l.qty > (l.returned_qty || 0))

  return (
    <div className="fade-in">
      <PageHeader title="سفارش‌ها" subtitle="تاریخچه و جزئیات همه سفارش‌ها" extra={<JalaliRange value={range} onChange={(r) => { setRange(r); setFilters({ ...filters, page: 1 }) }} />} />
      <Card className="card-r">
        <Space wrap style={{ marginBottom: 14 }}>
          <Input.Search placeholder="شماره سفارش، نام یا تلفن مشتری" allowClear prefix={<SearchOutlined />} value={q} onChange={(e) => setQ(e.target.value)}
            onSearch={(v) => setFilters({ ...filters, q: v, page: 1 })} style={{ width: 300 }} />
          <Select allowClear placeholder="وضعیت" style={{ width: 130 }} onChange={(v) => setFilters({ ...filters, status: v, page: 1 })}
            options={Object.entries(STATUS).map(([k, v]) => ({ value: k, label: v[0] }))} />
          <Select allowClear placeholder="نوع سفارش" style={{ width: 140 }} onChange={(v) => setFilters({ ...filters, type: v, page: 1 })}
            options={Object.entries(ORDER_TYPES).map(([k, v]) => ({ value: k, label: `${v.icon} ${v.label}` }))} />
        </Space>
        <Table rowKey="id" loading={loading} dataSource={data?.items || []} scroll={{ x: 900 }} onRow={(r) => ({ onClick: () => open(r.id), style: { cursor: 'pointer' } })}
          pagination={{ current: filters.page, pageSize: filters.size, total: data?.total, showSizeChanger: false, onChange: (page) => setFilters({ ...filters, page }), showTotal: (t) => `${num(t)} سفارش` }}
          columns={[
            { title: 'شماره', dataIndex: 'number', render: (v) => <b>#{num(v)}</b>, width: 80 },
            { title: 'زمان', dataIndex: 'created_at', render: faDateTime },
            { title: 'نوع', dataIndex: 'type', render: (t, r) => <span>{ORDER_TYPES[t].icon} {ORDER_TYPES[t].label}{r.table_name && ` · میز ${r.table_name}`}</span> },
            { title: 'مشتری', dataIndex: 'customer_name', render: (v) => v || '—' },
            { title: 'گارسون', dataIndex: 'waiter_name' },
            { title: 'مبلغ', dataIndex: 'total', render: (v) => <b>{money(v)}</b> },
            { title: 'وضعیت', dataIndex: 'status', render: (s) => <Tag color={STATUS[s][1]}>{STATUS[s][0]}</Tag> },
            { title: '', width: 50, render: (_, r) => <Button type="text" icon={<EyeOutlined />} onClick={(e) => { e.stopPropagation(); open(r.id) }} /> },
          ]} />
      </Card>

      <Drawer open={!!detail} onClose={() => setDetail(null)} width={Math.min(560, window.innerWidth)} title={detail && `سفارش #${num(detail.number)}`}
        extra={detail && (
          <Space>
            <Button icon={<PrinterOutlined />} onClick={() => printReceipt(detail, auth.settings, detail.status === 'closed' ? 'receipt' : 'bill')}>چاپ</Button>
            {detail.status === 'closed' && <Button danger icon={<RollbackOutlined />} onClick={() => setRefund({ method: 'cash', amount: detail.paid_amount, reason: '', request_id: newRequestId(), restock: {} })}>بازپرداخت</Button>}
          </Space>
        )}>
        {detail && (
          <>
            <Descriptions column={2} size="small" bordered>
              <Descriptions.Item label="وضعیت"><Tag color={STATUS[detail.status][1]}>{STATUS[detail.status][0]}</Tag></Descriptions.Item>
              <Descriptions.Item label="نوع">{ORDER_TYPES[detail.type].label}{detail.table_name && ` · میز ${detail.table_name}`}</Descriptions.Item>
              <Descriptions.Item label="ثبت">{faDateTime(detail.created_at)}</Descriptions.Item>
              <Descriptions.Item label="بسته شدن">{faDateTime(detail.closed_at)}</Descriptions.Item>
              <Descriptions.Item label="گارسون">{detail.waiter_name || '—'}</Descriptions.Item>
              <Descriptions.Item label="نفرات">{num(detail.guests)}</Descriptions.Item>
              {detail.customer_name && <Descriptions.Item label="مشتری" span={2}>{detail.customer_name} {detail.customer_phone}</Descriptions.Item>}
              {detail.customer_address && <Descriptions.Item label="آدرس" span={2}>{detail.customer_address}</Descriptions.Item>}
              {detail.cancel_reason && <Descriptions.Item label="دلیل لغو" span={2}>{detail.cancel_reason}</Descriptions.Item>}
            </Descriptions>
            <Table size="small" style={{ marginTop: 16 }} rowKey="id" pagination={false} dataSource={detail.lines}
              rowClassName={(l) => (l.status === 'void' ? 'low-row' : '')}
              columns={[
                { title: 'آیتم', render: (_, l) => <div><b>{num(l.qty)}× {l.name}</b>{l.modifiers?.length > 0 && <div style={{ fontSize: 12, color: 'var(--muted)' }}>{modText(l.modifiers)}</div>}{l.void_reason && <div style={{ fontSize: 12, color: 'var(--red)' }}>حذف: {l.void_reason}</div>}{l.returned_qty > 0 && <div style={{ fontSize: 12, color: 'var(--blue)' }}>↩ {num(l.returned_qty)} عدد برگشت به انبار</div>}{l.status !== 'void' && l.discount_amount > 0 && <div style={{ fontSize: 12, color: 'var(--red)' }}>تخفیف{l.discount_type === 'percent' ? ` ${num(l.discount_value)}٪` : ''}: −{money(l.discount_amount)}{l.discount_reason ? ` · ${l.discount_reason}` : ''}</div>}</div> },
                { title: 'وضعیت', dataIndex: 'status', render: (s) => <Tag color={LINE_STATUS[s].color}>{LINE_STATUS[s].label}</Tag> },
                { title: 'مبلغ', render: (_, l) => money(l.total) },
              ]} />
            <div className="op-totals" style={{ marginTop: 12, borderRadius: 12 }}>
              <div className="row"><span>جمع</span><span>{money(detail.subtotal)}</span></div>
              {detail.line_discount_amount > 0 && <div className="row discount"><span>تخفیف اقلام</span><span>−{money(detail.line_discount_amount)}</span></div>}
              {detail.discount_amount - (detail.line_discount_amount || 0) > 0 && <div className="row discount"><span>تخفیف فاکتور {detail.discount_reason && `(${detail.discount_reason})`}</span><span>−{money(detail.discount_amount - (detail.line_discount_amount || 0))}</span></div>}
              {detail.service_amount > 0 && <div className="row"><span>سرویس</span><span>{money(detail.service_amount)}</span></div>}
              {detail.tax_amount > 0 && <div className="row"><span>مالیات</span><span>{money(detail.tax_amount)}</span></div>}
              <div className="row grand"><span>مبلغ کل</span><span>{money(detail.total)}</span></div>
            </div>
            <Typography.Title level={5} style={{ marginTop: 16 }}>پرداخت‌ها</Typography.Title>
            {detail.payments.map((p) => (
              <div key={p.id} className="kpi-mini">
                <span>{PAY_METHODS[p.method]?.icon} {p.is_refund ? 'بازپرداخت ' : ''}{PAY_METHODS[p.method]?.label} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{faDateTime(p.created_at)}</Typography.Text></span>
                <b style={{ color: p.amount < 0 ? 'var(--red)' : undefined }}>{money(p.amount)}</b>
              </div>
            ))}
            {!detail.payments.length && <Typography.Text type="secondary">پرداختی ثبت نشده</Typography.Text>}
          </>
        )}
      </Drawer>

      <Modal open={!!refund} title="بازپرداخت وجه به مشتری" onCancel={() => setRefund(null)} onOk={doRefund} confirmLoading={busy} okText="ثبت بازپرداخت" okButtonProps={{ danger: true, disabled: !refund?.reason || refund.reason.length < 2 }}>
        {refund && (
          <Space direction="vertical" style={{ width: '100%' }}>
            <Select value={refund.method} onChange={(v) => setRefund({ ...refund, method: v })} style={{ width: '100%' }} options={Object.entries(PAY_METHODS).map(([k, v]) => ({ value: k, label: v.label }))} />
            <InputNumber value={refund.amount} min={1} max={detail?.paid_amount} onChange={(v) => setRefund({ ...refund, amount: v })} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" />
            <Input.TextArea placeholder="دلیل بازپرداخت" value={refund.reason} onChange={(e) => setRefund({ ...refund, reason: e.target.value })} />
            {returnable.length > 0 && (
              <div className="restock-box">
                <b>برگشت کالا به انبار <Typography.Text type="secondary" style={{ fontSize: 12, fontWeight: 400 }}>(اختیاری — فقط اقلامی که سالم پس گرفته شده‌اند)</Typography.Text></b>
                {returnable.map((l) => (
                  <div key={l.id} className="restock-row">
                    <span>{l.name}{l.modifiers?.length > 0 && <small> ({modText(l.modifiers)})</small>}</span>
                    <InputNumber size="small" min={0} max={l.qty - (l.returned_qty || 0)} value={refund.restock[l.id] || 0} style={{ width: 90 }}
                      onChange={(v) => setRefund({ ...refund, restock: { ...refund.restock, [l.id]: v || 0 } })} addonAfter={`از ${num(l.qty - (l.returned_qty || 0))}`} />
                  </div>
                ))}
              </div>
            )}
          </Space>
        )}
      </Modal>
    </div>
  )
}
