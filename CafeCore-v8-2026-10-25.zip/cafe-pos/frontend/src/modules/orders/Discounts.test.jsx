import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Discount presets: what the cashier may hand out, when, and to whom. A preset that displays the
// wrong value is money given away — so the list rendering (value/conditions/status) is pinned.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
// the preset form embeds the Jalali date picker, which cannot load under vitest (see DEVELOPMENT.md)
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})
const auth = { can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }
vi.mock('../../core/auth', () => ({ useAuth: () => auth }))

const { default: Discounts } = await import('./Discounts')

const PRESETS = [
  { id: 1, name: 'کارمندی', kind: 'percent', value: 20, scope: 'order', color: '#0ea5e9', reason_required: true, is_active: true, uses: 4 },
  { id: 2, name: 'هپی‌آور', kind: 'percent', value: 15, scope: 'order', start_time: '16:00', end_time: '19:00', weekdays: [0, 1, 2, 3, 4], auto_apply: true, is_active: true, uses: 12 },
  { id: 3, name: 'جبران تأخیر', kind: 'amount', value: 100_000, scope: 'order', max_amount: 200_000, color: '#9333ea', is_active: true, uses: 0 },
  { id: 4, name: 'مهمان مدیریت', kind: 'percent', value: 100, scope: 'both', requires_manager: true, is_active: true, uses: 1 },
  { id: 5, name: 'یکی بخر یکی ببر', kind: 'bogo', value: 100, buy_qty: 2, get_qty: 1, scope: 'order', is_active: true, uses: 3 },
  { id: 6, name: 'منوی ترکیبی', kind: 'combo', value: 350_000, scope: 'order', combo_parts: [{ qty: 1 }, { qty: 1 }, { qty: 1 }], is_active: true, uses: 0 },
  { id: 7, name: 'کد اینستاگرام', kind: 'percent', value: 10, scope: 'order', code: 'INSTA10', max_uses: 100, is_active: true, uses: 37 },
  { id: 8, name: 'تخفیف تمام‌شده', kind: 'percent', value: 30, scope: 'order', is_active: true, uses: 50, unavailable: 'ظرفیت استفاده از این تخفیف تمام شده است' },
  { id: 9, name: 'غیرفعال‌شده', kind: 'percent', value: 5, scope: 'item', is_active: false, uses: 0 },
]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = (presets = PRESETS) => {
  get.mockImplementation((path) => {
    if (path === '/orders/discounts/presets') return Promise.resolve(presets)
    if (path === '/orders/discounts/limits') return Promise.resolve({ roles: [], users: [], limits: [] })
    return Promise.resolve([])
  })
}
const page = () => render(<App><Discounts /></App>)

describe('Discount presets', () => {
  beforeEach(() => { get.mockReset(); post.mockReset() })

  it('shows a percent preset, a fixed amount and its ceiling', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('کارمندی'))
    expect(text()).toContain('۲۰٪')
    expect(text()).toContain('۱۰۰٬۰۰۰ تومان')
    expect(text()).toContain('(تا ۲۰۰٬۰۰۰)')          // the max_amount ceiling is spelled out
  })

  it('renders buy-X-get-Y and combo presets in plain words', async () => {
    respond()
    page()
    // the rows render in one pass, but under a loaded CI the table can still be filling in
    await waitFor(() => expect(text()).toContain('۲ بخر، ۱ رایگان'))
    expect(text()).toContain('۱ + ۱ + ۱ قلم به قیمت ۳۵۰٬۰۰۰ تومان')
  })

  it('shows the conditions: time window, weekdays and usage count', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('هپی‌آور'))
    expect(text()).toContain('16:00 تا 19:00')
    expect(text()).toContain('شنبه')
    expect(text()).toContain('۱۲ بار')
    expect(text()).toContain('۳۷ / ۱۰۰ بار')          // code preset usage against its cap
  })

  it('marks a manager-only preset with a lock and a code preset with its code', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('مهمان مدیریت'))
    expect(document.querySelectorAll('.anticon-lock').length).toBeGreaterThan(0)
    expect(text()).toContain('INSTA10')
  })

  it('distinguishes automatic / usable / exhausted / disabled', async () => {
    respond()
    page()
    await waitFor(() => expect(text()).toContain('هپی‌آور'))
    expect(text()).toContain('خودکار')
    expect(text()).toContain('قابل استفاده')
    expect(text()).toContain('الان قابل استفاده نیست')   // the exhausted one
    expect(text()).toContain('غیرفعال')                  // the disabled one
  })

  it('offers the common examples only while the list is empty, and posts them on request', async () => {
    respond([])
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('هنوز تخفیف آماده'))
    await user().click(screen.getByRole('button', { name: /افزودن نمونه‌های رایج/ }))
    await waitFor(() => expect(post).toHaveBeenCalledTimes(5))     // five examples
    const names = post.mock.calls.map(([, body]) => body.name)
    expect(names).toContain('هپی‌آور عصر')
    expect(names).toContain('مهمان مدیریت')
  })

  it('hides the staff-ceiling tab from a cashier without discounts.manage', async () => {
    respond()
    auth.can = () => false
    page()
    await waitFor(() => expect(text()).toContain('کارمندی'))
    const tabs = [...document.querySelectorAll('.ant-tabs-tab')].map((t) => t.textContent)
    expect(tabs).toContain('تخفیف‌ها')
    expect(tabs).not.toContain('سقف تخفیف کارکنان')
    auth.can = () => true
  })
})
