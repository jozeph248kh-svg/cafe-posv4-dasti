import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Order history is where a complaint gets investigated: find the order, open it, see the lines and
// payments. The filters must go to the server (pagination depends on it) and a row click must load
// the full order, not a cached list row.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/print', () => ({ printReceipt: vi.fn(), printHtml: vi.fn() }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: OrdersHistory } = await import('./OrdersHistory')

const PAGE = {
  total: 3,
  items: [
    { id: 41, number: 41, created_at: '2026-10-23T19:00:00', type: 'dine_in', table_name: '۳', customer_name: 'شیرین', waiter_name: 'علی', total: 480_000, paid_amount: 480_000, status: 'closed', remaining: 0 },
    { id: 42, number: 42, created_at: '2026-10-23T19:20:00', type: 'takeaway', table_name: null, customer_name: null, waiter_name: 'رضا', total: 254_000, paid_amount: 0, status: 'open', remaining: 254_000 },
    { id: 40, number: 40, created_at: '2026-10-23T18:00:00', type: 'delivery', table_name: null, customer_name: 'آرش', waiter_name: 'رضا', total: 610_000, paid_amount: 0, status: 'cancelled', remaining: 0 },
  ],
}
const DETAIL = {
  ...PAGE.items[0],
  lines: [{ id: 1, name: 'اسپرسو', qty: 2, unit_price: 140_000, total: 280_000, status: 'served', modifiers: [], returned_qty: 0 }, { id: 2, name: 'چیزکیک', qty: 1, unit_price: 200_000, total: 200_000, status: 'served', modifiers: [], returned_qty: 0 }],
  payments: [{ id: 1, method: 'card', amount: 480_000, is_refund: false, created_at: '2026-10-23T19:05:00' }],
  subtotal: 480_000, discount_amount: 0, service_amount: 0, tax_amount: 0, rounding: 0,
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/orders') return Promise.resolve(PAGE)
    if (path === '/orders/41') return Promise.resolve(DETAIL)
    return Promise.resolve([])
  })
}
const page = () => render(<App><OrdersHistory /></App>)

describe('Order history', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('lists orders with number, type, customer, waiter and amount', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    expect(text()).toContain('سالن')
    expect(text()).toContain('میز ۳')
    expect(text()).toContain('شیرین')
    expect(text()).toContain('علی')
    expect(text()).toContain('۴۸۰٬۰۰۰')
  })

  it('shows the total order count from the server', async () => {
    page()
    await waitFor(() => expect(text()).toContain('سفارش'))
    expect(text()).toContain('۳ سفارش')
  })

  it('sends the search text to the server and resets to page 1', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalled())
    get.mockClear()
    await user().type(screen.getByPlaceholderText('شماره سفارش، نام یا تلفن مشتری'), '۰۹۱۲{enter}')
    await waitFor(() => expect(get).toHaveBeenCalledWith('/orders', expect.objectContaining({ q: '۰۹۱۲', page: 1 })))
  })

  it('opens the full order (lines + payments) when a row is clicked', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    fireEvent.click(screen.getByText('#۴۱'))
    await waitFor(() => expect(get).toHaveBeenCalledWith('/orders/41'))
    await waitFor(() => expect(document.body.textContent).toContain('چیزکیک'))
  })

  it('marks an open order as still owed instead of paid', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۲'))
    expect(text()).toContain('۲۵۴٬۰۰۰')
  })
})
