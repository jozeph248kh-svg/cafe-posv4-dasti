import { DeleteOutlined, EditOutlined, LockOutlined, MinusCircleOutlined, PercentageOutlined, PlusOutlined, SaveOutlined, TeamOutlined, ThunderboltOutlined, TagOutlined } from '@ant-design/icons'
import {
  Alert, App, Button, Card, Checkbox, Col, Drawer, Empty, Form, Input, InputNumber, Popconfirm, Radio, Row, Segmented, Select, Space, Switch, Table, Tabs, Tag, Tooltip, Typography,
} from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { pickerToIso } from '../../components/JalaliRange'
import { useEffect, useState } from 'react'
import { PageHeader } from '../../components/common'
import { del, post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { ORDER_TYPES, faDate, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

const WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه']
const COLORS = ['#4f46e5', '#16a34a', '#0ea5e9', '#f59e0b', '#e11d48', '#9333ea', '#0f766e', '#64748b']   // stored with the rule (data, not theme)
const SCOPES = { order: 'کل فاکتور', item: 'تک آیتم', both: 'فاکتور و آیتم' }
const TIME = { pattern: /^([01]\d|2[0-3]):[0-5]\d$/, message: 'به شکل ۱۶:۰۰' }
const EXAMPLES = [
  { name: 'کارمندی', kind: 'percent', value: 20, scope: 'order', color: '#0ea5e9', reason_required: true },
  { name: 'هپی‌آور عصر', kind: 'percent', value: 15, scope: 'order', start_time: '16:00', end_time: '19:00', color: '#f59e0b' },
  { name: 'مهمان مدیریت', kind: 'percent', value: 100, scope: 'both', requires_manager: true, reason_required: true, color: '#e11d48' },
  { name: 'جبران تأخیر', kind: 'percent', value: 10, scope: 'order', max_amount: 200_000, color: '#9333ea' },
  { name: 'آیتم معیوب', kind: 'percent', value: 100, scope: 'item', reason_required: true, color: '#64748b' },
]

const KINDS = [{ value: 'percent', label: 'درصدی' }, { value: 'amount', label: 'مبلغ ثابت' }, { value: 'bogo', label: 'یکی بخر، یکی ببر' }, { value: 'combo', label: 'منوی ترکیبی' }]
const valueText = (p) => {
  if (p.kind === 'bogo') return `${num(p.buy_qty)} بخر، ${num(p.get_qty)} ${p.value >= 100 ? 'رایگان' : `با ${num(p.value)}٪ تخفیف`}`
  if (p.kind === 'combo') return `${(p.combo_parts || []).map((x) => num(x.qty)).join(' + ')} قلم به قیمت ${money(p.value)} تومان`
  return p.value ? (p.kind === 'percent' ? `${num(p.value)}٪` : `${money(p.value)} تومان`) : 'دلخواه (هنگام فروش)'
}
const limitText = (...a) => {
  const [pct, amount, daily, monthly] = a
  const parts = [pct != null && `${num(pct)}٪`, amount != null && `${money(amount)} تومان`, daily != null && `روزانه ${money(daily)}`, monthly != null && `ماهانه ${money(monthly)}`].filter(Boolean)
  return parts.length ? parts.join(' / ') : 'بدون سقف'
}
const modeOf = (p) => (p?.auto_apply ? 'auto' : p?.code ? 'code' : 'manual')

/** Category / item multi-select used for targets and combo parts. */
function TargetSelect({ menu, name, label, extra }) {
  return (
    <Row gutter={8}>
      <Col span={12}><Form.Item name={[...name, 'category_ids']} label={label ? `${label} — دسته‌ها` : 'دسته‌ها'} extra={extra}>
        <Select mode="multiple" allowClear placeholder="همه" optionFilterProp="label" options={(menu?.categories || []).map((c) => ({ value: c.id, label: c.name }))} />
      </Form.Item></Col>
      <Col span={12}><Form.Item name={[...name, 'item_ids']} label="یا آیتم‌ها">
        <Select mode="multiple" allowClear placeholder="—" optionFilterProp="label" options={(menu?.items || []).filter((i) => !i.code?.startsWith('__')).map((i) => ({ value: i.id, label: i.name }))} />
      </Form.Item></Col>
    </Row>
  )
}

function PresetDrawer({ open, preset, onClose, onSaved }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const { data: menu } = useFetch(open ? '/menu/full' : null)
  const kind = Form.useWatch('kind', form)
  const mode = Form.useWatch('mode', form)
  const scope = Form.useWatch('scope', form)
  const rule = kind === 'bogo' || kind === 'combo'
  useEffect(() => {
    if (open) {
      const p = preset || {}
      form.setFieldsValue({
        kind: 'percent', value: 10, scope: 'order', order_types: [], weekdays: [], requires_manager: false, reason_required: false, is_active: true,
        sort: 0, color: COLORS[0], min_subtotal: 0, buy_qty: 1, get_qty: 1, combo_parts: [{ qty: 1 }, { qty: 1 }], ...p,
        mode: modeOf(p), target: { category_ids: p.target_category_ids || [], item_ids: p.target_item_ids || [] },
        valid_from: p.valid_from ? dayjs(p.valid_from) : null, valid_to: p.valid_to ? dayjs(p.valid_to) : null,
      })
    } else form.resetFields()
  }, [open, preset, form])
  const save = async () => {
    const v = await form.validateFields()
    setBusy(true)
    try {
      const { mode: m, target, ...rest } = v
      const body = {
        ...rest, start_time: v.start_time || null, end_time: v.end_time || null, max_amount: v.max_amount || null,
        auto_apply: m === 'auto', code: m === 'code' ? v.code : null,
        requires_manager: m === 'auto' ? false : v.requires_manager, reason_required: m === 'auto' ? false : v.reason_required,
        valid_from: v.valid_from ? pickerToIso(v.valid_from) : null, valid_to: v.valid_to ? pickerToIso(v.valid_to) : null,
        max_uses: v.max_uses || null, per_customer_limit: v.per_customer_limit || null,
        target_category_ids: target?.category_ids || [], target_item_ids: target?.item_ids || [],
        combo_parts: v.kind === 'combo' ? (v.combo_parts || []).map((x) => ({ category_ids: x.category_ids || [], item_ids: x.item_ids || [], qty: x.qty || 1 })) : [],
      }
      if (preset?.id) await put(`/orders/discounts/presets/${preset.id}`, body)
      else await post('/orders/discounts/presets', body)
      message.success('ذخیره شد')
      onSaved()
    } catch (e) { if (e?.message) message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Drawer open={open} onClose={onClose} width={600} title={preset?.id ? `ویرایش «${preset.name}»` : 'تخفیف جدید'} destroyOnClose
      extra={<Button type="primary" icon={<SaveOutlined />} loading={busy} onClick={save}>ذخیره</Button>}>
      <JalaliLocaleListener />
      <Form form={form} layout="vertical" requiredMark={false}>
        <Form.Item name="name" label="نام (روی دکمه صندوق و فیش)" rules={[{ required: true, min: 2, message: 'نام را وارد کنید' }]}><Input maxLength={60} placeholder="مثلاً کارمندی، هپی‌آور، دانشجویی" /></Form.Item>
        <Form.Item name="kind" label="نوع تخفیف"><Segmented block options={KINDS} /></Form.Item>

        {!rule && <>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="value" label="مقدار" extra={mode === 'auto' ? null : '۰ = مقدار هنگام فروش وارد می‌شود'} rules={[{ required: true }]}>
                <InputNumber min={0} max={kind === 'percent' ? 100 : undefined} style={{ width: '100%' }} addonAfter={kind === 'percent' ? '٪' : 'تومان'}
                  formatter={kind === 'amount' ? moneyFormatter : undefined} parser={kind === 'amount' ? moneyParser : undefined} />
              </Form.Item>
            </Col>
            <Col span={12}>{kind === 'percent' && <Form.Item name="max_amount" label="حداکثر مبلغ تخفیف"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" placeholder="بدون سقف" /></Form.Item>}</Col>
          </Row>
          <Form.Item name="scope" label="روی"><Segmented block options={Object.entries(SCOPES).filter(([k]) => mode !== 'auto' || k !== 'both').map(([value, label]) => ({ value, label }))} /></Form.Item>
        </>}
        {kind === 'bogo' && (
          <Card size="small" title="یکی بخر، یکی ببر" style={{ marginBottom: 16 }}>
            <Row gutter={12}>
              <Col span={8}><Form.Item name="buy_qty" label="تعداد خرید" rules={[{ required: true }]}><InputNumber min={1} max={50} style={{ width: '100%' }} /></Form.Item></Col>
              <Col span={8}><Form.Item name="get_qty" label="تعداد هدیه" rules={[{ required: true }]}><InputNumber min={1} max={50} style={{ width: '100%' }} /></Form.Item></Col>
              <Col span={8}><Form.Item name="value" label="تخفیف هدیه" extra="۱۰۰ = رایگان"><InputNumber min={1} max={100} style={{ width: '100%' }} addonAfter="٪" /></Form.Item></Col>
            </Row>
            <TargetSelect menu={menu} name={['target']} label="شامل" extra="خالی = همه آیتم‌ها" />
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>از هر گروه (خرید + هدیه) قلم، ارزان‌ترین‌ها هدیه حساب می‌شوند.</Typography.Text>
          </Card>
        )}
        {kind === 'combo' && (
          <Card size="small" title="اجزای منوی ترکیبی" style={{ marginBottom: 16 }}>
            <Form.List name="combo_parts">
              {(fields, { add, remove }) => (
                <>
                  {fields.map((f, idx) => (
                    <div key={f.key} className="combo-part">
                      <Space align="start" style={{ width: '100%' }}>
                        <b className="combo-n">{num(idx + 1)}</b>
                        <div style={{ flex: 1 }}><TargetSelect menu={menu} name={[f.name]} /></div>
                        <Form.Item name={[f.name, 'qty']} label="تعداد"><InputNumber min={1} max={20} style={{ width: 72 }} /></Form.Item>
                        {fields.length > 1 && <Button type="text" danger icon={<MinusCircleOutlined />} onClick={() => remove(f.name)} style={{ marginTop: 30 }} />}
                      </Space>
                    </div>
                  ))}
                  <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({ qty: 1 })}>افزودن جزء</Button>
                </>
              )}
            </Form.List>
            <Form.Item name="value" label="قیمت منوی ترکیبی" style={{ marginTop: 12, marginBottom: 0 }} rules={[{ required: true, message: 'قیمت را وارد کنید' }]} extra="تخفیف = جمع قیمت اجزا − این قیمت (برای هر مجموعه کامل)">
              <InputNumber min={1} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" />
            </Form.Item>
          </Card>
        )}

        <Card size="small" title="نحوه اعمال" style={{ marginBottom: 16 }}>
          <Form.Item name="mode" style={{ marginBottom: 8 }}>
            <Radio.Group optionType="button" buttonStyle="solid" options={[
              { value: 'manual', label: 'انتخاب در صندوق' }, { value: 'auto', label: <><ThunderboltOutlined /> خودکار</> }, { value: 'code', label: <><TagOutlined /> با کد تخفیف</> },
            ]} />
          </Form.Item>
          <Typography.Paragraph type="secondary" style={{ fontSize: 12.5, marginBottom: 8 }}>
            {mode === 'auto' ? 'بدون دخالت صندوقدار روی سفارش‌هایی که شرایط را دارند اعمال می‌شود (مثلاً هپی‌آور). تخفیف دستی صندوقدار بر آن مقدم است و جزو سقف تخفیف صندوقدار حساب نمی‌شود.'
              : mode === 'code' ? 'مشتری کد را در سفارش آنلاین وارد می‌کند یا صندوقدار آن را در پنجره تخفیف می‌زند. کد تأیید مدیر نمی‌خواهد و از سقف صندوقدار کم نمی‌کند.'
                : 'صندوقدار آن را از پنجره تخفیف انتخاب می‌کند (تا سقف خودش؛ بیشتر از آن با رمز مدیر).'}
          </Typography.Paragraph>
          {mode === 'code' && <Form.Item name="code" label="کد" rules={[{ required: true, message: 'کد را وارد کنید' }, { pattern: /^[A-Za-z0-9_-]{3,30}$/, message: '۳ تا ۳۰ حرف/رقم لاتین' }]} style={{ marginBottom: 0 }}>
            <Input className="ltr" style={{ textTransform: 'uppercase' }} placeholder="OPEN30" maxLength={30} />
          </Form.Item>}
          {mode === 'auto' && !rule && scope === 'item' && <TargetSelect menu={menu} name={['target']} label="فقط برای" extra="خالی = همه آیتم‌ها" />}
        </Card>

        <Card size="small" title="شرایط استفاده" style={{ marginBottom: 16 }}>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="start_time" label="از ساعت" rules={[TIME]}><Input className="ltr" placeholder="16:00" maxLength={5} /></Form.Item></Col>
            <Col span={12}><Form.Item name="end_time" label="تا ساعت" rules={[TIME]}><Input className="ltr" placeholder="19:00" maxLength={5} /></Form.Item></Col>
          </Row>
          <Form.Item name="weekdays" label="روزهای هفته (خالی = همه روزها)"><Checkbox.Group options={WEEKDAYS.map((label, value) => ({ label, value }))} /></Form.Item>
          <Form.Item name="order_types" label="نوع سفارش (خالی = همه)"><Checkbox.Group options={Object.entries(ORDER_TYPES).map(([value, t]) => ({ value, label: t.label }))} /></Form.Item>
          <Row gutter={12}>
            <Col span={12}><Form.Item name="valid_from" label="معتبر از تاریخ"><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" placeholder="از امروز" /></Form.Item></Col>
            <Col span={12}><Form.Item name="valid_to" label="تا تاریخ"><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" placeholder="بدون پایان" /></Form.Item></Col>
          </Row>
          <Row gutter={12}>
            <Col span={8}><Form.Item name="min_subtotal" label="حداقل مبلغ سفارش"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
            <Col span={8}><Form.Item name="max_uses" label="حداکثر دفعات استفاده"><InputNumber min={1} style={{ width: '100%' }} placeholder="نامحدود" /></Form.Item></Col>
            <Col span={8}><Form.Item name="per_customer_limit" label="دفعات برای هر مشتری" extra="با شماره موبایل"><InputNumber min={1} style={{ width: '100%' }} placeholder="نامحدود" /></Form.Item></Col>
          </Row>
        </Card>
        {mode !== 'auto' && <>
          <Form.Item name="requires_manager" valuePropName="checked" extra="حتی اگر در سقف صندوقدار باشد، رمز مدیر لازم است"><Checkbox>فقط با تأیید مدیر <LockOutlined /></Checkbox></Form.Item>
          <Form.Item name="reason_required" valuePropName="checked" extra="مثلاً نام مهمان، شماره کارت دانشجویی یا کد پرسنلی"><Checkbox>ثبت توضیح الزامی است</Checkbox></Form.Item>
        </>}
        <Form.Item name="color" label="رنگ دکمه">
          <Segmented options={COLORS.map((c) => ({ value: c, label: <span style={{ display: 'inline-block', width: 18, height: 18, borderRadius: 6, background: c, verticalAlign: 'middle' }} /> }))} />
        </Form.Item>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="sort" label="ترتیب"><InputNumber style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={12}><Form.Item name="is_active" label="فعال" valuePropName="checked"><Switch /></Form.Item></Col>
        </Row>
      </Form>
    </Drawer>
  )
}

function Presets() {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/orders/discounts/presets', { all: true })
  const [edit, setEdit] = useState(null)
  const addExamples = async () => {
    try { for (const e of EXAMPLES) await post('/orders/discounts/presets', e); message.success('نمونه‌ها اضافه شدند'); reload() } catch (e) { message.error(e.message) }
  }
  return (
    <>
      <Space style={{ marginBottom: 12 }} wrap>
        <Button type="primary" icon={<PlusOutlined />} onClick={() => setEdit({})}>تخفیف جدید</Button>
        {data && !data.length && <Button onClick={addExamples}>افزودن نمونه‌های رایج</Button>}
      </Space>
      <Table rowKey="id" loading={loading} dataSource={data || []} pagination={false} scroll={{ x: 980 }}
        locale={{ emptyText: <Empty description="هنوز تخفیف آماده‌ای تعریف نشده؛ صندوقدار می‌تواند تخفیف دلخواه (تا سقف خودش) بدهد" /> }}
        columns={[
          { title: 'نام', dataIndex: 'name', render: (v, r) => <Space><span style={{ width: 10, height: 10, borderRadius: 3, background: r.color || COLORS[0], display: 'inline-block' }} /><b>{v}</b>{r.requires_manager && <Tooltip title="فقط با تأیید مدیر"><LockOutlined style={{ color: 'var(--amber)' }} /></Tooltip>}</Space> },
          { title: 'مقدار', render: (_, r) => <>{valueText(r)}{r.max_amount ? <Typography.Text type="secondary"> (تا {money(r.max_amount)})</Typography.Text> : null}</> },
          { title: 'روی', dataIndex: 'scope', render: (v) => SCOPES[v] },
          { title: 'اعمال', render: (_, r) => (
            <Space size={[4, 4]} wrap>
              {r.auto_apply ? <Tag color="green" icon={<ThunderboltOutlined />}>خودکار</Tag> : r.code ? <Tag color="purple" icon={<TagOutlined />} className="ltr">{r.code}</Tag> : <Tag>صندوق</Tag>}
              {(r.uses > 0 || r.max_uses) && <Tooltip title="تعداد سفارش‌هایی که از این تخفیف استفاده کرده‌اند"><Tag>{num(r.uses || 0)}{r.max_uses ? ` / ${num(r.max_uses)}` : ''} بار</Tag></Tooltip>}
            </Space>
          ) },
          { title: 'شرایط', render: (_, r) => (
            <Space size={[4, 4]} wrap>
              {r.start_time && <Tag>{r.start_time} تا {r.end_time}</Tag>}
              {r.weekdays?.length > 0 && <Tag>{r.weekdays.map((d) => WEEKDAYS[d]).join('، ')}</Tag>}
              {r.order_types?.length > 0 && <Tag>{r.order_types.map((t) => ORDER_TYPES[t]?.label).join('، ')}</Tag>}
              {r.min_subtotal > 0 && <Tag>حداقل {money(r.min_subtotal)}</Tag>}
              {(r.valid_from || r.valid_to) && <Tag>{r.valid_from ? faDate(r.valid_from) : '…'} تا {r.valid_to ? faDate(r.valid_to) : '…'}</Tag>}
              {r.per_customer_limit && <Tag>هر مشتری {num(r.per_customer_limit)} بار</Tag>}
              {r.reason_required && <Tag color="blue">توضیح الزامی</Tag>}
            </Space>
          ) },
          { title: 'وضعیت', render: (_, r) => (!r.is_active ? <Tag>غیرفعال</Tag> : r.unavailable ? <Tooltip title={r.unavailable}><Tag color="orange">الان قابل استفاده نیست</Tag></Tooltip> : <Tag color="green">قابل استفاده</Tag>) },
          { title: '', width: 100, render: (_, r) => (
            <Space size={2}>
              <Button size="small" type="text" icon={<EditOutlined />} onClick={() => setEdit(r)} />
              <Popconfirm title="این تخفیف حذف شود؟" description="سفارش‌های قبلی تغییری نمی‌کنند" okText="حذف" cancelText="انصراف" okButtonProps={{ danger: true }}
                onConfirm={async () => { try { await del(`/orders/discounts/presets/${r.id}`); reload() } catch (e) { message.error(e.message) } }}>
                <Button size="small" type="text" danger icon={<DeleteOutlined />} />
              </Popconfirm>
            </Space>
          ) },
        ]} />
      <PresetDrawer open={!!edit} preset={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); reload() }} />
    </>
  )
}

const LIMIT_FIELDS = ['max_discount_pct', 'max_discount_amount', 'max_discount_daily', 'max_discount_monthly']

function LimitEditor({ row, kind, onSaved, inherit }) {
  const { message } = App.useApp()
  const pick = (r) => Object.fromEntries(LIMIT_FIELDS.map((f) => [f, r[f]]))
  const [v, setV] = useState(pick(row))
  const [busy, setBusy] = useState(false)
  useEffect(() => { setV(pick(row)) }, [row])
  const dirty = LIMIT_FIELDS.some((f) => (v[f] ?? null) !== (row[f] ?? null))
  const set = (f) => (x) => setV({ ...v, [f]: x })
  const save = async () => {
    setBusy(true)
    try {
      await put('/orders/discounts/limits', { kind, id: row.id, ...Object.fromEntries(LIMIT_FIELDS.map((f) => [f, v[f] ?? null])) })
      message.success('سقف تخفیف ذخیره شد'); onSaved()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  const ph = inherit ? 'مثل نقش' : 'بدون سقف'
  return (
    <div className="limit-editor">
      <div><small>هر فاکتور</small>
        <Space.Compact>
          <InputNumber min={0} max={100} value={v.max_discount_pct} onChange={set('max_discount_pct')} addonAfter="٪" placeholder={ph} style={{ width: 120 }} />
          <InputNumber min={0} value={v.max_discount_amount} onChange={set('max_discount_amount')} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" placeholder={ph} style={{ width: 170 }} />
        </Space.Compact>
      </div>
      <div><small>جمع در روز</small><InputNumber min={0} value={v.max_discount_daily} onChange={set('max_discount_daily')} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" placeholder={ph} style={{ width: 170 }} /></div>
      <div><small>جمع در ماه</small><InputNumber min={0} value={v.max_discount_monthly} onChange={set('max_discount_monthly')} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" placeholder={ph} style={{ width: 170 }} /></div>
      <Button type={dirty ? 'primary' : 'default'} disabled={!dirty} loading={busy} icon={<SaveOutlined />} onClick={save}>ذخیره</Button>
    </div>
  )
}

function Limits() {
  const { data, loading, reload } = useFetch('/orders/discounts/limits')
  const roles = (data?.roles || []).filter((r) => !r.unlimited)
  return (
    <>
      <Alert type="info" showIcon style={{ marginBottom: 16 }} message="سقف تخفیف چطور کار می‌کند؟"
        description={<>
          هر کاربری که مجوز «اعمال تخفیف» دارد، تا سقف تعیین‌شده می‌تواند بدون رمز مدیر تخفیف بدهد: سقف هر فاکتور (درصد و/یا مبلغ؛ جمع تخفیف‌های دستی یک فاکتور حساب می‌شود) و در صورت نیاز سقف جمع تخفیف در روز و در ماه (شمسی).
          تخفیف‌های خودکار و کد تخفیف جزو سقف صندوقدار حساب نمی‌شوند؛ تخفیف‌هایی که مدیر با رمز تأیید کرده هم از سقف روزانه/ماهانه کم نمی‌کنند.
          بیشتر از سقف، صندوق رمز مدیر را می‌خواهد و نام تأییدکننده در رویدادها ثبت می‌شود. خالی بودن = بدون سقف. سقف شخصی (پایین) بر سقف نقش مقدم است.
          مجوز «اعمال تخفیف» را از «پرسنل و دسترسی» به نقش بدهید یا بگیرید.
        </>} />
      <Card size="small" title="سقف بر اساس نقش" style={{ marginBottom: 16 }}>
        <Table rowKey="id" size="small" loading={loading} dataSource={roles} pagination={false} scroll={{ x: 900 }}
          columns={[
            { title: 'نقش', dataIndex: 'title', render: (v, r) => <Space>{v}{!r.can_discount && <Tooltip title="این نقش مجوز «اعمال تخفیف» ندارد؛ هر تخفیفی رمز مدیر می‌خواهد"><Tag>بدون مجوز</Tag></Tooltip>}</Space> },
            { title: 'سقف تخفیف بدون تأیید مدیر', render: (_, r) => <LimitEditor row={r} kind="role" onSaved={reload} /> },
          ]} />
      </Card>
      <Card size="small" title={<><TeamOutlined /> سقف شخصی کارکنان</>}>
        <Table rowKey="id" size="small" loading={loading} dataSource={(data?.users || []).filter((u) => roles.some((r) => r.id === u.role_id))} pagination={{ pageSize: 10, hideOnSinglePage: true }} scroll={{ x: 1100 }}
          columns={[
            { title: 'نام', dataIndex: 'full_name' },
            { title: 'نقش', dataIndex: 'role_title' },
            { title: 'سقف فعلی', render: (_, r) => (r.can_discount ? <Tag color="blue">{limitText(r.effective_pct, r.effective_amount, r.effective_daily, r.effective_monthly)}</Tag> : <Tag>نیاز به رمز مدیر</Tag>) },
            { title: 'سقف شخصی (خالی = مثل نقش)', render: (_, r) => <LimitEditor row={r} kind="user" onSaved={reload} inherit /> },
          ]} />
      </Card>
    </>
  )
}

export default function Discounts() {
  const auth = useAuth()
  return (
    <>
      <PageHeader title="تخفیف‌ها" icon={<PercentageOutlined />} subtitle="تخفیف‌های صندوق، خودکار، کد تخفیف، یکی بخر یکی ببر، منوی ترکیبی و سقف تخفیف کارکنان" />
      <Card>
        <Tabs items={[
          { key: 'presets', label: 'تخفیف‌ها', children: <Presets /> },
          ...(auth.can('discounts.manage') ? [{ key: 'limits', label: 'سقف تخفیف کارکنان', children: <Limits /> }] : []),
        ]} />
      </Card>
    </>
  )
}
