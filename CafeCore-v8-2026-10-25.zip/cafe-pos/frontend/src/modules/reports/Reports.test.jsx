import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

// The sales report is the number the owner checks every night. These tests pin the KPIs to the
// server payload (no front-end re-calculation) and check that the food-cost / discount warnings fire
// where the server says they should.
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/print', () => ({ printZReport: vi.fn(), printHtml: vi.fn() }))
// charts read their palette from the theme context, which only exists inside <ThemeProvider>
vi.mock('../../core/theme', () => ({ useChart: () => ({ c: ['#111', '#222'], grid: '#eee', axis: '#999', money: '#111' }) }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})
// the insight tabs pull their own endpoints — not what this file is about
vi.mock('./Insights', () => ({
  DiscountsTab: () => <div>TAB-DISCOUNTS</div>, StaffTab: () => <div />, ShiftsTab: () => <div />,
  MenuEngineeringTab: () => <div />, ModifiersTab: () => <div />, TablesTab: () => <div />,
  KitchenTab: () => <div />, TaxTab: () => <div />, CustomersTab: () => <div />,
}))

const { default: Reports } = await import('./Reports')

const SALES = {
  range: { from: '2026-09-23', to: '2026-10-22' },
  summary: { orders: 57, gross: 12_400_000, discounts: 620_000, net: 11_780_000, avg_ticket: 206_666, voids: 2, cancelled: 1, voids_amount: 154_000, food_cost: 3_400_000, food_cost_pct: 28.9, guests: 120, refunds: 0, service: 0, tax: 1_120_000 },
  by_day: [{ date: '2026-10-21', revenue: 2_000_000, orders: 9 }, { date: '2026-10-22', revenue: 3_000_000, orders: 12 }],
  by_hour: [], heatmap: [],
  by_payment: [{ method: 'cash', amount: 6_000_000 }, { method: 'card', amount: 5_780_000 }],
  by_type: [{ type: 'dine_in', revenue: 9_000_000, orders: 40 }],
  by_waiter: [], by_category: [], by_item: [{ id: 11, name: 'اسپرسو', qty: 90, revenue: 12_600_000, cost: 3_400_000, profit: 9_200_000 }],
  voids: [],
}
const CMP = {
  current: { net: 11_780_000, orders: 57, avg_ticket: 206_666, discount_pct: 5.0, gross: 12_400_000 },
  previous: { net: 10_000_000, orders: 50, avg_ticket: 200_000, discount_pct: 2.5, gross: 10_250_000 },
  change: { net: 17.8, orders: 14.0, avg_ticket: 3.3 },
  previous_range: { from: '2026-08-24', to: '2026-09-22' },
}

const respond = (sales = SALES, cmp = CMP) => {
  get.mockImplementation((path) => {
    if (path === '/reports/sales') return Promise.resolve(sales)
    if (path === '/reports/insights/compare') return Promise.resolve(cmp)
    return Promise.resolve([])
  })
}
const page = () => render(<App><Reports /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Sales report', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows the KPIs exactly as the server computed them', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص'))
    expect(text()).toContain('۱۱٫۸ میلیون')        // big money is abbreviated on the KPI cards
    expect(text()).toContain('۵۷')                 // order count
    expect(text()).toContain('۲۰۶٬۶۶۶')           // average ticket
    expect(text()).toContain('۶۲۰٬۰۰۰')           // discounts
  })

  it('shows the percentage change against the previous period', async () => {
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص'))
    expect(text()).toContain('۱۷٫۸٪')             // net change
    expect(text()).toContain('نسبت به')
  })

  it('warns in red when discounts pass 5% of gross (the threshold the server reports)', async () => {
    page()
    await waitFor(() => expect(text()).toContain('تخفیف‌ها'))
    expect(text()).toContain('۵٪ فروش ناخالص')
  })

  it('shows food cost as a percentage with the toman amount behind it', async () => {
    page()
    await waitFor(() => expect(text()).toContain('درصد بهای مواد'))
    expect(text()).toContain('۲۸٫۹٪')
    expect(text()).toContain('میلیون')
  })

  it('counts voids and cancellations together', async () => {
    page()
    await waitFor(() => expect(text()).toContain('حذف و لغو'))
    expect(text()).toContain('۳')                 // 2 voids + 1 cancelled
  })

  it('asks for the selected range and offers the Z report', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/reports/sales', expect.objectContaining({
      date_from: expect.any(String), date_to: expect.any(String),
    })))
    expect(screen.getByRole('button', { name: /گزارش پایان روز/ })).toBeTruthy()
  })

  it('renders an empty report without crashing', async () => {
    respond({ summary: {}, by_item: [], by_day: [], by_payment: [], by_type: [], by_category: [], by_waiter: [], by_hour: [], heatmap: [], voids: [] }, { current: {}, previous: {}, change: {}, previous_range: { from: '2026-09-01', to: '2026-09-30' } })
    page()
    await waitFor(() => expect(text()).toContain('فروش خالص'))
    expect(text()).toContain('۰')
  })
})
