/**
 * Management report tabs (loaded only when opened): discounts, staff, cash reconciliation, menu engineering,
 * modifiers, tables, kitchen speed, customers and the tax ledger. Backend: /api/reports/insights/<section>.
 */
import { Alert, Card, Col, Empty, Progress, Row, Skeleton, Table, Tag, Typography } from 'antd'
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts'
import { compact, faDate, faDateTime, money, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { tooltipStyle } from '../dashboard/Dashboard'
import { useChart } from '../../core/theme'

const useSection = (section, range) => useFetch(`/reports/insights/${section}`, { date_from: range.from, date_to: range.to })
// A section that answers with a partial payload (an older server, a module that is switched off, an empty
// period) must degrade to an empty state — never take the whole Reports page down with a TypeError.
const arr = (v) => (Array.isArray(v) ? v : [])

export function Kpis({ items }) {
  return (
    <Row gutter={[12, 12]} style={{ marginBottom: 16 }}>
      {items.filter(Boolean).map(([label, value, hint, color]) => (
        <Col key={label} xs={12} md={8} xl={Math.max(4, Math.floor(24 / items.filter(Boolean).length))}>
          <div className="ins-kpi" style={{ '--c': color || 'var(--primary)' }}>
            <span>{label}</span><b>{value}</b>{hint && <small>{hint}</small>}
          </div>
        </Col>
      ))}
    </Row>
  )
}

const Loading = () => <Skeleton active paragraph={{ rows: 6 }} />
const moneyCol = (title, dataIndex, extra = {}) => ({ title, dataIndex, render: (v) => money(v), sorter: (a, b) => a[dataIndex] - b[dataIndex], ...extra })
const numCol = (title, dataIndex, digits = 0, extra = {}) => ({ title, dataIndex, render: (v) => num(v, digits), sorter: (a, b) => a[dataIndex] - b[dataIndex], ...extra })

// ---------------------------------------------------------------- discounts
const HEALTH = { ok: ['سالم', 'green', 'تخفیف‌ها در محدوده معمول (۱ تا ۳٪ فروش) است.'], warn: ['قابل توجه', 'orange', 'تخفیف‌ها بین ۳ تا ۵٪ فروش است؛ دلایل و کاربران را بررسی کنید.'], high: ['زیاد', 'red', 'تخفیف‌ها بیش از ۵٪ فروش است؛ بررسی دقیق دلایل، کاربران و تأییدکننده‌ها توصیه می‌شود.'] }

export function DiscountsTab({ range }) {
  const { data, loading } = useSection('discounts', range)
  if (loading || !data) return <Loading />
  const s = data.summary || {}
  const byItem = arr(data.by_item)
  const [hl, hc, ht] = HEALTH[s.health] || ['نامشخص', 'default', 'داده‌ای برای ارزیابی وضعیت تخفیف‌ها در این بازه نیست.']
  return (
    <>
      <Kpis items={[
        ['جمع تخفیف', money(s.total), `${num(s.pct_of_gross, 2)}٪ از فروش ناخالص`, 'var(--pal-5)'],
        ['فاکتورهای با تخفیف', num(s.orders), `${num(s.orders_pct, 1)}٪ از فاکتورها`, 'var(--primary-text)'],
        ['میانگین هر تخفیف', money(s.avg_discount), null, 'var(--amber)'],
        ['تخفیف روی آیتم‌ها', money(s.items_discount), s.comps ? `${money(s.comps)} رایگان/کامل` : null, 'var(--blue)'],
        ['با تأیید مدیر', num(s.approved_count), 'بیش از سقف کاربر', 'var(--green)'],
      ]} />
      <Alert type={s.health === 'ok' ? 'success' : s.health === 'warn' ? 'warning' : 'error'} showIcon style={{ marginBottom: 16 }}
        message={<>وضعیت تخفیف‌ها: <Tag color={hc}>{hl}</Tag></>} description={ht} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Card size="small" title="بر اساس دلیل / تخفیف آماده">
            <Table size="small" rowKey="reason" dataSource={arr(data.by_reason)} pagination={false} locale={{ emptyText: 'تخفیفی ثبت نشده' }}
              columns={[{ title: 'دلیل', dataIndex: 'reason' }, numCol('تعداد', 'count'), moneyCol('مبلغ', 'amount'),
                { title: 'سهم', dataIndex: 'share', width: 140, render: (v) => <Progress percent={v} size="small" strokeColor="var(--chart-5)" format={(p) => `${num(p, 1)}٪`} /> }]} />
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="بر اساس کاربر اعمال‌کننده" style={{ marginBottom: 16 }}>
            <Table size="small" rowKey="user" dataSource={arr(data.by_user)} pagination={false}
              columns={[{ title: 'کاربر', dataIndex: 'user' }, numCol('تعداد', 'count'), moneyCol('مبلغ', 'amount'), numCol('با تأیید مدیر', 'approved')]} />
          </Card>
          <Card size="small" title="تأییدکننده‌ها (بیش از سقف کاربر)">
            <Table size="small" rowKey="user" dataSource={arr(data.by_approver)} pagination={false} locale={{ emptyText: 'موردی نیست' }}
              columns={[{ title: 'مدیر', dataIndex: 'user' }, numCol('تعداد', 'count'), moneyCol('مبلغ', 'amount')]} />
          </Card>
        </Col>
        {byItem.length > 0 && (
          <Col xs={24} xl={10}>
            <Card size="small" title="آیتم‌های دارای تخفیف">
              <Table size="small" rowKey="name" dataSource={byItem} pagination={{ pageSize: 8, hideOnSinglePage: true }}
                columns={[{ title: 'آیتم', dataIndex: 'name' }, numCol('دفعات', 'count'), numCol('تعداد', 'qty'), moneyCol('مبلغ', 'amount')]} />
            </Card>
          </Col>
        )}
        <Col xs={24} xl={byItem.length ? 14 : 24}>
          <Card size="small" title="فاکتورهای با تخفیف (بیشترین مبلغ)">
            <Table size="small" rowKey="id" dataSource={arr(data.orders)} pagination={{ pageSize: 10, showSizeChanger: false }} scroll={{ x: 760 }}
              columns={[
                { title: 'سفارش', dataIndex: 'number', render: (v, r) => <span>#{num(v)} <Typography.Text type="secondary" style={{ fontSize: 12 }}>{faDate(r.date)}</Typography.Text></span> },
                moneyCol('جمع اقلام', 'subtotal'), moneyCol('تخفیف', 'discount', { render: (v) => <b style={{ color: 'var(--red)' }}>{money(v)}</b> }),
                { title: '٪', dataIndex: 'pct', render: (v) => <Tag color={v > 30 ? 'red' : v > 15 ? 'orange' : 'default'}>{num(v, 1)}٪</Tag>, sorter: (a, b) => a.pct - b.pct },
                { title: 'دلیل', dataIndex: 'reason', ellipsis: true },
                { title: 'اعمال / تأیید', render: (_, r) => <span>{r.by || '—'}{r.approver && <Typography.Text type="secondary" style={{ fontSize: 12 }}> ✓ {r.approver}</Typography.Text>}</span> },
              ]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}

// ---------------------------------------------------------------- staff
export function StaffTab({ range }) {
  const { data, loading } = useSection('staff', range)
  if (loading || !data) return <Loading />
  const rows = arr(data.rows)
  const total = rows.reduce((a, r) => a + (r.revenue || 0), 0) || 1
  return (
    <Table rowKey={(r) => r.id ?? 'none'} dataSource={rows} pagination={false} scroll={{ x: 980 }}
      columns={[
        { title: 'نام', dataIndex: 'name', fixed: 'right', render: (v, _, i) => <span><span className={`rank r${i + 1}`}>{num(i + 1)}</span>{v}</span> },
        numCol('سفارش', 'orders'), moneyCol('فروش', 'revenue'),
        { title: 'سهم', render: (_, r) => `${num((r.revenue / total) * 100, 1)}٪` },
        moneyCol('میانگین فاکتور', 'avg_check'), numCol('آیتم در هر سفارش', 'items_per_order', 1), numCol('مهمان', 'guests'),
        { title: 'تخفیف داده‌شده', dataIndex: 'discounts', sorter: (a, b) => a.discounts - b.discounts,
          render: (v, r) => (v ? <span>{money(v)} <Tag color={r.discount_pct > 5 ? 'red' : r.discount_pct > 3 ? 'orange' : 'default'}>{num(r.discount_pct, 1)}٪</Tag></span> : '—') },
        { title: 'حذف آیتم', dataIndex: 'voids', sorter: (a, b) => a.voids - b.voids, render: (v, r) => (v ? `${num(v)} (${money(r.void_amount)})` : '—') },
      ]} />
  )
}

// ---------------------------------------------------------------- shifts
export function ShiftsTab({ range }) {
  const { data, loading } = useSection('shifts', range)
  if (loading || !data) return <Loading />
  if (!data.available) return <Empty description="ماژول شیفت فعال نیست" />
  const s = data.summary || {}
  const diff = (v) => <b style={{ color: v < 0 ? 'var(--red)' : v > 0 ? 'var(--amber)' : 'var(--green)' }}>{v ? (v > 0 ? '+' : '−') + money(Math.abs(v)) : 'بدون مغایرت'}</b>
  return (
    <>
      <Kpis items={[
        ['شیفت بسته‌شده', num(s.shifts), `${num(s.with_difference)} شیفت با مغایرت`, 'var(--primary-text)'],
        ['کسری نقدی', money(s.short), null, 'var(--red)'], ['اضافه نقدی', money(s.over), null, 'var(--amber)'],
        ['مغایرت خالص', (s.net > 0 ? '+' : s.net < 0 ? '−' : '') + money(Math.abs(s.net)), null, s.net < 0 ? 'var(--red)' : 'var(--green)'],
      ]} />
      {arr(data.by_cashier).length > 0 && (
        <Card size="small" title="خلاصه بر اساس صندوقدار (بستن شیفت)" style={{ marginBottom: 16 }}>
          <Table size="small" rowKey="name" dataSource={arr(data.by_cashier)} pagination={false}
            columns={[{ title: 'صندوقدار', dataIndex: 'name' }, numCol('شیفت', 'shifts'), moneyCol('فروش', 'sales'), moneyCol('کسری', 'short'), moneyCol('اضافه', 'over'),
              { title: 'خالص', dataIndex: 'net', render: diff }]} />
        </Card>
      )}
      <Table size="small" rowKey="id" dataSource={arr(data.rows)} pagination={{ pageSize: 15, hideOnSinglePage: true }} scroll={{ x: 980 }} locale={{ emptyText: 'شیفت بسته‌شده‌ای در این بازه نیست' }}
        columns={[
          { title: 'بسته شده', dataIndex: 'closed_at', render: faDateTime }, { title: 'صندوقدار', dataIndex: 'closed_by' },
          moneyCol('موجودی اول', 'opening_cash'), moneyCol('فروش شیفت', 'sales'), moneyCol('نقد مورد انتظار', 'expected'), moneyCol('شمارش‌شده', 'counted'),
          { title: 'مغایرت', dataIndex: 'difference', render: diff, sorter: (a, b) => a.difference - b.difference }, { title: 'توضیح', dataIndex: 'note', ellipsis: true },
        ]} />
    </>
  )
}

// ---------------------------------------------------------------- menu engineering
const CLASS_COLOR = { star: 'var(--green)', plowhorse: 'var(--amber)', puzzle: 'var(--primary-text)', dog: 'var(--red)' }
const CLASS_CHART = { star: 'green', plowhorse: 'amber', puzzle: 'accent', dog: 'red' }
const CLASS_ICON = { star: '⭐', plowhorse: '🐴', puzzle: '🧩', dog: '⚠️' }

export function MenuEngineeringTab({ range }) {
  const ch = useChart()
  const { data, loading } = useSection('menu', range)
  if (loading || !data) return <Loading />
  if (!arr(data.rows).length) return <Empty description="فروشی در این بازه نیست" />
  return (
    <>
      {!data.has_costs && <Alert type="warning" showIcon style={{ marginBottom: 16 }} message="برای آیتم‌ها رسپی/بهای تمام‌شده ثبت نشده" description="حاشیه سود با فرض بهای صفر حساب شده؛ برای نتیجه دقیق، از «رسپی و بهای تمام‌شده» رسپی آیتم‌ها را وارد کنید." />}
      <Row gutter={[12, 12]} style={{ marginBottom: 16 }}>
        {arr(data.classes).map((c) => (
          <Col key={c.key} xs={12} xl={6}>
            <div className="ins-class" style={{ '--c': CLASS_COLOR[c.key] }}>
              <div><span>{CLASS_ICON[c.key]}</span><b>{c.label}</b><Tag color={CLASS_COLOR[c.key]}>{num(c.count)} آیتم</Tag></div>
              <small>{c.hint}</small>
            </div>
          </Col>
        ))}
      </Row>
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={10}>
          <Card size="small" title="ماتریس منو (محبوبیت × حاشیه سود)">
            <ResponsiveContainer width="100%" height={340}>
              <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis type="number" dataKey="mix_pct" name="سهم فروش" unit="٪" reversed tick={{ fontSize: 11 }} tickFormatter={(v) => num(v, 1)} />
                <YAxis type="number" dataKey="cm" name="حاشیه سود" orientation="right" width={64} tick={{ fontSize: 11 }} tickFormatter={compact} />
                <ZAxis range={[60, 60]} />
                <ReferenceLine x={data.popularity_threshold} stroke={ch.faint} strokeDasharray="4 4" />
                <ReferenceLine y={data.avg_cm} stroke={ch.faint} strokeDasharray="4 4" />
                <Tooltip contentStyle={tooltipStyle} content={({ payload }) => {
                  const p = payload?.[0]?.payload
                  return p ? <div style={{ ...tooltipStyle, padding: 8 }}><b>{p.name}</b><div>{p.class_label} · سهم {num(p.mix_pct, 1)}٪ · حاشیه {money(p.cm)}</div></div> : null
                }} />
                <Scatter data={arr(data.rows)}>{arr(data.rows).map((r) => <Cell key={r.id} fill={ch[CLASS_CHART[r.class]]} />)}</Scatter>
              </ScatterChart>
            </ResponsiveContainer>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              خط عمودی: آستانه محبوبیت ({num(data.popularity_threshold, 2)}٪ = ۷۰٪ سهم مساوی) · خط افقی: میانگین وزنی حاشیه سود ({money(data.avg_cm)} تومان)
            </Typography.Text>
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          <Table size="small" rowKey="id" dataSource={data.rows} pagination={{ pageSize: 12, showSizeChanger: false }} scroll={{ x: 760 }}
            columns={[
              { title: 'آیتم', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.category}</Typography.Text></span> },
              { title: 'گروه', dataIndex: 'class', render: (v, r) => <Tag color={CLASS_COLOR[v]}>{CLASS_ICON[v]} {r.class_label}</Tag>,
                filters: arr(data.classes).map((c) => ({ value: c.key, text: c.label })), onFilter: (v, r) => r.class === v },
              numCol('تعداد', 'qty'), numCol('سهم ٪', 'mix_pct', 1), moneyCol('حاشیه واحد', 'cm'), moneyCol('حاشیه کل', 'total_cm'),
              { title: 'بهای مواد', dataIndex: 'cost_pct', render: (v, r) => (r.unit_cost ? <Tag color={v > 40 ? 'red' : v > 30 ? 'orange' : 'green'}>{num(v, 1)}٪</Tag> : '—') },
            ]} />
        </Col>
      </Row>
      {arr(data.unsold).length > 0 && (
        <Card size="small" title={`آیتم‌های فعال بدون فروش در این بازه (${num(arr(data.unsold).length)})`} style={{ marginTop: 16 }}>
          {arr(data.unsold).map((u) => <Tag key={u.id} style={{ marginBottom: 6 }}>{u.name} · {u.category}</Tag>)}
        </Card>
      )}
    </>
  )
}

// ---------------------------------------------------------------- modifiers
export function ModifiersTab({ range }) {
  const { data, loading } = useSection('modifiers', range)
  if (loading || !data) return <Loading />
  return (
    <>
      <Kpis items={[['فروش افزودنی‌ها', money(data.revenue), 'درآمد اضافه از انتخاب‌های پولی', 'var(--pal-7)'], ['تعداد نوع افزودنی', num(arr(data.rows).length), null, 'var(--pal-1)']]} />
      <Table size="small" rowKey="name" dataSource={arr(data.rows)} pagination={{ pageSize: 15, hideOnSinglePage: true }} locale={{ emptyText: 'افزودنی‌ای فروخته نشده' }}
        columns={[{ title: 'افزودنی / انتخاب', dataIndex: 'name' }, numCol('دفعات', 'count'), moneyCol('فروش', 'revenue'), { title: 'بیشتر روی', dataIndex: 'top_items', ellipsis: true }]} />
    </>
  )
}

// ---------------------------------------------------------------- tables
export function TablesTab({ range }) {
  const { data, loading } = useSection('tables', range)
  if (loading || !data) return <Loading />
  if (!data.available) return <Empty description="ماژول سالن فعال نیست" />
  const s = data.summary || {}
  return (
    <>
      <Kpis items={[
        ['فروش سالن', money(s.revenue), `${num(s.orders)} سفارش`, 'var(--primary-text)'], ['سرانه هر مهمان', money(s.per_guest), `${num(s.guests)} مهمان`, 'var(--green)'],
        ['میانگین مدت نشستن', `${num(s.avg_minutes)} دقیقه`, null, 'var(--amber)'], ['گردش هر میز در روز', num(s.turns_per_table_day, 2), null, 'var(--blue)'],
      ]} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={9}>
          <Card size="small" title="بر اساس سالن">
            <Table size="small" rowKey="area" dataSource={arr(data.by_area)} pagination={false}
              columns={[{ title: 'سالن', dataIndex: 'area' }, numCol('میز', 'tables'), numCol('سفارش', 'orders'), moneyCol('فروش', 'revenue'), moneyCol('سرانه', 'per_guest')]} />
          </Card>
        </Col>
        <Col xs={24} xl={15}>
          <Table size="small" rowKey="id" dataSource={arr(data.rows)} pagination={{ pageSize: 12, hideOnSinglePage: true }} scroll={{ x: 760 }}
            columns={[
              { title: 'میز', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.area} · {num(r.seats)} نفره</Typography.Text></span> },
              numCol('سفارش', 'orders'), numCol('مهمان', 'guests'), moneyCol('فروش', 'revenue'), moneyCol('سرانه', 'per_guest'),
              { title: 'مدت (دقیقه)', dataIndex: 'avg_minutes', render: (v) => (v ? num(v) : '—'), sorter: (a, b) => a.avg_minutes - b.avg_minutes },
              numCol('گردش روزانه', 'turns_per_day', 2), moneyCol('فروش هر صندلی/روز', 'per_seat_day'),
            ]} />
        </Col>
      </Row>
    </>
  )
}

// ---------------------------------------------------------------- kitchen
export function KitchenTab({ range }) {
  const ch = useChart()
  const { data, loading } = useSection('kitchen', range)
  if (loading || !data) return <Loading />
  if (!data.available) return <Empty description="ماژول آشپزخانه فعال نیست" />
  const s = data.summary || {}
  if (!s.count) return <Empty description="در این بازه سفارشی در نمایشگر آشپزخانه «آماده» نشده است" />
  const late = (v) => <Tag color={v > 25 ? 'red' : v > 10 ? 'orange' : 'green'}>{num(v, 1)}٪</Tag>
  return (
    <>
      <Kpis items={[
        ['میانگین زمان آماده‌سازی', `${num(s.avg, 1)} دقیقه`, `از ثبت تا آماده — ${num(s.count)} برگه`, 'var(--primary-text)'],
        ['۹۰٪ سفارش‌ها زیر', `${num(s.p90, 1)} دقیقه`, null, 'var(--blue)'],
        [`دیرتر از ${num(data.late_minutes)} دقیقه`, `${num(s.late_pct, 1)}٪`, null, s.late_pct > 15 ? 'var(--red)' : 'var(--green)'],
        ['میانگین تا شروع پخت', `${num(s.avg_wait_to_start, 1)} دقیقه`, null, 'var(--amber)'],
      ]} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={10}>
          <Card size="small" title="بر اساس ایستگاه">
            <ResponsiveContainer width="100%" height={Math.max(160, arr(data.by_station).length * 54)}>
              <BarChart data={arr(data.by_station)} layout="vertical" margin={{ left: 10, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                <XAxis type="number" reversed tick={{ fontSize: 11 }} tickFormatter={(v) => num(v)} />
                <YAxis type="category" dataKey="station" orientation="right" width={110} tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v, n) => [`${num(v, 1)} دقیقه`, n]} />
                <Bar dataKey="avg" name="میانگین" fill={ch.accent} radius={[6, 0, 0, 6]} barSize={16} />
                <Bar dataKey="p90" name="۹۰٪" fill={ch.amber} radius={[6, 0, 0, 6]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
            <Table size="small" rowKey="station" dataSource={arr(data.by_station)} pagination={false}
              columns={[{ title: 'ایستگاه', dataIndex: 'station' }, numCol('برگه', 'count'), numCol('میانگین', 'avg', 1), numCol('۹۰٪', 'p90', 1), { title: 'دیرکرد', dataIndex: 'late_pct', render: late }]} />
          </Card>
        </Col>
        <Col xs={24} xl={14}>
          <Card size="small" title="کندترین آیتم‌ها">
            <Table size="small" rowKey="name" dataSource={arr(data.by_item)} pagination={{ pageSize: 12, showSizeChanger: false }}
              columns={[{ title: 'آیتم', dataIndex: 'name' }, numCol('تعداد', 'qty'), numCol('میانگین (دقیقه)', 'avg', 1), numCol('۹۰٪', 'p90', 1), { title: 'دیرکرد', dataIndex: 'late_pct', render: late, sorter: (a, b) => a.late_pct - b.late_pct }]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}

// ---------------------------------------------------------------- customers
export function CustomersTab({ range }) {
  const { data, loading } = useSection('customers', range)
  if (loading || !data) return <Loading />
  const s = data.summary || {}
  return (
    <>
      <Kpis items={[
        ['مشتری شناسایی‌شده', num(s.customers), `${num(s.identified_pct, 1)}٪ سفارش‌ها با شماره موبایل`, 'var(--primary-text)'],
        ['مشتری جدید', num(s.new), null, 'var(--green)'], ['مشتری بازگشتی', num(s.returning), `${num(s.repeat_customers)} نفر بیش از یک خرید در بازه`, 'var(--amber)'],
        ['میانگین خرید هر مشتری', money(s.avg_per_customer), null, 'var(--pal-5)'],
      ]} />
      <Card size="small" title="مشتریان برتر">
        <Table size="small" rowKey="phone" dataSource={arr(data.top)} pagination={false} locale={{ emptyText: 'سفارشی با شماره موبایل ثبت نشده' }}
          columns={[
            { title: 'مشتری', dataIndex: 'name', render: (v, _, i) => <span><span className={`rank r${i + 1}`}>{num(i + 1)}</span>{v || '—'}</span> },
            { title: 'موبایل', dataIndex: 'phone', render: (v) => <span className="ltr">{v}</span> }, numCol('سفارش', 'orders'), moneyCol('جمع خرید', 'spent'),
            { title: 'آخرین خرید', dataIndex: 'last', render: faDate },
          ]} />
      </Card>
    </>
  )
}

// ---------------------------------------------------------------- tax ledger
export function TaxTab({ range }) {
  const { data, loading } = useSection('tax', range)
  if (loading || !data) return <Loading />
  const t = data.totals || {}
  return (
    <>
      <Kpis items={[
        ['فروش خالص (پس از تخفیف)', money(t.net_sales), null, 'var(--primary-text)'], ['حق سرویس', money(t.service), null, 'var(--blue)'],
        [`مالیات بر ارزش افزوده${data.tax_enabled ? ` (${num(data.tax_percent)}٪)` : ''}`, money(t.tax), data.tax_enabled ? null : 'مالیات در تنظیمات غیرفعال است', 'var(--amber)'],
        ['جمع دریافتی', money(t.total), t.refunds ? `بازپرداخت: ${money(t.refunds)}` : null, 'var(--green)'],
      ]} />
      <Table size="small" rowKey="date" dataSource={arr(data.rows)} pagination={false} scroll={{ x: 900, y: 420 }}
        summary={() => (
          <Table.Summary fixed>
            <Table.Summary.Row style={{ fontWeight: 700 }}>
              <Table.Summary.Cell index={0}>جمع</Table.Summary.Cell>
              {['orders', 'gross', 'discounts', 'net_sales', 'service', 'tax', 'total', 'refunds'].map((k, i) => <Table.Summary.Cell key={k} index={i + 1}>{k === 'orders' ? num(t[k]) : money(t[k])}</Table.Summary.Cell>)}
            </Table.Summary.Row>
          </Table.Summary>
        )}
        columns={[
          { title: 'تاریخ', dataIndex: 'date', render: faDate }, numCol('سفارش', 'orders'), moneyCol('فروش ناخالص', 'gross'), moneyCol('تخفیف', 'discounts'),
          moneyCol('فروش خالص', 'net_sales'), moneyCol('سرویس', 'service'), moneyCol('مالیات', 'tax'), moneyCol('جمع دریافتی', 'total'), moneyCol('بازپرداخت', 'refunds'),
        ]} />
      <Typography.Text type="secondary" style={{ fontSize: 12 }}>بازپرداخت‌ها در روزی که پرداخت شده‌اند ثبت می‌شوند. این جدول برای تطبیق با اظهارنامه و سامانه مودیان است.</Typography.Text>
    </>
  )
}

