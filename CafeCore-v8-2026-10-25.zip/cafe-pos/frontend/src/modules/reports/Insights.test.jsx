import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor } from '@testing-library/react'
import { App } from 'antd'

/**
 * The nine insight tabs (discounts, staff, shifts, menu engineering, modifiers, tables, kitchen,
 * tax, customers). Each tab fetches its own section and renders a different view of the same money —
 * the tests pin that every tab paints its payload and survives an empty answer.
 */
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/theme', () => ({ useChart: () => ({ c: ['#111', '#222'], accent: '#4f46e5', grid: '#eee', axis: '#999' }) }))

const {
  DiscountsTab, StaffTab, ShiftsTab, MenuEngineeringTab, ModifiersTab, TablesTab, KitchenTab, TaxTab, CustomersTab,
} = await import('./Insights')

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const RANGE = { from: '2026-09-23', to: '2026-10-22' }

const SECTIONS = {
  discounts: {
    summary: { total: 620_000, orders: 12, pct_of_gross: 5.0, health: 'warn', orders_pct: 21.0, avg_discount: 51_666, items_discount: 120_000, approved_count: 3, comps: 0 },
    by_reason: [{ reason: 'کارمندی', count: 7, amount: 300_000 }],
    by_user: [{ name: 'رضا', count: 7, amount: 300_000 }],
    by_item: [{ name: 'اسپرسو', qty: 9, amount: 120_000 }],
  },
  staff: { rows: [{ name: 'علی', role: 'گارسون', orders: 30, sales: 6_000_000, avg_ticket: 200_000, items_per_check: 2.4, discounts: 50_000, voids: 1 }] },
  shifts: {
    available: true,
    rows: [{ id: 12, register: 'صندوق اصلی', closed_by: 'رضا', expected: 800_800, counted: 800_000, difference: -800, closed_at: '2026-10-23T09:00:00', sales: 1_180_000, opening_cash: 500_000 }],
    summary: { net: -800, over: 0, short: 800, shifts: 1, with_difference: 1 },
    by_cashier: [{ name: 'رضا', shifts: 1, sales: 1_180_000, short: 800, over: 0, net: -800 }],
  },
  menu: {
    rows: [
      { id: 11, name: 'اسپرسو', category: 'قهوه', qty: 90, revenue: 12_600_000, mix_pct: 60, cm: 98_000, total_cm: 8_820_000, class: 'star', class_label: 'ستاره' },
      { id: 12, name: 'چیزکیک', category: 'کیک', qty: 10, revenue: 2_000_000, mix_pct: 8, cm: 110_000, total_cm: 1_100_000, class: 'puzzle', class_label: 'معما' },
    ],
    unsold: [{ id: 13, name: 'کوکی', category: 'کیک', price: 80_000 }],
    avg_cm: 90_000, popularity_threshold: 35, has_costs: true,
    classes: [{ key: 'star', label: 'ستاره', count: 1 }, { key: 'puzzle', label: 'معما', count: 1 }],
  },
  modifiers: { rows: [{ name: 'شیر بادام', count: 12, revenue: 90_000, top_items: 'اسپرسو' }], revenue: 90_000 },
  tables: {
    available: true,
    rows: [{ id: 1, name: 'میز ۱', area: 'سالن', seats: 4, orders: 12, guests: 30, revenue: 3_000_000, avg_minutes: 42, per_guest: 100_000, turns_per_day: 1.2, per_seat_day: 50_000 }],
    by_area: [{ area: 'سالن', orders: 12, guests: 30, revenue: 3_000_000, tables: 4, per_guest: 100_000 }],
    summary: { orders: 12, guests: 30, revenue: 3_000_000, per_guest: 100_000, avg_minutes: 42, turns_per_table_day: 1.2 },
  },
  kitchen: {
    stations: [{ station: 'بار', count: 40, avg_minutes: 6.5, p90: 11, late_pct: 4.2 }],
    rows: [{ name: 'اسپرسو', count: 90, avg_minutes: 5, p90: 9, late_pct: 2 }],
    summary: { avg_wait_to_start: 3.1, late: 2 },
  },
  tax: { rows: [{ date: '2026-10-22', gross: 2_000_000, discount: 100_000, service: 0, tax: 180_000 }], totals: { gross: 12_400_000, tax: 1_120_000 } },
  customers: { rows: [{ phone: '09127770011', orders: 12, spent: 4_250_000, last: '2026-10-22' }], summary: { new: 4, returning: 20, avg_per_customer: 350_000 } },
}

const respond = () => get.mockImplementation((path) => {
  const section = String(path).split('/').pop()
  return Promise.resolve(SECTIONS[section] ?? {})
})
const show = (Tab) => render(<App><Tab range={RANGE} /></App>)
const painted = async (pattern) => {
  await waitFor(() => expect(text()).toMatch(pattern))
}

describe('Insight tabs', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('asks the server for its own section and the selected range', async () => {
    show(DiscountsTab)
    await waitFor(() => expect(get).toHaveBeenCalledWith('/reports/insights/discounts', { date_from: RANGE.from, date_to: RANGE.to }))
  })

  it('discounts: total, share of gross and the reasons', async () => {
    show(DiscountsTab)
    await painted(/تخفیف/)
    expect(text()).toContain('۶۲۰٬۰۰۰')
  })

  it('staff: employees with their sales', async () => {
    show(StaffTab)
    await painted(/علی|گارسون|پرسنل/)
  })

  it('shifts: the over/short of the drawer', async () => {
    show(ShiftsTab)
    await painted(/صندوق|مغایرت|رضا/)
  })

  it('menu engineering: the classes and the unsold list', async () => {
    show(MenuEngineeringTab)
    await painted(/اسپرسو|ستاره|مهندسی|منو/)
  })

  it('modifiers: add-on revenue', async () => {
    show(ModifiersTab)
    await painted(/شیر بادام|افزودنی/)
  })

  it('tables: revenue per table', async () => {
    show(TablesTab)
    await painted(/میز|سالن/)
  })

  it('kitchen: preparation speed', async () => {
    show(KitchenTab)
    await painted(/آشپزخانه|بار|سرعت|تأخیر/)
  })

  it('tax: the daily VAT ledger', async () => {
    show(TaxTab)
    await painted(/مالیات|دفتر/)
  })

  it('customers: new vs returning', async () => {
    show(CustomersTab)
    await painted(/مشتری|جدید|بازگشتی/)
  })

  it('every tab survives an empty answer', async () => {
    get.mockImplementation(() => Promise.resolve({}))
    const tabs = [DiscountsTab, StaffTab, ShiftsTab, MenuEngineeringTab, ModifiersTab, TablesTab, KitchenTab, TaxTab, CustomersTab]
    for (const Tab of tabs) {
      const { unmount } = render(<App><Tab range={RANGE} /></App>)
      await waitFor(() => expect(get).toHaveBeenCalled())
      unmount()
    }
  })
})
