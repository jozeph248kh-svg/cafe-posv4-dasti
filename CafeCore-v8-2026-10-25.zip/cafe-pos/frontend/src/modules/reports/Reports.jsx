import { DownOutlined, FileExcelOutlined, LeftOutlined, PrinterOutlined, RightOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, Dropdown, Empty, Modal, Row, Segmented, Skeleton, Space, Table, Tabs, Tag, Tooltip as AntTip, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ComposedChart, Line, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { DataTag, PageHeader, StatCard } from '../../components/common'
import { download } from '../../core/api'
import { useAuth } from '../../core/auth'
import { compact, faDate, faShort, faWeekday, money, num } from '../../core/format'
import { printZReport } from '../../core/print'
import { useFetch } from '../../core/useFetch'
import { COLORS, MoneyTip, tooltipStyle } from '../dashboard/Dashboard'
import { CustomersTab, DiscountsTab, KitchenTab, MenuEngineeringTab, ModifiersTab, ShiftsTab, StaffTab, TablesTab, TaxTab } from './Insights'
import { DollarOutlined, PercentageOutlined, ShoppingCartOutlined, StopOutlined, TagOutlined, FireOutlined } from '@ant-design/icons'
import { useChart } from '../../core/theme'

// JS getDay(): Sat=6 ... backend weekday(): Mon=0. Persian week starts Saturday.
const WEEK = [5, 6, 0, 1, 2, 3, 4]
const WEEK_LABEL = { 0: 'دوشنبه', 1: 'سه‌شنبه', 2: 'چهارشنبه', 3: 'پنجشنبه', 4: 'جمعه', 5: 'شنبه', 6: 'یکشنبه' }

function Heatmap({ data }) {
  const max = Math.max(1, ...data.map((d) => d.revenue))
  const map = Object.fromEntries(data.map((d) => [`${d.weekday}-${d.hour}`, d.revenue]))
  const hours = Array.from({ length: 17 }, (_, i) => i + 7)
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ borderCollapse: 'separate', borderSpacing: 3, width: '100%', minWidth: 640 }}>
        <thead><tr><th />{hours.map((h) => <th key={h} style={{ fontSize: 11, fontWeight: 400, color: 'var(--muted)' }}>{num(h)}</th>)}</tr></thead>
        <tbody>
          {WEEK.map((w) => (
            <tr key={w}>
              <td style={{ fontSize: 12, whiteSpace: 'nowrap', paddingLeft: 8 }}>{WEEK_LABEL[w]}</td>
              {hours.map((h) => {
                const v = map[`${w}-${h}`] || 0
                return (
                  <td key={h}>
                    <AntTip title={`${WEEK_LABEL[w]} ساعت ${num(h)}: ${money(v)}`}>
                      <div className="heat-cell" style={{ background: v ? `rgba(194,105,62,${0.08 + (v / max) * 0.92})` : 'var(--soft)' }} />
                    </AntTip>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

const shiftDay = (iso, n) => { const d = new Date(`${iso}T12:00:00`); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10) }

/** End-of-day (Z) report: preview + 80 mm print. */
function ZReportModal({ open, day: initial, onClose }) {
  const auth = useAuth()
  const [day, setDay] = useState(initial)
  const { data: z, loading } = useFetch('/reports/insights/z', { day }, { skip: !open })
  const m = z?.summary
  const line = (a, b, strong) => <div className="kpi-mini" style={strong ? { fontWeight: 700 } : undefined}><span>{a}</span><b>{b}</b></div>
  return (
    <Modal open={open} onCancel={onClose} width={460} centered destroyOnClose title="گزارش پایان روز (Z)"
      footer={[<Button key="c" onClick={onClose}>بستن</Button>, <Button key="p" type="primary" icon={<PrinterOutlined />} disabled={!z} onClick={() => printZReport(z, auth.settings, auth.user?.full_name)}>چاپ</Button>]}>
      <Space style={{ width: '100%', justifyContent: 'space-between', marginBottom: 12 }}>
        <Button icon={<RightOutlined />} onClick={() => setDay(shiftDay(day, -1))}>روز قبل</Button>
        <b>{faWeekday(day)} {faDate(day)}</b>
        <Button onClick={() => setDay(shiftDay(day, 1))}>روز بعد <LeftOutlined /></Button>
      </Space>
      {loading || !z ? <Skeleton active /> : (
        <div>
          {line('تعداد فاکتور', num(m.orders))}{line('فروش ناخالص', money(m.gross))}{line('تخفیف', `−${money(m.discounts)}`)}
          {m.service > 0 && line('حق سرویس', money(m.service))}{m.tax > 0 && line('مالیات', money(m.tax))}
          {line('فروش خالص', money(m.net), true)}{line('میانگین فاکتور', money(m.avg_ticket))}
          <Typography.Title level={5} style={{ marginTop: 12 }}>روش پرداخت</Typography.Title>
          {z.by_payment.map((p) => line(p.label, money(p.amount)))}
          <Typography.Title level={5} style={{ marginTop: 12 }}>کنترل</Typography.Title>
          {line(`تخفیف (${num(z.discounts.orders)} فاکتور)`, `${money(z.discounts.total)} · ${num(z.discounts.pct, 1)}٪`)}
          {line(`آیتم حذف‌شده (${num(z.voids.count)})`, money(z.voids.amount))}
          {line(`سفارش لغوشده (${num(m.cancelled)})`, money(m.cancelled_amount))}
          {z.shifts.map((sh) => line(`مغایرت صندوق ${sh.closed_by || ''}`, <span style={{ color: sh.difference < 0 ? 'var(--red)' : undefined }}>{money(sh.difference)}</span>))}
          {z.open_orders > 0 && <Typography.Text type="warning">⚠ {num(z.open_orders)} سفارش باز هنوز تسویه نشده است.</Typography.Text>}
        </div>
      )}
    </Modal>
  )
}

export default function Reports() {
  const ch = useChart()
  const { message } = App.useApp()
  const [range, setRange] = useState(rangeOf('last30'))
  const [itemSort, setItemSort] = useState('revenue')
  const { data: r, loading } = useFetch('/reports/sales', { date_from: range.from, date_to: range.to })
  const s = r?.summary || {}
  const items = useMemo(() => [...(r?.by_item || [])].sort((a, b) => b[itemSort] - a[itemSort]), [r, itemSort])
  const { data: cmp } = useFetch('/reports/insights/compare', { date_from: range.from, date_to: range.to })
  const [zOpen, setZOpen] = useState(false)
  const vsPrev = (k) => { const d = cmp?.change?.[k]; return d === null || d === undefined ? {} : { delta: d, hint: prevHint } }
  const prevHint = cmp ? `نسبت به ${faShort(cmp.previous_range.from)} تا ${faShort(cmp.previous_range.to)}` : ''
  const exportXlsx = (kind) => download(kind === 'insights' ? '/reports/insights/export' : '/reports/sales/export', { date_from: range.from, date_to: range.to }).catch((e) => message.error(e.message))

  return (
    <div className="fade-in">
      <PageHeader title="گزارش فروش" subtitle={r ? `${faDate(range.from)} تا ${faDate(range.to)}` : ''}
        extra={[<JalaliRange key="r" value={range} onChange={setRange} />,
          <Button key="z" icon={<PrinterOutlined />} onClick={() => setZOpen(true)}>گزارش پایان روز (Z)</Button>,
          <Dropdown key="x" trigger={['click']} menu={{ onClick: ({ key }) => exportXlsx(key), items: [
            { key: 'sales', label: 'گزارش فروش (روزانه، آیتم‌ها، پرداخت، حذفیات)' },
            { key: 'insights', label: 'گزارش‌های مدیریتی (تخفیف، پرسنل، صندوق، مهندسی منو، میز، آشپزخانه، مالیات، مشتریان)' },
          ] }}>
            <Button icon={<FileExcelOutlined />} style={{ color: 'var(--green)', borderColor: 'var(--green)' }}>خروجی اکسل <DownOutlined /></Button>
          </Dropdown>]} />
      <ZReportModal key={zOpen ? range.to : 'closed'} open={zOpen} day={range.to} onClose={() => setZOpen(false)} />
      <Row gutter={[16, 16]}>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="فروش خالص (بدون مالیات)" value={s.net_revenue ?? s.net} money
          {...vsPrev('net')} hint={vsPrev('net').delta === undefined ? `جمع دریافتی با مالیات: ${money(s.net ?? 0)}` : prevHint}
          icon={<DollarOutlined />} color="var(--primary-text)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="تعداد سفارش" value={s.orders} {...vsPrev('orders')} icon={<ShoppingCartOutlined />} color="var(--green)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="میانگین فاکتور" value={s.avg_ticket} money {...vsPrev('avg_ticket')} icon={<TagOutlined />} color="var(--amber)" /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="تخفیف‌ها" value={s.discounts} money hint={`${num(cmp?.current?.discount_pct ?? 0, 2)}٪ فروش ناخالص${cmp?.previous?.gross ? ` (دوره قبل ${num(cmp.previous.discount_pct, 2)}٪)` : ''}`} icon={<PercentageOutlined />} color={(cmp?.current?.discount_pct || 0) > 5 ? 'var(--red)' : 'var(--pal-5)'} /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="درصد بهای مواد (فودکاست)" value={`${num(s.food_cost_pct, 1)}٪`} hint={`${compact(s.food_cost)} تومان`} icon={<FireOutlined />} color={s.food_cost_pct > 35 ? 'var(--red)' : 'var(--pal-7)'} /></Col>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={loading} title="حذف و لغو" value={s.voids + s.cancelled} hint={`${compact(s.voids_amount)} تومان آیتم حذف‌شده`} icon={<StopOutlined />} color="var(--red)" /></Col>
      </Row>

      <Card className="card-r" style={{ marginTop: 16 }} loading={loading}>
        <Tabs items={[
          {
            key: 'trend', label: 'روند فروش', children: (
              <ResponsiveContainer width="100%" height={340}>
                <ComposedChart data={r?.by_day || []} margin={{ left: 10, right: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="date" tickFormatter={faShort} tick={{ fontSize: 11 }} reversed />
                  <YAxis yAxisId="m" tickFormatter={compact} tick={{ fontSize: 11 }} orientation="right" width={70} />
                  <YAxis yAxisId="o" tick={{ fontSize: 11 }} orientation="left" tickFormatter={(v) => num(v)} />
                  <Tooltip content={<MoneyTip labelFmt={(d) => `${faWeekday(d)} ${faShort(d)}`} />} />
                  <Bar yAxisId="m" dataKey="revenue" name="فروش" fill={ch.accent} radius={[6, 6, 0, 0]} maxBarSize={30} />
                  <Line yAxisId="o" dataKey="orders" name="سفارش" stroke={ch.amber} strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            ),
          },
          {
            key: 'peak', label: 'ساعات اوج', children: (
              <Row gutter={[24, 24]}>
                <Col xs={24} xl={10}>
                  <Typography.Title level={5}>فروش بر اساس ساعت</Typography.Title>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={(r?.by_hour || []).filter((h) => h.hour >= 7)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="hour" tickFormatter={(h) => num(h)} reversed tick={{ fontSize: 11 }} />
                      <YAxis tickFormatter={compact} orientation="right" width={60} tick={{ fontSize: 11 }} />
                      <Tooltip content={<MoneyTip labelFmt={(h) => `ساعت ${num(h)}`} />} />
                      <Bar dataKey="revenue" name="فروش" radius={[6, 6, 0, 0]}>
                        {(r?.by_hour || []).filter((h) => h.hour >= 7).map((h) => <Cell key={h.hour} fill={h.hour >= 19 && h.hour <= 21 ? ch.c[4] : h.hour >= 12 && h.hour <= 14 ? ch.amber : ch.accent} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Col>
                <Col xs={24} xl={14}>
                  <Typography.Title level={5}>نقشه حرارتی روز هفته × ساعت</Typography.Title>
                  <Heatmap data={r?.heatmap || []} />
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>رنگ پررنگ‌تر = فروش بیشتر؛ برای برنامه‌ریزی شیفت پرسنل و خرید مواد استفاده کنید.</Typography.Text>
                </Col>
              </Row>
            ),
          },
          {
            key: 'items', label: 'آیتم‌ها و سودآوری', children: (
              <>
                <Segmented value={itemSort} onChange={setItemSort} style={{ marginBottom: 12 }}
                  options={[{ value: 'revenue', label: 'بیشترین فروش' }, { value: 'qty', label: 'بیشترین تعداد' }, { value: 'profit', label: 'بیشترین سود' }]} />
                <Table size="middle" rowKey="id" dataSource={items} pagination={{ pageSize: 15, showSizeChanger: false }} scroll={{ x: 700 }}
                  columns={[
                    { title: '#', width: 50, render: (_, __, i) => num(i + 1) },
                    { title: 'آیتم', dataIndex: 'name', render: (v, x) => <span><b>{v}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{x.category}</Typography.Text></span> },
                    { title: 'تعداد', dataIndex: 'qty', render: (v) => num(v), sorter: (a, b) => a.qty - b.qty },
                    // «فروش» = مبلغ واقعیِ دریافتی برای این آیتم (پس از تخفیف آیتم و سهم آن از تخفیف کلی فاکتور)
                    { title: 'فروش (پس از تخفیف)', dataIndex: 'revenue', render: (v, x) => (x.gross && x.gross !== v
                      ? <span><b>{money(v)}</b> <Typography.Text delete type="secondary" style={{ fontSize: 12 }}>{money(x.gross)}</Typography.Text></span>
                      : money(v)), sorter: (a, b) => a.revenue - b.revenue },
                    // بهای تمام‌شدهٔ همان آیتم در همان فروش (تاریخی، قفل‌شده در لحظهٔ فروش) — مستقل از قیمت امروز
                    { title: 'بهای تمام‌شده (COGS)', dataIndex: 'cost', render: (v) => (v ? money(v) : <Typography.Text type="secondary">بدون رسپی</Typography.Text>) },
                    { title: 'سود ناخالص', dataIndex: 'profit', render: (v, x) => (x.cost ? <b style={{ color: 'var(--green)' }}>{money(v)}</b> : '—'), sorter: (a, b) => a.profit - b.profit },
                    { title: 'فودکاست', render: (_, x) => { if (!x.cost) return '—'; const p = (x.cost / x.revenue) * 100; return <Tag color={p > 40 ? 'red' : p > 30 ? 'orange' : 'green'}>{num(p, 1)}٪</Tag> } },
                  ]} />
              </>
            ),
          },
          {
            key: 'cats', label: 'دسته‌بندی و نوع سفارش', children: (
              <Row gutter={[24, 24]}>
                {[['by_category', 'فروش دسته‌بندی‌ها', 'revenue', 'name'], ['by_type', 'نوع سفارش', 'revenue', 'label'], ['by_payment', 'روش پرداخت', 'amount', 'label']].map(([k, title, val, name]) => (
                  <Col key={k} xs={24} md={8}>
                    <Typography.Title level={5}>{title}</Typography.Title>
                    {(r?.[k] || []).length ? (
                      <>
                        <ResponsiveContainer width="100%" height={220}>
                          <PieChart>
                            <Pie data={r[k]} dataKey={val} nameKey={name} innerRadius={55} outerRadius={90} paddingAngle={2}>
                              {r[k].map((x, i) => <Cell key={i} fill={x.color || ch.c[i % ch.c.length]} />)}
                            </Pie>
                            <Tooltip formatter={(v) => money(v)} contentStyle={tooltipStyle} />
                          </PieChart>
                        </ResponsiveContainer>
                        {r[k].map((x, i) => <div key={i} className="kpi-mini"><span><DataTag color={x.color || COLORS[i % COLORS.length]}>{x[name]}</DataTag></span><b>{money(x[val])}</b></div>)}
                      </>
                    ) : <Empty />}
                  </Col>
                ))}
              </Row>
            ),
          },
          { key: 'menueng', label: 'مهندسی منو', children: <MenuEngineeringTab range={range} /> },
          { key: 'discounts', label: 'تخفیف‌ها', children: <DiscountsTab range={range} /> },
          { key: 'staff', label: 'عملکرد پرسنل', children: <StaffTab range={range} /> },
          { key: 'shifts', label: 'مغایرت صندوق', children: <ShiftsTab range={range} /> },
          { key: 'tables', label: 'میزها و سالن', children: <TablesTab range={range} /> },
          { key: 'kitchen', label: 'سرعت آشپزخانه', children: <KitchenTab range={range} /> },
          { key: 'modifiers', label: 'افزودنی‌ها', children: <ModifiersTab range={range} /> },
          { key: 'customers', label: 'مشتریان', children: <CustomersTab range={range} /> },
          { key: 'tax', label: 'دفتر مالیات', children: <TaxTab range={range} /> },
          {
            key: 'voids', label: `حذفیات (${num(r?.voids?.length || 0)})`, children: (
              <Table rowKey={(x, i) => i} dataSource={r?.voids || []} size="small" pagination={{ pageSize: 15 }}
                columns={[
                  { title: 'تاریخ', dataIndex: 'date', render: faDate },
                  { title: 'سفارش', dataIndex: 'order_number', render: (v) => `#${num(v)}` },
                  { title: 'آیتم', dataIndex: 'name', render: (v, x) => `${num(x.qty)}× ${v}` },
                  { title: 'مبلغ', dataIndex: 'amount', render: money },
                  { title: 'دلیل', dataIndex: 'reason' },
                  { title: 'تأییدکننده', dataIndex: 'by' },
                ]} />
            ),
          },
        ]} />
      </Card>
    </div>
  )
}
