import {
  AppstoreOutlined, CheckOutlined, FullscreenExitOutlined, FullscreenOutlined, HistoryOutlined, LockOutlined,
  PrinterOutlined, SoundOutlined, UndoOutlined, UnorderedListOutlined, MutedOutlined,
} from '@ant-design/icons'
import { App, Badge, Button, Empty, Segmented, Space, Spin, Tooltip } from 'antd'
import { memo, useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import { useNavigate } from 'react-router-dom'
import ConnectionBadge from '../../components/ConnectionBadge'
import { get, post } from '../../core/api'
import { inkOn } from '../../core/color'
import { useAuth } from '../../core/auth'
import { ORDER_TYPES, clock, faTime, minutesSince, modText, num } from '../../core/format'
import { printKitchenTicket } from '../../core/print'
import { beep, useRealtime } from '../../core/realtime'

const NEXT_LABEL = { new: 'شروع آماده‌سازی', preparing: 'آماده شد ✓', ready: 'تحویل شد' }

/**
 * ONE clock for the whole board. It used to be one interval per ticket, so a busy service with 30
 * tickets re-rendered 30 full cards every second — on a cheap kitchen tablet that made the screen
 * crawl and look frozen. Only the tiny nodes below subscribe, so a tick repaints a few spans and
 * never re-renders a ticket or its item list.
 */
const tickSubs = new Set()
let tickTimer = null
let tickValue = 0
function subscribeTick(cb) {
  tickSubs.add(cb)
  if (!tickTimer) tickTimer = setInterval(() => { tickValue += 1; tickSubs.forEach((f) => f()) }, 1000)
  return () => {
    tickSubs.delete(cb)
    if (!tickSubs.size && tickTimer) { clearInterval(tickTimer); tickTimer = null }
  }
}
const getTick = () => tickValue
const useTick = () => useSyncExternalStore(subscribeTick, getTick)

/** The moving parts of a ticket: the SLA bar and the elapsed clock. */
const SlaBar = memo(function SlaBar({ created_at, status, late }) {
  useTick()
  const mins = minutesSince(created_at)
  const settled = ['ready', 'done'].includes(status)
  return <div className="kt-prog"><i style={{ width: `${settled ? 100 : Math.min(100, Math.max(3, (mins / late) * 100))}%` }} /></div>
})
const Elapsed = memo(function Elapsed({ created_at, status }) {
  useTick()
  return <div className="kt-clock">{status === 'done' ? faTime(created_at) : clock(created_at)}</div>
})

function Ticket({ t, station, late, onBump, onToggle, onRecall, onPrint }) {
  const mins = minutesSince(t.created_at)
  const level = t.status === 'ready' ? 'ready' : t.status === 'done' ? 'done' : mins >= late ? 'late' : mins >= late * 0.66 ? 'warn' : 'ok'
  const type = ORDER_TYPES[t.order_type] || ORDER_TYPES.dine_in
  return (
    <div className={`kds-ticket ${level} st-${t.status}`}>
      {/* SLA bar: fills towards the «late» threshold — green → amber → red */}
      <SlaBar created_at={t.created_at} status={t.status} late={late} />
      <div className="kt-head">
        <div>
          <div className="kt-num">#{num(t.order_number)}</div>
          <div className="kt-where">{t.table_name ? `میز ${t.table_name}` : `${type.icon} ${type.label}`}</div>
        </div>
        <div className="kt-time">
          <Elapsed created_at={t.created_at} status={t.status} />
          <div className="kt-station" style={station?.color ? { background: station.color, color: inkOn(station.color) } : undefined}>{station?.name}</div>
        </div>
      </div>
      <div className="kt-meta">{t.waiter_name && <span>👤 {t.waiter_name}</span>}<span>{faTime(t.created_at)}</span></div>
      <div className="kt-items">
        {t.items.map((i) => (
          <button type="button" key={i.id} className={`kt-item ${i.is_done ? 'done' : ''} ${i.is_void ? 'void' : ''}`} disabled={i.is_void || t.status === 'done'} onClick={() => onToggle(t, i)}>
            <span className="kt-qty">{num(i.qty)}</span>
            <span className="kt-body">
              <span className="kt-name">{i.name}{i.is_void && <b className="kt-void"> (حذف شد)</b>}</span>
              {i.modifiers?.length > 0 && <span className="kt-mods">{modText(i.modifiers, ' · ')}</span>}
              {i.note && <span className="kt-note">⚠ {i.note}</span>}
            </span>
          </button>
        ))}
      </div>
      {t.note && <div className="kt-order-note">📝 {t.note}</div>}
      <div className="kt-foot">
        {t.status === 'done' ? (
          <Button block icon={<UndoOutlined />} onClick={() => onRecall(t)}>بازگرداندن</Button>
        ) : (
          <>
            <Button className={`kt-bump b-${t.status}`} block size="large" onClick={() => onBump(t)}>{NEXT_LABEL[t.status]}</Button>
            <Button size="large" icon={<PrinterOutlined />} onClick={() => onPrint(t)} />
          </>
        )}
      </div>
    </div>
  )
}

export default function KdsPage() {
  const auth = useAuth()
  const nav = useNavigate()
  const { message } = App.useApp()
  const [tickets, setTickets] = useState(null)
  const [stations, setStations] = useState([])
  const [station, setStation] = useState(() => localStorage.getItem('kds_station') || 'all')
  const [history, setHistory] = useState(false)
  const [allDay, setAllDay] = useState(false)
  const [sound, setSound] = useState(() => localStorage.getItem('kds_sound') !== '0')
  const [full, setFull] = useState(false)
  const known = useRef(null)
  const late = Number(auth.settings['kitchen.late_minutes'] || 15)

  const load = useCallback(async () => {
    try {
      const list = await get('/kitchen/tickets', { include_done: history })
      const ids = new Set(list.map((t) => t.id))
      if (known.current && sound) {
        const fresh = list.filter((t) => !known.current.has(t.id) && t.status === 'new' && (station === 'all' || String(t.station_id) === station))
        if (fresh.length) beep('new')
      }
      known.current = ids
      setTickets(list)
    } catch (e) { message.error(e.message) }
  }, [history, sound, station, message])

  useEffect(() => { load() }, [load])
  useEffect(() => { get('/menu/stations').then(setStations).catch(() => {}) }, [])
  useEffect(() => { const t = setInterval(load, 30000); return () => clearInterval(t) }, [load])
  const timer = useRef(null)
  useRealtime(['kitchen.ticket', '_reconnected'], () => { clearTimeout(timer.current); timer.current = setTimeout(load, 150) })

  const stationMap = useMemo(() => Object.fromEntries(stations.map((s) => [s.id, s])), [stations])
  const visible = useMemo(() => (tickets || [])
    .filter((t) => station === 'all' || String(t.station_id) === station)
    .filter((t) => (history ? t.status === 'done' : t.status !== 'done' && t.status !== 'void'))
    .sort((a, b) => (history ? new Date(b.created_at) - new Date(a.created_at) : new Date(a.created_at) - new Date(b.created_at))), [tickets, station, history])
  const stats = useMemo(() => {
    const act = (tickets || []).filter((t) => ['new', 'preparing', 'ready'].includes(t.status) && (station === 'all' || String(t.station_id) === station))
    return { new: act.filter((t) => t.status === 'new').length, preparing: act.filter((t) => t.status === 'preparing').length, ready: act.filter((t) => t.status === 'ready').length, late: act.filter((t) => t.status !== 'ready' && minutesSince(t.created_at) >= late).length }
  }, [tickets, station, late])
  const summary = useMemo(() => {
    const m = {}
    ;(tickets || []).filter((t) => ['new', 'preparing'].includes(t.status) && (station === 'all' || String(t.station_id) === station))
      .forEach((t) => t.items.filter((i) => !i.is_void && !i.is_done).forEach((i) => { m[i.name] = (m[i.name] || 0) + i.qty }))
    return Object.entries(m).sort((a, b) => b[1] - a[1])
  }, [tickets, station])

  const act = async (fn) => { try { await fn(); load() } catch (e) { message.error(e.message) } }
  const bump = (t) => act(() => post(`/kitchen/tickets/${t.id}/bump`))
  const toggle = (t, i) => act(() => post(`/kitchen/tickets/${t.id}/items/${i.id}/toggle`))
  const recall = (t) => act(() => post(`/kitchen/tickets/${t.id}/status`, { status: 'preparing' }))
  const toggleFull = () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().then(() => setFull(true)).catch(() => {})
    else document.exitFullscreen?.().then(() => setFull(false))
  }

  return (
    <div className="kds">
      <header className="kds-top">
        <Space size={10}>
          <Button type="text" icon={<AppstoreOutlined />} onClick={() => nav('/')} className="kds-btn" />
          <span className="kds-title">🔥 آشپزخانه</span>
          <Segmented value={station} onChange={(v) => { setStation(v); localStorage.setItem('kds_station', v) }}
            options={[{ value: 'all', label: 'همه ایستگاه‌ها' }, ...stations.map((s) => ({ value: String(s.id), label: s.name }))]} />
        </Space>
        <Space size={14}>
          <span className="kds-stat"><Badge color="var(--blue-raw)" /> جدید {num(stats.new)}</span>
          <span className="kds-stat"><Badge color="var(--amber-raw)" /> در حال آماده‌سازی {num(stats.preparing)}</span>
          <span className="kds-stat"><Badge color="var(--green-raw)" /> آماده {num(stats.ready)}</span>
          {stats.late > 0 && <span className="kds-stat late"><Badge color="var(--red-raw)" /> تأخیر {num(stats.late)}</span>}
        </Space>
        <Space size={4}>
          <ConnectionBadge />
          <Tooltip title="خلاصه اقلام در حال آماده‌سازی"><Button type={allDay ? 'primary' : 'text'} className="kds-btn" icon={<UnorderedListOutlined />} onClick={() => setAllDay(!allDay)} /></Tooltip>
          <Tooltip title="تحویل‌شده‌های ۳۰ دقیقه اخیر"><Button type={history ? 'primary' : 'text'} className="kds-btn" icon={<HistoryOutlined />} onClick={() => setHistory(!history)} /></Tooltip>
          <Tooltip title={sound ? 'صدا روشن' : 'صدا خاموش'}><Button type="text" className="kds-btn" icon={sound ? <SoundOutlined /> : <MutedOutlined />} onClick={() => { setSound(!sound); localStorage.setItem('kds_sound', sound ? '0' : '1'); if (!sound) beep('new') }} /></Tooltip>
          <Button type="text" className="kds-btn" icon={full ? <FullscreenExitOutlined /> : <FullscreenOutlined />} onClick={toggleFull} />
          <Button type="text" className="kds-btn" icon={<LockOutlined />} onClick={() => { auth.logout(); nav('/login') }} />
        </Space>
      </header>
      <div className="kds-body">
        {allDay && (
          <aside className="kds-allday">
            <div className="kds-allday-title">جمع اقلام در صف</div>
            {summary.map(([name, q]) => <div key={name} className="ad-row"><span>{name}</span><b>{num(q)}</b></div>)}
            {!summary.length && <div className="ad-empty">صف خالی است</div>}
          </aside>
        )}
        {tickets === null ? <div className="center-fill"><Spin size="large" /></div> : visible.length ? (
          <div className="kds-grid">
            {visible.map((t) => <Ticket key={t.id} t={t} station={stationMap[t.station_id]} late={late} onBump={bump} onToggle={toggle} onRecall={recall} onPrint={(x) => printKitchenTicket(x, stationMap[x.station_id]?.name, auth.settings)} />)}
          </div>
        ) : (
          <div className="center-fill"><Empty image={<CheckOutlined style={{ fontSize: 72, color: 'var(--green)' }} />} description={<span className="kds-empty">{history ? 'تیکت تحویل‌شده‌ای نیست' : 'همه سفارش‌ها آماده شده‌اند 👌'}</span>} /></div>
        )}
      </div>
    </div>
  )
}
