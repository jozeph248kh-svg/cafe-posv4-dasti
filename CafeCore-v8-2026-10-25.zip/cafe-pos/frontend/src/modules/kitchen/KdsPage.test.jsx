import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { MemoryRouter } from 'react-router-dom'

/**
 * The kitchen display: the busiest screen after the till. A ticket that never turns red means a
 * customer waiting without anyone noticing, so the late flag, the per-station filter and the "done"
 * bump are pinned here.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({
  useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1, full_name: 'آشپز' }, settings: { 'kitchen.late_minutes': 15, 'kitchen.sound': false }, system: {} }),
}))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: vi.fn() }))
vi.mock('react-router-dom', async (orig) => ({ ...(await orig()), useNavigate: () => vi.fn() }))

const { default: KdsPage } = await import('./KdsPage')

const ago = (min) => new Date(Date.now() - min * 60000).toISOString()
const TICKETS = [
  { id: 1, number: 41, order_number: 41, table_name: '۳', type: 'dine_in', status: 'new', station_id: 1, created_at: ago(3), items: [{ id: 11, name: 'اسپرسو', qty: 2, is_done: false, is_void: false }, { id: 12, name: 'چیزکیک', qty: 1, is_done: false, is_void: false }] },
  { id: 2, number: 42, order_number: 42, table_name: null, type: 'takeaway', status: 'preparing', station_id: 2, created_at: ago(25), items: [{ id: 21, name: 'آمریکانو', qty: 1, is_done: false, is_void: false }] },
  { id: 3, number: 43, order_number: 43, table_name: '۵', type: 'dine_in', status: 'ready', station_id: 1, created_at: ago(6), items: [{ id: 31, name: 'لاته', qty: 1, is_done: false, is_void: false }] },
  { id: 4, number: 40, order_number: 40, table_name: '۲', type: 'dine_in', status: 'done', station_id: 1, created_at: ago(60), items: [{ id: 41, name: 'اسپرسو', qty: 1, is_done: true, is_void: false }] },
]
const STATIONS = [{ id: 1, name: 'بار' }, { id: 2, name: 'قنادی' }]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => get.mockImplementation((path) => {
  if (path === '/kitchen/tickets') return Promise.resolve(TICKETS)
  if (path === '/menu/stations') return Promise.resolve(STATIONS)
  return Promise.resolve([])
})
const page = () => render(<MemoryRouter><App><KdsPage /></App></MemoryRouter>)

describe('Kitchen display (KDS)', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond(); localStorage.clear() })

  it('shows the open tickets with their items and table', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    expect(text()).toContain('اسپرسو')
    expect(text()).toContain('میز ۳')
    expect(text()).toContain('آمریکانو')
  })

  it('hides finished and voided tickets from the live board', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    expect(text()).not.toContain('#۴۰')          // done
  })

  it('marks a ticket that has been waiting longer than the configured limit', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۲'))
    expect(document.querySelectorAll('.t-late, .late').length).toBeGreaterThan(0)
  })

  it('filters to one station and remembers it on the device', async () => {
    page()
    await waitFor(() => expect(text()).toContain('بار'))
    const chip = [...document.querySelectorAll('button, .ant-segmented-item')].find((b) => b.textContent.includes('قنادی'))
    fireEvent.click(chip)
    await waitFor(() => expect(localStorage.getItem('kds_station')).toBeTruthy())
    expect(text()).toContain('آمریکانو')
    expect(text()).not.toContain('#۴۱')
  })

  it('bumps a ticket to done through the API', async () => {
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    const done = [...document.querySelectorAll('button')].find((b) => /تحویل|تمام|آماده/.test(b.textContent))
    fireEvent.click(done)
    await waitFor(() => expect(post).toHaveBeenCalled())
    expect(post.mock.calls[0][0]).toMatch(/\/kitchen\/tickets\/\d+\/(bump|items\/\d+\/toggle|status)/)
  })

  it('switches to the history view', async () => {
    page()
    await waitFor(() => expect(text()).toContain('#۴۱'))
    get.mockClear()
    const hist = document.querySelector('.kds-btn.ant-btn') && [...document.querySelectorAll('.kds-btn')].find((b) => b.querySelector('[data-icon="history"]'))
    fireEvent.click(hist)
    await waitFor(() => expect(get.mock.calls.some(([p, q]) => p === '/kitchen/tickets' && q?.include_done)).toBe(true))
  })
})

// ---------------------------------------------------------------- render storm (freeze)
describe('Kitchen display — render cost', () => {
  it('runs ONE timer for the whole board, not one per ticket', async () => {
    const many = Array.from({ length: 12 }, (_, k) => ({
      id: 100 + k, order_number: 100 + k, table_name: String(k + 1), order_type: 'dine_in', status: 'preparing',
      station_id: 1, created_at: new Date(Date.now() - (k + 1) * 60000).toISOString(),
      items: [{ id: 1000 + k, name: 'اسپرسو', qty: 1, is_done: false, is_void: false }],
    }))
    get.mockImplementation((path) => (path === '/kitchen/tickets' ? Promise.resolve(many) : Promise.resolve(STATIONS)))
    const spy = vi.spyOn(globalThis, 'setInterval')
    page()
    await waitFor(() => expect(document.querySelectorAll('.kds-ticket').length).toBe(12))
    const oneSecondTimers = spy.mock.calls.filter(([, ms]) => ms === 1000).length
    spy.mockRestore()
    // 12 tickets must not mean 12 re-rendering tickers every second
    expect(oneSecondTimers).toBeLessThanOrEqual(1)
  })
})
