import { CheckOutlined, LeftOutlined, PhoneOutlined, PlusOutlined, RightOutlined, UserAddOutlined } from '@ant-design/icons'
import { App, Button, Card, Col, Drawer, Empty, Form, Input, InputNumber, Modal, Row, Segmented, Select, Space, Table, Tag, TimePicker, Tooltip, Typography } from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { useEffect, useMemo, useState } from 'react'
import { PageHeader, StatCard } from '../../components/common'
import { get, post, put } from '../../core/api'
import { faDate, faTime, faWeekday, isoDate, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useRealtime } from '../../core/realtime'
import { useFetch } from '../../core/useFetch'

export const R_STATUS = {
  booked: { label: 'ثبت‌شده', color: 'var(--hero-base)', tag: 'blue' }, confirmed: { label: 'تأییدشده', color: 'var(--info-solid)', tag: 'cyan' },
  seated: { label: 'حاضر/نشسته', color: 'var(--ok-solid)', tag: 'green' }, completed: { label: 'پایان‌یافته', color: 'var(--muted-solid)', tag: 'default' },
  no_show: { label: 'نیامد', color: 'var(--bad-solid)', tag: 'red' }, cancelled: { label: 'لغوشده', color: 'var(--muted-solid)', tag: 'default' },
}
const SOURCES = { phone: '📞 تلفنی', walk_in: '🚶 حضوری', online: '🌐 آنلاین', instagram: '📷 اینستاگرام' }
const START_H = 10
const END_H = 24
const SPAN = (END_H - START_H) * 60
const addDays = (iso, n) => { const d = new Date(`${iso}T00:00:00`); d.setDate(d.getDate() + n); return isoDate(d) }
const toLocalIso = (d, t) => `${isoDate(d.toDate())}T${t.format('HH:mm')}:00`
const minsOf = (dt) => { const d = new Date(dt); return d.getHours() * 60 + d.getMinutes() - START_H * 60 }

function ReservationForm({ value, day, onClose, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const [avail, setAvail] = useState([])
  const editing = !!value?.id
  const date = Form.useWatch('date', form)
  const time = Form.useWatch('time', form)
  const guests = Form.useWatch('guests', form)
  const duration = Form.useWatch('duration', form)
  const tableId = Form.useWatch('table_id', form)
  useEffect(() => {
    if (!date || !time) return
    get('/reservations/availability', { start_at: toLocalIso(date, time), guests: guests || 2, duration: duration || 90, exclude: value?.id }).then(setAvail).catch(() => {})
  }, [date, time, guests, duration, value?.id])
  const init = editing
    ? { ...value, date: dayjs(value.start_at), time: dayjs(value.start_at) }
    : { date: dayjs(`${day}T12:00:00`), time: value?.time ? dayjs(value.time) : dayjs().add(1, 'hour').minute(0), guests: 2, duration: 90, source: 'phone', deposit: 0, table_id: value?.table_id }
  const submit = async (v) => {
    setBusy(true)
    try {
      const body = { ...v, start_at: toLocalIso(v.date, v.time), table_id: v.table_id || null }
      delete body.date; delete body.time
      if (editing) await put(`/reservations/${value.id}`, body); else await post('/reservations', body)
      message.success('رزرو ذخیره شد'); onDone()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open title={editing ? 'ویرایش رزرو' : 'رزرو جدید'} width={640} onCancel={onClose} onOk={() => form.submit()} okText="ذخیره رزرو" confirmLoading={busy} destroyOnClose>
      <JalaliLocaleListener />
      <Form form={form} layout="vertical" onFinish={submit} initialValues={init}>
        <Row gutter={12}>
          <Col span={12}><Form.Item name="customer_name" label="نام مهمان" rules={[{ required: true, min: 2 }]}><Input /></Form.Item></Col>
          <Col span={12}><Form.Item name="phone" label="موبایل"><Input className="ltr" inputMode="tel" /></Form.Item></Col>
          <Col span={8}><Form.Item name="date" label="تاریخ" rules={[{ required: true }]}><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" allowClear={false} /></Form.Item></Col>
          <Col span={5}><Form.Item name="time" label="ساعت" rules={[{ required: true }]}><TimePicker format="HH:mm" minuteStep={15} style={{ width: '100%' }} allowClear={false} needConfirm={false} /></Form.Item></Col>
          <Col span={5}><Form.Item name="guests" label="نفرات" rules={[{ required: true }]}><InputNumber min={1} max={200} style={{ width: '100%' }} /></Form.Item></Col>
          <Col span={6}><Form.Item name="duration" label="مدت (دقیقه)"><Select options={[60, 90, 120, 150, 180, 240].map((m) => ({ value: m, label: num(m) }))} /></Form.Item></Col>
        </Row>
        <Form.Item name="table_id" hidden><InputNumber /></Form.Item>
        <Form.Item label="میز (موارد خط‌خورده در این ساعت رزرو دارند · خط‌چین = ظرفیت کمتر)" style={{ marginBottom: 12 }}>
          <div className="av-grid">
            <button type="button" className={`av-btn ${!tableId ? 'on' : ''}`} onClick={() => form.setFieldValue('table_id', null)}><b>بعداً</b>بدون میز</button>
            {avail.map((a) => (
              <Tooltip key={a.id} title={a.clash ? `رزرو: ${a.clash}` : !a.fits ? 'ظرفیت کمتر از تعداد نفرات' : a.area}>
                <button type="button" disabled={!a.free} className={`av-btn ${tableId === a.id ? 'on' : ''} ${!a.free ? 'busy' : ''} ${!a.fits ? 'small' : ''}`}
                  onClick={() => form.setFieldValue('table_id', a.id)}><b>{a.name}</b>{num(a.seats)} نفره</button>
              </Tooltip>
            ))}
          </div>
        </Form.Item>
        <Row gutter={12}>
          <Col span={8}><Form.Item name="source" label="نحوه رزرو"><Select options={Object.entries(SOURCES).map(([value, label]) => ({ value, label }))} /></Form.Item></Col>
          <Col span={8}><Form.Item name="occasion" label="مناسبت"><Select allowClear options={['تولد 🎂', 'سالگرد ازدواج 💍', 'جلسه کاری 💼', 'خواستگاری 💐', 'دورهمی 🎉'].map((v) => ({ value: v, label: v }))} /></Form.Item></Col>
          <Col span={8}><Form.Item name="deposit" label="بیعانه (تومان)"><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
        </Row>
        <Form.Item name="note" label="یادداشت (میز کنار پنجره، صندلی کودک، حساسیت غذایی...)"><Input.TextArea rows={2} /></Form.Item>
      </Form>
    </Modal>
  )
}

function Timeline({ data, onPick, onNew }) {
  const isToday = data.day === isoDate(new Date())
  const nowM = minsOf(new Date())
  const pct = (m) => `${Math.max(0, Math.min(100, (m / SPAN) * 100))}%`
  const byTable = useMemo(() => {
    const m = {}
    for (const r of data.items) if (r.table_id) (m[r.table_id] = m[r.table_id] || []).push(r)
    return m
  }, [data])
  const unassigned = data.items.filter((r) => !r.table_id && !['cancelled', 'no_show'].includes(r.status))
  const grid = { backgroundSize: `calc(100% / ${END_H - START_H}) 100%` }
  const clickTrack = (e, table) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const m = Math.round((((rect.right - e.clientX) / rect.width) * SPAN) / 15) * 15 + START_H * 60
    onNew({ table_id: table.id, time: `${data.day}T${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}:00` })
  }
  return (
    <div className="tl-wrap">
      <div className="tl">
        <div className="tl-head">
          <div className="tl-label" style={{ fontSize: 12 }}>میز</div>
          <div className="tl-hours">
            {Array.from({ length: END_H - START_H }, (_, i) => <span key={i} className="tl-hour" style={{ right: pct(i * 60) }}>{num(START_H + i)}:۰۰</span>)}
          </div>
        </div>
        {data.areas.map((a) => (
          <div key={a.id}>
            <div className="tl-area">{a.name}</div>
            {a.tables.map((t) => (
              <div key={t.id} className="tl-row">
                <div className="tl-label">{t.name}<small>{num(t.seats)} نفره</small></div>
                <div className="tl-track" style={grid} onClick={(e) => clickTrack(e, t)}>
                  {isToday && nowM > 0 && nowM < SPAN && <div className="tl-now" style={{ right: pct(nowM) }} />}
                  {(byTable[t.id] || []).map((r) => {
                    const s = minsOf(r.start_at)
                    const st = R_STATUS[r.status]
                    return (
                      <Tooltip key={r.id} title={<div>{r.customer_name} · {num(r.guests)} نفر<br />{faTime(r.start_at)} تا {faTime(r.end_at)}{r.occasion ? <><br />{r.occasion}</> : null}{r.note ? <><br />📝 {r.note}</> : null}</div>}>
                        <div className={`tl-block ${r.late ? 'late' : ''} ${['cancelled', 'no_show', 'completed'].includes(r.status) ? 'dim' : ''}`}
                          style={{ right: pct(s), width: `calc(${pct(Math.min(r.duration, SPAN - s))} - 3px)`, background: st.color }}
                          onClick={(e) => { e.stopPropagation(); onPick(r) }}>
                          <b>{faTime(r.start_at)}</b> {r.customer_name} · {num(r.guests)}👤 {r.occasion?.slice(-2)}
                        </div>
                      </Tooltip>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
      {unassigned.length > 0 && (
        <div style={{ padding: 12, borderTop: '1px solid var(--border)' }}>
          <Typography.Text strong>بدون میز: </Typography.Text>
          {unassigned.map((r) => <Tag key={r.id} color="orange" style={{ cursor: 'pointer' }} onClick={() => onPick(r)}>{faTime(r.start_at)} {r.customer_name} ({num(r.guests)})</Tag>)}
        </div>
      )}
    </div>
  )
}

function Waitlist({ tables }) {
  const { message } = App.useApp()
  const { data, reload } = useFetch('/reservations/waitlist')
  const [adding, setAdding] = useState(false)
  const [seat, setSeat] = useState(null)
  const [form] = Form.useForm()
  useRealtime(['reservation.changed'], () => reload(true))
  const act = async (w, status, extra = {}) => { try { await post(`/reservations/waitlist/${w.id}/status`, { status, ...extra }); reload(true); setSeat(null) } catch (e) { message.error(e.message) } }
  const add = async (v) => { try { await post('/reservations/waitlist', v); form.resetFields(); setAdding(false); reload(true) } catch (e) { message.error(e.message) } }
  const active = (data || []).filter((w) => ['waiting', 'notified'].includes(w.status))
  return (
    <Card className="card-r" title={<span>لیست انتظار <Tag color="gold">{num(active.length)}</Tag></span>} extra={<Button size="small" icon={<UserAddOutlined />} onClick={() => setAdding(true)}>افزودن</Button>}>
      {!active.length && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="کسی در صف انتظار نیست" />}
      {active.map((w, i) => (
        <div key={w.id} className={`wl-item ${w.status}`}>
          <div className="wl-num">{num(i + 1)}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <b>{w.customer_name}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>· {num(w.guests)} نفر</Typography.Text>
            <div style={{ fontSize: 12, color: w.waited > w.quoted_minutes ? 'var(--red)' : 'var(--muted)' }}>
              {num(w.waited)} دقیقه انتظار (وعده: {num(w.quoted_minutes)}′){w.status === 'notified' && ' · خبر داده شد'}
            </div>
          </div>
          <Space size={2}>
            {w.phone && <Tooltip title={w.phone}><Button size="small" type="text" icon={<PhoneOutlined />} href={`tel:${w.phone}`} /></Tooltip>}
            {w.status === 'waiting' && <Button size="small" onClick={() => act(w, 'notified')}>خبر بده</Button>}
            <Button size="small" type="primary" onClick={() => setSeat(w)}>نشاندن</Button>
            <Button size="small" type="text" danger onClick={() => act(w, 'left')}>رفت</Button>
          </Space>
        </div>
      ))}
      <Modal open={adding} title="افزودن به لیست انتظار" onCancel={() => setAdding(false)} onOk={() => form.submit()} destroyOnClose>
        <Form form={form} layout="vertical" onFinish={add} initialValues={{ guests: 2, quoted_minutes: 15 }}>
          <Form.Item name="customer_name" label="نام" rules={[{ required: true, min: 2 }]}><Input autoFocus /></Form.Item>
          <Row gutter={12}>
            <Col span={8}><Form.Item name="guests" label="نفرات"><InputNumber min={1} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={8}><Form.Item name="quoted_minutes" label="زمان تخمینی (دقیقه)"><InputNumber min={0} style={{ width: '100%' }} /></Form.Item></Col>
            <Col span={8}><Form.Item name="phone" label="موبایل"><Input className="ltr" /></Form.Item></Col>
          </Row>
          <Form.Item name="note" label="یادداشت"><Input /></Form.Item>
        </Form>
      </Modal>
      <Modal open={!!seat} title={`نشاندن ${seat?.customer_name || ''} (${num(seat?.guests || 0)} نفر)`} footer={null} onCancel={() => setSeat(null)}>
        <Typography.Paragraph type="secondary">یک میز آزاد انتخاب کنید؛ سفارش میز به‌صورت خودکار باز می‌شود.</Typography.Paragraph>
        <div className="av-grid">
          {tables.filter((t) => t.status === 'free').map((t) => (
            <button type="button" key={t.id} className={`av-btn ${t.seats < (seat?.guests || 0) ? 'small' : ''}`} onClick={() => act(seat, 'seated', { table_id: t.id })}><b>{t.name}</b>{num(t.seats)} نفره</button>
          ))}
        </div>
      </Modal>
    </Card>
  )
}

export default function Reservations() {
  const { message } = App.useApp()
  const [day, setDay] = useState(isoDate(new Date()))
  const [view, setView] = useState('timeline')
  const [form, setForm] = useState(null)
  const [pick, setPick] = useState(null)
  const { data, loading, reload } = useFetch('/reservations', { day })
  const floor = useFetch('/orders/floor')
  useRealtime(['reservation.changed', 'floor.changed'], () => { reload(true); floor.reload(true) })
  const tables = (floor.data || []).flatMap((a) => a.tables)
  const setStatus = async (r, status) => {
    try {
      const res = await post(`/reservations/${r.id}/status`, { status })
      message.success(status === 'seated' && res.order_id ? 'مهمان نشست و سفارش میز باز شد' : 'وضعیت به‌روز شد')
      setPick(null); reload(true); floor.reload(true)
    } catch (e) { message.error(e.message) }
  }
  const s = data?.stats || {}
  return (
    <div className="fade-in">
      <PageHeader title="رزرو میز" subtitle="تقویم روزانه میزها؛ برای رزرو سریع روی فضای خالی ردیف میز کلیک کنید"
        extra={[<Segmented key="v" value={view} onChange={setView} options={[{ value: 'timeline', label: 'جدول زمانی' }, { value: 'list', label: 'فهرست' }]} />,
          <Button key="n" type="primary" icon={<PlusOutlined />} onClick={() => setForm({})}>رزرو جدید</Button>]} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xxl={18}>
          <Card className="card-r" styles={{ body: { padding: 16 } }}>
            <div className="rv-toolbar" style={{ marginBottom: 14, justifyContent: 'space-between' }}>
              <Space wrap>
                <Button icon={<RightOutlined />} onClick={() => setDay(addDays(day, -1))} />
                <div className="rv-day">{faWeekday(day)} {faDate(day)}</div>
                <Button icon={<LeftOutlined />} onClick={() => setDay(addDays(day, 1))} />
                <Button onClick={() => setDay(isoDate(new Date()))}>امروز</Button>
                <JalaliLocaleListener />
                <JDatePicker value={dayjs(`${day}T12:00:00`)} onChange={(d) => d && setDay(isoDate(d.toDate()))} allowClear={false} format="YYYY/MM/DD" style={{ width: 130 }} />
              </Space>
              <Space wrap size={4}>{Object.entries(R_STATUS).slice(0, 4).map(([k, v]) => <Tag key={k} color={v.tag}>{v.label}</Tag>)}</Space>
            </div>
            <Row gutter={[12, 12]} style={{ marginBottom: 14 }}>
              <Col xs={12} md={6}><StatCard loading={loading} title="رزروها" value={s.count} icon={<span>📅</span>} color="var(--pal-1)" /></Col>
              <Col xs={12} md={6}><StatCard loading={loading} title="مهمانان" value={s.guests} icon={<span>👥</span>} color="var(--blue)" /></Col>
              <Col xs={12} md={6}><StatCard loading={loading} title="در انتظار ورود" value={s.upcoming} icon={<span>⏳</span>} color="var(--amber)" /></Col>
              <Col xs={12} md={6}><StatCard loading={loading} title="نیامدند" value={s.no_show} icon={<span>🚫</span>} color="var(--red)" /></Col>
            </Row>
            {data && view === 'timeline' && <Timeline data={data} onPick={setPick} onNew={(v) => setForm(v)} />}
            {data && view === 'list' && (
              <Table rowKey="id" dataSource={data.items} pagination={false} scroll={{ x: 760 }} onRow={(r) => ({ onClick: () => setPick(r), style: { cursor: 'pointer' } })}
                columns={[
                  { title: 'ساعت', dataIndex: 'start_at', render: (v, r) => <b style={{ color: r.late ? 'var(--red)' : undefined }}>{faTime(v)}</b>, width: 80 },
                  { title: 'مهمان', render: (_, r) => <div><b>{r.customer_name}</b> {r.occasion && <Tag>{r.occasion}</Tag>}<div className="ltr" style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'right' }}>{r.phone}</div></div> },
                  { title: 'نفرات', dataIndex: 'guests', render: (v) => num(v) },
                  { title: 'میز', dataIndex: 'table', render: (v) => v || <Tag color="orange">تعیین نشده</Tag> },
                  { title: 'منبع', dataIndex: 'source', render: (v) => SOURCES[v] },
                  { title: 'وضعیت', dataIndex: 'status', render: (v, r) => <><Tag color={R_STATUS[v].tag}>{R_STATUS[v].label}</Tag>{r.late && <Tag color="red">تأخیر</Tag>}</> },
                ]} />
            )}
          </Card>
        </Col>
        <Col xs={24} xxl={6}><Waitlist tables={tables} /></Col>
      </Row>
      {form && <ReservationForm value={form} day={day} onClose={() => setForm(null)} onDone={() => { setForm(null); reload(true) }} />}
      <Drawer open={!!pick} onClose={() => setPick(null)} width={Math.min(420, window.innerWidth)} title={pick && <span>{pick.customer_name} <Tag color={R_STATUS[pick.status].tag}>{R_STATUS[pick.status].label}</Tag></span>}>
        {pick && (<>
          <div className="kpi-mini"><span>زمان</span><b>{faWeekday(pick.start_at)} {faDate(pick.start_at)} — {faTime(pick.start_at)} تا {faTime(pick.end_at)}</b></div>
          <div className="kpi-mini"><span>نفرات</span><b>{num(pick.guests)} نفر</b></div>
          <div className="kpi-mini"><span>میز</span><b>{pick.table || 'تعیین نشده'}</b></div>
          {pick.phone && <div className="kpi-mini"><span>موبایل</span><a className="ltr" href={`tel:${pick.phone}`}>{pick.phone}</a></div>}
          <div className="kpi-mini"><span>نحوه رزرو</span><span>{SOURCES[pick.source]}</span></div>
          {pick.occasion && <div className="kpi-mini"><span>مناسبت</span><span>{pick.occasion}</span></div>}
          {pick.deposit > 0 && <div className="kpi-mini"><span>بیعانه</span><b>{money(pick.deposit)} تومان</b></div>}
          {pick.note && <div className="kpi-mini"><span>یادداشت</span><span>{pick.note}</span></div>}
          {pick.late && <Typography.Text type="danger" style={{ display: 'block', marginTop: 10 }}>⚠ مهمان بیش از ۱۵ دقیقه تأخیر دارد.</Typography.Text>}
          <Space wrap style={{ marginTop: 20 }}>
            {pick.status === 'booked' && <Button icon={<CheckOutlined />} onClick={() => setStatus(pick, 'confirmed')}>تأیید (تماس گرفته شد)</Button>}
            {['booked', 'confirmed'].includes(pick.status) && <Button type="primary" style={{ background: 'var(--ok-solid)', color: '#fff' }} onClick={() => setStatus(pick, 'seated')}>مهمان رسید — نشاندن و باز کردن میز</Button>}
            {pick.status === 'seated' && <Button onClick={() => setStatus(pick, 'completed')}>پایان</Button>}
            {['booked', 'confirmed'].includes(pick.status) && <Button onClick={() => { setForm(pick); setPick(null) }}>ویرایش</Button>}
            {['booked', 'confirmed'].includes(pick.status) && <Button danger onClick={() => setStatus(pick, 'no_show')}>نیامد</Button>}
            {['booked', 'confirmed'].includes(pick.status) && <Button danger type="text" onClick={() => setStatus(pick, 'cancelled')}>لغو رزرو</Button>}
          </Space>
        </>)}
      </Drawer>
    </div>
  )
}
