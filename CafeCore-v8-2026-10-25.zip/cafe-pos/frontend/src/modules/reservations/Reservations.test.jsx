import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Reservations: the day's stats, and the status changes a host taps all evening (seated → no-show).
// "Seated" is the one that can open a table order, so it must send the right status for the right id.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('../../core/realtime', () => ({ useRealtime: () => {}, useWsStatus: () => 'online', beep: () => {} }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: Reservations } = await import('./Reservations')

const FLOOR = [{ id: 1, name: 'سالن اصلی', tables: [{ id: 1, name: 'میز ۱' }, { id: 2, name: 'میز ۲' }] }]
const DAY = {
  stats: { count: 6, guests: 19, seated: 2, no_show: 1, upcoming: 3 },
  areas: FLOOR,                                  // the timeline needs areas → tables → reservations
  items: [
    { id: 31, customer_name: 'خانم رضایی', phone: '09121234567', start_at: '2026-10-23T19:30:00', guests: 4, table_id: 1, table_name: 'میز ۱', status: 'booked', duration: 90, note: 'تولد' },
    { id: 32, customer_name: 'آقای محمدی', phone: '09127654321', start_at: '2026-10-23T20:00:00', guests: 2, table_id: 2, table_name: 'میز ۲', status: 'seated', duration: 60, note: null },
  ],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/reservations') return Promise.resolve(DAY)
    if (path === '/orders/floor') return Promise.resolve(FLOOR)
    if (path === '/reservations/waitlist') return Promise.resolve([])
    return Promise.resolve([])
  })
}
const page = () => render(<App><Reservations /></App>)

describe('Reservations', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('shows the day stats and both views', async () => {
    page()
    await waitFor(() => expect(text()).toContain('رزروها'))
    expect(text()).toContain('۶')                  // count
    expect(text()).toContain('۱۹')                 // guests
    expect(screen.getByText('جدول زمانی')).toBeTruthy()
    expect(screen.getByText('فهرست')).toBeTruthy()
  })

  it('asks the server for the selected day', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/reservations', { day: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) }))
  })

  it('moves to another day and refetches it', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/reservations', { day: expect.any(String) }))
    const dayCalls = () => get.mock.calls.filter(([p]) => p === '/reservations')
    const firstDay = dayCalls().at(-1)[1].day
    const buttons = [...document.querySelectorAll('.rv-toolbar button')]
    await user().click(buttons[0])                 // the previous-day arrow
    await waitFor(() => expect(dayCalls().at(-1)[1].day).not.toBe(firstDay))
  })

  it('shows the reservation list with name, guests and table', async () => {
    page()
    await user().click(screen.getByText('فهرست'))
    await waitFor(() => expect(text()).toContain('خانم رضایی'))
    expect(text()).toContain('آقای محمدی')
  })

  it('opens the new-reservation form without saving anything', async () => {
    page()
    await waitFor(() => expect(text()).toContain('رزرو جدید'))
    await user().click(screen.getByRole('button', { name: /رزرو جدید/ }))
    await waitFor(() => expect(document.querySelector('.ant-modal, .ant-drawer')).toBeTruthy())
    expect(post).not.toHaveBeenCalled()
  })
})
