import { BellOutlined, FileTextOutlined, InstagramOutlined, PhoneOutlined, WifiOutlined } from '@ant-design/icons'
import { App, Button, Empty, Input, Spin, Tag } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../../core/api'
import { money } from '../../core/format'
import OrderApp from '../online/OrderApp'

/** Public digital menu (no login). Opened by scanning the QR code on a table: /menu/<table-token> */
export default function QrMenu() {
  const { token } = useParams()
  const { message } = App.useApp()
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [q, setQ] = useState('')
  const [activeCat, setActiveCat] = useState(null)
  const [sending, setSending] = useState(null)
  const refs = useRef({})
  const [ordering, setOrdering] = useState(token ? null : false)

  useEffect(() => {
    // when the online module is on and QR ordering is enabled, guests get the full ordering experience
    if (!token) return
    api('/online/public/info', { params: { table: token } }).then((i) => setOrdering(!!(i.qr_ordering && i.table))).catch(() => setOrdering(false))
  }, [token])

  useEffect(() => {
    api('/public/menu', { params: { table: token } }).then(setData).catch((e) => setError(e.message))
    document.documentElement.dataset.theme = 'light'
  }, [token])

  const grouped = useMemo(() => {
    if (!data) return []
    const items = data.items.filter((i) => !q || i.name.includes(q) || (i.description || '').includes(q))
    return data.categories.map((c) => ({ ...c, items: items.filter((i) => i.category_id === c.id) })).filter((c) => c.items.length)
  }, [data, q])

  const call = async (kind) => {
    setSending(kind)
    try {
      await api('/public/call', { method: 'POST', body: { token, kind } })
      message.success(kind === 'bill' ? 'درخواست صورتحساب ارسال شد 🧾' : 'گارسون به‌زودی خدمت می‌رسد 🙋')
    } catch (e) { message.error(e.message) } finally { setSending(null) }
  }

  if (ordering) return <OrderApp table={token} />
  if (error) return <div className="center-screen"><Empty description={error} /></div>
  if (!data || ordering === null) return <div className="center-screen"><Spin size="large" /></div>
  const b = data.business

  return (
    <div className="qr">
      <div className="qr-hero">
        <div className="qr-logo">{b.logo ? <img src={b.logo} alt="" /> : '☕'}</div>
        <h1 style={{ margin: 0, fontSize: 24 }}>{b.name}</h1>
        {data.table && <div className="qr-table">میز {data.table.name}</div>}
        <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap', marginTop: 12, fontSize: 13, opacity: 0.9 }}>
          {b.wifi && <span><WifiOutlined /> {b.wifi}</span>}
          {b.phone && <a href={`tel:${b.phone}`} style={{ color: '#fff' }}><PhoneOutlined /> {b.phone}</a>}
          {b.instagram && <span className="ltr"><InstagramOutlined /> {b.instagram}</span>}
        </div>
      </div>
      <div className="qr-cats">
        {grouped.map((c) => (
          <button type="button" key={c.id} className={`cat-chip ${activeCat === c.id ? 'on' : ''}`} style={{ '--c': c.color }}
            onClick={() => { setActiveCat(c.id); refs.current[c.id]?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }}>{c.icon} {c.name}</button>
        ))}
      </div>
      <div style={{ padding: '0 14px' }}><Input.Search allowClear placeholder="جستجو در منو..." value={q} onChange={(e) => setQ(e.target.value)} size="large" /></div>
      {grouped.map((c) => (
        <section key={c.id} className="qr-section" ref={(el) => { refs.current[c.id] = el }} style={{ scrollMarginTop: 64 }}>
          <h3>{c.icon} {c.name}</h3>
          {c.items.map((i) => (
            <div key={i.id} className={`qr-item ${i.is_available ? '' : 'off'}`}>
              <div className="qr-item-img">{i.image ? <img src={i.image} alt="" loading="lazy" /> : c.icon}</div>
              <div className="qr-item-body">
                <b>{i.name} {i.tags?.split(',').filter(Boolean).map((t) => <Tag key={t} color="volcano" style={{ marginInlineStart: 6 }}>{t}</Tag>)}</b>
                {i.description && <div className="qr-item-desc">{i.description}</div>}
                {i.options?.length > 0 && <div className="qr-item-desc">{i.options.map((g) => g.group).join(' · ')}</div>}
                <div className="qr-item-price">{i.is_available ? `${money(i.price)} ${b.currency}` : 'ناموجود'}</div>
              </div>
            </div>
          ))}
        </section>
      ))}
      {b.tax_percent > 0 && <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>قیمت‌ها بدون احتساب {b.tax_percent.toLocaleString('fa-IR')}٪ مالیات بر ارزش افزوده است</p>}
      {b.call_enabled && (
        <div className="qr-actions">
          <Button size="large" type="primary" icon={<BellOutlined />} block loading={sending === 'waiter'} onClick={() => call('waiter')} style={{ height: 50 }}>صدا زدن گارسون</Button>
          <Button size="large" icon={<FileTextOutlined />} block loading={sending === 'bill'} onClick={() => call('bill')} style={{ height: 50 }}>درخواست صورتحساب</Button>
        </div>
      )}
    </div>
  )
}
