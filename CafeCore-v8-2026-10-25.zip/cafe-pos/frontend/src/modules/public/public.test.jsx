import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { MemoryRouter, Route, Routes } from 'react-router-dom'

/**
 * The customer-facing screens (QR menu, online order page, order tracking). A guest has no account,
 * no training and one chance: these pages must render from the public API alone and never show a
 * blank screen, because a blank screen at the table is a lost order.
 */
const get = vi.fn()
const post = vi.fn()
// these screens call the low-level `api()` directly (they need POST + query in one place)
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: (path, opts) => (opts?.method && opts.method !== 'GET' ? post(path, opts.body) : get(path)),
  ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => null, setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => false, hasModule: () => false, user: null, settings: {}, system: {} }) }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const INFO = {
  enabled: true, accepting: true, pickup: true, delivery: true, min_order: 0,
  qr_ordering: true, notice: 'امروز کیک تازه داریم', zones: [{ id: 1, name: 'ونک', fee: 45_000, eta: 30, min_order: 200_000 }],
  table: { name: 'میز ۳' }, tax_percent: 10,
  business: { name: 'کافه ونک', phone: '02188776655', address: 'تهران', logo: null, currency: 'تومان', instagram: 'cafe', wifi: '1234' },
}
const MENU = {
  categories: [{ id: 1, name: 'قهوه گرم', icon: '☕', color: '#92400e' }],
  items: [
    { id: 11, category_id: 1, name: 'اسپرسو', description: 'تلخ', price: 140_000, image: null, is_available: true, tags: 'پرفروش', groups: [] },
    { id: 12, category_id: 1, name: 'آمریکانو', description: null, price: 160_000, image: null, is_available: false, tags: '', groups: [] },
  ],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const mockPublic = () => get.mockImplementation((path) => {
  if (path === '/online/public/info') return Promise.resolve(INFO)
  if (path === '/online/public/menu') return Promise.resolve(MENU)
  if (path.startsWith('/online/public/orders/')) return Promise.resolve({
    token: 'tok123', status: 'pending', items: [{ qty: 2, name: 'اسپرسو' }], subtotal: 280_000,
    delivery_fee: 0, total: 308_000, mode: 'pickup', business: INFO.business,
  })
  // the QR menu endpoint wraps the menu with the business block
  if (path === '/public/menu') return Promise.resolve({ ...MENU, business: INFO.business, table: INFO.table, call_enabled: true })
  return Promise.resolve([])
})

describe('customer-facing screens', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); mockPublic() })

  it('QR menu shows the business, the notice and the items', async () => {
    const { default: QrMenu } = await import('./QrMenu')
    render(<MemoryRouter initialEntries={['/menu/tok-table-1']}><App><Routes><Route path="/menu/:token?" element={<QrMenu />} /></Routes></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('کافه ونک')
    expect(text()).toContain('امروز کیک تازه داریم')
  })

  it('online order page lists the menu and marks the sold-out item', async () => {
    const { default: OrderApp } = await import('../online/OrderApp')
    render(<MemoryRouter initialEntries={['/order']}><App><Routes><Route path="/order" element={<OrderApp />} /></Routes></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('آمریکانو')          // shown, but not orderable
    expect(text()).toContain('۱۴۰٬۰۰۰')
  })

  it('tracking page renders the status of a placed order', async () => {
    const { default: Track } = await import('../online/Track')
    render(<MemoryRouter initialEntries={['/order/track/tok123']}><App><Routes><Route path="/order/track/:token" element={<Track />} /></Routes></App></MemoryRouter>)
    await waitFor(() => expect(text()).toContain('اسپرسو'))
    expect(text()).toContain('۳۰۸٬۰۰۰')
  })

  it('shows a clear message when online ordering is switched off', async () => {
    get.mockImplementation((path) => path === '/online/public/info'
      ? Promise.resolve({ ...INFO, enabled: false, accepting: false })
      : Promise.resolve(path === '/online/public/menu' ? MENU : []))
    const { default: OrderApp } = await import('../online/OrderApp')
    render(<MemoryRouter initialEntries={['/order']}><App><Routes><Route path="/order" element={<OrderApp />} /></Routes></App></MemoryRouter>)
    await waitFor(() => expect(document.body.textContent.length).toBeGreaterThan(20))
  })
})
