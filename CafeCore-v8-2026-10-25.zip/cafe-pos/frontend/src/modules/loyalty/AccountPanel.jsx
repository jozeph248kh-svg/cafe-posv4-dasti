import { MinusCircleOutlined, PlusCircleOutlined, SettingOutlined, SwapOutlined } from '@ant-design/icons'
import { App, Button, Col, Empty, Form, Input, InputNumber, Modal, Progress, Radio, Row, Segmented, Skeleton, Table, Tag, Tooltip, Typography } from 'antd'
import { useState } from 'react'
import { post, put } from '../../core/api'
import { useAuth } from '../../core/auth'
import { faDateTime, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'

export const WALLET_KIND = {
  topup: { label: 'شارژ', color: 'green' }, bonus: { label: 'هدیه شارژ', color: 'lime' }, pay: { label: 'پرداخت سفارش', color: 'blue' },
  refund: { label: 'برگشت', color: 'cyan' }, cashback: { label: 'کش‌بک', color: 'purple' }, adjust: { label: 'اصلاح دستی', color: 'orange' }, settle: { label: 'تسویه نسیه', color: 'gold' },
}
export const CREDIT_KIND = { sale: { label: 'خرید نسیه', color: 'red' }, settle: { label: 'تسویه', color: 'green' }, refund: { label: 'برگشت', color: 'cyan' }, adjust: { label: 'اصلاح دستی', color: 'orange' } }
const METHOD = { cash: 'نقد', card: 'کارتخوان', transfer: 'انتقال بانکی', wallet: 'کیف پول' }

export function TierTag({ tier, style }) {
  if (!tier) return null
  return <Tag style={{ background: `color-mix(in srgb, ${tier.color} 12%, var(--card))`, color: `color-mix(in srgb, ${tier.color} 62%, var(--text))`, borderColor: `color-mix(in srgb, ${tier.color} 40%, transparent)`, fontWeight: 700, ...style }}>{tier.key === 'vip' ? '👑' : '★'} {tier.name}</Tag>
}

function MoneyDialog({ mode, acc, onClose, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const conf = {
    topup: { title: 'شارژ کیف پول', url: 'topup', ok: 'شارژ', methods: ['cash', 'card', 'transfer'], presets: [200_000, 500_000, 1_000_000, 2_000_000] },
    settle: { title: 'تسویه بدهی نسیه', url: 'settle', ok: 'ثبت تسویه', methods: ['cash', 'card', 'transfer', ...(acc.wallet > 0 ? ['wallet'] : [])], presets: [acc.debt] },
  }[mode]
  const submit = async (v) => {
    setBusy(true)
    try {
      const r = await post(`/loyalty/customers/${acc.customer_id}/${conf.url}`, v)
      message.success(mode === 'topup' ? `کیف پول شارژ شد${r.bonus ? ` (+${money(r.bonus)} هدیه)` : ''}` : 'تسویه ثبت شد')
      onDone()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open title={`${conf.title} — ${acc.name}`} onCancel={onClose} onOk={() => form.submit()} okText={conf.ok} confirmLoading={busy} destroyOnClose>
      <Form form={form} layout="vertical" onFinish={submit} initialValues={{ method: 'cash', amount: mode === 'settle' ? acc.debt : undefined }}>
        <Form.Item name="amount" label="مبلغ (تومان)" rules={[{ required: true, message: 'مبلغ را وارد کنید' }]}
          extra={mode === 'settle' ? `بدهی فعلی: ${money(acc.debt)} تومان` : `موجودی فعلی: ${money(acc.wallet)} تومان`}>
          <InputNumber size="large" min={1} max={mode === 'settle' ? acc.debt : undefined} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} />
        </Form.Item>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: -8, marginBottom: 14 }}>
          {conf.presets.filter(Boolean).map((p) => <Button key={p} size="small" onClick={() => form.setFieldValue('amount', p)}>{money(p)}</Button>)}
        </div>
        <Form.Item name="method" label="روش دریافت">
          <Radio.Group optionType="button" buttonStyle="solid" options={conf.methods.map((m) => ({ value: m, label: METHOD[m] }))} />
        </Form.Item>
        <Form.Item name="note" label="توضیحات"><Input maxLength={200} /></Form.Item>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>دریافت نقدی به‌صورت «ورود وجه» در صندوق شیفت باز ثبت می‌شود.</Typography.Text>
      </Form>
    </Modal>
  )
}

function AdjustDialog({ acc, onClose, onDone }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const submit = async (v) => {
    try {
      if (v.target === 'limit') await put(`/loyalty/customers/${acc.customer_id}/limit`, { credit_limit: v.limit_mode === 'default' ? null : v.limit ?? 0 })
      else await post(`/loyalty/customers/${acc.customer_id}/adjust`, { target: v.target, amount: v.sign * v.amount, reason: v.reason })
      message.success('ثبت شد'); onDone()
    } catch (e) { message.error(e.message) }
  }
  return (
    <Modal open title={`اصلاح حساب — ${acc.name}`} onCancel={onClose} onOk={() => form.submit()} destroyOnClose>
      <Form form={form} layout="vertical" onFinish={submit} initialValues={{ target: 'wallet', sign: 1, limit_mode: acc.credit_limit === null ? 'default' : 'custom', limit: acc.credit_limit }}>
        <Form.Item name="target"><Segmented block options={[{ value: 'wallet', label: 'کیف پول' }, { value: 'debt', label: 'بدهی نسیه' }, { value: 'limit', label: 'سقف نسیه' }]} /></Form.Item>
        <Form.Item noStyle shouldUpdate>{({ getFieldValue }) => getFieldValue('target') === 'limit' ? (<>
          <Form.Item name="limit_mode"><Radio.Group options={[{ value: 'default', label: 'پیش‌فرض تنظیمات' }, { value: 'custom', label: 'سقف اختصاصی' }]} /></Form.Item>
          {getFieldValue('limit_mode') === 'custom' && <Form.Item name="limit" label="سقف (تومان) — صفر یعنی نسیه ممنوع" rules={[{ required: true }]}><InputNumber min={0} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item>}
        </>) : (<>
          <Row gutter={8}>
            <Col span={9}><Form.Item name="sign" label="نوع"><Radio.Group optionType="button" options={[{ value: 1, label: 'افزایش' }, { value: -1, label: 'کاهش' }]} /></Form.Item></Col>
            <Col span={15}><Form.Item name="amount" label="مبلغ" rules={[{ required: true }]}><InputNumber min={1} style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} /></Form.Item></Col>
          </Row>
          <Form.Item name="reason" label="دلیل (در گزارش رویدادها ثبت می‌شود)" rules={[{ required: true, min: 3 }]}><Input /></Form.Item>
        </>)}</Form.Item>
      </Form>
    </Modal>
  )
}

/** Wallet / credit account of a customer with actions. Used in the club page and the customers drawer. */
export default function AccountPanel({ customerId, onChange }) {
  const auth = useAuth()
  const { data: a, loading, reload } = useFetch(`/loyalty/customers/${customerId}`)
  const [dlg, setDlg] = useState(null)
  const [tab, setTab] = useState('wallet')
  if (loading && !a) return <Skeleton active />
  if (!a) return <Empty />
  const done = () => { setDlg(null); reload(); onChange?.() }
  const canManage = auth.can('loyalty.manage')
  const nt = a.next_tier
  const progress = nt ? Math.min(100, Math.round(((a.total_spent - (a.tier?.min || 0)) / (nt.min - (a.tier?.min || 0))) * 100)) : 100
  const columns = (kinds) => [
    { title: 'زمان', dataIndex: 'created_at', render: faDateTime, width: 130 },
    { title: 'نوع', dataIndex: 'kind', render: (k, t) => <><Tag color={kinds[k]?.color}>{kinds[k]?.label || k}</Tag>{t.method && <Typography.Text type="secondary" style={{ fontSize: 11 }}>{METHOD[t.method]}</Typography.Text>}</> },
    { title: 'مبلغ', dataIndex: 'amount', render: (v) => <b className="money" style={{ color: v >= 0 ? 'var(--green)' : 'var(--red)' }}>{v > 0 ? '+' : ''}{money(v)}</b> },
    { title: 'مانده', dataIndex: 'balance', render: money },
    { title: 'شرح', render: (_, t) => <Tooltip title={t.by ? `توسط ${t.by}` : null}><span style={{ fontSize: 12 }}>{t.note}</span></Tooltip> },
  ]
  return (
    <div>
      <div className="acc-cards">
        <div className="acc-card wallet">
          <span>👛 کیف پول</span><b>{money(a.wallet)}</b><small>کش‌بک دریافتی تاکنون: {money(a.cashback_total)}</small>
          {canManage && <Button size="small" icon={<PlusCircleOutlined />} onClick={() => setDlg('topup')}>شارژ</Button>}
        </div>
        <div className={`acc-card debt ${a.debt > 0 ? 'has' : ''}`}>
          <span>📒 بدهی نسیه</span><b>{money(a.debt)}</b>
          <small>{a.credit_limit === 0 ? 'نسیه برای این مشتری ممنوع است' : a.effective_limit ? `سقف: ${money(a.effective_limit)}` : 'بدون سقف'}</small>
          {canManage && a.debt > 0 && <Button size="small" icon={<MinusCircleOutlined />} onClick={() => setDlg('settle')}>تسویه</Button>}
        </div>
      </div>
      <div className="tier-box">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>سطح عضویت: <TierTag tier={a.tier} /> <Typography.Text type="secondary" style={{ fontSize: 12 }}>کش‌بک {num(a.tier?.pct || 0)}٪</Typography.Text></span>
          {auth.can('loyalty.adjust') && <Button size="small" type="text" icon={<SettingOutlined />} onClick={() => setDlg('adjust')}>اصلاح حساب</Button>}
        </div>
        {nt ? (<>
          <Progress percent={progress} showInfo={false} strokeColor={{ from: a.tier?.color || 'var(--faint)', to: nt.color }} />
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>{money(nt.min - a.total_spent)} تومان خرید دیگر تا سطح <b style={{ color: nt.color }}>{nt.name}</b> (کش‌بک {num(nt.pct)}٪)</Typography.Text>
        </>) : <Typography.Text type="secondary" style={{ fontSize: 12 }}>بالاترین سطح باشگاه 🎉</Typography.Text>}
      </div>
      <Segmented value={tab} onChange={setTab} style={{ margin: '14px 0 8px' }} options={[{ value: 'wallet', label: `گردش کیف پول (${num(a.wallet_txns.length)})` }, { value: 'credit', label: <span><SwapOutlined /> حساب نسیه ({num(a.credit_txns.length)})</span> }]} />
      <Table size="small" rowKey="id" dataSource={tab === 'wallet' ? a.wallet_txns : a.credit_txns} columns={columns(tab === 'wallet' ? WALLET_KIND : CREDIT_KIND)}
        pagination={{ pageSize: 8, hideOnSinglePage: true, size: 'small' }} scroll={{ x: 520 }} locale={{ emptyText: 'تراکنشی ثبت نشده' }} />
      {(dlg === 'topup' || dlg === 'settle') && <MoneyDialog mode={dlg} acc={a} onClose={() => setDlg(null)} onDone={done} />}
      {dlg === 'adjust' && <AdjustDialog acc={a} onClose={() => setDlg(null)} onDone={done} />}
    </div>
  )
}
