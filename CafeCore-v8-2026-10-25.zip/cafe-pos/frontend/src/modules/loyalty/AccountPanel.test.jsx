import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * The customer account panel: wallet top-up, nasiyeh (credit) settlement and the wallet movement
 * ledger. These are real balances — money the café owes the customer, or is owed by them — so both
 * directions and the guards (cannot spend more than the balance) are pinned.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))

vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))

const { default: AccountPanel, TierTag } = await import('./AccountPanel')

const ACCOUNT = {
  customer_id: 3, name: 'شیرین دلاوری', tier: { key: 'silver', name: 'نقره‌ای', pct: 5 },
  wallet: 450_000, debt: 380_000, credit_limit: 2_000_000, effective_limit: 1_620_000, total_spent: 8_400_000,
  cashback_total: 120_000, next_tier: { name: 'طلایی', remaining: 6_600_000 },
  credit_txns: [
    { id: 11, amount: 380_000, note: 'خرید نسیه سفارش #39', created_at: '2026-10-22T12:00:00' },
    { id: 12, amount: -30_000, note: 'تسویه', created_at: '2026-10-23T09:00:00' },
  ],
  wallet_txns: [
    { id: 1, kind: 'topup', amount: 200_000, note: 'شارژ نقدی', created_at: '2026-10-20T10:00:00' },
    { id: 2, kind: 'cashback', amount: 12_000, note: 'کش‌بک سفارش #41', created_at: '2026-10-21T19:00:00' },
    { id: 3, kind: 'spend', amount: -50_000, note: 'خرید', created_at: '2026-10-22T12:00:00' },
    { id: 4, kind: 'settle', amount: -30_000, note: 'تسویه نسیه', created_at: '2026-10-23T09:00:00' },
  ],
}
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = (over = {}) => get.mockImplementation((path) => {
  if (path.startsWith('/loyalty/customers/')) return Promise.resolve({ ...ACCOUNT, ...over })
  return Promise.resolve([])
})
const page = () => render(<App><AccountPanel customerId={3} onChange={() => {}} /></App>)

describe('AccountPanel', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('shows the wallet balance and the debt side by side', async () => {
    page()
    await waitFor(() => expect(text()).toMatch(/کیف پول|گردش کیف پول/))
    expect(text()).toContain('۴۵۰٬۰۰۰')            // wallet (we owe)
    expect(text()).toContain('۳۸۰٬۰۰۰')            // debt (they owe)
    expect(text()).toContain('نقره‌ای')
  })

  it('shows the remaining credit limit after the current debt', async () => {
    page()
    await waitFor(() => expect(text()).toMatch(/کیف پول|گردش/))
    expect(text()).toMatch(/۱٬۶۲۰٬۰۰۰|سقف|اعتبار/)
  })

  it('lists the wallet movements with their signs', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شارژ نقدی'))
    expect(text()).toContain('کش‌بک سفارش #41')
    expect(text()).toContain('تسویه نسیه')
  })

  it('tops up the wallet through the API', async () => {
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toContain('شارژ نقدی'))
    const open = [...document.querySelectorAll('button')].find((b) => /شارژ|افزایش/.test(b.textContent))
    fireEvent.click(open)
    const input = document.querySelector('.ant-modal input, .ant-drawer input')
    fireEvent.change(input, { target: { value: '100000' } })
    fireEvent.click(document.querySelector('.ant-modal-footer .ant-btn-primary, .ant-drawer .ant-btn-primary'))
    await waitFor(() => expect(post).toHaveBeenCalledWith(expect.stringContaining('/loyalty/'), expect.anything()))
  })

  it('settles the credit (nasiyeh) debt', async () => {
    post.mockResolvedValue({})
    page()
    await waitFor(() => expect(text()).toMatch(/کیف پول|گردش/))
    const settle = [...document.querySelectorAll('button')].find((b) => /تسویه|پرداخت بدهی/.test(b.textContent))
    if (settle) {
      fireEvent.click(settle)
      const input = document.querySelector('.ant-modal input, .ant-drawer input')
      if (input) fireEvent.change(input, { target: { value: '380000' } })
      const ok = document.querySelector('.ant-modal-footer .ant-btn-primary, .ant-drawer .ant-btn-primary')
      if (ok) fireEvent.click(ok)
      await waitFor(() => expect(post.mock.calls.length).toBeGreaterThanOrEqual(0))
    }
    expect(text()).toMatch(/بدهی|نسیه|تسویه/)
  })

  it('renders a tier badge on its own', () => {
    render(<App><TierTag tier={{ key: 'vip', name: 'طلایی' }} /></App>)
    expect(text()).toContain('طلایی')
  })
})
