import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { App } from 'antd'

// Loyalty club: the wallet is real money the café owes the customer, and "debt" is money owed to the
// café. Both are shown on the dashboard cards, so a mis-mapped field here is a wrong balance at the
// counter. The table + filters are pinned; AccountPanel (the drawer) has its own behaviour.
const user = () => userEvent.setup({ delay: null })
const get = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => true, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})
vi.mock('./AccountPanel', () => ({
  default: ({ customerId }) => <div>ACCOUNT-PANEL-{customerId}</div>,
  TierTag: ({ tier }) => <span className="tier-tag">{tier || '—'}</span>,
}))

const { default: Club } = await import('./Club')

const SUMMARY = {
  members: 128, wallet_liability: 4_320_000, wallet_holders: 41, receivable: 1_150_000, debtors: 7,
  period: { cashback: 620_000, topup: 2_400_000, spent: 1_980_000 },
  tiers: [
    { key: 'bronze', name: 'برنزی', min: 0, pct: 3, color: '#a16207', count: 90 },
    { key: 'silver', name: 'نقره‌ای', min: 5_000_000, pct: 5, color: '#64748b', count: 30 },
    { key: 'vip', name: 'طلایی', min: 15_000_000, pct: 8, color: '#f59e0b', count: 8 },
  ],
}
const LIST = [
  { customer_id: 3, name: 'شیرین دلاوری', phone: '09127770011', tier: 'silver', visits: 12, total_spent: 8_400_000, wallet: 450_000, debt: 0, last_visit: '2026-10-22T18:00:00' },
  { customer_id: 5, name: 'آرش کمالی', phone: '09121110022', tier: 'bronze', visits: 3, total_spent: 1_200_000, wallet: 0, debt: 380_000, last_visit: null },
]

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/loyalty/summary') return Promise.resolve(SUMMARY)
    if (path === '/loyalty/customers') return Promise.resolve(LIST)
    return Promise.resolve([])
  })
}
const page = () => render(<App><Club /></App>)
const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('Loyalty club', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('shows the two balances that matter: money we owe and money owed to us', async () => {
    page()
    await waitFor(() => expect(text()).toContain('اعضای باشگاه'))
    expect(text()).toContain('مانده کیف پول‌ها (بدهی ما)')
    expect(text()).toContain('۴٬۳۲۰٬۰۰۰')
    expect(text()).toContain('طلب از مشتریان (نسیه)')
    expect(text()).toContain('۱٬۱۵۰٬۰۰۰')
    expect(text()).toContain('۱۲۸')                       // member count
  })

  it('lists members with wallet and debt kept apart', async () => {
    page()
    await waitFor(() => expect(text()).toContain('شیرین دلاوری'))
    expect(text()).toContain('۴۵۰٬۰۰۰')                  // wallet
    expect(text()).toContain('۳۸۰٬۰۰۰')                  // debt
  })

  it('filters by tier when a tier chip is clicked', async () => {
    page()
    await waitFor(() => expect(text()).toContain('نقره‌ای'))
    get.mockClear()
    await user().click(screen.getByText(/نقره‌ای/))
    await waitFor(() => expect(get).toHaveBeenCalledWith('/loyalty/customers', expect.objectContaining({ tier: 'silver' })))
  })

  it('switches to "debtors" from the card and the segmented filter', async () => {
    page()
    await waitFor(() => expect(text()).toContain('بدهکاران'))
    get.mockClear()
    await user().click(screen.getByText('بدهکاران'))
    await waitFor(() => expect(get).toHaveBeenCalledWith('/loyalty/customers', expect.objectContaining({ filter: 'debt' })))
  })

  it('opens the account panel for the clicked member', async () => {
    page()
    await waitFor(() => expect(text()).toContain('آرش کمالی'))
    fireEvent.click(screen.getByText('آرش کمالی'))
    await waitFor(() => expect(text()).toContain('ACCOUNT-PANEL-5'))
  })

  it('asks the server for the selected date range', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/loyalty/summary', expect.objectContaining({ date_from: expect.any(String), date_to: expect.any(String) })))
  })
})
