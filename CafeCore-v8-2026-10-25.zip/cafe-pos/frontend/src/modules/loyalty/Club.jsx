import { CrownOutlined, GiftOutlined, TeamOutlined, WalletOutlined, BookOutlined } from '@ant-design/icons'
import { Avatar, Card, Col, Drawer, Input, Row, Segmented, Space, Table, Typography } from 'antd'
import { useState } from 'react'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader, StatCard } from '../../components/common'
import { colorOf, initials, money, num, timeAgo } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import AccountPanel, { TierTag } from './AccountPanel'

export default function Club() {
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('all')
  const [tier, setTier] = useState(null)
  const [range, setRange] = useState(rangeOf('last30'))
  const [view, setView] = useState(null)
  const sum = useFetch('/loyalty/summary', { date_from: range.from, date_to: range.to })
  const list = useFetch('/loyalty/customers', { q: q || undefined, filter, tier: tier || undefined })
  const s = sum.data
  const reloadAll = () => { sum.reload(true); list.reload(true) }
  return (
    <div className="fade-in">
      <PageHeader title="باشگاه مشتریان" subtitle="کیف پول، کش‌بک پلکانی و حساب نسیه مشتریان" extra={<JalaliRange value={range} onChange={setRange} presets={['week', 'month', 'last30', 'lastMonth']} />} />
      <Row gutter={[16, 16]}>
        <Col xs={12} lg={8} xxl={4}><StatCard loading={sum.loading} title="اعضای باشگاه" value={s?.members} icon={<TeamOutlined />} color="var(--pal-1)" /></Col>
        <Col xs={12} lg={8} xxl={5}><StatCard loading={sum.loading} title="مانده کیف پول‌ها (بدهی ما)" value={s?.wallet_liability} money hint={`${num(s?.wallet_holders)} مشتری دارای موجودی`} icon={<WalletOutlined />} color="var(--violet)" onClick={() => setFilter('wallet')} /></Col>
        <Col xs={12} lg={8} xxl={5}><StatCard loading={sum.loading} title="طلب از مشتریان (نسیه)" value={s?.receivable} money hint={`${num(s?.debtors)} بدهکار`} icon={<BookOutlined />} color="var(--amber)" onClick={() => setFilter('debt')} /></Col>
        <Col xs={12} lg={12} xxl={5}><StatCard loading={sum.loading} title="کش‌بک اعطاشده در بازه" value={s?.period.cashback} money icon={<GiftOutlined />} color="var(--pal-5)" /></Col>
        <Col xs={24} lg={12} xxl={5}><StatCard loading={sum.loading} title="شارژ کیف پول در بازه" value={s?.period.topup} money hint={`مصرف از کیف پول: ${money(s?.period.spent)}`} icon={<CrownOutlined />} color="var(--green)" /></Col>
      </Row>
      <div className="tier-strip">
        {(s?.tiers || []).map((t) => (
          <button type="button" key={t.key} className={`tier-pill ${tier === t.key ? 'on' : ''}`} style={{ '--c': t.color }} onClick={() => setTier(tier === t.key ? null : t.key)}>
            <span className="tp-name">{t.key === 'vip' ? '👑' : '★'} {t.name}</span>
            <b>{num(t.count)}</b><small>از {money(t.min)} · کش‌بک {num(t.pct)}٪</small>
          </button>
        ))}
      </div>
      <Card className="card-r">
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
          <Input.Search placeholder="جستجوی نام یا شماره" allowClear onSearch={setQ} style={{ maxWidth: 300 }} />
          <Segmented value={filter} onChange={setFilter} options={[{ value: 'all', label: 'همه' }, { value: 'wallet', label: 'دارای موجودی کیف پول' }, { value: 'debt', label: 'بدهکاران' }]} />
        </div>
        <Table rowKey="customer_id" loading={list.loading} dataSource={list.data || []} scroll={{ x: 860 }} pagination={{ pageSize: 15, hideOnSinglePage: true }}
          onRow={(r) => ({ onClick: () => setView(r), style: { cursor: 'pointer' } })}
          columns={[
            { title: 'مشتری', dataIndex: 'name', render: (v, r) => <Space><Avatar style={{ background: colorOf(v) }}>{initials(v)}</Avatar><div><b>{v}</b><div className="ltr" style={{ fontSize: 12, color: 'var(--muted)', textAlign: 'right' }}>{r.phone}</div></div></Space> },
            { title: 'سطح', dataIndex: 'tier', render: (t) => <TierTag tier={t} /> },
            { title: 'خرید', dataIndex: 'visits', render: (v) => num(v), sorter: (a, b) => a.visits - b.visits },
            { title: 'مجموع خرید', dataIndex: 'total_spent', render: (v) => money(v), sorter: (a, b) => a.total_spent - b.total_spent },
            { title: 'کیف پول', dataIndex: 'wallet', render: (v) => <b style={{ color: v > 0 ? 'var(--violet)' : 'var(--muted)' }}>{money(v)}</b>, sorter: (a, b) => a.wallet - b.wallet },
            { title: 'بدهی نسیه', dataIndex: 'debt', render: (v) => <b style={{ color: v > 0 ? 'var(--red)' : 'var(--muted)' }}>{money(v)}</b>, sorter: (a, b) => a.debt - b.debt },
            { title: 'آخرین خرید', dataIndex: 'last_visit', render: (v) => (v ? timeAgo(v) : '—') },
          ]} />
      </Card>
      <Drawer open={!!view} onClose={() => setView(null)} width={Math.min(620, window.innerWidth)}
        title={view && <Space><Avatar style={{ background: colorOf(view.name) }}>{initials(view.name)}</Avatar><div><div>{view.name}</div><Typography.Text type="secondary" className="ltr" style={{ fontSize: 12 }}>{view.phone}</Typography.Text></div></Space>}>
        {view && <AccountPanel key={view.customer_id} customerId={view.customer_id} onChange={reloadAll} />}
      </Drawer>
    </div>
  )
}
