/**
 * Time clock (حضور و غیاب): who is on the clock, the attendance log with manager corrections, hourly wages and the
 * labour-vs-sales report (labour cost %, sales per labour hour). Backend: /api/timeclock/*.
 */
import { DeleteOutlined, EditOutlined, PlusOutlined, WarningOutlined } from '@ant-design/icons'
import { Alert, App, Button, Card, Col, Empty, Form, Input, InputNumber, Modal, Popconfirm, Row, Segmented, Select, Space, Switch, Table, Tabs, Tag, TimePicker, Tooltip, Typography } from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { useState } from 'react'
import { Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from 'recharts'
import JalaliRange, { rangeOf } from '../../components/JalaliRange'
import { PageHeader } from '../../components/common'
import { clock, hm } from '../../components/TimeClockButton'
import { del, post, put } from '../../core/api'
import { compact, faDate, faWeekday, isoDate, money, moneyFormatter, moneyParser, num } from '../../core/format'
import { useFetch } from '../../core/useFetch'
import { tooltipStyle } from '../dashboard/Dashboard'
import { Kpis } from '../reports/Insights'
import { useChart } from '../../core/theme'

const SOURCE = { pin: ['کد شخصی', 'blue'], self: ['از برنامه', 'cyan'], manual: ['ثبت دستی', 'orange'] }
const localIso = (d, t) => `${isoDate(d.toDate())}T${t.format('HH:mm')}:00`

export default function TimeClock() {
  const [range, setRange] = useState(rangeOf('week'))
  return (
    <div className="fade-in">
      <PageHeader title="حضور و غیاب" subtitle="ورود و خروج پرسنل، اصلاح ترددها و هزینه نیرو در برابر فروش"
        extra={<JalaliRange value={range} onChange={setRange} presets={['today', 'yesterday', 'week', 'month', 'last30']} />} />
      <Tabs destroyInactiveTabPane items={[
        { key: 'log', label: 'ترددها', children: <LogTab range={range} /> },
        { key: 'labor', label: 'هزینه نیرو و فروش', children: <LaborTab range={range} /> },
        { key: 'wages', label: 'حقوق و دستمزد', children: <WagesTab /> },
      ]} />
    </div>
  )
}

// ---------------------------------------------------------------- attendance log
function LogTab({ range }) {
  const { message } = App.useApp()
  const [userId, setUserId] = useState(null)
  const [edit, setEdit] = useState(null)
  const now = useFetch('/timeclock/now')
  const staff = useFetch('/timeclock/wages')
  const { data, loading, reload } = useFetch('/timeclock/entries', { date_from: range.from, date_to: range.to, user_id: userId || undefined })
  const refresh = () => { reload(true); now.reload(true) }
  const remove = async (r) => {
    try { await del(`/timeclock/entries/${r.id}`); message.success('حذف شد'); refresh() } catch (e) { message.error(e.message) }
  }
  const total = (data || []).reduce((a, r) => a + r.minutes, 0)
  return (
    <>
      <Card size="small" className="card-r" style={{ marginBottom: 16 }} title={<span>🟢 حاضرین الان <Tag>{num(now.data?.length || 0)} نفر</Tag></span>}>
        {now.data?.length ? (
          <div className="tc-now">
            {now.data.map((e) => (
              <div key={e.id} className={`tc-person ${e.forgotten ? 'warn' : ''}`}>
                <b>{e.name}</b>
                <span>از {clock(e.clock_in)} · {hm(e.minutes)}</span>
                {e.forgotten && <Tag color="red" icon={<WarningOutlined />}>خروج ثبت نشده</Tag>}
                <Button size="small" type="link" onClick={() => setEdit({ ...e })}>ثبت خروج دستی</Button>
              </div>
            ))}
          </div>
        ) : <Typography.Text type="secondary">الان کسی در شیفت نیست.</Typography.Text>}
      </Card>
      <Card className="card-r">
        <Space wrap style={{ marginBottom: 14, width: '100%', justifyContent: 'space-between' }}>
          <Space wrap>
            <Select allowClear showSearch optionFilterProp="label" placeholder="همه پرسنل" style={{ width: 200 }} value={userId} onChange={setUserId}
              options={(staff.data || []).map((u) => ({ value: u.user_id, label: u.name }))} />
            <Typography.Text type="secondary">{num(data?.length || 0)} تردد · جمع {hm(total)}</Typography.Text>
          </Space>
          <Button type="primary" icon={<PlusOutlined />} onClick={() => setEdit({})}>ثبت دستی</Button>
        </Space>
        <Table rowKey="id" size="middle" loading={loading} dataSource={data || []} scroll={{ x: 820 }} pagination={{ pageSize: 15, showSizeChanger: false }}
          columns={[
            { title: 'نام', dataIndex: 'name', render: (v) => <b>{v}</b> },
            { title: 'روز کاری', dataIndex: 'business_date', render: (d) => <span>{faWeekday(d)} {faDate(d)}</span> },
            { title: 'ورود', dataIndex: 'clock_in', render: clock },
            { title: 'خروج', dataIndex: 'clock_out', render: (v, r) => (v ? clock(v) : r.forgotten ? <Tag color="red">ثبت نشده</Tag> : <Tag color="green">در شیفت</Tag>) },
            { title: 'مدت', dataIndex: 'minutes', render: hm, sorter: (a, b) => a.minutes - b.minutes },
            { title: 'منبع', dataIndex: 'source', render: (s, r) => <Tooltip title={r.note}><Tag color={SOURCE[s]?.[1]}>{SOURCE[s]?.[0] || s}</Tag></Tooltip> },
            { title: '', width: 90, render: (_, r) => (
              <Space size={0}>
                <Button type="text" icon={<EditOutlined />} onClick={() => setEdit({ ...r })} />
                <Popconfirm title="این تردد حذف شود؟" okText="حذف" okButtonProps={{ danger: true }} cancelText="انصراف" onConfirm={() => remove(r)}>
                  <Button type="text" danger icon={<DeleteOutlined />} />
                </Popconfirm>
              </Space>
            ) },
          ]} />
      </Card>
      <EntryModal value={edit} staff={staff.data || []} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); refresh() }} />
    </>
  )
}

function EntryModal({ value, staff, onClose, onSaved }) {
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)
  const open = !!value
  const init = value && (value.id
    ? { user_id: value.user_id, date: dayjs(value.clock_in), in: dayjs(value.clock_in), out: value.clock_out ? dayjs(value.clock_out) : null, note: value.note }
    : { date: dayjs(), in: dayjs().hour(9).minute(0), out: null })
  const save = async () => {
    const v = await form.validateFields().catch(() => null)
    if (!v) return
    const clockIn = localIso(v.date, v.in)
    let clockOut = null
    if (v.out) {
      const outDay = v.out.format('HH:mm') <= v.in.format('HH:mm') ? v.date.add(1, 'day') : v.date   // past midnight → next day
      clockOut = localIso(outDay, v.out)
    }
    setBusy(true)
    try {
      const body = { user_id: v.user_id, clock_in: clockIn, clock_out: clockOut, note: v.note || null }
      if (value.id) await put(`/timeclock/entries/${value.id}`, body)
      else await post('/timeclock/entries', body)
      message.success('ذخیره شد')
      onSaved()
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  return (
    <Modal open={open} title={value?.id ? `اصلاح تردد — ${value.name}` : 'ثبت دستی تردد'} onCancel={onClose} onOk={save} confirmLoading={busy} okText="ذخیره" cancelText="انصراف" destroyOnClose>
      <JalaliLocaleListener />
      {open && (
        <Form form={form} layout="vertical" initialValues={init} preserve={false}>
          <Form.Item name="user_id" label="پرسنل" rules={[{ required: true, message: 'پرسنل را انتخاب کنید' }]}>
            <Select showSearch optionFilterProp="label" disabled={!!value.id} options={staff.map((u) => ({ value: u.user_id, label: u.name }))} />
          </Form.Item>
          <Row gutter={12}>
            <Col span={10}><Form.Item name="date" label="روز ورود" rules={[{ required: true }]}><JDatePicker style={{ width: '100%' }} format="YYYY/MM/DD" allowClear={false} /></Form.Item></Col>
            <Col span={7}><Form.Item name="in" label="ساعت ورود" rules={[{ required: true }]}><TimePicker style={{ width: '100%' }} format="HH:mm" minuteStep={5} allowClear={false} /></Form.Item></Col>
            <Col span={7}><Form.Item name="out" label="ساعت خروج" tooltip="خالی = هنوز در شیفت. ساعت کمتر از ورود یعنی بعد از نیمه‌شب"><TimePicker style={{ width: '100%' }} format="HH:mm" minuteStep={5} placeholder="در شیفت" /></Form.Item></Col>
          </Row>
          <Form.Item name="note" label="توضیح (در گزارش رویدادها ثبت می‌شود)"><Input maxLength={200} placeholder="مثلاً: فراموشی ثبت خروج" /></Form.Item>
        </Form>
      )}
    </Modal>
  )
}

// ---------------------------------------------------------------- labour vs sales
function LaborTab({ range }) {
  const ch = useChart()
  const { data, loading } = useFetch('/timeclock/labor', { date_from: range.from, date_to: range.to })
  if (loading || !data) return <Card loading className="card-r" />
  const t = data.totals
  if (!t.entries) return <Empty description="در این بازه ورود و خروجی ثبت نشده است" />
  const pctColor = (p) => (p == null ? 'default' : p > 35 ? 'red' : p > 30 ? 'orange' : 'green')
  const pctTag = (p) => (p == null ? '—' : <Tag color={pctColor(p)}>{num(p, 1)}٪</Tag>)
  return (
    <>
      {t.no_wage.length > 0 && <Alert type="warning" showIcon style={{ marginBottom: 12 }} message={`برای ${t.no_wage.join('، ')} دستمزد ثبت نشده؛ هزینه آن‌ها صفر حساب شده است (تب «حقوق و دستمزد»).`} />}
      {t.forgotten > 0 && <Alert type="error" showIcon style={{ marginBottom: 12 }} message={`${num(t.forgotten)} تردد بدون ثبت خروج و بیش از ${num(t.max_hours)} ساعت؛ تا اصلاح، حداکثر ${num(t.max_hours)} ساعت حساب شده است.`} />}
      <Kpis items={[
        ['ساعت کار پرسنل', `${num(t.hours, 1)} ساعت`, `${num(t.entries)} تردد`, 'var(--primary-text)'],
        ['هزینه نیرو', money(t.cost), 'بر اساس نرخ ساعتی', 'var(--amber)'],
        ['فروش خالص', money(t.sales), 'بدون مالیات و سرویس، پس از تخفیف', 'var(--green)'],
        ['نسبت هزینه نیرو به فروش', t.labor_pct == null ? '—' : `${num(t.labor_pct, 1)}٪`, 'معمول رستوران‌ها: ۲۵ تا ۳۰٪', t.labor_pct > 35 ? 'var(--red)' : t.labor_pct > 30 ? 'var(--amber)' : 'var(--green)'],
        ['فروش به ازای هر ساعت کار', t.splh == null ? '—' : money(t.splh), 'SPLH', 'var(--blue)'],
      ]} />
      <Row gutter={[16, 16]}>
        <Col xs={24} xl={12}>
          <Card size="small" title="ساعات روز: نیروی حاضر در برابر فروش" className="card-r">
            <ResponsiveContainer width="100%" height={260}>
              <ComposedChart data={data.hours} margin={{ left: 10, right: 10, top: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="hour" reversed tick={{ fontSize: 11 }} tickFormatter={(h) => `${num(h)}`} />
                <YAxis yAxisId="s" orientation="right" tick={{ fontSize: 11 }} tickFormatter={compact} width={50} />
                <YAxis yAxisId="p" orientation="left" tick={{ fontSize: 11 }} tickFormatter={(v) => num(v, 1)} width={30} />
                <RTooltip contentStyle={tooltipStyle} labelFormatter={(h) => `ساعت ${num(h)}`}
                  formatter={(v, n) => (n === 'فروش' ? [money(v), n] : [num(v, 1), n])} />
                <Bar yAxisId="s" dataKey="sales" name="فروش" fill={ch.green} radius={[6, 6, 0, 0]} barSize={14} />
                <Line yAxisId="p" dataKey="avg_staff" name="میانگین نفرات حاضر" stroke={ch.accent} strokeWidth={2} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>ساعت‌هایی که نفرات زیاد و فروش کم است، جای کاهش نیرو دارند؛ و برعکس.</Typography.Text>
          </Card>
        </Col>
        <Col xs={24} xl={12}>
          <Card size="small" title="روزانه" className="card-r">
            <Table size="small" rowKey="date" dataSource={data.days} pagination={{ pageSize: 8, showSizeChanger: false }}
              columns={[
                { title: 'روز', dataIndex: 'date', render: (d) => <span>{faWeekday(d)} {faDate(d)}</span> },
                { title: 'نفرات', dataIndex: 'staff', render: (v) => num(v) },
                { title: 'ساعت', dataIndex: 'hours', render: (v) => num(v, 1) },
                { title: 'هزینه', dataIndex: 'cost', render: money },
                { title: 'فروش', dataIndex: 'sales', render: money },
                { title: 'نسبت', dataIndex: 'labor_pct', render: pctTag },
              ]} />
          </Card>
        </Col>
        <Col span={24}>
          <Card size="small" title="به تفکیک پرسنل" className="card-r">
            <Table size="small" rowKey="user_id" dataSource={data.staff} pagination={false} scroll={{ x: 800 }}
              columns={[
                { title: 'نام', dataIndex: 'name', render: (v, r) => <span><b>{v}</b> <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.role}</Typography.Text></span> },
                { title: 'روز کاری', dataIndex: 'days', render: (v) => num(v) },
                { title: 'ساعت', dataIndex: 'hours', render: (v) => num(v, 1), sorter: (a, b) => a.hours - b.hours },
                { title: 'دستمزد', dataIndex: 'wage', render: (v, r) => (!r.has_pay ? <Tag color="orange">ثبت نشده</Tag>
                  : <span>{r.pay_type === 'monthly' ? <>{money(r.monthly_salary)} <Typography.Text type="secondary" style={{ fontSize: 12 }}>ماهانه</Typography.Text></> : <>{money(v)} <Typography.Text type="secondary" style={{ fontSize: 12 }}>ساعتی</Typography.Text></>}
                    {r.insured && <Tag color="blue" style={{ marginInlineStart: 6 }}>بیمه</Tag>}</span>) },
                { title: 'هزینه', dataIndex: 'cost', render: money, sorter: (a, b) => a.cost - b.cost },
                { title: 'فروش ثبت‌شده توسط او', dataIndex: 'sales', render: (v) => (v ? money(v) : '—') },
                { title: 'فروش در ساعت', dataIndex: 'splh', render: (v, r) => (r.sales && v ? money(v) : '—') },
              ]} />
          </Card>
        </Col>
      </Row>
    </>
  )
}

// ---------------------------------------------------------------- wages
function WagesTab() {
  const { message } = App.useApp()
  const { data, loading, setData } = useFetch('/timeclock/wages')
  const cfg = useFetch('/timeclock/config')
  const [dirty, setDirty] = useState({})
  const [ins, setIns] = useState(null)
  const val = (r) => ({ ...r, ...(dirty[r.user_id] || {}) })
  const change = (r, patch) => setDirty({ ...dirty, [r.user_id]: { ...(dirty[r.user_id] || {}), ...patch } })
  const save = async (r) => {
    const v = val(r)
    try {
      const res = await put('/timeclock/wages', { user_id: v.user_id, hourly_wage: v.hourly_wage || 0, pay_type: v.pay_type, monthly_salary: v.monthly_salary || 0, insured: !!v.insured })
      setData(data.map((x) => (x.user_id === r.user_id ? { ...x, ...res } : x)))
      setDirty(({ [r.user_id]: _, ...rest }) => rest)
      message.success(`دستمزد ${r.name} ذخیره شد`)
    } catch (e) { message.error(e.message) }
  }
  const saveIns = async () => {
    try {
      const res = await put('/timeclock/config', { insurance_pct: ins })
      cfg.setData(res)
      setIns(null)
      message.success('سهم بیمه ذخیره شد')
    } catch (e) { message.error(e.message) }
  }
  const pct = ins ?? cfg.data?.insurance_pct
  return (
    <Card className="card-r">
      <Alert type="info" showIcon style={{ marginBottom: 14 }} message="فقط برای گزارش «هزینه نیرو به فروش» استفاده می‌شود و محاسبه فیش حقوقی نیست."
        description={<>ساعتی: هزینه = ساعت حضور × نرخ. ماهانه: هر روز تقویمی <b>حقوق ÷ ۳۰</b> هزینه حساب می‌شود (چه سر کار آمده باشد چه نه). برای افراد بیمه‌شده، سهم بیمه کارفرما روی مبلغ اضافه می‌شود.</>} />
      <Space style={{ marginBottom: 16 }} wrap>
        <span>سهم بیمه کارفرما:</span>
        <InputNumber className="tc-insurance" min={0} max={50} step={1} value={pct} onChange={(x) => setIns(x ?? 0)} addonAfter="٪" style={{ width: 130 }} disabled={cfg.loading} />
        <Button type={ins != null ? 'primary' : 'default'} disabled={ins == null} onClick={saveIns}>ذخیره</Button>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>معمولاً ۲۳٪ (۲۰٪ کارفرما + ۳٪ بیکاری)</Typography.Text>
      </Space>
      <Table rowKey="user_id" loading={loading} dataSource={data || []} pagination={false} scroll={{ x: 760 }}
        columns={[
          { title: 'نام', dataIndex: 'name', render: (v) => <b>{v}</b> },
          { title: 'نوع', width: 150, render: (_, r) => (
            <Segmented size="small" value={val(r).pay_type} onChange={(x) => change(r, { pay_type: x })}
              options={[{ value: 'hourly', label: 'ساعتی' }, { value: 'monthly', label: 'ماهانه' }]} />
          ) },
          { title: 'مبلغ', render: (_, r) => {
            const v = val(r)
            return v.pay_type === 'monthly'
              ? <InputNumber min={0} max={10_000_000_000} step={500_000} value={v.monthly_salary} style={{ width: 220 }} formatter={moneyFormatter} parser={moneyParser}
                  addonAfter="تومان در ماه" onChange={(x) => change(r, { monthly_salary: x ?? 0 })} onPressEnter={() => save(r)} />
              : <InputNumber min={0} max={100_000_000} step={5000} value={v.hourly_wage} style={{ width: 220 }} formatter={moneyFormatter} parser={moneyParser}
                  addonAfter="تومان در ساعت" onChange={(x) => change(r, { hourly_wage: x ?? 0 })} onPressEnter={() => save(r)} />
          } },
          { title: 'بیمه', width: 80, render: (_, r) => <Switch size="small" checked={!!val(r).insured} onChange={(x) => change(r, { insured: x })} /> },
          { title: 'هزینه روزانه تقریبی', render: (_, r) => {
            const v = val(r)
            const f = v.insured ? 1 + (pct || 0) / 100 : 1
            const d = v.pay_type === 'monthly' ? (v.monthly_salary || 0) / 30 * f : (v.hourly_wage || 0) * 8 * f
            return d ? <Typography.Text type="secondary">{money(Math.round(d))}{v.pay_type !== 'monthly' && ' (۸ ساعت)'}</Typography.Text> : '—'
          } },
          { title: '', width: 100, render: (_, r) => <Button type={dirty[r.user_id] ? 'primary' : 'default'} disabled={!dirty[r.user_id]} onClick={() => save(r)}>ذخیره</Button> },
        ]} />
    </Card>
  )
}
