import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

// Attendance: who is clocked in right now, and the hours that end up in payroll. The "forgotten
// checkout" warning matters — an open entry that is never closed inflates the wage bill.
const get = vi.fn()
const post = vi.fn()
vi.mock('../../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
vi.mock('../../core/auth', () => ({ useAuth: () => ({ can: () => true, hasModule: () => false, user: { id: 1 }, settings: {}, system: {} }) }))
vi.mock('antd-jalali', () => {
  const Stub = () => null
  Stub.RangePicker = () => null
  return { DatePicker: Stub, TimePicker: Stub, JalaliLocaleListener: () => null }
})

const { default: TimeClock } = await import('./TimeClock')

const NOW = [
  { id: 1, name: 'رضا صندوق‌دار', clock_in: new Date(Date.now() - 135 * 60000).toISOString(), minutes: 135, forgotten: false },
  { id: 2, name: 'علی گارسون', clock_in: new Date(Date.now() - 14 * 3600000).toISOString(), minutes: 840, forgotten: true },
]
const ENTRIES = [
  { id: 1, name: 'رضا صندوق‌دار', user_id: 4, business_date: '2026-10-23', source: 'pin', clock_in: new Date(Date.now() - 135 * 60000).toISOString(), clock_out: null, minutes: 135, note: null },
  { id: 5, name: 'مریم گارسون', user_id: 5, business_date: '2026-10-22', source: 'manual', clock_in: '2026-10-22T09:00:00', clock_out: '2026-10-22T17:30:00', minutes: 510, note: 'شیفت صبح' },
]
const WAGES = [{ user_id: 4, name: 'رضا صندوق‌دار', hourly: 120_000, monthly: 21_600_000, insurance_pct: 23 }]
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const respond = () => {
  get.mockImplementation((path) => {
    if (path === '/timeclock/now') return Promise.resolve(NOW)
    if (path === '/timeclock/wages') return Promise.resolve(WAGES)
    if (path === '/timeclock/entries') return Promise.resolve(ENTRIES)
    if (path === '/timeclock/labor') return Promise.resolve({ rows: [], summary: {} })
    return Promise.resolve([])
  })
}
const page = () => render(<App><TimeClock /></App>)

describe('Attendance (time clock)', () => {
  beforeEach(() => { get.mockReset(); respond() })

  it('lists who is clocked in right now with their elapsed time', async () => {
    page()
    await waitFor(() => expect(text()).toContain('حاضرین الان'))
    expect(text()).toContain('رضا صندوق‌دار')
    expect(text()).toContain('۲ نفر')
  })

  it('flags a forgotten checkout (14 hours open)', async () => {
    page()
    await waitFor(() => expect(text()).toContain('علی گارسون'))
    expect(document.querySelectorAll('.tc-person.warn').length).toBe(1)
  })

  it('shows the entries with an open one still running', async () => {
    page()
    await waitFor(() => expect(text()).toContain('مریم گارسون'))
    // the note travels as a tooltip on the source tag, so the row itself is what we assert
    expect(text()).toContain('۸ ساعت و ۳۰ دقیقه')
  })

  it('asks for the selected range and offers all three tabs', async () => {
    page()
    await waitFor(() => expect(get).toHaveBeenCalledWith('/timeclock/entries', expect.objectContaining({
      date_from: expect.any(String), date_to: expect.any(String),
    })))
    const tabs = [...document.querySelectorAll('.ant-tabs-tab')].map((t) => t.textContent)
    expect(tabs.join(' ')).toContain('ترددها')
    expect(tabs.join(' ')).toContain('هزینه نیرو و فروش')
    expect(tabs.join(' ')).toContain('حقوق و دستمزد')
  })

  it('renders an empty day without crashing', async () => {
    get.mockImplementation((path) => {
      if (path === '/timeclock/now') return Promise.resolve([])
      if (path === '/timeclock/entries') return Promise.resolve([])
      return Promise.resolve([])
    })
    page()
    await waitFor(() => expect(text()).toContain('حاضرین الان'))
    expect(text()).toContain('۰ نفر')
  })
})

// ---------------------------------------------------------------- manual entry (add / correct)
describe('Time clock — manual entry', () => {
  beforeEach(() => { get.mockReset(); post.mockReset(); respond() })

  it('opens the form for a new punch and needs an employee', async () => {
    const { default: TimeClock } = await import('./TimeClock')
    page(TimeClock)
    await waitFor(() => expect(text()).toContain('حاضرین الان'))
    fireEvent.click(screen.getByRole('button', { name: /ثبت دستی/ }))
    await waitFor(() => expect(document.querySelector('.ant-modal')).toBeTruthy())
    fireEvent.click(document.querySelector('.ant-modal-footer .ant-btn-primary'))
    await waitFor(() => expect(text()).toContain('پرسنل'))     // validation, not a POST
    expect(post).not.toHaveBeenCalled()
  })

  it('opens the correction form from a row (employee is locked)', async () => {
    const { default: TimeClock } = await import('./TimeClock')
    page(TimeClock)
    await waitFor(() => expect(text()).toContain('مریم'))
    fireEvent.click([...document.querySelectorAll('.ant-table-tbody .anticon-edit')][0].closest('button'))
    await waitFor(() => expect(text()).toMatch(/اصلاح تردد/))
    const select = document.querySelector('.ant-modal .ant-select-disabled')
    expect(select).toBeTruthy()                                // the employee cannot be swapped
  })
})
