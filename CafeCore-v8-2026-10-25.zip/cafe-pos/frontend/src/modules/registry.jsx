/**
 * Frontend module registry. A feature module = backend package (app/modules/<name>) + a folder here.
 * Pages appear automatically when the backend module is enabled and the user has the permission.
 * To add a module: create `src/modules/<name>/`, then add its pages/apps below.
 */
import {
  AccountBookOutlined, ApartmentOutlined, AppstoreOutlined, AuditOutlined, BarChartOutlined, BookOutlined, CalendarOutlined, CarOutlined, CheckSquareOutlined, CreditCardOutlined, CrownOutlined, DashboardOutlined, DatabaseOutlined, FieldTimeOutlined, FireOutlined, FundOutlined, GlobalOutlined, HistoryOutlined, InboxOutlined, LayoutOutlined, MessageOutlined, PercentageOutlined, PieChartOutlined, SettingOutlined, ShopOutlined, ShoppingCartOutlined, SolutionOutlined, SwapOutlined, TeamOutlined, UserOutlined, WalletOutlined,
} from '@ant-design/icons'
import { lazy } from 'react'

const L = (f) => lazy(f)

/** Full-screen apps shown on the launcher */
export const APPS = [
  { key: 'pos', path: '/pos', title: 'صندوق و سفارش‌گیری', desc: 'ثبت سفارش سالن، بیرون‌بر و پیک، پرداخت و چاپ رسید', icon: <ShopOutlined />, color: 'var(--pal-1)', perm: 'pos.access', module: 'orders' },
  { key: 'kds', path: '/kds', title: 'نمایشگر آشپزخانه', desc: 'نمایش لحظه‌ای سفارش‌ها برای آشپزخانه و بار', icon: <FireOutlined />, color: 'var(--red)', perm: 'kitchen.access', module: 'kitchen' },
  { key: 'dispatch', path: '/admin/delivery', title: 'پیک و ارسال', desc: 'تابلوی توزیع سفارش بین پیک‌ها و تسویه حساب', icon: <CarOutlined />, color: 'var(--violet)', perm: 'delivery.dispatch', module: 'delivery' },
  { key: 'myshift', path: '/my-shift', title: 'شیفت من', desc: 'نتیجه کار شیفت، تحویل صندوق و ارسال گزارش پایان شیفت به مدیر', icon: <SolutionOutlined />, color: 'var(--green)', module: 'shifts' },
  { key: 'admin', path: '/admin', title: 'مدیریت', desc: 'داشبورد، گزارش‌ها، منو، انبار، پرسنل و تنظیمات', icon: <DashboardOutlined />, color: 'var(--blue)', anyPerm: ['dashboard.view', 'reports.view', 'menu.manage', 'inventory.view', 'staff.manage', 'settings.manage', 'shifts.manage', 'shifts.supervise', 'customers.manage', 'floor.manage', 'finance.view', 'expenses.manage', 'delivery.dispatch', 'reservations.manage', 'online.manage', 'sms.manage', 'market.manage', 'moadian.manage', 'branches.manage', 'discounts.manage', 'timeclock.manage'] },
]

/** Admin panel pages (grouped in the side menu) */
export const ADMIN_PAGES = [
  { group: 'عملیات', key: 'dashboard', path: 'dashboard', title: 'داشبورد', icon: <DashboardOutlined />, perm: 'dashboard.view', module: 'reports', element: L(() => import('./dashboard/Dashboard')) },
  { group: 'عملیات', key: 'orders', path: 'orders', title: 'سفارش‌ها', icon: <HistoryOutlined />, perm: 'pos.access', module: 'orders', element: L(() => import('./orders/OrdersHistory')) },
  { group: 'عملیات', key: 'online', path: 'online', title: 'سفارش آنلاین و QR', icon: <GlobalOutlined />, perm: 'online.manage', module: 'online', element: L(() => import('./online/OnlineOrders')) },
  { group: 'عملیات', key: 'reservations', path: 'reservations', title: 'رزرو میز', icon: <CalendarOutlined />, perm: 'reservations.manage', module: 'reservations', element: L(() => import('./reservations/Reservations')) },
  { group: 'عملیات', key: 'delivery', path: 'delivery', title: 'پیک و ارسال', icon: <CarOutlined />, perm: 'delivery.dispatch', module: 'delivery', element: L(() => import('./delivery/Dispatch')) },
  { group: 'عملیات', key: 'shifts', path: 'shifts', title: 'شیفت و صندوق', icon: <WalletOutlined />, perm: 'shifts.manage', module: 'shifts', element: L(() => import('./shifts/Shifts')) },
  { group: 'عملیات', key: 'customers', path: 'customers', title: 'مشتریان', icon: <UserOutlined />, perm: 'customers.manage', module: 'customers', element: L(() => import('./customers/Customers')) },
  { group: 'عملیات', key: 'club', path: 'club', title: 'باشگاه مشتریان', icon: <CrownOutlined />, perm: 'customers.manage', module: 'loyalty', element: L(() => import('./loyalty/Club')) },
  { group: 'گزارش', key: 'reports', path: 'reports', title: 'گزارش فروش', icon: <BarChartOutlined />, perm: 'reports.view', module: 'reports', element: L(() => import('./reports/Reports')) },
  { group: 'مالی', key: 'pnl', path: 'finance/pnl', title: 'سود و زیان', icon: <FundOutlined />, perm: 'finance.view', module: 'expenses', element: L(() => import('./expenses/ProfitLoss')) },
  { group: 'مالی', key: 'expenses', path: 'finance/expenses', title: 'هزینه‌ها', icon: <AccountBookOutlined />, perm: 'expenses.manage', module: 'expenses', element: L(() => import('./expenses/Expenses')) },
  { group: 'منو و سالن', key: 'menu', path: 'menu', title: 'منو و قیمت‌ها', icon: <BookOutlined />, perm: 'menu.manage', module: 'menu', element: L(() => import('./menu/MenuAdmin')) },
  { group: 'منو و سالن', key: 'discounts', path: 'discounts', title: 'تخفیف‌ها', icon: <PercentageOutlined />, perm: 'discounts.manage', module: 'orders', element: L(() => import('./orders/Discounts')) },
  { group: 'منو و سالن', key: 'floor', path: 'floor', title: 'سالن و میزها', icon: <LayoutOutlined />, perm: 'floor.manage', module: 'floor', element: L(() => import('./floor/FloorAdmin')) },
  { group: 'انبار', key: 'ingredients', path: 'inventory/ingredients', title: 'مواد اولیه', icon: <DatabaseOutlined />, perm: 'inventory.view', module: 'inventory', element: L(() => import('./inventory/Ingredients')) },
  { group: 'انبار', key: 'foodcost', path: 'inventory/food-cost', title: 'رسپی و بهای تمام‌شده', icon: <PieChartOutlined />, perm: 'inventory.view', module: 'inventory', element: L(() => import('./inventory/FoodCost')) },
  { group: 'انبار', key: 'purchases', path: 'inventory/purchases', title: 'خرید و تأمین‌کنندگان', icon: <ShoppingCartOutlined />, perm: 'inventory.view', module: 'inventory', element: L(() => import('./inventory/Purchases')) },
  { group: 'انبار', key: 'stockcount', path: 'inventory/count', title: 'انبارگردانی', icon: <CheckSquareOutlined />, perm: 'inventory.manage', module: 'inventory', element: L(() => import('./inventory/StockCount')) },
  { group: 'انبار', key: 'movements', path: 'inventory/movements', title: 'گردش انبار', icon: <SwapOutlined />, perm: 'inventory.view', module: 'inventory', element: L(() => import('./inventory/Movements')) },
  { group: 'اتصالات', key: 'marketplace', path: 'marketplace', title: 'اسنپ‌فود و کانال‌ها', icon: <ShopOutlined />, perm: 'market.manage', module: 'marketplace', element: L(() => import('./marketplace/Marketplace')) },
  { group: 'اتصالات', key: 'sms', path: 'sms', title: 'مرکز پیامک', icon: <MessageOutlined />, perm: 'sms.manage', module: 'sms', element: L(() => import('./sms/SmsCenter')) },
  { group: 'اتصالات', key: 'cardreader', path: 'card-readers', title: 'کارتخوان‌ها', icon: <CreditCardOutlined />, perm: 'settings.manage', module: 'cardreader', element: L(() => import('./cardreader/CardReaders')) },
  { group: 'اتصالات', key: 'moadian', path: 'moadian', title: 'سامانه مودیان', icon: <AuditOutlined />, perm: 'moadian.manage', module: 'moadian', element: L(() => import('./moadian/Moadian')) },
  { group: 'اتصالات', key: 'branches', path: 'branches', title: 'شعبه‌ها', icon: <ApartmentOutlined />, perm: 'branches.manage', module: 'branches', element: L(() => import('./branches/Branches')) },
  { group: 'سیستم', key: 'timeclock', path: 'timeclock', title: 'حضور و غیاب', icon: <FieldTimeOutlined />, perm: 'timeclock.manage', module: 'timeclock', element: L(() => import('./timeclock/TimeClock')) },
  { group: 'سیستم', key: 'staff', path: 'staff', title: 'پرسنل و دسترسی', icon: <TeamOutlined />, perm: 'staff.manage', module: 'staff', element: L(() => import('./staff/Staff')) },
  { group: 'سیستم', key: 'settings', path: 'settings', title: 'تنظیمات', icon: <SettingOutlined />, perm: 'settings.manage', module: 'system', element: L(() => import('./system/Settings')) },
  { group: 'سیستم', key: 'audit', path: 'audit', title: 'رویدادهای سیستم', icon: <AuditOutlined />, perm: 'audit.view', module: 'system', element: L(() => import('./system/Audit')) },
  { group: 'سیستم', key: 'modules', path: 'modules', title: 'ماژول‌ها', icon: <AppstoreOutlined />, perm: 'settings.manage', module: 'system', element: L(() => import('./system/Modules')) },
]

export const visible = (auth, item) =>
  (!item.module || auth.hasModule(item.module)) &&
  (!item.perm || auth.can(item.perm)) &&
  (!item.anyPerm || auth.canAny(...item.anyPerm))

export const ICONS = { InboxOutlined }
