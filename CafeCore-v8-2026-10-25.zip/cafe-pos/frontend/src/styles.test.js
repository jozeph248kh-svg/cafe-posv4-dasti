import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

// The hover elevation («روی هاور برجسته بشن») is pure CSS, so no component test can see it. These checks keep the
// rules from being silently deleted by a future refactor and pin the two promises the product made:
//   1) every real button lifts and gets a shadow on hover,
//   2) table tiles lift further than buttons and keep naming their status in words.
// They are deliberately structural (not pixel tests) — they fail if a rule disappears, not if a colour changes.
const css = readFileSync(resolve(process.cwd(), 'src/index.css'), 'utf8')
const rule = (selector) => {                       // the declaration block of one exact selector (not a selector list)
  const i = css.indexOf(`${selector} {`)
  return i === -1 ? '' : css.slice(i, css.indexOf('}', i) + 1)
}

describe('pressable depth in index.css', () => {
  it('lifts antd buttons on hover and presses them down on click', () => {
    const hover = rule('html .ant-btn:not(.ant-btn-compact-item):not(:disabled):not(.ant-btn-link):not(.ant-btn-text):hover')
    expect(hover).toContain('translateY(var(--lift-btn))')
    expect(hover).toContain('box-shadow')
    expect(rule('html .ant-btn:not(.ant-btn-compact-item):not(:disabled):not(.ant-btn-link):not(.ant-btn-text):active')).toContain('scale(')
  })

  it('defines the lift distances once, as variables', () => {
    expect(css).toMatch(/--lift-btn:\s*-?\d+px/)
    expect(css).toMatch(/--lift-tile:\s*-?\d+px/)
  })

  it('lifts a button at least as much as a table tile, and a merged group a little less', () => {
    // the owner's rule («مثل قسمت میزها ولی یکم بیشتر»): the button must never feel flatter than a tile,
    // while a wide merged group stays calmer because the same distance already reads as more movement
    const px = (name) => -parseFloat(css.match(new RegExp(`--${name}:\\s*(-?[\\d.]+)px`))[1])
    expect(px('lift-btn')).toBeGreaterThanOrEqual(px('lift-tile'))
    expect(px('lift-group')).toBeGreaterThan(0)
    expect(px('lift-group')).toBeLessThanOrEqual(px('lift-btn'))
  })

  it('colours the table hover glow with the status colour', () => {
    const hover = rule('.table-card:hover')
    expect(hover).toContain('var(--lift-tile)')
    expect(hover).toContain('var(--tc)')
  })

  it('styles the dwell bar for its three states', () => {
    expect(rule('.tc-bar > i')).toContain('transition')
    expect(rule('.tc-bar.warn > i')).toContain('--amber-raw')
    expect(rule('.tc-bar.late > i')).toContain('--red-raw')
  })

  it('lifts a merged button group as one block instead of splitting its buttons apart', () => {
    // the POS action row (تخفیف / پیش‌فاکتور / پرداخت) is an AntD compact group: if the single buttons lifted
    // on their own they would tear away from each other under the cursor
    expect(css).toContain('html .ant-btn:not(.ant-btn-compact-item):not(:disabled)')
    expect(rule('html .ant-space-compact:hover')).toContain('var(--lift-group)')
    expect(rule('html .ant-space-compact .ant-btn:hover')).toContain('transform: none')
  })

  it('keeps buttons inside data tables still, so rows never jump', () => {
    const dense = css.slice(css.indexOf('html .ant-table .ant-btn:hover'), css.indexOf('html .ant-table .ant-btn:hover') + 200)
    expect(dense).toContain('transform: none')
  })

  it('does not move anything when the user asked for reduced motion', () => {
    const block = css.slice(css.indexOf('@media (prefers-reduced-motion: reduce)'))
    expect(block).toContain('transform: none !important')
  })
})
