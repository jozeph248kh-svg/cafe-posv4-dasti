import { SafetyCertificateOutlined } from '@ant-design/icons'
import { App, Modal, Typography } from 'antd'
import { useEffect, useRef, useState } from 'react'
import { setOverrideHandler } from '../core/api'
import PinPad from './PinPad'

/** Shows a manager-PIN dialog whenever the API asks for approval (void, discount, refund, cancel...). */
export default function OverrideProvider({ children }) {
  const [state, setState] = useState(null)       // { message, invalid }
  // A queue, not a single slot: two requests can need a manager PIN at the same time (a discount and
  // a refund). With one slot the second overwrote the first, its promise never settled and the POS
  // waited for ever — the bug that made the till look frozen.
  const pending = useRef([])
  const { message } = App.useApp()
  useEffect(() => {                               // direct printer failures (core/print.js) → visible warning
    const f = (e) => message.warning({ content: e.detail, duration: 6 })
    window.addEventListener('print:error', f)
    return () => window.removeEventListener('print:error', f)
  }, [message])

  useEffect(() => {
    const show = (err, resolve) => setState({ message: err.message, invalid: err.code === 'override_invalid', at: Date.now(), resolve })
    setOverrideHandler((err) => new Promise((resolve) => {
      pending.current.push({ err, resolve })
      if (pending.current.length === 1) show(err, resolve)      // one dialog at a time
      // a request that arrives while the dialog is open simply waits its turn
      else if (!state) show(pending.current[0].err, pending.current[0].resolve)
    }))
    return () => { setOverrideHandler(null); pending.current.splice(0).forEach((p) => p.resolve(null)) }
  }, [])  // eslint-disable-line react-hooks/exhaustive-deps

  const close = (pin) => {
    const head = pending.current.shift()
    head?.resolve(pin)
    const next = pending.current[0]
    if (next) setState({ message: next.err.message, invalid: next.err.code === 'override_invalid', at: Date.now(), resolve: next.resolve })
    else setState(null)
  }

  return (
    <>
      {children}
      <Modal open={!!state} onCancel={() => close(null)} footer={null} width={340} centered destroyOnClose
        title={<span><SafetyCertificateOutlined style={{ color: 'var(--amber)' }} /> تأیید مدیر</span>}>
        <Typography.Paragraph type={state?.invalid ? 'danger' : 'secondary'} style={{ textAlign: 'center' }}>
          {state?.message || 'این عملیات نیاز به تأیید مدیر دارد'}
          <br />کد ورود (PIN) مدیر را وارد کنید
        </Typography.Paragraph>
        {state && <PinPad key={state.at} onSubmit={close} error={state.invalid ? state.at : null} />}
      </Modal>
    </>
  )
}
