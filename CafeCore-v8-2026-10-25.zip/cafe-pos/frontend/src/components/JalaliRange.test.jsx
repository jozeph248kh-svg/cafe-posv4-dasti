import { afterEach, describe, expect, it, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import JalaliRange, { PRESETS, pickerToIso, rangeOf } from './JalaliRange'
import * as format from '../core/format'

// `antd-jalali` deep-imports antd's ESM internals ("antd/es/date-picker/generatePicker"), which Node's
// module loader cannot resolve by extension-less path — so that package cannot be loaded under vitest
// at all (this project had no component tests, which is how it went unnoticed). The picker itself is
// third-party UI; what this app owns is the range maths below, so the picker is stubbed out.
// The Persian calendar those pickers rely on is covered separately in src/core/jalali.test.js.
vi.mock('antd-jalali', () => ({
  DatePicker: { RangePicker: () => <div data-testid="range-picker" /> },
  JalaliLocaleListener: () => null,
}))

// Every report screen sends a {from, to} Gregorian range built by this component, and the backend
// compares it to `business_date`. A preset that is one day off silently shows the wrong day's money,
// so the presets are pinned here. Dates are frozen so the test does not depend on when it runs.
const wrap = (ui) => render(ui)

describe('JalaliRange presets', () => {
  const realNow = Date.now
  const realTz = process.env.TZ
  const freeze = (iso) => { const t = new Date(iso).getTime(); Date.now = () => t }

  afterEach(() => { Date.now = realNow; format.setBusinessCutoff(5) })

  it('builds every preset from the business day, not the wall clock', () => {
    freeze('2026-10-23T02:00:00')          // 02:00 → still the 22nd for a 05:00 cutoff
    const today = format.isoDate(format.businessToday())
    expect(today).toBe('2026-10-22')
    expect(rangeOf('today')).toEqual({ from: '2026-10-22', to: '2026-10-22' })
    expect(rangeOf('yesterday')).toEqual({ from: '2026-10-21', to: '2026-10-21' })
    expect(rangeOf('week')).toEqual({ from: '2026-10-16', to: '2026-10-22' })          // 7 days inclusive
    expect(rangeOf('last30')).toEqual({ from: '2026-09-23', to: '2026-10-22' })        // 30 days inclusive
  })

  it('starts "this month" on the Persian month boundary', () => {
    freeze('2026-10-23T12:00:00')          // 1 Aban 1405
    expect(rangeOf('month')).toEqual({ from: '2026-10-23', to: '2026-10-23' })
    freeze('2026-11-05T12:00:00')          // 14 Aban 1405
    expect(rangeOf('month')).toEqual({ from: '2026-10-23', to: '2026-11-05' })
    // "last month" = the whole 1405/07 (Mehr): 23 Sep – 22 Oct 2026
    expect(rangeOf('lastMonth')).toEqual({ from: '2026-09-23', to: '2026-10-22' })
  })

  it('keeps every preset inside the 1403 leap year correctly', () => {
    freeze('2025-03-20T12:00:00')          // 30 Esfand 1403 — the day the old calendar math lost
    expect(rangeOf('today')).toEqual({ from: '2025-03-20', to: '2025-03-20' })
    freeze('2025-03-21T12:00:00')          // 1 Farvardin 1404
    expect(rangeOf('month')).toEqual({ from: '2025-03-21', to: '2025-03-21' })
    expect(rangeOf('lastMonth')).toEqual({ from: '2025-02-19', to: '2025-03-20' })     // all 30 days of Esfand 1403 (a leap year)
  })

  it('highlights the preset that matches the current value', () => {
    freeze('2026-10-23T12:00:00')
    wrap(<JalaliRange value={{ from: '2026-10-23', to: '2026-10-23' }} onChange={() => {}} />)
    expect(screen.getByRole('button', { name: PRESETS.today.label }).className).toContain('ant-btn-primary')
    expect(screen.getByRole('button', { name: PRESETS.week.label }).className).not.toContain('ant-btn-primary')
  })

  it('reports a preset click as an ISO Gregorian range', async () => {
    freeze('2026-10-23T12:00:00')
    const onChange = vi.fn()
    wrap(<JalaliRange value={{ from: '2026-01-01', to: '2026-01-02' }} onChange={onChange} />)
    await userEvent.click(screen.getByRole('button', { name: PRESETS.week.label }))
    expect(onChange).toHaveBeenCalledWith({ from: '2026-10-17', to: '2026-10-23' })
  })

  it('turns a picker value into a local ISO date (no UTC off-by-one)', () => {
    // the picker hands back a dayjs; toDate() is the local calendar day, so 00:30 local stays the same day
    expect(pickerToIso({ toDate: () => new Date(2026, 9, 23, 0, 30) })).toBe('2026-10-23')
    expect(pickerToIso({ toDate: () => new Date(2026, 9, 23, 23, 30) })).toBe('2026-10-23')
  })
})
