import { EyeInvisibleOutlined, FieldTimeOutlined, ShoppingOutlined, WalletOutlined } from '@ant-design/icons'
import { Alert, Card, Col, Descriptions, Empty, Row, Table, Tag } from 'antd'
import { ORDER_TYPES, PAY_METHODS, faDateTime, faTime, money, num } from '../core/format'
import { cashOr, diffInfo } from '../core/shiftview'
import { StatCard } from './common'
import { hm } from './TimeClockButton'

const box = { size: 'small', className: 'card-r' }

/** Body of an end-of-shift report (`data` from /shifts/my-report or a submitted report). */
export default function StaffReportView({ data: d, compact }) {
  if (!d) return null
  const o = d.orders || {}
  const pays = Object.entries(d.payments || {})
  const col = compact ? { xs: 24, md: 12 } : { xs: 24, lg: 12 }
  return (
    <div className="staff-report">
      {d.cash_hidden && (
        <Alert type="warning" showIcon icon={<EyeInvisibleOutlined />} style={{ marginBottom: 12 }} className="cash-hidden"
          message="مبلغ نقدی تا تحویل صندوق پنهان است" description="صندوقی که این پول‌ها در آن است هنوز باز است (شمارش کور). بعد از شمارش و بستن صندوق نمایش داده می‌شود." />
      )}
      <Row gutter={[12, 12]}>
        <Col xs={12} md={6}><StatCard title="مدت حضور" value={d.minutes == null ? '—' : hm(d.minutes)} icon={<FieldTimeOutlined />} color="var(--blue)" /></Col>
        <Col xs={12} md={6}><StatCard title="سفارش تسویه‌شده" value={o.closed || 0} icon={<ShoppingOutlined />} hint={o.open ? `${num(o.open)} سفارش باز` : undefined} /></Col>
        <Col xs={12} md={6}><StatCard title="فروش" value={o.sales || 0} money icon={<WalletOutlined />} color="var(--green)" hint={o.closed ? `میانگین ${money(o.avg)}` : undefined} /></Col>
        <Col xs={12} md={6}><StatCard title="دریافتی شما" value={d.collected_total == null ? 'پنهان' : d.collected_total} money={d.collected_total != null} icon="💰" color="var(--amber)" hint={`${num(d.payments_count || 0)} پرداخت`} /></Col>
      </Row>

      {(d.drawer || (d.drawers_closed || []).length > 0) && (
        <Card {...box} title="تحویل صندوق" style={{ marginTop: 12 }}>
          {d.drawer && <Alert type="error" showIcon className="drawer-held" message={`«${d.drawer.register_name || 'صندوق'}» به نام شما باز است`}
            description={`از ${faTime(d.drawer.opened_at)} با موجودی اول ${money(d.drawer.opening_cash)} تومان. پیش از پایان شیفت، پول را بشمارید و صندوق را تحویل دهید.`} />}
          {(d.drawers_closed || []).map((s) => {
            const x = diffInfo(s.difference)
            return (
              <Descriptions key={s.shift_id} size="small" column={{ xs: 1, md: 4 }} style={{ marginTop: 8 }}>
                <Descriptions.Item label="صندوق">{s.register_name || '—'} (#{num(s.shift_id)})</Descriptions.Item>
                <Descriptions.Item label="تحویل">{faTime(s.closed_at)}</Descriptions.Item>
                <Descriptions.Item label="شمارش / انتظار">{money(s.counted_cash)} / {money(s.expected_cash)}</Descriptions.Item>
                <Descriptions.Item label="مغایرت"><Tag className="drawer-diff" color={x.tone === 'success' ? 'green' : x.tone === 'info' ? 'blue' : 'red'}>{x.text}</Tag></Descriptions.Item>
              </Descriptions>
            )
          })}
        </Card>
      )}

      <Row gutter={[12, 12]} style={{ marginTop: 12 }}>
        <Col {...col}>
          <Card {...box} title="دریافت‌ها به تفکیک روش">
            {pays.length ? (
              <Descriptions size="small" column={1}>
                {pays.map(([m, v]) => <Descriptions.Item key={m} label={`${PAY_METHODS[m]?.icon || ''} ${PAY_METHODS[m]?.label || m}`}><b className={m === 'cash' ? 'pay-cash' : ''}>{cashOr(v)}</b></Descriptions.Item>)}
                {d.refunds?.count > 0 && <Descriptions.Item label="بازپرداخت">{num(d.refunds.count)} مورد — {money(d.refunds.amount)}</Descriptions.Item>}
              </Descriptions>
            ) : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="پرداختی ثبت نکرده‌اید" />}
          </Card>
        </Col>
        <Col {...col}>
          <Card {...box} title="فروش به تفکیک نوع سفارش">
            {Object.keys(o.by_type || {}).length ? (
              <Descriptions size="small" column={1}>
                {Object.entries(o.by_type).map(([t, v]) => <Descriptions.Item key={t} label={`${ORDER_TYPES[t]?.icon || ''} ${ORDER_TYPES[t]?.label || t} (${num(v.count)})`}>{money(v.amount)}</Descriptions.Item>)}
                {o.guests > 0 && <Descriptions.Item label="مهمان">{num(o.guests)} نفر</Descriptions.Item>}
              </Descriptions>
            ) : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="سفارش تسویه‌شده‌ای ندارید" />}
          </Card>
        </Col>
        <Col {...col}>
          <Card {...box} title="پرفروش‌های شما">
            <Table size="small" rowKey="name" pagination={false} dataSource={d.top_items || []} locale={{ emptyText: '—' }}
              columns={[{ title: 'آیتم', dataIndex: 'name' }, { title: 'تعداد', dataIndex: 'qty', render: (v) => num(v) }, { title: 'مبلغ', dataIndex: 'amount', render: (v) => money(v) }]} />
          </Card>
        </Col>
        <Col {...col}>
          <Card {...box} title="کنترل (تخفیف، حذف، لغو)">
            <Descriptions size="small" column={1}>
              <Descriptions.Item label="تخفیف داده‌شده">{num(d.discounts?.count || 0)} مورد — {money(d.discounts?.amount)}</Descriptions.Item>
              <Descriptions.Item label="آیتم حذف‌شده">{num(d.voids?.count || 0)} مورد — {money(d.voids?.amount)}</Descriptions.Item>
              <Descriptions.Item label="سفارش لغوشده">{num(d.cancels?.count || 0)} مورد — {money(d.cancels?.amount)}</Descriptions.Item>
            </Descriptions>
            {(d.voids?.items || []).length > 0 && <ul className="void-list">{d.voids.items.map((v, i) => <li key={i}>{v.summary}{v.approver ? ` (تأیید: ${v.approver})` : ''}</li>)}</ul>}
          </Card>
        </Col>
      </Row>

      {(d.open_orders || []).length > 0 && (
        <Card {...box} style={{ marginTop: 12 }} className="open-orders-card" title={<span>سفارش‌های باز برای تحویل به شیفت بعد <Tag color="orange">{num(d.open_orders.length)}</Tag></span>}>
          <Table size="small" rowKey="id" pagination={false} dataSource={d.open_orders} scroll={{ x: 520 }}
            columns={[
              { title: 'سفارش', dataIndex: 'number', render: (v) => `#${num(v)}` },
              { title: 'نوع', dataIndex: 'type', render: (t, r) => `${ORDER_TYPES[t]?.label || t}${r.table ? ` — میز ${r.table}` : ''}` },
              { title: 'مبلغ', dataIndex: 'total', render: (v) => money(v) },
              { title: 'پرداخت‌شده', dataIndex: 'paid', render: (v) => money(v) },
              { title: 'از', dataIndex: 'created_at', render: faTime },
            ]} />
        </Card>
      )}
      {(d.cash_moves || []).length > 0 && (
        <Card {...box} style={{ marginTop: 12 }} title="واریز / برداشت ثبت‌شده توسط شما">
          <Table size="small" rowKey="at" pagination={false} dataSource={d.cash_moves}
            columns={[
              { title: 'نوع', dataIndex: 'kind', render: (k) => (k === 'in' ? <Tag color="green">واریز</Tag> : <Tag color="red">برداشت</Tag>) },
              { title: 'مبلغ', dataIndex: 'amount', render: (v) => money(v) }, { title: 'بابت', dataIndex: 'reason' }, { title: 'زمان', dataIndex: 'at', render: faDateTime },
            ]} />
        </Card>
      )}
    </div>
  )
}
