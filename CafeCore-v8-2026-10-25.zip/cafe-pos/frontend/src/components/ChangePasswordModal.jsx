import { LockOutlined, SafetyCertificateOutlined } from '@ant-design/icons'
import { Alert, App, Form, Input, Modal } from 'antd'
import { useState } from 'react'
import { useAuth } from '../core/auth'

/** Change own password. `forced` = first login with a factory password: cannot be dismissed (only logout). */
export default function ChangePasswordModal({ open, onClose, forced = false }) {
  const auth = useAuth()
  const { message } = App.useApp()
  const [form] = Form.useForm()
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    const v = await form.validateFields().catch(() => null)   // invalid fields are shown on the form
    if (!v) return
    setBusy(true)
    try {
      await auth.changePassword(v.current, v.next)
      message.success('رمز عبور تغییر کرد؛ سایر دستگاه‌هایی که با رمز قبلی وارد شده‌اند خارج شدند')
      form.resetFields()
      onClose?.()
    } catch (e) {
      message.error(e.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <Modal
      open={open}
      title={<span>{forced ? <SafetyCertificateOutlined /> : <LockOutlined />} {forced ? 'تغییر رمز عبور پیش‌فرض' : 'تغییر رمز عبور'}</span>}
      okText="ذخیره رمز جدید" cancelText={forced ? 'خروج از حساب' : 'انصراف'}
      onOk={submit} confirmLoading={busy}
      onCancel={() => (forced ? auth.logout() : onClose?.())}
      closable={!forced} maskClosable={false} keyboard={!forced} destroyOnClose
    >
      {forced && (
        <Alert type="warning" showIcon style={{ marginBottom: 16 }}
          message="این حساب هنوز رمز پیش‌فرض کارخانه را دارد"
          description="برای امنیت اطلاعات فروش و صندوق، پیش از ادامه یک رمز جدید انتخاب کنید." />
      )}
      <Form form={form} layout="vertical" onFinish={submit} autoComplete="off">
        <Form.Item name="current" label="رمز فعلی" rules={[{ required: true, message: 'رمز فعلی را وارد کنید' }]}>
          <Input.Password autoFocus autoComplete="current-password" />
        </Form.Item>
        <Form.Item name="next" label="رمز جدید" hasFeedback
          rules={[{ required: true, message: 'رمز جدید را وارد کنید' }, { min: 8, message: 'حداقل ۸ کاراکتر' }]}>
          <Input.Password autoComplete="new-password" />
        </Form.Item>
        <Form.Item name="confirm" label="تکرار رمز جدید" dependencies={['next']} hasFeedback
          rules={[{ required: true, message: 'تکرار رمز را وارد کنید' },
            ({ getFieldValue }) => ({ validator: (_, v) => (!v || v === getFieldValue('next') ? Promise.resolve() : Promise.reject(new Error('تکرار رمز با رمز جدید یکسان نیست'))) })]}>
          <Input.Password autoComplete="new-password" onPressEnter={submit} />
        </Form.Item>
      </Form>
    </Modal>
  )
}
