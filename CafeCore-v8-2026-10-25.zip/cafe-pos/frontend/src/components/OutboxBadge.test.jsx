import { act, render, screen } from '@testing-library/react'
import { App } from 'antd'
import { describe, expect, it, vi } from 'vitest'

vi.mock('../core/realtime', () => ({ subscribe: () => () => {} }))
const { enqueue, dropEntry } = await import('../core/outbox')
const { default: OutboxBadge } = await import('./OutboxBadge')

describe('<OutboxBadge>', () => {
  it('is hidden while the queue is empty and follows queue changes', () => {
    const { container } = render(<App><OutboxBadge /></App>)
    expect(container.querySelector('.outbox-tag')).toBeNull()
    act(() => enqueue({ id: 'req-ui000000', kind: 'create', draft: { type: 'takeaway' }, lines: [{ menu_item_id: 1, qty: 1 }], send: true }))
    expect(screen.getByText('صف آفلاین')).toBeTruthy()
    expect(container.querySelector('.ant-badge-count').textContent).toMatch(/1|۱/)
    act(() => dropEntry('req-ui000000'))
    expect(container.querySelector('.outbox-tag')).toBeNull()
  })
})
