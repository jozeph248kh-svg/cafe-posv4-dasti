import { Button, Space } from 'antd'
import { DatePicker as JDatePicker, JalaliLocaleListener } from 'antd-jalali'
import dayjs from 'dayjs'
import { businessToday, isoDate } from '../core/format'

// NOTE: antd-jalali also installs dayjs' own `calendar` plugin which shadows jalaliday's `.calendar('jalali')`,
// so all date math here uses native Date + Intl's Persian calendar, and picker values are converted via toDate().
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const jDay = (d) => Number(new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', { day: 'numeric' }).format(d))
const jMonthStart = (d) => addDays(d, 1 - jDay(d))
const today = businessToday       // presets follow the business day (same basis as the server's reports)

export const PRESETS = {
  today: { label: 'امروز', range: () => [today(), today()] },
  yesterday: { label: 'دیروز', range: () => [addDays(today(), -1), addDays(today(), -1)] },
  week: { label: '۷ روز اخیر', range: () => [addDays(today(), -6), today()] },
  month: { label: 'این ماه', range: () => [jMonthStart(today()), today()] },
  last30: { label: '۳۰ روز اخیر', range: () => [addDays(today(), -29), today()] },
  lastMonth: { label: 'ماه قبل', range: () => { const end = addDays(jMonthStart(today()), -1); return [jMonthStart(end), end] } },
}

export const pickerToIso = (d) => isoDate(d.toDate())

/** Persian (Jalali) date-range picker. value/onChange use Gregorian ISO strings: { from, to }. */
export default function JalaliRange({ value, onChange, presets = ['today', 'yesterday', 'week', 'month', 'last30'] }) {
  const v = value?.from ? [dayjs(value.from), dayjs(value.to)] : null
  const pickDates = (r) => onChange({ from: isoDate(r[0]), to: isoDate(r[1]) })
  const active = presets.find((p) => { const r = PRESETS[p].range(); return value && isoDate(r[0]) === value.from && isoDate(r[1]) === value.to })
  return (
    <Space wrap size={6}>
      <JalaliLocaleListener />
      <Space.Compact className="jr-presets">
        {presets.map((p) => (
          <Button key={p} type={active === p ? 'primary' : 'default'} onClick={() => pickDates(PRESETS[p].range())}>{PRESETS[p].label}</Button>
        ))}
      </Space.Compact>
      <JDatePicker.RangePicker value={v} allowClear={false} onChange={(r) => r && pickDates([r[0].toDate(), r[1].toDate()])} format="YYYY/MM/DD" style={{ width: 250 }} />
    </Space>
  )
}

export const rangeOf = (preset) => { const r = PRESETS[preset].range(); return { from: isoDate(r[0]), to: isoDate(r[1]) } }
