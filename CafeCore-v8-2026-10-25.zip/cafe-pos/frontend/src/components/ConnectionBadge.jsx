import { Badge, Tooltip } from 'antd'
import { useWsStatus } from '../core/realtime'

const MAP = { online: ['success', 'اتصال زنده برقرار است'], connecting: ['processing', 'در حال اتصال...'], offline: ['error', 'اتصال زنده قطع است؛ تلاش مجدد خودکار'] }

export default function ConnectionBadge({ label }) {
  const s = useWsStatus()
  return <Tooltip title={MAP[s][1]}><Badge status={MAP[s][0]} text={label ? (s === 'online' ? 'آنلاین' : 'آفلاین') : undefined} style={{ paddingInline: 8 }} /></Tooltip>
}
