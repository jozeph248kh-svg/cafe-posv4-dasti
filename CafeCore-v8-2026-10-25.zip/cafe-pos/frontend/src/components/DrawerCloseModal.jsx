import { EyeInvisibleOutlined } from '@ant-design/icons'
import { Alert, App, Form, Input, InputNumber, Modal, Typography } from 'antd'
import { useState } from 'react'
import { post } from '../core/api'
import { useAuth } from '../core/auth'
import { money, moneyFormatter, moneyParser } from '../core/format'
import { printShift } from '../core/print'
import { denomTotal, diffInfo } from '../core/shiftview'

export const DENOMS = [100_000, 50_000, 20_000, 10_000, 5_000, 2_000, 1_000, 500]  // common Iranian banknotes / Iran Cheques (toman)

/** Count and close a cash drawer. Blind count: when the server withholds `expected_cash` (null) the counter
 *  doesn't see the target; the difference is shown only after the count is saved. */
export default function DrawerCloseModal({ open, shift, title, onClose, onClosed }) {
  const auth = useAuth()
  const { message, modal } = App.useApp()
  const [form] = Form.useForm()
  const [counts, setCounts] = useState({})
  const [busy, setBusy] = useState(false)
  const blind = shift && shift.expected_cash == null

  const close = () => { setCounts({}); onClose?.() }
  const submit = async (v) => {
    setBusy(true)
    try {
      const closed = await post('/shifts/close', { counted_cash: v.amount ?? 0, note: v.note, register_id: shift.register_id })
      const d = diffInfo(closed.difference)
      setCounts({})
      onClosed?.(closed)
      const show = closed.difference === 0 ? modal.success : closed.difference > 0 ? modal.info : modal.warning
      show({
        title: 'صندوق بسته و تحویل شد',
        content: <div className="drawer-result">
          <div>نقد شمارش‌شده: <b>{money(closed.counted_cash)}</b> تومان</div>
          <div>نقد مورد انتظار: <b>{money(closed.expected_cash)}</b> تومان</div>
          <Alert style={{ marginTop: 10 }} type={d.tone} showIcon message={d.text} />
        </div>,
        okText: 'چاپ گزارش صندوق', closable: true, onOk: () => printShift(closed, auth.settings),
      })
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }

  return (
    <Modal open={open} onCancel={close} onOk={() => form.submit()} confirmLoading={busy} destroyOnClose width={620}
      title={title || 'بستن صندوق و شمارش پول'} okText="ثبت شمارش و بستن صندوق" okButtonProps={{ danger: true, className: 'drawer-close-ok' }}>
      <Form form={form} layout="vertical" onFinish={submit} preserve={false}>
        {shift && (blind
          ? <Alert type="warning" showIcon icon={<EyeInvisibleOutlined />} style={{ marginBottom: 12 }} className="blind-alert"
              message="شمارش کور" description="پول داخل صندوق را دقیق بشمارید و مبلغ را وارد کنید. مبلغ مورد انتظار و مغایرت پس از ثبت شمارش نمایش داده می‌شود." />
          : <Alert type="info" showIcon style={{ marginBottom: 12 }} message={`نقد مورد انتظار در صندوق: ${money(shift.expected_cash)} تومان`} />)}
        <Typography.Text type="secondary">شمارش اسکناس‌ها (اختیاری):</Typography.Text>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, margin: '8px 0 12px' }}>
          {DENOMS.map((d) => (
            <InputNumber key={d} min={0} placeholder="تعداد" addonBefore={money(d)} size="small" value={counts[d]}
              onChange={(n) => { const c = { ...counts, [d]: n }; setCounts(c); form.setFieldValue('amount', denomTotal(c)) }} />
          ))}
        </div>
        <Form.Item name="amount" label="جمع نقد شمارش‌شده" rules={[{ required: true, message: 'مبلغ را وارد کنید' }]}>
          <InputNumber min={0} size="large" style={{ width: '100%' }} formatter={moneyFormatter} parser={moneyParser} addonAfter="تومان" autoFocus className="drawer-counted" />
        </Form.Item>
        {shift && !blind && (
          <Form.Item shouldUpdate noStyle>{() => {
            const v = form.getFieldValue('amount')
            if (v == null) return null
            const d = diffInfo(v - shift.expected_cash)
            return <Alert type={d.tone} message={d.text} style={{ marginBottom: 12 }} />
          }}</Form.Item>
        )}
        <Form.Item name="note" label="یادداشت"><Input.TextArea rows={2} /></Form.Item>
      </Form>
      {denomTotal(counts) > 0 && <Typography.Text type="secondary">جمع شمارش: {money(denomTotal(counts))}</Typography.Text>}
    </Modal>
  )
}
