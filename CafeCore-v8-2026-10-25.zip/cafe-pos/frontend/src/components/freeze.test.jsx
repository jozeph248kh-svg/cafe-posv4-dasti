import { describe, expect, it, vi, beforeEach } from 'vitest'
import { fireEvent, render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * REGRESSION: two freeze-class bugs around the manager-PIN approval flow.
 *
 * 1. OverrideProvider kept a single `resolver`. When two requests needed approval at the same time
 *    (e.g. a discount and a refund), the second overwrote the first — the first promise never
 *    settled, its `await` hung forever and the POS stayed on a spinner: only a reload helped.
 * 2. The retry in core/api never set the flag it checks (`X-Manager-Pin-Retry`), so a server that
 *    kept answering "override required" re-opened the PIN dialog endlessly.
 */
const get = vi.fn()
const post = vi.fn()
vi.mock('../core/api', async (orig) => {
  const actual = await orig()
  return { ...actual, get: (...a) => get(...a), post: (...a) => post(...a) }
})

const text = () => document.body.textContent.replace(/\s+/g, ' ')
const pin = (digits) => digits.forEach((d) => screen.getAllByRole('button').find((x) => x.textContent === d).click())
const okRes = (body) => ({ ok: true, status: 200, headers: { get: () => 'application/json' }, json: async () => body })
const errRes = (code, message) => ({ ok: false, status: 403, headers: { get: () => 'application/json' }, json: async () => ({ detail: { message, code } }) })
const race = (p, ms, label) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(`${label} hung`)), ms))])

describe('manager approval', () => {
  beforeEach(() => { localStorage.setItem('cafe_token', 't') })

  it('settles BOTH requests when two need approval at the same time', async () => {
    global.fetch = vi.fn(async (url, opts) => (opts.headers['X-Manager-Pin'] ? okRes({ ok: true, path: String(url) }) : errRes('override_required', 'تأیید مدیر لازم است')))
    const { default: OverrideProvider } = await import('./OverrideProvider')
    const { api, setToken } = await import('../core/api')
    setToken('t')
    render(<App><OverrideProvider><div /></OverrideProvider></App>)

    const a = api('/orders/1/discount', { method: 'POST' })
    const b = api('/orders/2/refund', { method: 'POST' })

    await waitFor(() => expect(text()).toContain('تأیید مدیر'))
    pin(['۱', '۲', '۳', '۴'])

    // A must settle first…
    await expect(race(a, 5000, 'request A')).resolves.toBeTruthy()
    // …and then B gets its own dialog instead of hanging for ever
    await waitFor(() => expect(document.querySelector('.ant-modal')).toBeTruthy(), { timeout: 4000 })
    await new Promise((r) => setTimeout(r, 300))
    pin(['۱', '۲', '۳', '۴'])
    await expect(race(b, 5000, 'request B')).resolves.toBeTruthy()
  })

  it('asks for the PIN once when the server keeps refusing (no endless dialog loop)', async () => {
    const withPin = []
    global.fetch = vi.fn(async (url, opts) => {
      if (opts.headers['X-Manager-Pin']) withPin.push(opts.headers['X-Manager-Pin'])
      return errRes('override_invalid', 'رمز نامعتبر است')
    })
    const { default: OverrideProvider } = await import('./OverrideProvider')
    const { api, setToken } = await import('../core/api')
    setToken('t')
    render(<App><OverrideProvider><div /></OverrideProvider></App>)

    const p = api('/orders/9/void', { method: 'POST' })
    await waitFor(() => expect(text()).toContain('تأیید'))
    pin(['۹', '۹', '۹', '۹'])

    // it must give up by itself with an ApiError — not hang waiting for a third PIN
    await expect(race(p, 5000, 'the request')).rejects.toMatchObject({ status: 403 })
    expect(withPin).toHaveLength(1)      // exactly one retry with a PIN, then it gives up
  })
})
