/**
 * «ظاهر» quick picker for the top bars (admin header, launcher, POS): light/dark/auto, this device's skin and text size.
 * Everything here is stored on this device only; the business default is set in Settings → «ظاهر و تم».
 */
import { BgColorsOutlined, CheckOutlined, MoonOutlined, SunOutlined } from '@ant-design/icons'
import { Button, Popover, Segmented, Tooltip } from 'antd'
import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../core/auth'
import { derive, findSkin, SCALES } from '../core/skins'
import { useTheme } from '../core/theme'

/** round swatch: page / card / primary of a skin in the given mode */
export function SkinSwatch({ skin, dark, size = 30 }) {
  const m = dark ? skin.dark : skin.light
  return (
    <span className="skin-swatch" style={{ width: size, height: size, background: `conic-gradient(${m.primary} 0 33%, ${m.card} 0 66%, ${m.sider} 0)`, borderColor: m.border }} />
  )
}

export const MODE_OPTIONS = [
  { value: '0', label: <span><SunOutlined /> روشن</span> },
  { value: '1', label: <span><MoonOutlined /> تیره</span> },
  { value: 'auto', label: 'خودکار' },
]
export const SCALE_OPTIONS = [{ value: 'skin', label: 'طبق تم' }, ...SCALES.map((s) => ({ value: String(s.value), label: s.value === 1.2 ? 'بزرگ‌تر' : s.label }))]

/** device-level controls (also used at the top of Settings → «ظاهر و تم») */
export function DevicePrefs({ onManage }) {
  const t = useTheme()
  const businessSkin = useMemo(() => findSkin(t.business.skin, t.business.custom), [t.business])
  return (
    <div className="ts-pop">
      <div className="ts-label">حالت نمایش</div>
      <Segmented block value={t.mode} onChange={t.setMode} options={MODE_OPTIONS} className="ts-mode" />
      <div className="ts-label">تم این دستگاه</div>
      <div className="ts-skins">
        <button type="button" className={`ts-skin ${!t.deviceSkin ? 'on' : ''}`} onClick={() => t.setDeviceSkin('')}>
          <SkinSwatch skin={businessSkin} dark={t.dark} />
          <span>پیش‌فرض مجموعه<small>{businessSkin.name}</small></span>
          {!t.deviceSkin && <CheckOutlined />}
        </button>
        {t.skins.map((s) => (
          <button type="button" key={s.id} className={`ts-skin ${t.deviceSkin === s.id ? 'on' : ''}`} onClick={() => t.setDeviceSkin(s.id)}>
            <SkinSwatch skin={s} dark={t.dark} />
            <span>{s.name}</span>
            {t.deviceSkin === s.id && <CheckOutlined />}
          </button>
        ))}
      </div>
      <div className="ts-label">اندازهٔ متن</div>
      <Segmented block size="small" value={t.deviceScale || 'skin'} onChange={(v) => t.setDeviceScale(v === 'skin' ? '' : v)} options={SCALE_OPTIONS} className="ts-scale" />
      {onManage && <Button type="link" block onClick={onManage} style={{ marginTop: 6 }}>ساخت و ویرایش تم‌ها…</Button>}
    </div>
  )
}

export default function ThemeSwitcher({ type = 'text' }) {
  const t = useTheme()
  const auth = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const manage = auth?.can?.('settings.manage') ? () => { setOpen(false); nav('/admin/settings?tab=theme') } : null
  // derive() is cheap, but only needed for the icon tint
  const tint = useMemo(() => derive(t.skin, t.dark).vars['--primary-text'], [t.skin, t.dark])
  return (
    <Popover open={open} onOpenChange={setOpen} trigger="click" placement="bottomLeft" title="ظاهر برنامه (فقط این دستگاه)"
      content={<DevicePrefs onManage={manage} />} overlayClassName="ts-popover">
      <Tooltip title="ظاهر و تم" open={open ? false : undefined}>
        <Button type={type} className="theme-switch" aria-label="ظاهر و تم" icon={<BgColorsOutlined style={{ color: tint }} />} />
      </Tooltip>
    </Popover>
  )
}
