import { DeleteOutlined } from '@ant-design/icons'
import { useCallback, useEffect, useState } from 'react'
import { toEnDigits } from '../core/format'

/** Numeric PIN pad (touch + physical keyboard). Calls onSubmit(pin) at `length` digits or Enter. */
export default function PinPad({ onSubmit, length = 4, maxLength = 8, loading, error, dark }) {
  const [pin, setPin] = useState('')
  const [shake, setShake] = useState(false)

  useEffect(() => {
    if (error) { setShake(true); setPin(''); const t = setTimeout(() => setShake(false), 500); return () => clearTimeout(t) }
  }, [error])

  const submit = useCallback((p) => { if (p.length >= 4 && !loading) onSubmit(p) }, [onSubmit, loading])
  const press = useCallback((d) => {
    setPin((p) => {
      if (p.length >= maxLength) return p
      const next = p + d
      if (next.length === length) setTimeout(() => submit(next), 80)
      return next
    })
  }, [length, maxLength, submit])

  useEffect(() => {
    const onKey = (e) => {
      // let real text fields keep their keys; radios/checkboxes (e.g. the Segmented mode switch) must not swallow the PIN
      const el = document.activeElement
      if (el?.tagName === 'TEXTAREA' || el?.isContentEditable || (el?.tagName === 'INPUT' && !['radio', 'checkbox', 'button'].includes(el.type))) return
      const k = toEnDigits(e.key)
      if (/^\d$/.test(k)) press(k)
      else if (e.key === 'Backspace') setPin((p) => p.slice(0, -1))
      else if (e.key === 'Enter') submit(pin)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [press, submit, pin])

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'back']
  return (
    <div className={`pinpad ${dark ? 'pinpad-dark' : ''}`}>
      <div className={`pin-dots ${shake ? 'shake' : ''}`}>
        {Array.from({ length: Math.max(length, pin.length) }).map((_, i) => <span key={i} className={i < pin.length ? 'on' : ''} />)}
      </div>
      <div className="pin-grid">
        {keys.map((k) => (
          <button key={k} type="button" disabled={loading} className={`pin-key ${k.length > 1 ? 'pin-fn' : ''}`}
            onClick={() => (k === 'back' ? setPin((p) => p.slice(0, -1)) : k === 'clear' ? setPin('') : press(k))}>
            {k === 'back' ? <DeleteOutlined /> : k === 'clear' ? 'پاک' : Number(k).toLocaleString('fa-IR')}
          </button>
        ))}
      </div>
    </div>
  )
}
