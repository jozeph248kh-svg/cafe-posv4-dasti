import { describe, expect, it, vi } from 'vitest'
import { render, waitFor, screen } from '@testing-library/react'
import { App } from 'antd'

/**
 * The end-of-shift report body — the page an employee fills and a manager reads. It carries the
 * hand-over of the cash drawer, so the difference (over/short) and the "cash hidden" warning are the
 * two things pinned here.
 */
const text = () => document.body.textContent.replace(/\s+/g, ' ')

const { default: StaffReportView } = await import('./StaffReportView')

const DATA = {
  minutes: 510, orders: { closed: 12, open: 1, sales: 3_000_000, avg: 250_000 },
  payments: { cash: 1_400_000, card: 1_600_000 }, payments_count: 14, collected_total: 1_400_000,
  drawer: null,
  drawers_closed: [{ register_name: 'صندوق اصلی', expected_cash: 800_800, counted_cash: 800_000, difference: -800, opened_at: '2026-10-23T09:00:00', closed_at: '2026-10-23T17:00:00' }],
  cash_hidden: false,
}

describe('StaffReportView', () => {
  it('shows attendance, orders, sales and what the employee collected', () => {
    render(<App><StaffReportView data={DATA} /></App>)
    const t = text()
    expect(t).toContain('مدت حضور')
    expect(t).toContain('۸ ساعت و ۳۰ دقیقه')
    expect(t).toContain('۱۲')                       // settled orders
    expect(t).toContain('۳٬۰۰۰٬۰۰۰')                // sales
    expect(t).toContain('دریافتی شما')
  })

  it('shows the drawer hand-over with its difference', async () => {
    render(<App><StaffReportView data={DATA} /></App>)
    await waitFor(() => expect(text()).toContain('تحویل صندوق'))
    expect(text()).toMatch(/کسری|مغایرت|۸۰۰/)
  })

  it('warns when the cash is hidden because the drawer is still open (blind count)', async () => {
    render(<App><StaffReportView data={{ ...DATA, cash_hidden: true, collected_total: null }} /></App>)
    await waitFor(() => expect(text()).toContain('پنهان'))
    expect(document.querySelector('.cash-hidden')).toBeTruthy()
  })

  it('warns when a drawer is still held open by this employee', async () => {
    render(<App><StaffReportView data={{ ...DATA, drawer: { register_name: 'صندوق بیرون‌بر', opened_at: '2026-10-23T09:00:00', opening_cash: 500_000 } }} /></App>)
    await waitFor(() => expect(document.querySelector('.drawer-held')).toBeTruthy())
    expect(text()).toContain('صندوق بیرون‌بر')
  })

  it('renders nothing without data', () => {
    const { container } = render(<App><StaffReportView data={null} /></App>)
    expect(container.textContent).toBe('')
  })

  it('splits the payments by method', () => {
    render(<App><StaffReportView data={DATA} /></App>)
    expect(text()).toContain('نقد')
    expect(text()).toContain('کارتخوان')
  })
})
