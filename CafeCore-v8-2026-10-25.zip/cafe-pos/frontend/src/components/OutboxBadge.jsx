import { CloudUploadOutlined, DeleteOutlined, ReloadOutlined } from '@ant-design/icons'
import { Badge, Button, List, Popconfirm, Popover, Tag, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { ORDER_TYPES, num, timeAgo } from '../core/format'
import { dropEntry, flushOutbox, outboxList, retryEntry } from '../core/outbox'

/** Header badge for this device's offline queue; hidden while empty. */
export default function OutboxBadge() {
  const [items, setItems] = useState(outboxList())
  useEffect(() => {
    const f = () => setItems(outboxList())
    window.addEventListener('outbox:changed', f)
    return () => window.removeEventListener('outbox:changed', f)
  }, [])
  if (!items.length) return null
  const failed = items.filter((x) => x.error).length
  const content = (
    <div style={{ width: 340 }}>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
        این سفارش‌ها هنگام قطع ارتباط با سرور روی همین دستگاه ذخیره شده‌اند و با وصل شدن، خودکار (بدون تکرار) ارسال می‌شوند. این صفحه را نبندید و مرورگر را پاک نکنید.
      </Typography.Paragraph>
      <List size="small" dataSource={items} renderItem={(e) => (
        <List.Item className="outbox-item" actions={[
          e.error && <Button key="r" size="small" type="text" icon={<ReloadOutlined />} onClick={() => retryEntry(e.id)} />,
          <Popconfirm key="d" title="این سفارش از صف حذف شود؟ (به سرور ارسال نمی‌شود)" okText="حذف" cancelText="انصراف" okButtonProps={{ danger: true }} onConfirm={() => dropEntry(e.id)}>
            <Button size="small" type="text" danger icon={<DeleteOutlined />} />
          </Popconfirm>,
        ].filter(Boolean)}>
          <List.Item.Meta
            title={<span>{e.kind === 'lines' ? `افزودن به سفارش #${num(e.order_number || e.order_id)}` : `${ORDER_TYPES[e.draft?.type]?.label || 'سفارش'} ${e.draft?.table_name ? `· میز ${e.draft.table_name}` : ''}`}</span>}
            description={<span style={{ fontSize: 12 }}>{num(e.lines.reduce((a, l) => a + l.qty, 0))} قلم · {timeAgo(new Date(e.created_at))}{e.error && <div style={{ color: 'var(--ant-color-error, #ff4d4f)' }}>{e.error}</div>}</span>}
          />
        </List.Item>
      )} />
      <Button block icon={<CloudUploadOutlined />} onClick={() => flushOutbox()}>ارسال الان</Button>
    </div>
  )
  return (
    <Popover content={content} title="صف آفلاین این دستگاه" trigger="click" placement="bottom">
      <Badge count={items.length} size="small" color={failed ? 'red' : 'orange'}>
        <Tag className="outbox-tag" color={failed ? 'red' : 'orange'} icon={<CloudUploadOutlined />} style={{ cursor: 'pointer', marginInlineEnd: 0 }}>صف آفلاین</Tag>
      </Badge>
    </Popover>
  )
}
