/**
 * Cash registers (صندوق‌ها): picking this device's register and managing the list (managers).
 */
import { PlusOutlined } from '@ant-design/icons'
import { App, Button, Input, InputNumber, Modal, Select, Space, Switch, Table, Tag, Typography } from 'antd'
import { useState } from 'react'
import { post, put } from '../core/api'
import { getRegisterId, setRegisterId } from '../core/register'
import { useFetch } from '../core/useFetch'

export const registerOptions = (list) => (list || []).filter((r) => r.is_active).map((r) => ({
  value: r.id,
  label: <span>{r.name} {r.open_shift ? <Tag color="green" style={{ marginInlineStart: 6 }}>باز</Tag> : <Tag style={{ marginInlineStart: 6 }}>بسته</Tag>}</span>,
}))

/** Asks which register this device uses (shown when there are several and the device hasn't chosen yet). */
export function DeviceRegisterModal({ open, registers, onDone }) {
  const [val, setVal] = useState(null)
  return (
    <Modal open={open} title="این دستگاه از کدام صندوق استفاده می‌کند؟" closable={false} maskClosable={false} okText="ذخیره" cancelButtonProps={{ style: { display: 'none' } }}
      okButtonProps={{ disabled: !val, className: 'reg-pick-ok' }} onOk={() => { setRegisterId(val); onDone?.(val) }}>
      <Typography.Paragraph type="secondary">پرداخت‌ها و برداشت/واریز نقدی این دستگاه در شیفتِ صندوقی که انتخاب می‌کنید ثبت می‌شود. بعداً از صفحه «شیفت و صندوق» قابل تغییر است.</Typography.Paragraph>
      <Select className="reg-pick" style={{ width: '100%' }} size="large" placeholder="انتخاب صندوق" value={val} onChange={setVal} options={registerOptions(registers)} />
    </Modal>
  )
}

/** Add / rename / disable registers. */
export function RegisterManager({ open, onClose, onChanged }) {
  const { message } = App.useApp()
  const { data, loading, reload } = useFetch('/shifts/registers', { all: 1 }, { skip: !open, deps: [open] })
  const [name, setName] = useState('')
  const [edit, setEdit] = useState({})
  const done = () => { reload(); onChanged?.() }
  const add = async () => {
    try { await post('/shifts/registers', { name: name.trim() }); setName(''); message.success('صندوق اضافه شد'); done() } catch (e) { message.error(e.message) }
  }
  const save = async (r, patch) => {
    try {
      await put(`/shifts/registers/${r.id}`, { name: r.name, is_active: r.is_active, sort: r.sort, ...edit[r.id], ...patch })
      setEdit(({ [r.id]: _, ...rest }) => rest)
      message.success('ذخیره شد'); done()
    } catch (e) { message.error(e.message) }
  }
  return (
    <Modal open={open} onCancel={onClose} footer={null} title="صندوق‌ها" width={620} destroyOnClose>
      <Typography.Paragraph type="secondary">هر صندوق شیفت، موجودی اول و شمارش پول جداگانه دارد. هر دستگاه (کامپیوتر/تبلت صندوق) یکی را انتخاب می‌کند؛ چند صندوقدار می‌توانند از یک صندوق استفاده کنند.</Typography.Paragraph>
      <Space.Compact style={{ width: '100%', marginBottom: 12 }}>
        <Input className="reg-new-name" placeholder="نام صندوق جدید، مثلاً صندوق بیرون‌بر" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} onPressEnter={() => name.trim().length >= 2 && add()} />
        <Button type="primary" icon={<PlusOutlined />} disabled={name.trim().length < 2} onClick={add}>افزودن</Button>
      </Space.Compact>
      <Table size="small" rowKey="id" loading={loading} dataSource={data || []} pagination={false}
        columns={[
          { title: 'نام', render: (_, r) => (
            <Input value={edit[r.id]?.name ?? r.name} maxLength={40} onChange={(e) => setEdit({ ...edit, [r.id]: { ...edit[r.id], name: e.target.value } })}
              suffix={r.is_main ? <Tag color="blue">اصلی</Tag> : null} />
          ) },
          { title: 'ترتیب', width: 90, render: (_, r) => <InputNumber min={0} max={1000} value={edit[r.id]?.sort ?? r.sort} onChange={(v) => setEdit({ ...edit, [r.id]: { ...edit[r.id], sort: v ?? 0 } })} style={{ width: 70 }} /> },
          { title: 'وضعیت', width: 110, render: (_, r) => (r.open_shift ? <Tag color="green">شیفت باز</Tag> : <Tag>بسته</Tag>) },
          { title: 'فعال', width: 70, render: (_, r) => <Switch size="small" checked={r.is_active} onChange={(v) => save(r, { is_active: v })} /> },
          { title: '', width: 80, render: (_, r) => <Button size="small" type={edit[r.id] ? 'primary' : 'default'} disabled={!edit[r.id]} onClick={() => save(r)}>ذخیره</Button> },
        ]} />
    </Modal>
  )
}

/** The register this device uses, or the main one when none is chosen. */
export const deviceRegister = (list) => {
  const id = getRegisterId()
  const active = (list || []).filter((r) => r.is_active)
  return { chosen: id, valid: !id || active.some((r) => r.id === id), current: active.find((r) => r.id === id) || active.find((r) => r.is_main) || active[0] }
}
