import { ClockCircleOutlined } from '@ant-design/icons'
import { App, Badge, Button, Popconfirm, Tooltip } from 'antd'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { post } from '../core/api'
import { useAuth } from '../core/auth'
import { minutesSince, num } from '../core/format'
import { useFetch } from '../core/useFetch'

export const hm = (m) => {
  const h = Math.floor((m || 0) / 60)
  return h ? `${num(h)} ساعت${m % 60 ? ` و ${num(m % 60)} دقیقه` : ''}` : `${num(m % 60)} دقیقه`
}
export const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : '—')

/** Header button: the signed-in user clocks in/out for themselves (time clock module). */
export default function TimeClockButton({ compact }) {
  const auth = useAuth()
  const { message } = App.useApp()
  const [busy, setBusy] = useState(false)
  const nav = useNavigate()
  const enabled = auth.hasModule('timeclock')
  const { data, setData } = useFetch(enabled ? '/timeclock/me' : null)
  if (!enabled || !data) return null
  // end of shift goes through «شیفت من»: drawer hand-over + report to the manager, then clock-out
  const viaReport = data.on_clock && auth.hasModule('shifts') && auth.settings['shift.report_required'] !== false
  const overdue = data.on_clock && minutesSince(data.since) >= (Number(auth.settings['shift.hours']) || 8) * 60
  const punch = async () => {
    setBusy(true)
    try {
      const r = await post('/timeclock/me/punch')
      setData(r)
      message.success(r.action === 'in' ? `ورود شما ساعت ${clock(r.at)} ثبت شد` : `خروج ثبت شد — ${hm(r.minutes)} کار`)
    } catch (e) { message.error(e.message) } finally { setBusy(false) }
  }
  const label = data.on_clock ? `حاضر از ${clock(data.since)}` : 'ثبت ورود'
  if (viaReport) {
    return (
      <Tooltip title={`${overdue ? 'شیفت شما تمام شده — ' : ''}پایان شیفت: تحویل صندوق، گزارش و ثبت خروج`}>
        <Badge dot={overdue} offset={[-6, 6]}>
          <Button type="text" className={`tc-btn on ${overdue ? 'overdue' : ''}`} icon={<ClockCircleOutlined />} onClick={() => nav('/my-shift')}>{!compact && label}</Button>
        </Badge>
      </Tooltip>
    )
  }
  return (
    <Popconfirm title={data.on_clock ? 'خروج شما ثبت شود؟' : 'ورود شما ثبت شود؟'} okText={data.on_clock ? 'ثبت خروج' : 'ثبت ورود'} cancelText="انصراف" onConfirm={punch}>
      <Tooltip title={`حضور و غیاب — امروز ${hm(data.today_minutes)}`}>
        <Button type="text" loading={busy} className={`tc-btn ${data.on_clock ? 'on' : ''}`} icon={<ClockCircleOutlined />}>{!compact && label}</Button>
      </Tooltip>
    </Popconfirm>
  )
}
