import { ArrowDownOutlined, ArrowUpOutlined } from '@ant-design/icons'
import { Card, Empty, Skeleton, Space, Tag, Typography } from 'antd'
import { inkOn } from '../core/color'
import { compact, money, num } from '../core/format'

export function PageHeader({ title, subtitle, icon, extra }) {
  return (
    <div className="page-header fade-in">
      <div>
        <Typography.Title level={3} style={{ margin: 0 }}>{icon && <span className="ph-icon">{icon}</span>}{title}</Typography.Title>
        {subtitle && <Typography.Text type="secondary">{subtitle}</Typography.Text>}
      </div>
      {extra && <Space wrap>{extra}</Space>}
    </div>
  )
}

export function StatCard({ title, value, suffix, icon, color = 'var(--pal-1)', delta, invert, hint, loading, money: isMoney, onClick, className = '' }) {
  return (
    <Card className={`stat-card hover-lift ${className}`} styles={{ body: { padding: 18 } }} onClick={onClick} style={onClick ? { cursor: 'pointer' } : undefined}>
      {loading ? <Skeleton active paragraph={{ rows: 1 }} /> : (
        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <div className="stat-icon" style={{ background: `color-mix(in srgb, ${color} 13%, var(--card))`, color }}>{icon}</div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <Typography.Text type="secondary" style={{ fontSize: 13 }}>{title}</Typography.Text>
            <div className="stat-value">
              {isMoney ? (Math.abs(value) >= 1e7 ? compact(value) : money(value)) : typeof value === 'number' ? num(value) : value}
              {suffix && <span className="stat-suffix">{suffix}</span>}
            </div>
            {(delta !== undefined && delta !== null) && (
              <Typography.Text style={{ fontSize: 12, color: (delta >= 0) !== !!invert ? 'var(--green)' : 'var(--red)' }}>
                {delta >= 0 ? <ArrowUpOutlined /> : <ArrowDownOutlined />} {num(Math.abs(delta), 1)}٪ <Typography.Text type="secondary" style={{ fontSize: 12 }}>{hint || 'نسبت به دیروز'}</Typography.Text>
              </Typography.Text>
            )}
            {delta === undefined && hint && <Typography.Text type="secondary" style={{ fontSize: 12 }}>{hint}</Typography.Text>}
          </div>
        </div>
      )}
    </Card>
  )
}

/** Tag whose colour comes from data (category, station, expense…): picks white or dark text so it always reads. */
export function DataTag({ color, style, ...rest }) {
  const hex = typeof color === 'string' && color.startsWith('#')
  return <Tag color={color} style={hex ? { color: inkOn(color), ...style } : style} {...rest} />
}

export const pctChange = (a, b) => (b ? ((a - b) / b) * 100 : a ? 100 : 0)

export function EmptyState({ text = 'موردی برای نمایش وجود ندارد', children }) {
  return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={text}>{children}</Empty>
}

export function Money({ value, strong, color, size }) {
  return <span className="money" style={{ fontWeight: strong ? 700 : undefined, color, fontSize: size }}>{money(value)}</span>
}
