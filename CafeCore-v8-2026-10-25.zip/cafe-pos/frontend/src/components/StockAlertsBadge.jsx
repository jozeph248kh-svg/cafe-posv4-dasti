import { WarningOutlined } from '@ant-design/icons'
import { Badge, List, Popover, Tag, Typography } from 'antd'
import { useEffect, useState } from 'react'
import { get } from '../core/api'
import { useAuth } from '../core/auth'
import { num } from '../core/format'
import { useRealtime } from '../core/realtime'

/**
 * Negative-stock alerts for the manager: the till keeps selling when the store is short (the owner's decision),
 * so somebody has to *see* the shortage. This badge sits in the header next to the connection status, refreshes on
 * the `inventory.negative` live event, and lists item / stock before / stock after / shortage.
 */
export default function StockAlertsBadge() {
  const auth = useAuth()
  const canSee = auth.can('inventory.view')
  const [items, setItems] = useState([])
  useEffect(() => {
    if (!canSee) return undefined
    let alive = true
    get('/inventory/alerts').then((r) => alive && setItems(Array.isArray(r) ? r : [])).catch(() => {})
    return () => { alive = false }
  }, [canSee])
  // the live event refreshes the list (a sale that pushed an ingredient below zero)
  useRealtime(canSee ? ['inventory.negative'] : [], () => {
    get('/inventory/alerts').then((r) => setItems(Array.isArray(r) ? r : [])).catch(() => {})
  })
  if (!canSee || !items.length) return null
  const content = (
    <div style={{ width: 380 }}>
      <Typography.Paragraph type="secondary" style={{ fontSize: 12 }}>
        فروش این اقلام از موجودی انبار بیشتر بوده است. فروش متوقف نشده؛ این فهرست برای بررسی و اصلاح موجودی است.
      </Typography.Paragraph>
      <List size="small" dataSource={items} renderItem={(a) => (
        <List.Item className="stock-alert-item">
          <List.Item.Meta
            title={<span><b>{a.name}</b>{a.occurrences > 1 && <Tag color="red" style={{ marginInlineStart: 6 }}>{num(a.occurrences)} بار</Tag>}</span>}
            description={<span style={{ fontSize: 12 }}>
              قبل: {num(a.stock_before, 2)} {a.unit} · بعد: {num(a.stock_after, 2)} {a.unit} ·
              {' '}کسری: <b style={{ color: 'var(--ant-color-error, #ff4d4f)' }}>{num(a.shortage, 2)} {a.unit}</b>
            </span>}
          />
        </List.Item>
      )} />
    </div>
  )
  return (
    <Popover content={content} title="هشدار موجودی منفی" trigger="click" placement="bottom">
      <Badge count={items.length} size="small">
        <Tag className="stock-alert-tag" color="red" icon={<WarningOutlined />} style={{ cursor: 'pointer', marginInlineEnd: 0 }}>
          موجودی منفی
        </Tag>
      </Badge>
    </Popover>
  )
}
