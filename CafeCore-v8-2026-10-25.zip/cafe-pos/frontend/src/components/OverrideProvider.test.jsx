import { describe, expect, it, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import { App } from 'antd'
import OverrideProvider from './OverrideProvider'
import { api, ApiError, setToken } from '../core/api'

// Manager approval is the gate in front of void / discount / refund / cancel. `api()` calls the
// registered handler when the server answers 403 override_required and retries with X-Manager-Pin.
// A bug here either lets an unapproved action through or blocks the cashier for good, so the whole
// loop is exercised against a stubbed fetch.
const wrap = (ui) => render(<App>{ui}</App>)

const respond = (body, status = 200, headers = {}) => ({
  ok: status < 400, status, headers: { get: (k) => headers[k] ?? 'application/json' },
  json: async () => body, text: async () => JSON.stringify(body),
})

describe('manager override', () => {
  it('asks for a PIN and retries the request with X-Manager-Pin', async () => {
    setToken('t')
    const seen = []
    global.fetch = vi.fn(async (url, opts) => {
      seen.push(opts.headers['X-Manager-Pin'] || null)
      if (!opts.headers['X-Manager-Pin']) {
        return respond({ detail: { message: 'این عملیات نیاز به تأیید مدیر دارد', code: 'override_required' } }, 403)
      }
      return respond({ ok: true })
    })

    wrap(<OverrideProvider><div /></OverrideProvider>)

    const pending = api('/orders/1/void', { method: 'POST', body: { reason: 'خطا' } })
    // the dialog appears with the server's message
    await waitFor(() => expect(document.querySelector('.ant-modal-title')?.textContent).toContain('تأیید مدیر'))
    expect(screen.getByText(/نیاز به تأیید مدیر دارد/)).toBeTruthy()

    // manager types 1234 on the PIN pad
    for (const d of ['۱', '۲', '۳', '۴']) screen.getAllByRole('button').find((b) => b.textContent === d).click()
    await expect(pending).resolves.toEqual({ ok: true })
    expect(seen).toEqual([null, '1234'])          // first without, retried with the PIN
  })

  it('cancelling the dialog rejects the request instead of hanging', async () => {
    setToken('t')
    global.fetch = vi.fn(async () => respond({ detail: { message: 'تأیید لازم است', code: 'override_required' } }, 403))
    wrap(<OverrideProvider><div /></OverrideProvider>)
    const pending = api('/orders/1/void', { method: 'POST' })
    await waitFor(() => expect(document.querySelector('.ant-modal-title')?.textContent).toContain('تأیید مدیر'))
    screen.getByRole('button', { name: /close|بستن/i })?.click()
    await expect(pending).rejects.toBeInstanceOf(ApiError)
  })
})
