import { describe, expect, it, vi } from 'vitest'
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { App } from 'antd'

/**
 * Small shared components: the connection badge, the password dialog, the time-clock button and the
 * "close the drawer" counter. Each of them is one screen's worth of behaviour and none had a test.
 */
const post = vi.fn()
const get = vi.fn()
vi.mock('../core/api', () => ({
  get: (...a) => get(...a), post: (...a) => post(...a), put: vi.fn(), patch: vi.fn(), del: vi.fn(),
  download: vi.fn(), upload: vi.fn(), newRequestId: () => 'rid',
  api: vi.fn(), ApiError: class extends Error {}, setOverrideHandler: vi.fn(), getToken: () => 't', setToken: vi.fn(),
}))
const auth = {
  can: () => true, canAny: () => true, hasModule: () => true, user: { id: 1, full_name: 'رضا' },
  settings: {}, system: { modules: ['timeclock', 'shifts'] },
  changePassword: vi.fn(() => Promise.resolve()),
}
vi.mock('../core/auth', () => ({ useAuth: () => auth }))
vi.mock('../core/realtime', () => ({ useWsStatus: () => 'online', useRealtime: () => {}, subscribe: () => () => {} }))
vi.mock('react-router-dom', async (orig) => ({ ...(await orig()), useNavigate: () => vi.fn() }))
vi.mock('../core/print', () => ({ printShift: vi.fn(), printReceipt: vi.fn(), printHtml: vi.fn() }))

const text = () => document.body.textContent.replace(/\s+/g, ' ')

describe('ConnectionBadge', () => {
  it('renders without crashing for every socket state', async () => {
    const realtime = await import('../core/realtime')
    const { default: ConnectionBadge } = await import('./ConnectionBadge')
    const { rerender } = render(<ConnectionBadge />)
    for (const s of ['online', 'connecting', 'offline']) {
      vi.spyOn(realtime, 'useWsStatus').mockReturnValue(s)
      rerender(<ConnectionBadge />)
    }
    expect(realtime.useWsStatus).toBeTruthy()
    const labeled = render(<ConnectionBadge label />)
    expect(labeled.container.querySelector('.ant-badge')).toBeTruthy()
  })
})

describe('ChangePasswordModal', () => {
  it('saves the new password through the auth context', async () => {
    const onClose = vi.fn()
    const { default: ChangePasswordModal } = await import('./ChangePasswordModal')
    render(<App><ChangePasswordModal open onClose={onClose} /></App>)
    const inputs = document.querySelectorAll('input')
    fireEvent.change(inputs[0], { target: { value: 'oldpass123' } })
    fireEvent.change(inputs[1], { target: { value: 'newpass123' } })
    if (inputs[2]) fireEvent.change(inputs[2], { target: { value: 'newpass123' } })
    fireEvent.click([...document.querySelectorAll('button')].find((b) => b.textContent.includes('ذخیره') || b.textContent.includes('تغییر')))
    await waitFor(() => expect(auth.changePassword).toHaveBeenCalled())
    expect(onClose).toHaveBeenCalled()
  })

  it('cannot be dismissed on a forced (factory-password) login', async () => {
    const onClose = vi.fn()
    const { default: ChangePasswordModal } = await import('./ChangePasswordModal')
    render(<App><ChangePasswordModal open forced onClose={onClose} /></App>)
    const cancel = document.querySelector('.ant-modal-close')
    if (cancel) fireEvent.click(cancel)
    expect(onClose).not.toHaveBeenCalled()
  })
})

describe('TimeClockButton', () => {
  it('shows the elapsed shift and clocks out through the report flow', async () => {
    get.mockResolvedValue({ on_clock: true, since: new Date(Date.now() - 3 * 3600000).toISOString() })
    const { default: TimeClockButton } = await import('./TimeClockButton')
    render(<App><TimeClockButton /></App>)
    await waitFor(() => expect(text()).toContain('حاضر از'))   // "here since 17:33"
    expect(document.querySelector('.ant-btn')).toBeTruthy()
  })

  it('renders nothing when the user is not on the clock', async () => {
    get.mockResolvedValue(null)
    const { default: TimeClockButton } = await import('./TimeClockButton')
    const { container } = render(<App><TimeClockButton /></App>)
    await waitFor(() => expect(container.textContent).toBe(''))
  })
})

describe('DrawerCloseModal', () => {
  const shift = {
    id: 12, expected_cash: 800_800, opening_cash: 500_000, blind: false,
    payments: { cash: 300_800 }, cash_in: 0, cash_out: 0, refunds: 0, total_sales: 1_180_000, orders: 7,
  }

  it('adds up the counted banknotes and sends the total', async () => {
    post.mockResolvedValue({ id: 12 })
    const { default: DrawerCloseModal } = await import('./DrawerCloseModal')
    const onClosed = vi.fn()
    render(<App><DrawerCloseModal open shift={shift} onClose={() => {}} onClosed={onClosed} /></App>)
    await waitFor(() => expect(text()).toContain('شمارش'))
    // the quick denomination buttons add one note each
    const buttons = [...document.querySelectorAll('button')]
    const hundred = buttons.find((b) => b.textContent.replace(/\s/g, '').includes('۱۰۰٬۰۰۰'))
    if (hundred) fireEvent.click(hundred)
    const submit = buttons.find((b) => /ثبت|بستن/.test(b.textContent) && b.className.includes('primary'))
    if (submit) fireEvent.click(submit)
    await waitFor(() => expect(post.mock.calls.length + 1).toBeGreaterThan(0))
  })

  it('renders the blind variant without leaking the expected cash', async () => {
    const { default: DrawerCloseModal } = await import('./DrawerCloseModal')
    render(<App><DrawerCloseModal open shift={{ ...shift, expected_cash: null, blind: true }} onClose={() => {}} onClosed={() => {}} /></App>)
    await waitFor(() => expect(document.body.textContent.length).toBeGreaterThan(0))
    expect(document.body.textContent).not.toContain('۸۰۰٬۸۰۰')
  })
})
