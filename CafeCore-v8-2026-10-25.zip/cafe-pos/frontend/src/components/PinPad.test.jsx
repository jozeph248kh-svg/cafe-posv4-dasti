import { describe, expect, it, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import PinPad from './PinPad'

// The PIN pad is the only way staff can log in on a shared tablet: it has to work by touch AND with
// a physical keyboard, submit exactly once at the right length, and never grow past maxLength.
const type = (keys) => keys.forEach((k) => screen.getByText(k).click())

describe('PinPad', () => {
  it('submits once when the last digit of a 4-digit PIN is pressed', async () => {
    const onSubmit = vi.fn()
    render(<PinPad onSubmit={onSubmit} length={4} />)
    type(['۱', '۲', '۳', '۴'])
    await waitFor(() => expect(onSubmit).toHaveBeenCalledTimes(1))
    expect(onSubmit).toHaveBeenCalledWith('1234')
  })

  it('works with the physical keyboard too', async () => {
    const onSubmit = vi.fn()
    render(<PinPad onSubmit={onSubmit} length={4} />)
    const user = userEvent.setup()
    await user.keyboard('5678')
    await waitFor(() => expect(onSubmit).toHaveBeenCalledWith('5678'))
  })

  it('deletes and clears', async () => {
    const onSubmit = vi.fn()
    render(<PinPad onSubmit={onSubmit} length={4} />)
    type(['۱', '۲'])
    screen.getByText('پاک').click()                 // clear
    type(['۹'])
    await waitFor(() => expect(screen.getAllByRole('button').length).toBeGreaterThan(0))
    expect(onSubmit).not.toHaveBeenCalled()
  })

  it('never collects more digits than maxLength', async () => {
    const onSubmit = vi.fn()
    const { container } = render(<PinPad onSubmit={onSubmit} length={4} maxLength={4} />)
    type(['۱', '۲', '۳', '۴', '۵', '۶'])
    await waitFor(() => expect(onSubmit).toHaveBeenCalledTimes(1))
    expect(onSubmit).toHaveBeenCalledWith('1234')    // the 5th and 6th presses are ignored
    expect(container.querySelectorAll('.pin-dots span.on').length).toBeLessThanOrEqual(4)
  })

  it('clears the entry when the login is rejected', async () => {
    const onSubmit = vi.fn()
    const { container, rerender } = render(<PinPad onSubmit={onSubmit} length={4} />)
    type(['۱', '۲', '۳', '۴'])
    await waitFor(() => expect(container.querySelectorAll('.pin-dots span.on').length).toBe(4))
    rerender(<PinPad onSubmit={onSubmit} length={4} error={{ message: 'رمز اشتباه' }} />)
    await waitFor(() => expect(container.querySelectorAll('.pin-dots span.on').length).toBe(0))
  })
})
