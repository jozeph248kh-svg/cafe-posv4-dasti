import { act, render, screen, waitFor } from '@testing-library/react'
import { App } from 'antd'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const get = vi.fn()
vi.mock('../core/api', () => ({ get: (...a) => get(...a), post: vi.fn(), put: vi.fn(), patch: vi.fn(), del: vi.fn() }))
let handler = null
vi.mock('../core/realtime', () => ({ useRealtime: (topics, fn) => { handler = { topic: topics[0], fn } } }))
vi.mock('../core/auth', () => ({ useAuth: () => ({ can: () => true }) }))

const { default: StockAlertsBadge } = await import('./StockAlertsBadge')

const ALERT = { id: 1, ingredient_id: 4, name: 'شیر', unit: 'g', stock_before: 500, stock_after: -300, shortage: 300, occurrences: 2 }

describe('<StockAlertsBadge>', () => {
  beforeEach(() => get.mockReset())

  it('stays hidden when nothing is short', async () => {
    get.mockResolvedValue([])
    const { container } = render(<App><StockAlertsBadge /></App>)
    await waitFor(() => expect(get).toHaveBeenCalledWith('/inventory/alerts'))
    expect(container.querySelector('.stock-alert-tag')).toBeNull()
  })

  it('shows the count and the item / before / after / shortage', async () => {
    get.mockResolvedValue([ALERT])
    const { container } = render(<App><StockAlertsBadge /></App>)
    await waitFor(() => expect(container.querySelector('.stock-alert-tag')).toBeTruthy())
    expect(container.querySelector('.ant-badge-count').textContent).toMatch(/1|۱/)
    screen.getByText('موجودی منفی').click()                       // open the popover
    await waitFor(() => expect(screen.getByText('شیر')).toBeTruthy())
    const text = document.body.textContent.replace(/\s+/g, ' ')
    expect(text).toContain('کسری')
    expect(text).toContain('۳۰۰')                                 // the shortage, in Persian digits
    expect(text).toContain('−۳۰۰')                                // stock after the sale
  })

  it('reloads when the live negative-stock event arrives', async () => {
    get.mockResolvedValue([])
    const { container } = render(<App><StockAlertsBadge /></App>)
    await waitFor(() => expect(get).toHaveBeenCalled())
    expect(handler.topic).toBe('inventory.negative')
    get.mockResolvedValue([ALERT])
    await act(async () => { handler.fn() })
    await waitFor(() => expect(container.querySelector('.stock-alert-tag')).toBeTruthy())
  })
})
