import { Spin } from 'antd'
import { Suspense, lazy } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useAuth } from './core/auth'
import ChangePasswordModal from './components/ChangePasswordModal'
import AdminLayout from './layouts/AdminLayout'
import { ADMIN_PAGES, APPS, visible } from './modules/registry'
import Launcher from './pages/Launcher'
import Login from './pages/Login'

const PosPage = lazy(() => import('./modules/pos/PosPage'))
const MyShift = lazy(() => import('./pages/MyShift'))
const KdsPage = lazy(() => import('./modules/kitchen/KdsPage'))
const QrMenu = lazy(() => import('./modules/public/QrMenu'))
const OrderApp = lazy(() => import('./modules/online/OrderApp'))
const Track = lazy(() => import('./modules/online/Track'))

export const Loading = () => <div className="center-screen"><Spin size="large" /></div>

function RequireAuth({ children, app }) {
  const auth = useAuth()
  const loc = useLocation()
  if (!auth.ready) return <Loading />
  if (!auth.user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  if (auth.mustChange) return <div className="center-screen"><ChangePasswordModal open forced /></div>
  if (app && !visible(auth, APPS.find((a) => a.key === app))) return <Navigate to="/" replace />
  return children
}

function AdminHome() {
  const auth = useAuth()
  const first = ADMIN_PAGES.find((p) => visible(auth, p))
  return first ? <Navigate to={`/admin/${first.path}`} replace /> : <Navigate to="/" replace />
}

export default function App() {
  const auth = useAuth()
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/menu/:token?" element={<QrMenu />} />
        <Route path="/order" element={<OrderApp />} />
        <Route path="/order/track/:token" element={<Track />} />
        <Route path="/" element={<RequireAuth><Launcher /></RequireAuth>} />
        <Route path="/pos" element={<RequireAuth app="pos"><PosPage /></RequireAuth>} />
        <Route path="/kds" element={<RequireAuth app="kds"><KdsPage /></RequireAuth>} />
        <Route path="/my-shift" element={<RequireAuth app="myshift"><Suspense fallback={<Loading />}><MyShift /></Suspense></RequireAuth>} />
        <Route path="/admin" element={<RequireAuth app="admin"><AdminLayout /></RequireAuth>}>
          <Route index element={<AdminHome />} />
          {ADMIN_PAGES.filter((p) => !auth.user || visible(auth, p)).map((p) => (
            <Route key={p.key} path={p.path} element={<Suspense fallback={<Loading />}><p.element /></Suspense>} />
          ))}
          <Route path="*" element={<AdminHome />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
