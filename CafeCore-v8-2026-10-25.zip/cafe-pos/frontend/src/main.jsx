import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import 'vazirmatn/misc/Farsi-Digits/Vazirmatn-FD-font-face.css'
import './index.css'
import './core/jalali'
import App from './App'
import OverrideProvider from './components/OverrideProvider'
import { AuthProvider } from './core/auth'
import { ThemeProvider } from './core/theme'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <OverrideProvider>
            <App />
          </OverrideProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
