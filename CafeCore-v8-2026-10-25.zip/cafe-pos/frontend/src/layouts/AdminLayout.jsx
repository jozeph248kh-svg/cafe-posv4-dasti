import { AppstoreOutlined, KeyOutlined, LogoutOutlined, MenuFoldOutlined, MenuUnfoldOutlined, UserOutlined } from '@ant-design/icons'
import ChangePasswordModal from '../components/ChangePasswordModal'
import { Avatar, Button, Drawer, Dropdown, Grid, Layout, Menu, Space, Tooltip, Typography } from 'antd'
import { useMemo, useState } from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import ConnectionBadge from '../components/ConnectionBadge'
import StockAlertsBadge from '../components/StockAlertsBadge'
import TimeClockButton from '../components/TimeClockButton'
import { useAuth } from '../core/auth'
import { colorOf, faToday, initials } from '../core/format'
import ThemeSwitcher from '../components/ThemeSwitcher'
import { ADMIN_PAGES, visible } from '../modules/registry'

const { Sider, Header, Content } = Layout

export default function AdminLayout() {
  const auth = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const screens = Grid.useBreakpoint()
  const mobile = !screens.lg
  const [collapsed, setCollapsed] = useState(false)
  const [drawer, setDrawer] = useState(false)
  const [pwd, setPwd] = useState(false)

  const items = useMemo(() => {
    const groups = {}
    ADMIN_PAGES.filter((p) => visible(auth, p)).forEach((p) => {
      (groups[p.group] = groups[p.group] || []).push({ key: `/admin/${p.path}`, icon: p.icon, label: p.title })
    })
    return Object.entries(groups).map(([g, children]) => ({ type: 'group', key: g, label: g, children }))
  }, [auth])

  const selected = ADMIN_PAGES.map((p) => `/admin/${p.path}`).filter((k) => loc.pathname.startsWith(k)).sort((a, b) => b.length - a.length)[0]
  const page = ADMIN_PAGES.find((p) => `/admin/${p.path}` === selected)
  const brand = (
    <div className="brand" onClick={() => nav('/')}>
      <div className="brand-logo">☕</div>
      {(!collapsed || mobile) && <div><div className="brand-name">{auth.settings['business.name'] || 'کافه‌پوز'}</div><div className="brand-sub">پنل مدیریت</div></div>}
    </div>
  )
  const menu = <Menu theme="dark" mode="inline" selectedKeys={[selected]} items={items} onClick={({ key }) => { nav(key); setDrawer(false) }} />

  return (
    <Layout style={{ minHeight: '100vh' }}>
      {mobile ? (
        <Drawer open={drawer} onClose={() => setDrawer(false)} placement="right" width={260} styles={{ body: { padding: 0, background: 'var(--sider-bg)' }, header: { display: 'none' } }}>
          <div className="app-sider">{brand}{menu}</div>
        </Drawer>
      ) : (
        <Sider className="app-sider" width={240} collapsedWidth={76} collapsed={collapsed} style={{ position: 'sticky', top: 0, height: '100vh', overflow: 'auto' }}>
          {brand}{menu}
        </Sider>
      )}
      <Layout>
        <Header className="app-header">
          <Space>
            <Button type="text" icon={mobile || collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />} onClick={() => (mobile ? setDrawer(true) : setCollapsed(!collapsed))} />
            {page && <div className="hdr-crumb"><span className="g">{page.group}</span><span className="sep" /><span className="t">{page.title}</span></div>}
            {screens.xl && <Typography.Text type="secondary" style={{ fontSize: 12.5, marginInlineStart: 6 }}>{faToday()}</Typography.Text>}
          </Space>
          <Space size={4}>
            <TimeClockButton compact={mobile} />
            <StockAlertsBadge />
            <ConnectionBadge />
            <Tooltip title="برنامه‌ها"><Button type="text" icon={<AppstoreOutlined />} onClick={() => nav('/')} /></Tooltip>
            <ThemeSwitcher />
            <Dropdown menu={{ items: [
              { key: 'r', icon: <UserOutlined />, label: auth.user.role_title, disabled: true },
              { type: 'divider' },
              { key: 'pwd', icon: <KeyOutlined />, label: 'تغییر رمز عبور', onClick: () => setPwd(true) },
              { key: 'out', icon: <LogoutOutlined />, label: 'خروج', danger: true, onClick: () => { auth.logout(); nav('/login') } },
            ] }}>
              <Space style={{ cursor: 'pointer', paddingInline: 8 }}>
                <Avatar style={{ background: colorOf(auth.user.full_name) }}>{initials(auth.user.full_name)}</Avatar>
                {!mobile && <span>{auth.user.full_name}</span>}
              </Space>
            </Dropdown>
          </Space>
        </Header>
        <ChangePasswordModal open={pwd} onClose={() => setPwd(false)} />
        <Content className="app-content"><Outlet /></Content>
      </Layout>
    </Layout>
  )
}
